extends Control
const UltravioletInfo=preload("res://ui/ultraviolet_growth_info.gd")
const NativeOwnerProgress=preload("res://ui/native_owner_progress_info.gd")
const NativeScoutInfo=preload("res://ui/native_scout_decision_info.gd")
const AttackGainOrder = preload("res://core/attack_gain_order.gd")
## All game mutations go through Game.apply_command; this file owns presentation only.

const OutbackSettings = preload("res://ui/outback_settings.gd")
const DamageSettings = preload("res://ui/damage_listener_settings.gd")
const BeetleSettings = preload("res://ui/beetle_growth_settings.gd")
const OwnerAuraDisplay = preload("res://ui/owner_aura_display.gd")
const RecruitQuests = preload("res://core/recruit_quest_predicates.gd")
const CatalogScript = preload("res://core/catalog.gd")
const RoomScript = preload("res://core/room_config.gd")
const GameScript = preload("res://core/game.gd")
const MagneticRules = preload("res://core/magnetic_rules.gd")
const CustomShop = preload("res://core/custom_shop.gd")
const ChooseOne = preload("res://core/choose_one_effects.gd")
const LobbyTribes = preload("res://core/lobby_tribes.gd")
const TribeRules = preload("res://core/tribe_pool_rules.gd")
const MinionActivate = preload("res://core/minion_activate.gd")
const BuddyButton = preload("res://core/buddy_button.gd")
const NativePrizes = preload("res://core/native_prizes.gd")
const PrizeCoinRoom = preload("res://core/prize_coin_room.gd")
const MinionPriceOrder = preload("res://core/minion_price_order.gd")
const AttackUnlock = preload("res://core/attack_unlock_hero.gd")
const PeriodicHero = preload("res://core/periodic_spell_hero.gd")
const TavernAmplifier = preload("res://core/tavern_spell_amplifiers.gd")
const NextSpellDiscount = preload("res://core/next_spell_discount.gd")
const DelayedMinionGold = preload("res://core/delayed_minion_gold.gd")
const DelayedIncomeRoom = preload("res://core/delayed_income_room.gd")
const EndTurnCategoryOrder = preload("res://core/end_turn_category_order.gd")
const ShopRefreshCategoryOrder = preload("res://core/shop_refresh_category_order.gd")
const RefreshGemBarrage = preload("res://core/refresh_gem_barrage.gd")
const RefreshOwnerBuffs = preload("res://core/refresh_owner_buffs.gd")
const RefreshOffers = preload("res://core/refresh_extra_offers.gd")
const CurrentScope=preload("res://core/current_scope.gd")
const TRIBE_MODES = ["all", "manual", "random"]
const ROOM_PATH = "user://rooms/default.json"
const SAVE_PATH = "user://saves/latest.json"
const KINDS = ["minion", "hero", "spell", "anomaly", "trinket", "quest", "reward"]
const KIND_NAMES = ["随从", "英雄", "酒馆法术", "畸变", "饰品", "任务", "任务奖励 / 黑暗之赐"]
const POOL_KEYS = {
	"minion": "enabled_minions", "hero": "enabled_heroes", "spell": "enabled_spells",
	"anomaly": "enabled_anomalies", "trinket": "enabled_trinkets", "quest": "enabled_quests", "reward": "enabled_rewards", "prize": "enabled_prizes"
}
const BG = Color("101719")
const SURFACE = Color("192326")
const PANEL = Color("1f2b2d")
const BORDER = Color("344548")
const TEXT = Color("eee7d8")
const MUTED = Color("9daeb0")
const GOLD = Color("ecc57b")
const TEAL = Color("7ec5b0")
const RED = Color("e59389")
const KEYWORDS = {"charge": "冲锋（战棋不额外攻击）", "taunt": "嘲讽", "divine_shield": "圣盾", "reborn": "复生", "windfury": "风怒", "poisonous": "剧毒", "venomous": "烈毒", "magnetic": "磁力"}
const TRIBES = {"beast": "野兽", "demon": "恶魔", "dragon": "龙", "elemental": "元素", "mech": "机械", "murloc": "鱼人", "naga": "纳迦", "pirate": "海盗", "quilboar": "野猪人", "undead": "亡灵", "all": "全部种族"}

var catalog = CatalogScript.new()
var room = RoomScript.new()
var game = GameScript.new()
var screen = "room"
var page: VBoxContainer
var notices: Label
var room_validation: Label
var room_summary: Label
var pool_count: Label
var pool_list: VBoxContainer
var pool_search_field: LineEdit
var pool_supported_filter: CheckBox
var pool_selected_filter: CheckBox
var room_settings_scroll: ScrollContainer
var hero_picker: OptionButton
var start_button: Button
var pool_kind = "minion"
var pool_query = ""
var pool_supported_only = false
var pool_selected_only = false
var selected_board = -1
var selected_shop = -1
var pool_page = 0
const POOL_PAGE_SIZE = 40
var pool_page_bar: HBoxContainer
var seed_valid = true
var selected_hand = -1
var message = ""
var message_is_error = false
var current_tab_buttons: Array[Button] = []
var current_checkboxes: Dictionary = {}
var season_items: Array = []
var hero_items: Array = []
var _ready_complete = false
var active_dialog: AcceptDialog
var recruit_scroll: ScrollContainer
var opponents_scroll: ScrollContainer
var saved_recruit_scroll = 0
var saved_opponents_scroll = 0
var rendered_round = -1
var scroll_build_revision = 0
var restoring_game_scroll = false
var tribe_mode_picker: OptionButton
var tribe_historical_checkbox: CheckBox
var tribe_checkboxes: Dictionary = {}
var tribe_preview_label: Label
var tribe_rules_label: Label
var room_rules_label: Label
var lobby_preview: Dictionary = {}
var beetle_settings: VBoxContainer
var outback_settings: VBoxContainer
var damage_settings: VBoxContainer
var native_buddy_checkbox: CheckBox
var native_buddy_summary: Label
var native_prize_checkbox: CheckBox
var native_prize_summary: Label
var prize_choice_picker: OptionButton
var prize_delivery_picker: OptionButton
var attack_gain_order_picker: OptionButton
var coin_order_picker: OptionButton
var minion_price_picker: OptionButton
var delayed_income_picker: OptionButton
var end_turn_category_picker: OptionButton
var shop_refresh_category_picker: OptionButton
var refresh_gem_barrage_picker: OptionButton
var refresh_owner_buff_picker: OptionButton
var refresh_extra_offer_picker: OptionButton
var pool_help: Label
var recruit_drag: Dictionary = {}
var recruit_drag_serial: int = 0

func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_build_theme()
	var background = ColorRect.new()
	background.color = BG
	background.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	background.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(background)
	var top_line = ColorRect.new()
	top_line.color = GOLD
	top_line.set_anchors_and_offsets_preset(Control.PRESET_TOP_WIDE)
	top_line.offset_bottom = 3
	top_line.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(top_line)
	var margin = MarginContainer.new()
	margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	margin.add_theme_constant_override("margin_left", 26)
	margin.add_theme_constant_override("margin_right", 26)
	margin.add_theme_constant_override("margin_top", 20)
	margin.add_theme_constant_override("margin_bottom", 18)
	add_child(margin)
	page = VBoxContainer.new()
	page.add_theme_constant_override("separation", 16)
	margin.add_child(page)
	catalog.load_catalog()
	if not catalog.load_errors.is_empty():
		message = "数据加载提示：" + "；".join(catalog.load_errors)
		message_is_error = true
	room.reset(catalog)
	if message.is_empty() and not FileAccess.file_exists(SAVE_PATH):
		message = "首次游玩：点击左侧底部“新建对局”。开局后用右上角“保存对局”保存进度；“保存房间”仅保存卡池配置。"
	_ready_complete = true
	_build_room()

func _build_theme() -> void:
	var theme_data = Theme.new()
	var font = load("res://ui/assets/tavern_cjk.ttc")
	if font != null:
		theme_data.default_font = font
	theme_data.default_font_size = 16
	theme_data.set_color("font_color", "Label", TEXT)
	theme_data.set_color("font_color", "Button", TEXT)
	theme_data.set_color("font_hover_color", "Button", Color.WHITE)
	theme_data.set_color("font_disabled_color", "Button", Color("607073"))
	for kind in ["Button", "OptionButton", "MenuButton"]:
		theme_data.set_stylebox("normal", kind, _style(PANEL, BORDER, 8, 12, 8))
		theme_data.set_stylebox("hover", kind, _style(Color("2b3b3e"), TEAL, 8, 12, 8))
		theme_data.set_stylebox("pressed", kind, _style(Color("354b46"), GOLD, 8, 12, 8))
		theme_data.set_stylebox("disabled", kind, _style(Color("162023"), Color("263437"), 8, 12, 8))
		theme_data.set_stylebox("focus", kind, _focus_style())
	theme_data.set_stylebox("normal", "LineEdit", _style(Color("111b1e"), BORDER, 7, 12, 8))
	theme_data.set_stylebox("focus", "LineEdit", _style(Color("152124"), TEAL, 7, 12, 8))
	theme_data.set_color("font_color", "LineEdit", TEXT)
	theme_data.set_color("font_placeholder_color", "LineEdit", MUTED)
	theme_data.set_stylebox("panel", "PopupMenu", _style(SURFACE, BORDER, 10, 12, 10))
	theme_data.set_stylebox("panel", "AcceptDialog", _style(SURFACE, GOLD, 10, 20, 20))
	theme_data.set_stylebox("panel", "TooltipPanel", _style(Color("0d1619"), TEAL, 8, 14, 12))
	theme_data.set_color("font_color", "TooltipLabel", TEXT)
	theme_data.set_font_size("font_size", "TooltipLabel", 16)
	theme_data.set_stylebox("scroll", "VScrollBar", _style(Color("111a1c"), Color("111a1c"), 4, 4, 4))
	theme_data.set_stylebox("grabber", "VScrollBar", _style(BORDER, BORDER, 4, 4, 4))
	theme_data.set_stylebox("grabber_highlight", "VScrollBar", _style(TEAL, TEAL, 4, 4, 4))
	theme_data.set_color("font_color", "CheckBox", TEXT)
	theme_data.set_constant("h_separation", "CheckBox", 8)
	theme = theme_data

func _style(color: Color, border: Color = BORDER, radius: int = 10, pad_x: int = 16, pad_y: int = 14) -> StyleBoxFlat:
	var box = StyleBoxFlat.new()
	box.bg_color = color
	box.border_color = border
	box.set_border_width_all(1)
	box.set_corner_radius_all(radius)
	box.content_margin_left = pad_x
	box.content_margin_right = pad_x
	box.content_margin_top = pad_y
	box.content_margin_bottom = pad_y
	return box

func _focus_style() -> StyleBoxFlat:
	var box = StyleBoxFlat.new()
	box.bg_color = Color.TRANSPARENT
	box.border_color = TEAL
	box.set_border_width_all(2)
	box.set_corner_radius_all(8)
	return box

func _clear(node: Node) -> void:
	for child in node.get_children():
		node.remove_child(child)
		child.queue_free()

func _label(text_value: String, size_value: int = 16, color: Color = TEXT, wrap: bool = false) -> Label:
	var label = Label.new()
	label.text = text_value
	label.add_theme_font_size_override("font_size", size_value)
	label.add_theme_color_override("font_color", color)
	if wrap:
		label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	return label

func _button(title: String, action: Callable, accent: bool = false) -> Button:
	var button = Button.new()
	button.text = title
	button.custom_minimum_size.y = 40
	button.mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND
	if action.is_valid():
		button.pressed.connect(action)
	if accent:
		button.add_theme_stylebox_override("normal", _style(GOLD, GOLD, 8, 16, 10))
		button.add_theme_stylebox_override("hover", _style(Color("ffdfa0"), Color("ffdfa0"), 8, 16, 10))
		button.add_theme_stylebox_override("pressed", _style(Color("bc9653"), GOLD, 8, 16, 10))
		button.add_theme_color_override("font_color", Color("202927"))
		button.add_theme_color_override("font_hover_color", Color("202927"))
		button.add_theme_color_override("font_pressed_color", Color("202927"))
	return button

func _row(separation: int = 10) -> HBoxContainer:
	var row = HBoxContainer.new()
	row.add_theme_constant_override("separation", separation)
	return row

func _column(separation: int = 10) -> VBoxContainer:
	var column = VBoxContainer.new()
	column.add_theme_constant_override("separation", separation)
	return column

func _panel(parent: Node, color: Color = SURFACE, border: Color = BORDER) -> VBoxContainer:
	var panel = PanelContainer.new()
	panel.add_theme_stylebox_override("panel", _style(color, border))
	parent.add_child(panel)
	var content = _column(12)
	panel.add_child(content)
	return content

func _expand(node: Control) -> Control:
	node.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	return node

func _spacer(parent: Node) -> void:
	var spacer = Control.new()
	spacer.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	parent.add_child(spacer)

func _pill(text_value: String, color: Color = TEAL) -> PanelContainer:
	var panel = PanelContainer.new()
	panel.add_theme_stylebox_override("panel", _style(Color(color, 0.08), Color(color, 0.4), 12, 10, 4))
	panel.add_child(_label(text_value, 13, color))
	return panel

func _header(subtitle: String) -> HBoxContainer:
	var row = _row(14)
	var emblem = _pill("BG\nLAB", GOLD)
	row.add_child(emblem)
	var titles = _column(0)
	titles.add_child(_label("暮光酒馆", 29, TEXT))
	titles.add_child(_label(subtitle, 13, MUTED))
	row.add_child(titles)
	_spacer(row)
	page.add_child(row)
	return row

func _notice_bar() -> void:
	notices = _label(message if not message.is_empty() else "本地单机 · 无网络服务 · 可复现随机种子", 14, RED if message_is_error else MUTED)
	notices.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	page.add_child(notices)

func _notify(text_value: String, is_error: bool = false) -> void:
	message = text_value
	message_is_error = is_error
	if is_instance_valid(notices):
		notices.text = text_value
		notices.add_theme_color_override("font_color", RED if is_error else TEAL)

func _build_room() -> void:
	_capture_game_scroll()
	scroll_build_revision += 1
	restoring_game_scroll = false
	_dismiss_dialog()
	screen = "room"
	_clear(page)
	var header = _header("BATTLEGROUNDS SANDBOX / 房间实验室")
	header.add_child(_pill("自定义规则 sandbox-1", GOLD))
	if not game.state.is_empty():
		header.add_child(_button("继续对局", _build_game))
	header.add_child(_button("载入对局", _load_game))
	var body = _row(18)
	body.size_flags_vertical = Control.SIZE_EXPAND_FILL
	page.add_child(body)
	_build_room_settings(body)
	_build_pool_editor(body)
	_notice_bar()
	_refresh_room_summary()

func _build_room_settings(body: HBoxContainer) -> void:
	var outer = PanelContainer.new()
	outer.custom_minimum_size.x = 312
	outer.add_theme_stylebox_override("panel", _style(SURFACE, BORDER, 12, 18, 18))
	body.add_child(outer)
	var layout = _column(12)
	outer.add_child(layout)
	var scroll = ScrollContainer.new()
	room_settings_scroll = scroll
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	layout.add_child(scroll)
	var column = _column(12)
	column.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.add_child(column)
	column.add_child(_label("01   房间设置", 20, GOLD))
	column.add_child(_label("配置一个只属于你的酒馆。", 14, MUTED))
	var title_field = LineEdit.new()
	title_field.placeholder_text = "房间名称"
	title_field.text = str(room.data.get("title", "我的酒馆"))
	title_field.text_changed.connect(func(value: String): room.data["title"] = value)
	column.add_child(title_field)
	column.add_child(_label("当前范围",14,MUTED))
	column.add_child(_label(CurrentScope.summary(),12,GOLD,true))
	column.add_child(_label("历史预设已隐藏，原源码/资料与旧存档保留。",12,MUTED,true))
	var retained_extra_row = _row(4)
	for extra_group in CurrentScope.EXTRA_LABELS:
		var group: String=str(extra_group)
		retained_extra_row.add_child(_button(group,func(): _show_scope_extra(group)))
	column.add_child(retained_extra_row)
	column.add_child(_button("查看非默认娜迦英雄/法术资料",_show_scope_optional))
	_build_tribe_settings(column)
	var number_row = _row(14)
	var bot_column = _column(5)
	bot_column.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	bot_column.add_child(_label("机器人", 14, MUTED))
	var bots = SpinBox.new()
	bots.min_value = 1
	bots.max_value = 7
	bots.step = 1
	bots.value = int(room.data.get("bot_count", 7))
	bots.value_changed.connect(func(value: float): room.data["bot_count"] = int(value); _refresh_room_summary())
	bot_column.add_child(bots)
	number_row.add_child(bot_column)
	var seed_column = _column(5)
	seed_column.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	seed_column.add_child(_label("随机种子", 14, MUTED))
	var seed_field = LineEdit.new()
	seed_field.name = "RoomSeed"
	seed_field.text = str(room.data.get("seed", 2026))
	seed_field.custom_minimum_size.x = 126
	seed_field.text_changed.connect(func(value: String):
		seed_valid = value.is_valid_int()
		if seed_valid:
			room.data["seed"] = int(value)
		else:
			_notify("随机种子必须是整数。", true)
		_refresh_room_summary()
	)
	seed_column.add_child(seed_field)
	number_row.add_child(seed_column)
	column.add_child(number_row)
	column.add_child(_label("我的英雄", 14, MUTED))
	hero_picker = OptionButton.new()
	hero_picker.custom_minimum_size.y = 40
	hero_picker.fit_to_longest_item = false
	hero_picker.item_selected.connect(_on_hero_selected)
	column.add_child(hero_picker)
	_populate_hero_picker()
	_build_native_buddy_settings(column)
	beetle_settings = BeetleSettings.new()
	column.add_child(beetle_settings)
	beetle_settings.configure(room,catalog,_refresh_room_summary)
	damage_settings = DamageSettings.new()
	column.add_child(damage_settings)
	damage_settings.configure(room,catalog,_refresh_room_summary)
	outback_settings = OutbackSettings.new()
	column.add_child(outback_settings)
	outback_settings.configure(room,catalog,_refresh_room_summary)
	_build_native_prize_settings(column)
	var rules_box = _panel(column, Color("23322f"), Color("3d5a50"))
	rules_box.add_child(_label("机制叠加 · 自定义规则", 15, TEAL))
	room_rules_label = _label("", 12, MUTED, true)
	room_rules_label.name = "RoomRulesSummary"
	rules_box.add_child(room_rules_label)
	column.add_child(_label("自定义任务目标", 14, MUTED))
	var requirement = SpinBox.new()
	requirement.min_value = 1
	requirement.max_value = 100
	requirement.step = 1
	requirement.value = int(room.data.get("quest_requirement", 6))
	requirement.value_changed.connect(func(value: float): room.data["quest_requirement"] = int(value))
	column.add_child(requirement)
	column.add_child(_label("官方动态难度未公开；此处设置自定义目标次数。", 12, MUTED, true))
	_build_quest_parameters(column)
	var footer = _column(9)
	layout.add_child(footer)
	room_summary = _label("", 14, TEXT, true)
	footer.add_child(room_summary)
	room_validation = _label("", 12, RED, true)
	footer.add_child(room_validation)
	start_button = _button("新建对局  →", _start_game, true)
	start_button.tooltip_text = "使用当前房间设置开始一局游戏；不需要预先保存。"
	start_button.custom_minimum_size.y = 52
	start_button.add_theme_font_size_override("font_size", 18)
	footer.add_child(start_button)
	var persist_row = _row(8)
	persist_row.add_child(_expand(_button("保存房间", _save_room)))
	persist_row.add_child(_expand(_button("载入房间", _load_room)))
	footer.add_child(persist_row)
	footer.add_child(_button("新建当前范围默认池", _reset_room))

func _build_quest_parameters(column: VBoxContainer) -> void:
	column.add_child(_label("非凡组合 · 本局两个购买类型", 14, MUTED))
	column.add_child(_label("选择该任务时须手动指定两种不同类型；双类型或全类型牌每次购买只计一次。", 12, MUTED, true))
	var line = _row(6)
	var picks: Array[OptionButton] = []
	var selected: Array = room.data.get("quest_parameters",{}).get(RecruitQuests.PAIR_QUEST,{}).get("tribes",[])
	for i in range(2):
		var pick = OptionButton.new()
		pick.name = "QuestTribeFirst" if i == 0 else "QuestTribeSecond"
		pick.add_item("请选择类型",0)
		pick.set_item_metadata(0,"")
		for tribe in RecruitQuests.TRIBES:
			pick.add_item(LobbyTribes.names_zh([tribe]))
			pick.set_item_metadata(pick.item_count-1,tribe)
			if i < selected.size() and selected[i] == tribe: pick.select(pick.item_count-1)
		pick.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		pick.custom_minimum_size.y = 36
		line.add_child(pick)
		picks.append(pick)
	for pick in picks:
		pick.item_selected.connect(func(_index: int):
			var tribes: Array = []
			for item in picks:
				var tribe: String = str(item.get_item_metadata(item.selected))
				if not tribe.is_empty(): tribes.append(tribe)
			if not room.data.has("quest_parameters"): room.data.quest_parameters = {}
			if tribes.size() == 2 and tribes[0] != tribes[1]: room.data.quest_parameters[RecruitQuests.PAIR_QUEST] = {"tribes":tribes}
			else: room.data.quest_parameters.erase(RecruitQuests.PAIR_QUEST)
			_refresh_room_summary()
		)
	column.add_child(line)


func _build_native_buddy_settings(column: VBoxContainer) -> void:
	native_buddy_checkbox = CheckBox.new()
	native_buddy_checkbox.name = "NativeBuddyEnabled"
	native_buddy_checkbox.text = "启用原生伙伴按钮（25.6+）"
	native_buddy_checkbox.add_theme_font_size_override("font_size", 14)
	native_buddy_checkbox.tooltip_text = "使用现代付费伙伴按钮。第一次领取1张，第二次领取2张；战斗胜利/平局降价3，失败降价2。英雄与普通、金色伙伴效果均须已实现。"
	native_buddy_checkbox.toggled.connect(_on_native_buddy_toggled)
	column.add_child(native_buddy_checkbox)
	native_buddy_summary = _label("", 12, MUTED, true)
	native_buddy_summary.name = "NativeBuddyRoomSummary"
	column.add_child(native_buddy_summary)
	var filter_button = _button("只保留伙伴效果已实现的英雄", _filter_native_buddy_heroes)
	filter_button.name = "NativeBuddyFilterHeroes"
	filter_button.add_theme_font_size_override("font_size", 13)
	filter_button.tooltip_text = "主动修改当前英雄池：只保留已有来源映射，且英雄、普通伙伴和金色伙伴效果全部通过验证的已选英雄。不会加入未选英雄。"
	column.add_child(filter_button)

func _on_native_buddy_toggled(enabled: bool) -> void:
	room.data["native_buddies"] = enabled
	_refresh_room_summary()

func _filter_native_buddy_heroes() -> void:
	var heroes: Array = _pool("hero")
	var retained: Array = []
	for id in heroes:
		if BuddyButton.binding_error(catalog, str(id)).is_empty():
			retained.append(id)
	room.data["enabled_heroes"] = retained
	_populate_hero_picker()
	_refresh_pool_list()
	_refresh_room_summary()
	_notify("已移除 %d 个伙伴组合未完整实现的英雄，保留 %d 个。%s" % [heroes.size() - retained.size(), retained.size(), "当前英雄池为空，请在英雄页主动选择已实现的伙伴英雄。" if retained.is_empty() else "英雄池已更新。"], retained.is_empty())

func _refresh_native_buddy_summary() -> void:
	if not is_instance_valid(native_buddy_summary):
		return
	var enabled: bool = BuddyButton.enabled(room.data)
	native_buddy_checkbox.set_pressed_no_signal(enabled)
	var heroes: Array = _pool("hero")
	var issues: PackedStringArray = []
	var supported: int = 0
	for id in heroes:
		var issue: String = BuddyButton.binding_error(catalog, str(id))
		if issue.is_empty():
			supported += 1
		else:
			issues.append(str(catalog.get_card(str(id)).get("name", id)) + "：" + issue)
	var lines: PackedStringArray = ["已选 %d 个英雄，%d 个伙伴组合完整实现。" % [heroes.size(), supported]]
	if enabled:
		lines.append("开启按钮不会自动删选；所有已选英雄都须通过伙伴校验。")
		if not issues.is_empty():
			lines.append(issues[0])
		elif heroes.is_empty():
			lines.append("请先选择至少一个伙伴效果已实现的英雄。")
	else:
		lines.append("当前关闭，不使用付费伙伴按钮。")
	native_buddy_summary.text = "\n".join(lines)
	native_buddy_summary.tooltip_text = "\n".join(issues) if not issues.is_empty() else "已选英雄的普通与金色伙伴均通过来源与效果校验。"
	native_buddy_summary.add_theme_color_override("font_color", RED if enabled and (not issues.is_empty() or heroes.is_empty()) else MUTED)

func _build_native_prize_settings(column: VBoxContainer) -> void:
	native_prize_checkbox = CheckBox.new()
	native_prize_checkbox.name = "NativePrizeEnabled"
	native_prize_checkbox.text = "独立暗月奖品已暂停（原英雄/畸变依赖保留）"
	native_prize_checkbox.visible=false
	native_prize_checkbox.tooltip_text = "每4回合选择暗月奖品，等级依次1、2、3、4，此后维持4级。与正式奖品畸变同时开启也只发放一次。"
	native_prize_checkbox.toggled.connect(_on_native_prize_toggled)
	column.add_child(native_prize_checkbox)
	column.add_child(_label("本地混搭顺序 · 请主动选择", 13, GOLD))
	prize_choice_picker = OptionButton.new()
	prize_choice_picker.name = "NativePrizeChoiceOrder"
	prize_choice_picker.fit_to_longest_item = false
	prize_choice_picker.custom_minimum_size.y = 40
	for title in ["第4轮发现：请选择", "第4轮发现：任务先选", "第4轮发现：奖品先选"]:
		prize_choice_picker.add_item(title)
	prize_choice_picker.tooltip_text = "仅决定第4轮任务与奖品同时出现时的本地选择顺序，不代表官方顺序。未启用任务时可保留未指定。"
	prize_choice_picker.item_selected.connect(_on_prize_choice_selected)
	column.add_child(prize_choice_picker)
	prize_delivery_picker = OptionButton.new()
	prize_delivery_picker.name = "NativePrizeDeliveryOrder"
	prize_delivery_picker.fit_to_longest_item = false
	prize_delivery_picker.custom_minimum_size.y = 40
	for title in ["保护待发：请选择", "操作结算后先补奖品", "操作结算后先补已有来源"]:
		prize_delivery_picker.add_item(title)
	prize_delivery_picker.tooltip_text = "操作本身先结算，再按所选本地顺序处理奖品与已有来源的待发；同源奖品按产生回合先后补发。此处不是官方优先级。"
	prize_delivery_picker.item_selected.connect(_on_prize_delivery_selected)
	column.add_child(prize_delivery_picker)
	coin_order_picker = OptionButton.new()
	coin_order_picker.name = "MixedEndTurnOrder"
	coin_order_picker.fit_to_longest_item = false
	coin_order_picker.custom_minimum_size.y = 40
	for title in ["回合末返币：未指定", "回合末：先返币，再结算其它来源", "回合末：先结算其它来源，再返币"]:
		coin_order_picker.add_item(title)
	coin_order_picker.tooltip_text = "这是本地自选规则，适用于所有玩家和机器人。仅无穷铸币与战队、机制、英雄或回合末任务产生可观察先后冲突时必须选择；共同临时手牌到期和最终待发清理在两者之后。不会解除未核实的单卡效果。"
	coin_order_picker.item_selected.connect(_on_coin_order_selected)
	column.add_child(coin_order_picker)
	column.add_child(_label("回合末整组顺序 · 本地自选沙盒规则（非官方）", 12, MUTED, true))
	end_turn_category_picker = OptionButton.new()
	end_turn_category_picker.name = "EndTurnCategoryOrder"
	end_turn_category_picker.fit_to_longest_item = false
	end_turn_category_picker.custom_minimum_size.y = 40
	end_turn_category_picker.add_item("回合末整组顺序：未指定")
	end_turn_category_picker.set_item_metadata(0, "")
	for option in EndTurnCategoryOrder.options():
		end_turn_category_picker.add_item(option.label)
		end_turn_category_picker.set_item_metadata(end_turn_category_picker.item_count - 1, option.value)
	end_turn_category_picker.tooltip_text = "本地自选沙盒规则，非官方顺序，适用于所有玩家和机器人。只移动整组随从与整组机制（已启用畸变、已获得饰品、已获得任务奖励），不拆分或交替执行；保留各组内部顺序。仅经校验确认有可观察顺序冲突时须主动选择；空白不自动选第一项。返币规则与英雄阶段独立，不改变未核实单卡或组合的限制。"
	end_turn_category_picker.item_selected.connect(_on_end_turn_category_selected)
	column.add_child(end_turn_category_picker)
	column.add_child(_label("刷新后整组顺序 · 本地自选沙盒规则（非官方）", 12, MUTED, true))
	shop_refresh_category_picker = OptionButton.new()
	shop_refresh_category_picker.name = "ShopRefreshCategoryOrder"
	shop_refresh_category_picker.fit_to_longest_item = false
	shop_refresh_category_picker.custom_minimum_size.y = 40
	shop_refresh_category_picker.add_item("未选择（有冲突时再选）")
	shop_refresh_category_picker.set_item_metadata(0, "")
	for option in ShopRefreshCategoryOrder.options():
		shop_refresh_category_picker.add_item(option.label)
		shop_refresh_category_picker.set_item_metadata(shop_refresh_category_picker.item_count - 1, option.value)
	shop_refresh_category_picker.tooltip_text = "本地自选沙盒规则，非官方顺序，适用于所有玩家和机器人，并随房间与对局保存。新商店牌和基础商店加成就绪后，仅移动已核实的最右随从增益触发组（战队随从来源）与刷新后机制组（已启用畸变、已获得饰品、已获得任务奖励）；保留各来源及各组内部顺序，不拆分或交替执行。有可观察顺序冲突时再选；空白不自动选择。此项不改变普通随从回合末、返币、奖品、延迟收入、价格或任务规则，也不解除未核实单卡或组合的限制。"
	shop_refresh_category_picker.item_selected.connect(_on_shop_refresh_category_selected)
	column.add_child(shop_refresh_category_picker)
	column.add_child(_label("鲜血宝石弹幕整组顺序 · 本地自选沙盒规则（非官方）", 12, MUTED, true))
	refresh_gem_barrage_picker = OptionButton.new()
	refresh_gem_barrage_picker.name = "RefreshGemBarrage"
	refresh_gem_barrage_picker.fit_to_longest_item = false
	refresh_gem_barrage_picker.custom_minimum_size.y = 40
	refresh_gem_barrage_picker.add_item("未选择（施放宝石弹幕前必选）")
	refresh_gem_barrage_picker.set_item_metadata(0, "")
	for option in RefreshGemBarrage.options():
		refresh_gem_barrage_picker.add_item(option.label)
		refresh_gem_barrage_picker.set_item_metadata(refresh_gem_barrage_picker.item_count - 1, option.value)
	refresh_gem_barrage_picker.tooltip_text = "本地自选沙盒规则，非官方顺序。施放鲜血宝石弹幕前必须选择，适用于全员并随房间保存。将完整永久宝石权益组放在原随从和机制两组之前或之后，保留原组内部及原两组顺序；每次施放一条权益，按施放顺序、酒馆从左至右添加固定+2/+2的宝石附魔账本。不是手牌鲜血宝石，也不调用普通宝石升级加成。未知来源刷新及已有同组门禁不解除。"
	refresh_gem_barrage_picker.item_selected.connect(_on_refresh_gem_barrage_selected)
	column.add_child(refresh_gem_barrage_picker)
	column.add_child(_label("永久随机刷新权益整组顺序 · 本地自选沙盒规则（非官方）", 12, MUTED, true))
	refresh_owner_buff_picker = OptionButton.new()
	refresh_owner_buff_picker.name = "RefreshOwnerBuffs"
	refresh_owner_buff_picker.fit_to_longest_item = false
	refresh_owner_buff_picker.custom_minimum_size.y = 40
	refresh_owner_buff_picker.add_item("未选择（使用永久随机刷新来源前必选）")
	refresh_owner_buff_picker.set_item_metadata(0, "")
	for option in RefreshOwnerBuffs.options():
		refresh_owner_buff_picker.add_item(option.label)
		refresh_owner_buff_picker.set_item_metadata(refresh_owner_buff_picker.item_count - 1, option.value)
	refresh_owner_buff_picker.tooltip_text = "本地自选规则，非官方顺序，适用于全员并随房间保存。将完整永久随机刷新权益组放在所有原刷新组（含宝石弹幕）之前或之后，保留原内部顺序。按实际获得权益的顺序逐条执行；金色每发独立重新随机选当时酒馆随从，不能折叠为单次双倍数值。这里只是普通属性增益，不写鲜血宝石账本。"
	refresh_owner_buff_picker.item_selected.connect(_on_refresh_owner_buff_selected)
	column.add_child(refresh_owner_buff_picker)
	column.add_child(_label("额外商店容量与建设 · 本地自选策略（非官方）",12,MUTED,true))
	refresh_extra_offer_picker=OptionButton.new()
	refresh_extra_offer_picker.name="RefreshExtraOffers"
	refresh_extra_offer_picker.fit_to_longest_item=false
	refresh_extra_offer_picker.custom_minimum_size.y=40
	refresh_extra_offer_picker.add_item("未选择（使用额外商店来源前必选）")
	refresh_extra_offer_picker.set_item_metadata(0,"")
	for option in RefreshOffers.options():
		refresh_extra_offer_picker.add_item(option.label)
		refresh_extra_offer_picker.set_item_metadata(refresh_extra_offer_picker.item_count-1,option.value)
	refresh_extra_offer_picker.tooltip_text="明确本地策略：初始构建和自然补货也提供额外组。保留冻结牌，整组预留容量7；超出先暂停。英雄→战队从左至右→畸变ID→实际饰品→永久奖品权益获得顺序先按当前有效库存加权抽取额外牌，再填普通格，最后追加额外实体。无候选则无牌。真实塑造刷新附加组在被动组后独立抽取，每张减1（最低0），先于现有购买修正。旱地标签按真实本回合首张酒馆法术购买计数，在机制原顺序中减1；普通已购/非酒馆牌不触发。物色新人仅已证永久权益和未来额外随从+2/+2；当前店立即补位未证，仍partial。当前星级畸变与额外法术因存档域未证仍暂停。保留原刷新监听门禁，所有实际新实体参加同一completion。容量未闭合，来源仍partial。"
	refresh_extra_offer_picker.item_selected.connect(_on_refresh_extra_offer_selected)
	column.add_child(refresh_extra_offer_picker)
	column.add_child(_label("攻击增益顺序 · 本地自选规则（非官方）", 12, MUTED, true))
	attack_gain_order_picker = OptionButton.new()
	attack_gain_order_picker.name = "AttackGainOrder"
	attack_gain_order_picker.fit_to_longest_item = false
	attack_gain_order_picker.custom_minimum_size.y = 40
	attack_gain_order_picker.add_item("未选择（有冲突时再选）")
	attack_gain_order_picker.set_item_metadata(0, "")
	for option in AttackGainOrder.options():
		attack_gain_order_picker.add_item(option.label)
		attack_gain_order_picker.set_item_metadata(attack_gain_order_picker.item_count - 1, option.value)
	attack_gain_order_picker.tooltip_text = "本地自选规则（非官方），适用于所有玩家和机器人，并随房间与对局保存。仅调整已核实的友方固定攻击增益与单一自身攻击乘算；存在同侧、种族和受益者匹配的可观察冲突时须明确选择，空白不会自动选择。不改变宣告与目标选择、受攻击、Rally、伤害阶段及各来源内部顺序，不解除未知单卡、光环或军团限制。"
	attack_gain_order_picker.item_selected.connect(_on_attack_gain_order_selected)
	column.add_child(attack_gain_order_picker)
	delayed_income_picker = OptionButton.new()
	delayed_income_picker.name = "DelayedIncomeOrder"
	delayed_income_picker.fit_to_longest_item = false
	delayed_income_picker.custom_minimum_size.y = 40
	for title in ["延迟收入与负债：请选择","延迟收入：随从先，法术后","延迟收入：法术先，随从后"]: delayed_income_picker.add_item(title)
	delayed_income_picker.tooltip_text = "本地自选规则：仅当随从下回合收入与法术负债可能触及0金币下限时需要选择。基础收入后按此顺序处理，适用于所有玩家。"
	delayed_income_picker.item_selected.connect(_on_delayed_income_selected)
	column.add_child(delayed_income_picker)
	minion_price_picker = OptionButton.new()
	minion_price_picker.name = "MinionPriceOrder"
	minion_price_picker.fit_to_longest_item = false
	minion_price_picker.custom_minimum_size.y = 40
	minion_price_picker.add_item("随从价格顺序：未指定")
	for option in MinionPriceOrder.options(): minion_price_picker.add_item(option.label)
	minion_price_picker.tooltip_text = "本地自选规则，适用于所有玩家和机器人。只在亲友折扣与已实现的其它随从价格有可观察差异时要求选择；其它价格优先会保留首购免费，之后恢复折扣后的2枚。未知单卡效果仍不可用。"
	minion_price_picker.item_selected.connect(_on_minion_price_selected)
	column.add_child(minion_price_picker)
	native_prize_summary = _label("", 12, MUTED, true)
	native_prize_summary.name = "NativePrizeRoomSummary"
	column.add_child(native_prize_summary)

func _on_native_prize_toggled(enabled: bool) -> void:
	room.data["native_prizes"] = enabled
	_refresh_room_summary()

func _on_prize_choice_selected(index: int) -> void:
	if index < 0 or index >= NativePrizes.CHOICE_ORDERS.size(): return
	room.data["prize_choice_order"] = NativePrizes.CHOICE_ORDERS[index]
	_refresh_room_summary()

func _on_prize_delivery_selected(index: int) -> void:
	if index < 0 or index >= NativePrizes.DELIVERY_ORDERS.size(): return
	room.data["prize_delivery_order"] = NativePrizes.DELIVERY_ORDERS[index]
	_refresh_room_summary()

func _on_delayed_income_selected(index: int) -> void:
	if index < 0 or index >= DelayedIncomeRoom.ORDERS.size(): return
	room.data[DelayedIncomeRoom.FIELD] = DelayedIncomeRoom.ORDERS[index]
	_refresh_room_summary()

func _on_minion_price_selected(index: int) -> void:
	var choices: Array = ["",MinionPriceOrder.PRIZE_LAST,MinionPriceOrder.OTHER_LAST]
	if index < 0 or index >= choices.size(): return
	room.data[MinionPriceOrder.FIELD] = choices[index]
	_refresh_room_summary()

func _on_coin_order_selected(index: int) -> void:
	if index < 0 or index >= PrizeCoinRoom.ORDERS.size(): return
	room.data["coin_end_turn_order"] = PrizeCoinRoom.ORDERS[index]
	_refresh_room_summary()

func _on_end_turn_category_selected(index: int) -> void:
	if index < 0 or index >= EndTurnCategoryOrder.ORDERS.size(): return
	room.data[EndTurnCategoryOrder.FIELD] = EndTurnCategoryOrder.ORDERS[index]
	_refresh_room_summary()

func _refresh_end_turn_category_picker() -> void:
	if not is_instance_valid(end_turn_category_picker): return
	# A malformed imported value stays malformed for the authoritative validator.
	# Never turn it into the empty state or the first executable order by rendering.
	if not EndTurnCategoryOrder.schema_error(room.data).is_empty():
		end_turn_category_picker.select(-1)
		end_turn_category_picker.text = "回合末整组顺序：配置无效，请重新选择"
		return
	end_turn_category_picker.select(EndTurnCategoryOrder.ORDERS.find(room.data.get(EndTurnCategoryOrder.FIELD, "")))

func _on_shop_refresh_category_selected(index: int) -> void:
	if index < 0 or index >= ShopRefreshCategoryOrder.ORDERS.size(): return
	room.data[ShopRefreshCategoryOrder.FIELD] = ShopRefreshCategoryOrder.ORDERS[index]
	_refresh_room_summary()

func _refresh_shop_refresh_category_picker() -> void:
	if not is_instance_valid(shop_refresh_category_picker): return
	# Preserve malformed loaded values for Room's authoritative rejection.
	# Displaying a missing legacy value must not write a default back to the room.
	if not ShopRefreshCategoryOrder.schema_error(room.data).is_empty():
		shop_refresh_category_picker.select(-1)
		shop_refresh_category_picker.text = "刷新后整组顺序：配置无效，请重新选择"
		return
	shop_refresh_category_picker.select(ShopRefreshCategoryOrder.ORDERS.find(room.data.get(ShopRefreshCategoryOrder.FIELD, "")))

func _on_refresh_gem_barrage_selected(index: int) -> void:
	if index < 0 or index >= RefreshGemBarrage.ORDERS.size(): return
	room.data[RefreshGemBarrage.FIELD] = RefreshGemBarrage.ORDERS[index]
	_refresh_room_summary()

func _refresh_refresh_gem_barrage_picker() -> void:
	if not is_instance_valid(refresh_gem_barrage_picker): return
	# Preserve malformed loaded values for Room's authoritative rejection.
	# Displaying a missing legacy value must not write a default back to the room.
	if not RefreshGemBarrage.schema_error(room.data).is_empty():
		refresh_gem_barrage_picker.select(-1)
		refresh_gem_barrage_picker.text = "宝石弹幕整组顺序：配置无效，请重新选择"
		return
	refresh_gem_barrage_picker.select(RefreshGemBarrage.ORDERS.find(room.data.get(RefreshGemBarrage.FIELD, "")))

func _on_refresh_extra_offer_selected(index: int) -> void:
	if index<0 or index>=RefreshOffers.ORDERS.size(): return
	room.data[RefreshOffers.FIELD]=RefreshOffers.ORDERS[index]
	_refresh_room_summary()

func _refresh_refresh_extra_offer_picker() -> void:
	if not is_instance_valid(refresh_extra_offer_picker): return
	if not RefreshOffers.schema_error(room.data).is_empty():
		refresh_extra_offer_picker.select(-1)
		refresh_extra_offer_picker.text="额外商店策略配置无效，请重新选择"
		return
	refresh_extra_offer_picker.select(RefreshOffers.ORDERS.find(room.data.get(RefreshOffers.FIELD,"")))

func _on_refresh_owner_buff_selected(index: int) -> void:
	if index < 0 or index >= RefreshOwnerBuffs.ORDERS.size(): return
	room.data[RefreshOwnerBuffs.FIELD] = RefreshOwnerBuffs.ORDERS[index]
	_refresh_room_summary()

func _refresh_refresh_owner_buff_picker() -> void:
	if not is_instance_valid(refresh_owner_buff_picker): return
	# Preserve malformed loaded values for Room's authoritative rejection.
	# Displaying a missing legacy value must not write a default back to the room.
	if not RefreshOwnerBuffs.schema_error(room.data).is_empty():
		refresh_owner_buff_picker.select(-1)
		refresh_owner_buff_picker.text = "永久随机刷新权益整组顺序：配置无效，请重新选择"
		return
	refresh_owner_buff_picker.select(RefreshOwnerBuffs.ORDERS.find(room.data.get(RefreshOwnerBuffs.FIELD, "")))

func _on_attack_gain_order_selected(index: int) -> void:
	if index < 0 or index >= AttackGainOrder.ORDERS.size(): return
	room.data[AttackGainOrder.FIELD] = AttackGainOrder.ORDERS[index]
	_refresh_room_summary()

func _refresh_attack_gain_order_picker() -> void:
	if not is_instance_valid(attack_gain_order_picker): return
	# Rendering preserves both missing legacy fields and malformed loaded data.
	if not AttackGainOrder.schema_error(room.data).is_empty():
		attack_gain_order_picker.select(-1)
		attack_gain_order_picker.text = "攻击增益顺序：配置无效，请重新选择"
		return
	attack_gain_order_picker.select(AttackGainOrder.ORDERS.find(room.data.get(AttackGainOrder.FIELD, "")))

func _refresh_native_prize_summary() -> void:
	if not is_instance_valid(native_prize_summary): return
	var enabled: bool = NativePrizes.enabled(room.data)
	native_prize_checkbox.set_pressed_no_signal(bool(room.data.get("native_prizes", false)))
	prize_choice_picker.select(maxi(0, NativePrizes.CHOICE_ORDERS.find(room.data.get("prize_choice_order", ""))))
	prize_delivery_picker.select(maxi(0, NativePrizes.DELIVERY_ORDERS.find(room.data.get("prize_delivery_order", ""))))
	coin_order_picker.select(maxi(0, PrizeCoinRoom.ORDERS.find(room.data.get("coin_end_turn_order", ""))))
	# Custom-shop coins can be used with the native Prize schedule disabled.
	coin_order_picker.disabled = false
	_refresh_end_turn_category_picker()
	_refresh_shop_refresh_category_picker()
	_refresh_refresh_gem_barrage_picker()
	_refresh_refresh_owner_buff_picker()
	_refresh_refresh_extra_offer_picker()
	_refresh_attack_gain_order_picker()
	minion_price_picker.select(maxi(0,["",MinionPriceOrder.PRIZE_LAST,MinionPriceOrder.OTHER_LAST].find(room.data.get(MinionPriceOrder.FIELD,""))))
	delayed_income_picker.select(maxi(0,DelayedIncomeRoom.ORDERS.find(room.data.get(DelayedIncomeRoom.FIELD,""))))
	prize_choice_picker.disabled = not enabled
	prize_delivery_picker.disabled = not enabled
	var counts: Array = [0, 0, 0, 0]
	for id in _pool("prize"):
		var entry: Dictionary = catalog.native_prize_registry.get(id, {})
		var card: Dictionary = catalog.get_card(str(id))
		if not entry.is_empty() and card.get("supported", false) and not card.get("excluded", false) and card.get("kind", "") == entry.get("kind", ""):
			counts[int(entry.prize_tier) - 1] += 1
	var lines: PackedStringArray = ["已选 %d 个奖品；已实现：1级 %d / 2级 %d / 3级 %d / 4级 %d。" % [_pool("prize").size(), counts[0], counts[1], counts[2], counts[3]]]
	if enabled:
		lines.append("每个奖品等级至少保留1个已实现候选；未实现项仍会阻止开局。")
		if NativePrizes.SOURCE in _pool("anomaly"):
			lines.append("正式奖品畸变已启用同一系统；与开关叠加不重复发放。")
		if NativePrizes.hero_enabled(room.data):
			lines.append("英雄池包含提克特斯：仅实际选到他的玩家获得奖品；仍使用此处编辑的奖品池。")
		lines.append("本地混搭顺序由你选择；同源奖品按回合先后补发。")
	else:
		lines.append("当前关闭；可先编辑独立奖品池，不影响普通对局。")
	var errors: Array = NativePrizes.room_errors(room.data, catalog)
	native_prize_summary.text = "\n".join(lines)
	native_prize_summary.tooltip_text = "\n".join(errors) if not errors.is_empty() else "奖品等级来自独立来源标签1735，不是酒馆星级。原卡牌保持法术或随从分类。"
	native_prize_summary.add_theme_color_override("font_color", RED if not errors.is_empty() else MUTED)

func _build_tribe_settings(column: VBoxContainer) -> void:
	column.add_child(_label("大厅种族", 14, MUTED))
	tribe_mode_picker = OptionButton.new()
	tribe_mode_picker.name = "TribeMode"
	tribe_mode_picker.custom_minimum_size.y = 40
	tribe_mode_picker.fit_to_longest_item = false
	for title in ["全开 · 不按种族筛选", "手动选择 · 自由组合", "随机组合 · 本地均匀抽取"]:
		tribe_mode_picker.add_item(title)
	tribe_mode_picker.item_selected.connect(_on_tribe_mode_selected)
	column.add_child(tribe_mode_picker)
	var grid = GridContainer.new()
	grid.columns = 2
	grid.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	grid.add_theme_constant_override("h_separation", 16)
	tribe_checkboxes.clear()
	for tribe in TribeRules.TRIBES:
		var checkbox = CheckBox.new()
		checkbox.name = "Tribe_" + str(tribe)
		checkbox.text = str(TRIBES.get(tribe, tribe))
		checkbox.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		checkbox.toggled.connect(_on_tribe_toggled.bind(str(tribe)))
		grid.add_child(checkbox)
		tribe_checkboxes[tribe] = checkbox
	column.add_child(grid)
	tribe_historical_checkbox = CheckBox.new()
	tribe_historical_checkbox.name = "TribeHistoricalConstraints"
	tribe_historical_checkbox.text = "使用历史大厅约束（可选）"
	tribe_historical_checkbox.tooltip_text = "仅在手动或随机模式生效：按当前历史预设限制可用种族、种族数量及已知必选/互斥规则。取消即可自由组合。卡牌的历史入池条件仍按所选赛季判定。"
	tribe_historical_checkbox.toggled.connect(_on_tribe_historical_toggled)
	column.add_child(tribe_historical_checkbox)
	tribe_rules_label = _label("", 12, MUTED, true)
	tribe_rules_label.name = "TribeRules"
	column.add_child(tribe_rules_label)
	tribe_preview_label = _label("", 12, TEAL, true)
	tribe_preview_label.name = "TribePreview"
	column.add_child(tribe_preview_label)

func _on_tribe_mode_selected(index: int) -> void:
	if index < 0 or index >= TRIBE_MODES.size():
		return
	room.data["tribe_mode"] = TRIBE_MODES[index]
	_refresh_room_summary()

func _on_tribe_toggled(enabled: bool, tribe: String) -> void:
	if str(room.data.get("tribe_mode", "all")) != "manual":
		_refresh_room_summary()
		return
	var selected: Array = room.data.get("selected_tribes", []).duplicate()
	if enabled and tribe not in selected:
		selected.append(tribe)
	elif not enabled:
		selected.erase(tribe)
	selected.sort()
	room.data["selected_tribes"] = selected
	_refresh_room_summary()

func _on_tribe_historical_toggled(enabled: bool) -> void:
	room.data["tribe_historical_constraints"] = enabled
	_refresh_room_summary()

func _tribe_mode_description() -> String:
	match str(room.data.get("tribe_mode", "all")):
		"manual":
			return "手动种族筛选；已选 %d 种。" % room.data.get("selected_tribes", []).size()
		"random":
			return "按种子从合法种族组合中本地均匀抽取；不代表官方权重。"
	return "种族全开，不按种族筛选。"

func _refresh_tribe_preview() -> void:
	lobby_preview = LobbyTribes.preview(room.data, catalog)
	if not is_instance_valid(tribe_preview_label):
		return
	var mode = str(room.data.get("tribe_mode", "all"))
	var historical = bool(room.data.get("tribe_historical_constraints", false))
	var selected: Array = lobby_preview.get("selected_tribes", [])
	tribe_mode_picker.select(TRIBE_MODES.find(mode))
	tribe_historical_checkbox.set_pressed_no_signal(historical)
	tribe_historical_checkbox.disabled = mode == "all"
	for tribe in tribe_checkboxes:
		var checkbox: CheckBox = tribe_checkboxes[tribe]
		checkbox.disabled = mode != "manual"
		checkbox.set_pressed_no_signal(tribe in (room.data.get("selected_tribes", []) if mode == "manual" else (TribeRules.TRIBES if mode == "all" else selected)))
		checkbox.tooltip_text = "点击加入或移除此种族；至少选择1种。" if mode == "manual" else ("全开模式不按种族筛选。" if mode == "all" else "当前种子的随机结果；切换手动模式可编辑。")
	var explanation = "手动可选1–10种；随机从10种中抽5种，各组合等概率。取消历史约束即可自由组合。"
	if mode == "all":
		explanation = "不按种族筛选，保留已选池。切回手动时会恢复之前的勾选。"
	elif historical:
		var built: Dictionary = LobbyTribes.spec(room.data, catalog)
		if bool(built.get("ok", false)):
			var spec: Dictionary = built.get("spec", {})
			explanation = "历史约束：%s种；可用：%s。" % [spec.get("lobby_tribe_count", "?"), LobbyTribes.names_zh(spec.get("available_tribes", []))]
			if not spec.get("required_tribes", []).is_empty():
				explanation += "必选：%s。" % LobbyTribes.names_zh(spec.required_tribes)
			for group in spec.get("lobby_constraints", []):
				explanation += "不能同时选择：%s。" % LobbyTribes.names_zh(group)
		else:
			explanation = "历史大厅约束不可用：" + "；".join(built.get("errors", []))
	if mode == "random":
		explanation += "本地均匀抽取，不代表官方权重。"
	if mode != "all":
		explanation += "卡牌条件仍按所选历史季；跨季新增项使用最终已核实来源。"
	tribe_rules_label.text = explanation
	var displayed_tribes: Array = room.data.get("selected_tribes", []) if mode == "manual" else selected
	var selected_text = "全开（不筛选）" if mode == "all" else (LobbyTribes.names_zh(displayed_tribes) if not displayed_tribes.is_empty() else "未选择")
	var excluded: Array = lobby_preview.get("excluded_ids", [])
	var unknown: Array = lobby_preview.get("unknown_ids", [])
	var lines: PackedStringArray = ["当前种族：" + selected_text, "实际入池：%d 随从 / %d 法术" % [lobby_preview.get("enabled_minions", []).size(), lobby_preview.get("enabled_spells", []).size()], "被筛除 %d 项 · 未知 %d 项" % [excluded.size(), unknown.size()]]
	if mode == "random" and lobby_preview.has("combination_count"):
		lines.append("种子 %s · %s 个合法组合" % [room.data.get("seed", 2026), lobby_preview.combination_count])
	if not seed_valid:
		lines.append("种子输入无效；上方为上一个有效种子的预览，无法开局。")
	if not unknown.is_empty():
		lines.append("未知入池条件会阻止开局，请核实或移除：" + "、".join(unknown.slice(0, 3)) + ("…" if unknown.size() > 3 else ""))
	if not bool(lobby_preview.get("ok", false)):
		lines.append("种族配置未通过校验，以上入池预览尚未生效。")
	tribe_preview_label.text = "\n".join(lines)
	tribe_preview_label.add_theme_color_override("font_color", TEAL if bool(lobby_preview.get("ok", false)) and seed_valid else RED)
	tribe_preview_label.tooltip_text = "种族预览只影响本局实际卡池，不改动右侧原始勾选。\n被筛除：%s\n未知：%s\n%s" % ["、".join(excluded), "、".join(unknown), "；".join(lobby_preview.get("errors", []))]
	if is_instance_valid(room_rules_label):
		room_rules_label.text = "第4回合分发任务，第6/9回合分发饰品。" + _tribe_mode_description() + "英雄可重复；按种子排定首轮循环，淘汰后尽量避开近3轮重复。机制叠加使用 sandbox-1 固定规则，不宣称还原官方动态发放与隐藏匹配。"

func _current_season_note() -> String:
	var id = str(room.data.get("season_id", ""))
	for season in catalog.seasons:
		if str(season.get("id", "")) == id:
			return str(season.get("notes", ""))
	return ""

func _populate_hero_picker() -> void:
	if not is_instance_valid(hero_picker):
		return
	hero_picker.clear()
	hero_items = [""]
	hero_picker.add_item("随机可用英雄")
	var selection = 0
	for id in _pool("hero"):
		var card = catalog.get_card(str(id))
		hero_picker.add_item(str(card.get("name", id)))
		hero_items.append(str(id))
		if str(room.data.get("selected_hero", "")) == str(id):
			selection = hero_items.size() - 1
	hero_picker.select(selection)
	# A hidden legacy selected hero remains in the loaded data for an explicit
	# incompatibility message; merely drawing this picker never migrates it.

func _on_hero_selected(index: int) -> void:
	if index > 0 and index < hero_items.size():
		room.data["selected_hero"] = hero_items[index]
	else:
		room.data.erase("selected_hero")
	_refresh_room_summary()

func _build_pool_editor(body: HBoxContainer) -> void:
	var container = PanelContainer.new()
	container.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	container.add_theme_stylebox_override("panel", _style(SURFACE, BORDER, 12, 18, 18))
	body.add_child(container)
	var column = _column(12)
	container.add_child(column)
	var title_row = _row()
	title_row.add_child(_label("02   卡池与机制", 20, GOLD))
	_spacer(title_row)
	pool_count = _label("", 13, MUTED)
	title_row.add_child(pool_count)
	column.add_child(title_row)
	var tabs = _row(6)
	current_tab_buttons.clear()
	for index in range(KINDS.size()):
		var kind = str(KINDS[index])
		var button = _button(str(KIND_NAMES[index]), func(): _change_pool_kind(kind))
		button.name = "PoolTab_" + kind
		button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		button.add_theme_font_size_override("font_size", 14)
		tabs.add_child(button)
		current_tab_buttons.append(button)
	column.add_child(tabs)
	var filters = _row(10)
	var search = LineEdit.new()
	pool_search_field = search
	search.placeholder_text = "搜索名称、种族或效果…"
	search.text = pool_query
	search.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	search.text_changed.connect(func(value: String): pool_query = value; pool_page = 0; _refresh_pool_list())
	filters.add_child(search)
	var verified = CheckBox.new()
	pool_supported_filter = verified
	verified.text = "仅已实现"
	verified.button_pressed = pool_supported_only
	verified.toggled.connect(func(value: bool): pool_supported_only = value; pool_page = 0; _refresh_pool_list())
	filters.add_child(verified)
	var enabled = CheckBox.new()
	pool_selected_filter = enabled
	enabled.text = "仅已选"
	enabled.button_pressed = pool_selected_only
	enabled.toggled.connect(func(value: bool): pool_selected_only = value; pool_page = 0; _refresh_pool_list())
	filters.add_child(enabled)
	column.add_child(filters)
	var quick = _row(8)
	quick.add_child(_button("恢复本类当前成员", _restore_scope_kind))
	quick.add_child(_button("清空本类", _clear_kind))
	_spacer(quick)
	# No supported-only pruning or historical one-card shortcut in current scope.
	column.add_child(quick)
	pool_help = _label("", 12, MUTED, true)
	pool_help.name = "PoolHelp"
	column.add_child(pool_help)
	var scroller = ScrollContainer.new()
	scroller.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroller.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	column.add_child(scroller)
	pool_list = _column(8)
	pool_list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroller.add_child(pool_list)
	pool_page_bar = _row(8)
	column.add_child(pool_page_bar)
	_refresh_pool_list()

func _change_pool_kind(kind: String) -> void:
	if kind not in KINDS: return
	pool_kind = kind
	pool_page = 0
	_refresh_pool_list()

func _pool(kind: String) -> Array:
	var active: Array = []
	for id in room.data.get(POOL_KEYS.get(kind, ""), []):
		if not room.data.get("disabled_ids", []).has(id) and CurrentScope.allows_pool(kind,str(id),catalog):
			active.append(id)
	return active

func _pool_records(kind: String, supported_only: bool = false) -> Array:
	if kind != "prize": return CurrentScope.records(catalog,kind,supported_only)
	var records: Array = []
	for id in catalog.native_prize_registry:
		var card: Dictionary = catalog.get_card(str(id))
		if card.is_empty() or (supported_only and not card.get("supported", false)): continue
		records.append(card)
	return records

func _refresh_pool_list() -> void:
	if not is_instance_valid(pool_list):
		return
	_clear(pool_list)
	current_checkboxes.clear()
	for index in range(current_tab_buttons.size()):
		var button = current_tab_buttons[index]
		button.add_theme_color_override("font_color", GOLD if KINDS[index] == pool_kind else MUTED)
		button.add_theme_stylebox_override("normal", _style(Color("354238") if KINDS[index] == pool_kind else PANEL, GOLD if KINDS[index] == pool_kind else BORDER, 8, 8, 8))
	var found = 0
	var supported_count = 0
	var conditional_count = 0
	var visible_records: Array = []
	if is_instance_valid(pool_help):
		pool_help.text = "暗月奖品独立池：仅列来源标签1735核实的32个身份，可逐项增删。奖品等级不是酒馆星级；原法术/随从分类不变。未实现项可编辑，启用后会阻止开局。" if pool_kind == "prize" else "勾选 = 加入房间。自定义入店可显式设置 sandbox 星级、基础价格和库存；未实现效果仍会阻止开局。"
		if pool_kind == "trinket": pool_help.text += "\n" + OwnerAuraDisplay.ROOM_HINT
	var records = _pool_records(pool_kind, pool_supported_only)
	# Imported unknown selections must also remain individually removable.
	for selected_id in _pool(pool_kind):
		if pool_kind != "prize" and catalog.get_card(str(selected_id)).is_empty() and not pool_supported_only and not records.any(func(record):return str(record.get("id",""))==str(selected_id)):
			records.append({"id": str(selected_id), "name": "缺少数据的记录", "kind": pool_kind, "supported": false, "pool_supported": false, "text": "缺少来源数据：" + str(selected_id)})
	for card in records:
		var searchable = str(card.get("name", "")) + " " + str(card.get("text", "")) + " " + str(card.get("id", "")) + " " + _tribes(card.get("tribes", []))
		if not pool_query.is_empty() and searchable.findn(pool_query) < 0:
			continue
		var id = str(card.get("id", ""))
		var selected = _pool(pool_kind).has(id)
		if bool(card.get("is_golden", false)) and not selected and not str(card.get("id","")) in CurrentScope.main_ids(pool_kind):
			continue
		if pool_selected_only and not selected:
			continue
		found += 1
		if bool(card.get("supported", false)):
			supported_count += 1
			if card.has("conditional_support"): conditional_count += 1
		visible_records.append(card)
	visible_records.sort_custom(func(a: Dictionary, b: Dictionary) -> bool:
		if bool(a.get("supported", false)) != bool(b.get("supported", false)):
			return bool(a.get("supported", false))
		var at = int(catalog.native_prize_registry.get(str(a.get("id", "")), {}).get("prize_tier", 0)) if pool_kind == "prize" else int(a.get("tier", 0) if a.get("tier") != null else 0)
		var bt = int(catalog.native_prize_registry.get(str(b.get("id", "")), {}).get("prize_tier", 0)) if pool_kind == "prize" else int(b.get("tier", 0) if b.get("tier") != null else 0)
		return at < bt if at != bt else str(a.get("name", "")) < str(b.get("name", "")))
	var page_count = maxi(1, ceili(float(visible_records.size()) / POOL_PAGE_SIZE))
	pool_page = clampi(pool_page, 0, page_count - 1)
	for card in visible_records.slice(pool_page * POOL_PAGE_SIZE, (pool_page + 1) * POOL_PAGE_SIZE):
		_add_pool_card(card, _pool(pool_kind).has(str(card.id)))
	_clear(pool_page_bar)
	var previous = _button("← 上一页", func(): pool_page -= 1; _refresh_pool_list())
	previous.disabled = pool_page == 0
	pool_page_bar.add_child(previous)
	pool_page_bar.add_child(_label("第 %s / %s 页 · 每页 %s 项" % [pool_page + 1, page_count, POOL_PAGE_SIZE], 12, MUTED))
	var next = _button("下一页 →", func(): pool_page += 1; _refresh_pool_list())
	next.disabled = pool_page >= page_count - 1
	pool_page_bar.add_child(next)
	_spacer(pool_page_bar)
	pool_count.text = "%d 项 / %d 已实现（%d 条件支持）· 已选 %d" % [found, supported_count, conditional_count, _pool(pool_kind).size()]
	if found == 0:
		var empty = _panel(pool_list, Color("142023"))
		empty.add_child(_label("没有匹配的条目", 19, MUTED))
		empty.add_child(_label("试试清除搜索，或切换筛选条件。", 14, MUTED))

func _add_pool_card(card: Dictionary, selected: bool) -> void:
	var id = str(card.get("id", ""))
	var supported = bool(card.get("supported", false))
	var pool_allowed = _pool_allowed(card)
	var frame = PanelContainer.new()
	frame.add_theme_stylebox_override("panel", _style(Color("21302e") if selected else Color("162124"), Color("466456") if selected else Color("2c3b3e"), 9, 12, 10))
	pool_list.add_child(frame)
	var row = _row(12)
	frame.add_child(row)
	var check = CheckBox.new()
	check.button_pressed = selected
	check.disabled = not pool_allowed and not selected
	check.tooltip_text = "取消该条目的选择；恢复普通入池规则后，不可入池项仍可单独移除。" if selected and not pool_allowed else ("普通规则不可入池；可查看“自定义入店”的支持条件。" if not pool_allowed else ("加入房间卡池" if supported else "尚未实现：可加入配置，但无法通过开局验证"))
	check.toggled.connect(func(value: bool): _toggle_card(id, value))
	row.add_child(check)
	current_checkboxes[id] = check
	var custom_entry = {} if pool_kind == "prize" else _custom_shop_entry(id)
	var tier_text = "自定★%s" % custom_entry.tier if not custom_entry.is_empty() else "来源★%s" % _source_number(card.get("tier"))
	if pool_kind == "prize": tier_text = "奖品等级 %s" % catalog.native_prize_registry.get(id, {}).get("prize_tier", "?")
	var tier = _label(tier_text if pool_kind in ["minion", "spell", "prize"] else _kind_name(pool_kind), 13, GOLD)
	tier.custom_minimum_size.x = 54
	row.add_child(tier)
	var text_column = _column(3)
	text_column.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var heading = _row(10)
	heading.add_child(_label(str(card.get("name", id)), 17, TEXT))
	if pool_kind == "minion":
		heading.add_child(_label("%s / %s" % [card.get("attack", 0), card.get("health", 1)], 14, TEAL))
	var tribes = _tribes(card.get("tribes", []))
	if not tribes.is_empty():
		heading.add_child(_label(tribes, 12, MUTED))
	_spacer(heading)
	if not custom_entry.is_empty():
		heading.add_child(_pill("sandbox 自定义", GOLD))
	# Conditional support is independent of ordinary/custom shop eligibility.
	if id == "129427":
		heading.add_child(_pill("原始参考 · 不执行", MUTED))
	elif card.has("conditional_support") and supported:
		heading.add_child(_pill("条件支持", RED))
	elif custom_entry.is_empty():
		heading.add_child(_pill("衍生/不可入池" if not pool_allowed else ("已实现" if supported else "待实现"), MUTED if not pool_allowed else (TEAL if supported else RED)))
	if pool_kind in ["minion", "spell"]:
		var custom_button = _button("自定义入店", func(): _show_custom_shop_editor(id))
		custom_button.custom_minimum_size.y = 30
		custom_button.add_theme_font_size_override("font_size", 12)
		heading.add_child(custom_button)
	var details = _button("详情", func(): _show_card_details(card))
	details.custom_minimum_size.y = 30
	details.add_theme_font_size_override("font_size", 12)
	heading.add_child(details)
	text_column.add_child(heading)
	if not custom_entry.is_empty():
		text_column.add_child(_label(_custom_shop_summary(id), 12, GOLD, true))
	elif room.data.get("shop_overrides", {}).has(id):
		text_column.add_child(_label("sandbox 参数无效：请编辑或移除自定义入店配置。", 12, RED, true))
	if pool_kind == "prize":
		text_column.add_child(_label("原卡牌分类：%s · 来源标签1735 · %s" % [_kind_name(str(card.get("kind", ""))), id], 12, MUTED, true))
	if pool_kind == "spell" or not custom_entry.is_empty():
		text_column.add_child(_label("来源分类：" + str(card.get("category", _kind_name(pool_kind))), 12, MUTED, true))
	text_column.add_child(_label(str(card.get("text", "暂无效果说明")), 13, MUTED, true))
	if supported and OwnerAuraDisplay.is_source(id):
		var aura_hint = _label(OwnerAuraDisplay.CARD_HINT, 12, GOLD, true)
		aura_hint.name = "OwnerAuraRoomHint"
		text_column.add_child(aura_hint)
	row.add_child(text_column)
	frame.tooltip_text = "%s\nID: %s\n%s\n%s" % [card.get("name", id), id, card.get("text", ""), "衍生/不可入池；可在详情中查看效果与来源" if not pool_allowed else (_conditional_support_reason(card) if card.has("conditional_support") and supported else ("已实现并启用严格效果校验" if supported else "尚未实现，启用会阻止开局"))]

func _conditional_support_reason(card: Dictionary) -> String:
	var support: Variant = card.get("conditional_support", "")
	if support is Dictionary:
		return str(support.get("reason", ""))
	return str(support)

func _kind_name(kind: String) -> String:
	var index = KINDS.find(kind)
	return str(KIND_NAMES[index]) if index >= 0 else kind

func _tribes(tribes: Array) -> String:
	var names: PackedStringArray = []
	for tribe in tribes:
		names.append(str(TRIBES.get(str(tribe).to_lower(), tribe)))
	return " / ".join(names)

func _toggle_card(id: String, enabled: bool) -> void:
	if not CurrentScope.allows_pool(pool_kind,id,catalog):
		_notify("范围外条目已暂停；原代码与资料保留。",true)
		return
	if enabled and not _pool_allowed(catalog.get_card(id)):
		if current_checkboxes.has(id):
			current_checkboxes[id].set_pressed_no_signal(false)
		_notify("该条目不满足普通入池规则。请在“自定义入店”中显式配置；效果、数值、单打及金色支持检查仍有效。", true)
		return
	var key = str(POOL_KEYS[pool_kind])
	var values: Array = room.data.get(key, []).duplicate()
	if enabled and not values.has(id):
		values.append(id)
	elif not enabled:
		values.erase(id)
	room.data[key] = values
	var disabled: Array = room.data.get("disabled_ids", []).duplicate()
	if enabled:
		disabled.erase(id)
	elif pool_kind != "prize" and not disabled.has(id):
		disabled.append(id)
	room.data["disabled_ids"] = disabled
	_refresh_room_summary()
	pool_count.text = pool_count.text.get_slice(" · 已选 ", 0) + " · 已选 %d" % _pool(pool_kind).size()
	if pool_kind == "hero":
		_populate_hero_picker()
	# Preserve focus and scroll position for quick consecutive selection.
	if current_checkboxes.has(id):
		current_checkboxes[id].disabled = not enabled and not _pool_allowed(catalog.get_card(id))
		var frame = current_checkboxes[id].get_parent().get_parent()
		frame.add_theme_stylebox_override("panel", _style(Color("21302e") if enabled else Color("162124"), Color("466456") if enabled else Color("2c3b3e"), 9, 12, 10))
	if pool_selected_only and not enabled:
		_refresh_pool_list()

func _enable_kind_supported() -> void:
	var values: Array = room.data.get(POOL_KEYS[pool_kind], []).duplicate()
	var disabled: Array = room.data.get("disabled_ids", []).duplicate()
	for card in _pool_records(pool_kind, true):
		var id = str(card.get("id", ""))
		if bool(card.get("is_golden", false)) or not _pool_allowed(card):
			continue
		if not values.has(id):
			values.append(id)
		disabled.erase(id)
	room.data[POOL_KEYS[pool_kind]] = values
	room.data["disabled_ids"] = disabled
	_refresh_pool_list()
	_refresh_room_summary()
	_populate_hero_picker()
	_notify("已加入本类全部已实现且可入池条目。已有待实现勾选仍会显示验证错误。")

func _clear_kind() -> void:
	room.data[POOL_KEYS[pool_kind]] = []
	_refresh_pool_list()
	_refresh_room_summary()
	_populate_hero_picker()
	_notify("已清空%s卡池。" % _kind_name(pool_kind))

func _remove_unsupported() -> void:
	var removed = 0
	for kind in KINDS:
		var values: Array = []
		for id in _pool(str(kind)):
			var card = catalog.get_card(str(id))
			if bool(card.get("supported", false)) and not bool(card.get("is_golden", false)) and _pool_allowed(card, str(kind)):
				values.append(id)
			else:
				removed += 1
		room.data[POOL_KEYS[kind]] = values
	_refresh_pool_list()
	_refresh_room_summary()
	_populate_hero_picker()
	_notify("已移除 %d 个待实现或不可直接入池条目，保留现有已实现选择。" % removed)

func _add_leeroy() -> void:
	var matches: Array = []
	for card in catalog.list_cards("minion", "", false):
		var name_value = str(card.get("name", "")).to_lower()
		var id = str(card.get("id", ""))
		if ("火车王" in name_value or "leeroy" in name_value or "leeroy" in id.to_lower()) and not bool(card.get("is_golden", false)):
			matches.append(card)
	if matches.is_empty():
		_notify("数据中尚未找到火车王。可通过随从搜索检查当前目录。", true)
		return
	var card: Dictionary = matches.back()
	var values: Array = _pool("minion").duplicate()
	if not values.has(str(card.id)):
		values.append(str(card.id))
	room.data[POOL_KEYS.minion] = values
	var disabled: Array = room.data.get("disabled_ids", []).duplicate()
	disabled.erase(str(card.id))
	room.data["disabled_ids"] = disabled
	pool_kind = "minion"
	_refresh_pool_list()
	_refresh_room_summary()
	_notify("已将「%s」加入当前随从池。%s" % [card.get("name", "火车王"), "保留历史预设中的其他选择。" if bool(card.get("supported", false)) else "该记录尚未通过效果或数值验证，当前配置会阻止开局。"], not bool(card.get("supported", false)))

func _on_season_selected(index: int) -> void:
	_notify("历史赛季预设已暂停，当前成员清单不会被替换。",true)

func _archived_on_season_selected(index: int) -> void:
	if index == 0:
		room.data["season_id"] = ""
	else:
		room.apply_season(str(season_items[index]), catalog)
	pool_page = 0
	_build_room()
	_notify("已应用赛季成员预设。请查看考据状态与验证提示；数值仍使用当前数据。")

func _refresh_room_summary() -> void:
	if not is_instance_valid(room_summary):
		return
	_refresh_tribe_preview()
	_refresh_native_buddy_summary()
	if is_instance_valid(beetle_settings): beetle_settings.refresh()
	if is_instance_valid(damage_settings): damage_settings.refresh()
	if is_instance_valid(outback_settings): outback_settings.refresh()
	_refresh_native_prize_summary()
	var count = 0
	for kind in KINDS:
		count += _pool(str(kind)).size()
	room_summary.text = "%d 人酒馆 · 种子 %s\n%d 个已选条目 · %d 随从 / %d 法术" % [int(room.data.get("bot_count", 7)) + 1, room.data.get("seed", 2026), count, _pool("minion").size(), _pool("spell").size()]
	var errors: Array = room.validate(catalog)
	if not seed_valid:
		errors.append("随机种子必须是整数。")
	start_button.disabled = not errors.is_empty()
	room_validation.tooltip_text = "\n".join(errors)
	if errors.is_empty():
		room_validation.text = "✓ 配置通过，可开始已实现规则对局"
		room_validation.add_theme_color_override("font_color", TEAL)
	else:
		var lines: PackedStringArray = []
		for index in range(mini(errors.size(), 4)):
			lines.append("• " + str(errors[index]))
		if errors.size() > 4:
			var hint = "请查看种族预览；可回全开或主动移除未知项。" if not bool(lobby_preview.get("ok", true)) else "可使用“仅保留已实现”。"
			lines.append("另有 %d 项问题。%s" % [errors.size() - 4, hint])
		room_validation.text = "\n".join(lines)
		room_validation.add_theme_color_override("font_color", RED)

func _reset_room() -> void:
	seed_valid = true
	room.reset(catalog)
	_build_room()
	_notify("已新建当前范围房间；包含待实现成员，不会自动缩减为已实现子集。")

func _save_room() -> void:
	DirAccess.make_dir_recursive_absolute("user://rooms")
	var result = room.save_to(ROOM_PATH)
	_notify("房间已保存到本地 rooms/default.json。" if result == OK else "保存房间失败：%s" % error_string(result), result != OK)

func _load_room() -> void:
	# Import into an isolated draft. Even a readable old-scope room must not
	# replace the current editor, its invalid seed text or its selected pools.
	var candidate = RoomScript.new()
	var result = candidate.load_from(ROOM_PATH)
	if result != OK:
		var advice: String = "请先保存房间配置。" if result == ERR_FILE_NOT_FOUND else "请保留原文件，或显式新建当前范围房间。"
		_notify("载入房间失败：%s。当前编辑内容未改变。%s" % [error_string(result), advice], true)
		return
	var scope_errors: Array = CurrentScope.room_errors(candidate.data, catalog)
	if not scope_errors.is_empty():
		_notify("房间不属于当前范围，未替换当前编辑内容或改写原文件：" + "；".join(scope_errors), true)
		return
	# A current-scope draft may still contain held members. Keep it editable;
	# ordinary start admission, not import, decides whether it can be played.
	room = candidate
	seed_valid = true
	_build_room()
	_notify("已读取当前范围房间配置。待实现或规则留空成员仍保留；开局使用原有规则检查。")

func _start_game() -> void:
	var errors: Array = room.validate(catalog)
	if not seed_valid or not errors.is_empty():
		_refresh_room_summary()
		_notify("当前配置未通过验证，无法开始对局。", true)
		return
	var candidate = GameScript.new()
	var result = candidate.start(room.data.duplicate(true), catalog)
	if not bool(result.get("ok", false)):
		var preserved: String = " 当前房间与原对局未被替换，可继续原对局。" if not game.state.is_empty() else " 当前房间编辑内容未改变。"
		_notify(str(result.get("error", "无法开始对局")) + preserved, true)
		return
	_commit_game_session(candidate)
	message = "酒馆已开门。点击商店卡牌购买，再选择手牌打出。"
	message_is_error = false
	_build_game(false)

func _player() -> Dictionary:
	for player in game.state.get("players", []):
		if int(player.get("id", -1)) == 0:
			return player
	return {}

func _build_game(preserve_scroll: bool = true) -> void:
	_capture_game_scroll()
	scroll_build_revision += 1
	var revision = scroll_build_revision
	var current_round = int(game.state.get("round", -1))
	if not preserve_scroll:
		saved_recruit_scroll = 0
		saved_opponents_scroll = 0
	elif rendered_round != current_round:
		# New rounds may offer discoveries above the shop; keep those in view.
		saved_recruit_scroll = 0
	screen = "game"
	recruit_scroll = null
	opponents_scroll = null
	_clear(page)
	var player = _player()
	if player.is_empty():
		_build_room()
		_notify("未找到可用对局。", true)
		return
	var header = _header("单机对局 / 第 %s 回合 · %s" % [game.state.get("round", 1), _phase_name()])
	header.add_child(_pill("SEED %s" % game.state.get("seed", room.data.get("seed", 2026)), MUTED))
	header.add_child(_button("保存对局", _save_game))
	header.add_child(_button("载入对局", _load_game))
	header.add_child(_button("返回房间", _build_room))
	var body = _row(16)
	body.size_flags_vertical = Control.SIZE_EXPAND_FILL
	page.add_child(body)
	_build_opponents(body, player)
	_build_play_area(body, player)
	_build_log_area(body)
	_notice_bar()
	rendered_round = current_round
	restoring_game_scroll = true
	_restore_game_scroll.call_deferred(revision)

func _capture_game_scroll() -> void:
	# A newer rebuild must not capture the temporary zero of an unrestored view.
	if screen != "game" or restoring_game_scroll:
		return
	if is_instance_valid(recruit_scroll) and recruit_scroll.is_inside_tree():
		saved_recruit_scroll = recruit_scroll.scroll_vertical
	if is_instance_valid(opponents_scroll) and opponents_scroll.is_inside_tree():
		saved_opponents_scroll = opponents_scroll.scroll_vertical

func _restore_game_scroll(revision: int) -> void:
	# Bound one-shot callbacks are disconnected if this UI is freed mid-layout.
	if revision != scroll_build_revision or screen != "game" or not is_inside_tree():
		return
	get_tree().process_frame.connect(_restore_game_scroll_after_layout.bind(revision), CONNECT_ONE_SHOT)

func _restore_game_scroll_after_layout(revision: int) -> void:
	# Nested containers need a second layout pass before scroll limits are final.
	if revision != scroll_build_revision or screen != "game" or not is_inside_tree():
		return
	get_tree().process_frame.connect(_apply_game_scroll.bind(revision), CONNECT_ONE_SHOT)

func _apply_game_scroll(revision: int) -> void:
	if revision != scroll_build_revision or screen != "game":
		return
	if is_instance_valid(recruit_scroll):
		recruit_scroll.scroll_vertical = saved_recruit_scroll
	if is_instance_valid(opponents_scroll):
		opponents_scroll.scroll_vertical = saved_opponents_scroll
	restoring_game_scroll = false

func _phase_name() -> String:
	var phase = str(game.state.get("phase", "recruit"))
	return {"recruit": "招募阶段", "combat": "战斗阶段", "finished": "对局结束", "game_over": "对局结束", "ended": "对局结束", "spectate": "观战阶段", "error": "校验失败，已停止"}.get(phase, phase)

func _hero_display_card(player: Dictionary) -> Dictionary:
	return game.HeroPowerIdentity.display(player,_hero_power_display_card(player),catalog)

func _hero_power_display_card(player: Dictionary) -> Dictionary:
	var card: Dictionary = catalog.get_card(str(player.get("hero_id","")))
	if player.get("hero_id") in game.HeroTrinkets.Sources.IDS: return game.HeroTrinkets.display(player,card)
	if player.get("hero_id")==game.CookiePot.Sources.HERO: return game.CookiePot.display(player,card)
	if player.get("hero_id")==game.Faelin.Sources.HERO: return game.Faelin.display(player,card)
	if player.get("hero_id")==game.Artanis.Sources.HERO: return game.Artanis.display(player,card)
	if player.get("hero_id")==game.Thorim.Sources.HERO: return game.Thorim.display(player,card)
	if player.get("hero_id")==game.AfkStart.Sources.HERO: return game.AfkStart.display(player,card)
	if player.get("hero_id")==game.Galewing.Sources.HERO: return game.Galewing.display(player,card)
	if player.get("hero_id")==game.Wagtoggle.HERO: return game.Wagtoggle.display(player,card)
	if player.get("hero_id")==game.Kerrigan.Sources.HERO: return game.Kerrigan.display(player,card)
	if player.get("hero_id")==game.Cariel.HERO: return game.Cariel.display(player,card)
	if player.get("hero_id")==game.Cthun.HERO: return game.Cthun.display(player,card,int(game.state.round))
	if player.get("hero_id")==game.Azshara.Sources.HERO: return game.Azshara.display(player,card)
	if player.get("hero_id")==game.RatKing.Sources.HERO: return game.RatKing.display(player,card)
	if player.get("hero_id","") != AttackUnlock.HERO: return card
	var saved: Variant = player.get(AttackUnlock.STATE_KEY)
	if not saved is Dictionary: return card
	var progress: Dictionary = AttackUnlock.presentation(saved,player.get("id"),saved.get("round"))
	if not progress.ok: return card
	var shown: Dictionary = catalog.get_card(progress.hero_id).duplicate(true)
	if shown.is_empty(): return card
	if progress.remaining_attacks > 0:
		shown.text = "恶魔猎手训练：还需 %s 次友方随从攻击，解锁后每回合首购随从免费。" % progress.remaining_attacks
	else:
		shown.text = "幽灵视觉：每回合你购买的第一个随从免费。"
	return shown

func _build_opponents(body: HBoxContainer, player: Dictionary) -> void:
	var outer = _column(12)
	outer.custom_minimum_size.x = 190
	body.add_child(outer)
	var hero_card = _hero_display_card(player)
	var hero_box = _panel(outer, Color("263832"), Color("5a6950"))
	hero_box.add_child(_label("你的英雄", 12, GOLD))
	hero_box.add_child(_label(str(hero_card.get("name", "酒馆旅人")), 21, TEXT, true))
	hero_box.add_child(_label("生命 %s   护甲 %s" % [player.get("health", 0), player.get("armor", 0)], 16, TEAL))
	hero_box.add_child(_label(str(hero_card.get("text", "")), 12, MUTED, true))
	var growth: Dictionary = game.hero_progress(player)
	if growth.get("ok",false): hero_box.add_child(_label("当前技能 +%s/+%s · 再购买 %s 张牌提升" % [growth.amount,growth.amount,growth.left],12,TEAL,true))
	var uses_left: int = maxi(0,game.hero_power_use_limit(player)-int(player.get("hero_uses",0)))
	var power_quote: Dictionary = game.hero_power_quote(player)
	var power = _button("英雄技能 · %s  (%s次)" % [str(power_quote.cost) if power_quote.ok else "不可用",uses_left], func(): _activate_hero_power())
	power.tooltip_text = "先点击商店卡牌下方的技能目标按钮。" if _hero_targets_shop() else "有目标技能使用当前选中的己方或商店随从；目标合法性由规则引擎校验。"
	power.disabled = not power_quote.ok or not _can_recruit() or game.HeroExtraUses.exhausted(game,player) or uses_left <= 0 or not _hero_has_active_power() or int(player.get("gold",0)) < game.hero_power_cost(player)
	if player.get("hero_id","") == AttackUnlock.HERO:
		power.text = "被动技能 · 自动累计攻击"
		power.tooltip_text = "进度只由实际友方攻击推进，无需点击；解锁后真实首购随从自动免费。"
	if player.get("hero_id","") == "BG28_HERO_400":
		var cooldown: Dictionary = game.hero_cooldown_status(player)
		if cooldown.get("ok",false):
			power.text = "英雄技能 · 1金币" if cooldown.cooldown_ready else "好运当投 · 冷却%s回合" % cooldown.remaining_rounds
			power.tooltip_text = "成功投掷后获得1–6金币；第%s回合可再次使用。" % cooldown.ready_round
	if player.get("hero_id","") in ["BG31_HERO_003","BG23_HERO_305"]:
		var unavailable: String = game.hero_power_unavailable_reason(player)
		power.disabled = power.disabled or not power_quote.ok or not unavailable.is_empty()
		power.tooltip_text = unavailable if not unavailable.is_empty() else "无需选择目标；按显示费用使用当前技能。"
		if not power_quote.ok: power.tooltip_text = str(power_quote.error)
	if player.get("hero_id","")=="BG20_HERO_201":
		var voljin_menu=MenuButton.new()
		voljin_menu.text="灵魂互换 · 选择两名随从"
		voljin_menu.name="VoljinAttackTargets"
		var voljin_popup=voljin_menu.get_popup()
		var voljin_commands: Array=game.VoljinAttack.legal_commands(game,player)
		for voljin_index in range(voljin_commands.size()):
			var voljin_labels: Array[String]=[]
			for voljin_selection in voljin_commands[voljin_index].hero_targets:
				var voljin_unit: Dictionary=player[voljin_selection.zone][int(voljin_selection.index)]
				voljin_labels.append(("战队" if voljin_selection.zone=="board" else "酒馆")+str(int(voljin_selection.index)+1)+" "+str(voljin_unit.get("name","随从"))+"（攻击"+str(voljin_unit.attack)+"）")
			voljin_popup.add_item(" → ".join(voljin_labels),voljin_index)
		voljin_menu.disabled=power.disabled or voljin_commands.is_empty()
		voljin_popup.id_pressed.connect(func(item_id: int): _do_command(voljin_commands[item_id].duplicate(true)))
		hero_box.add_child(voljin_menu)
		power.disabled=true
		power.tooltip_text="使用上方菜单选择两个不同随从；双方各获得对方使用前的攻击力，持续至下回合。"
	if player.get("hero_id","")=="TB_BaconShop_HERO_45":
		power.disabled=power.disabled or not game.Rafaam.power_error(game,player).is_empty()
		power.tooltip_text="下一场战斗：获取你击杀的第一个随从的原始版复制。已经准备后不能重复叠加本实现范围。"
	if player.get("hero_id","")=="TB_BaconShop_HERO_92":
		power.disabled=power.disabled or not game.Yshaarj.power_error(game,player).is_empty()
		power.tooltip_text="下一场战斗开始：召唤并获取一个你当前等级的随从；满场、等级7及重复叠加仍有实现边界。"
	if player.get("hero_id","")=="TB_BaconShop_HERO_37":
		var portal: Dictionary=player.get(game.Jaraxxus.Sources.STATE,{})
		power.disabled=true
		power.text="虚空之门 · 回合开始获取2恶魔" if int(portal.get("damage",0))==150 else "血怒 · %s/150真实伤害" % portal.get("damage","?")
		power.tooltip_text="友方随从实际造成150伤害后解锁。进度跨战斗保留；过量伤害与未认证招募来源仍有实现边界。"
	if player.get("hero_id","")=="BG23_HERO_201":
		var tentacle_history: Dictionary=player.get(game.Ozumat.Sources.STATE,{})
		power.disabled=true
		power.text="触须 · %s/%s 嘲讽" % [2+int(tentacle_history.get("sold",0)),2+int(tentacle_history.get("sold",0))]
		power.tooltip_text="实际出售随从永久提升触须1/1。每场战斗有空位时召唤一次；满场保留等待，调度先后仍按本地规则。"
	if player.get("hero_id","") in game.TurnSevenCopy.Sources.IDS:
		var turn_seven_history: Dictionary=player.get(game.TurnSevenCopy.Sources.STATE,{})
		var turn_seven_axis: String="攻击力" if player.hero_id=="BG22_HERO_002" else "当前生命值"
		power.disabled=true
		power.text="第7回合复制 · 历史不可用" if turn_seven_history.is_empty() else ("战斗中复制最高"+turn_seven_axis if int(turn_seven_history.turn)>=7 else "复制解锁还需 %s 回合"%[7-int(turn_seven_history.turn)])
		power.tooltip_text="按真实己方回合开始解锁；每战一次，满场保留等待。空位出现时选当前最高实体，保留已证附魔及受伤；并列与调度采用明确本地规则。"
	if player.get("hero_id","")=="BG20_HERO_282":
		power.disabled=true
		power.text="开战 · 最低攻击随从获得亡语"
		power.tooltip_text="使最低攻击力随从获得亡语：其他友方获得其属性值。没有主动消灭；死亡/活体整组触发读取真实属性，并列与组顺序采用本地规则。"
	if player.get("hero_id","")=="BG22_HERO_305":
		var broodmother_history: Dictionary=player.get(game.Onyxia.Sources.STATE,{})
		power.disabled=true
		power.text="巢母 · 复仇4 · %s/%s雏龙" % [1+int(broodmother_history.get("growth",0)),1+int(broodmother_history.get("growth",0))]
		power.tooltip_text="实际友方死亡累计4次，召唤雏龙并立即发起一次攻击，此效果提升1/1。满场与嵌套时序仍有实现边界。"
	hero_box.add_child(power)
	if game.EmergencyLanding.Sources.enabled(game.room):
		var emergency_uses: int = 2 - int(player.get(game.EmergencyLanding.Sources.STATE, {}).get("used", 0))
		var emergency_button = _button("紧急着陆 · 移出个人池（剩余%d次）" % emergency_uses, func(): _do_command({"type": "anomaly_remove_pool", "index": selected_shop}))
		emergency_button.disabled = not _can_recruit() or not game.EmergencyLanding.target_error(game, player, selected_shop).is_empty()
		emergency_button.tooltip_text = "先选商店随从。已写未验证：仅影响你的后续商店与普通发现候选；当前商店、手牌和战队实体不移除。"
		hero_box.add_child(emergency_button)
	var repeat_entries: Dictionary = player.get("turn_repeat_spell_state",{}).get("entries",{})
	for family in repeat_entries:
		hero_box.add_child(_label("本回合倍率：%s ×2（与同类倍率按规则合并）" % {"battlecry":"战吼","deathrattle":"亡语","end_of_turn":"回合结束"}.get(family,family),12,TEAL,true))
	if not player.get("trinkets", []).is_empty():
		hero_box.add_child(_label("饰品：%s" % _short_value(player.get("trinkets", [])), 12, GOLD, true))
	for sale_quest_line in NativeOwnerProgress.aristocrat_lines(player,catalog):
		hero_box.add_child(_label(str(sale_quest_line),12,GOLD,true))
	var hero_quest_state: Dictionary=player.get("native_denathrius_initial_quest",{})
	var hero_quest: Dictionary=hero_quest_state.get("quest",{})
	if not hero_quest.is_empty():
		hero_box.add_child(_label("英雄任务：%s" % hero_quest.get("name","进行中"),12,GOLD,true))
		hero_box.add_child(_label("进度 %s / %s%s" % [hero_quest_state.get("progress",0),hero_quest.get("requirement",0)," · 已完成" if hero_quest.get("complete",false) else ""],12,MUTED,true))
	if not player.get("active_quest", {}).is_empty():
		var quest: Dictionary = player.get("active_quest", {})
		hero_box.add_child(_label("任务：%s" % quest.get("name", "进行中"), 12, GOLD, true))
		hero_box.add_child(_label("进度 %s / %s%s" % [player.get("quest_progress", {}).get(str(quest.get("id", "")), 0), quest.get("requirement", game.room.get("quest_requirement", 6)), " · 已完成" if bool(quest.get("complete", false)) else ""], 12, MUTED, true))
	if not player.get("reward_active", []).is_empty():
		hero_box.add_child(_label("任务奖励已激活：%s" % _short_value(player.get("reward_active", [])), 12, TEAL, true))
	var lobby_pool: Dictionary = game.state.get("lobby_pool", {})
	var tribe_text = "本局种族：全开（不筛选）"
	if str(lobby_pool.get("mode", game.room.get("tribe_mode", "all"))) != "all":
		tribe_text = "本局种族：" + LobbyTribes.names_zh(lobby_pool.get("selected_tribes", []))
	var game_tribes = _label(tribe_text, 12, TEAL, true)
	game_tribes.name = "GameTribeSummary"
	hero_box.add_child(game_tribes)
	outer.add_child(_label("酒馆席位", 15, MUTED))
	var scroll = ScrollContainer.new()
	opponents_scroll = scroll
	scroll.name = "OpponentsScroll"
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	outer.add_child(scroll)
	var list_column = _column(7)
	list_column.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.add_child(list_column)
	for opponent in game.state.get("players", []):
		var alive = bool(opponent.get("alive", true))
		var panel = _panel(list_column, Color("20332f") if int(opponent.get("id", -1)) == 0 else SURFACE, Color("486454") if int(opponent.get("id", -1)) == 0 else BORDER)
		var opponent_hero = _hero_display_card(opponent)
		panel.add_child(_label("%s  %s" % ["你" if int(opponent.get("id", -1)) == 0 else str(opponent.get("name", "对手")), "" if alive else "已淘汰"], 14, TEXT if alive else MUTED, true))
		panel.add_child(_label(str(opponent_hero.get("name", "未知英雄")), 12, MUTED, true))
		panel.add_child(_label("♥ %s  ◇ %s  ★ %s" % [opponent.get("health", 0), opponent.get("armor", 0), opponent.get("tier", 1)], 13, TEAL if alive else MUTED))

func _build_economy_status(content: VBoxContainer, player: Dictionary) -> void:
	# Read-only owner state. These values are additional bonuses, not card price
	# replacements or promises that unrelated spell programs have been admitted.
	var lines: Array[String] = []
	if player.get("hero_id","") == AttackUnlock.HERO:
		var progress: Dictionary = AttackUnlock.presentation(player.get(AttackUnlock.STATE_KEY),player.id,player.get(AttackUnlock.STATE_KEY,{}).get("round",game.state.round))
		if progress.ok:
			lines.append("%s：%s" % [progress.hero_power_name,("本回合首购随从免费" if progress.first_minion_free else "本回合首购已用，下回合恢复") if progress.remaining_attacks == 0 else "还需 %s 次友方随从攻击" % progress.remaining_attacks])
	if player.has(TavernAmplifier.STATE_KEY):
		var bonus: Dictionary = TavernAmplifier.totals(player)
		if bonus.ok:
			lines.append("酒馆法术永久增幅：每次实际属性加成额外 +%s 攻击 / +%s 生命" % [bonus.attack,bonus.health])
	if player.get("hero_id","") == PeriodicHero.HERO:
		var periodic: Dictionary = PeriodicHero.progress(player,game.catalog,game.state.round)
		if periodic.ok:
			lines.append("点亮酒馆：酒馆法术额外 +%s/+%s（再过 %s 回合提升；与永久增幅相加）" % [periodic.amount,periodic.amount,periodic.left])
	if player.has(NextSpellDiscount.STATE_KEY):
		var discount: Dictionary = NextSpellDiscount.owner_discount(player,game.state.round,game.state.phase)
		if discount.ok and discount.amount > 0:
			lines.append("下次购买酒馆法术：额外减 %s 金币（0 费购买也消耗次数）" % discount.amount)
	if player.has(DelayedMinionGold.STATE_KEY) and player.get("alive",false):
		var pending: Dictionary = {}
		for receipt in player[DelayedMinionGold.STATE_KEY].entries:
			if int(receipt.paid_round) != 0: continue
			var due: int = int(receipt.event.due_round)
			pending[due] = int(pending.get(due,0))+int(receipt.event.amount)
		var rounds: Array = pending.keys(); rounds.sort()
		for due in rounds:
			lines.append("随从待入账：第 %s 回合招募开始获得 %s 金币" % [due,pending[due]])
	if not lines.is_empty():
		var label = _label("\n".join(lines),14,TEAL,true)
		label.name = "EconomyEffectsStatus"
		content.add_child(label)

func _build_play_area(body: HBoxContainer, player: Dictionary) -> void:
	var center = _column(12)
	center.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	body.add_child(center)
	var status = _row(10)
	status.add_child(_pill("金币 %s / %s" % [player.get("gold", 0), player.get("max_gold", 0)], GOLD))
	status.add_child(_pill("酒馆等级 %s" % player.get("tier", 1), TEAL))
	_spacer(status)
	var roll_quote: Dictionary=game._roll_quote(player)
	var roll_cost: int=int(roll_quote.get("cost",-1))
	var roll_label: String="刷新 · 暂不可用" if not roll_quote.get("ok",false) else ("刷新 · %s 生命" % int(roll_quote.health_cost) if roll_quote.get("health_refresh",false) else "刷新 · %s" % roll_cost)
	var roll = _button(roll_label, func(): _do_command({"type": "roll"}))
	var health_refresh_issue: String=game.HealthRefresh.button_error(game,player)
	roll.disabled = not roll_quote.get("ok",false) or not health_refresh_issue.is_empty() or int(player.get("gold", 0)) < roll_cost or not _can_recruit()
	if not health_refresh_issue.is_empty(): roll.tooltip_text=health_refresh_issue
	status.add_child(roll)
	var freeze = _button("解冻商店" if bool(player.get("frozen", false)) else "冻结商店", func(): _do_command({"type": "freeze"}))
	freeze.disabled = not _can_recruit()
	status.add_child(freeze)
	var upgrade_quote: Dictionary = game._upgrade_cost_quote(player)
	var upgrade = _button("升级 · %s" % (str(upgrade_quote.cost) if upgrade_quote.ok else "?"), func(): _do_command({"type": "upgrade"}))
	upgrade.name = "UpgradeTavern"
	upgrade.disabled = not _can_recruit() or int(player.get("tier", 1)) >= game.LittleLeague.maximum(game.room) or not upgrade_quote.ok or int(player.get("gold",0)) < int(upgrade_quote.cost)
	if not upgrade_quote.ok: upgrade.tooltip_text = str(upgrade_quote.error)
	status.add_child(upgrade)
	center.add_child(status)
	var scroll = ScrollContainer.new()
	recruit_scroll = scroll
	scroll.name = "RecruitScroll"
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	center.add_child(scroll)
	var content = _column(14)
	content.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.add_child(content)
	_build_economy_status(content,player)
	for battle in game.last_combats:
		if int(battle.get("left_player", -1)) == 0 or int(battle.get("right_player", -1)) == 0:
			var side = 0 if int(battle.get("left_player", -1)) == 0 else 1
			var outcome = "平局" if int(battle.get("winner", -1)) == -1 else ("战斗胜利" if int(battle.get("winner", -1)) == side else "战斗落败")
			var opponent_name = str(battle.get("right_name", "对手")) if side == 0 else str(battle.get("left_name", "对手"))
			content.add_child(_label("上一战 · %s vs %s · 结算伤害 %s" % [outcome, opponent_name, battle.get("applied_damage", battle.get("damage", 0))], 14, TEAL if outcome == "战斗胜利" else GOLD, true))
			break
	if _is_finished():
		var end_box = _panel(content, Color("3b3525"), GOLD)
		var winner = game.state.get("winner", -1)
		end_box.add_child(_label("酒馆终章 · 你赢得了胜利" if int(winner) == 0 else "酒馆终章 · 对局结束", 22, GOLD))
		end_box.add_child(_label("你可以查看战斗记录、保存结果，或返回房间再开一局。", 14, MUTED, true))
	if str(game.state.get("phase", "")) == "error":
		var error_box = _panel(content, Color("3a2827"), RED)
		error_box.add_child(_label("效果校验失败，结算已停止", 22, RED))
		error_box.add_child(_label("请查看右侧日志；可保存诊断存档或返回房间调整卡池。未实现效果不会被跳过。", 14, TEXT, true))
	_build_native_buddy_panel(content, player)
	_build_native_prize_panel(content, player)
	if not player.get("discover", []).is_empty():
		var discover_box = _panel(content, Color("3b3525"), GOLD)
		var choice_kind = str(player.discover[0].get("choice_kind", "minion"))
		var discover_title = _label("选择%s级暗月奖品" % player.discover[0].get("prize_tier", "?") if choice_kind == "prize" else {"trinket": "选择饰品", "quest": "选择任务与奖励"}.get(choice_kind, "发现奖励 · 选择一张"), 21, GOLD)
		var scout_discover_info: Dictionary=NativeScoutInfo.discover(player)
		if not scout_discover_info.is_empty(): discover_title.text=scout_discover_info.title
		discover_title.name = "DiscoverTitle"
		if choice_kind == "prize": discover_title.tooltip_text = "来源：" + str(player.discover[0].get("source_id", player.discover[0].get("prize_source_id", NativePrizes.SOURCE)))
		discover_box.add_child(discover_title)
		var discover_hint = _label("选择后加入手牌，使用时再施放或打出。手牌已满仍可选择，已选奖品会保留待发，腾位后领取。" if choice_kind == "prize" else "完成选择后继续招募。", 13, MUTED, true)
		if not scout_discover_info.is_empty(): discover_hint.text=scout_discover_info.hint
		discover_hint.name = "DiscoverHint"
		discover_box.add_child(discover_hint)
		var discover_row = HFlowContainer.new()
		discover_row.add_theme_constant_override("h_separation", 10)
		discover_box.add_child(discover_row)
		for index in range(player.discover.size()):
			var slot = index
			var offer: Dictionary = game.discover_display_card(player,player.discover[index]).duplicate(true)
			offer["card_id"] = offer.get("id", "")
			var offer_column = _column(6)
			var choice_label = "选择 · %s 金币" % offer.get("cost", 0) if str(offer.get("choice_kind", "")) == "trinket" else "选择此奖励"
			if choice_kind == "prize": choice_label = "选择此奖品 · 满手可待发"
			if not scout_discover_info.is_empty(): choice_label=scout_discover_info.button
			var choice_button = _unit_button(offer, choice_label, false, func(): _do_command({"type": "discover", "index": slot}))
			choice_button.name = "DiscoverChoice" + str(index)
			choice_button.disabled = game.AfkStart.Sources.skipping(player) or (game.Faelin.skipping(player) and choice_kind!=game.Faelin.KIND)
			offer_column.add_child(choice_button)
			if str(offer.get("choice_kind", "")) == "quest":
				var detail = _label("奖励：%s\n目标：%s 次" % [offer.get("reward_name", "未知"), offer.get("requirement", 6)], 12, GOLD, true)
				detail.custom_minimum_size.x = 116
				offer_column.add_child(detail)
			discover_row.add_child(offer_column)
	var shop_box = _panel(content, Color("222c29"), Color("535744"))
	var shop_header = _row()
	shop_header.add_child(_label("鲍勃的商店", 19, GOLD))
	_spacer(shop_header)
	shop_header.add_child(_label("已冻结" if bool(player.get("frozen", false)) else "点击卡牌购买", 12, TEAL if bool(player.get("frozen", false)) else MUTED))
	shop_box.add_child(shop_header)
	var shop_row = HFlowContainer.new()
	shop_row.add_theme_constant_override("h_separation", 9)
	shop_row.add_theme_constant_override("v_separation", 9)
	shop_box.add_child(shop_row)
	var shop: Array = player.get("shop", [])
	for index in range(shop.size()):
		var slot = index
		var unit: Dictionary = shop[index]
		var card = catalog.get_card(str(unit.get("card_id", "")))
		var health_buy_quote: Dictionary=game._buy_cost_quote(player,unit)
		var cost: int=int(health_buy_quote.get("cost",-1)) if health_buy_quote.get("ok",false) else -1
		var button = _unit_button(unit, ("购买 · %s 生命" % int(health_buy_quote.health_cost) if health_buy_quote.get("health_buy",false) else "购买 · %s 金币"%cost) if cost>=0 else "价格不可用", false, func(): _do_command({"type": "buy", "index": slot}), "", "shop")
		button.disabled = not _can_recruit() or cost < 0 or not game.Pilgrimp.button_error(game,player,unit).is_empty() or not game.BouncyBuy.button_error(game,player,unit).is_empty() or not game.Bazaar.button_error(game,player,unit).is_empty() or not game.HealthBuy.button_error(game,player,unit).is_empty()
		var card_column = _column(5)
		card_column.add_child(button)
		_wire_recruit_drag(button, "shop", index, "shop", index)
		var target_button = _button("商店目标 ✓" if selected_shop == index else "选为施法目标", func(): selected_shop = -1 if selected_shop == slot else slot; selected_board = -1; _build_game())
		target_button.custom_minimum_size.y = 28
		target_button.add_theme_font_size_override("font_size", 11)
		target_button.disabled = not _can_recruit()
		card_column.add_child(target_button)
		shop_row.add_child(card_column)
	if shop.is_empty():
		shop_row.add_child(_label("商店暂时空了，试试刷新。", 15, MUTED))
	var board_box = _panel(content, Color("15282a"), Color("3d6260"))
	var board_header = _row()
	board_header.add_child(_label("你的战团", 19, TEAL))
	_spacer(board_header)
	board_header.add_child(_label("%s / 7 · 点击选择随从或施法目标" % player.get("board", []).size(), 12, MUTED))
	board_box.add_child(board_header)
	var board_row = HFlowContainer.new()
	board_row.add_theme_constant_override("h_separation", 9)
	board_row.add_theme_constant_override("v_separation", 9)
	board_box.add_child(board_row)
	var board: Array = player.get("board", [])
	if selected_board >= board.size():
		selected_board = -1
	for index in range(board.size()):
		var slot = index
		var select_board: Callable = func():
			selected_board = -1 if selected_board == slot else slot
			selected_shop = -1
			_build_game()
		var board_card = _unit_button(board[index], "目标已选中" if selected_board == index else "位置 %s" % (index + 1), selected_board == index, select_board, "board")
		board_row.add_child(board_card)
		_wire_recruit_drag(board_card, "board", index, "board", index)
	if board.is_empty():
		var placeholder = _label("这里还空着。购买随从，再从手牌打出。", 16, MUTED, true)
		placeholder.custom_minimum_size.y = 82
		board_row.add_child(placeholder)
	var placement_row = HFlowContainer.new()
	placement_row.name = "DragPlacementSlots"
	board_box.add_child(placement_row)
	for gap in range(board.size() + 1):
		var placement = _button("↓ 位置 %s" % (gap + 1), func(): pass)
		placement.tooltip_text = "把手牌拖到这里上场；把战队随从拖到这里调整位置。需要目标或多项选择的牌请使用对应卡牌目标或原按钮。"
		placement_row.add_child(placement)
		_wire_recruit_drag(placement, "", -1, "placement", gap)
	var board_actions = _row(8)
	var move_left = _button("← 左移", func(): _do_command({"type": "move", "from": selected_board, "to": selected_board - 1}))
	move_left.disabled = selected_board <= 0 or not _can_recruit()
	board_actions.add_child(move_left)
	var move_right = _button("右移 →", func(): _do_command({"type": "move", "from": selected_board, "to": selected_board + 1}))
	move_right.disabled = selected_board < 0 or selected_board >= board.size() - 1 or not _can_recruit()
	board_actions.add_child(move_right)
	var sell = _button("出售 · +1 金币", func(): _do_command({"type": "sell", "index": selected_board}))
	sell.disabled = selected_board < 0 or not _can_recruit()
	if selected_board>=0 and selected_board<board.size():
		var scout_sale_info: Dictionary=NativeScoutInfo.sale(game,player,board[selected_board])
		if scout_sale_info.get("active",false):
			sell.tooltip_text=scout_sale_info.text
			sell.disabled=sell.disabled or not scout_sale_info.allowed
			board_actions.add_child(_label(scout_sale_info.text,12,TEAL if scout_sale_info.allowed else RED,true))
	board_actions.add_child(sell)
	var drag_sell = _button("拖到此处出售", func(): pass)
	drag_sell.name = "DragSellTarget"
	drag_sell.tooltip_text = "仅接受战队中的随从；松开后使用原出售命令。拖回原处或按 Esc 可取消。"
	board_actions.add_child(drag_sell)
	_wire_recruit_drag(drag_sell, "", -1, "sell", -1)
	if selected_board >= 0 and MinionActivate.has_source(board[selected_board].get("card_id","")):
		var activation_source: int=selected_board
		var activation_id: String=str(board[activation_source].card_id)
		var activation_cost: int=int(MinionActivate.effect_for_id(activation_id).get("cost",1))
		if MinionActivate.needs_target(activation_id):
			var activate_menu = MenuButton.new()
			activate_menu.text=("发动 · %s 金币 · 选择弃牌" if MinionActivate.target_zones(activation_id)==["hand"] else "发动 · %s 金币 · 选择其他随从") % activation_cost
			if MinionActivate.SkyhatchRallySources.accepts_id(activation_id): activate_menu.text="发动 · 1 金币 · 选择友方进击"
			activate_menu.name="ActivateSelectedMinion"
			activate_menu.disabled=not _can_recruit()
			activate_menu.tooltip_text=MinionActivate.tooltip_for_id(activation_id)
			var activation_commands: Array=[]
			var popup = activate_menu.get_popup()
			for activation_zone in MinionActivate.target_zones(activation_id):
				for target_index in range(player.get(activation_zone,[]).size()):
					var target_unit: Dictionary=player[activation_zone][target_index]
					if activation_zone!="hand" and (target_unit.get("kind")!="minion" or target_unit.get("uid")==board[activation_source].get("uid")): continue
					var command: Dictionary={"type":"activate_minion","index":activation_source,"target":target_index,"target_zone":activation_zone}
					var item_id: int=activation_commands.size()
					activation_commands.append(command)
					popup.add_item("%s %s · %s" % ["手牌" if activation_zone=="hand" else ("战队" if activation_zone=="board" else "酒馆"),target_index+1,target_unit.get("name","随从")],item_id)
					var activation_issue: String=MinionActivate.preflight(game,player,activation_source,target_index,activation_zone)
					popup.set_item_disabled(item_id,not activation_issue.is_empty())
					popup.set_item_tooltip(item_id,activation_issue)
			activate_menu.disabled=activate_menu.disabled or activation_commands.is_empty()
			popup.id_pressed.connect(func(item_id: int): _do_command(activation_commands[item_id].duplicate(true)))
			board_actions.add_child(activate_menu)
		else:
			var activation_issue: String=MinionActivate.preflight(game,player,activation_source)
			var activate_button = _button("发动 · %s 金币" % activation_cost,func(): _do_command({"type":"activate_minion","index":activation_source}),true)
			activate_button.name="ActivateSelectedMinion"
			activate_button.disabled=not _can_recruit() or not activation_issue.is_empty()
			activate_button.tooltip_text=activation_issue if not activation_issue.is_empty() else MinionActivate.tooltip_for_id(activation_id)
			board_actions.add_child(activate_button)
	_spacer(board_actions)
	if selected_board >= 0:
		board_actions.add_child(_label("目标：%s" % board[selected_board].get("name", "随从"), 12, TEAL))
	board_box.add_child(board_actions)
	var hand_box = _panel(content, SURFACE, BORDER)
	var hand_header = _row()
	hand_header.add_child(_label("你的手牌", 19, TEXT))
	_spacer(hand_header)
	hand_header.add_child(_label("%s / 10" % player.get("hand", []).size(), 12, MUTED))
	hand_box.add_child(hand_header)
	var ditch_guardian_extra: int=GameScript.DitchGuardian.amount(player)
	if ditch_guardian_extra>0:
		var ditch_guardian_label = _label("沟渠守护元素 · 本局元素给予额外 +%s/+%s" % [ditch_guardian_extra,ditch_guardian_extra],12,TEAL,true)
		ditch_guardian_label.name="DitchGuardianEarnedEntitlement"
		ditch_guardian_label.tooltip_text="来自真实原生进击的持久给予权益。看给予者是否为元素，不看接受者种族；不预加牌面、不在战斗手牌留存时重复套用。未核实复制、倍增及多给予修饰器组合仍条件阻止。"
		hand_box.add_child(ditch_guardian_label)
	var enhanced_spawn_bonus: Dictionary=GameScript.EnhancedSpawn.bonuses(player)
	if enhanced_spawn_bonus.attack>0 or enhanced_spawn_bonus.health>0:
		var enhanced_spawn_label = _label("增强的光耀之子 · 本局元素给予额外 +%s/+%s" % [enhanced_spawn_bonus.attack,enhanced_spawn_bonus.health],12,TEAL,true)
		enhanced_spawn_label.name="EnhancedSpawnEarnedEntitlement"
		enhanced_spawn_label.tooltip_text="来自真实回合结束的持久给予权益。看给予者是否为元素，不看接受者种族；出售来源后权益仍保留，战斗手牌留存不重复套用。"
		hand_box.add_child(enhanced_spawn_label)
	for enhanced_spawn_source in player.board+player.hand:
		if not GameScript.EnhancedSpawn.Sources.claimed(enhanced_spawn_source): continue
		var enhanced_spawn_clock: Dictionary=enhanced_spawn_source.get(GameScript.EnhancedSpawn.CLOCK,{})
		var enhanced_spawn_axis: String="生命值" if enhanced_spawn_clock.get("axis")=="health" else "攻击力"
		var enhanced_spawn_clock_label = _label("%s · 本轮给予额外 +%s%s；下轮切换" % [enhanced_spawn_source.name,GameScript.EnhancedSpawn.Sources.PROGRAMS[enhanced_spawn_source.card_id][0].amount,enhanced_spawn_axis],11,MUTED)
		enhanced_spawn_clock_label.name="EnhancedSpawnSourceClock"+str(enhanced_spawn_source.uid)
		enhanced_spawn_clock_label.tooltip_text="轴状态绑定此实际来源与主人轮次，只有真正进入主人下一轮才切换，不按效果执行次数翻转。手牌跨轮、复制和变金继承尚未核实，仍条件阻止。"
		hand_box.add_child(enhanced_spawn_clock_label)
	var radiant_ember_health: int=GameScript.RadiantEmber.amount(player)
	if radiant_ember_health>0:
		var radiant_ember_label = _label("辐光余烬 · 本局元素给予额外 +%s 生命" % radiant_ember_health,12,TEAL,true)
		radiant_ember_label.name="RadiantEmberEarnedEntitlement"
		radiant_ember_label.tooltip_text="来自已真实结算亡语的持久给予权益。看给予者是否为元素，不看目标种族；不预加到牌面、不在战斗留存时重复套用。未核实的给予修饰器和动态来源组合仍条件阻止。"
		hand_box.add_child(radiant_ember_label)
	var owner_hand_hint: String = OwnerAuraDisplay.hand_hint(player)
	if not owner_hand_hint.is_empty():
		var aura_hand_label = _label(owner_hand_hint, 12, MUTED, true)
		aura_hand_label.name = "OwnerAuraHandHint"
		hand_box.add_child(aura_hand_label)
	var native_pending: int = BuddyButton.pending_count(player)
	if BuddyButton.enabled(game.room) and native_pending > 0:
		var pending_label = _label("原生伙伴待发 %d 张 · %s已付款，不会重复扣费。通过允许的招募操作腾出手牌空位后自动补发。" % [native_pending, "手牌已满；" if player.get("hand", []).size() >= 10 else ""], 14, GOLD, true)
		pending_label.name = "NativeBuddyHandPending"
		pending_label.tooltip_text = "待发伙伴权益保留；若腾位操作与其他生牌、塑造或奖励的先后尚未核实，规则引擎会明确阻止该操作。淘汰或对局结束时取消未发份数。"
		hand_box.add_child(pending_label)
	var prize_pending: int = NativePrizes.pending_count(player)
	if NativePrizes.enabled_for(game.room,player) and prize_pending > 0:
		var prize_pending_label = _label("暗月奖品待发 %d 张 · %s已选奖品已保留。通过允许的招募操作腾出手牌空位后领取。" % [prize_pending, "手牌已满；" if player.get("hand", []).size() >= 10 else ""], 14, GOLD, true)
		prize_pending_label.name = "NativePrizeHandPending"
		prize_pending_label.tooltip_text = "操作本身先结算，再按本房间所选本地补发顺序处理；同源奖品按产生回合先后。入手不等于使用。"
		hand_box.add_child(prize_pending_label)
	var waiting_count: int = GameScript.SpellcraftWaiting.pending_count(player)
	if waiting_count > 0:
		hand_box.add_child(_label("塑造待领 %s 张 · 腾出手牌后按当前站位从左到右领取。" % waiting_count, 14, TEAL, true))
		hand_box.add_child(_label("本房间自定义规则：来源离场或本回合结束取消未领取的牌；已入手不因卖出来源消失。", 12, MUTED, true))
	var hand_row = HFlowContainer.new()
	hand_row.add_theme_constant_override("h_separation", 9)
	hand_row.add_theme_constant_override("v_separation", 9)
	hand_box.add_child(hand_row)
	_wire_recruit_drag(hand_box, "", -1, "hand", -1)
	_wire_recruit_drag(hand_row, "", -1, "hand", -1)
	hand_box.add_child(_label("拖动商店卡牌到手牌区购买；手牌拖到位置格上场、拖到随从上施法或磁力合体。", 12, MUTED, true))
	var hand: Array = player.get("hand", [])
	if selected_hand >= hand.size():
		selected_hand = -1
	for index in range(hand.size()):
		var slot = index
		var select_hand: Callable=func():
			selected_hand = -1 if selected_hand == slot else slot
			_build_game()
		var hand_card = _unit_button(hand[index], ("锁定 · 剩余 %d 次回合开始" % int(hand[index][game.HandLocks.Sources.MARKER].remaining)) if game.HandLocks.Sources.marked(hand[index]) else ("已选手牌" if selected_hand == index else "选择手牌"), selected_hand == index, select_hand, "", "hand")
		hand_row.add_child(hand_card)
		_wire_recruit_drag(hand_card, "hand", index, "hand", -1)
	if hand.is_empty():
		hand_row.add_child(_label("商店购买的卡牌会放入手牌。", 15, MUTED))
	var hand_actions = _row(10)
	var magnetic_selected = selected_hand >= 0 and selected_hand < hand.size() and "magnetic" in hand[selected_hand].get("keywords", [])
	var play = _button("普通打出" if magnetic_selected else "打出选中手牌", _play_hand, true)
	play.name = "PlaySelectedHand"
	play.custom_minimum_size.y = 52
	play.tooltip_text = "按独立随从上场，不执行磁力合体。" if magnetic_selected else "选择手牌后可直接打出；需要目标时先选择战队或商店中的目标。"
	var selected_hand_locked: bool=selected_hand>=0 and selected_hand<hand.size() and game.HandLocks.Sources.marked(hand[selected_hand])
	var choices: Array = game.Trailblazer.options(game,player,hand[selected_hand]) if selected_hand >= 0 and selected_hand < hand.size() and not selected_hand_locked else []
	play.disabled = selected_hand < 0 or selected_hand_locked or not _can_recruit() or not choices.is_empty()
	if selected_hand_locked: play.tooltip_text="此牌等待实际回合开始解锁，当前无法使用或磁力合体。"
	if selected_hand>=0 and selected_hand<hand.size() and not selected_hand_locked and game.Clunker.Sources.accepts_id(hand[selected_hand].get("card_id")):
		play.tooltip_text="先选择友方机械，再打出废铁残械。选择发现的完整机械并吸附；金色分两次选择。"
	if selected_hand>=0 and selected_hand<hand.size() and not selected_hand_locked and game.FacelessDisciple.Sources.claimed(hand[selected_hand]):
		play.tooltip_text="选择战队或商店中的普通随从。普通提升一级，金色提升两级；当前完整手牌域最高结果六级。"
	if selected_hand>=0 and selected_hand<hand.size() and not selected_hand_locked and game.Nathanos.Sources.claimed(hand[selected_hand]):
		play.tooltip_text="选择另一友方随从。真实出售后将当前属性值均分给原相邻随从；金色先取双倍，双邻居奇数份额暂不支持。"
	if selected_hand>=0 and selected_hand<hand.size() and not selected_hand_locked and game.MiniZerek.Sources.claimed(hand[selected_hand]):
		play.tooltip_text="先选择商店中的随从，再打出迷你泽里克。保留原使用实体与原手牌奖励权利。"
	if selected_hand>=0 and selected_hand<hand.size() and not selected_hand_locked and game.Faceless.Sources.claimed(hand[selected_hand]):
		play.tooltip_text="先选择友方战队中的随从，再打出无面操纵者。复制完整当前实体；保留原使用身份和原奖励权利。"
	if selected_hand>=0 and selected_hand<hand.size() and not selected_hand_locked and game.EfficientEngineer.Sources.claimed(hand[selected_hand]):
		play.tooltip_text="先选择友方随从，触发其完整回合结束效果（小瞎眼除外）；当前支持催眠机器人、拉佐格尔、掘金者及各金色版本。"
	if selected_hand>=0 and selected_hand<hand.size() and not selected_hand_locked and game.LuckyEgg.Sources.claimed(hand[selected_hand]):
		play.tooltip_text="打出幸运彩蛋后选择发现的金色随从，原实体随后变形并完成本次使用。库存采用已标明的本地 pool0 策略。"
	if selected_hand>=0 and selected_hand<hand.size() and not selected_hand_locked and game.Evolution.Sources.claimed(hand[selected_hand]):
		play.tooltip_text="先选择战队或商店中的普通随从，再施放时空扭曲异变并选择六级发现。选择后原位置同一实体变形、设置30/30并完成施法。"
	if not choices.is_empty(): play.tooltip_text = "请点击下方对应的抉择分支；未提交前不会消耗手牌。"
	hand_actions.add_child(play)
	if selected_hand>=0 and selected_hand<hand.size() and not selected_hand_locked and game.DrakkariReborn.Sources.claimed(hand[selected_hand]):
		play.disabled=true;play.tooltip_text="请使用复生菜单，选择本次打出前的不同友方亡灵。"
		var reborn_menu=MenuButton.new()
		reborn_menu.text="战吼复生 · 选择亡灵目标"
		reborn_menu.name="DrakkariRebornTargets"
		reborn_menu.disabled=not _can_recruit()
		var reborn_popup=reborn_menu.get_popup()
		var reborn_commands: Array=[]
		for reborn_selected in game.DrakkariReborn.options(game,player,hand[selected_hand]):
			var reborn_labels: Array[String]=[]
			for reborn_target in reborn_selected:
				var reborn_unit: Dictionary=player.board[int(reborn_target.index)]
				reborn_labels.append("战队"+str(int(reborn_target.index)+1)+" "+str(reborn_unit.get("name","随从")))
			var reborn_item: int=reborn_commands.size()
			reborn_commands.append({"type":"play","index":selected_hand,"target":-1,"position":-1,"target_zone":"board","reborn_targets":reborn_selected.duplicate(true)})
			reborn_popup.add_item(" → ".join(reborn_labels) if not reborn_labels.is_empty() else "无合法目标，直接打出",reborn_item)
			var reborn_plan: Dictionary=game.DrakkariReborn.prepare(game,player,hand[selected_hand],reborn_selected)
			reborn_popup.set_item_disabled(reborn_item,not reborn_plan.ok)
			reborn_popup.set_item_tooltip(reborn_item,str(reborn_plan.error))
		reborn_menu.disabled=reborn_menu.disabled or reborn_commands.is_empty()
		reborn_popup.id_pressed.connect(func(item_id: int): _do_command(reborn_commands[item_id].duplicate(true)))
		hand_actions.add_child(reborn_menu)
	if selected_hand>=0 and selected_hand<hand.size() and not selected_hand_locked and game.BattlecryGolden.Sources.claimed(hand[selected_hand]):
		play.disabled=true;play.tooltip_text="请使用变金菜单明确选择全部目标及先后次序。"
		var golden_menu=MenuButton.new()
		golden_menu.text="战吼变金 · 选择目标顺序"
		golden_menu.name="BattlecryGoldenTargets"
		golden_menu.disabled=not _can_recruit()
		var golden_popup=golden_menu.get_popup()
		var golden_commands: Array=[]
		for golden_selected in game.BattlecryGolden.options(game,player,hand[selected_hand]):
			var golden_labels: Array[String]=[]
			for golden_target in golden_selected:
				var golden_unit: Dictionary=player[golden_target.zone][int(golden_target.index)]
				golden_labels.append(("战队" if golden_target.zone=="board" else "酒馆")+str(int(golden_target.index)+1)+" "+str(golden_unit.get("name","随从")))
			var golden_item: int=golden_commands.size()
			golden_commands.append({"type":"play","index":selected_hand,"target":-1,"position":-1,"target_zone":"board","golden_targets":golden_selected.duplicate(true)})
			var golden_empty_label: String="全部合适的友方亡语随从" if game.BattlecryGolden.Sources.PROGRAMS[hand[selected_hand].card_id][0].scope=="all_friendly" else "无合法目标，直接打出"
			golden_popup.add_item(" → ".join(golden_labels) if not golden_labels.is_empty() else golden_empty_label,golden_item)
			var golden_plan: Dictionary=game.BattlecryGolden.prepare(game,player,hand[selected_hand],golden_selected)
			golden_popup.set_item_disabled(golden_item,not golden_plan.ok)
			golden_popup.set_item_tooltip(golden_item,str(golden_plan.error))
		golden_menu.disabled=golden_menu.disabled or golden_commands.is_empty()
		golden_popup.id_pressed.connect(func(item_id: int): _do_command(golden_commands[item_id].duplicate(true)))
		hand_actions.add_child(golden_menu)
	for choice_index in range(choices.size()):
		var branch_index: int = choice_index
		var option: Dictionary = choices[choice_index]
		var choose_button = _button(str(option.label), func(): _play_hand(branch_index), true)
		choose_button.name = "ChooseOneOption" + str(choice_index)
		var branch_issue: String = ChooseOne.preflight(game,player,hand[selected_hand],branch_index,selected_shop if selected_shop >= 0 else selected_board,"shop" if selected_shop >= 0 else "board")
		choose_button.tooltip_text = str(catalog.get_card(option.card_id).get("text", option.label))
		if not branch_issue.is_empty(): choose_button.tooltip_text += "\n" + branch_issue
		choose_button.disabled = not _can_recruit() or not branch_issue.is_empty()
		hand_actions.add_child(choose_button)
		if ChooseOne.Scarab.claimed(hand[selected_hand]):
			var self_button = _button(str(option.label)+"（自身）",func(): _play_hand(branch_index,true),true)
			self_button.name="ChooseOnePlayedSelf"+str(choice_index)
			var self_issue: String=ChooseOne.preflight(game,player,hand[selected_hand],branch_index,-1,"played")
			self_button.tooltip_text="实际打出后，对这只随从自身结算完整分支。"+("\n"+self_issue if not self_issue.is_empty() else "")
			self_button.disabled=not _can_recruit() or not self_issue.is_empty()
			hand_actions.add_child(self_button)
	if selected_shop < 0 and MagneticRules.can_merge(player, selected_hand, selected_board):
		var magnetize = _button("磁力合体", _magnetize_hand)
		magnetize.name = "MagnetizeSelectedHand"
		magnetize.custom_minimum_size.y = 52
		magnetize.tooltip_text = "将选中磁力手牌融合至选中战队随从。满7个随从时也可融合；普通打出保持独立上场。双发攻城车在已支持组合中使完整吸附发生2次（金色3次），仍只消耗一张手牌；未核实的重复或监听组合不会执行。"
		magnetize.add_theme_color_override("font_color", TEAL)
		var magnetic_repeat_preview: Dictionary=game.MagneticRepeat.prepare(game,player,selected_hand,selected_board,true)
		if not magnetic_repeat_preview.ok: magnetize.tooltip_text+="\n"+str(magnetic_repeat_preview.error)
		magnetize.disabled = selected_hand_locked or not _can_recruit() or not magnetic_repeat_preview.ok
		hand_actions.add_child(magnetize)
	hand_actions.add_child(_label("目标：商店第 %s 格" % (selected_shop + 1) if selected_shop >= 0 else ("目标：己方第 %s 格" % (selected_board + 1) if selected_board >= 0 else "先选手牌；需要目标时选择己方或商店随从。"), 12, TEAL if selected_shop >= 0 or selected_board >= 0 else MUTED, true))
	var scout_hand_notice: String=NativeScoutInfo.hand_notice(player)
	if not scout_hand_notice.is_empty(): hand_actions.add_child(_label(scout_hand_notice,12,RED,true))
	var footer = _row(12)
	footer.name = "RecruitActionBar"
	footer.add_child(_expand(hand_actions))
	var spectating = str(game.state.get("phase", "")) == "spectate"
	var end_turn = _button("继续观战  →" if spectating else "结束回合  →", _advance_spectator if spectating else func(): _do_command({"type": "end_turn"}), true)
	end_turn.custom_minimum_size = Vector2(182, 52)
	end_turn.tooltip_text = "回合结束后自动处理机器人行动与战斗。"
	end_turn.disabled = (not _can_recruit(true) and not spectating)
	footer.add_child(end_turn)
	center.add_child(footer)

func _unit_button(unit: Dictionary, action: String, selected: bool, callback: Callable, display_zone: String = "", ultraviolet_zone: String = "") -> Button:
	var button = Button.new()
	button.custom_minimum_size = Vector2(116, 206)
	button.mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND
	button.pressed.connect(func():
		if recruit_drag.is_empty(): callback.call()
	)
	var card = catalog.get_card(str(unit.get("card_id", "")))
	var unit_kind = str(unit.get("kind", card.get("kind", "minion")))
	var is_spell = unit_kind == "spell"
	var is_minion = unit_kind == "minion"
	var golden = bool(unit.get("golden", false))
	var accent = GOLD if golden else (TEAL if not is_spell else Color("b1a1dc"))
	button.add_theme_stylebox_override("normal", _style(Color("30473c") if selected else Color("253135"), GOLD if selected or golden else Color("48605e"), 10, 10, 10))
	button.add_theme_stylebox_override("hover", _style(Color("344642"), accent, 10, 10, 10))
	button.add_theme_stylebox_override("pressed", _style(Color("3d5346"), GOLD, 10, 10, 10))
	var margin = MarginContainer.new()
	margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	margin.offset_left = 10
	margin.offset_right = -10
	margin.offset_top = 8
	margin.offset_bottom = -8
	margin.mouse_filter = Control.MOUSE_FILTER_IGNORE
	button.add_child(margin)
	var column = _column(3)
	column.mouse_filter = Control.MOUSE_FILTER_IGNORE
	margin.add_child(column)
	var top = _label("★ %s%s" % [unit.get("tier", card.get("tier", 1)), " · 金色" if golden else ""] if is_minion else _kind_name(unit_kind), 11, accent)
	if str(unit.get("choice_kind", "")) == "prize":
		top.text = "奖品等级 %s · %s" % [unit.get("prize_tier", "?"), _kind_name(unit_kind)]
	top.mouse_filter = Control.MOUSE_FILTER_IGNORE
	column.add_child(top)
	var image_path = str(unit.get("image", card.get("image", "")))
	if not image_path.is_empty() and ResourceLoader.exists(image_path):
		var full_texture = load(image_path)
		if full_texture is Texture2D:
			var art = TextureRect.new()
			var atlas = AtlasTexture.new()
			atlas.atlas = full_texture
			var image_size = full_texture.get_size()
			atlas.region = Rect2(image_size.x * 0.24, image_size.y * 0.15, image_size.x * 0.52, image_size.y * 0.35)
			art.texture = atlas
			art.custom_minimum_size.y = 56
			art.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
			art.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
			art.mouse_filter = Control.MOUSE_FILTER_IGNORE
			column.add_child(art)
	var name_label = _label(str(unit.get("name", card.get("name", "未知卡牌"))), 14, TEXT, true)
	name_label.custom_minimum_size.y = 38
	name_label.max_lines_visible = 2
	name_label.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
	name_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	column.add_child(name_label)
	var keywords: PackedStringArray = []
	for keyword in unit.get("keywords", []):
		keywords.append(str(KEYWORDS.get(str(keyword), keyword)))
	var description = _label(" · ".join(keywords) if not keywords.is_empty() else (_spell_category_label(unit) if is_spell else _tribes(unit.get("tribes", []))), 11, MUTED, true)
	description.custom_minimum_size.y = 23
	description.max_lines_visible = 2
	description.mouse_filter = Control.MOUSE_FILTER_IGNORE
	column.add_child(description)
	var stats = _label("%s     /     %s" % [unit.get("attack", 0), unit.get("health", 1)] if is_minion else ("施放效果" if is_spell else "机制选择"), 20, accent)
	stats.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	stats.mouse_filter = Control.MOUSE_FILTER_IGNORE
	column.add_child(stats)
	var owner_contribution: String = OwnerAuraDisplay.board_label(unit, display_zone) if is_minion else ""
	if not owner_contribution.is_empty():
		var aura_label = _label(owner_contribution, 11, TEAL, true)
		aura_label.name = "OwnerAuraContribution"
		aura_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		aura_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
		column.add_child(aura_label)
		button.custom_minimum_size.y = 228
	var scout_note: String=NativeScoutInfo.unit_note(game,unit,display_zone)
	if not scout_note.is_empty():
		var scout_label=_label(scout_note.split("\n")[0],11,TEAL,true)
		scout_label.name="PatientScoutCurrentDiscoverTier"
		scout_label.mouse_filter=Control.MOUSE_FILTER_IGNORE
		column.add_child(scout_label)
		button.custom_minimum_size.y=maxf(button.custom_minimum_size.y,228)
	var nosy_note: String=NativeOwnerProgress.nosy_note(unit,display_zone)
	if not nosy_note.is_empty():
		var nosy_label=_label(nosy_note.split("\n")[0],11,TEAL,true)
		nosy_label.name="NosyActualInstanceClock"
		nosy_label.mouse_filter=Control.MOUSE_FILTER_IGNORE
		column.add_child(nosy_label)
		button.custom_minimum_size.y=maxf(button.custom_minimum_size.y,228)
	var ultraviolet_note: String=UltravioletInfo.note(unit,ultraviolet_zone if not ultraviolet_zone.is_empty() else display_zone)
	if not ultraviolet_note.is_empty():
		var ultraviolet_label=_label(ultraviolet_note.split("\n")[0],11,TEAL,true)
		ultraviolet_label.name="UltravioletActualGrowth"
		ultraviolet_label.mouse_filter=Control.MOUSE_FILTER_IGNORE
		column.add_child(ultraviolet_label)
		button.custom_minimum_size.y=maxf(button.custom_minimum_size.y,244)
	var action_label = _label(action, 11, GOLD if selected else MUTED)
	action_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	action_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	column.add_child(action_label)
	var display_note: String = OwnerAuraDisplay.BOARD_HINT + "\n" + owner_contribution if not owner_contribution.is_empty() else ""
	if not scout_note.is_empty(): display_note+=("\n" if not display_note.is_empty() else "")+scout_note
	if not ultraviolet_note.is_empty(): display_note+=("\n" if not display_note.is_empty() else "")+ultraviolet_note
	if not nosy_note.is_empty(): display_note+=("\n" if not display_note.is_empty() else "")+nosy_note
	if unit.get("card_id") in ["BG33_891","BG33_891_G"]:
		var teach_limit: int=2 if unit.card_id=="BG33_891_G" else 1
		var teach_quota: Dictionary=unit.get("native_spellteach_purchase_quota",{})
		var teach_used: int=int(teach_quota.get("used",0)) if teach_quota.get("round")==game.state.get("round") else 0
		display_note+=("\n" if not display_note.is_empty() else "")+"本回合剩余教学："+str(maxi(0,teach_limit-teach_used))
	if unit.has("native_spellteach_binding"):
		var learned: Dictionary=catalog.get_card(str(unit.native_spellteach_binding.get("spell_id","")))
		var learned_note: String="已学会："+str(learned.get("name","未核实法术"))+"\n"+str(learned.get("text",""))
		display_note+=("\n" if not display_note.is_empty() else "")+learned_note
		var learned_label=_label("已学："+str(learned.get("name","法术")),11,TEAL,true)
		learned_label.mouse_filter=Control.MOUSE_FILTER_IGNORE
		column.add_child(learned_label)
		button.custom_minimum_size.y=maxf(button.custom_minimum_size.y,228)
	if game.OldSoul.Sources.accepts_id(unit.get("card_id")):
		var old_soul_remaining: int=15-game.OldSoul.Sources.progress(unit)
		var old_soul_note: String="手牌死亡进度：已完成" if old_soul_remaining==0 else "手牌死亡进度：还剩"+str(old_soul_remaining)+"个友方随从"
		display_note+=("\n" if not display_note.is_empty() else "")+old_soul_note
	var slither_note: String=game.Slither.description(unit)
	if not slither_note.is_empty(): display_note+=("\n" if not display_note.is_empty() else "")+slither_note
	button.tooltip_text = "%s\n%s\n%s%s\n%s" % [unit.get("name", ""), unit.get("text", card.get("text", "")), " · ".join(keywords), "\n" + display_note if not display_note.is_empty() else "", action]
	return button

func _wire_recruit_drag(control: Control, source_zone: String, source_index: int, target_zone: String, target_index: int) -> void:
	control.set_drag_forwarding(
		_recruit_drag_data.bind(control, source_zone, source_index),
		_recruit_can_drop.bind(target_zone, target_index),
		_recruit_drop.bind(target_zone, target_index)
	)

func _drag_input_available() -> bool:
	return screen == "game" and _can_recruit() and not bool(_player().get("ready", false)) and _player().get("discover", []).is_empty() and not (is_instance_valid(active_dialog) and active_dialog.visible)

func _recruit_drag_data(_at: Vector2, control: Control, zone: String, index: int) -> Variant:
	if not _drag_input_available() or zone not in ["shop", "hand", "board"]: return null
	var units: Array = _player().get(zone, [])
	if index < 0 or index >= units.size(): return null
	var commands: Array = game.legal_actions(0)
	var source: Dictionary = units[index]
	var usable: bool = commands.any(func(command):
		if zone == "shop": return command.get("type") == "buy" and command.get("index", -1) == index
		if zone == "board": return (command.get("type") == "sell" and command.get("index", -1) == index) or (command.get("type") == "move" and command.get("from", -1) == index)
		return command.get("type") in ["play", "spell", "magnetize"] and command.get("index", -1) == index
	)
	if not usable: return null
	recruit_drag_serial += 1
	recruit_drag = {"owner": get_instance_id(), "serial": recruit_drag_serial, "revision": scroll_build_revision, "sequence": game.state.get("command_sequence", 0), "event_count": game.events.size(), "round": game.state.get("round"), "zone": zone, "index": index, "unit": source, "uid": source.get("uid"), "card_id": source.get("card_id"), "commands": commands}
	var preview = PanelContainer.new()
	preview.mouse_filter = Control.MOUSE_FILTER_IGNORE
	preview.add_theme_stylebox_override("panel", _style(SURFACE, GOLD))
	var caption = _label(str(source.get("name", "卡牌")) + "\n松开执行 · Esc 取消", 16, GOLD)
	caption.mouse_filter = Control.MOUSE_FILTER_IGNORE
	preview.add_child(caption)
	control.set_drag_preview(preview)
	return recruit_drag

func _recruit_drag_current(data: Variant) -> bool:
	if not data is Dictionary or not is_same(data, recruit_drag) or not _drag_input_available(): return false
	if data.get("owner") != get_instance_id() or data.get("revision") != scroll_build_revision or data.get("sequence") != game.state.get("command_sequence", 0) or data.get("event_count") != game.events.size() or data.get("round") != game.state.get("round"): return false
	var units: Array = _player().get(str(data.get("zone", "")), [])
	var index: int = int(data.get("index", -1))
	return index >= 0 and index < units.size() and is_same(units[index], data.get("unit")) and units[index].get("uid") == data.get("uid") and units[index].get("card_id") == data.get("card_id")

func _recruit_drop_command(data: Variant, zone: String, index: int, fresh: bool = false) -> Dictionary:
	if not _recruit_drag_current(data): return {}
	var commands: Array = game.legal_actions(0) if fresh else data.commands
	var source_index: int = int(data.index)
	var board_size: int = _player().get("board", []).size()
	if data.zone == "shop" and zone == "hand":
		for command in commands:
			if command.get("type") == "buy" and command.get("index", -1) == source_index: return command.duplicate(true)
	if data.zone == "board":
		if zone == "sell":
			for command in commands:
				if command.get("type") == "sell" and command.get("index", -1) == source_index: return command.duplicate(true)
		if zone in ["board", "placement"]:
			var destination: int = index - (1 if zone == "placement" and index > source_index else 0)
			if destination < 0 or destination >= board_size or destination == source_index: return {}
			for command in commands:
				if command.get("type") == "move" and command.get("from", -1) == source_index and command.get("to", -1) == destination: return command.duplicate(true)
	if data.zone != "hand": return {}
	# Dropping directly onto a friendly card means Magnetic when the engine
	# offers that exact command. Separate placement slots always mean normal play.
	if zone == "board":
		for command in commands:
			if command.get("type") == "magnetize" and command.get("index", -1) == source_index and command.get("target", -1) == index: return command.duplicate(true)
	for command in commands:
		if command.get("type") not in ["play", "spell"] or command.get("index", -1) != source_index: continue
		# Do not silently choose a branch or an ordered multi-target program.
		if command.has("choice") or command.has("golden_targets") or command.has("reborn_targets") or command.has("hero_targets"): continue
		var target: int = int(command.get("target", -1))
		if zone in ["board", "shop"] and index >= 0 and target == index and command.get("target_zone", "board") == zone: return command.duplicate(true)
		if zone == "placement" and target < 0 and command.get("target_zone", "board") == "board" and index >= 0 and index <= board_size:
			var placed: Dictionary = command.duplicate(true)
			if data.unit.get("kind", "minion") == "minion": placed.position = index
			return placed
	return {}

func _recruit_can_drop(_at: Vector2, data: Variant, zone: String, index: int) -> bool:
	return not _recruit_drop_command(data, zone, index).is_empty()

func _recruit_drop(_at: Vector2, data: Variant, zone: String, index: int) -> void:
	var command: Dictionary = _recruit_drop_command(data, zone, index, true)
	if command.is_empty(): return
	if command.get("type") == "magnetize":
		selected_board = int(command.target)
		selected_shop = -1
	# Dispatch through the original boundary before a later input can change
	# indexes. The native drag payload stays live through mouse release so the
	# source button cannot also perform its click action.
	_do_command(command)

func _notification(what: int) -> void:
	if what == NOTIFICATION_DRAG_END:
		_finish_recruit_drag.call_deferred(recruit_drag_serial)

func _finish_recruit_drag(serial: int) -> void:
	if serial == recruit_drag_serial: recruit_drag = {}

func _build_log_area(body: HBoxContainer) -> void:
	var outer = PanelContainer.new()
	outer.custom_minimum_size.x = 256
	outer.add_theme_stylebox_override("panel", _style(SURFACE, BORDER, 12, 14, 14))
	body.add_child(outer)
	var column = _column(10)
	outer.add_child(column)
	column.add_child(_label("酒馆纪事", 19, GOLD))
	column.add_child(_label("行动与战斗结果", 12, MUTED))
	column.add_child(_button("查看上轮战斗记录", _show_combat_replay))
	var log_view = RichTextLabel.new()
	log_view.size_flags_vertical = Control.SIZE_EXPAND_FILL
	log_view.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	log_view.custom_minimum_size.x = 220
	log_view.bbcode_enabled = false
	log_view.scroll_following = true
	log_view.add_theme_font_size_override("normal_font_size", 13)
	log_view.add_theme_color_override("default_color", MUTED)
	column.add_child(log_view)
	var logs: Array = game.state.get("log", [])
	var lines: PackedStringArray = []
	for index in range(maxi(0, logs.size() - 100), logs.size()):
		lines.append(_format_log(logs[index]))
	log_view.text = "\n\n".join(lines) if not lines.is_empty() else "欢迎来到暮光酒馆。\n\n从商店购买你的第一位随从吧。"

func _format_log(entry: Variant) -> String:
	if entry is String:
		return str(entry)
	if entry is Dictionary:
		for field in ["message", "text", "description"]:
			if entry.has(field):
				return str(entry[field])
		return JSON.stringify(entry)
	return str(entry)

func _short_value(value: Variant) -> String:
	if value is Array:
		var names: PackedStringArray = []
		for item in value:
			if item is String:
				names.append(str(catalog.get_card(item).get("name", item)))
			else:
				names.append(str(item))
		return "、".join(names)
	return str(value)

func _is_finished() -> bool:
	return str(game.state.get("phase", "")) in ["finished", "game_over", "ended"]

func _play_hand(choice: int = -1, choose_played_self: bool = false) -> void:
	var player = _player()
	var hand: Array = player.get("hand", [])
	if selected_hand < 0 or selected_hand >= hand.size():
		_notify("请先选择一张手牌。", true)
		return
	var card = catalog.get_card(str(hand[selected_hand].get("card_id", "")))
	var command = {"type": "spell" if str(hand[selected_hand].get("kind", card.get("kind", "minion"))) == "spell" else "play", "index": selected_hand, "target": selected_shop if selected_shop >= 0 else selected_board, "target_zone": "shop" if selected_shop >= 0 else "board", "position": -1}
	if choice >= 0: command.choice = choice
	if choose_played_self and ChooseOne.Scarab.claimed(hand[selected_hand]):
		command.target=-1;command.target_zone="played"
	_do_command(command)

func _magnetize_hand() -> void:
	if selected_shop >= 0 or not MagneticRules.can_merge(_player(), selected_hand, selected_board):
		_notify("请先选择磁力手牌和可融合的己方随从。", true)
		return
	_do_command({"type": "magnetize", "index": selected_hand, "target": selected_board})

func _build_native_buddy_panel(parent: VBoxContainer, player: Dictionary) -> void:
	if not BuddyButton.enabled(game.room):
		return
	var box = _panel(parent, Color("302f23"), Color("716246"))
	box.name = "NativeBuddyPanel"
	var saved: Variant = player.get(BuddyButton.KEY, {})
	var buddy_state: Dictionary = saved if saved is Dictionary else {}
	var buddy: Dictionary = game.catalog.get_card(str(buddy_state.get("buddy_id", "")))
	var title = _label("原生伙伴 · " + str(buddy.get("name", "伙伴身份待核实")), 19, GOLD, true)
	title.name = "NativeBuddyName"
	title.tooltip_text = str(buddy.get("text", ""))
	box.add_child(title)
	var current_cost: int = BuddyButton.cost(player)
	var price_text: String = str(current_cost) if current_cost >= 0 else "待核实"
	var purchases: int = int(buddy_state.get("purchases", 0))
	var pending: int = BuddyButton.pending_count(player)
	var status = _label("当前价格 %s 金币 · 已付费领取 %d / 2 · 待发 %d 张" % [price_text, purchases, pending], 14, TEXT, true)
	status.name = "NativeBuddyStatus"
	box.add_child(status)
	var issue: String = BuddyButton.purchase_error(game, player)
	var buy = _button("伙伴领取已用完" if purchases >= 2 else "领取伙伴 ×%d · %s 金币" % [purchases + 1, price_text], func(): _do_command({"type": "buddy_buy"}), true)
	buy.name = "NativeBuddyBuy"
	buy.disabled = not issue.is_empty()
	buy.tooltip_text = issue if not issue.is_empty() else "向规则引擎提交一次伙伴领取；首次1张，第二次2张，手牌满时保留已付款的待发份数。"
	box.add_child(buy)
	var reason = _label(issue if not issue.is_empty() else "可以领取。手牌满时先付款，待发伙伴会在合法腾位后补发。", 13, RED if not issue.is_empty() else TEAL, true)
	reason.name = "NativeBuddyReason"
	reason.tooltip_text = reason.text
	box.add_child(reason)

func _build_native_prize_panel(parent: VBoxContainer, player: Dictionary) -> void:
	BeetleSettings.add_match_summary(parent,game.room,player)
	DamageSettings.add_match_summary(parent,game.room)
	OutbackSettings.add_match_summary(parent,game.room)
	# Read the match's saved rule, never the independently editable next room.
	if AttackGainOrder.schema_error(game.room).is_empty():
		for option in AttackGainOrder.options():
			if game.room.get(AttackGainOrder.FIELD, "") != option.value: continue
			var attack_box = _panel(parent, Color("302f23"), Color("716246"))
			attack_box.name = "AttackGainRules"
			var attack_label = _label(option.label + "。本地自选规则（非官方），适用于所有玩家和机器人。仅调整已核实的固定友方增益与单一攻击乘算，各来源内部顺序不变。", 12, MUTED, true)
			attack_label.name = "AttackGainMatchRule"
			attack_box.add_child(attack_label)
			break
	if ShopRefreshCategoryOrder.schema_error(game.room).is_empty():
		for option in ShopRefreshCategoryOrder.options():
			if game.room.get(ShopRefreshCategoryOrder.FIELD, "") != option.value: continue
			var refresh_box = _panel(parent, Color("302f23"), Color("716246"))
			refresh_box.name = "ShopRefreshCategoryRules"
			var refresh_label = _label(option.label + "。本地自选沙盒规则（非官方），适用于所有玩家和机器人。新商店牌和基础商店加成就绪后执行；保留各来源及各组内部顺序。", 12, MUTED, true)
			refresh_label.name = "ShopRefreshCategoryMatchRule"
			refresh_box.add_child(refresh_label)
			break
	if RefreshGemBarrage.schema_error(game.room).is_empty():
		for option in RefreshGemBarrage.options():
			if game.room.get(RefreshGemBarrage.FIELD, "") != option.value: continue
			var gem_box = _panel(parent, Color("302f23"), Color("716246"))
			gem_box.name = "RefreshGemBarrageRules"
			gem_box.add_child(_label(option.label + "。本地自选规则（非官方），适用于全员。按实际施放顺序逐权益、酒馆从左至右添加固定宝石附魔。", 12, MUTED, true))
			break
	if game.room.get(RefreshOffers.FIELD,"")==RefreshOffers.POLICY:
		var offer_box=_panel(parent,Color("302f23"),Color("716246"))
		offer_box.name="RefreshExtraOfferRules"
		offer_box.add_child(_label("额外商店本地策略（非官方）：容量7，冻结先保留，额外组先占库存与容量，普通格后抽，额外实体最后追加。含初始/自然补货；溢出暂停，来源partial。",12,MUTED,true))
	if RefreshOwnerBuffs.schema_error(game.room).is_empty():
		for option in RefreshOwnerBuffs.options():
			if game.room.get(RefreshOwnerBuffs.FIELD, "") != option.value: continue
			var owner_refresh_box = _panel(parent, Color("302f23"), Color("716246"))
			owner_refresh_box.name = "RefreshOwnerBuffRules"
			owner_refresh_box.add_child(_label(option.label + "。本地自选规则（非官方），适用于全员。金色每发独立随机选取当时酒馆目标；普通属性增益，不产生宝石附魔。", 12, MUTED, true))
			break
	if EndTurnCategoryOrder.schema_error(game.room).is_empty():
		for option in EndTurnCategoryOrder.options():
			if game.room.get(EndTurnCategoryOrder.FIELD, "") != option.value: continue
			var category_box = _panel(parent, Color("302f23"), Color("716246"))
			category_box.name = "EndTurnCategoryRules"
			var category_label = _label(option.label + "。本地自选沙盒规则（非官方），适用于所有玩家和机器人。保留各组内部顺序；返币规则与英雄阶段独立。", 12, MUTED, true)
			category_label.name = "EndTurnCategoryMatchRule"
			category_box.add_child(category_label)
			break
	if not str(game.room.get(MinionPriceOrder.FIELD,"")).is_empty():
		var price_box = _panel(parent,Color("302f23"),Color("716246"))
		price_box.name = "MinionPriceRules"
		var price_label: String = "亲友折扣最终生效：固定2枚" if game.room[MinionPriceOrder.FIELD] == MinionPriceOrder.PRIZE_LAST else "其它已实现价格优先：首购免费等来源先按原有条件判断"
		price_box.add_child(_label("本地混搭价格："+price_label+"，适用于所有玩家。",12,MUTED,true))
	if not str(game.room.get(DelayedIncomeRoom.FIELD,"")).is_empty():
		var income_box = _panel(parent,Color("302f23"),Color("716246"))
		income_box.name = "DelayedIncomeRules"
		var income_label: String = "随从收入先于法术负债" if game.room[DelayedIncomeRoom.FIELD] == "minion_first" else "法术负债先于随从收入"
		income_box.add_child(_label("本地混搭到账顺序："+income_label+"，适用于所有玩家。",12,MUTED,true))
	if not str(game.room.get("coin_end_turn_order","")).is_empty():
		var local_box = _panel(parent, Color("302f23"), Color("716246"))
		local_box.name = "MixedEndTurnRules"
		var order_label: String = "先返币，再结算其它回合末来源" if game.room.coin_end_turn_order == "coin_first" else "先结算其它回合末来源，再返币"
		local_box.add_child(_label("本地混搭顺序："+order_label+"。两者均先于共同到期清理，适用于所有玩家。",12,MUTED,true))
	if not NativePrizes.enabled_for(game.room,player): return
	var box = _panel(parent, Color("302f23"), Color("716246"))
	box.name = "NativePrizePanel"
	box.add_child(_label("提克特斯 · 奖品满墙" if NativePrizes.source_for(game.room,player) == NativePrizes.Tickatus.SOURCE else "原生暗月奖品", 19, GOLD))
	var pending: int = NativePrizes.pending_count(player)
	var status = _label("每4回合选择一次 · 奖品等级1 → 2 → 3 → 4，之后维持4级 · 已选待发 %d 张" % pending, 13, TEXT, true)
	status.name = "NativePrizeStatus"
	box.add_child(status)
	var choice_text: String = {"quest_first": "第4轮任务先选", "prize_first": "第4轮奖品先选"}.get(str(game.room.get("prize_choice_order", "")), "未启用任务，无需发现顺序")
	var delivery_text: String = {"after_command_prize_first": "操作结算后先补奖品", "after_command_existing_first": "操作结算后先补已有来源"}.get(str(game.room.get("prize_delivery_order", "")), "补发顺序未指定")
	var rules = _label("本地混搭：%s；%s。同源奖品按回合先后。" % [choice_text, delivery_text], 12, MUTED, true)
	rules.name = "NativePrizeMatchRules"
	box.add_child(rules)

func _do_command(command: Dictionary) -> void:
	var command_type = str(command.get("type", ""))
	var events_before: int = game.events.size()
	var chosen_prize: Dictionary = {}
	var before_choices: Array = _player().get("discover", [])
	var choice_index: int = int(command.get("index", -1))
	if command_type == "discover" and choice_index >= 0 and choice_index < before_choices.size() and before_choices[choice_index].get("choice_kind", "") == "prize":
		chosen_prize = before_choices[choice_index].duplicate(true)
	var old_board = selected_board
	var old_target_uid = ""
	var board_before: Array = _player().get("board", [])
	if selected_board >= 0 and selected_board < board_before.size():
		old_target_uid = str(board_before[selected_board].get("uid", ""))
	var result = game.apply_command(0, command)
	if bool(result.get("ok", false)):
		message_is_error = false
		message = {"buy": "已购买，卡牌已加入手牌。", "play": "随从已上场。", "spell": "法术已施放。", "sell": "已出售随从。", "move": "已调整阵容顺序。", "roll": "商店已刷新。", "freeze": "已切换商店冻结状态。", "upgrade": "酒馆已升级。", "hero_power": "英雄技能已使用。", "end_turn": "战斗已结算，可观看回放；关闭后继续招募。", "discover": "发现奖励已加入手牌。", "magnetize": "磁力合体完成，目标随从已获得强化。"}.get(command_type, "行动已完成。")
		var delivered_prizes: Array = game.events.slice(events_before).filter(func(event): return event.get("type", "") == "prize_delivered" and event.get("player", -1) == 0)
		if not chosen_prize.is_empty():
			var waiting: bool = _player().get(NativePrizes.KEY, {}).get("events", []).any(func(event): return event.get("sequence") == chosen_prize.get("prize_sequence") and event.get("status") == "pending")
			message = "已选择「%s」，奖品已保留待发；腾出手牌空位后领取。" % chosen_prize.get("name", "暗月奖品") if waiting else "暗月奖品「%s」已加入手牌，使用时再施放或打出。" % chosen_prize.get("name", "暗月奖品")
		elif not delivered_prizes.is_empty():
			message += " 暗月奖品已补发入手。"
		if command_type == "buddy_buy":
			var pending: int = BuddyButton.pending_count(_player())
			message = "伙伴已付款领取，仍有 %d 张等待手牌空位；不会重复扣费。" % pending if pending > 0 else "伙伴已领取并加入手牌。"
		if command_type in ["buy", "roll", "hero_power", "end_turn"]:
			selected_shop = -1
		if command_type in ["buy", "play", "spell", "magnetize"]:
			selected_hand = -1
		if command_type in ["buy", "play", "spell", "sell", "end_turn"]:
			selected_board = -1
		elif command_type == "move":
			selected_board = int(command.get("to", old_board))
		elif command_type == "magnetize":
			selected_board = -1
			var board_after: Array = _player().get("board", [])
			for index in range(board_after.size()):
				if str(board_after[index].get("uid", "")) == old_target_uid:
					selected_board = index
					break
		if str(game.state.get("phase", "")) == "error":
			message = "结算遇到不支持的效果，已停止。请查看日志。"
			message_is_error = true
	else:
		message = str(result.get("error", "行动失败"))
		message_is_error = true
	_build_game()
	if command_type == "end_turn" and bool(result.get("ok", false)) and not game.last_combats.is_empty():
		_show_combat_replay(true)

func _save_game() -> void:
	DirAccess.make_dir_recursive_absolute("user://saves")
	var result = game.save_to(SAVE_PATH)
	_notify("对局已保存到本地 saves/latest.json。" if result == OK else "保存对局失败：%s" % error_string(result), result != OK)

func _load_game() -> void:
	# Game.load_from owns isolated restoration and commits only on success.
	# Keep UI selections and callbacks intact until that transaction succeeds.
	var result = game.load_from(SAVE_PATH, catalog)
	var ok = bool(result.get("ok", false)) if result is Dictionary else result == OK
	if ok:
		_commit_game_session(game)
		message = "已载入对局存档。"
		message_is_error = false
		_build_game(false)
	else:
		var reason = str(result.get("error", "未知错误")) if result is Dictionary else error_string(result)
		if result == ERR_FILE_NOT_FOUND:
			var guidance: String = "请先用右上角“保存对局”保存当前进度，或“返回房间”新建对局。" if screen == "game" else "请点击左侧底部“新建对局”；开局后用右上角“保存对局”保存进度。"
			_notify("尚无对局存档。" + guidance, true)
		elif result == ERR_INVALID_DATA:
			_notify("存档与当前范围/规则不兼容或数据损坏；未改变当前对局，也未改写旧存档。请返回房间显式新建当前范围对局。", true)
		else:
			_notify("载入对局失败：%s。当前对局未改变。" % reason, true)

func _commit_game_session(candidate) -> void:
	# Only successful start/load paths enter here. Old UI captures must not
	# target a new match that happens to reuse the same source UID or round.
	_dismiss_dialog()
	recruit_drag_serial += 1
	recruit_drag = {}
	scroll_build_revision += 1
	restoring_game_scroll = false
	recruit_scroll = null
	opponents_scroll = null
	saved_recruit_scroll = 0
	saved_opponents_scroll = 0
	rendered_round = -1
	selected_board = -1
	selected_shop = -1
	selected_hand = -1
	game = candidate

func _show_combat_replay(autoplay: bool = false) -> void:
	_dismiss_dialog()
	var dialog = preload("res://ui/combat_replay.gd").new()
	dialog.configure(game.last_combats, catalog, autoplay)
	active_dialog = dialog
	add_child(dialog)
	dialog.popup_centered(Vector2i(1160, 790))

func _can_recruit(allow_skipped_end_turn: bool=false) -> bool:
	return str(game.state.get("phase", "")) == "recruit" and bool(_player().get("alive", false)) and (allow_skipped_end_turn or (not game.AfkStart.Sources.skipping(_player()) and not game.Faelin.skipping(_player())))

func _hero_targets_shop() -> bool:
	for effect in catalog.get_card(str(_player().get("hero_id", ""))).get("effects", []):
		if str(effect.get("type", "")) == "hero_collect_minion_types_discover": return true
		if str(effect.get("type", "")) == "hero_lock_tavern_card": return true
		if str(effect.get("type", "")) == "hero_tavern_higher_tier_choice": return true
		if str(effect.get("type", "")) == "hero_steal" and effect.get("scope","target") == "target":
			return true
	return false

func _activate_hero_power() -> void:
	# The engine owns current power identity, cost, phase, pending choices and
	# native target rules. Preserve its complete command rather than routing by
	# a second, inevitably stale list of hero IDs or effect names.
	var commands: Array = game.legal_actions(0).filter(func(command): return command.get("type", "") == "hero_power")
	if commands.is_empty():
		var unavailable: String = game.hero_power_unavailable_reason(_player())
		_notify(unavailable if not unavailable.is_empty() else "当前没有可执行的英雄技能，请先处理待选奖励或检查技能条件。", true)
		return
	var selections: Dictionary = {"board": selected_board, "shop": selected_shop, "hand": selected_hand}
	for command in commands:
		# Multi-target powers retain their existing explicit ordered-target menu.
		if command.has("hero_targets"): continue
		var target: int = int(command.get("target", -1))
		var zone: String = str(command.get("target_zone", "board"))
		if target >= 0 and target == int(selections.get(zone, -1)):
			_do_command(command.duplicate(true))
			return
	for command in commands:
		if not command.has("hero_targets") and int(command.get("target", -1)) < 0:
			_do_command(command.duplicate(true))
			return
	_notify("请先选择当前技能的合法目标；需要两个目标的技能请使用目标菜单。", true)

func _hero_has_active_power() -> bool:
	# A source already supported by Game must not be hidden by a UI whitelist.
	return game.legal_actions(0).any(func(command): return command.get("type", "") == "hero_power")

func _advance_spectator() -> void:
	var result = game.advance_round()
	message = "观战回合已结算。" if bool(result.get("ok", false)) else str(result.get("error", "无法继续观战"))
	message_is_error = not bool(result.get("ok", false))
	if str(game.state.get("phase", "")) == "error":
		message = "结算遇到不支持的效果，已停止。请查看日志。"
		message_is_error = true
	_build_game()

func _show_card_details(card: Dictionary) -> void:
	_dismiss_dialog()
	var dialog = AcceptDialog.new()
	active_dialog = dialog
	dialog.title = str(card.get("name", "卡牌详情"))
	dialog.ok_button_text = "关闭详情"
	add_child(dialog)
	var row = _row(18)
	row.custom_minimum_size = Vector2(680, 360)
	dialog.add_child(row)
	var image_path = str(card.get("image", ""))
	if not image_path.is_empty() and ResourceLoader.exists(image_path):
		var art = TextureRect.new()
		art.texture = load(image_path)
		art.custom_minimum_size = Vector2(215, 320)
		art.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		art.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		row.add_child(art)
	var column = _column(12)
	column.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	row.add_child(column)
	column.add_child(_label(str(card.get("name", "")), 25, GOLD, true))
	column.add_child(_label("来源分类：%s · %s" % [card.get("category", _kind_name(str(card.get("kind", "")))), card.get("id", "")], 12, MUTED, true))
	var custom_id = str(card.get("id", ""))
	if not _custom_shop_entry(custom_id).is_empty():
		column.add_child(_label(_custom_shop_summary(custom_id), 14, GOLD, true))
	if pool_kind != "prize" and str(card.get("kind", "")) in ["minion", "spell"] and CurrentScope.allows_pool(str(card.kind),custom_id,catalog):
		column.add_child(_button("自定义入店", func(): _show_custom_shop_editor(custom_id)))
	column.add_child(_label("衍生/不可入池：可浏览，不可直接加入可购池" if not _pool_allowed(card) else ("已实现" if bool(card.get("supported", false)) else "待实现：启用会阻止开局"), 15, MUTED if not _pool_allowed(card) else (TEAL if bool(card.get("supported", false)) else RED), true))
	column.add_child(_label(str(card.get("text", "")), 17, TEXT, true))
	var scope_flags: Variant=CurrentScope.manifest().get("dependency_flags",{}).get(custom_id,[])
	if not scope_flags.is_empty(): column.add_child(_label("范围依赖待处理（未删除该成员）："+JSON.stringify(scope_flags),12,GOLD,true))
	if card.has("conditional_support"):
		column.add_child(_label("条件支持：" + _conditional_support_reason(card), 13, RED, true))
	if card.has("coverage_blocker"):
		column.add_child(_label("当前限制：" + str(card.coverage_blocker), 13, RED, true))
	if pool_kind == "prize" and catalog.native_prize_registry.has(custom_id):
		column.add_child(_label("奖品等级 %s · 原卡牌分类：%s · 来源标签1735" % [catalog.native_prize_registry[custom_id].prize_tier, _kind_name(str(card.get("kind", "")))], 14, TEAL, true))
	elif str(card.get("kind", "")) == "minion":
		column.add_child(_label("来源星级 %s · 攻击 %s · 生命 %s\n%s" % [card.get("tier", "?"), card.get("attack", "?"), card.get("health", "?"), _tribes(card.get("tribes", []))], 14, TEAL, true))
	column.add_child(_label("数据中的卡牌说明不代表所有效果均已实现。历史卡池使用当前记录数值。", 12, MUTED, true))
	var source = str(card.get("source_url", card.get("source", "")))
	if source.begins_with("https://"):
		var source_label = _label("来源：" + source, 11, MUTED, true)
		column.add_child(source_label)
	dialog.confirmed.connect(dialog.queue_free)
	dialog.canceled.connect(dialog.queue_free)
	dialog.popup_centered()

func _dismiss_dialog() -> void:
	if is_instance_valid(active_dialog):
		active_dialog.hide()
		active_dialog.queue_free()
	active_dialog = null

func _pool_allowed(card: Dictionary, for_kind: String = "") -> bool:
	if card.is_empty() or catalog.get_card(str(card.get("id", ""))).is_empty():
		return false
	var kind: String = pool_kind if for_kind.is_empty() else for_kind
	if not CurrentScope.allows_pool(kind,str(card.get("id","")),catalog): return false
	if kind in CurrentScope.MAIN: return true
	if bool(card.get("is_golden", false)): return false
	if kind == "prize":
		return catalog.native_prize_registry.has(str(card.get("id", "")))
	if str(card.get("id", "")) == "129427": return false
	if str(card.get("kind", "")) not in ["minion", "spell"]:
		return true
	return bool(card.get("pool_supported", false)) or not _custom_shop_entry(str(card.get("id", ""))).is_empty()

func _source_number(value: Variant) -> String:
	return "未提供" if value == null else str(value)

func _spell_category_label(unit: Dictionary) -> String:
	var source: Dictionary = catalog.get_card(str(unit.get("card_id",unit.get("id",""))))
	if GameScript.Mechanisms.is_tavern_spell_card(source): return "酒馆法术"
	if "暗月奖品" in source.get("mechanisms",[]): return "暗月奖品"
	return str(source.get("category","法术"))

func _custom_shop_entry(id: String) -> Dictionary:
	var overrides: Variant = room.data.get("shop_overrides", {})
	if not overrides is Dictionary or not overrides.has(id):
		return {}
	if not CustomShop.entry_error(overrides[id]).is_empty() or not CustomShop.source_error(catalog, id).is_empty():
		return {}
	return overrides[id]

func _custom_shop_summary(id: String) -> String:
	var entry = _custom_shop_entry(id)
	if entry.is_empty():
		return ""
	return "sandbox 自定义：★%s · 基础价格 %s 金 · 共享库存 %s 份（非官方数值）" % [int(entry.tier), int(entry.cost), int(entry.copies)]

func _source_shop_summary(card: Dictionary) -> String:
	var ordinary = bool(card.get("pool_supported", false)) and not bool(card.get("is_golden", false))
	var tier: int = int(card.get("tier", 0) if card.get("tier") != null else 0)
	var copies = "无普通商店库存"
	if ordinary and tier >= 1 and tier <= 6:
		copies = "%s 份" % (GameScript.POOL_COUNTS[tier] if card.get("kind") == "minion" else GameScript.SPELL_POOL_COUNTS[tier])
	var price = "3 金（普通随从基础购买价）" if card.get("kind") == "minion" else _source_number(card.get("cost")) + " 金"
	return "来源分类：%s · 来源星级/档次：%s\n来源记录费用：%s · 普通基础购买价：%s\n普通共享库存：%s · 普通入池：%s" % [card.get("category", _kind_name(str(card.get("kind", "")))), _source_number(card.get("tier")), _source_number(card.get("cost")), price, copies, "允许" if ordinary else "不允许"]

func _show_custom_shop_editor(id: String) -> void:
	if not CurrentScope.allows_pool(str(catalog.get_card(id).get("kind","")),id,catalog):
		_notify("衍生物或范围外资料不能加入主酒馆池；原生成链与来源定义保留。",true)
		return
	_dismiss_dialog()
	var card: Dictionary = catalog.get_card(id)
	var dialog = AcceptDialog.new()
	active_dialog = dialog
	dialog.name = "CustomShopDialog"
	dialog.title = "自定义入店 · sandbox"
	dialog.ok_button_text = "取消 / 关闭"
	add_child(dialog)
	var body = _column(12)
	dialog.add_child(body)
	var scroller = ScrollContainer.new()
	scroller.custom_minimum_size = Vector2(680, 440)
	scroller.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroller.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	body.add_child(scroller)
	var column = _column(12)
	column.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroller.add_child(column)
	column.add_child(_label(str(card.get("name", id)), 22, GOLD, true))
	column.add_child(_label(id, 12, MUTED, true))
	column.add_child(_label(_source_shop_summary(card), 13, MUTED, true))
	column.add_child(_label("这是显式 sandbox 规则，不代表官方或历史数值。仅更改入店星级、基础购买价及共享库存；来源攻击、生命、效果与卡牌分类不变。本房间同一卡牌的购买、生成、战斗召唤及金色版统一使用自定义星级（影响战斗伤害），金色仍只能通过三连获取。英雄/机制固定价格及折扣规则继续生效。", 13, GOLD, true))
	column.add_child(_label("不能绕过未实现效果、缺失数值、单打限制或条件支持；不会自动修改机器人数量。", 13, RED, true))
	if card.has("conditional_support"):
		column.add_child(_label("条件支持：" + _conditional_support_reason(card), 13, RED, true))
	var source_issue: String = CustomShop.source_error(catalog, id)
	var original_tier = int(card.get("tier", 1) if card.get("tier") != null else 1)
	var defaults = {"tier": clampi(original_tier, 1, 6), "cost": 3 if card.get("kind") == "minion" else int(card.get("cost", 0) if card.get("cost") != null else 0), "copies": 1}
	if bool(card.get("pool_supported", false)) and original_tier >= 1 and original_tier <= 6:
		defaults.copies = GameScript.POOL_COUNTS[original_tier] if card.get("kind") == "minion" else GameScript.SPELL_POOL_COUNTS[original_tier]
	var current = _custom_shop_entry(id)
	if not current.is_empty():
		defaults = current
	else:
		column.add_child(_label("下方为待确认的 sandbox 参数；只有点击应用才会保存。不可普通入池条目的库存初始为 1，请自行设定。", 12, MUTED, true))
	var fields = _row(18)
	var inputs: Dictionary = {}
	for field in ["tier", "cost", "copies"]:
		var field_column = _column(6)
		field_column.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		field_column.add_child(_label({"tier": "自定义星级（1–6）", "cost": "基础价格（0–99 金）", "copies": "共享库存（1–99 份）"}[field], 14, TEXT))
		var input = SpinBox.new()
		input.name = {"tier": "CustomShopTier", "cost": "CustomShopCost", "copies": "CustomShopCopies"}[field]
		input.min_value = 0 if field == "cost" else 1
		input.max_value = 6 if field == "tier" else 99
		input.step = 1
		input.value = defaults[field]
		input.editable = source_issue.is_empty()
		input.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		field_column.add_child(input)
		inputs[field] = input
		fields.add_child(field_column)
	column.add_child(fields)
	var add_to_pool = CheckBox.new()
	add_to_pool.name = "CustomShopAddToPool"
	add_to_pool.text = "同时将此卡加入对应卡池（只更改这个 ID）"
	add_to_pool.button_pressed = true
	add_to_pool.disabled = not source_issue.is_empty()
	column.add_child(add_to_pool)
	var issue_label = _label(source_issue, 13, RED, true)
	issue_label.name = "CustomShopError"
	column.add_child(issue_label)
	var actions = _row(12)
	var apply_button = _button("应用并加入卡池", func():
		var entry: Dictionary = {}
		for field in inputs:
			inputs[field].apply()
			entry[field] = int(inputs[field].value)
		var issue = _apply_custom_shop(id, entry, add_to_pool.button_pressed)
		if issue.is_empty():
			_dismiss_dialog()
		else:
			issue_label.text = issue
	, true)
	apply_button.name = "ApplyCustomShop"
	apply_button.disabled = not source_issue.is_empty()
	add_to_pool.toggled.connect(func(value: bool): apply_button.text = "应用并加入卡池" if value else "仅应用参数")
	actions.add_child(apply_button)
	var remove_button = _button("移除自定义参数", func(): _remove_custom_shop(id); _dismiss_dialog())
	remove_button.name = "RemoveCustomShop"
	remove_button.disabled = not room.data.get("shop_overrides", {}).has(id)
	actions.add_child(remove_button)
	body.add_child(actions)
	var footer_note = _label("移除参数会恢复普通入池规则并保留已选卡池。原本不可入池的已选项会阻止开局，可在列表中单独取消勾选。", 12, MUTED, true)
	footer_note.custom_minimum_size.x = 680
	footer_note.size.x = 680
	body.add_child(footer_note)
	dialog.confirmed.connect(dialog.queue_free)
	dialog.canceled.connect(dialog.queue_free)
	dialog.popup_centered(Vector2i(720, 620))

func _apply_custom_shop(id: String, entry: Variant, add_to_pool: bool = true) -> String:
	if not CurrentScope.allows_pool(str(catalog.get_card(id).get("kind","")),id,catalog): return "自定义入店不能绕过当前成员范围。"
	var issue: String = CustomShop.entry_error(entry)
	if issue.is_empty():
		issue = CustomShop.source_error(catalog, id)
	if not issue.is_empty():
		return issue
	var candidate: Dictionary = room.data.duplicate(true)
	var overrides: Dictionary = candidate.get("shop_overrides", {}).duplicate(true)
	overrides[id] = {"tier": int(entry.tier), "cost": int(entry.cost), "copies": int(entry.copies)}
	candidate["shop_overrides"] = overrides
	var errors: Array = CustomShop.validate(candidate, catalog)
	if not errors.is_empty():
		return "；".join(errors)
	if add_to_pool:
		var key = str(POOL_KEYS[str(catalog.get_card(id).kind)])
		var values: Array = candidate.get(key, []).duplicate()
		if not values.has(id):
			values.append(id)
		candidate[key] = values
		var disabled: Array = candidate.get("disabled_ids", []).duplicate()
		disabled.erase(id)
		candidate["disabled_ids"] = disabled
	room.data = candidate
	_refresh_pool_list()
	_refresh_room_summary()
	_notify("已保存「%s」的 sandbox 入店参数。%s；开局仍需通过全部房间校验。" % [catalog.get_card(id).get("name", id), "已加入对应卡池" if add_to_pool else "卡池选择未改变"])
	return ""

func _remove_custom_shop(id: String) -> bool:
	var overrides: Dictionary = room.data.get("shop_overrides", {}).duplicate(true)
	if not overrides.has(id):
		return false
	overrides.erase(id)
	room.data["shop_overrides"] = overrides
	_refresh_pool_list()
	_refresh_room_summary()
	_notify("已移除「%s」的 sandbox 参数并恢复普通入池规则。所有已选条目保持不变；如出现入池错误，请单独取消该卡的勾选。" % catalog.get_card(id).get("name", id))
	return true


func _restore_scope_kind() -> void:
	if pool_kind not in CurrentScope.MAIN:
		_notify("额外机制保留各自选择入口，请逐项选择；不会自动同时启用全部机制。")
		return
	var ids: Array=CurrentScope.main_ids(pool_kind)
	room.data[POOL_KEYS[pool_kind]]=ids.duplicate()
	for id in ids: room.data.disabled_ids.erase(id)
	_refresh_pool_list()
	_refresh_room_summary()
	_populate_hero_picker()
	_notify("已恢复本类完整当前成员；未实现/依赖冲突仍明确保留并阻止不完整开局。")

func _show_scope_extra(group: String) -> void:
	var records: Array=[]
	for card in catalog.list_cards("","",false):
		if group in CurrentScope.extra_groups(card): records.append(card)
	_show_scope_reference(group+" · 保留机制与依赖资料",records,"这些身份由原机制入口取得，不会因此加入主酒馆池。伙伴、时空扭曲、黑暗之赐的专属获取规则不变；待实现/规则未知仍保留原限制。",group)

func _show_scope_optional() -> void:
	var records: Array=[]
	var optional: Dictionary=CurrentScope.manifest().get("optional",{})
	for id in optional.get("naga_hero_ids",[])+optional.get("naga_spell_ids",[]):
		var card: Dictionary=catalog.get_card(str(id))
		records.append(card if not card.is_empty() else {"id":id,"name":id,"kind":"dependency","text":"本地定义待接入"})
	_show_scope_reference("娜迦额外英雄/法术 · 非默认",records,"用户指定的娜迦随从已叠加；这些英雄/法术不是官方当前主池成员，未默认启用，也未改写其效果。")

func _show_scope_reference(title: String, records: Array, note: String, group: String = "") -> void:
	_dismiss_dialog()
	var dialog = AcceptDialog.new()
	active_dialog=dialog
	dialog.title=title
	dialog.ok_button_text="关闭"
	add_child(dialog)
	var scroll=ScrollContainer.new()
	scroll.custom_minimum_size=Vector2(720,460)
	dialog.add_child(scroll)
	var column=_column(8)
	column.size_flags_horizontal=Control.SIZE_EXPAND_FILL
	scroll.add_child(column)
	column.add_child(_label(note,13,GOLD,true))
	if not group.is_empty(): _build_scope_config_routes(column,group)
	for entry in records:
		var card: Dictionary=entry
		column.add_child(_button(str(card.get("name",card.get("id","")))+" · "+str(card.get("id","")),func(): _show_card_details(card)))
	dialog.confirmed.connect(dialog.queue_free)
	dialog.canceled.connect(dialog.queue_free)
	dialog.popup_centered()

func _build_scope_config_routes(column: VBoxContainer, group: String) -> void:
	# These are navigation links, not mechanism enablement or generated offers.
	match group:
		"畸变":
			column.add_child(_button("前往畸变配置",func(): _navigate_scope_pool("anomaly")))
		"饰品":
			column.add_child(_button("前往饰品配置",func(): _navigate_scope_pool("trinket")))
		"任务":
			column.add_child(_button("前往任务配置",func(): _navigate_scope_pool("quest")))
			column.add_child(_button("前往任务奖励依赖配置",func(): _navigate_scope_pool("reward")))
		"伙伴":
			column.add_child(_button("定位已有伙伴按钮设置",_navigate_scope_buddies))
		"黑暗之赐":
			for id in ["BG36_HERO_101","BG36_HERO_105"]:
				_add_scope_identity_route(column,"hero",id,"英雄配置")
			_add_scope_identity_route(column,"anomaly","BG36_Anomaly_002","畸变资料与配置（完整流程未启用）")
			column.add_child(_label("这里只定位原有取得来源，不建立黑暗之赐全局开关，不改变英雄或畸变的原有准入限制。",12,MUTED,true))
		"时空扭曲":
			var unavailable = _button("完整时空扭曲入口尚未接通",func(): pass)
			unavailable.disabled = true
			unavailable.tooltip_text = "现有独立交易组件不等于完整酒馆控制器；进入、报价与退出规则留空时不能启用。"
			column.add_child(unavailable)
			column.add_child(_label("目前仅有独立组件；没有可安全启用的完整控制器。不会用普通发现或假报价替代。",12,MUTED,true))

func _add_scope_identity_route(column: VBoxContainer, kind: String, id: String, suffix: String) -> void:
	var card: Dictionary = catalog.get_card(id)
	var button = _button(str(card.get("name",id))+" · "+suffix,func(): _navigate_scope_pool(kind,id))
	button.disabled = not CurrentScope.allows_pool(kind,id,catalog)
	button.tooltip_text = "仅在原配置页定位此身份；不会勾选、切换英雄或解锁未实现效果。" if not button.disabled else "当前范围未开放此身份；保留资料，不修改成员资格。"
	column.add_child(button)

func _navigate_scope_pool(kind: String, identity: String = "") -> void:
	if screen != "room" or kind not in KINDS or not is_instance_valid(pool_search_field): return
	if not identity.is_empty() and not CurrentScope.allows_pool(kind,identity,catalog):
		_notify("该身份不属于当前可编辑范围；未改变配置。",true)
		return
	_dismiss_dialog()
	# Remove display-only filters so a held/unselected identity is not hidden.
	# The actual enabled/disabled IDs and all source gates stay untouched.
	pool_query = identity
	pool_supported_only = false
	pool_selected_only = false
	pool_search_field.set_block_signals(true)
	pool_search_field.text = identity
	pool_search_field.set_block_signals(false)
	if is_instance_valid(pool_supported_filter): pool_supported_filter.set_pressed_no_signal(false)
	if is_instance_valid(pool_selected_filter): pool_selected_filter.set_pressed_no_signal(false)
	_change_pool_kind(kind)
	pool_search_field.grab_focus()
	_notify("已定位"+_kind_name(kind)+"配置；只改变显示筛选，未修改卡池或启用任何机制。")

func _navigate_scope_buddies() -> void:
	if screen != "room" or not is_instance_valid(native_buddy_checkbox) or not is_instance_valid(room_settings_scroll): return
	_dismiss_dialog()
	room_settings_scroll.ensure_control_visible(native_buddy_checkbox)
	native_buddy_checkbox.grab_focus()
	_notify("已定位原有伙伴设置；开关与英雄池保持不变，请自行选择。")
