extends RefCounted
## Read-only presentation of this instance's implemented combat effect, not a rule claim.
const Host=preload("res://core/ultraviolet_host.gd")
static func note(unit: Dictionary,zone: String) -> String:
 if zone not in ["board","hand","shop"] or unit.get("card_id") not in Host.IDS:return ""
 var issue: String=Host.unit_error(unit)
 if not issue.is_empty():return "极紫外成长数据不可用："+issue
 var plays: int=int(unit.get(Host.GROWTH,{}).get("plays",0))
 var amount: int=Host.buff_amount(unit,unit.effects[0])
 var status: String="失效" if not Host.Gains.active(unit) else ("待上场" if zone!="board" else "战斗开始")
 var result: String="%s：+%s/+%s · 已成长%s次"%[status,amount,amount,plays]
 result+="\n仅在战斗开始时赋予其他友方元素，不改变本体招募属性。"
 if not Host.Gains.active(unit):result+="\n当前效果失效，不会触发；以上为该实例保留的数值。"
 elif zone!="board":result+="\n当前不在战队，不会触发；以上为该实例保留的数值。"
 return result
