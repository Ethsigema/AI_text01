extends SceneTree
var game
var cat
var checks=0
var view
const Info=preload("res://ui/ultraviolet_growth_info.gd")
func check(ok: bool,label: String) -> bool:
 checks+=1
 print("PASS " if ok else "FAIL ",label)
 if not ok:
  if game!=null: print("EVENTS ",JSON.stringify(game.events.slice(-4)))
  quit(1)
 return ok
func setup(id: String) -> bool:
 game=load("res://core/game.gd").new()
 var room=load("res://core/room_config.gd").new();room.reset(cat)
 room.data.enabled_minions=["BG31_810","BGS_119","BG31_330"]
 room.data.enabled_spells=["BG28_810"]
 room.data.selected_hero="TB_BaconShop_HERO_01";room.data.enabled_heroes=["TB_BaconShop_HERO_01"];room.data.bot_count=1;room.data.seed=20261114
 for key in ["enabled_anomalies","enabled_quests","enabled_rewards","enabled_trinkets"]: room.data[key]=[]
 var result=game.start(room.data,cat)
 if not check(result.get("ok",false),"real_room"): print(result);return false
 var p=game.state.players[0]
 var source=game._unit(cat.get_card(id));p.board.append(source);p.gold=10
 return check(not source.is_empty(),"source_factory_"+id)
func one(id: String) -> bool:
 if not setup(id):return false
 view.game=game
 var p=game.state.players[0];var source=p.board[0];var amount=8 if id.ends_with("_G") else 4
 for i in range(2):
  var child=game._unit(cat.get_card("BGS_119"));game._add_hand(p,child)
  if i==0:
   var unchanged=p.duplicate(true)
   var rejected=game._magnetize(p,0,0)
   if not check(not rejected.get("ok",true) and p==unchanged,"elemental_magnetize_held_before_mutation"):return false
  var result=game.apply_command(0,{"type":"play","index":0})
  if not check(result.get("ok",false),"actual_elemental_play_"+str(i)):print(result);return false
  if not check(source.get(game.Ultraviolet.GROWTH,{}).get("plays")==i+1,"persistent_growth_count"):return false
  if not check(game.Ultraviolet.buff_amount(source,source.effects[0])==amount*(i+2),"scaled_combat_amount"):return false
  if not check(source.attack==cat.get_card(id).attack and source.health==cat.get_card(id).health,"does_not_buff_recruit_body"):return false
 var before=source.duplicate(true)
 var note: String=Info.note(source,"board")
 if not check(note.contains("+%s/+%s"%[amount*3,amount*3]) and note.contains("已成长2次"),"actual_growth_display_amount"):return false
 var button=view._unit_button(source,"查看",false,func():pass,"board")
 if not check(button.tooltip_text.contains(note) and button.find_child("UltravioletActualGrowth",true,false)!=null,"native_card_button_label_and_tooltip"):return false
 button.free()
 for zone in ["hand","shop"]:
  button=view._unit_button(source,"查看",false,func():pass,"",zone)
  if not check(button.tooltip_text.contains("当前不在战队") and str(button.find_child("UltravioletActualGrowth",true,false).text).begins_with("待上场"),"native_"+zone+"_button_status"):return false
  button.free()
 if not check(source==before,"display_does_not_mutate_instance"):return false
 if not check(Info.note(source,"hand").begins_with("待上场") and Info.note(source,"hand").contains("当前不在战队") and Info.note(source,"shop").contains("当前不在战队"),"nonboard_display_not_trigger_claim"):return false
 var inactive=source.duplicate(true);inactive.silenced=true
 if not check(Info.note(inactive,"board").begins_with("失效") and Info.note(inactive,"board").contains("当前效果失效"),"silenced_display_caveat"):return false
 inactive=source.duplicate(true);inactive.abilities_disabled=true
 if not check(Info.note(inactive,"board").begins_with("失效") and Info.note(inactive,"board").contains("当前效果失效"),"disabled_display_caveat"):return false
 var bad=source.duplicate(true);bad[game.Ultraviolet.GROWTH].uid="wrong"
 if not check(Info.note(bad,"board").begins_with("极紫外成长数据不可用"),"invalid_growth_not_displayed_as_valid"):return false
 if not check(Info.note(source,"unknown").is_empty() and Info.note({},"board").is_empty(),"unknown_zone_and_other_cards_ignored"):return false
 var dummy=game._unit(cat.get_card("BG31_330"));game._add_hand(p,dummy)
 var played=game.apply_command(0,{"type":"play","index":0})
 if not check(played.get("ok",false),"non_elemental_play"):print(played);return false
 if not check(source==before,"non_elemental_does_not_grow"):return false
 var snapshot=p.duplicate(true)
 var duplicate=game.Ultraviolet.on_play(game,p,source,p.board[1])
 if not check(duplicate=="ultraviolet_actual_hand_play_context_required" and p==snapshot,"unissued_dispatch_rejected_read_only"):return false
 var copied=source.duplicate(true);copied.uid="different_fixture_uid"
 if not check(game.Ultraviolet.unit_error(copied)=="ultraviolet_changed_growth_identity","copied_growth_not_silently_rebound"):return false
 var combat=game.Combat.new()
 var battle=combat.resolve(p.board,[game._unit(cat.get_card("BGS_119"))],20261114)
 if not check(str(battle.get("error","")).is_empty(),"real_combat_resolve"):print(battle.get("error"));return false
 var buffs=battle.get("log",[]).filter(func(e):return e.get("event")=="ultraviolet_base_buff")
 if not check(buffs.size()==1,"combat_one_trigger"): print(battle.get("log",[]).slice(0,6));return false
 if not check(buffs[0].attack==amount*3 and buffs[0].health==amount*3 and buffs[0].targets.size()==2 and source.uid not in buffs[0].targets,"actual_combat_payoff_only_other_elementals"):return false
 if not check(source==before,"combat_only_growth_payoff_preserves_recruit_source"):return false
 var wire=JSON.parse_string(JSON.stringify(source))
 if not check(game.Ultraviolet.unit_error(wire).is_empty(),"growth_survives_json_number_representation"):return false
 var held=game.TripleStats.temporary_floor_error([source],cat.get_card("BG31_810"),cat.get_card("BG31_810_G"))
 if not check(held=="ultraviolet_growth_triple_inheritance_unverified","unverified_triple_preserves_instead_of_losing_growth"):return false
 var second=game._unit(cat.get_card(id));game._add_hand(p,second)
 played=game.apply_command(0,{"type":"play","index":0})
 if not check(played.get("ok",false),"play_another_ascendant"):print(played);return false
 if not check(not second.has(game.Ultraviolet.GROWTH) and source[game.Ultraviolet.GROWTH].plays==3,"own_play_excluded_prior_source_grows"):return false
 var wild=game._unit(cat.get_card(game.Surprise.Sources.IDS[0]))
 var parents=[source,second,wild];var parents_before=parents.duplicate(true)
 var wildcard=game.Surprise.prepare(game,p,"BG31_810",parents)
 if not check(not wildcard.ok and wildcard.error=="ultraviolet_growth_triple_inheritance_unverified" and parents==parents_before,"wildcard_triple_also_held_read_only"):return false
 source.silenced=true;second.silenced=true
 var counts=source[game.Ultraviolet.GROWTH].plays
 var vanilla=game._unit(cat.get_card("BGS_119"));game._add_hand(p,vanilla)
 played=game.apply_command(0,{"type":"play","index":0})
 if not check(played.get("ok",false),"elemental_with_silenced_sources"):print(played);return false
 if not check(source[game.Ultraviolet.GROWTH].plays==counts and not second.has(game.Ultraviolet.GROWTH),"silenced_sources_do_not_grow"):return false
 source.silenced=false;second.silenced=false
 # Explicit numeric-bound fixtures: not claims of a million natural plays.
 for listener in [source,second]:
  listener[game.Ultraviolet.GROWTH]={"uid":listener.uid,"plays":game.Ultraviolet.MAX_PLAYS-1,"sequence":game.state.command_sequence-1}
 var last=game._unit(cat.get_card("BGS_119"));game._add_hand(p,last)
 played=game.apply_command(0,{"type":"play","index":0})
 if not check(played.get("ok",false),"two_sources_last_bounded_growth"):print(played);return false
 if not check(source[game.Ultraviolet.GROWTH].plays==game.Ultraviolet.MAX_PLAYS and second[game.Ultraviolet.GROWTH].plays==game.Ultraviolet.MAX_PLAYS,"sequential_sources_each_reach_bound"):return false
 var bound_snapshot=p.duplicate(true)
 if not check(game.Ultraviolet.play_error(game,p,last)=="ultraviolet_growth_capacity_exceeded" and p==bound_snapshot,"over_bound_preflight_is_read_only"):return false
 return true
func _initialize():
 cat=load("res://core/catalog.gd").new();cat.load_catalog()
 if not check(cat.load_errors.is_empty(),"catalog"):print(cat.load_errors);return
 view=load("res://ui/main.gd").new();view.catalog=cat
 for id in ["BG31_810","BG31_810_G"]:
  if not one(id):return
 view.free()
 print("ULTRAVIOLET_DISPLAY_PASS checks=",checks)
 quit(0)
