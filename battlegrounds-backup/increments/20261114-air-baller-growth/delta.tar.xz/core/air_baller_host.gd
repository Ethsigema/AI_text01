extends RefCounted
const Normal=preload("res://core/patch_3702_air_baller_sources.gd")
const Golden=preload("res://core/patch_3702_air_baller_golden_sources.gd")
const Gains=preload("res://core/attack_gain_listeners.gd")
const IDS=["BG36_181","BG36_181_G"]
const CHAIN="air_baller_sale_chain_v1"
const MAX_SALES: int=1000000
const TYPE="on_sell_air_baller_verified_base"
static func program(id: String) -> Array:
	return [{"type":TYPE,"source_id":id,"attack":4 if id==IDS[1] else 2,"health":4 if id==IDS[1] else 2}] if id in IDS else []
static func unit_error(unit: Dictionary) -> String:
	var id: String=str(unit.get("card_id",unit.get("id","")))
	var marker: bool=unit.get("effects",[]).any(func(e):return e.get("type")==TYPE)
	if id not in IDS: return "air_baller_unbound_program" if marker else ""
	return "" if Normal.same(unit.get("effects"),program(id)) else "air_baller_changed_program"
# Only a complete consecutive Air-only history is supported in this slice.
# Missing old history, any interleaved sale, and other Baller families remain held.
static func history_error(p: Dictionary) -> String:
	var sold: Variant=p.get("stats",{}).get("sold",-1)
	if not (sold is int or sold is float) or sold is bool or not is_finite(float(sold)) or sold!=floor(sold) or sold<0 or sold>=MAX_SALES: return "air_baller_invalid_or_full_sale_history"
	if not p.has(CHAIN): return "" if sold==0 else "air_baller_growth_after_prior_sale_unverified"
	var h: Variant=p[CHAIN]
	if not h is Dictionary or h.size()!=2 or not Normal.same(h.get("owner"),p.get("id")) or not Normal.same(h.get("sales"),sold) or sold<1: return "air_baller_incomplete_or_changed_sale_history"
	return ""
static func amount(p: Dictionary,u: Dictionary) -> int:
	return int(program(u.card_id)[0].attack)*(1+int(p.stats.sold))
static func sale_error(engine,p: Dictionary,u: Dictionary) -> String:
	if u.get("card_id") not in IDS: return ""
	var issue: String=unit_error(u)
	var canonical=engine.catalog.source_catalog if engine.catalog.source_catalog!=null else engine.catalog
	if issue.is_empty(): issue=Normal.source_error(canonical.get_card(u.card_id)) if u.card_id==IDS[0] else Golden.source_error(canonical.get_card(u.card_id))
	if not issue.is_empty(): return issue
	issue=history_error(p)
	if not issue.is_empty(): return issue
	if not Gains.active(u) or not p.board.any(func(v):return is_same(v,u)): return "air_baller_actual_active_source_required"
	if not p.get("trinkets",[]).is_empty() or not p.get("reward_active",[]).is_empty(): return "air_baller_owned_observers_partial"
	for v in p.board:
		for effect in v.get("effects",[]):
			var type: String=str(effect.get("type",""))
			if type=="timewarp_swirler_giver_aura" and int(p.stats.sold)>0: return "air_baller_grown_swirler_bridge_unverified"
			if type not in [TYPE,"timewarp_swirler_giver_aura","on_sell_fire_baller_verified_base","on_sell_snow_baller_verified_base"] and not type.begins_with("battlecry_") and not type.begins_with("deathrattle_"): return "air_baller_competing_board_observer_partial:"+type
		if not is_same(v,u) and not engine.Combat.StartCombatEffects.buff_fits(v,amount(p,u),amount(p,u)): return "air_baller_buff_overflow"
	return ""
static func prepare(engine,p: Dictionary,u: Dictionary) -> Dictionary:
	if u.get("card_id") not in IDS: return {"ok":true,"active":false}
	var issue: String=sale_error(engine,p,u)
	if not issue.is_empty(): return {"ok":false,"error":issue}
	return {"ok":true,"active":true,"owner":p,"source":u,"sequence":engine.state.command_sequence,"round":engine.state.round,"targets":p.board.filter(func(v):return not is_same(v,u)).map(func(v):return v.uid),"used":false,"prior_sales":p.stats.sold,"amount":amount(p,u)}
static func commit(engine,p: Dictionary,u: Dictionary,ticket: Dictionary) -> String:
	if not ticket.get("active",false): return "air_baller_missing_sale_ticket"
	if not is_same(engine._air_baller_context,ticket) or ticket.used or not is_same(ticket.owner,p) or not is_same(ticket.source,u) or ticket.sequence!=engine.state.command_sequence or ticket.round!=engine.state.round: return "air_baller_stale_sale_ticket"
	if not history_error(p).is_empty() or not Normal.same(p.stats.sold,ticket.prior_sales) or p.board.any(func(v):return v.uid==u.uid): return "air_baller_actual_removal_required"
	if not Normal.same(p.board.map(func(v):return v.uid),ticket.targets): return "air_baller_changed_sale_recipients"
	var payoff: int=amount(p,u)
	if payoff!=ticket.amount: return "air_baller_changed_sale_payoff"
	ticket.used=true
	for target in p.board:
		engine._buff(target,payoff,payoff,u)
		if engine.state.phase=="error": return "air_baller_actual_buff_failed"
		engine._log("air_baller_sale_growth_buff",{"player":p.id,"source_id":u.card_id,"source_uid":u.uid,"target_uid":target.uid,"attack":payoff,"health":payoff})
	p[CHAIN]={"owner":p.id,"sales":int(p.stats.sold)+1}
	return ""
static func legal_actions(engine,player_id: int,commands: Array) -> Array:
	if engine.state.is_empty() or player_id<0 or player_id>=engine.state.players.size(): return commands
	var p: Dictionary=engine.state.players[player_id]
	return commands.filter(func(c):
		if c.get("type")!="sell": return true
		var index: int=int(c.get("index",-1))
		return index<0 or index>=p.board.size() or sale_error(engine,p,p.board[index]).is_empty()
	)
