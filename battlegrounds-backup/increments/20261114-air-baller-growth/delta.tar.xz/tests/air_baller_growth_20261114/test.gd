extends SceneTree
var game
var cat
var checks=0
func check(ok: bool,label: String) -> bool:
 checks+=1
 print("PASS " if ok else "FAIL ",label)
 if not ok:
  if game!=null: print("EVENTS ",JSON.stringify(game.events.slice(-4)))
  quit(1)
 return ok
func setup() -> bool:
 game=load("res://core/game.gd").new()
 var room=load("res://core/room_config.gd").new();room.reset(cat)
 room.data.enabled_minions=["BG36_181","BGS_119","BG31_330"]
 room.data.enabled_spells=["BG28_810"]
 room.data.selected_hero="TB_BaconShop_HERO_01";room.data.enabled_heroes=["TB_BaconShop_HERO_01"];room.data.bot_count=1;room.data.seed=20261114
 for key in ["enabled_anomalies","enabled_quests","enabled_rewards","enabled_trinkets"]: room.data[key]=[]
 var result=game.start(room.data,cat)
 if not check(result.get("ok",false),"real_room"):print(result);return false
 return true
func chain(ids: Array) -> bool:
 if not setup():return false
 var p=game.state.players[0]
 var target=game._unit(cat.get_card("BGS_119"));p.board.append(target)
 var a=target.attack;var h=target.health;var total=0
 for i in range(ids.size()):
  var source=game._unit(cat.get_card(ids[i]));p.board.append(source)
  var before=p.duplicate(true)
  if not check(game.AirBaller.sale_error(game,p,source).is_empty() and p==before,"read_only_preflight_"+str(i)):return false
  var actions=game.AirBaller.legal_actions(game,0,[{"type":"sell","index":1}])
  if not check(actions.size()==1,"legal_action_present"):return false
  var gold=p.gold
  var result=game.apply_command(0,{"type":"sell","index":1})
  if not check(result.get("ok",false),"actual_sale_"+str(i)):print(result);return false
  var amount=(4 if ids[i].ends_with("_G") else 2)*(i+1);total+=amount
  if not check(target.attack==a+total and target.health==h+total,"scaled_real_buff_"+str(amount)):return false
  if not check(p.stats.sold==i+1 and p[game.AirBaller.CHAIN].sales==i+1,"actual_sale_history"):return false
  if not check(p.board.size()==1 and p.board[0].uid==target.uid and p.gold==gold+1,"sale_removal_and_one_gold"):return false
  if not check(not game.state.players[1].has(game.AirBaller.CHAIN),"opponent_history_unchanged"):return false
 var next=game._unit(cat.get_card("BG36_181"));p.board.append(next)
 var copy=p.duplicate(true);copy[game.AirBaller.CHAIN].owner=1
 if not check(not game.AirBaller.history_error(copy).is_empty(),"wrong_owner_held"):return false
 copy=p.duplicate(true);copy.erase(game.AirBaller.CHAIN)
 if not check(not game.AirBaller.history_error(copy).is_empty(),"missing_old_history_held"):return false
 copy=p.duplicate(true);copy[game.AirBaller.CHAIN].sales=true
 if not check(not game.AirBaller.history_error(copy).is_empty(),"boolean_history_held"):return false
 for bad in [-1,0.5,true,game.AirBaller.MAX_SALES]:
  copy=p.duplicate(true);copy.stats.sold=bad
  if not check(not game.AirBaller.history_error(copy).is_empty(),"invalid_or_full_history_"+str(bad)):return false
 var saved_effects=target.effects.duplicate(true)
 target.effects=[{"type":"timewarp_swirler_giver_aura"}]
 var held_snapshot=p.duplicate(true)
 if not check(game.AirBaller.sale_error(game,p,next)=="air_baller_grown_swirler_bridge_unverified" and p==held_snapshot,"grown_swirler_bridge_held_before_removal"):return false
 target.effects=saved_effects
 var old_attack=target.attack;target.attack=game.Combat.StartCombatEffects.MAX_STAT
 held_snapshot=p.duplicate(true)
 if not check(game.AirBaller.sale_error(game,p,next)=="air_baller_buff_overflow" and p==held_snapshot,"grown_buff_overflow_read_only"):return false
 target.attack=old_attack
 var wire=JSON.parse_string(JSON.stringify(p))
 if not check(game.AirBaller.history_error(wire).is_empty(),"json_numbers_preserve_history"):return false
 var source_snapshot=next.duplicate(true);var snapshot=p.duplicate(true)
 var result=game.AirBaller.commit(game,p,next,{"active":true})
 if not check(result=="air_baller_stale_sale_ticket" and p==snapshot and next==source_snapshot,"unissued_ticket_read_only"):return false
 # Real intervening ordinary sale breaks the bounded Air-only provenance chain.
 result=game.apply_command(0,{"type":"sell","index":0})
 if not check(result.get("ok",false),"interleaved_real_ordinary_sale"):print(result);return false
 snapshot=p.duplicate(true)
 if not check(game.AirBaller.sale_error(game,p,next)=="air_baller_incomplete_or_changed_sale_history" and p==snapshot,"unknown_interleaving_hold_before_mutation"):return false
 if not check(game.AirBaller.legal_actions(game,0,[{"type":"sell","index":0}]).is_empty(),"held_action_hidden"):return false
 return true
func empty_sale() -> bool:
 if not setup():return false
 var p=game.state.players[0];p.board.append(game._unit(cat.get_card("BG36_181")))
 var r=game.apply_command(0,{"type":"sell","index":0})
 if not check(r.get("ok",false) and p.board.is_empty() and p[game.AirBaller.CHAIN].sales==1,"empty_recipients_still_improve_future_air"):return false
 var first=game._unit(cat.get_card("BGS_119"));var second=game._unit(cat.get_card("BGS_119"))
 var a=first.attack;var h=first.health
 p.board.append(first);p.board.append(second);p.board.append(game._unit(cat.get_card("BG36_181")))
 r=game.apply_command(0,{"type":"sell","index":2})
 if not check(r.get("ok",false),"real_second_sale_multiple_recipients"):print(r);return false
 return check(first.attack==a+4 and second.attack==a+4 and first.health==h+4 and second.health==h+4,"both_survivors_receive_grown_payoff_once")
func _initialize():
 cat=load("res://core/catalog.gd").new();cat.load_catalog()
 if not check(cat.load_errors.is_empty(),"catalog"):print(cat.load_errors);return
 for ids in [["BG36_181","BG36_181","BG36_181"],["BG36_181_G","BG36_181_G","BG36_181_G"],["BG36_181_G","BG36_181","BG36_181_G"]]:
  if not chain(ids):return
 if not empty_sale():return
 print("AIR_BALLER_PASS checks=",checks)
 quit(0)
