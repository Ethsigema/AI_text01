extends SceneTree
const Host=preload("res://core/greater_baller_portrait.gd")
var cat
var game
var checks=0
var bone_id="BG28_300"
func check(ok:bool,label:String)->bool:
 checks+=1;print("PASS " if ok else "FAIL ",label)
 if not ok:quit(1)
 return ok
func _initialize():
 cat=load("res://core/catalog.gd").new();cat.load_catalog()
 if not check(cat.load_errors.is_empty(),"catalog"):print(cat.load_errors);return
 for id in ["BG28_300","BG28_300_G"]:
  bone_id=id
  for family in ["fire","snow"]:
   if not run_family(family):return
 print("PASS TOTAL ",checks);quit(0)
func run_family(family:String)->bool:
 game=load("res://core/game.gd").new()
 var room=load("res://core/room_config.gd").new();room.reset(cat)
 room.data.enabled_minions=["BGS_119","BG31_816","BG31_818"];room.data.enabled_spells=["BG28_810"];room.data.selected_hero="TB_BaconShop_HERO_01";room.data.enabled_heroes=["TB_BaconShop_HERO_01"];room.data.bot_count=1;room.data.seed=20261116
 for k in ["enabled_anomalies","enabled_quests","enabled_rewards","enabled_trinkets"]:room.data[k]=[]
 if not check(game.start(room.data,cat).get("ok",false),family+"_real_room"):return false
 var p=game.state.players[0];p.gold=10;p.board=[]
 var offer=cat.get_card(Host.ID).duplicate(true);offer.choice_kind="trinket";p.discover=[offer]
 var r=game.apply_command(0,{"type":"discover","index":0})
 if not check(r.get("ok",false),family+"_acquisition"):print(r);return false
 r=game.apply_command(0,{"type":"play","index":0})
 if not check(r.get("ok",false) and p.hand.size()==2,family+"_reward_spell"):print(r);return false
 var seller="BG31_816" if family=="fire" else "BG31_818"
 var other="BG31_818" if family=="fire" else "BG31_816"
 # Play only the chosen real reward; other family remains in hand.
 var chosen_index=0 if family=="fire" else 1
 r=game.apply_command(0,{"type":"play","index":chosen_index})
 if not check(r.get("ok",false),family+"_actual_child_play"):print(r);return false
 # Exact Bonehead then effect-free recipient are explicit factory fixtures.
 for n in range(2):
  p.hand.append(game._unit(cat.get_card(bone_id if n==0 else "BGS_119")))
  r=game.apply_command(0,{"type":"play","index":p.hand.size()-1})
  if not check(r.get("ok",false),family+"_ordinary_play"):print(r);return false
 var recipient=p.board[2];var attack=recipient.attack;var health=recipient.health;var gold=p.gold
 var progress=p.mechanism_state[Host.key()]
 r=game.apply_command(0,{"type":"sell","index":1})
 if not check(r.get("ok",false) and p.stats.sold==1 and p.gold==gold+1,family+"_actual_ordinary_sale"):print(r);return false
 if not check(p.board.size()==2 and recipient.attack==attack and recipient.health==health and p.mechanism_state[Host.key()]==progress,family+"_ordinary_does_not_buff_or_count"):return false
 var chain="fire_baller_sale_chain_v1" if family=="fire" else "snow_baller_sale_chain_v1"
 if not check(p.get(chain,{}).get("ordinary_sales")==1 and p[chain].sales==1,family+"_ordinary_history_certified"):return false
 r=game.apply_command(0,{"type":"sell","index":0})
 if not check(r.get("ok",false) and p.stats.sold==2 and p.gold==gold+2,family+"_first_baller_after_ordinary"):print(r);return false
 if not check(recipient.attack==attack+(1 if family=="fire" else 0) and recipient.health==health+(1 if family=="snow" else 0),family+"_ordinary_did_not_inflate_growth"):return false
 p.hand.append(game._unit(cat.get_card(seller)))
 r=game.apply_command(0,{"type":"play","index":p.hand.size()-1})
 if not check(r.get("ok",false),family+"_second_baller_play"):return false
 p.hand.append(game._unit(cat.get_card(bone_id)))
 r=game.apply_command(0,{"type":"play","index":p.hand.size()-1})
 if not check(r.get("ok",false),family+"_second_ordinary_play"):return false
 progress=p.mechanism_state[Host.key()]
 r=game.apply_command(0,{"type":"sell","index":2})
 if not check(r.get("ok",false) and p.stats.sold==3 and p[chain].ordinary_sales==2,family+"_second_ordinary_history"):print(r);return false
 r=game.apply_command(0,{"type":"sell","index":1})
 if not check(r.get("ok",false) and p.stats.sold==4 and p.gold==gold+4,family+"_second_baller_sale"):print(r);return false
 if not check(recipient.attack==attack+(3 if family=="fire" else 0) and recipient.health==health+(3 if family=="snow" else 0),family+"_same_family_second_growth"):return false
 if not check(p.mechanism_state[Host.key()]==progress and p.hand.size()==1 and p.hand[0].card_id==other,family+"_sales_leave_counter_and_other_hand_card"):return false
 # Mutation rejection must remain atomic despite the new exact exception.
 for field in ["effects","attachments","tribes","keywords"]:
  var invalid=game._unit(cat.get_card(bone_id))
  if field=="effects":invalid.effects=[]
  elif field=="attachments":invalid.attachments=[{}]
  elif field=="tribes":invalid.tribes=["元素"]
  else:invalid.keywords=["magnetic"]
  p.hand.append(invalid)
  var snapshot=p.duplicate(true)
  r=game.apply_command(0,{"type":"play","index":p.hand.size()-1})
  if not check(not r.get("ok",false) and p==snapshot,family+"_"+bone_id+"_reject_"+field):print(r);return false
  p.hand.pop_back()
 # Corrupted history is never repaired by an ordinary sale.
 p[chain].sales=0
 var before_history=p[chain].duplicate(true)
 r=game.apply_command(0,{"type":"sell","index":0})
 if not check(r.get("ok",false) and p[chain]==before_history,family+"_ordinary_cannot_repair_corrupt_history"):print(r);return false
 return true
