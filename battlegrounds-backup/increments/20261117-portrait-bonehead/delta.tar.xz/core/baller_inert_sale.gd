extends RefCounted
## Narrow additional history certification, not a general deathrattle exemption.
const Skeletons=preload("res://core/sand_skeleton_summon_sources.gd")
const Exact=preload("res://core/phase_undead_army_sources.gd")
const IDS=["BG28_300","BG28_300_G"]
static func recognized(engine,p: Dictionary,u: Dictionary) -> bool:
 if u.get("card_id") not in IDS or u.get("kind")!="minion":return false
 # New domain is deliberately narrower than legacy effect-free sales.
 if p.get("hero_id")!="TB_BaconShop_HERO_01":return false
 for key in ["hero_identity_id","hero_identity_portrait","hero_power_replacement_history"]:
  if p.has(key):return false
 for owner in engine.state.players:
  if not owner.get("active_quest",{}) is Dictionary or not owner.get("reward_active",[]) is Array or not owner.get("trinkets",[]) is Array:return false
  if not owner.get("active_quest",{}).is_empty() or not owner.get("reward_active",[]).is_empty() or not owner.get("trinkets",[]).is_empty():return false
 return identity(engine,u)
static func identity(engine,u: Dictionary) -> bool:
 if u.get("card_id") not in IDS or u.get("kind")!="minion":return false
 var canonical=engine.catalog.source_catalog if engine.catalog.source_catalog!=null else engine.catalog
 var card: Dictionary=canonical.get_card(u.card_id)
 if not Skeletons.source_error(card).is_empty():return false
 if not Exact.same(u.get("effects"),Skeletons.PROGRAMS[u.card_id]):return false
 if not Exact.same(u.get("tribes"),card.get("tribes")) or not Exact.same(u.get("keywords"),card.get("keywords")):return false
 if u.get("golden",false)!=card.get("is_golden",false):return false
 if not u.get("attachments",[]) is Array or not u.get("attachments",[]).is_empty():return false
 var base: Variant=u.get("base_unit")
 if not base is Dictionary or base.get("card_id")!=u.card_id or not Exact.same(base.get("effects"),Skeletons.PROGRAMS[u.card_id]):return false
 return true
