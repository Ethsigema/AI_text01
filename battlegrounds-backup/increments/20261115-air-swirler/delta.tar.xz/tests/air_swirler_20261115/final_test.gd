extends SceneTree
var game
var cat
var checks=0
func check(ok: bool,label: String) -> bool:
 checks+=1
 print("PASS " if ok else "FAIL ",label)
 if not ok: print(cat.load_errors);quit(1)
 return ok
func setup() -> bool:
 game=load("res://core/game.gd").new()
 var room=load("res://core/room_config.gd").new();room.reset(cat)
 room.data.enabled_minions=["BG36_181","BGS_119","BG31_330"]
 room.data.enabled_spells=["BG28_810"]
 room.data.selected_hero="TB_BaconShop_HERO_01";room.data.enabled_heroes=["TB_BaconShop_HERO_01"];room.data.bot_count=1;room.data.seed=20261115
 for key in ["enabled_anomalies","enabled_quests","enabled_rewards","enabled_trinkets"]: room.data[key]=[]
 return check(game.start(room.data,cat).get("ok",false),"real_room")
func run_case(aura: String,ids: Array) -> bool:
 if not setup(): return false
 var p=game.state.players[0]
 var sw=game._unit(cat.get_card(aura));var target=game._unit(cat.get_card("BGS_119"))
 p.board.append(sw);p.board.append(target)
 var attack=target.attack;var health=target.health;var sw_attack=sw.attack;var sum=0;var count=0
 for id in ids:
  var u=game._unit(cat.get_card(id));p.board.append(u);var before=p.duplicate(true);var gold=p.gold
  if not check(game.TimewarpSwirler.command_error(game,0,{"type":"sell","index":2}).is_empty(),"grown_preflight"):return false
  if not check(p==before,"preflight_read_only"):return false
  var result=game.apply_command(0,{"type":"sell","index":2})
  if not check(result.get("ok",false),"real_sale_"+id+"_"+aura):print(result);return false
  count+=1;sum+=(4 if id.ends_with("_G") else 2)*count+(6 if aura.ends_with("_G") else 3)
  if not check(target.attack==attack+sum and target.health==health+sum,"grown_plus_aura_once"):return false
  if not check(sw.attack==sw_attack+sum,"aura_holder_receives_vector"):return false
  if not check(p.stats.sold==count and game.AirBaller.air_sales(p)==count,"aura_not_added_to_growth_counter"):return false
  if not check(p.gold==gold+1 and p.board.size()==2,"real_sale_gold_removal"):return false
  if not check(not game.state.players[1].has(game.AirBaller.CHAIN),"opponent_isolated"):return false
 # Reject direct buff invocation without an actual sale receipt.
 var fake=game._unit(cat.get_card("BG36_181"));var snapshot=p.duplicate(true)
 if not check(not game.TimewarpSwirler.vector(game,target,2,2,fake).get("ok",true),"unissued_vector_rejected"):return false
 if not check(p==snapshot,"unissued_vector_no_mutation"):return false
 return true
func guard_cases() -> bool:
 if not setup():return false
 var p=game.state.players[0];p.board.append(game._unit(cat.get_card("BG34_Giant_686")))
 var air=game._unit(cat.get_card("BG36_181"));p.board.append(air)
 p.stats.sold=1
 var snapshot=p.duplicate(true)
 if not check(not game.apply_command(0,{"type":"sell","index":1}).get("ok",true),"unknown_history_held"):return false
 if not check(p==snapshot,"unknown_history_no_removal"):return false
 p.stats.sold=0;p.board.insert(1,game._unit(cat.get_card("BG34_Giant_686")))
 snapshot=p.duplicate(true)
 if not check(not game.apply_command(0,{"type":"sell","index":2}).get("ok",true),"multiple_aura_held"):return false
 if not check(p==snapshot,"multiple_aura_no_removal"):return false
 return true
func boundary_cases() -> bool:
 for field in ["attack","max_health"]:
  if not setup():return false
  var p=game.state.players[0];var sw=game._unit(cat.get_card("BG34_Giant_686"));var air=game._unit(cat.get_card("BG36_181"))
  p.board.append(sw);p.board.append(air)
  p.stats.sold=1;p[game.AirBaller.CHAIN]={"owner":p.id,"sales":1}
  sw[field]=game.Combat.StartCombatEffects.MAX_STAT-5
  var snapshot=p.duplicate(true)
  var result=game.apply_command(0,{"type":"sell","index":1})
  if not check(not result.get("ok",true) and str(result.get("error","")).contains("overflow"),"aura_inclusive_overflow_"+field):print(result);return false
  if not check(p==snapshot,"overflow_prevents_all_sale_mutation_"+field):return false
 for ordinary in [0,1]:
  if not setup():return false
  var p=game.state.players[0];var sw=game._unit(cat.get_card("BG34_Giant_686"));p.board.append(sw)
  var air=game._unit(cat.get_card("BG36_181_G"));p.board.append(air)
  p.stats.sold=2;p[game.AirBaller.CHAIN]={"owner":p.id,"sales":2}
  if ordinary: p[game.AirBaller.CHAIN].ordinary_sales=1
  var before=sw.attack
  if not check(game.apply_command(0,{"type":"sell","index":1}).get("ok",false),"certified_history_shape_"+str(ordinary)):return false
  if not check(sw.attack==before+4*(3-ordinary)+3,"history_excludes_ordinary_from_growth"):return false
 # Aura silence keeps Air growth, without the extra vector.
 if not setup():return false
 var p=game.state.players[0];var sw=game._unit(cat.get_card("BG34_Giant_686"));p.board.append(sw)
 sw.silenced=true
 var before=sw.attack
 for i in range(2):
  p.board.append(game._unit(cat.get_card("BG36_181")))
  if not check(game.apply_command(0,{"type":"sell","index":1}).get("ok",false),"silenced_aura_real_sale"):return false
 if not check(sw.attack==before+6,"silenced_aura_no_bonus"):return false
 return true
func _initialize():
 cat=load("res://core/catalog.gd").new();cat.load_catalog()
 if not check(cat.load_errors.is_empty(),"catalog"):return
 for aura in ["BG34_Giant_686","BG34_Giant_686_G"]:
  if not run_case(aura,["BG36_181","BG36_181_G","BG36_181"]):return
 if not guard_cases() or not boundary_cases():return
 print("AIR_SWIRLER_PASS checks=",checks);quit(0)
