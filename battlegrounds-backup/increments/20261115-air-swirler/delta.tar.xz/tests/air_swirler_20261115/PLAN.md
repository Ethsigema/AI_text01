# Growth Air Baller with existing Timewarped Swirler

Baseline: source 27acae4ff8e0d7d9ce979e8b791fbdb9ae13b860; 18:00 checkpoint 2c31887b1b958f97ceed409e447f145ffc789e91. Full baseline 28,070 files was independently reread against the already verified target manifest, no mismatch. No newer visible development handoff was found. Unknown invisible work is not claimed captured.

Bounded slice: allow the already implemented Air Baller certified growth amount to pass through the existing single active Swirler additive aura bridge. Do not implement a new extra mechanism or change the aura lifetime; preserve multi-aura, modifier-stack, Fire/Snow mixed and unknown sale-history guards.

Rule support: native records already pinned in research/patch_3702_timewarp_swirler and patch_3702_timewarp_swirler_golden; official 34.6 patch https://hearthstone.blizzard.com/en-gb/news/24242740/34-6-patch-notes states Elementals give an extra +3/+3. This extends the prior first-sale bridge, not a claim of live-client acceptance or latest pool verification.

Before actual sell, capacity check uses grown payoff plus aura. At write, require actual single-use sale receipt, matching prior total sale count and amount, command sequence, round, source identity, removal and target membership. Do not blindly accept arbitrary buff invocation.
