extends RefCounted
const InertSale=preload("res://core/baller_inert_sale.gd")
const Exact=preload("res://core/phase_undead_army_sources.gd")
const Child=preload("res://core/patch_3702_temperature_shift_sources.gd")
const Fire=preload("res://core/patch_3702_fire_baller_sources.gd")
const Snow=preload("res://core/patch_3702_snow_baller_sources.gd")
const ID="BG35_MagicItem_861"
const RAW={"id":"BG35_MagicItem_861","card_code":"BG35_MagicItem_861","identity_type":"source_card_code","dbf_id":"130873","name":"投球手肖像","kind":"trinket","category":"大型饰品","categories":["大型饰品"],"kinds":["trinket"],"source_sheets":["酒馆饰品"],"source_groups":["mechanisms"],"mechanisms":["酒馆饰品"],"tier":null,"attack":null,"health":null,"cost":5,"armor":null,"armor_by_mode":{},"text":"获取一张寒热骤变。在你使用11张元素牌后，重复此效果。（还剩11张！）","tribes":[],"keywords":[],"supported":false,"effects":[],"variant":"普通","is_golden":false,"golden_id":null,"normal_id":null,"image":"res://assets/cards/BG35_MagicItem_861.jpg","images":[{"path":"res://assets/cards/BG35_MagicItem_861.jpg","sha256":"ad8aad0b388d111aa68f3967de53f711de20cd9d3c52692c322e801a763e287a","xlsx_media_part":"xl/media/image489.jpg","row":75,"column_zero_based":6,"size_bytes":5237}],"source_url":"https://wiki.ifindhs.com/index.php?title=酒馆战棋/投球手肖像（大型）&oldid=163277","source":"https://wiki.ifindhs.com/index.php?title=酒馆战棋/投球手肖像（大型）&oldid=163277","source_urls":["https://wiki.ifindhs.com/index.php?title=酒馆战棋/投球手肖像（大型）&oldid=163277"],"verification_source_urls":[],"image_source_url":"http://search.ifindhs.com/pics/latest/BG35_MagicItem_861.png","fields":{"tier":null,"attack":null,"health":null,"cost":5,"armor":null,"race":"","variant":"普通","status":"机制池","text":"获取一张寒热骤变。在你使用11张元素牌后，重复此效果。（还剩11张！）","acquisition":"饰品选择\n仅对应机制或明确的特殊生成来源","restrictions":"饰品选择\n仅对应机制或明确的特殊生成来源","pool_tag":"元素","related_content":"寒热骤变","notes":"括号中的剩余次数或回合数为来源牌面进度，实战会按回合或触发次数更新。","updated_at":"2026-09-04 Patch36.4.2.251332","prize_tier":null,"cost_currency":null,"timewarped":null,"applicable_modes":null},"raw_fields":{"名称":"投球手肖像","类别":"大型饰品","饰品种族标签":"","费用":5,"效果":"获取一张寒热骤变。在你使用11张元素牌后，重复此效果。（还剩11张！）","获取方式 / 限定条件":"饰品选择\n仅对应机制或明确的特殊生成来源","图像":"","版本":"普通\n大型","状态":"机制池","选择池 / 等级标记":"元素","获取来源 / 关联英雄":"","衍生物 / 关联内容":"寒热骤变","最终更新":"2026-09-04 Patch36.4.2.251332","卡牌代码 / ID":"BG35_MagicItem_861\n130873","核实备注":"括号中的剩余次数或回合数为来源牌面进度，实战会按回合或触发次数更新。","来源":"https://wiki.ifindhs.com/index.php?title=酒馆战棋/投球手肖像（大型）&oldid=163277","获取 / 核验来源链接":"","图片来源":"http://search.ifindhs.com/pics/latest/BG35_MagicItem_861.png"},"field_status":{"tier":{"raw":"","value":null,"status":"blank_or_not_applicable","verification":null,"value_source":null},"attack":{"raw":"","value":null,"status":"blank_or_not_applicable","verification":null,"value_source":null},"health":{"raw":"","value":null,"status":"blank_or_not_applicable","verification":null,"value_source":null},"cost":{"raw":5,"value":5,"status":"known","verification":null,"value_source":null},"armor":{"raw":"","value":null,"status":"blank_or_not_applicable","verification":null,"value_source":null}},"quality_flags":["dynamic_values_or_progress"],"historical_abilities":[],"provenance":{"workbook":"限时机制.xlsx","library_file_id":"libfile_80439ad8142c8191a11c1a8ee066d07c","version":1,"sheet":"酒馆饰品","row":75,"source_catalog_file":"res://data/source_catalog/mechanisms.json"},"occurrences":[{"provenance":{"workbook":"限时机制.xlsx","library_file_id":"libfile_80439ad8142c8191a11c1a8ee066d07c","version":1,"sheet":"酒馆饰品","row":75,"source_catalog_file":"res://data/source_catalog/mechanisms.json"},"raw_fields":{"名称":"投球手肖像","类别":"大型饰品","饰品种族标签":"","费用":5,"效果":"获取一张寒热骤变。在你使用11张元素牌后，重复此效果。（还剩11张！）","获取方式 / 限定条件":"饰品选择\n仅对应机制或明确的特殊生成来源","图像":"","版本":"普通\n大型","状态":"机制池","选择池 / 等级标记":"元素","获取来源 / 关联英雄":"","衍生物 / 关联内容":"寒热骤变","最终更新":"2026-09-04 Patch36.4.2.251332","卡牌代码 / ID":"BG35_MagicItem_861\n130873","核实备注":"括号中的剩余次数或回合数为来源牌面进度，实战会按回合或触发次数更新。","来源":"https://wiki.ifindhs.com/index.php?title=酒馆战棋/投球手肖像（大型）&oldid=163277","获取 / 核验来源链接":"","图片来源":"http://search.ifindhs.com/pics/latest/BG35_MagicItem_861.png"},"images":[{"path":"res://assets/cards/BG35_MagicItem_861.jpg","sha256":"ad8aad0b388d111aa68f3967de53f711de20cd9d3c52692c322e801a763e287a","xlsx_media_part":"xl/media/image489.jpg","row":75,"column_zero_based":6,"size_bytes":5237}]}],"source_conflicts":[],"supplemental_evidence_key":null,"status":"机制池","notes":"括号中的剩余次数或回合数为来源牌面进度，实战会按回合或触发次数更新。","solo_eligible":true,"duos_exclusive":false,"requires_teammate_effect":false,"mode_evidence":{"latest_client":{"card_code":"BG35_MagicItem_861","dbf_id":"130873","duos_exclusive":false,"tag_3166":null,"source_url":"https://raw.githubusercontent.com/HearthSim/hsdata/27fbd2323aec20cab1c6ecc7d5f55cf12729f956/CardDefs.Bacon.xml"},"workbook_applicable_modes":null,"effect_requires_team_mechanism":false,"basis":"Current exclusivity flag and explicit source mode/effect text. No duo-to-solo rewrite."}}
const EXPECTED={"id":"BG35_MagicItem_861","card_code":"BG35_MagicItem_861","identity_type":"source_card_code","dbf_id":"130873","name":"投球手肖像","kind":"trinket","category":"大型饰品","categories":["大型饰品"],"kinds":["trinket"],"source_sheets":["酒馆饰品"],"source_groups":["mechanisms"],"mechanisms":["酒馆饰品"],"tier":null,"attack":null,"health":null,"cost":5,"armor":null,"armor_by_mode":{},"text":"获取一张寒热骤变。在你使用11张元素牌后，重复此效果。（还剩11张！）","tribes":[],"keywords":[],"supported":true,"effects":[{"type":"mechanism_trigger","event":"mechanic_acquired","action":"add_spell","card_id":"BG31_819","count":1,"cyclic_resource_source":"BG35_MagicItem_861"},{"type":"mechanism_trigger","event":"play_minion","trigger_kind":"minion","trigger_tribe":"元素","interval":11,"action":"add_spell","card_id":"BG31_819","count":1,"cyclic_resource_source":"BG35_MagicItem_861"}],"variant":"普通","is_golden":false,"golden_id":null,"normal_id":null,"image":"res://assets/cards/BG35_MagicItem_861.jpg","images":[{"path":"res://assets/cards/BG35_MagicItem_861.jpg","sha256":"ad8aad0b388d111aa68f3967de53f711de20cd9d3c52692c322e801a763e287a","xlsx_media_part":"xl/media/image489.jpg","row":75,"column_zero_based":6,"size_bytes":5237}],"source_url":"https://wiki.ifindhs.com/index.php?title=酒馆战棋/投球手肖像（大型）&oldid=163277","source":"https://wiki.ifindhs.com/index.php?title=酒馆战棋/投球手肖像（大型）&oldid=163277","source_urls":["https://wiki.ifindhs.com/index.php?title=酒馆战棋/投球手肖像（大型）&oldid=163277"],"verification_source_urls":[],"image_source_url":"http://search.ifindhs.com/pics/latest/BG35_MagicItem_861.png","fields":{"tier":null,"attack":null,"health":null,"cost":5,"armor":null,"race":"","variant":"普通","status":"机制池","text":"获取一张寒热骤变。在你使用11张元素牌后，重复此效果。（还剩11张！）","acquisition":"饰品选择\n仅对应机制或明确的特殊生成来源","restrictions":"饰品选择\n仅对应机制或明确的特殊生成来源","pool_tag":"元素","related_content":"寒热骤变","notes":"括号中的剩余次数或回合数为来源牌面进度，实战会按回合或触发次数更新。","updated_at":"2026-09-04 Patch36.4.2.251332","prize_tier":null,"cost_currency":null,"timewarped":null,"applicable_modes":null},"raw_fields":{"名称":"投球手肖像","类别":"大型饰品","饰品种族标签":"","费用":5,"效果":"获取一张寒热骤变。在你使用11张元素牌后，重复此效果。（还剩11张！）","获取方式 / 限定条件":"饰品选择\n仅对应机制或明确的特殊生成来源","图像":"","版本":"普通\n大型","状态":"机制池","选择池 / 等级标记":"元素","获取来源 / 关联英雄":"","衍生物 / 关联内容":"寒热骤变","最终更新":"2026-09-04 Patch36.4.2.251332","卡牌代码 / ID":"BG35_MagicItem_861\n130873","核实备注":"括号中的剩余次数或回合数为来源牌面进度，实战会按回合或触发次数更新。","来源":"https://wiki.ifindhs.com/index.php?title=酒馆战棋/投球手肖像（大型）&oldid=163277","获取 / 核验来源链接":"","图片来源":"http://search.ifindhs.com/pics/latest/BG35_MagicItem_861.png"},"field_status":{"tier":{"raw":"","value":null,"status":"blank_or_not_applicable","verification":null,"value_source":null},"attack":{"raw":"","value":null,"status":"blank_or_not_applicable","verification":null,"value_source":null},"health":{"raw":"","value":null,"status":"blank_or_not_applicable","verification":null,"value_source":null},"cost":{"raw":5,"value":5,"status":"known","verification":null,"value_source":null},"armor":{"raw":"","value":null,"status":"blank_or_not_applicable","verification":null,"value_source":null}},"quality_flags":["dynamic_values_or_progress"],"historical_abilities":[],"provenance":{"workbook":"限时机制.xlsx","library_file_id":"libfile_80439ad8142c8191a11c1a8ee066d07c","version":1,"sheet":"酒馆饰品","row":75,"source_catalog_file":"res://data/source_catalog/mechanisms.json"},"occurrences":[{"provenance":{"workbook":"限时机制.xlsx","library_file_id":"libfile_80439ad8142c8191a11c1a8ee066d07c","version":1,"sheet":"酒馆饰品","row":75,"source_catalog_file":"res://data/source_catalog/mechanisms.json"},"raw_fields":{"名称":"投球手肖像","类别":"大型饰品","饰品种族标签":"","费用":5,"效果":"获取一张寒热骤变。在你使用11张元素牌后，重复此效果。（还剩11张！）","获取方式 / 限定条件":"饰品选择\n仅对应机制或明确的特殊生成来源","图像":"","版本":"普通\n大型","状态":"机制池","选择池 / 等级标记":"元素","获取来源 / 关联英雄":"","衍生物 / 关联内容":"寒热骤变","最终更新":"2026-09-04 Patch36.4.2.251332","卡牌代码 / ID":"BG35_MagicItem_861\n130873","核实备注":"括号中的剩余次数或回合数为来源牌面进度，实战会按回合或触发次数更新。","来源":"https://wiki.ifindhs.com/index.php?title=酒馆战棋/投球手肖像（大型）&oldid=163277","获取 / 核验来源链接":"","图片来源":"http://search.ifindhs.com/pics/latest/BG35_MagicItem_861.png"},"images":[{"path":"res://assets/cards/BG35_MagicItem_861.jpg","sha256":"ad8aad0b388d111aa68f3967de53f711de20cd9d3c52692c322e801a763e287a","xlsx_media_part":"xl/media/image489.jpg","row":75,"column_zero_based":6,"size_bytes":5237}]}],"source_conflicts":[],"supplemental_evidence_key":null,"status":"机制池","notes":"括号中的剩余次数或回合数为来源牌面进度，实战会按回合或触发次数更新。","solo_eligible":true,"duos_exclusive":false,"requires_teammate_effect":false,"mode_evidence":{"latest_client":{"card_code":"BG35_MagicItem_861","dbf_id":"130873","duos_exclusive":false,"tag_3166":null,"source_url":"https://raw.githubusercontent.com/HearthSim/hsdata/27fbd2323aec20cab1c6ecc7d5f55cf12729f956/CardDefs.Bacon.xml"},"workbook_applicable_modes":null,"effect_requires_team_mechanism":false,"basis":"Current exclusivity flag and explicit source mode/effect text. No duo-to-solo rewrite."},"pool_supported":false,"default_pool":false,"implementation_status":"partial_pending_unified_validation","coverage_rule":"greater_baller_owned_finite_20261116","conditional_support":{"reason":"仅单饰品、帕奇维克无其他监听、effect-free打出有限域；满手、磁力、组合待验证。非整卡完成。"}}
const PROGRAMS=[{"type":"mechanism_trigger","event":"mechanic_acquired","action":"add_spell","card_id":"BG31_819","count":1,"cyclic_resource_source":"BG35_MagicItem_861"},{"type":"mechanism_trigger","event":"play_minion","trigger_kind":"minion","trigger_tribe":"元素","interval":11,"action":"add_spell","card_id":"BG31_819","count":1,"cyclic_resource_source":"BG35_MagicItem_861"}]
static func source_error(card: Dictionary)->String:
 return "" if Exact.same(card,EXPECTED) else "greater_baller_source_changed"
static func has_source(p: Dictionary)->bool:return ID in p.get("trinkets",[])
static func key()->String:return "trinket:0:"+ID+":1:interval"
static func domain(engine,p: Dictionary,acquire: bool)->String:
 if engine.state.phase!="recruit" or p.hero_id!="TB_BaconShop_HERO_01":return "greater_baller_hero_phase_partial"
 if engine._enabled("anomalies")!=[]:return "greater_baller_anomalies_partial"
 if p.get("trinkets",[])!=([] if acquire else [ID]):return "greater_baller_single_slot_partial"
 for q in engine.state.players:
  if q.get("hero_id")!="TB_BaconShop_HERO_01":return "greater_baller_other_hero_partial"
  for k in ["hero_identity_id","hero_identity_portrait","hero_power_replacement_history","hero_power"]:
   if q.has(k):return "greater_baller_replaced_hero_partial"
  if q.get("permanent_tribe_bonuses",{})!={}:return "greater_baller_global_bonuses_partial"
  for u in q.hand:
   var c=engine.catalog.get_card(str(u.get("card_id","")))
   if u.get("attachments",[])!=[] or not Exact.same(u.get("effects",[]),c.get("effects",[])):return "greater_baller_hand_listener_partial"
   if u.get("effects",[])!=[] and u.get("card_id") not in ["BG31_819","BG31_816","BG31_818"] and not InertSale.identity(engine,u):return "greater_baller_hand_listener_partial"
  if q.get("reward_active",[])!=[] or q.get("active_quest",{})!={} or (not is_same(q,p) and q.get("trinkets",[])!=[]):return "greater_baller_other_mechanisms_partial"
  for u in q.board:
   var c=engine.catalog.get_card(str(u.get("card_id","")))
   if u.get("attachments",[])!=[]:return "greater_baller_board_listeners_partial"
   if u.get("effects",[])!=[] and not InertSale.identity(engine,u) and (u.get("card_id") not in ["BG31_816","BG31_818"] or not Exact.same(u.get("effects",[]),c.get("effects",[]))):return "greater_baller_board_listeners_partial"
 for k in ["hero_identity_id","hero_identity_portrait","hero_power_replacement_history"]:
  if p.has(k):return "greater_baller_replaced_hero_partial"
 if p.get("mechanism_reward_queue",[])!=[]:return "greater_baller_queue_partial"
 var n=p.get("mechanism_state",{}).get(key(),0)
 if not (n is int or n is float) or n is bool or not is_finite(float(n)) or n!=floor(float(n)) or n<0 or n>10:return "greater_baller_invalid_progress"
 if acquire and n!=0:return "greater_baller_orphan_progress"
 var issue=source_error(engine.catalog.get_card(ID))
 if issue.is_empty():issue=Child.source_error(engine.catalog.get_card("BG31_819"))
 if issue.is_empty():issue=Fire.source_error(engine.catalog.get_card("BG31_816"))
 if issue.is_empty():issue=Snow.source_error(engine.catalog.get_card("BG31_818"))
 return issue
static func command_error(engine,p: Dictionary,command: Dictionary)->String:
 var acquire=false
 var i=int(command.get("index",-1))
 if command.get("type")=="discover" and i>=0 and i<p.discover.size():acquire=p.discover[i].get("id")==ID
 if not acquire and not has_source(p):return ""
 var issue=domain(engine,p,acquire)
 if not issue.is_empty():return issue
 if acquire:
  if p.hand.size()>=10:return "greater_baller_full_hand_partial"
  var offered=p.discover[i].duplicate(true);offered.erase("choice_kind")
  if not source_error(offered).is_empty():return "greater_baller_offer_changed"
 elif command.get("type")=="discover":return "greater_baller_additional_discover_partial"
 elif command.get("type")=="buy":
  if i>=0 and i<p.shop.size():
   var offered=p.shop[i]
   var c=engine.catalog.get_card(str(offered.get("card_id",offered.get("id",""))))
   var child=c.get("id") in ["BG31_816","BG31_818"]
   if c.get("id")=="BG31_819":
    if offered.get("kind")!="spell" or offered.get("attachments",[])!=[] or not Exact.same(offered.get("effects",[]),c.get("effects",[])) or not Exact.same(offered.get("keywords",[]),c.get("keywords",[])):return "greater_baller_incoming_spell_changed"
   elif child:
    # Only the already-certified ordinary children; retain existing triple and purchase preflights.
    if offered.get("kind")!="minion" or offered.get("is_golden",false) or offered.get("attachments",[])!=[] or not Exact.same(offered.get("effects",[]),c.get("effects",[])) or not Exact.same(offered.get("tribes",[]),c.get("tribes",[])) or not Exact.same(offered.get("keywords",[]),c.get("keywords",[])):return "greater_baller_incoming_child_changed"
   elif InertSale.identity(engine,offered) and not offered.get("golden",false):
    pass # Exact ordinary Bonehead; generic purchase/stock/triple guards remain.
   elif c.get("kind")!="minion" or c.get("effects",[])!=[] or "magnetic" in c.get("keywords",[]) or offered.get("effects",[])!=[]:return "greater_baller_incoming_payload_partial"
 elif command.get("type") not in ["play","sell","move","roll","freeze","upgrade","end_turn"]:return "greater_baller_other_command_partial"
 elif command.get("type")=="play" and i>=0 and i<p.hand.size():
  var u=p.hand[i]
  if u.get("card_id")=="BG31_819":
   if u.get("kind")!="spell" or u.get("attachments",[])!=[] or not Exact.same(u.get("effects",[]),Child.EXPECTED_CURRENT.effects) or u.get("keywords",[])!=[]:return "greater_baller_spell_identity_changed"
   if p.hand.size()>9:return "greater_baller_spell_overflow_partial"
   return ""
  var child=u.get("card_id") in ["BG31_816","BG31_818"] or InertSale.identity(engine,u)
  if u.get("kind")!="minion" or (not child and u.get("effects",[])!=[]) or u.get("attachments",[])!=[] or "magnetic" in u.get("keywords",[]):return "greater_baller_play_payload_partial"
  var card=engine.catalog.get_card(str(u.get("card_id","")))
  if (not child and card.get("effects",[])!=[]) or not Exact.same(u.get("effects",[]),card.get("effects",[])) or not Exact.same(u.get("tribes",[]),card.get("tribes",[])) or not Exact.same(u.get("keywords",[]),card.get("keywords",[])):return "greater_baller_play_identity_changed"
 return ""
static func observe(engine,p: Dictionary,effect: Dictionary,event: String,context: Dictionary)->String:
 var expected_slot="trinket:0:"+ID+(":0" if event=="mechanic_acquired" else ":1")
 var payload=effect.duplicate(true)
 for field in ["source_id","source_kind","source_slot","latest_instance"]:payload.erase(field)
 if effect.get("source_id")!=ID or effect.get("source_kind")!="trinket" or effect.get("source_slot")!=expected_slot or not Exact.same(payload,PROGRAMS[0 if event=="mechanic_acquired" else 1]):return "greater_baller_exact_program_required"
 var actual=engine._greater_baller_context
 if actual.get("used",true) or not is_same(actual.get("owner"),p) or actual.get("event")!=event or actual.get("sequence")!=engine.state.command_sequence or actual.get("round")!=engine.state.round:return "greater_baller_actual_command_required"
 if event=="play_minion" and not is_same(actual.get("unit"),context.get("unit")):return "greater_baller_wrong_played_object"
 var ticket=engine._owned_timed_event_context
 if ticket.get("event")!=event or not is_same(ticket.get("owner"),p) or not is_same(ticket.get("context"),context) or ticket.get("round")!=engine.state.round or ticket.get("sequence")!=engine.state.command_sequence or effect.source_slot in ticket.get("used",[]):return "greater_baller_requires_actual_event"
 var issue=domain(engine,p,false)
 if not issue.is_empty():return issue
 if event=="mechanic_acquired":
  if context.get("source_id")!=ID or not effect.get("latest_instance",false):return "greater_baller_wrong_acquisition"
 elif event=="play_minion":
  if not p.board.any(func(u):return is_same(u,context.get("unit"))):return "greater_baller_actual_board_play_required"
  if context.has("magnetic_target_uid"):return "greater_baller_magnetic_partial"
 else:return "greater_baller_wrong_event"
 actual.used=true
 ticket.used.append(effect.source_slot)
 return ""
