extends RefCounted
## Read-only current-cycle presentation. Never executes or predicts a reward.
const Host=preload("res://core/greater_baller_portrait.gd")
static func note(engine,player: Dictionary)->String:
 if not Host.has_source(player):return ""
 if engine==null or engine.state.is_empty():return "大型投球手肖像：进度不可用（没有当前对局）"
 var owners=engine.state.get("players",[]).filter(func(p):return is_same(p,player))
 if owners.size()!=1:return "大型投球手肖像：进度不可用（未绑定实际玩家）"
 if player.get("trinkets",[])!=[Host.ID]:return "大型投球手肖像：进度不可用（多饰品尚未验证）"
 if not Host.source_error(engine.catalog.get_card(Host.ID)).is_empty():return "大型投球手肖像：进度不可用（来源改变）"
 var counters=player.get("mechanism_state",{})
 if not counters is Dictionary:return "大型投球手肖像：进度不可用（状态异常）"
 var count=counters.get(Host.key(),0)
 if not (count is int or count is float) or count is bool or not is_finite(float(count)) or count!=floor(float(count)) or count<0 or count>10:return "大型投球手肖像：进度不可用（计数异常）"
 return "大型投球手肖像：%d/11 · 还需%d张元素\n当前奖励周期；进度跨回合保留。"%[int(count),11-int(count)]
