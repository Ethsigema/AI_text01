extends SceneTree
const Display=preload("res://ui/greater_baller_progress.gd")
const Host=preload("res://core/greater_baller_portrait.gd")
var cat
var game
var checks=0
func check(ok:bool,label:String)->bool:
 checks+=1;print("PASS " if ok else "FAIL ",label)
 if not ok:quit(1)
 return ok
func _initialize():
 cat=load("res://core/catalog.gd").new();cat.load_catalog()
 if not check(cat.load_errors.is_empty(),"catalog"):print(cat.load_errors);return
 print("SOURCE ",cat.get_card(Host.ID).get("coverage_blocker")," SUPPORTED ",cat.get_card(Host.ID).get("supported"))
 game=load("res://core/game.gd").new()
 var room=load("res://core/room_config.gd").new();room.reset(cat)
 room.data.enabled_minions=["BGS_119","BG31_818","BG31_330"];room.data.enabled_spells=["BG28_810"];room.data.selected_hero="TB_BaconShop_HERO_01";room.data.enabled_heroes=["TB_BaconShop_HERO_01"];room.data.bot_count=1;room.data.seed=20261116
 for k in ["enabled_anomalies","enabled_quests","enabled_rewards","enabled_trinkets"]:room.data[k]=[]
 if not check(game.start(room.data,cat).get("ok",false),"real_room"):return
 var p=game.state.players[0];p.gold=10;p.board=[]
 var offer=cat.get_card(Host.ID).duplicate(true);offer.choice_kind="trinket";p.discover=[offer]
 var r=game.apply_command(0,{"type":"discover","index":0})
 if not check(r.get("ok",false),"actual_acquisition"):print(r);return
 if not check(p.gold==5 and p.hand.size()==1 and p.hand[0].card_id=="BG31_819","reward_and_cost"):return
 var snap=p.duplicate(true)
 if not check(Display.note(game,p).contains("0/11 · 还需11张元素") and p==snap,"initial_display_readonly"):return
 for n in range(10):
  p.board=[]
  p.hand.append(game._unit(cat.get_card("BGS_119")))
  r=game.apply_command(0,{"type":"play","index":p.hand.size()-1})
  if not check(r.get("ok",false),"actual_element_%d"%(n+1)):print(r);return
  var text=Display.note(game,p)
  if not check(text.contains("%d/11 · 还需%d张元素"%[n+1,10-n]) and p.hand.size()==1,"display_and_reward_%d"%(n+1)):return
 if not check(Display.note(game,p).contains("10/11 · 还需1张元素"),"ten_of_eleven"):return
 p.board=[]
 var round_before=game.state.round
 game._begin_round()
 if not check(game.state.round==round_before+1 and Display.note(game,p).contains("10/11 · 还需1张元素") and p.hand.size()==1,"real_round_preserves_display_and_reward"):return
 p.hand.append(game._unit(cat.get_card("BGS_119")))
 r=game.apply_command(0,{"type":"play","index":p.hand.size()-1})
 if not check(r.get("ok",false) and p.hand.size()==2 and p.hand.all(func(u):return u.card_id=="BG31_819"),"eleventh_delivers_actual_reward"):print(r);return
 if not check(Display.note(game,p).contains("0/11 · 还需11张元素"),"reward_reset_display"):return
 p.board=[]
 p.hand.append(game._unit(cat.get_card("BGS_119")))
 r=game.apply_command(0,{"type":"play","index":p.hand.size()-1})
 if not check(r.get("ok",false) and Display.note(game,p).contains("1/11 · 还需10张元素") and p.hand.size()==2,"second_cycle"):return
 snap=p.duplicate(true)
 for n in range(5):Display.note(game,p)
 if not check(p==snap,"repeated_read_does_not_mutate"):return
 if not check(Display.note(game,p.duplicate(true)).contains("未绑定实际玩家"),"cloned_owner_no_progress"):return
 if not check(Display.note(game,game.state.players[1])=="","nonowner_has_no_progress"):return
 for value in [-1,11,1.5,true]:
  p.mechanism_state[Host.key()]=value
  if not check(Display.note(game,p).contains("计数异常"),"invalid_count_not_clamped"):return
 p.mechanism_state[Host.key()]=1
 var ui=load("res://ui/main.gd")
 if not check(ui!=null and ui.can_instantiate(),"ui_script_load"):return
 var code=FileAccess.get_file_as_string("res://ui/main.gd")
 if not check(code.contains("GreaterBallerProgress.note(game,player)") and code.contains('baller_progress_label.name="GreaterBallerProgress"'),"ui_live_owner_wiring"):return
 print("PASS TOTAL ",checks);quit(0)
