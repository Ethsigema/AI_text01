extends SceneTree
const Info=preload("res://ui/baller_sale_info.gd")
var checks=0
func check(ok: bool,label: String):
 checks+=1
 print("PASS " if ok else "FAIL ",label)
 if not ok:quit(1)
 return ok
func _initialize():
 var cat=load("res://core/catalog.gd").new();cat.load_catalog()
 if not check(cat.load_errors.is_empty(),"catalog"):return
 var game=load("res://core/game.gd").new()
 var room=load("res://core/room_config.gd").new();room.reset(cat)
 room.data.enabled_minions=["BG31_818","BGS_119","BG31_330"]
 room.data.enabled_spells=["BG28_810"]
 room.data.selected_hero="TB_BaconShop_HERO_01";room.data.enabled_heroes=["TB_BaconShop_HERO_01"];room.data.bot_count=1;room.data.seed=20261116
 for key in ["enabled_anomalies","enabled_quests","enabled_rewards","enabled_trinkets"]:room.data[key]=[]
 if not check(game.start(room.data,cat).get("ok",false),"real_game"):return
 for id in Info.Air.IDS+Info.Fire.IDS+Info.Snow.IDS:
  var family=Info.host(id);var p=game.state.players[0]
  var u=game._unit(cat.get_card(id));p.board=[u];p.stats.sold=0
  for h in [Info.Air,Info.Fire,Info.Snow]:p.erase(h.CHAIN)
  var before=game.state.duplicate(true);var rng=game.rng.state;var uid=game.next_uid
  var note=Info.note(game,u,"board")
  if not check(note.begins_with("出售基础收益：") and str(family.amount(p,u)) in note,"initial_"+id):return
  if not check("不含旋流" in note,"base_not_total_"+id):return
  if not check(game.state==before and game.rng.state==rng and game.next_uid==uid,"read_only_"+id):return
  p.stats.sold=4;p[family.CHAIN]={"owner":p.id,"sales":4,"ordinary_sales":2}
  note=Info.note(game,u,"board")
  if not check(("+"+str(family.amount(p,u))) in note and family.amount(p,u)==int(family.program(id)[0].health if family==Info.Snow else family.program(id)[0].attack)*3,"growth_ordinary_"+id):return
  for zone in ["hand","shop"]:
   p.board=[];p[zone].append(u)
   if not check(Info.note(game,u,zone).begins_with("待上场") and "不能直接出售" in Info.note(game,u,zone),"zone_"+zone+id):return
   p[zone].erase(u)
  p.board=[u]
  if not check("未核验" in Info.note(game,u.duplicate(true),"board"),"detached_"+id):return
  p[family.CHAIN].owner=1
  if not check("未核验" in Info.note(game,u,"board") and "+" not in Info.note(game,u,"board"),"bad_history_"+id):return
  p.erase(family.CHAIN);p.stats.sold=0
  u.silenced=true
  if not check(Info.note(game,u,"board").begins_with("效果失效"),"silenced_"+id):return
  u.silenced=false;p.trinkets=["unverified_fixture"]
  if not check(Info.note(game,u,"board").begins_with("当前受限"),"observer_hold_"+id):return
  p.trinkets=[]
  p.stats.sold=4;p[family.CHAIN]={"owner":p.id,"sales":4,"ordinary_sales":2}
  var other=game.state.players[1];other.board=[game._unit(cat.get_card(id))];other.stats.sold=0
  if not check(Info.note(game,other.board[0],"board").contains("+"+str(family.amount(other,other.board[0]))),"opponent_own_history_"+id):return
  other.board=[]
  if not check(Info.note(game,u,"combat").is_empty(),"combat_excluded_"+id):return
 # Compile the actual wired screen; no gameplay acceptance or visual QA claimed.
 if not check(load("res://ui/main.gd")!=null,"ui_script_load"):return
 print("PASS TOTAL ",checks);quit(0)
