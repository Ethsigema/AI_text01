extends RefCounted
## Pure presentation. No history certification, mutation, sale or rule override.
const Air=preload("res://core/air_baller_host.gd")
const Fire=preload("res://core/fire_baller_host.gd")
const Snow=preload("res://core/snow_baller_host.gd")
static func host(id: String):
 if id in Air.IDS:return Air
 if id in Fire.IDS:return Fire
 if id in Snow.IDS:return Snow
 return null
static func note(engine,unit: Dictionary,zone: String) -> String:
 var family=host(str(unit.get("card_id","")))
 if family==null or zone not in ["board","hand","shop"]:return ""
 if engine==null or engine.state.is_empty():return "投球手收益：未核验（没有当前对局）"
 # Never borrow the local player's history for an opponent, detached preview,
 # cloned dictionary, combat snapshot or a same-UID replacement.
 var owners: Array=[]
 for player in engine.state.get("players",[]):
  if player.get(zone,[]).any(func(body):return is_same(body,unit)):owners.append(player)
 if owners.size()!=1:return "投球手收益：未核验（未绑定实际玩家与区域）"
 var p: Dictionary=owners[0]
 if not unit.get("effects") is Array or not unit.effects.all(func(e):return e is Dictionary):return "投球手收益：未核验（效果数据异常）"
 var issue: String=family.unit_error(unit)
 if issue.is_empty():issue=family.history_error(p)
 if not issue.is_empty():return "投球手收益：未核验\n当前实现不支持这份效果或出售历史；不推算收益。\n"+issue
 var canonical=engine.catalog.source_catalog if engine.catalog.source_catalog!=null else engine.catalog
 issue=family.Normal.source_error(canonical.get_card(unit.card_id)) if unit.card_id==family.IDS[0] else family.Golden.source_error(canonical.get_card(unit.card_id))
 if not issue.is_empty():return "投球手收益：未核验（来源数据已改变）"
 var amount: int=family.amount(p,unit)
 var bonus: String=("+%s攻击力"%amount if family==Fire else ("+%s生命值"%amount if family==Snow else "+%s/+%s"%[amount,amount]))
 var status: String="出售基础收益"
 if zone!="board":status="待上场·收益预览"
 elif not family.Gains.active(unit):status="效果失效·保留收益"
 elif engine.state.get("phase")!="recruit" or not p.get("alive",false):status="非招募阶段·收益预览"
 else:
  issue=family.sale_error(engine,p,unit)
  if not issue.is_empty():status="当前受限·收益预览"
 var text: String="%s：%s"%[status,bonus]
 text+="\n仅显示投球手自身的基础成长，不含旋流等给予修饰器的额外增益；实际结算可能更高。"
 text+="\n按该玩家当前已认证出售历史计算，赋予出售后留下的友方随从；不是本体属性。"
 text+="\n已认证的普通随从出售不增加成长。后续操作可能改变收益或可用性。"
 if zone!="board":text+="\n当前不在战队，不能直接出售；上场后仍须通过实际出售检查。"
 elif not family.Gains.active(unit):text+="\n当前效果失效，不会触发。"
 elif not issue.is_empty():text+="\n当前实现暂不支持此出售组合："+issue
 return text
