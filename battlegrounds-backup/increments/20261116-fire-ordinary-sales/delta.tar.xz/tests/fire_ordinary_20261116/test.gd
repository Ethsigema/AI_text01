extends SceneTree
var game
var cat
var checks=0
func check(ok: bool,label: String) -> bool:
 checks+=1
 print("PASS " if ok else "FAIL ",label)
 if not ok: print(cat.load_errors);quit(1)
 return ok
func setup() -> bool:
 game=load("res://core/game.gd").new()
 var room=load("res://core/room_config.gd").new();room.reset(cat)
 room.data.enabled_minions=["BG31_816","BGS_119","BG31_330"]
 room.data.enabled_spells=["BG28_810"]
 room.data.selected_hero="TB_BaconShop_HERO_01";room.data.enabled_heroes=["TB_BaconShop_HERO_01"];room.data.bot_count=1;room.data.seed=20261115
 for key in ["enabled_anomalies","enabled_quests","enabled_rewards","enabled_trinkets"]: room.data[key]=[]
 return check(game.start(room.data,cat).get("ok",false),"real_room")
func run_case(ids: Array) -> bool:
 if not setup(): return false
 var p=game.state.players[0];var target=game._unit(cat.get_card("BGS_119"));p.board.append(target)
 var attack=target.attack;var health=target.health;var payoff=0;var fire_count=0;var ordinary_count=0
 for id in ids:
  var u=game._unit(cat.get_card(id));p.board.append(u);var gold=p.gold
  var before=p.duplicate(true);var quote=game.FireBaller.sale_error(game,p,u)
  if not check(quote.is_empty() and p==before,"read_only_preflight"): return false
  var result=game.apply_command(0,{"type":"sell","index":1})
  if not check(result.get("ok",false),"actual_sale_"+id): print(result);return false
  if id=="BGS_119": ordinary_count+=1
  else:
   fire_count+=1;payoff+=(2 if id.ends_with("_G") else 1)*fire_count
  if not check(target.attack==attack+payoff and target.health==health,"payoff_counts_only_fire"):return false
  if not check(p.stats.sold==fire_count+ordinary_count and p.get(game.FireBaller.CHAIN,{}).get("ordinary_sales",-1)==ordinary_count,"total_and_ordinary_counts"):return false
  if not check(p.gold==gold+1 and p.board.size()==1,"remove_once_pay_one_gold"):return false
  if not check(not game.state.players[1].has(game.FireBaller.CHAIN),"other_player_untouched"):return false
  if not check(game.FireBaller.history_error(JSON.parse_string(JSON.stringify(p))).is_empty(),"json_roundtrip"):return false
 var before=p.duplicate(true)
 var bad=game.apply_command(0,{"type":"sell","index":99})
 if not check(not bad.get("ok",true) and p==before,"failed_sale_does_not_certify"):return false
 for n in [-1,0.5,true,p.stats.sold+1]:
  var copy=p.duplicate(true);copy[game.FireBaller.CHAIN].ordinary_sales=n
  if not check(not game.FireBaller.history_error(copy).is_empty(),"invalid_ordinary_counter_held"):return false
 var copy=p.duplicate(true);copy[game.FireBaller.CHAIN].extra=true
 if not check(not game.FireBaller.history_error(copy).is_empty(),"extra_history_field_held"):return false
 return true
func unknown_history() -> bool:
 if not setup():return false
 var p=game.state.players[0];p.stats.sold=3;p.board.append(game._unit(cat.get_card("BGS_119")))
 if not check(game.apply_command(0,{"type":"sell","index":0}).get("ok",false),"ordinary_sale_with_unknown_history_still_legal"):return false
 if not check(not p.has(game.FireBaller.CHAIN),"unknown_history_not_retroactively_certified"):return false
 p.board.append(game._unit(cat.get_card("BG31_816")))
 return check(not game.FireBaller.sale_error(game,p,p.board[0]).is_empty(),"fire_after_unknown_history_held")
func guards() -> bool:
 if not setup():return false
 var p=game.state.players[0];var u=game._unit(cat.get_card("BGS_119"));p.board.append(u)
 var before=p.duplicate(true)
 game.FireBaller.commit_ordinary(game,p,u,{"used":false})
 if not check(p==before,"unissued_ordinary_ticket_no_mutation"):return false
 var ticket=game.FireBaller.prepare_ordinary(game,p,u)
 game._fire_baller_ordinary_context=ticket
 game.FireBaller.commit_ordinary(game,p,u,ticket)
 game._fire_baller_ordinary_context={}
 if not check(p==before,"issued_ticket_without_completed_sale_no_mutation"):return false
 var old={"id":p.id,"stats":{"sold":2},game.FireBaller.CHAIN:{"owner":p.id,"sales":2}}
 var fire=game._unit(cat.get_card("BG31_816"))
 if not check(game.FireBaller.history_error(old).is_empty() and game.FireBaller.amount(old,fire)==3,"old_two_field_history_compatible"):return false
 u.effects=[{"type":"on_sell_fire_baller_verified_base"}]
 if not check(game.FireBaller.prepare_ordinary(game,p,u).is_empty(),"tampered_effects_not_certified"):return false
 u.effects=[];p.board.append(game._unit(cat.get_card("BG31_330")))
 if not check(game.FireBaller.prepare_ordinary(game,p,u).is_empty(),"unknown_board_observer_not_certified"):return false
 p.board.pop_back();p.trinkets=[{"id":"unsupported"}]
 return check(game.FireBaller.prepare_ordinary(game,p,u).is_empty(),"trinket_observers_not_certified")
func mixed_guard(id: String) -> bool:
 if not setup():return false
 var p=game.state.players[0];p.board.append(game._unit(cat.get_card("BGS_119")))
 var other=game._unit(cat.get_card(id));p.board.append(other)
 if not check(game.FireBaller.prepare_ordinary(game,p,other).is_empty(),"other_baller_not_certified_as_ordinary_"+id):return false
 var r=game.apply_command(0,{"type":"sell","index":1})
 if not check(r.get("ok",false),"real_other_baller_sale_"+id):print(r);return false
 var fire=game._unit(cat.get_card("BG31_816"));p.board.append(fire)
 return check(not game.FireBaller.sale_error(game,p,fire).is_empty(),"fire_after_other_baller_still_held_"+id)
func _initialize():
 cat=load("res://core/catalog.gd").new();cat.load_catalog()
 if not check(cat.load_errors.is_empty(),"catalog"):return
 for ids in [["BGS_119","BG31_816"],["BG31_816","BGS_119","BG31_816"],["BGS_119","BGS_119","BG31_816_G","BGS_119","BG31_816","BG31_816_G"]]:
  if not run_case(ids):return
 if not unknown_history() or not guards() or not mixed_guard("BG36_181") or not mixed_guard("BG31_818"):return
 print("FIRE_ORDINARY_SALE_PASS checks=",checks);quit(0)
