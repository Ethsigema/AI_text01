extends SceneTree
var checks=0
func check(ok:bool,label:String)->bool:
 checks+=1;print("PASS " if ok else "FAIL ",label)
 if not ok:quit(1)
 return ok
func _initialize():
 var cat=load("res://core/catalog.gd").new();cat.load_catalog()
 if not check(cat.load_errors.is_empty(),"catalog"):return
 var room=load("res://core/room_config.gd").new();room.reset(cat)
 for id in ["EBG_Spell_014","BG31_893"]:
  var c=cat.get_card(id)
  print("IDENTITY ",id," ",c.get("dbf_id")," ",c.get("name")," ",c.get("tier")," ",c.get("cost"))
  if not check(not c.is_empty() and c.kind=="spell" and c.supported,id+"_generated_dependency_retained"):return
  # Historical capability flags are not current product membership.
  print("HISTORICAL_FLAGS ",id," ",c.get("default_pool")," ",c.get("pool_supported"))
  if not check(not load("res://core/current_scope.gd").allows_pool("spell",id,cat),id+"_current_scope_excludes_tavern_pool"):return
  var injected=room.data.duplicate(true);injected.enabled_spells.append(id)
  if not check(not load("res://core/current_scope.gd").room_errors(injected,cat).is_empty(),id+"_direct_pool_injection_rejected"):return
  if not check(id not in room.data.enabled_spells,id+"_excluded_from_default_room"):return
 var forge=cat.get_card("BG36_884")
 if not check(forge.dbf_id=="133371" and forge.tier==4 and forge.cost==2,"forge_identity_tier_cost"):return
 if not check("BG36_884" in room.data.enabled_spells,"forge_default_pool"):return
 if not check(cat.get_card("EBG_Spell_014").dbf_id=="100596","arrow_stable_id"):return
 print("PASS TOTAL ",checks);quit(0)
