extends SceneTree
const Host=preload("res://core/greater_baller_portrait.gd")
var cat
var game
var checks=0
func check(ok:bool,label:String)->bool:
 checks+=1;print("PASS " if ok else "FAIL ",label)
 if not ok:quit(1)
 return ok
func _initialize():
 cat=load("res://core/catalog.gd").new();cat.load_catalog()
 if not check(cat.load_errors.is_empty(),"catalog"):print(cat.load_errors);return
 for family in ["fire","snow"]:
  if not run_family(family):return
 print("PASS TOTAL ",checks);quit(0)
func run_family(family:String)->bool:
 game=load("res://core/game.gd").new()
 var room=load("res://core/room_config.gd").new();room.reset(cat)
 room.data.enabled_minions=["BGS_119","BG31_816","BG31_818"];room.data.enabled_spells=["BG28_810"];room.data.selected_hero="TB_BaconShop_HERO_01";room.data.enabled_heroes=["TB_BaconShop_HERO_01"];room.data.bot_count=1;room.data.seed=20261116
 for k in ["enabled_anomalies","enabled_quests","enabled_rewards","enabled_trinkets"]:room.data[k]=[]
 if not check(game.start(room.data,cat).get("ok",false),family+"_real_room"):return false
 var p=game.state.players[0];p.gold=10;p.board=[]
 var offer=cat.get_card(Host.ID).duplicate(true);offer.choice_kind="trinket";p.discover=[offer]
 var r=game.apply_command(0,{"type":"discover","index":0})
 if not check(r.get("ok",false),family+"_acquisition"):print(r);return false
 r=game.apply_command(0,{"type":"play","index":0})
 if not check(r.get("ok",false) and p.hand.size()==2,family+"_reward_spell"):print(r);return false
 var seller="BG31_816" if family=="fire" else "BG31_818"
 # A canonical shop fixture isolates the actual purchase command, not shop generation.
 p.hand=[]
 p.shop=[game._unit(cat.get_card(seller))]
 var offered=p.shop[0]
 var gold=p.gold
 var progress=p.mechanism_state.get(Host.key(),0)
 r=game.apply_command(0,{"type":"buy","index":0})
 if not check(r.get("ok",false),family+"_actual_purchase"):print(r);return false
 if not check(p.gold==gold-3 and p.hand.size()==1 and p.shop.size()==0,family+"_purchase_cost_and_transfer"):return false
 if not check(is_same(p.hand[0],offered) and p.mechanism_state.get(Host.key(),0)==progress,family+"_purchase_does_not_count_play"):return false
 r=game.apply_command(0,{"type":"play","index":0})
 if not check(r.get("ok",false) and p.board.size()==1 and p.mechanism_state.get(Host.key(),0)==progress+1,family+"_actual_purchased_child_play"):print(r);return false
 # Every rejection below must leave spendable resources and cards untouched.
 for mutation in ["effects","tribes","keywords","attachments","golden"]:
  var u=game._unit(cat.get_card(seller))
  if mutation=="effects":u.effects=[]
  elif mutation=="tribes":u.tribes=[]
  elif mutation=="keywords":u.keywords=["taunt"]
  elif mutation=="attachments":u.attachments=[{}]
  elif mutation=="golden":u.is_golden=true
  p.shop=[u];p.gold=10
  var old_hand=p.hand.duplicate(true);var old_board=p.board.duplicate(true);var old_stats=p.stats.duplicate(true)
  r=game.apply_command(0,{"type":"buy","index":0})
  if not check(not r.get("ok",false) and p.gold==10 and p.hand==old_hand and p.board==old_board and p.stats==old_stats and p.shop.size()==1,family+"_reject_atomic_"+mutation):print(r);return false
 p.shop=[game._unit(cat.get_card(seller))];p.hand=[]
 for n in range(10):p.hand.append(game._unit(cat.get_card("BGS_119")))
 r=game.apply_command(0,{"type":"buy","index":0})
 if not check(not r.get("ok",false) and p.gold==10 and p.hand.size()==10 and p.shop.size()==1,family+"_full_hand_atomic"):return false
 p.hand=[];p.gold=2
 r=game.apply_command(0,{"type":"buy","index":0})
 if not check(not r.get("ok",false) and p.gold==2 and p.hand.is_empty() and p.shop.size()==1,family+"_insufficient_gold_atomic"):return false
 return true
