extends SceneTree
var cat
var game
var checks=0
func ck(ok:bool,label:String)->bool:
 checks+=1;print("PASS " if ok else "FAIL ",label)
 if not ok:print(game.events.slice(-3));quit(1)
 return ok
func _initialize():
 cat=load("res://core/catalog.gd").new();cat.load_catalog()
 game=load("res://core/game.gd").new()
 var room=load("res://core/room_config.gd").new();room.reset(cat)
 room.data.enabled_minions=["BGS_119","BG23_000"];room.data.enabled_spells=["BG28_810"];room.data.selected_hero="TB_BaconShop_HERO_01";room.data.enabled_heroes=["TB_BaconShop_HERO_01"];room.data.bot_count=1;room.data.seed=20261117
 for k in ["enabled_anomalies","enabled_quests","enabled_rewards","enabled_trinkets"]:room.data[k]=[]
 if not ck(game.start(room.data,cat).get("ok",false),"real_room"):return
 var p=game.state.players[0];p.board=[];p.hand=[]
 var normal=game._unit(cat.get_card("BG23_000"))
 var gid=cat.get_card("BG23_000").golden_id
 var golden=game._unit(cat.get_card(gid))
 p.board=[normal,golden]
 for n in range(10):p.hand.append(game._unit(cat.get_card("BG28_810")))
 game._grant_spellcraft(p,normal);game._grant_spellcraft(p,golden)
 if not ck(game.state.phase=="recruit" and p.hand.size()==10 and game.SpellcraftWaiting.pending_count(p)==2,"normal_golden_full_hand_wait"):return
 var expected=[]
 for source in [normal,golden]:
  for e in source.effects:
   if e.type=="spellcraft":expected.append(e.card_id)
 print("NATIVE_MAPPINGS ",expected)
 if not ck(expected.size()==2 and expected[0]!=expected[1],"independent_golden_mapping"):return
 var r=game.apply_command(0,{"type":"play","index":0})
 if not ck(r.get("ok",false) and p.hand.size()==10 and game.SpellcraftWaiting.pending_count(p)==1,"public_coin_cast_opens_one_slot"):print(r);return
 if not ck(p.hand[-1].card_id==expected[0] and p.hand[-1].is_spellcraft and p.hand[-1].expires_at_end_turn,"normal_waiting_delivery_flags"):return
 r=game.apply_command(0,{"type":"play","index":0})
 if not ck(r.get("ok",false) and p.hand.size()==10 and game.SpellcraftWaiting.pending_count(p)==0,"second_public_cast_delivers_remaining"):print(r);return
 if not ck(p.hand[-1].card_id==expected[1] and p.hand[-1].is_spellcraft and p.hand[-1].expires_at_end_turn,"golden_waiting_delivery_flags"):return
 var ids=p.hand.map(func(u):return u.uid)
 game._flush_spellcraft(p)
 if not ck(p.hand.map(func(u):return u.uid)==ids,"empty_queue_no_duplicate"):return
 # Register a further issuance only to test outstanding EOT cancellation; does not claim a second official trigger.
 game._grant_spellcraft(p,normal)
 if not ck(game.SpellcraftWaiting.pending_count(p)==1,"eot_pending_fixture"):return
 r=game.apply_command(0,{"type":"end_turn"})
 if not ck(r.get("ok",false),"owner_public_end_turn"):print(r);return
 r=game.apply_command(1,{"type":"end_turn"})
 if not ck(r.get("ok",false) and game.state.phase=="recruit" and game.state.round==2,"actual_combat_and_next_recruit"):print(r);return
 if not ck(not p.hand.any(func(u):return u.uid in ids and u.get("is_spellcraft",false)),"old_spellcraft_expired"):return
 if not ck(p.hand.filter(func(u):return u.get("is_spellcraft",false)).size()==2 and game.SpellcraftWaiting.pending_count(p)==0,"fresh_next_round_not_old_pending"):return
 print("PASS TOTAL ",checks);quit(0)
