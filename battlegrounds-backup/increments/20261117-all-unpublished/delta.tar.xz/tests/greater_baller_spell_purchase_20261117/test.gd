extends SceneTree
const Host=preload("res://core/greater_baller_portrait.gd")
var cat
var game
var checks=0
func check(ok:bool,label:String)->bool:
 checks+=1;print("PASS " if ok else "FAIL ",label)
 if not ok:quit(1)
 return ok
func _initialize():
 cat=load("res://core/catalog.gd").new();cat.load_catalog()
 if not check(cat.load_errors.is_empty(),"catalog"):print(cat.load_errors);return
 for family in ["spell"]:
  if not run_family(family):return
 print("PASS TOTAL ",checks);quit(0)
func run_family(family:String)->bool:
 game=load("res://core/game.gd").new()
 var room=load("res://core/room_config.gd").new();room.reset(cat)
 room.data.enabled_minions=["BGS_119","BG31_816","BG31_818"];room.data.enabled_spells=["BG28_810"];room.data.selected_hero="TB_BaconShop_HERO_01";room.data.enabled_heroes=["TB_BaconShop_HERO_01"];room.data.bot_count=1;room.data.seed=20261116
 for k in ["enabled_anomalies","enabled_quests","enabled_rewards","enabled_trinkets"]:room.data[k]=[]
 if not check(game.start(room.data,cat).get("ok",false),family+"_real_room"):return false
 var p=game.state.players[0];p.gold=10;p.board=[]
 var offer=cat.get_card(Host.ID).duplicate(true);offer.choice_kind="trinket";p.discover=[offer]
 var r=game.apply_command(0,{"type":"discover","index":0})
 if not check(r.get("ok",false),family+"_acquisition"):print(r);return false
 r=game.apply_command(0,{"type":"play","index":0})
 if not check(r.get("ok",false) and p.hand.size()==2,family+"_reward_spell"):print(r);return false
 p.hand=[]
 p.shop=[game._unit(cat.get_card("BG31_819"))]
 var offered=p.shop[0];var gold=p.gold
 var progress=p.mechanism_state.get(Host.key(),0)
 r=game.apply_command(0,{"type":"buy","index":0})
 if not check(r.get("ok",false),"actual_spell_purchase"):print(r);return false
 if not check(p.gold==gold-4 and p.shop.is_empty() and p.hand.size()==1 and is_same(p.hand[0],offered),"four_gold_transfer"):return false
 if not check(p.mechanism_state.get(Host.key(),0)==progress,"buy_not_elemental_play"):return false
 r=game.apply_command(0,{"type":"play","index":0})
 if not check(r.get("ok",false) and p.hand.size()==2 and p.hand[0].card_id=="BG31_816" and p.hand[1].card_id=="BG31_818","purchased_spell_real_cast"):print(r);return false
 if not check(p.gold==gold-4 and p.mechanism_state.get(Host.key(),0)==progress,"cast_no_second_charge_or_elemental_count"):return false
 for mutation in ["effects","kind","attachments","keywords"]:
  p.hand=[];p.gold=10
  var u=game._unit(cat.get_card("BG31_819"))
  if mutation=="effects":u.effects=[]
  elif mutation=="kind":u.kind="minion"
  elif mutation=="attachments":u.attachments=[{}]
  else:u.keywords=["taunt"]
  p.shop=[u];var before=p.duplicate(true)
  r=game.apply_command(0,{"type":"buy","index":0})
  if not check(not r.get("ok",false) and p==before,"reject_atomic_"+mutation):print(r);return false
 p.hand=[];p.gold=3;p.shop=[game._unit(cat.get_card("BG31_819"))]
 var before=p.duplicate(true)
 r=game.apply_command(0,{"type":"buy","index":0})
 if not check(not r.get("ok",false) and p==before,"insufficient_gold"):return false
 p.gold=10
 # Spell fillers avoid automatic triples from nine identical minions.
 for n in range(10):p.hand.append(game._unit(cat.get_card("BG31_819")))
 before=p.duplicate(true)
 r=game.apply_command(0,{"type":"buy","index":0})
 if not check(not r.get("ok",false) and p==before,"full_hand_purchase_atomic"):return false
 p.hand.pop_back()
 r=game.apply_command(0,{"type":"buy","index":0})
 if not check(r.get("ok",false) and p.hand.size()==10 and p.gold==6,"nine_hand_purchase_to_ten"):print(r," hand=",p.hand.size()," gold=",p.gold," shop=",p.shop.size()," actual=",game.state.players[0].gold);return false
 before=p.duplicate(true)
 r=game.apply_command(0,{"type":"play","index":9})
 if not check(not r.get("ok",false) and p==before,"ten_hand_cast_still_guarded"):return false
 return true
