extends RefCounted
const GreaterPortrait=preload("res://core/greater_baller_portrait.gd")
const InertSale=preload("res://core/baller_inert_sale.gd")
const Normal=preload("res://core/patch_3702_fire_baller_sources.gd")
const Golden=preload("res://core/patch_3702_fire_baller_golden_sources.gd")
const Gains=preload("res://core/attack_gain_listeners.gd")
const IDS=["BG31_816","BG31_816_G"]
const CHAIN="fire_baller_sale_chain_v1"
const MAX_SALES: int=1000000
const TYPE="on_sell_fire_baller_verified_base"
static func program(id: String) -> Array:
	return [{"type":TYPE,"source_id":id,"attack":2 if id==IDS[1] else 1,"health":0}] if id in IDS else []
static func unit_error(unit: Dictionary) -> String:
	var id: String=str(unit.get("card_id",unit.get("id","")))
	var marker: bool=unit.get("effects",[]).any(func(e):return e.get("type")==TYPE)
	if id not in IDS: return "fire_baller_unbound_program" if marker else ""
	return "" if Normal.same(unit.get("effects"),program(id)) else "fire_baller_changed_program"
# Certified Fire sales may be separated by canonical effect-free ordinary sales.
# Unknown history, other Baller families and unsupported observers remain held.
static func history_error(p: Dictionary) -> String:
	var sold: Variant=p.get("stats",{}).get("sold",-1)
	if not (sold is int or sold is float) or sold is bool or not is_finite(float(sold)) or sold!=floor(sold) or sold<0 or sold>=MAX_SALES: return "fire_baller_invalid_or_full_sale_history"
	if not p.has(CHAIN): return "" if sold==0 else "fire_baller_growth_after_prior_sale_unverified"
	var h: Variant=p[CHAIN]
	if not h is Dictionary or (h.size()!=2 and h.size()!=3) or not Normal.same(h.get("owner"),p.get("id")) or not Normal.same(h.get("sales"),sold) or sold<1: return "fire_baller_incomplete_or_changed_sale_history"
	if h.size()==3 and not h.has("ordinary_sales"): return "fire_baller_incomplete_or_changed_sale_history"
	var ordinary: Variant=h.get("ordinary_sales",0)
	if not (ordinary is int or ordinary is float) or ordinary is bool or not is_finite(float(ordinary)) or ordinary!=floor(ordinary) or ordinary<0 or ordinary>sold: return "fire_baller_invalid_ordinary_sale_history"
	return ""
static func fire_sales(p: Dictionary) -> int:
	return int(p.stats.sold)-int(p.get(CHAIN,{}).get("ordinary_sales",0))
static func amount(p: Dictionary,u: Dictionary) -> int:
	return int(program(u.card_id)[0].attack)*(1+fire_sales(p))
static func sale_error(engine,p: Dictionary,u: Dictionary) -> String:
	if u.get("card_id") not in IDS: return ""
	var issue: String=unit_error(u)
	var canonical=engine.catalog.source_catalog if engine.catalog.source_catalog!=null else engine.catalog
	if issue.is_empty(): issue=Normal.source_error(canonical.get_card(u.card_id)) if u.card_id==IDS[0] else Golden.source_error(canonical.get_card(u.card_id))
	if not issue.is_empty(): return issue
	issue=history_error(p)
	if not issue.is_empty(): return issue
	if not Gains.active(u) or not p.board.any(func(v):return is_same(v,u)): return "fire_baller_actual_active_source_required"
	if not p.get("reward_active",[]).is_empty(): return "fire_baller_owned_observers_partial"
	if not p.get("trinkets",[]).is_empty():
		if p.get("trinkets")!=[GreaterPortrait.ID]: return "fire_baller_owned_observers_partial"
		var portrait_issue: String=GreaterPortrait.domain(engine,p,false)
		if not portrait_issue.is_empty(): return portrait_issue
	for v in p.board:
		for effect in v.get("effects",[]):
			var type: String=str(effect.get("type",""))
			if type not in ["on_sell_fire_baller_verified_base","on_sell_snow_baller_verified_base"] and not type.begins_with("battlecry_") and not type.begins_with("deathrattle_"): return "fire_baller_competing_board_observer_partial:"+type
		if not is_same(v,u) and not engine.Combat.StartCombatEffects.buff_fits(v,amount(p,u),0): return "fire_baller_buff_overflow"
	return ""
static func prepare(engine,p: Dictionary,u: Dictionary) -> Dictionary:
	if u.get("card_id") not in IDS: return {"ok":true,"active":false}
	var issue: String=sale_error(engine,p,u)
	if not issue.is_empty(): return {"ok":false,"error":issue}
	return {"ok":true,"active":true,"owner":p,"source":u,"sequence":engine.state.command_sequence,"round":engine.state.round,"targets":p.board.filter(func(v):return not is_same(v,u)).map(func(v):return v.uid),"used":false,"prior_sales":p.stats.sold,"amount":amount(p,u)}
static func commit(engine,p: Dictionary,u: Dictionary,ticket: Dictionary) -> String:
	if not ticket.get("active",false): return "fire_baller_missing_sale_ticket"
	if not is_same(engine._fire_baller_context,ticket) or ticket.used or not is_same(ticket.owner,p) or not is_same(ticket.source,u) or ticket.sequence!=engine.state.command_sequence or ticket.round!=engine.state.round: return "fire_baller_stale_sale_ticket"
	if not history_error(p).is_empty() or not Normal.same(p.stats.sold,ticket.prior_sales) or p.board.any(func(v):return v.uid==u.uid): return "fire_baller_actual_removal_required"
	if not Normal.same(p.board.map(func(v):return v.uid),ticket.targets): return "fire_baller_changed_sale_recipients"
	var payoff: int=amount(p,u)
	if payoff!=ticket.amount: return "fire_baller_changed_sale_payoff"
	ticket.used=true
	for target in p.board:
		engine._buff(target,payoff,0)
		if engine.state.phase=="error": return "fire_baller_actual_buff_failed"
		engine._log("fire_baller_sale_growth_buff",{"player":p.id,"source_id":u.card_id,"source_uid":u.uid,"target_uid":target.uid,"attack":payoff,"health":0})
	p[CHAIN]={"owner":p.id,"sales":int(p.stats.sold)+1,"ordinary_sales":int(p.get(CHAIN,{}).get("ordinary_sales",0))}
	return ""
# Ticket is issued before a real sale and consumed only at its successful tail.
# Failure to certify never blocks an otherwise legal ordinary sale.
static func prepare_ordinary(engine,p: Dictionary,u: Dictionary) -> Dictionary:
	if u.get("card_id") in IDS or not history_error(p).is_empty() or not Gains.active(u): return {}
	if not p.board.any(func(v):return is_same(v,u)): return {}
	var canonical=engine.catalog.source_catalog if engine.catalog.source_catalog!=null else engine.catalog
	var card: Dictionary=canonical.get_card(str(u.get("card_id","")))
	var inert: bool=InertSale.recognized(engine,p,u)
	if not inert and (card.is_empty() or not Normal.same(card.get("effects",[]),[]) or not Normal.same(u.get("effects",[]),[])): return {}
	if not p.get("reward_active",[]).is_empty(): return {}
	if not p.get("trinkets",[]).is_empty():
		if p.get("trinkets")!=[GreaterPortrait.ID] or not GreaterPortrait.domain(engine,p,false).is_empty(): return {}
	for v in p.board:
		if inert and is_same(v,u): continue # Exact native Bonehead program is inert on sale.
		for e in v.get("effects",[]):
			if e.get("type")!=TYPE or not unit_error(v).is_empty(): return {}
	return {"owner":p,"source":u,"prior_sales":p.stats.sold,"had_chain":p.has(CHAIN),"chain":p.get(CHAIN,{}).duplicate(true),"sequence":engine.state.command_sequence,"round":engine.state.round,"used":false}
static func commit_ordinary(engine,p: Dictionary,u: Dictionary,ticket: Dictionary) -> void:
	if ticket.is_empty() or not is_same(engine._fire_baller_ordinary_context,ticket): return
	if ticket.used or not is_same(ticket.owner,p) or not is_same(ticket.source,u) or ticket.sequence!=engine.state.command_sequence or ticket.round!=engine.state.round: return
	if engine.state.phase=="error" or p.stats.sold!=ticket.prior_sales+1 or p.board.any(func(v):return v.uid==u.uid): return
	if p.has(CHAIN)!=ticket.had_chain or not Normal.same(p.get(CHAIN,{}),ticket.chain): return
	ticket.used=true
	p[CHAIN]={"owner":p.id,"sales":int(p.stats.sold),"ordinary_sales":int(ticket.chain.get("ordinary_sales",0))+1}
static func legal_actions(engine,player_id: int,commands: Array) -> Array:
	if engine.state.is_empty() or player_id<0 or player_id>=engine.state.players.size(): return commands
	var p: Dictionary=engine.state.players[player_id]
	return commands.filter(func(c):
		if c.get("type")!="sell": return true
		var index: int=int(c.get("index",-1))
		return index<0 or index>=p.board.size() or sale_error(engine,p,p.board[index]).is_empty()
	)
