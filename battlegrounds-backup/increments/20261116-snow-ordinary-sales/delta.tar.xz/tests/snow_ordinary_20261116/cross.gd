extends "res://tests/snow_ordinary_20261116/test.gd"
func _initialize():
 cat=load("res://core/catalog.gd").new();cat.load_catalog()
 if not check(cat.load_errors.is_empty(),"catalog"):return
 for ids in [["BG31_818","BG31_816"],["BG31_816","BG31_818"],["BG31_818","BG36_181"],["BG36_181","BG31_818"],["BG31_816","BG36_181"],["BG36_181","BG31_816"]]:
  if not setup():return
  var p=game.state.players[0]
  p.board.append(game._unit(cat.get_card("BGS_119")))
  if not check(game.apply_command(0,{"type":"sell","index":0}).get("ok",false),"real_initial_ordinary"):return
  if not check(p.has(game.FireBaller.CHAIN) and p.has(game.AirBaller.CHAIN) and p.has(game.SnowBaller.CHAIN),"three_independent_chains_initially_certified"):return
  p.board.append(game._unit(cat.get_card(ids[0])))
  if not check(game.apply_command(0,{"type":"sell","index":0}).get("ok",false),"real_first_family_sale"):return
  p.board.append(game._unit(cat.get_card("BGS_119")))
  if not check(game.apply_command(0,{"type":"sell","index":0}).get("ok",false),"real_interposed_ordinary"):return
  p.board.append(game._unit(cat.get_card(ids[1])))
  var before=p.duplicate(true)
  var r=game.apply_command(0,{"type":"sell","index":0})
  if not check(not r.get("ok",false) and p==before,"cross_family_after_triple_chain_still_read_only_held"):return
 print("CROSS_CHAIN_PASS checks=",checks);quit(0)
