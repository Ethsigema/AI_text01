# 极紫外升腾者：使用元素后的成长候选

本次新增真实玩法路径，不是新卡身份：原版本在场上存在极紫外升腾者时拒绝使用元素。新增接入原 Game after-hand-play listener；普通每次累计 +4/+4、金色每次累计 +8/+8 的战斗开始增益，排除本体、非元素及失效来源，不在招募阶段改写本体身材。仍使用原 Combat 增益结算。

## 规则证据与范围

37.0.2 官方补丁只确证基础8/8、战斗增益4/4。每次成长步长及排除自身的细节来自固定提交的公开第三方 AutoTavern 实现，非暴雪客户端或实机验收；见 evidence/rule_evidence.json。没有把这项列作官方全功能实现，也没有增加完整随从完成数。

新增实体字段 `ultraviolet_play_growth_v1` 保留同一UID下的成长次数和上次实际指令序号。JSON整数表示允许数值型整数，拒绝布尔、小数、非法身份和超界。最多1,000,000次成长为当前安全数值域上限，超出明确拒绝，不溢出。

未知三连继承明确拒绝，不能悄悄清掉成长；复制到新UID不会被当作已验证继承。单目标变金保留原未知字段拒绝。未证明旧存档的完整加载、所有复制/变形/消除状态组合、所有英雄和饰品交互。界面动态提示尚未更新。

## 验证方法

Godot 4.6.3，完整 Catalog/Game，原 apply_command 使用手牌、Combat.resolve 真战斗。起始牌由原工厂建立并直接放入board/hand，属于显式fixture，未证明自然购买、普通三连或整局流程。测试涵盖普通/金色连续成长、非元素、自身使用、沉默、非真实回调拒绝、变UID拒绝、JSON数值表示和未知三连拒绝；战斗实际只给其他元素增益且不回写招募本体。

```
XDG_DATA_HOME=/tmp/ultraviolet-home/data XDG_CONFIG_HOME=/tmp/ultraviolet-home/config XDG_CACHE_HOME=/tmp/ultraviolet-home/cache godot --headless --path . --script tests/ultraviolet_growth_20261114/real_matrix.gd
```

最终结果以 REPORT.md 及日志为准；本文件不声称已通过、已上传或可整链恢复。
