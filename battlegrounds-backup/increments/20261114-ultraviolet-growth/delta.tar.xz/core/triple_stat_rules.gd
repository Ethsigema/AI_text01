extends RefCounted
## Designer triple rule: aggregate signed native deltas, then floor each stat
## at the independently sourced golden native value. No intermediate wrapping.
const MAX_STAT: int = 9223372036854775807
static func integer(value: Variant, minimum: int = 0) -> bool:
	return (value is int and value >= minimum) or (value is float and is_finite(value) and value >= minimum and value < 9223372036854775808.0 and value == floor(value))

static func plan(values: Array, normal_base: Variant, golden_base: Variant) -> Dictionary:
	var result: Dictionary = {"error":"","value":0,"net_bonus":0,"has_negative":false,"floored":false}
	if values.size() < 1 or values.size() > 3 or not integer(normal_base) or not integer(golden_base):
		result.error="三连属性需要1–3个安全整数来源和独立普通/金色原生值。";return result
	var positives: Array = []
	var negatives: Array = []
	for value in values:
		if not integer(value): result.error="三连来源属性必须为非负安全整数。";return result
		if int(value) >= int(normal_base): positives.append(int(value)-int(normal_base))
		else:
			negatives.append(int(normal_base)-int(value));result.has_negative=true
	# Cancel bounded magnitudes before summing; even a mathematically safe final
	# value must not wrap while summing large positive/negative intermediates.
	for n in range(negatives.size()):
		for p in range(positives.size()):
			var cancelled: int = mini(int(negatives[n]),int(positives[p]))
			negatives[n] -= cancelled;positives[p] -= cancelled
	var bonus: int = 0
	for amount in positives:
		if int(amount) > MAX_STAT-int(golden_base)-bonus:
			result.error="三连最终属性超出安全整数范围；原始实体必须保留。";return result
		bonus += int(amount)
	result.value=int(golden_base)+bonus;result.net_bonus=bonus
	result.floored=negatives.any(func(amount):return amount>0)
	return result

static func temporary_floor_error(originals: Array, normal: Dictionary, golden: Dictionary) -> String:
	if originals.any(func(unit):return unit.has("ultraviolet_play_growth_v1")): return "ultraviolet_growth_triple_inheritance_unverified"
	for stat in ["attack","health"]:
		var values: Array = []
		var temporary: int = 0
		for unit in originals:
			var amount: int = int(unit.get(stat,0))
			if stat == "attack": amount -= int(unit.get("permanent_tribe_applied",{}).get("attack",0))
			values.append(amount)
			for buff in unit.get("temporary_buffs",[]):
				var value: Variant = buff.get(stat,0)
				if not integer(value): return "三连临时属性记录无效。"
				if int(value) > MAX_STAT-temporary: return "三连临时属性合计超出安全范围。"
				temporary += int(value)
		var outcome: Dictionary = plan(values,normal.get(stat),golden.get(stat))
		if not str(outcome.error).is_empty(): return str(outcome.error)
		# A large temporary bonus can conceal every individual negative delta.
		# Check the eventual aggregate, not just today's visible native comparisons.
		if temporary>int(outcome.net_bonus):
			return "减益三连触及金色原生保底后，临时属性到期的结算尚未核实；请先等待临时效果到期，再取得第三张。"
	return ""
