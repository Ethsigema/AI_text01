extends RefCounted
const MawRetrigger=preload("res://core/maw_caster_retrigger.gd")
const SelflessSources=preload("res://core/selfless_portrait_sources.gd")
const TempDeath=preload("res://core/temporary_deathrattle_enchantments.gd")
const MegaGrants=preload("res://core/megasaur_adapt_grants.gd")
const GlobalCards = preload("res://core/bulk_global_card_stats.gd")
const NativeRecruit = preload("res://core/recruit_token_sources.gd")
## Final-source recruit event listeners. Keep source order in the host dispatcher.
const RecruitExtensions = preload("res://core/recruit_extensions.gd")
const NativeBattlecry = preload("res://core/battlecry_listener_sources.gd")
const BattlecryExecution = preload("res://core/native_recruit_battlecry_execution.gd")

const TARGETED_BATTLECRIES: Array = ["battlecry_native_sale_neighbor_split","battlecry_native_target_tier_replace","battlecry_discover_magnetize","battlecry_destroy_undead","battlecry_turn_counter_buff","battlecry_buy_count_buff","battlecry_control_count_buff","battlecry_buff", "battlecry_keyword", "battlecry_set", "battlecry_tier_buff", "battlecry_devour", "battlecry_blood_gem"]

const PLAY_BATTLECRY_TYPE: String = "on_play_battlecry_buff"
const PLAY_BATTLECRY_AMOUNTS: Dictionary = {"BG_AT_121":1, "TB_BaconUps_037":2}


# Existing listener validators plus source-exact Hangry condition.
static func validate_effect(effect: Dictionary) -> String:
	if effect.get("type")=="on_hand_added_deity_reserve": return preload("res://core/deity_hand_gain_sources.gd").effect_error(effect)
	if NativeRecruit.Thorn.effect_claimed(effect): return NativeRecruit.Thorn.effect_error(effect)
	if NativeRecruit.Peggy.effect_claimed(effect): return NativeRecruit.Peggy.effect_error(effect)
	if NativeRecruit.DeviousDrust.effect_claimed(effect): return NativeRecruit.DeviousDrust.effect_error(effect)
	if effect.has("requires_previous_win"): return NativeRecruit.effect_error(effect)
	# Scope-less Kalecgos programs retain their existing whole-tribe contract.
	var effect_type: Variant = effect.get("type")
	if not effect_type is String: return "战吼监听效果类型必须为字符串。"
	if effect_type == PLAY_BATTLECRY_TYPE:
		if effect.size() != 4 or not effect.get("scope") is String or effect.scope != "self": return "使用战吼牌监听仅支持完整自身程序。"
		for key in ["attack", "health"]:
			var value: Variant = effect.get(key)
			if not (value is int or value is float) or value not in [1, 2]: return "使用战吼牌监听需要独立原生的+1/+1或+2/+2。"
		if effect.attack != effect.health: return "使用战吼牌监听攻防增益必须相同。"
		return ""
	if effect_type != "on_battlecry_triggered_buff" or not effect.has("scope"): return ""
	var scope: Variant = effect.get("scope")
	if not scope is String: return "战吼监听范围必须为字符串。"
	if scope != "self" or effect.size() != 4: return "战吼监听仅支持显式自身范围和完整属性程序。"
	for key in ["attack", "health"]:
		var value: Variant = effect.get(key)
		if not (value is int or value is float) or value not in [1, 2]: return "自身战吼监听需要原生的+1/+1或+2/+2。"
	if effect.attack != effect.health: return "自身战吼监听属性必须与完整原生程序一致。"
	return ""


static func has_play_battlecry_effect(effects: Variant) -> bool:
	if effects is Array:
		for effect in effects:
			if effect is Dictionary and effect.get("type") is String and effect.type == PLAY_BATTLECRY_TYPE: return true
	return false


static func validate_play_battlecry_program(effects: Variant) -> String:
	if not has_play_battlecry_effect(effects): return ""
	if effects.size() != 1: return "人气选手必须只有一个完整的使用战吼牌自身程序。"
	return validate_effect(effects[0])


static func validate_play_battlecry_source(source: Dictionary) -> String:
	var effects: Variant = source.get("effects", [])
	var identity: Variant = source.get("card_id", source.get("id", ""))
	var known_source: bool = identity is String and PLAY_BATTLECRY_AMOUNTS.has(identity)
	if not known_source and not has_play_battlecry_effect(effects): return ""
	if not effects is Array or effects.size() != 1 or not effects[0] is Dictionary: return "人气选手缺少完整且唯一的使用战吼牌程序。"
	var effect_type: Variant = effects[0].get("type")
	if not effect_type is String or effect_type != PLAY_BATTLECRY_TYPE: return "人气选手缺少完整且唯一的使用战吼牌程序。"
	var issue: String = validate_play_battlecry_program(effects)
	if not issue.is_empty(): return issue
	var kind: Variant = source.get("kind", "minion")
	if not known_source or not kind is String or kind != "minion": return "使用战吼牌监听来源未经完整核实。"
	if effects[0].attack != PLAY_BATTLECRY_AMOUNTS[identity]: return "使用战吼牌监听数值与普通或金色独立来源不符。"
	return ""


static func handle_effect(engine, p: Dictionary, source: Dictionary, effect: Dictionary, _target: int = -1, _target_zone: String = "board") -> bool:
	if source.get("card_id",source.get("id")) in NativeRecruit.WIN_IDS or effect.has("requires_previous_win"):
		var issue: String = NativeRecruit.unit_error(source)
		if issue.is_empty(): issue = NativeRecruit.effect_error(effect)
		if issue.is_empty() and (source.get("effects",[]).size() != 1 or effect != source.effects[0]): issue = "hangry_source_call_mismatch"
		if not issue.is_empty():
			_fail(engine,issue)
			return true
		# False delegates one ordinary additive self buff to Game's existing path.
		return engine.state.get("phase") != "recruit" or not p.get("alive",false) or not p.get("board",[]).any(func(unit): return is_same(unit,source)) or p.get("last_combat_result","none") != "win"
	match str(effect.get("type", "")):
		"end_turn_elemental_buff":
			if not _on_board(p, source) or p.get("board", []).is_empty(): return true
			var count: int = 1 + maxi(0, int(p.get("recruit_elementals_played_turn", 0)))
			for _i in range(count):
				if p.board.is_empty(): break
				engine._buff(p.board[0], int(effect.get("attack", 0)), int(effect.get("health", 0)))
			return true
		"on_sell_loss_gold":
			# Complete native price is resolved before Game's one real sale payout.
			# A direct effect call cannot create a second supplemental income.
			_fail(engine,"loss_sale_requires_real_single_payment_host")
			return true
		"end_turn_steal_highest":
			if not _on_board(p, source): return true
			var lunder_ticket: Dictionary=engine.EfficientEngineer.LunderBridge.begin(engine,p,source,effect)
			if not lunder_ticket.ok: _fail(engine,str(lunder_ticket.error));return true
			for _i in range(int(effect.get("count", 1))):
				_steal_highest(engine, p)
				if lunder_ticket.get("active",false) and engine.state.phase=="error": return true
			var lunder_issue: String=engine.EfficientEngineer.LunderBridge.finish(engine,p,lunder_ticket)
			if not lunder_issue.is_empty(): _fail(engine,lunder_issue)
			return true
		"end_turn_adjacent_battlecries", "end_turn_all_battlecries":
			if not _on_board(p,source) or int(source.get("health",0))<=0 or source.get("silenced",false) or source.get("abilities_disabled",false): return true
			# This exploratory executor is NOT compiled into supported pools until
			# automatic targeted battlecries are specified. Fail closed on those.
			var adjacent: Array = p.board.duplicate() if effect.type=="end_turn_all_battlecries" else _adjacent(p, source)
			adjacent=adjacent.filter(func(unit):return int(unit.get("health",0))>0 and not unit.get("silenced",false) and not unit.get("abilities_disabled",false))
			for neighbor in adjacent:
				if not retrigger_is_supported(neighbor,p):
					_fail(engine, "小瞎眼指向战吼的自动目标规则尚未验证：" + str(neighbor.get("card_id", "")))
					return true
			for _i in range(int(effect.get("count", 1))):
				for neighbor in adjacent:
					if _on_board(p, neighbor) and not trigger_battlecry(engine, p, neighbor): return true
			return true
	return false


static func on_event(engine, p: Dictionary, event: String, context: Dictionary) -> void:
	if event in ["play_record","battlecry_listener","battlecry_triggered"]:
		var native_issue: String = NativeBattlecry.owner_error(engine,p)
		if not native_issue.is_empty():
			_fail(engine,native_issue)
			return
	match event:
		"start_turn": p.recruit_elementals_played_turn = 0
		"play_record":
			var played: Dictionary = context.get("played", context.get("unit", {}))
			if played.get("kind", "minion") == "minion" and _tribe(played, "元素"):
				p.recruit_elementals_played_turn = int(p.get("recruit_elementals_played_turn", 0)) + 1
			# Existing real-hand-play point: after entry, BEFORE the Battlecry group.
			# Do not reuse the after-play listener or the per-Battlecry event.
			if has_battlecry(played,p):
				var listeners: Array = []
				for listener in p.get("board", []).duplicate():
					if _same(listener, played): continue
					if not PLAY_BATTLECRY_AMOUNTS.has(listener.get("card_id", "")) and not has_play_battlecry_effect(listener.get("effects", [])): continue
					var issue: String = validate_play_battlecry_source(listener)
					if not issue.is_empty():
						_fail(engine, issue)
						return
					listeners.append(listener)
				for listener in listeners:
					if _on_board(p, listener): engine._buff(listener, int(listener.effects[0].attack), int(listener.effects[0].health))
		"combat_result":
			var result: String = str(context.get("result", "none"))
			if result in ["win", "loss", "tie", "none"]: p.last_combat_result = result
		"play_listener", "hand_added_listener", "battlecry_listener":
			var source: Dictionary = context.get("source", context.get("listener", {}))
			if event=="play_listener":
				var ultraviolet_issue: String=engine.Ultraviolet.on_play(engine,p,source,context.get("played",{}))
				if not ultraviolet_issue.is_empty():
					_fail(engine,ultraviolet_issue)
					return
			if event=="hand_added_listener" and engine.DeityHandGain.Sources.claimed(source):
				if str(context.get("phase",engine.state.get("phase","recruit"))) not in ["recruit","end_turn"]: return
				var deity_hand_issue: String=engine.DeityHandGain.received(engine,p,source,context.get("played",context.get("unit",context.get("card",{}))))
				if not deity_hand_issue.is_empty(): _fail(engine,deity_hand_issue)
				return
			# Validate this new native callback before the legacy UID comparison.
			if event == "hand_added_listener" and NativeRecruit.Thorn.claimed(source):
				if str(context.get("phase",engine.state.get("phase","recruit"))) not in ["recruit","end_turn"]: return
				var added: Dictionary = context.get("played",context.get("unit",context.get("card",{})))
				var thorn_issue: String = NativeRecruit.Thorn.recruit_source(engine,p,source,added)
				if not thorn_issue.is_empty(): _fail(engine,thorn_issue)
				return
			if event == "hand_added_listener" and NativeRecruit.Peggy.claimed(source):
				if str(context.get("phase",engine.state.get("phase","recruit"))) not in ["recruit","end_turn"]: return
				var added: Dictionary = context.get("played",context.get("unit",context.get("card",{})))
				var peggy_issue: String = NativeRecruit.Peggy.recruit_source(engine,p,source,added)
				if not peggy_issue.is_empty(): _fail(engine,peggy_issue)
				return
			if event == "hand_added_listener" and NativeRecruit.DeviousDrust.claimed(source):
				if str(context.get("phase",engine.state.get("phase","recruit"))) not in ["recruit","end_turn"]: return
				var added: Dictionary = context.get("played",context.get("unit",context.get("card",{})))
				var drust_issue: String = NativeRecruit.DeviousDrust.recruit_source(engine,p,source,added)
				if not drust_issue.is_empty(): _fail(engine,drust_issue)
				return
			if source.is_empty() or not _on_board(p, source): return
			var subject: Dictionary = context.get("played", context.get("unit", context.get("card", {})))
			# Combat-generated cards are awarded later to the real hand, but their
			# in-combat Peggy buffs must never leak onto the permanent recruit board.
			if event == "hand_added_listener" and str(context.get("phase", engine.state.get("phase", "recruit"))) not in ["recruit", "end_turn"]: return
			for effect in source.get("effects", []):
				match str(effect.get("type", "")):
					"on_play_deathrattle_buff":
						if event == "play_listener" and not _same(source, subject) and has_deathrattle(subject):
							engine._buff(source, int(effect.get("attack", 0)), int(effect.get("health", 0)))
					"on_hand_added_buff":
						if event != "hand_added_listener" or subject.is_empty(): continue
						var candidates: Array = []
						for unit in p.get("board", []):
							if not _same(source, unit) and _tribe(unit, str(effect.get("tribe", ""))): candidates.append(unit)
						if not candidates.is_empty():
							var target: Dictionary = candidates[engine._random(candidates.size(), "hand_added_pirate_buff")]
							engine._buff(target, int(effect.get("attack", 0)), int(effect.get("health", 0)))
					"on_battlecry_triggered_buff":
						if event != "battlecry_listener": continue
						if effect.has("scope"):
							# NEW implementation; the old Skyfin body was not recovered.
							# One self buff after each completed whole Battlecry activation.
							var issue: String = NativeBattlecry.unit_error(source)
							if issue.is_empty() and not p.board.any(func(unit): return is_same(unit,source)): issue = "battlecry_listener_detached_source"
							if not issue.is_empty():
								_fail(engine,issue)
								return
							if has_battlecry(subject,p): engine._buff(source,int(effect.attack),int(effect.health))
							continue
						# Scope-less Kalecgos keeps its old whole-tribe behavior.
						for unit in p.get("board", []).duplicate():
							if _tribe(unit, str(effect.get("tribe", ""))): engine._buff(unit, int(effect.get("attack", 0)), int(effect.get("health", 0)))
		"hand_added", "battlecry_triggered":
			if event=="battlecry_triggered":
				var fixed_completion_issue: String=engine.BattlecryStatCompletion.before(engine,p,context.get("unit",{}))
				if not fixed_completion_issue.is_empty(): _fail(engine,fixed_completion_issue);return
				var global_issue: String=GlobalCards.record(engine,p,"battlecries")
				if not global_issue.is_empty(): _fail(engine,global_issue); return
				engine._owned_recruit_battlecry_completed(p,context.get("unit",{}))
				if engine.state.phase=="error": return
			var listener_event: String = "hand_added_listener" if event == "hand_added" else "battlecry_listener"
			for source in p.get("board", []).duplicate():
				var child: Dictionary = context.duplicate()
				child.source = source
				on_event(engine, p, listener_event, child)
			if event=="battlecry_triggered" and engine.state.phase!="error":
				var fixed_completion_issue: String=engine.BattlecryStatCompletion.after(engine,p,context.get("unit",{}))
				if not fixed_completion_issue.is_empty(): _fail(engine,fixed_completion_issue)


static func has_battlecry(unit: Dictionary,player: Dictionary={}) -> bool:
	if SelflessSources.virtual(player,unit): return true
	for effect in unit.get("effects", []):
		if str(effect.get("type", "")).begins_with("battlecry_") and effect.get("type", "") != "battlecry_repeat": return true
	return false


static func has_deathrattle(unit: Dictionary) -> bool:
	if TempDeath.has_active(unit) or MegaGrants.has_active(unit): return true
	if unit.get("kind", "minion") != "minion": return false
	if "deathrattle" in unit.get("keywords", []): return true
	for effect in unit.get("effects", []):
		if str(effect.get("type", "")).begins_with("deathrattle_") and effect.get("type", "") != "deathrattle_repeat": return true
	return false


static func retrigger_is_supported(source: Dictionary,player: Dictionary={}) -> bool:
	if source.get("card_id") in ["BGS_031","TB_BaconUps_084"]: return false # Initial tranche requires an actual source-bound hand-play ticket; auto-retrigger ordering remains partial.
	if source.get("card_id")=="BG33_890t": return false # Taught spell needs an actual selected hand-play target.
	if source.get("card_id") in ["BG32_893","BG32_893_G"]: return false # Source refresh multiplier/retrigger order remains partial.
	if SelflessSources.virtual(player,source): return false
	if source.get("card_id") in ["BG34_926","BG34_926_G"]: return false # Actual hand minion-cast capability only.
	if source.get("card_id") in ["BG34_781","BG34_781_G"]: return false # New source-exact hand damage capability only.
	for effect in source.get("effects", []):
		if effect.get("type")=="battlecry_swap_attack_health": return false
		if effect.get("type")=="battlecry_selected_inplace_golden": return false
		if effect.get("type")=="battlecry_selected_undead_reborn": return false
		if effect.get("type")==MawRetrigger.Sources.BATTLECRY_TYPE and MawRetrigger.claimed(source) and MawRetrigger.Sources.unit_error(source).is_empty():
			continue # Actual target/repeat admission is owned by the private340 bridge.
		if effect.get("type", "") in TARGETED_BATTLECRIES and effect.get("scope", "target") == "target": return false
	return true


static func trigger_battlecry(engine, p: Dictionary, source: Dictionary, count: int = 1) -> bool:
	var replacements: Dictionary=engine.ShopReplaceRetrigger.begin(engine,p,source,count)
	if not replacements.ok: _fail(engine,str(replacements.error));return false
	var okay: bool=_trigger_battlecry_shop_replace_inner(engine,p,source,count)
	var issue: String=engine.ShopReplaceRetrigger.finish(engine,replacements,okay)
	if not issue.is_empty(): _fail(engine,issue);return false
	return okay

static func _trigger_battlecry_shop_replace_inner(engine, p: Dictionary, source: Dictionary, count: int = 1) -> bool:
	var discoveries: Dictionary=engine.PreviousPlainRetrigger.begin(engine,p,source,count)
	if not discoveries.ok: _fail(engine,str(discoveries.error));return false
	var okay: bool=_trigger_battlecry_previous_plain_inner(engine,p,source,count)
	var issue: String=engine.PreviousPlainRetrigger.finish(engine,discoveries,okay)
	if not issue.is_empty(): _fail(engine,issue);return false
	return okay

static func _trigger_battlecry_previous_plain_inner(engine, p: Dictionary, source: Dictionary, count: int = 1) -> bool:
	var discoveries: Dictionary=engine.DiscoverBattlecryRetrigger.begin(engine,p,source,count)
	if not discoveries.ok: _fail(engine,str(discoveries.error));return false
	var okay: bool=_trigger_battlecry_discover_inner(engine,p,source,count)
	var issue: String=engine.DiscoverBattlecryRetrigger.finish(engine,discoveries,okay)
	if not issue.is_empty(): _fail(engine,issue);return false
	return okay

static func _trigger_battlecry_discover_inner(engine, p: Dictionary, source: Dictionary, count: int = 1) -> bool:
	var minions: Dictionary=engine.RandomMinionBattlecry.begin(engine,p,source,count)
	if not minions.ok: _fail(engine,str(minions.error));return false
	var okay: bool=_trigger_battlecry_minion_inner(engine,p,source,count)
	var issue: String=engine.RandomMinionBattlecry.finish(engine,minions,okay)
	if not issue.is_empty(): _fail(engine,issue);return false
	return okay

static func _trigger_battlecry_minion_inner(engine, p: Dictionary, source: Dictionary, count: int = 1) -> bool:
	var refresh: Dictionary=engine.RefreshOwnerRetrigger.begin(engine,p,source,count)
	if not refresh.ok: _fail(engine,str(refresh.error));return false
	var okay: bool=_trigger_battlecry_refresh_owner_inner(engine,p,source,count)
	var issue: String=engine.RefreshOwnerRetrigger.finish(engine,refresh,okay)
	if not issue.is_empty(): _fail(engine,issue);return false
	return okay

static func _trigger_battlecry_refresh_owner_inner(engine, p: Dictionary, source: Dictionary, count: int = 1) -> bool:
	var reserve: Dictionary=engine.DeityReserveRetrigger.begin(engine,p,source,count)
	if not reserve.ok: _fail(engine,str(reserve.error));return false
	var okay: bool=_trigger_battlecry_deity_inner(engine,p,source,count)
	var issue: String=engine.DeityReserveRetrigger.finish(engine,reserve,okay)
	if not issue.is_empty(): _fail(engine,issue);return false
	return okay

static func _trigger_battlecry_deity_inner(engine, p: Dictionary, source: Dictionary, count: int = 1) -> bool:
	var sand: Dictionary=engine.SandSwirlerRetrigger.begin(engine,p,source,count)
	if not sand.ok: _fail(engine,str(sand.error));return false
	var okay: bool=_trigger_battlecry_sand_inner(engine,p,source,count)
	var issue: String=engine.SandSwirlerRetrigger.finish(engine,sand,okay)
	if not issue.is_empty(): _fail(engine,issue);return false
	return okay

static func _trigger_battlecry_sand_inner(engine, p: Dictionary, source: Dictionary, count: int = 1) -> bool:
	var owner_grants: Dictionary=engine.OwnerBattlecryLedger.begin(engine,p,source,count)
	if not owner_grants.ok: _fail(engine,str(owner_grants.error));return false
	var delayed_grants: Dictionary=engine.DelayedGoldRetrigger.begin(engine,p,source,count)
	if not delayed_grants.ok:
		engine.OwnerBattlecryLedger.finish(engine,owner_grants,false)
		_fail(engine,str(delayed_grants.error));return false
	var fixed_grants: Dictionary=engine.FixedResourceRetrigger.begin(engine,p,source,count)
	if not fixed_grants.ok:
		engine.DelayedGoldRetrigger.finish(engine,delayed_grants,false)
		engine.OwnerBattlecryLedger.finish(engine,owner_grants,false)
		_fail(engine,str(fixed_grants.error));return false
	var random_grants: Dictionary=engine.RandomSpellBattlecry.begin(engine,p,source,count)
	if not random_grants.ok:
		engine.FixedResourceRetrigger.finish(engine,fixed_grants,false)
		engine.DelayedGoldRetrigger.finish(engine,delayed_grants,false)
		engine.OwnerBattlecryLedger.finish(engine,owner_grants,false)
		_fail(engine,str(random_grants.error));return false
	var cost_grants: Dictionary=engine.NativeCostRetrigger.begin(engine,p,source,count)
	if not cost_grants.ok:
		engine.RandomSpellBattlecry.finish(engine,random_grants,false)
		engine.FixedResourceRetrigger.finish(engine,fixed_grants,false)
		engine.DelayedGoldRetrigger.finish(engine,delayed_grants,false)
		engine.OwnerBattlecryLedger.finish(engine,owner_grants,false)
		_fail(engine,str(cost_grants.error));return false
	var argent_grants: Dictionary=engine.ArgentBraggartRetrigger.begin(engine,p,source,count)
	if not argent_grants.ok:
		engine.NativeCostRetrigger.finish(engine,cost_grants,false)
		engine.RandomSpellBattlecry.finish(engine,random_grants,false)
		engine.FixedResourceRetrigger.finish(engine,fixed_grants,false)
		engine.DelayedGoldRetrigger.finish(engine,delayed_grants,false)
		engine.OwnerBattlecryLedger.finish(engine,owner_grants,false)
		_fail(engine,str(argent_grants.error));return false
	var okay: bool=_trigger_battlecry_body(engine,p,source,count)
	var argent_issue: String=engine.ArgentBraggartRetrigger.finish(engine,argent_grants,okay)
	if not argent_issue.is_empty():
		engine.NativeCostRetrigger.finish(engine,cost_grants,false)
		engine.RandomSpellBattlecry.finish(engine,random_grants,false)
		engine.FixedResourceRetrigger.finish(engine,fixed_grants,false)
		engine.DelayedGoldRetrigger.finish(engine,delayed_grants,false)
		engine.OwnerBattlecryLedger.finish(engine,owner_grants,false)
		_fail(engine,argent_issue);return false
	var cost_issue: String=engine.NativeCostRetrigger.finish(engine,cost_grants,okay)
	if not cost_issue.is_empty():
		engine.RandomSpellBattlecry.finish(engine,random_grants,false)
		engine.FixedResourceRetrigger.finish(engine,fixed_grants,false)
		engine.DelayedGoldRetrigger.finish(engine,delayed_grants,false)
		engine.OwnerBattlecryLedger.finish(engine,owner_grants,false)
		_fail(engine,cost_issue);return false
	var random_issue: String=engine.RandomSpellBattlecry.finish(engine,random_grants,okay)
	if not random_issue.is_empty():
		engine.FixedResourceRetrigger.finish(engine,fixed_grants,false)
		engine.DelayedGoldRetrigger.finish(engine,delayed_grants,false)
		engine.OwnerBattlecryLedger.finish(engine,owner_grants,false)
		_fail(engine,random_issue);return false
	var fixed_issue: String=engine.FixedResourceRetrigger.finish(engine,fixed_grants,okay)
	if not fixed_issue.is_empty():
		engine.DelayedGoldRetrigger.finish(engine,delayed_grants,false)
		engine.OwnerBattlecryLedger.finish(engine,owner_grants,false)
		_fail(engine,fixed_issue);return false
	var delayed_issue: String=engine.DelayedGoldRetrigger.finish(engine,delayed_grants,okay)
	if not delayed_issue.is_empty():
		engine.OwnerBattlecryLedger.finish(engine,owner_grants,false)
		_fail(engine,delayed_issue);return false
	var owner_grant_issue: String=engine.OwnerBattlecryLedger.finish(engine,owner_grants,okay)
	if not owner_grant_issue.is_empty(): _fail(engine,owner_grant_issue);return false
	return okay

static func _trigger_battlecry_body(engine, p: Dictionary, source: Dictionary, count: int = 1) -> bool:
	var native_issue: String = NativeBattlecry.owner_error(engine,p)
	if not native_issue.is_empty():
		_fail(engine,native_issue)
		return false
	if not has_battlecry(source,p): return true
	if not retrigger_is_supported(source,p):
		_fail(engine, "自动重触发指向战吼需要已验证目标规则。")
		return false
	var owned_execution: Dictionary=engine.Mechanisms.OwnedBattlecryCompletion.enter(engine,p,source,count)
	if not owned_execution.ok:
		_fail(engine,str(owned_execution.error))
		return false
	var felblood_multiplier: int=engine._battlecry_multiplier(p,source)
	var war_extra: Dictionary=engine.WarDrum.Sources.extra(p,int(engine.state.round),source)
	if not war_extra.ok: _fail(engine,str(war_extra.error));return false
	var total_programs: int=maxi(0,count)*felblood_multiplier-maxi(0,count-1)*int(war_extra.amount)
	var felblood_ticket: Dictionary=engine.FelbloodPortrait.prepare(engine,p,source,total_programs,"battlecry")
	if not felblood_ticket.ok: _fail(engine,str(felblood_ticket.error));return false
	var felemental_group: Dictionary=engine.FelementalPortrait.prepare_group(engine,p,source,total_programs,"actual_recruit_retrigger")
	if not felemental_group.ok: _fail(engine,str(felemental_group.error));return false
	for _activation in range(maxi(0, count)):
		var original_program: Array=BattlecryExecution.program(source.get("effects",[]))
		var multiplier: int = engine._battlecry_multiplier(p,source)
		if felblood_ticket.get("active",false) and multiplier!=felblood_multiplier-(int(war_extra.amount) if _activation>0 else 0): _fail(engine,"felblood_portrait_changed_outer_multiplier");return false
		if felemental_group.get("active",false) and multiplier!=felblood_multiplier-(int(war_extra.amount) if _activation>0 else 0): _fail(engine,"felemental_portrait_changed_outer_multiplier");return false
		var war_ticket: Dictionary=engine.WarDrum.begin(engine,p,source,multiplier,"retrigger")
		if not war_ticket.ok: _fail(engine,str(war_ticket.error));return false
		for _repeat in range(multiplier):
			for effect in original_program:
				if str(effect.get("type", "")).begins_with("battlecry_") and effect.get("type", "") != "battlecry_repeat":
					if felblood_ticket.get("active",false):
						if not engine._felblood_recruit_context.is_empty(): _fail(engine,"felblood_portrait_nested_battlecry_partial");return false
						engine._felblood_recruit_context=felblood_ticket
						var felblood_issue: String=engine.FelbloodPortrait.commit_leaf(engine,p,source,effect,felblood_ticket)
						engine._felblood_recruit_context={}
						if not felblood_issue.is_empty(): _fail(engine,felblood_issue);return false
					else:
						if not BattlecryExecution.dispatch_leaf(engine,p,source,effect,"actual_recruit_retrigger",felemental_group): return false
					if engine.state.get("phase","") == "error": return false
			# Private receipt is issued only after this actual whole program completed.
			var owned_completion_issue: String=engine.Mechanisms.OwnedBattlecryCompletion.before_completion(engine,p,source,owned_execution.ticket,_activation,_repeat,multiplier)
			if not owned_completion_issue.is_empty():
				_fail(engine,owned_completion_issue)
				return false
			# One event for the whole battlecry, not one per underlying DSL effect.
			on_event(engine, p, "battlecry_triggered", {"unit": source})
			if engine.state.get("phase","") == "error": return false
			var felemental_completion_issue: String=engine.FelementalPortrait.completed_group(engine,p,felemental_group)
			if not felemental_completion_issue.is_empty(): _fail(engine,felemental_completion_issue);return false
			var felblood_completion_issue: String=engine.FelbloodPortrait.completed(engine,p,felblood_ticket)
			if not felblood_completion_issue.is_empty(): _fail(engine,felblood_completion_issue);return false
		var war_finish: String=engine.WarDrum.finish(engine,p,source,war_ticket)
		if not war_finish.is_empty(): _fail(engine,war_finish);return false
	return true


static func _steal_highest(engine, p: Dictionary) -> void:
	var lunder_move: Dictionary=engine.EfficientEngineer.LunderBridge.begin_move(engine,p)
	if not lunder_move.ok: _fail(engine,str(lunder_move.error));return
	_steal_highest_body(engine,p,lunder_move)
	if lunder_move.get("active",false) and engine.state.phase=="error": return
	var lunder_issue: String=engine.EfficientEngineer.LunderBridge.finish_move(engine,p,lunder_move)
	if not lunder_issue.is_empty(): _fail(engine,lunder_issue);return
	engine._native_result(engine.TimewarpRecruitment.top_up(engine,p,"steal_highest"))

static func _steal_highest_body(engine, p: Dictionary, lunder_move: Dictionary) -> void:
	var timewarp_recruitment_remove_issue: String=engine.TimewarpRecruitment.remove_error(p,"native_acquisition")
	if not timewarp_recruitment_remove_issue.is_empty(): engine._native_result({"ok":false,"error":timewarp_recruitment_remove_issue});return
	if p.get("shop", []).is_empty(): return
	var highest: int = -1
	var candidates: Array = []
	for i in range(p.shop.size()):
		var tier: int = int(p.shop[i].get("tier", 0))
		if tier > highest:
			highest = tier
			candidates = [i]
		elif tier == highest: candidates.append(i)
	var index: int = int(candidates[engine._random(candidates.size(), "steal_highest_tavern_card")])
	var card: Dictionary = p.shop[index]
	var lunder_issue: String=engine.EfficientEngineer.LunderBridge.selected(engine,p,lunder_move,candidates,index,card)
	if not lunder_issue.is_empty(): _fail(engine,lunder_issue);return
	p.shop.remove_at(index)
	# Preserve a minion's owned pool copies. Tavern spells release theirs upon acquisition.
	engine._release_acquired_spell(card)
	RecruitExtensions.leave_shop(engine, card)
	lunder_issue=engine.EfficientEngineer.LunderBridge.left_shop(engine,p,lunder_move,card)
	if not lunder_issue.is_empty(): _fail(engine,lunder_issue);return
	engine._add_hand(p, card)
	if lunder_move.get("active",false) and engine.state.phase=="error": return
	lunder_issue=engine.EfficientEngineer.LunderBridge.delivered(engine,p,lunder_move,card)
	if not lunder_issue.is_empty(): _fail(engine,lunder_issue);return
	engine._check_triples(p)


static func _adjacent(p: Dictionary, source: Dictionary) -> Array:
	var result: Array = []
	for i in range(p.get("board", []).size()):
		if not _same(source, p.board[i]): continue
		if i > 0: result.append(p.board[i - 1])
		if i + 1 < p.board.size(): result.append(p.board[i + 1])
		break
	return result


static func _on_board(p: Dictionary, source: Dictionary) -> bool:
	for unit in p.get("board", []):
		if _same(source, unit): return true
	return false


static func _same(a: Dictionary, b: Dictionary) -> bool:
	return not a.is_empty() and not b.is_empty() and a.get("uid", "") == b.get("uid", "__missing")


static func _tribe(unit: Dictionary, tribe: String) -> bool:
	return tribe.is_empty() or tribe in unit.get("tribes", []) or "全部" in unit.get("tribes", []) or "all" in unit.get("tribes", [])


static func _fail(engine, message: String) -> void:
	engine.state.phase = "error"
	engine._log("unsupported_effect", {"message": message})
