extends RefCounted
## Exact native wildcard selection feeding the EXISTING three-parent merger.
## Selection priority and the mixed-stat equation are explicit local policy,
## not claims of an official priority or stat-folding specification.
const Sources=preload("res://core/surprise_elemental_sources.gd")
const Prefix=preload("res://core/recruit_prefix_cursor.gd")
const KEY: String="surprise_elemental_merge"
const POLICY: String="normal_same_target_first_owned_local_v1"
const STAT_POLICY: String="gold_base_target_buffs_plus_surprise_ordinary_local_v1"
const MAX: int=9007199254740991
static func fail(issue: String) -> Dictionary: return {"ok":false,"error":issue,"active":false}
static func elemental(unit: Dictionary) -> bool:
	return ["元素","全部","all"].any(func(tribe):return tribe in unit.get("tribes",[]))
static func wildcard(unit: Dictionary) -> bool:
	return unit.get("card_id")==Sources.IDS[0] and unit.get("golden")==false and not unit.get("silenced",false) and not unit.get("abilities_disabled",false)
static func mixed(id: String,parents: Array) -> bool:
	return id!=Sources.IDS[0] and parents.any(func(unit):return unit.get("card_id")==Sources.IDS[0])
static func counts(engine,player: Dictionary,incoming: Dictionary={}) -> Dictionary:
	var result: Dictionary={}
	var bodies: Array=player.board+player.hand
	if not incoming.is_empty(): bodies.append(incoming)
	for unit in bodies:
		if engine.HandLocks.Sources.marked(unit) or unit.get("card_id")==engine.Spellteach.Sources.CHILD: continue
		if unit.get("kind","minion")!="minion" or unit.get("golden",false): continue
		var id: String=str(unit.card_id)
		if not result.has(id): result[id]=[]
		result[id].append(unit)
	return result
static func select(engine,player: Dictionary,incoming: Dictionary={}) -> Dictionary:
	var result: Dictionary={"ok":true,"error":"","active":false,"normal_id":"","parents":[]}
	if engine.state.get("phase")!="recruit": return result
	var groups: Dictionary=counts(engine,player,incoming)
	# Existing complete ordinary triples retain their old priority and semantics.
	for id in groups:
		if groups[id].size()>=engine.triple_copies_required(player,engine.catalog.get_card(str(id))): return result
	var wild: Array=groups.get(Sources.IDS[0],[]).filter(func(unit):return wildcard(unit))
	if wild.is_empty(): return result
	# A normal Surprise substitutes for one missing copy of ONE target identity.
	# Two unrelated Elementals do not make a pair. Multiple matches use the
	# existing board-then-hand order, never RNG or an invented player choice.
	for id in groups:
		if id==Sources.IDS[0]: continue
		var native: Dictionary=engine.catalog.get_card(str(id))
		var target: Array=groups[id].filter(func(unit):return elemental(unit))
		var required: int=engine.triple_copies_required(player,native)
		if target.is_empty(): continue
		if groups[id].size()+wild.size()>=required and groups[id].any(func(unit):return not Sources.same(unit.get("tribes"),native.get("tribes"))): return fail("surprise_elemental_dynamic_type_intersection_partial")
		if target.size()+wild.size()<required: continue
		if not elemental(native): return fail("surprise_elemental_dynamic_type_intersection_partial")
		if required!=3: return fail("surprise_elemental_two_copy_rule_intersection_partial")
		result.parents=target.slice(0,mini(2,target.size()))
		result.parents.append_array(wild.slice(0,3-result.parents.size()))
		result.active=true;result.normal_id=id
		return result
	return result
static func axis(parts: Array,normal: Dictionary,golden: Dictionary,stat: String) -> Dictionary:
	var positives: Array=[];var negatives: Array=[];var temporary: int=0
	for unit in parts:
		var base: int=0 if unit.card_id==Sources.IDS[0] else int(normal.get(stat,0))
		var value: Variant=unit.get(stat)
		if not Sources.integer(value,0,MAX): return fail("surprise_elemental_noninteger_or_out_of_bound_stat")
		if int(value)>=base: positives.append(int(value)-base)
		else: negatives.append(base-int(value))
		for buff in unit.get("temporary_buffs",[]):
			if not Sources.integer(buff.get(stat),0,MAX-temporary): return fail("surprise_elemental_temporary_stat_bound")
			temporary+=int(buff[stat])
	for n in range(negatives.size()):
		for j in range(positives.size()):
			var cancel: int=mini(negatives[n],positives[j]);negatives[n]-=cancel;positives[j]-=cancel
	var bonus: int=0
	for amount in positives:
		if amount>MAX-int(golden[stat])-bonus: return fail("surprise_elemental_mixed_stat_overflow")
		bonus+=amount
	if temporary>bonus: return fail("surprise_elemental_temporary_floor_intersection_partial")
	return {"ok":true,"error":"","value":int(golden[stat])+bonus,"bonus":bonus}
static func prepare(engine,player: Dictionary,id: String,parents: Array) -> Dictionary:
	# Shared by ordinary and wildcard acquisition and actual merger paths.
	if parents.any(func(unit):return unit.has("ultraviolet_play_growth_v1")): return fail("ultraviolet_growth_triple_inheritance_unverified")
	var result: Dictionary={"ok":true,"error":"","active":mixed(id,parents)}
	if not result.active: return result
	var issue: String=Sources.closure_error(engine.catalog)
	if not issue.is_empty(): return fail(issue)
	if parents.size()!=3 or engine.state.phase!="recruit": return fail("surprise_elemental_exact_three_recruit_parents_required")
	if not engine._ordinary_triple_context.is_empty(): return fail("surprise_elemental_specialized_ordinary_projection_partial")
	var normal: Dictionary=engine.catalog.get_card(id)
	var golden: Dictionary=engine.catalog.get_card(str(normal.get("golden_id","")))
	if not normal.get("supported",false) or normal.get("is_golden")!=false or not elemental(normal) or not golden.get("supported",false) or golden.get("normal_id")!=id or golden.get("is_golden")!=true: return fail("surprise_elemental_actual_native_target_pair_required")
	if engine.triple_copies_required(player,normal)!=3: return fail("surprise_elemental_two_copy_rule_intersection_partial")
	var seen: Array=[];var surprise_count: int=0
	for unit in parents:
		if not unit.get("uid") is String or unit.uid.is_empty() or unit.uid in seen: return fail("surprise_elemental_distinct_parent_instances_required")
		seen.append(unit.uid)
		if unit.get("card_id") not in [id,Sources.IDS[0]] or unit.get("golden")!=false or not elemental(unit): return fail("surprise_elemental_same_target_normal_parent_required")
		if unit.card_id==Sources.IDS[0]:
			if not wildcard(unit): return fail("surprise_elemental_disabled_wildcard")
			surprise_count+=1
			issue=Sources.unit_error(unit)
			if not issue.is_empty(): return fail(issue)
		if unit.has(KEY) or not unit.get("pool_components",[]).is_empty(): return fail("surprise_elemental_recursive_stock_lineage_partial")
		if unit.get("health")!=unit.get("max_health") or not engine.GoldenRebase.eligible(unit): return fail("surprise_elemental_wounded_or_nonadditive_parent_partial")
		issue=engine.OrdinaryTriple._layers_error(engine,player,unit)
		if not issue.is_empty(): return fail("surprise_elemental_owner_layer_partial:"+issue)
		issue=engine.Magnetic.validation_error(engine.catalog,unit)
		if not issue.is_empty(): return fail(issue)
		var source: Dictionary=engine.catalog.get_card(str(unit.card_id))
		if not Sources.same(unit.get("tribes"),source.get("tribes")): return fail("surprise_elemental_dynamic_type_intersection_partial")
	if surprise_count not in [1,2]: return fail("surprise_elemental_one_or_two_substitutes_required")
	var guarded: Dictionary=engine.OrdinaryTriple._guards(engine,player,parents,normal,golden)
	if not guarded.ok: return fail("surprise_elemental_inheritance_partial:"+str(guarded.error))
	var stripped: Dictionary=engine.BoardAuraRebase.ordinary_units(parents,int(player.id))
	if not str(stripped.error).is_empty(): return fail(str(stripped.error))
	issue=engine.GlobalCards.strip_units(stripped.units)
	if not issue.is_empty(): return fail(issue)
	var attack: Dictionary=axis(stripped.units,normal,golden,"attack")
	if not attack.ok: return attack
	var health: Dictionary=axis(stripped.units,normal,golden,"health")
	if not health.ok: return health
	issue=engine.GlobalCards.triple_output_error(player,golden,int(attack.value),int(health.value))
	if not issue.is_empty(): return fail(issue)
	result.attack=attack;result.health=health;result.parents=parents;result.normal_id=id;result.golden_id=golden.id
	return result
static func inherit_stock(result: Dictionary,plan: Dictionary) -> void:
	if not plan.get("active",false): return
	# The target owns only its actual target copies; each wildcard keeps its
	# original stock identity. Never relabel a Surprise as a target pool copy.
	result.pool_count=0;result.pool_components=[]
	var provenance: Array=[]
	for unit in plan.parents:
		provenance.append({"uid":unit.uid,"card_id":unit.card_id,"pool_id":unit.get("pool_id",""),"pool_count":int(unit.get("pool_count",0))})
		if unit.card_id==plan.normal_id: result.pool_count+=int(unit.get("pool_count",0))
		elif int(unit.get("pool_count",0))>0:
			result.pool_components.append({"pool_id":Sources.IDS[0],"pool_kind":"minion","pool_count":int(unit.pool_count),"source_uid":unit.uid})
	result[KEY]={"host_uid":result.uid,"normal_id":plan.normal_id,"golden_id":plan.golden_id,"parents":provenance,"enchantment_id":"BG26_175e","selection_policy":POLICY,"stat_policy":STAT_POLICY}
static func ledger_error(unit: Dictionary,catalog=null) -> String:
	if not unit.get("pool_components",[]) is Array: return "surprise_elemental_invalid_stock_components"
	if not unit.has(KEY): return "" if unit.get("pool_components",[]).is_empty() else "surprise_elemental_unbound_pool_components"
	var proof: Variant=unit[KEY]
	if not proof is Dictionary or proof.size()!=7 or proof.get("host_uid")!=unit.get("uid") or proof.get("golden_id")!=unit.get("card_id") or unit.get("golden")!=true or proof.get("enchantment_id")!="BG26_175e" or proof.get("selection_policy")!=POLICY or proof.get("stat_policy")!=STAT_POLICY: return "surprise_elemental_stock_host_or_policy_changed"
	if not proof.get("parents") is Array or proof.parents.size()!=3 or not proof.get("normal_id") is String or proof.normal_id==Sources.IDS[0]: return "surprise_elemental_invalid_stock_lineage"
	var seen: Array=[];var wild: int=0;var own: int=0;var expected: Array=[]
	for parent in proof.parents:
		if not parent is Dictionary or parent.size()!=4 or not parent.get("uid") is String or parent.uid.is_empty() or parent.uid==unit.uid or parent.uid in seen or parent.get("card_id") not in [proof.normal_id,Sources.IDS[0]] or not Sources.integer(parent.get("pool_count"),0,1) or not parent.get("pool_id") is String: return "surprise_elemental_invalid_stock_parent"
		seen.append(parent.uid)
		if parent.pool_count>0 and parent.pool_id!=parent.card_id: return "surprise_elemental_parent_stock_identity_changed"
		if parent.card_id==Sources.IDS[0]:
			wild+=1
			if parent.pool_count>0: expected.append({"pool_id":Sources.IDS[0],"pool_kind":"minion","pool_count":parent.pool_count,"source_uid":parent.uid})
		else: own+=int(parent.pool_count)
	if wild not in [1,2] or unit.get("pool_count",0)!=own or unit.get("pool_id")!=proof.normal_id or not Sources.same(unit.get("pool_components",[]),expected): return "surprise_elemental_stock_components_changed"
	if catalog!=null:
		var normal: Dictionary=catalog.get_card(proof.normal_id)
		var golden: Dictionary=catalog.get_card(proof.golden_id)
		if not normal.get("supported",false) or not golden.get("supported",false) or normal.get("golden_id")!=proof.golden_id or golden.get("normal_id")!=proof.normal_id or not elemental(normal): return "surprise_elemental_stock_native_target_changed"
	return ""
static func stock_returns(unit: Dictionary) -> Array:
	if not unit.has(KEY) or not ledger_error(unit).is_empty(): return []
	var result: Array=[]
	for component in unit.get("pool_components",[]):
		result.append({"pool_id":component.pool_id,"pool_kind":"minion","pool_count":int(component.pool_count)})
	return result
static func stock_total(engine) -> int:
	var total: int=int(engine.pool.get(Sources.IDS[0],0))
	for player in engine.state.players:
		for unit in player.get("board",[])+player.get("hand",[])+player.get("shop",[]):
			if unit.get("pool_id")==Sources.IDS[0]: total+=int(unit.get("pool_count",0))
			for component in stock_returns(unit): total+=int(component.pool_count)
	return total
static func command_preflight(engine,player_id: int,command: Dictionary) -> String:
	if engine.state.get("phase")!="recruit" or player_id<0 or player_id>=engine.state.players.size(): return ""
	# A detached complete-command preview is already active. Never nest one or
	# issue a live receipt/capability in a disposable view.
	for property in engine.get_property_list():
		var name: String=str(property.name)
		if name.ends_with("_projecting") and engine.get(name)==true: return ""
	var needed: bool=Sources.IDS.any(func(id):return id in engine.room.get("enabled_minions",[]))
	for player in engine.state.players:
		for unit in player.get("board",[])+player.get("hand",[])+player.get("shop",[]):
			needed=needed or Sources.claimed(unit) or unit.has(KEY)
			var issue: String=ledger_error(unit,engine.catalog)
			if not issue.is_empty(): return issue
	if not needed: return ""
	var p: Dictionary=engine.state.players[player_id]
	# A consumed wildcard's ownership must not be lost by a foreign Magnetic
	# host clearing components, or duplicated by an unbridged entity copy.
	if command.get("type")=="magnetize" and (p.board+p.hand).any(func(unit):return unit.has(KEY)): return "surprise_elemental_magnetic_stock_migration_partial"
	var cursor: Dictionary={"player":p.duplicate(true),"totals":engine._attack_gain_health_totals.duplicate(true),"next_uid":engine.next_uid,"rng_seed":engine.rng.seed,"rng_state":engine.rng.state,"pool":engine.pool.duplicate(true),"spell_pool":engine.spell_pool.duplicate(true)}
	var detached: Dictionary=Prefix.create(engine,cursor)
	if not detached.ok: return str(detached.error)
	var shadow=detached.engine
	for property in shadow.get_property_list():
		var name: String=str(property.name)
		if name.ends_with("_projecting") and shadow.get(name) is bool: shadow.set(name,true)
	var outcome: Dictionary=shadow.apply_command(player_id,command.duplicate(true))
	if not outcome.get("ok",false) or shadow.state.phase=="error": return "surprise_elemental_complete_command_preflight:"+str(outcome.get("error",shadow.state.get("error","unknown")))
	if stock_total(shadow)!=stock_total(engine): return "surprise_elemental_stock_conservation_partial"
	for player in shadow.state.players:
		for unit in player.get("board",[])+player.get("hand",[])+player.get("shop",[]):
			var issue: String=ledger_error(unit,engine.catalog)
			if not issue.is_empty(): return "surprise_elemental_copy_or_transform_stock_partial:"+issue
	return ""
