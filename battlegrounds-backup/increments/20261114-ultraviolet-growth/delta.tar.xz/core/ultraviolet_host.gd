extends RefCounted
const Normal=preload("res://core/patch_3702_ultraviolet_sources.gd")
const Golden=preload("res://core/patch_3702_ultraviolet_golden_sources.gd")
const Gains=preload("res://core/attack_gain_listeners.gd")
const MODE="ultraviolet_verified_base"
const GROWTH="ultraviolet_play_growth_v1"
const MAX_PLAYS: int=1000000
const IDS=["BG31_810","BG31_810_G"]
static func whole(value: Variant,minimum: int,maximum: int) -> bool:
	return (value is int or value is float) and not value is bool and is_finite(float(value)) and value==floor(value) and value>=minimum and value<=maximum
static func program(id: String) -> Array:
	return [{"type":"start_combat_stats","mode":MODE,"source_id":id,"attack":8 if id==IDS[1] else 4,"health":8 if id==IDS[1] else 4}] if id in IDS else []
static func effect_error(effect: Dictionary) -> String:
	var id: String=str(effect.get("source_id",""))
	return "" if id in IDS and Normal.same(effect,program(id)[0]) else "ultraviolet_changed_effect"
static func unit_error(unit: Dictionary) -> String:
	var id: String=str(unit.get("card_id",unit.get("id","")))
	var marker: bool=unit.get("effects",[]).any(func(effect):return effect.get("mode")==MODE)
	if id not in IDS: return "ultraviolet_unbound_effect" if marker or unit.has(GROWTH) else ""
	if not Normal.same(unit.get("effects"),program(id)): return "ultraviolet_changed_program"
	if unit.has(GROWTH):
		var growth: Variant=unit[GROWTH]
		if not growth is Dictionary or growth.size()!=3 or growth.get("uid")!=unit.get("uid"): return "ultraviolet_changed_growth_identity"
		if not whole(growth.get("plays"),1,MAX_PLAYS): return "ultraviolet_invalid_growth_count"
		if not whole(growth.get("sequence"),0,9007199254740991): return "ultraviolet_invalid_growth_sequence"
	return ""
static func elemental(unit: Dictionary) -> bool:
	return unit.get("kind","minion")=="minion" and unit.get("tribes",[]).any(func(tribe):return tribe in ["元素","全部","all"])
static func magnetic_error(player: Dictionary,played: Dictionary) -> String:
	if elemental(played) and player.get("board",[]).any(func(u):return u.get("card_id") in IDS and Gains.active(u)): return "ultraviolet_elemental_magnetize_growth_unverified"
	return ""
static func play_error(engine,player: Dictionary,played: Dictionary) -> String:
	for source in player.get("board",[]):
		if source.get("card_id") in IDS and Gains.active(source):
			var canonical=engine.catalog.source_catalog if engine.catalog.source_catalog!=null else engine.catalog
			var issue: String=Normal.source_error(canonical.get_card(source.card_id)) if source.card_id==IDS[0] else Golden.source_error(canonical.get_card(source.card_id))
			if issue.is_empty(): issue=unit_error(source)
			if not issue.is_empty(): return issue
			if elemental(played) and int(source.get(GROWTH,{}).get("plays",0))>=MAX_PLAYS: return "ultraviolet_growth_capacity_exceeded"
			if elemental(played) and source.has(GROWTH) and int(source[GROWTH].sequence)>=int(engine.state.command_sequence): return "ultraviolet_growth_sequence_not_before_command"
	return ""
# Called only at the original Game after-hand-play source dispatch. No summon,
# acquisition, battlecry repeat, self-play, or hand-only source increments this.
static func on_play(engine,player: Dictionary,source: Dictionary,played: Dictionary) -> String:
	if source.get("card_id") not in IDS or not Gains.active(source) or not elemental(played): return ""
	if source.get("uid")==played.get("uid"): return ""
	var context: Dictionary=engine._mechagnome_recipient_context
	if context.get("origin")!="play" or not is_same(context.get("owner"),player) or not is_same(context.get("actor"),played): return "ultraviolet_actual_hand_play_context_required"
	if engine.state.get("phase")!="recruit" or not player.get("alive",false): return "ultraviolet_actual_recruit_required"
	if not player.board.any(func(u):return is_same(u,source)) or not player.board.any(func(u):return is_same(u,played)): return "ultraviolet_actual_play_units_required"
	# Earlier listeners may already have advanced. Revalidate only this source,
	# not the whole pre-event capacity plan against a partly committed board.
	var issue: String=unit_error(source)
	var canonical=engine.catalog.source_catalog if engine.catalog.source_catalog!=null else engine.catalog
	if issue.is_empty(): issue=Normal.source_error(canonical.get_card(source.card_id)) if source.card_id==IDS[0] else Golden.source_error(canonical.get_card(source.card_id))
	if not issue.is_empty(): return issue
	var previous: Dictionary=source.get(GROWTH,{})
	if int(previous.get("plays",0))>=MAX_PLAYS: return "ultraviolet_growth_capacity_exceeded"
	if previous.get("sequence",-1)==engine.state.command_sequence: return "ultraviolet_duplicate_play_dispatch"
	var count: int=int(previous.get("plays",0))+1
	source[GROWTH]={"uid":source.uid,"plays":count,"sequence":engine.state.command_sequence}
	engine._log("ultraviolet_elemental_play_growth",{"player":player.id,"source_uid":source.uid,"played_uid":played.uid,"plays":count,"buff":int(program(source.card_id)[0].attack)*(count+1)})
	return ""
static func buff_amount(source: Dictionary,effect: Dictionary) -> int:
	return int(effect.attack)*(1+int(source.get(GROWTH,{}).get("plays",0)))
static func activate(engine,side: int,source: Dictionary,effect: Dictionary) -> void:
	var issue: String=unit_error(source)
	if issue.is_empty(): issue=effect_error(effect)
	if not issue.is_empty() or effect.get("source_id")!=source.get("card_id"):
		engine._fail(issue if not issue.is_empty() else "ultraviolet_source_mismatch");return
	if not Gains.active(source): return
	if side not in [0,1] or not engine._boards[side].any(func(unit):return is_same(unit,source)):
		engine._fail("ultraviolet_requires_actual_board_source");return
	var amount: int=buff_amount(source,effect)
	var targets: Array=engine._boards[side].filter(func(unit):return unit.get("uid")!=source.get("uid") and int(unit.get("health",0))>0 and elemental(unit))
	for unit in targets:
		if not engine.StartCombatEffects.buff_fits(unit,amount,amount):
			engine._fail("ultraviolet_buff_overflow");return
	if not engine._tick(MODE): return
	for target in targets:
		engine._apply_trigger_buff(source,target,{"attack":amount,"health":amount},MODE,str(source.uid))
		if not engine._error.is_empty(): return
	engine._emit("ultraviolet_base_buff",{"side":side,"source":source.uid,"source_id":source.card_id,"targets":targets.map(func(unit):return unit.uid),"attack":amount,"health":amount})
static func legal_actions(engine,player_id: int,commands: Array) -> Array:
	if engine.state.is_empty() or player_id<0 or player_id>=engine.state.players.size(): return commands
	var player: Dictionary=engine.state.players[player_id]
	return commands.filter(func(command):
		if command.get("type")=="magnetize":
			var magnetic_index: int=int(command.get("index",-1))
			return magnetic_index<0 or magnetic_index>=player.hand.size() or magnetic_error(player,player.hand[magnetic_index]).is_empty()
		if command.get("type")!="play": return true
		var index: int=int(command.get("index",-1))
		return index<0 or index>=player.hand.size() or play_error(engine,player,player.hand[index]).is_empty()
	)
