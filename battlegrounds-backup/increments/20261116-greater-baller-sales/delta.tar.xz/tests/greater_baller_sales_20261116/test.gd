extends SceneTree
const Host=preload("res://core/greater_baller_portrait.gd")
var cat
var game
var checks=0
func check(ok:bool,label:String)->bool:
 checks+=1;print("PASS " if ok else "FAIL ",label)
 if not ok:quit(1)
 return ok
func _initialize():
 cat=load("res://core/catalog.gd").new();cat.load_catalog()
 if not check(cat.load_errors.is_empty(),"catalog"):print(cat.load_errors);return
 for family in ["fire","snow"]:
  if not run_family(family):return
 print("PASS TOTAL ",checks);quit(0)
func run_family(family:String)->bool:
 game=load("res://core/game.gd").new()
 var room=load("res://core/room_config.gd").new();room.reset(cat)
 room.data.enabled_minions=["BGS_119","BG31_816","BG31_818"];room.data.enabled_spells=["BG28_810"];room.data.selected_hero="TB_BaconShop_HERO_01";room.data.enabled_heroes=["TB_BaconShop_HERO_01"];room.data.bot_count=1;room.data.seed=20261116
 for k in ["enabled_anomalies","enabled_quests","enabled_rewards","enabled_trinkets"]:room.data[k]=[]
 if not check(game.start(room.data,cat).get("ok",false),family+"_real_room"):return false
 var p=game.state.players[0];p.gold=10;p.board=[]
 var offer=cat.get_card(Host.ID).duplicate(true);offer.choice_kind="trinket";p.discover=[offer]
 var r=game.apply_command(0,{"type":"discover","index":0})
 if not check(r.get("ok",false),family+"_acquisition"):print(r);return false
 r=game.apply_command(0,{"type":"play","index":0})
 if not check(r.get("ok",false) and p.hand.size()==2,family+"_reward_spell"):print(r);return false
 var seller="BG31_816" if family=="fire" else "BG31_818"
 var other="BG31_818" if family=="fire" else "BG31_816"
 # Play both actual spell rewards, preserving native order.
 for n in range(2):
  r=game.apply_command(0,{"type":"play","index":0})
  if not check(r.get("ok",false),family+"_actual_child_play"):print(r);return false
 var recipient=p.board.filter(func(u):return u.card_id==other)[0]
 var attack=recipient.attack;var health=recipient.health;var gold=p.gold
 var progress=p.mechanism_state[Host.key()]
 var ix=0 if family=="fire" else 1
 r=game.apply_command(0,{"type":"sell","index":ix})
 if not check(r.get("ok",false),family+"_actual_first_sale"):print(r);return false
 if not check(p.gold==gold+1 and p.stats.sold==1 and p.board.size()==1,family+"_sale_accounting"):return false
 if not check(recipient.attack==attack+(1 if family=="fire" else 0) and recipient.health==health+(1 if family=="snow" else 0),family+"_actual_first_payoff"):return false
 if not check(p.mechanism_state[Host.key()]==progress and p.hand.is_empty(),family+"_sale_does_not_count_element_play"):return false
 # Explicit fixture: another same-family minion enters hand; actual play/sale commands follow.
 p.hand.append(game._unit(cat.get_card(seller)))
 r=game.apply_command(0,{"type":"play","index":0})
 if not check(r.get("ok",false),family+"_second_play"):print(r);return false
 progress=p.mechanism_state[Host.key()]
 r=game.apply_command(0,{"type":"sell","index":1})
 if not check(r.get("ok",false) and p.stats.sold==2 and p.gold==gold+2,family+"_second_sale"):print(r);return false
 if not check(recipient.attack==attack+(3 if family=="fire" else 0) and recipient.health==health+(3 if family=="snow" else 0),family+"_same_family_growth"):return false
 if not check(p.mechanism_state[Host.key()]==progress,family+"_second_sale_counter_unchanged"):return false
 var before=p.duplicate(true)
 r=game.apply_command(0,{"type":"sell","index":0})
 if not check(not r.get("ok",true) and p==before,family+"_mixed_history_still_atomic_hold"):print(r);return false
 p.hand=[game._unit(cat.get_card(seller))]
 r=game.apply_command(0,{"type":"play","index":0})
 if not check(r.get("ok",false),family+"_third_play"):return false
 p.trinkets.append(Host.ID)
 before=p.duplicate(true);r=game.apply_command(0,{"type":"sell","index":1})
 if not check(not r.get("ok",true) and p==before,family+"_duplicate_portrait_atomic_hold"):return false
 p.trinkets=[Host.ID];p.board[1].effects[0].attack=999
 before=p.duplicate(true);r=game.apply_command(0,{"type":"sell","index":1})
 if not check(not r.get("ok",true) and p==before,family+"_tampered_source_atomic_hold"):return false
 return true
