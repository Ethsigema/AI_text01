from pathlib import Path
import json,hashlib,csv
base=Path('greater_baller_sales_backup_20261116/postupload/fresh_restore/project')
out=Path('pool_reconcile_20261116/research/pool_reconcile_20261116')
cp=base/'research/trinket_scope_inventory_20261114/candidate_inventory.json';ap=base/'research/hsbg_api_comparison_20261115/COMPARISON.json'
candidate=json.loads(cp.read_text());comparison=json.loads(ap.read_text());raw=json.loads((base/'data/catalog_raw.json').read_text())['cards'];bycode={c['id']:c for c in raw}
forum='https://us.forums.blizzard.com/en/hearthstone/t/battlegrounds-season-14-trinket-updates/163710'
p3702='https://hearthstone.blizzard.com/en-us/news/24307311';p3622='https://hearthstone.blizzard.com/en-us/news/24293284'
removals={'112397:greater','115253:greater','120864:lesser','134321:greater'}
rows=[]
for c in comparison['candidate_only']:
 row={k:c[k] for k in ['key','card_id','tier','name_en','card_codes']}
 row.update(candidate_present=True,community_current_present=False,completed=None,current_pool_verified=False)
 if c['key'] in removals:
  row.update(primary_event='removed_37.0.2',primary_url=p3702,decision='keep_out_of_latest_pool_unless_subsequent_authoritative_return; already known removal, not new progress')
 else:
  row.update(primary_event='listed_new_or_staying_at_36.2',primary_url=forum,decision='retain_candidate; community absence is not removal evidence')
 if c['name_en']=='Training Certificate':row.update(later_primary_event='Lesser cost changed 3 to 4 in 37.0.2',later_primary_url=p3702)
 rows.append(row)
sphere=bycode['BG36_MagicItem_372'];assert sphere['dbf_id']=='133712' and sphere['category']=='大型饰品'
sphere_row={'key':'133712:greater','card_id':133712,'tier':'greater','name_en':'Sphere of Memory','card_codes':['BG36_MagicItem_372'],'candidate_present':False,'community_current_present':True,'completed':None,'current_pool_verified':False,'primary_event':'new_Greater_at_36.2_and_text_updated_to_3_copies_at_36.2.2','primary_url':forum,'later_primary_url':p3622,'decision':'add_missing_candidate_with_primary_season_and_later_balance_evidence; not a verified current denominator','identity_workbook':sphere['provenance']}
rows.append(sphere_row)
# Derivative ledger, never overwrite historical evidence. All 263 old identities retained.
ledger=json.loads(json.dumps(candidate));ledger['cards'].append({'key':'133712:greater','card_id':133712,'tier':'greater','name_en':'Sphere of Memory','name_zh_candidates':['记忆之球'],'card_codes':['BG36_MagicItem_372'],'membership':'primary_season_candidate_latest_status_not_exhaustively_verified','completed':None,'primary_evidence':[forum,p3622]})
ledger.update(candidate_rows=len(ledger['cards']),full_inventory_verified=False,denominator=None,completed_count=None,derived_from_sha256=hashlib.sha256(cp.read_bytes()).hexdigest(),scope_note='264 is only derivative candidate rows, includes known removals. Not active pool total. Three official-conflict identities remain separately unresolved.')
assert len({x['key'] for x in ledger['cards']})==len(ledger['cards'])==264
spells=[]
for code,en in [('BG28_888','Misplaced Tea Set'),('BG28_838','Perfect Vision'),('BG34_990','Wave of Gold'),('BG28_845','Natural Blessing')]:
 c=bycode[code];spells.append({'card_code':code,'dbf_id':c['dbf_id'],'name_en':en,'name_zh':c['name'],'kind':c['kind'],'identity_source':'existing workbook raw row, crosschecked against saved secondary row','official_patch':p3702,'event':'balance_change_not_pool_addition_or_removal','completed':None})
summary={'base_commit':'a8c772876ffcda63d0e3cf8f119bb416e195ac5f','base_receipt':'2585d46c35d837efa81226ce4f1f73aab68c9412','research_only':True,'targeted_trinket_rows':22,'already_known_official_removals_rechecked':4,'candidate_only_not_proven_removed':17,'new_primary_supported_candidate':sphere_row,'derivative_candidate_rows':264,'current_pool_denominator':None,'completed_count':None,'official_conflict_identities':[{'card_code':'BG35_MagicItem_151','dbf_id':131278,'tier':'lesser'},{'card_code':'BG35_MagicItem_151t','dbf_id':131277,'tier':'greater'},{'card_code':'BG30_MagicItem_944','dbf_id':117858,'tier':'greater'}],'secondary_source_caveats':['hsbg.cards aggregate counts and dates are not authoritative','saved community current API absence cannot establish removal','source page repeats rendered and structured listings; do not double count','Training Certificate has current official Lesser balance notice despite absence from community snapshot'],'not_done':['full subsequent hotfix/return ledger for every candidate','official current membership conflict resolution','complete active pool denominator','per-card gameplay acceptance']}
for name,obj in [('TARGETED_LEDGER.json',rows),('DERIVED_CANDIDATES.json',ledger),('SPELL_IDENTITIES.json',spells),('SUMMARY.json',summary)]: (out/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
with (out/'TARGETED_LEDGER.csv').open('w',newline='') as f:
 w=csv.writer(f);w.writerow(['stable_key','code','name','size','primary_event','decision'])
 for row in rows:w.writerow([row['key'],';'.join(row['card_codes']),row['name_en'],row['tier'],row['primary_event'],row['decision']])
(out/'INPUT_SHA256.json').write_text(json.dumps({str(f.relative_to(base)):hashlib.sha256(f.read_bytes()).hexdigest() for f in [cp,ap,base/'data/catalog_raw.json']},indent=2)+'\n')
print('22 targeted trinkets, 264 derivative candidate rows, 4 spell identity checks; denominator remains null')
