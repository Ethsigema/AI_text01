extends SceneTree
const Air=preload("res://core/air_baller_host.gd")
const Fire=preload("res://core/fire_baller_host.gd")
const Snow=preload("res://core/snow_baller_host.gd")
const Inert=preload("res://core/baller_inert_sale.gd")
var cat
var game
var checks=0
func check(ok: bool,label: String)->bool:
 checks+=1;print("PASS " if ok else "FAIL ",label)
 if not ok:quit(1)
 return ok
func setup()->bool:
 game=load("res://core/game.gd").new()
 var room=load("res://core/room_config.gd").new();room.reset(cat)
 room.data.enabled_minions=["BG31_818","BGS_119","BG31_330"]
 room.data.enabled_spells=["BG28_810"];room.data.selected_hero="TB_BaconShop_HERO_01";room.data.enabled_heroes=["TB_BaconShop_HERO_01"];room.data.bot_count=1;room.data.seed=20261116
 for key in ["enabled_anomalies","enabled_quests","enabled_rewards","enabled_trinkets"]:room.data[key]=[]
 return check(game.start(room.data,cat).get("ok",false),"real_room")
func run_case(family,bone: String,golden: bool)->bool:
 if not setup():return false
 var p=game.state.players[0];var target=game._unit(cat.get_card("BGS_119"));p.board=[target]
 var base_a=target.attack;var base_h=target.health;var a=0;var h=0
 for step in range(3):
  var b=game._unit(cat.get_card(bone));p.board.append(b)
  var before=p.duplicate(true);var uid=game.next_uid;var gold=p.gold
  if not check(Inert.recognized(game,p,b) and not family.prepare_ordinary(game,p,b).is_empty() and p==before,"exact_inert_preflight"):print(Inert.Skeletons.source_error(cat.get_card(bone)));return false
  var result=game.apply_command(0,{"type":"sell","index":1})
  if not check(result.get("ok",false),"bone_sale"):print(result);return false
  if not check(p.board.size()==1 and is_same(p.board[0],target) and game.next_uid==uid,"no_skeletons_generated"):return false
  if not check(p.gold==gold+1 and p[family.CHAIN].ordinary_sales==step+1,"one_income_ordinary_only"):return false
  var id=family.IDS[1 if golden else 0];var u=game._unit(cat.get_card(id));p.board.append(u)
  var payoff=family.amount(p,u)
  if not check(payoff==(step+1)*int(family.program(id)[0].health if family==Snow else family.program(id)[0].attack),"bone_does_not_grow_payoff"):return false
  result=game.apply_command(0,{"type":"sell","index":1})
  if not check(result.get("ok",false),"subsequent_actual_baller_sale"):print(result);return false
  if family!=Snow:a+=payoff
  if family!=Fire:h+=payoff
  if not check(target.attack==base_a+a and target.health==base_h+h and p.stats.sold==(step+1)*2,"exact_growth_and_total"):return false
  if not check(not game.state.players[1].has(family.CHAIN),"owner_isolation"):return false
 return true
func negatives()->bool:
 if not setup():return false
 var p=game.state.players[0];var u=game._unit(cat.get_card("BG28_300"));p.board=[u]
 for family in [Air,Fire,Snow]:
  var snapshot=u.duplicate(true)
  u.effects[0].count=99
  if not check(family.prepare_ordinary(game,p,u).is_empty(),"changed_count_rejected"):return false
  u.clear();u.merge(snapshot.duplicate(true),true);u.effects[0].unit.attack=2
  if not check(family.prepare_ordinary(game,p,u).is_empty(),"changed_token_rejected"):return false
  u.clear();u.merge(snapshot.duplicate(true),true);u.effects.append({"type":"on_sell_gold","amount":1})
  if not check(family.prepare_ordinary(game,p,u).is_empty(),"additional_effect_rejected"):return false
  u.clear();u.merge(snapshot.duplicate(true),true);u.attachments=[{"card_id":"fake"}]
  if not check(family.prepare_ordinary(game,p,u).is_empty(),"attachment_rejected"):return false
  u.clear();u.merge(snapshot.duplicate(true),true);p.stats.sold=1
  if not check(family.prepare_ordinary(game,p,u).is_empty(),"unknown_history_not_repaired"):return false
  p.stats.sold=0;p.trinkets=["fake"]
  if not check(family.prepare_ordinary(game,p,u).is_empty(),"owned_trinket_rejected"):return false
  p.trinkets=[]
 var body=u.duplicate(true)
 for pair in [["kind","spell"],["golden",true],["attachments",7],["base_unit",{}]]:
  u[pair[0]]=pair[1]
  if not check(not Inert.recognized(game,p,u),"invalid_body_"+str(pair[0])):return false
  u.clear();u.merge(body.duplicate(true),true)
 for key in ["hero_identity_id","hero_identity_portrait","hero_power_replacement_history"]:
  p[key]="fixture"
  if not check(not Inert.recognized(game,p,u),"replaced_hero_"+key):return false
  p.erase(key)
 p.hero_id="other"
 if not check(not Inert.recognized(game,p,u),"other_hero"):return false
 p.hero_id="TB_BaconShop_HERO_01"
 for key in ["active_quest","reward_active","trinkets"]:
  var other=game.state.players[1];var old=other.get(key,{} if key=="active_quest" else [])
  other[key]={"fixture":true} if key=="active_quest" else ["fixture"]
  if not check(not Inert.recognized(game,p,u),"opponent_owned_"+key):return false
  other[key]=7
  if not check(not Inert.recognized(game,p,u),"malformed_owned_"+key):return false
  other[key]=old
 var before=p.duplicate(true)
 if not check(not game.apply_command(0,{"type":"sell","index":99}).get("ok",true) and p==before,"failed_command_no_history"):return false
 return true
func _initialize():
 cat=load("res://core/catalog.gd").new();cat.load_catalog()
 if not check(cat.load_errors.is_empty(),"catalog"):print(cat.load_errors);return
 for family in [Air,Fire,Snow]:
  for bone in Inert.IDS:
   for golden in [false,true]:
    if not run_case(family,bone,golden):return
 if not negatives():return
 print("PASS TOTAL ",checks);quit(0)
