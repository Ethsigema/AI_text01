extends SceneTree
var cat
var game
var checks=0
func verify(ok:bool,label:String)->bool:
 checks+=1
 print("PASS " if ok else "FAIL ",label)
 if not ok:quit(1)
 return ok
func run_case(fill:int,zone:String)->bool:
 game=load("res://core/game.gd").new()
 var room=load("res://core/room_config.gd").new();room.reset(cat)
 room.data.enabled_minions=["BGS_119"];room.data.enabled_spells=["BG36_884"]
 room.data.selected_hero="TB_BaconShop_HERO_01";room.data.enabled_heroes=["TB_BaconShop_HERO_01"];room.data.bot_count=1;room.data.seed=20261115
 for k in ["enabled_anomalies","enabled_quests","enabled_rewards","enabled_trinkets"]:room.data[k]=[]
 var r=game.start(room.data,cat)
 if not verify(r.get("ok",false),"room_started"):print(r);return false
 var p=game.state.players[0]
 p.hand.clear();p.board.clear()
 var target=game._unit(cat.get_card("BGS_119"))
 if zone=="board":p.board.append(target)
 else:p.shop=[target]
 for i in range(fill):p.hand.append(game._unit(cat.get_card("BG28_810")))
 p.hand.append(game._unit(cat.get_card("BG36_884")))
 var gold=p.gold
 r=game.apply_command(0,{"type":"play","index":fill})
 if not verify(r.get("ok",false),"real_forge_play"):print(r);return false
 var arrows=p.hand.filter(func(u):return u.card_id=="EBG_Spell_014")
 if not verify(arrows.size()==mini(3,10-fill),"generated_quantity"):return false
 if not verify(p.hand.size()==mini(10,fill+3),"capacity"):return false
 if not verify(p.gold==gold,"no_cast_purchase_charge"):return false
 var uids={}
 for arrow in arrows:uids[arrow.uid]=true
 if not verify(uids.size()==arrows.size(),"unique_generated_uids"):return false
 var before=p.duplicate(true)
 r=game.apply_command(0,{"type":"play","index":fill,"target":99,"target_zone":zone})
 if not verify(not r.get("ok",false) and p==before,"invalid_target_atomic_reject"):return false
 var a=target.attack
 var h=target.health
 for i in range(arrows.size()):
  r=game.apply_command(0,{"type":"play","index":fill,"target":0,"target_zone":zone})
  if not verify(r.get("ok",false),"real_arrow_play_"+zone):print(r);return false
  if not verify(target.attack==a+4*(i+1) and target.health==h,"target_buff"):return false
 if not verify(p.hand.size()==fill,"arrows_consumed"):return false
 return true
func _initialize():
 print("NEW_EVIDENCE_RERUN_NOT_ORIGINAL_54_LOG")
 cat=load("res://core/catalog.gd").new();cat.load_catalog()
 if not verify(cat.load_errors.is_empty(),"catalog_loaded"):return
 if not verify(cat.get_card("BG36_884").dbf_id=="133371" and cat.get_card("EBG_Spell_014").dbf_id=="100596","stable_identities"):return
 var room=load("res://core/room_config.gd").new();room.reset(cat)
 if not verify("BG36_884" in room.data.enabled_spells and "EBG_Spell_014" not in room.data.enabled_spells,"default_pool_distinguishes_generated_dependency"):return
 for zone in ["board","shop"]:
  for fill in [0,8,9]:
   if not run_case(fill,zone):return
 print("TOTAL ",checks)
 quit(0)
