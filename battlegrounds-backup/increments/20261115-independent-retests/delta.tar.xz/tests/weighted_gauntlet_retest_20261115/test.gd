extends SceneTree
var checks=0
func check(ok:bool,label:String)->bool:
 checks+=1
 print("PASS " if ok else "FAIL ",label)
 if not ok:quit(1)
 return ok
func _initialize():
 var catalog=load("res://core/catalog.gd").new();catalog.load_catalog()
 if not check(catalog.load_errors.is_empty(),"fresh_catalog_load"):print(catalog.load_errors);return
 var id="BG36_MagicItem_414"
 var card=catalog.get_card(id)
 if not check(card.dbf_id=="134444","stable_identity"):return
 if not check(card.category=="大型饰品" and card.categories==["大型饰品"],"effective_greater"):return
 if not check(card.effects[0].attack==7 and card.effects[0].health==7 and card.effects[0].start_multiplier==2,"effective_seven_and_double"):return
 var sources=load("res://core/owned_recruit_stat_sources.gd")
 var host=load("res://core/owned_recruit_stat_host.gd")
 if not check(sources.closure_error(catalog).is_empty(),"current_closure"):return
 var player={"id":0,"trinkets":[id]}
 player[sources.STATE]={"owner":0,"slots":{"0:BG36_MagicItem_414":{"id":id,"slot":0,"acquired_round":9,"last_start":9,"power":7}}}
 for elapsed in range(5):
  player[sources.STATE].slots["0:BG36_MagicItem_414"].last_start=9+elapsed
  player[sources.STATE].slots["0:BG36_MagicItem_414"].power=7*(1<<elapsed)
  if not check(host.player_error(player,9+elapsed,catalog).is_empty(),"clock_state_"+str(elapsed)):return
 player[sources.STATE].slots["0:BG36_MagicItem_414"].power=16
 if not check(not host.player_error(player,13,catalog).is_empty(),"reject_old_one_seed"):return
 print("TOTAL ",checks)
 quit(0)
