# hsbg.cards 社区 API 对照研究（非游戏完整验收）

研究日期：2026-11-15，实际请求 UTC 起止时间见 requests.json（与定时任务名义时刻分开）。所有请求均为匿名只读 GET。原始响应、HTTP 响应头、访问时间、URL、字节数和 SHA256 已保存。没有修改游戏源码、完成计数或官方范围分母。

## 观察结果

- 按公开文档调用 `GET /api/v1/cards?pool=current&cardType=trinket&limit=200&offset=...`，实际返回 `filters={"pool":"current"}`。cardType 过滤未生效，limit 被返回为100。严格跟随 nextOffset 下载0至1400的15页，终页nextOffset=null；总计1466行、1466唯一ID。
- 全量返回混有随从、法术、英雄、英雄技能、饰品、畸变、任务和奖励，不能把1466称为饰品总计。对实际 cardType=trinket 本地筛选得243行：小型118、大型125，全部pool=true。这仅是该站当次数据状态，不能认定为官方完整可选饰品池。
- 与已备份263候选按 `card_id:lesser/greater` 比较：交集242，社区API独有1，候选独有21。完整双方差集与原始字段见 COMPARISON.json。
- API独有：133712:greater，Sphere of Memory，BG36_MagicItem_372；updatedAt为2026-08-20。它是需交叉核实的新增候选线索，不等于新增实现。
- 候选独有21中包括大奇术师肖像120606。263候选来自历史资料汇总，并明确 full_inventory_verified=false。社区current列表缺席与历史候选存在属于来源/时间/范围差异；未取得逐项官方后续轮换/禁用证据，不把差集直接判为删除、不自动删候选。历史temporary_ban=false也不证明当前未禁用。

## ID117858 定向检查

`GET https://hsbg.cards/api/v1/cards/117858` 成功，得到 Redeemer Portrait，BG30_MagicItem_944，greater，pool=false，extra +4/+4，updatedAt=2026-08-05T10:52:01.597Z。117858不在263候选中，也不在该站current列表中。

这与此前该站36.2页面“Staying”线索不一致；官方S14表格自身又同时出现Removed与Staying（见既有Redeemer研究）。API不是官方裁决，不能据此宣称已解决当前可选性。此处不重复请求官方表，未将之前来源检查冒充本次重新核验。

## 新鲜度与可信度

公开API声明为社区项目。响应X-API-Version=1.0.0只是API契约版本，不是游戏补丁。饰品记录updatedAt最早2026-04-06、最晚2026-11-03；响应cache-control允许客户端1小时、共享缓存1天与过期再验证1天。HTTP响应时间和记录更新时间都不能证明该站掌握全部当前游戏池。未取得官方版本固定的选取池或当前客户端可复现选取证据。保留饰品分母与完成数为null。

## 固定候选来源

本次复制既有独立恢复研究保存的 candidate_inventory_source.json，逐字节保留。来源固定提交 `e4c0af45c0945a7f40eaff8dc52b64004cfaecfb`，仓库 Ethsigema/AI_text01，路径 `battlegrounds-backup/increments/20261114-trinket-scope-inventory/delta.tar.xz`。既有下载包SHA256为5ea5e871fc80124d24726549e1c5598aed826f2b102af6f19eb18d4d2006b65d，候选文件SHA256为f88a467946c47e6e64b5050e0b4411f18c932501233c850dd75d3167cfe4151c。本次没有重新下载该候选源；其来源说明见同目录 copied_prior_REVIEW.json，必须与本次新抓取API区分。
