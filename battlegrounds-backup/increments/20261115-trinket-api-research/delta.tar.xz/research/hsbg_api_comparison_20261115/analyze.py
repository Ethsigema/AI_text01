import json,pathlib,collections,hashlib,shutil
p=pathlib.Path(__file__).parent
src=pathlib.Path('redeemer_review_20261115/research/candidate_inventory_source.json')
shutil.copyfile(src,p/'candidate_inventory_source.json')
cand=json.loads(src.read_text())['cards']; raw=[];pg=[]
for f in sorted((p/'raw').glob('current_*.json'),key=lambda f:int(f.stem.split('_')[-1])):
 x=json.loads(f.read_text());raw+=x['data'];pg.append(x['pagination'])
tr=[x for x in raw if x.get('cardType')=='trinket']
ck={f"{x['card_id']}:{x['tier']}":x for x in cand}
tk={f"{x['id']}:{x.get('trinketTier','unknown')}":x for x in tr}
result={'source_authority':'community_secondary_only','api_version':'1.0.0_not_game_patch','requested_cardType':'trinket','observed_filters':[json.loads(f.read_text()).get('filters') for f in (p/'raw').glob('current_*.json')],'pagination':pg,'downloaded_rows':len(raw),'unique_ids':len({x['id'] for x in raw}),'card_type_counts':dict(collections.Counter(x.get('cardType') for x in raw)),'actual_trinkets':tr,'candidate_rows':len(cand),'matched_keys':sorted(tk.keys()&ck.keys()),'api_only':[tk[k] for k in sorted(tk.keys()-ck.keys())],'candidate_only':[ck[k] for k in sorted(ck.keys()-tk.keys())],'id117858':json.loads((p/'raw/id117858.json').read_text())['data'],'trinket_updatedAt_range':sorted({x.get('updatedAt','') for x in tr}),'full_current_game_trinket_denominator':None,'completed_count':None,'constraints':['Community pool flag does not prove current selectable membership.','Requested cardType filter not reflected in actual response; client-side filtering used.','API version is not game patch. Per-record updatedAt and cached HTTP response do not prove a complete live pool.','Candidate absence from community current listing does not prove removal.','Baseline candidate inventory is itself unverified and includes historical rows.']}
(p/'COMPARISON.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
print({k:result[k] for k in ['downloaded_rows','unique_ids','card_type_counts','candidate_rows']});print('matched',len(result['matched_keys']),'api_only',len(result['api_only']),'candidate_only',len(result['candidate_only']));print('api_only',[(x['id'],x['name'],x.get('trinketTier')) for x in result['api_only']])
