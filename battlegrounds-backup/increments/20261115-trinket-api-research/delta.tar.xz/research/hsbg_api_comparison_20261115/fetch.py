import urllib.request,json,datetime,hashlib,time,pathlib
p=pathlib.Path(__file__).parent; manifest=[]
def fetch(url,name):
 t=datetime.datetime.now(datetime.timezone.utc).isoformat()
 with urllib.request.urlopen(url,timeout=45) as r: body=r.read(); hdr=dict(r.headers); status=r.status
 (p/'raw'/name).write_bytes(body)
 manifest.append(dict(url=url,accessed_utc=t,status=status,headers=hdr,file='raw/'+name,bytes=len(body),sha256=hashlib.sha256(body).hexdigest()))
 (p/'requests.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
 return body
fetch('https://hsbg.cards/api-docs','api_docs.html')
fetch('https://hsbg.cards/api/v1/cards/117858','id117858.json')
offset=0
while True:
 x=json.loads(fetch(f'https://hsbg.cards/api/v1/cards?pool=current&cardType=trinket&limit=200&offset={offset}',f'current_{offset}.json'))
 print(offset,len(x.get('data',[])),x.get('pagination'),flush=True)
 nxt=x.get('pagination',{}).get('nextOffset')
 if nxt is None or nxt<=offset:break
 offset=nxt;time.sleep(.5)
