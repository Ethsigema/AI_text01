extends RefCounted
const Normal=preload("res://core/patch_3702_timewarp_swirler_sources.gd")
const Gains=preload("res://core/attack_gain_listeners.gd")
const ID="BG34_Giant_686"
const GOLDEN="BG34_Giant_686_G"
const IDS=[ID,GOLDEN]
const Golden=preload("res://core/patch_3702_timewarp_swirler_golden_sources.gd")
const TYPE="timewarp_swirler_giver_aura"
const MOLTEN="BG34_Giant_006"
const MOLTEN_GOLDEN="BG34_Giant_006_G"
const AIR="BG36_181"
const AIR_GOLDEN="BG36_181_G"
const ULTRA="BG31_810"
const ULTRA_GOLDEN="BG31_810_G"
const ULTRAS=[ULTRA,ULTRA_GOLDEN]
const Ultra=preload("res://core/ultraviolet_host.gd")
static func program(id: String=ID) -> Array: return [{"type":TYPE,"source_id":id,"attack":6 if id==GOLDEN else 3,"health":6 if id==GOLDEN else 3}] if id in IDS else []
static func unit_error(unit: Dictionary) -> String:
	if unit.get("card_id",unit.get("id")) in IDS:
		return "" if Normal.same(unit.get("effects"),program(str(unit.get("card_id",unit.get("id"))))) else "timewarp_swirler_changed_program"
	return "timewarp_swirler_unbound_effect" if unit.get("effects",[]).any(func(e):return e.get("type")==TYPE) else ""
static func holders(p: Dictionary) -> Array: return p.get("board",[]).filter(func(u):return u.get("card_id") in IDS and Gains.active(u))
static func command_error(engine,player_id: int,command: Dictionary) -> String:
	if command.get("type")=="sell" and player_id>=0 and player_id<engine.state.get("players",[]).size():
		var actor: Dictionary=engine.state.players[player_id]
		var index: int=int(command.get("index",-1))
		if index>=0 and index<actor.board.size() and actor.board[index].get("card_id") in IDS: return unit_error(actor.board[index])
	for p in engine.state.get("players",[]):
		var active: Array=holders(p)
		var owned: Array=p.get("board",[])+p.get("hand",[])
		if not owned.any(func(u):return u.get("card_id") in IDS): continue
		if active.size()>1: return "timewarp_swirler_multiple_auras_partial"
		if command.get("type")=="end_turn":
			var combat_issue: String=game_combat_error(engine)
			if not combat_issue.is_empty(): return combat_issue
		if not p.get("trinkets",[]).is_empty() or not p.get("reward_active",[]).is_empty(): return "timewarp_swirler_owned_modifiers_partial"
		if engine.Seaside.has(p.board) or engine.WaterloggedPen.has_source(p) or engine.DitchGuardian.amount(p)>0 or engine.RadiantEmber.amount(p)>0 or engine.EnhancedSpawn.relevant(p) or int(p.get("native_elemental_given_attack",{}).get("attack",0))>0: return "timewarp_swirler_modifier_stack_partial"
		for u in owned:
			var issue: String=unit_error(u)
			if not issue.is_empty(): return issue
			if not u.get("attachments",[]).is_empty(): return "timewarp_swirler_attachment_partial"
			if u.get("card_id") in IDS:
				var canonical=engine.catalog.source_catalog if engine.catalog.source_catalog!=null else engine.catalog
				issue=Golden.source_error(canonical.get_card(GOLDEN)) if u.card_id==GOLDEN else Normal.source_error(canonical.get_card(ID))
				if not issue.is_empty(): return issue
			elif u.get("card_id") in [MOLTEN,MOLTEN_GOLDEN]:
				issue=engine.TimewarpMolten.unit_error(u)
				if not issue.is_empty(): return issue
				if not active.is_empty():
					var total: int=int(engine.TimewarpMolten.program(u.card_id)[0].attack)+int(program(active[0].card_id)[0].attack)
					if not engine.Combat.StartCombatEffects.buff_fits(u,total,total): return "timewarp_swirler_molten_overflow"
			elif u.get("card_id") in ULTRAS:
				issue=Ultra.unit_error(u)
				if issue.is_empty(): issue=Ultra.Golden.source_error(engine.catalog.get_card(ULTRA_GOLDEN)) if u.card_id==ULTRA_GOLDEN else Ultra.Normal.source_error(engine.catalog.get_card(ULTRA))
				if not issue.is_empty(): return issue
			elif u.get("card_id") in [AIR,AIR_GOLDEN]:
				issue=engine.AirBaller.unit_error(u)
				if not issue.is_empty(): return issue
				if not active.is_empty():
					var history_issue: String=engine.AirBaller.history_error(p)
					if not history_issue.is_empty(): return history_issue
					var total: int=engine.AirBaller.amount(p,u)+int(program(active[0].card_id)[0].attack)
					for target in p.board:
						if not is_same(target,u) and not engine.Combat.StartCombatEffects.buff_fits(target,total,total): return "timewarp_swirler_air_overflow"
			elif u.get("card_id")=="BG29_611":
				# Exact native Deathrattle is inert in this recruit-only domain.
				if not Normal.same(u.get("effects"),engine.catalog.get_card("BG29_611").get("effects")): return "timewarp_swirler_changed_inert_mech"
			elif not u.get("effects",[]).is_empty(): return "timewarp_swirler_other_giver_program_partial"
			if u.get("kind")=="spell": return "timewarp_swirler_spell_giver_partial"
	return ""
static func vector(engine,target: Dictionary,attack: int,health: int,giver: Dictionary) -> Dictionary:
	var result: Dictionary={"ok":true,"error":"","attack":attack,"health":health}
	for p in engine.state.get("players",[]):
		if holders(p).is_empty() or not p.board.any(func(u):return is_same(u,target)): continue
		if engine.state.phase!="recruit" or holders(p).size()!=1: return {"ok":false,"error":"timewarp_swirler_actual_recruit_aura_required"}
		if giver.get("card_id") in [AIR,AIR_GOLDEN]:
			var history_issue: String=engine.AirBaller.history_error(p)
			if not history_issue.is_empty(): return {"ok":false,"error":history_issue}
			var base: int=engine.AirBaller.amount(p,giver)
			var total: int=base+int(program(holders(p)[0].card_id)[0].attack)
			var ticket: Dictionary=engine._air_baller_context
			if not is_same(ticket.get("owner"),p) or not is_same(ticket.get("source"),giver) or ticket.get("used")!=true or ticket.get("sequence")!=engine.state.command_sequence or ticket.get("round")!=engine.state.round or ticket.get("prior_sales",-1)!=p.stats.get("sold",-1) or ticket.get("amount",-1)!=base or p.board.any(func(u):return u.uid==giver.get("uid")) or target.uid not in ticket.get("targets",[]) or attack!=base or health!=base: return {"ok":false,"error":"timewarp_swirler_air_actual_sale_required"}
			var source_issue: String=engine.AirBaller.unit_error(giver)
			if not source_issue.is_empty(): return {"ok":false,"error":source_issue}
			if not engine.Combat.StartCombatEffects.buff_fits(target,total,total): return {"ok":false,"error":"timewarp_swirler_air_vector_bound"}
			result.attack=total;result.health=total
			engine._log("timewarp_swirler_air_vector",{"player":p.id,"source_uid":holders(p)[0].uid,"giver_uid":giver.uid,"target_uid":target.uid,"base_attack":base,"base_health":base,"attack":total,"health":total})
		else:
			var base: int=2 if giver.get("card_id")==MOLTEN_GOLDEN else 1
			var total: int=base+int(program(holders(p)[0].card_id)[0].attack)
			var context: Dictionary=engine._timewarp_molten_play_context
			if giver.get("card_id") not in [MOLTEN,MOLTEN_GOLDEN] or not is_same(giver,target) or not is_same(context.get("owner"),p) or not is_same(context.get("source"),giver) or context.get("used")!=true or attack!=base or health!=base: return {"ok":false,"error":"timewarp_swirler_unbridged_actual_giver"}
			if not engine.Combat.StartCombatEffects.buff_fits(target,total,total): return {"ok":false,"error":"timewarp_swirler_vector_bound"}
			result.attack=total;result.health=total
			engine._log("timewarp_swirler_molten_vector",{"player":p.id,"source_uid":holders(p)[0].uid,"giver_uid":giver.uid,"target_uid":target.uid,"base_attack":base,"base_health":base,"attack":total,"health":total})
	return result
static func legal_actions(engine,player_id: int,commands: Array) -> Array:
	return commands.filter(func(c):return command_error(engine,player_id,c).is_empty())

static func combat_units_error(boards: Array,hands: Array) -> String:
	if not boards.any(func(board):return board.any(func(u):return u.get("card_id") in IDS)):
		return "timewarp_swirler_hand_combat_partial" if hands.any(func(hand):return hand.any(func(u):return u.get("card_id") in IDS)) else ""
	for side in range(2):
		var board: Array=boards[side]
		if board.filter(func(u):return u.get("card_id") in IDS).size()>1 or board.filter(func(u):return u.get("card_id") in ULTRAS).size()>1: return "timewarp_swirler_repeated_combat_givers_partial"
		for u in board+hands[side]:
			if not u.get("attachments",[]).is_empty() or u.has("temporary_deathrattles") or u.has("fish_acquired_deathrattles"): return "timewarp_swirler_combat_inheritance_partial"
			if u.get("card_id") in IDS:
				var issue: String=unit_error(u)
				if not issue.is_empty(): return issue
			elif u.get("card_id") in ULTRAS:
				var issue: String=Ultra.unit_error(u)
				if not issue.is_empty(): return issue
			elif not u.get("effects",[]).is_empty(): return "timewarp_swirler_combat_giver_paths_partial"
		if not holders({"board":board}).is_empty():
			var givers: Array=board.filter(func(u):return u.get("card_id") in ULTRAS)
			var base: int=Ultra.buff_amount(givers[0],Ultra.program(givers[0].card_id)[0]) if not givers.is_empty() else 4
			var total: int=base+int(program(holders({"board":board})[0].card_id)[0].attack)
			for u in board:
				if Ultra.elemental(u) and u.get("card_id") not in ULTRAS and not fits_total(u,total): return "timewarp_swirler_combat_overflow"
	return ""
static func game_combat_error(engine) -> String:
	var boards: Array=[];var hands: Array=[]
	for p in engine.state.players:
		if not p.get("trinkets",[]).is_empty() or not p.get("reward_active",[]).is_empty(): return "timewarp_swirler_combat_owned_partial"
		boards.append(p.board);hands.append(p.hand)
	if boards.size()!=2: return "timewarp_swirler_combat_two_player_gate"
	return combat_units_error(boards,hands)
static func combat_domain(left: Array,right: Array,options: Dictionary) -> String:
	return combat_units_error([left,right],[options.get("left_hand",[]),options.get("right_hand",[])])
static func combat_vector(engine,target: Dictionary,attack: int,health: int,giver: Dictionary) -> Dictionary:
	var result: Dictionary={"ok":true,"error":"","attack":attack,"health":health}
	var side: int=int(target.get("_side",-1))
	if side not in [0,1] or holders({"board":engine._boards[side]}).is_empty(): return result
	var board: Array=engine._boards[side]
	var issue: String=Ultra.unit_error(giver)
	if not issue.is_empty(): return {"ok":false,"error":issue}
	var base: int=Ultra.buff_amount(giver,Ultra.program(giver.card_id)[0]) if giver.get("card_id") in ULTRAS else 0
	if not board.any(func(u):return is_same(u,target)) or not board.any(func(u):return is_same(u,giver)) or giver.get("card_id") not in ULTRAS or not Gains.active(giver) or is_same(target,giver) or not Ultra.elemental(target) or attack!=base or health!=base: return {"ok":false,"error":"timewarp_swirler_unbridged_combat_vector"}
	var total: int=base+int(program(holders({"board":board})[0].card_id)[0].attack)
	if holders({"board":board}).size()!=1 or not engine.StartCombatEffects.buff_fits(target,total,total): return {"ok":false,"error":"timewarp_swirler_combat_vector_bound"}
	result.attack=total;result.health=total
	engine._emit("timewarp_swirler_ultraviolet_vector",{"source":holders({"board":board})[0].uid,"giver":giver.uid,"target":target.uid,"attack":total,"health":total,"base_attack":base,"base_health":base})
	return result

static func fits_total(u: Dictionary,total: int) -> bool:
	for key in ["attack","health","max_health"]:
		if not u.get(key) is int or int(u[key])<0 or int(u[key])>9007199254740991-total: return false
	return true
