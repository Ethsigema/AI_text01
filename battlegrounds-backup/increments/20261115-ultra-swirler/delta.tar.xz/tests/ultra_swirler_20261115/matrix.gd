extends SceneTree
var game
var cat
var checks=0
func check(ok: bool,label: String) -> bool:
 checks+=1
 print("PASS " if ok else "FAIL ",label)
 if not ok:
  if game!=null: print("EVENTS ",JSON.stringify(game.events.slice(-4)))
  quit(1)
 return ok
func setup(id: String) -> bool:
 game=load("res://core/game.gd").new()
 var room=load("res://core/room_config.gd").new();room.reset(cat)
 room.data.enabled_minions=["BG31_810","BGS_119","BG31_330"]
 room.data.enabled_spells=["BG28_810"]
 room.data.selected_hero="TB_BaconShop_HERO_01";room.data.enabled_heroes=["TB_BaconShop_HERO_01"];room.data.bot_count=1;room.data.seed=20261114
 for key in ["enabled_anomalies","enabled_quests","enabled_rewards","enabled_trinkets"]: room.data[key]=[]
 var result=game.start(room.data,cat)
 if not check(result.get("ok",false),"real_room"): print(result);return false
 var p=game.state.players[0]
 var source=game._unit(cat.get_card(id));p.board.append(source);p.gold=10
 return check(not source.is_empty(),"source_factory_"+id)
func one(id: String,aura: String,n: int) -> bool:
 if not setup(id):return false
 var p=game.state.players[0];var source=p.board[0]
 for i in range(n):
  game._add_hand(p,game._unit(cat.get_card("BGS_119")))
  if not check(game.apply_command(0,{"type":"play","index":0}).get("ok",false),"actual_growth_play"):return false
 var sw=game._unit(cat.get_card(aura));p.board.append(sw)
 var target=game._unit(cat.get_card("BGS_119"));p.board.append(target)
 var before=p.duplicate(true)
 var battle=game.Combat.new().resolve(p.board,[game._unit(cat.get_card("BGS_119"))],20261115)
 if not check(str(battle.get("error","")).is_empty(),"combat_growth_bridge_"+id+"_"+aura+"_"+str(n)):print(battle.get("error"));return false
 var vectors=battle.get("log",[]).filter(func(e):return e.get("event")=="timewarp_swirler_ultraviolet_vector")
 var total=(8 if id.ends_with("_G") else 4)*(1+n)+(6 if aura.ends_with("_G") else 3)
 if not check(vectors.size()==n+2,"all_other_elementals_once"):print(vectors);return false
 for v in vectors:
  if not check(v.attack==total and v.health==total and v.target!=source.uid,"grown_plus_aura_exact"):return false
 if not check(p==before,"combat_preserves_recruit_state"):return false
 target.attack=9007199254740991-total+1
 var snap=p.duplicate(true)
 var err=game.TimewarpSwirler.game_combat_error(game)
 if not check(err=="timewarp_swirler_combat_overflow" and p==snap,"grown_aura_overflow_rejected_read_only"):print(err);return false
 target.attack=before.board[-1].attack
 sw.silenced=true
 var quiet=game.Combat.new().resolve(p.board,[game._unit(cat.get_card("BGS_119"))],20261115)
 if not check(str(quiet.get("error","")).is_empty() and quiet.get("log",[]).filter(func(e):return e.get("event")=="timewarp_swirler_ultraviolet_vector").is_empty(),"silenced_aura_no_extra_vector"):return false
 sw.silenced=false
 var growth=source.get(game.Ultraviolet.GROWTH)
 source[game.Ultraviolet.GROWTH]="broken"
 if not check(game.TimewarpSwirler.game_combat_error(game)=="ultraviolet_changed_growth_identity","malformed_growth_held"):return false
 if growth==null:source.erase(game.Ultraviolet.GROWTH)
 else:source[game.Ultraviolet.GROWTH]=growth
 return true
func _initialize():
 cat=load("res://core/catalog.gd").new();cat.load_catalog()
 if not check(cat.load_errors.is_empty(),"catalog"):print(cat.load_errors);return
 for id in ["BG31_810","BG31_810_G"]:
  for aura in ["BG34_Giant_686","BG34_Giant_686_G"]:
   for n in [0,1,2]:
    if not one(id,aura,n):return
 print("ULTRA_SWIRLER_PASS checks=",checks)
 quit(0)
