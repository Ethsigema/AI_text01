# 饰品手牌保护与投球手肖像核查（2026-11-15）

基线：ca9ae9c401a757967aa47dfe134a344b7a0b87b4 的独立恢复工程；仅只读检查，没有改变源工程，没有运行游戏测试。

## 已有实现，不作为新增
core/mechanism_effects.gd 的 _award_spell 已明确引用 2026-04-06 开发者规则，所有经过该共同入口的奖励先入 mechanism_reward_queue，再由 flush_reward_queue 在 hand.size()<10 时投递。游戏引擎的 _award_protected_trinket_resource 也在满手时入队。故“饰品生成牌满手等待”不是可直接宣称缺失的新功能。此处没有穷尽全部特殊饰品生成分支，不宣称所有饰品验收通过。

## 投球手肖像版本差异
原始目录存在两卡：BG36_MagicItem_390（小型，每回合获取火焰或冰雪投球手）和 BG35_MagicItem_861（大型，每使用 11 张元素获取寒热骤变）。两者 effects=[]、supported=false，core 没有这两 ID 的实现命中。_offer_original_trinket_category 未包含专属售卖过滤，但不能把这一点独立当成当前可玩肖像的缺陷。

2026-04-06 官方 S13 概览称 Baller Portrait 仅在本局卖过 Baller 后提供。2026-07-27 官方 S14 更新把同名小饰品列为 New；2026-11-03 的 37.0.2 仅确认其费用 2→1。因此尚缺将旧版提供门槛确证为新小饰品规则的版本绑定证据。没有据此加入可能错误的过滤，也没有强行启用尚无效果实现的卡牌。

## 来源
- https://us.forums.blizzard.com/en/hearthstone/t/battlegrounds-developer-insights-updated-trinket-rules/158955
- https://eu.forums.blizzard.com/en/hearthstone/t/battlegrounds-developer-insights-updated-trinket-rules/12768
- https://us.forums.blizzard.com/en/hearthstone/t/battlegrounds-season-14-trinket-updates/163710
- https://hearthstone.blizzard.com/en-us/news/24307311

## 结论
本次无游戏实现新增、无新增完成数量。前一个候选已有通用实现，后一个候选存在新旧同名规则绑定缺口。下一步需取得新小饰品实际提供规则，再将生成效果、满手队列、真实售卖历史及提供条件整体实现和测试；不能用不可触达的过滤代码或目录注册充当完成。
