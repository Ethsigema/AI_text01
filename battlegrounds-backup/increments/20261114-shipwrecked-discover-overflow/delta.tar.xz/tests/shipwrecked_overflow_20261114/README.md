# 机智的船难海盗：手牌容量不足时的发现队列扩展

只对 BG36_342 / BG36_342_G 增加有限执行域，印刷发动费用 2、普通 1 次发现和金色 2 次发现不变。既有已验证恢复工程来源为 32a8b33a；不是全池、整卡或完整对局验收。

原代码在排入发现队列前，要求所有结果都有空手牌位。因此金色 9 张手牌、普通/金色 10 张手牌都提前拒绝。新增逻辑仅允许既有艾德温且当轮未使用能力、单一此来源、手牌仅有法术、无任务/饰品/奖励/畸变等观察者的有限域，通过原发现队列和 `_add_hand` 满手 burn / 归还路径。保留其他来源、RANDOM 容量、未知观察者以及原来所有其余校验门；不筛选或缩小候选法术池。

## 定向运行

使用 Godot 4.6.3。在工程根目录执行（XDG 目录必须可写）：

    XDG_DATA_HOME=/tmp/shipwrecked-test-home/.local/share XDG_CONFIG_HOME=/tmp/shipwrecked-test-home/.config XDG_CACHE_HOME=/tmp/shipwrecked-test-home/.cache godot --headless --path . --script tests/shipwrecked_overflow_20261114/real_matrix.gd

测试真实加载整个 Catalog 与 Game，在双人房间真实调用 `apply_command` 发动和发现，使用原生工厂及 `_add_hand`。初始来源直接放入 board、起始 gold=10、9/10 张原生酒馆币手牌是明确的 fixture。没有证明普通购买/三连获得金色、自然对局、战斗、存档往返、混合观察者或完整法术池。

具体结果、日志及限制见 REPORT.md 和 evidence/。旧容量门的拒绝依据是已核验旧源码静态比较，不冒称再次执行旧版游戏。
