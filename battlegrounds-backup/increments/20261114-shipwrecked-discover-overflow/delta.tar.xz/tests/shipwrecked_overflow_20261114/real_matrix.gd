extends SceneTree
var game
var cat
var checks=0
func check(ok: bool,label: String) -> bool:
 checks+=1
 print("PASS " if ok else "FAIL ",label)
 if not ok:
  if game!=null: print("EVENTS ",JSON.stringify(game.events.slice(-4)))
  quit(1)
 return ok
func setup(id: String,size: int) -> bool:
 game=load("res://core/game.gd").new()
 var room=load("res://core/room_config.gd").new();room.reset(cat)
 room.data.enabled_minions=["BG36_342","BG31_330"]
 room.data.enabled_spells=["BG28_810"]
 room.data.selected_hero="TB_BaconShop_HERO_01";room.data.enabled_heroes=["TB_BaconShop_HERO_01"];room.data.bot_count=1;room.data.seed=20261114
 for key in ["enabled_anomalies","enabled_quests","enabled_rewards","enabled_trinkets"]: room.data[key]=[]
 var result=game.start(room.data,cat)
 if not check(result.get("ok",false),"real_room"): print(result);return false
 var p=game.state.players[0]
 # Explicit setup fixtures: native factory objects, direct placement and gold.
 # Not acquisition/triple proof and not a fixture-free game.
 var source=game._unit(cat.get_card(id))
 if not check(not source.is_empty(),"native_source_factory_"+id):return false
 p.board.append(source);p.gold=10
 for i in range(size):
  var coin=game._unit(cat.get_card("BG28_810"));game._add_hand(p,coin)
 return check(p.hand.size()==size,"fixture_hand_"+str(size))
func one(id: String,size: int) -> bool:
 if not setup(id,size):return false
 var p=game.state.players[0];var source=p.board[0];var count=2 if id.ends_with("_G") else 1
 var stock=game.spell_pool.duplicate(true);var before_uid=game.next_uid;var spells=p.stats.spells
 var clean={"state":game.state.duplicate(true),"pool":game.pool.duplicate(true),"spells":game.spell_pool.duplicate(true),"rng":str(game.rng.state),"uid":game.next_uid}
 if not check(game.BulkActivate.preflight(game,p,0).is_empty(),"preflight_accepts_finite_domain"):return false
 if not check(clean=={"state":game.state.duplicate(true),"pool":game.pool.duplicate(true),"spells":game.spell_pool.duplicate(true),"rng":str(game.rng.state),"uid":game.next_uid},"accepted_preflight_read_only"):return false
 p.gold=1
 var rejected_snapshot=p.duplicate(true)
 if not check(game.BulkActivate.preflight(game,p,0)=="bulk_activate_insufficient_gold" and p==rejected_snapshot,"insufficient_payment_read_only"):return false
 p.gold=10
 if size+count>10:
  p.trinkets=["fixture_unknown_observer"]
  rejected_snapshot=p.duplicate(true)
  if not check(game.BulkActivate.preflight(game,p,0)=="bulk_activate_overflow_owned_observer_partial" and p==rejected_snapshot,"unknown_owned_observer_stays_held_read_only"):return false
  p.trinkets=[]
  var saved_kind=p.hand[0].kind
  p.hand[0].kind="minion"
  rejected_snapshot=p.duplicate(true)
  if not check(game.BulkActivate.preflight(game,p,0)=="bulk_activate_overflow_hand_observer_partial" and p==rejected_snapshot,"hand_minion_domain_stays_held_read_only"):return false
  p.hand[0].kind=saved_kind
 var result=game.apply_command(0,{"type":"activate_minion","index":0})
 if not check(result.get("ok",false),"activate_"+id+"_"+str(size)):print(result);return false
 if not check(p.gold==8 and source.activate_used_round==game.state.round,"one_payment_and_use"):return false
 if not check(p.discover.size()==1 and p.discover_queue.size()==count-1,"serial_choices"):return false
 for i in range(count):
  result=game.apply_command(0,{"type":"discover","index":0})
  if not check(result.get("ok",false),"select_"+str(i)):print(result);return false
  if not check(p.hand.size()==mini(10,size+i+1),"bounded_hand_"+str(i)):return false
  if not check(game.spell_pool==stock,"spell_stock_returned_"+str(i)):return false
 if not check(p.discover.is_empty() and p.discover_queue.is_empty(),"queue_drained"):return false
 if not check(p.stats.spells==spells and game.next_uid==before_uid+count,"no_cast_each_real_factory"):return false
 var burned=game.events.filter(func(e):return e.get("type")=="hand_overflow")
 if not check(burned.size()==maxi(0,size+count-10),"exact_burn_count"):return false
 return true
func _initialize():
 print("SHIPWRECKED_BEGIN")
 cat=load("res://core/catalog.gd").new();cat.load_catalog()
 if not check(cat.load_errors.is_empty(),"catalog"):print(cat.load_errors);return
 for id in ["BG36_342","BG36_342_G"]:
  for size in [9,10]:
   if not one(id,size):return
 print("SHIPWRECKED_PASS checks=",checks)
 quit(0)
