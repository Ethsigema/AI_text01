import json,pathlib,hashlib,collections
root=pathlib.Path('night_backup_check_20261111T1500Z/restored_shatterer_candidate')
out=pathlib.Path('trinket_scope_inventory_20261114')
paths={'api':root/'research/patch_3702_thaumaturgist_portrait/official_api_trinkets.json','solo':root/'research/patch_3702_thaumaturgist_portrait/library_trinkets_solos.json','catalog':root/'data/catalog_raw.json'}
data={k:json.load(open(p)) for k,p in paths.items()}
raw=collections.defaultdict(list)
for c in data['catalog']['cards']:
 if c.get('kind')=='trinket':raw[str(c.get('dbf_id'))].append(c)
solo={c['id'] for c in data['solo']['cards']}
patch='https://hearthstone.blizzard.com/en-us/news/24307311'
bans='https://us.forums.blizzard.com/en/hearthstone/t/370-highlights-known-issues/153567/1'
removed={'Spell-powered Wrench':'lesser','Fridge Magnet':'greater','Writhing Tentacles':'greater','Quilligraphy Set':'greater'}
rows=[];events=[]
for c in data['api']['cards']:
 matches=raw[str(c['id'])]; cats=set(m.get('category') for m in matches)
 tiers=set('lesser' if x=='小型饰品' else 'greater' if x=='大型饰品' else 'unknown' for x in cats)
 tier=next(iter(tiers)) if len(tiers)==1 else 'unknown'
 tier_source='historical_workbook_catalog' if tier!='unknown' else 'unresolved'
 if c['name']=='Weighted Gauntlet':
  tier='greater';tier_source=patch
  events.append({'card_id':c['id'],'tier':'greater','version':'37.0.2','change':'tier_changed_lesser_to_greater','source':patch})
 row={'key':f"{c['id']}:{tier}",'card_id':c['id'],'tier':tier,'tier_evidence':tier_source,'name_en':c['name'],'name_zh_candidates':sorted(set(m['name'] for m in matches)),'card_codes':sorted(set(m['id'] for m in matches)),'api_duos_only':c.get('battlegrounds',{}).get('duosOnly'),'api_solos_only':c.get('battlegrounds',{}).get('solosOnly'),'present_in_historical_solo_query':c['id'] in solo,'historical_api_cost':c.get('manaCost'),'membership':'unverified_candidate','temporary_ban':False,'completed':None,'source_snapshot':'api','workbook_references':[{'workbook':m.get('provenance',{}).get('workbook'),'sheet':m.get('provenance',{}).get('sheet'),'row':m.get('provenance',{}).get('row'),'source_url':m.get('source_url')} for m in matches],'unresolved':['full_post_36.2_patch_membership_reconciliation','current_source_implementation_and_acceptance_not_audited']}
 if c['name'] in removed:
  if tier==removed[c['name']] or c['name']!='Quilligraphy Set':
   row['membership']='removed_in_37.0.2';row['membership_source']=patch
   events.append({'card_id':c['id'],'tier':removed[c['name']],'version':'37.0.2','change':'removed_from_offering_pool','source':patch})
  elif tier=='unknown':row['unresolved'].append('Quilligraphy_greater_removal_needs_tier_resolution')
 if c['name'] in ["Kiri's Double Eclipse",'Putricide Sticker']:
  row['temporary_ban']=True;row['temporary_ban_source']=bans
  events.append({'card_id':c['id'],'tier':tier,'observed_on':'2026-11-14','effective_date':None,'change':'temporary_ban_not_scope_deletion','source':bans})
 rows.append(row)
obj={'schema_version':1,'scope':'latest_live_appearance_full_trinket_content_not_all_history','candidate_season':14,'latest_verified_balance_note':'37.0.2 (2026-11-03)','full_inventory_verified':False,'denominator':None,'completed_count':None,'candidate_rows':len(rows),'historical_solo_query_rows':len(solo),'sources':{k:{'project_relative_path':str(p.relative_to(root)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for k,p in paths.items()},'cards':rows}
(out/'candidate_inventory.json').write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
(out/'patch_delta_ledger.json').write_text(json.dumps({'complete':False,'events':events,'unresolved':['All 36.2 through 37.0.2 intermediate changes must be reconciled.','36.2 announcement table has Defiler Portrait in both removed and staying; ID-level resolution required.','Historical API includes removed cards; query membership is not live offering eligibility.','Temporary bans do not automatically remove content from implementation scope.','Patch 37.0.2 remaining cost and text edits not yet exhaustively encoded.','No complete implementation counts were assessed.'],'sources':[{'url':'https://us.forums.blizzard.com/en/hearthstone/t/battlegrounds-season-14-trinket-updates/163710','role':'36.2 starting inventory by category'},{'url':patch,'role':'37.0.2 updates'},{'url':bans,'role':'mutable current ban list; original post date not ban date'}]},ensure_ascii=False,indent=2)+'\n')
assert len(rows)==263 and len({r['key'] for r in rows})==263
assert sum(r['membership']=='removed_in_37.0.2' for r in rows)==4
assert sum(r['temporary_ban'] for r in rows)==3
print(json.dumps({'rows':len(rows),'tier_counts':dict(collections.Counter(r['tier'] for r in rows)),'removed':4,'temporary_bans':3,'denominator':None}))
