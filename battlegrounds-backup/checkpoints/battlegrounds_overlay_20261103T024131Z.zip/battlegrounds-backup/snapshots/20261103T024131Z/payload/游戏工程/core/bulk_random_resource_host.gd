extends RefCounted
const ExactTier=preload("res://core/exact_tier_minion_resource.gd")
const EnergySources=preload("res://core/energy_recycling_sources.gd")
const BobbleheadSources=preload("res://core/bobblehead_sources.gd")
const Aureate=preload("res://core/aureate_laureate_sources.gd")
const SeafloorCastSources=preload("res://core/seafloor_cast_sources.gd")
const Chamber=preload("res://core/energizing_chamber_host.gd")
const RustyTridentSources=preload("res://core/rusty_trident_sources.gd")
const LinkedUndeadSources=preload("res://core/linked_undead_sources.gd")
const PastryAvenge=preload("res://core/pastry_avenge_sources.gd")
const SummonGet=preload("res://core/summon_get_host.gd")
const RaptorAvengeSources=preload("res://core/raptor_avenge_sources.gd")
var _summon_get_used: bool=false
const Nat=preload("res://core/nat_attack_kill_sources.gd")
const Golden=preload("res://core/golden_resource_sources.gd")
const NativeSummon=preload("res://core/combat_summon_resource_clock.gd")
const DamageFollowupSources=preload("res://core/damage_followup_sources.gd")
const RandomSpellcraft=preload("res://core/random_spellcraft_host.gd")
const NativeSpellcraft=preload("res://core/combat_spellcraft_resources.gd")
const FixedEvents=preload("res://core/fixed_event_resource_sources.gd")
const FixedHand=preload("res://core/fixed_combat_hand_rewards.gd")
const NativeFixedHand=preload("res://core/native_fixed_hand_rewards.gd")
const RallyFixedHand=preload("res://core/rally_fixed_hand_rewards.gd")
const FixedSpellDRHand=preload("res://core/fixed_spell_dr_hand_rewards.gd")
const RandomSpellDRHand=preload("res://core/random_spell_dr_hand_rewards.gd")
const RandomMinionDRHand=preload("res://core/random_minion_dr_hand_rewards.gd")
const RandomSpellAvengeHand=preload("res://core/random_spell_avenge_hand_rewards.gd")
const SummonGetRallyHand=preload("res://core/summon_get_rally_hand_rewards.gd")
const DeathTrinketSources=preload("res://core/cyclic_resource_trinkets.gd")
const Chromatic=preload("res://core/chromatic_special_resources.gd")
const VolumizerSpecial=preload("res://core/volumizer_special_resources.gd")
const NativeMana = preload("res://core/bulk_native_mana.gd")
const Majority = preload("res://core/rally_majority_resources.gd")
const Special = preload("res://core/magnetic_special_resources.gd")
const FiniteAvenge=preload("res://core/finite_avenge_resources.gd")
const Bounty = preload("res://core/bounty_resources.gd")
## Explicit local sandbox generation policy, not a claim about official hidden rules.
## Effective enabled normal pool; current stock weighting; all effective tiers.
## Spells release their reservation before acquisition, like Game.buy().
const Sources = preload("res://core/bulk_random_resource_sources.gd")
const AvalancheCallerSources=preload("res://core/avalanche_caller_sources.gd")
const KEY: String = "bulk_random_resource_context"
const FAMILY: String = "bulk_random_resource_v1"
const POLICY: String = "effective_stock_weighted_all_tiers_printed_cost_v1"
var _context: Dictionary = {}
var _stock: Dictionary = {}
var _ghost_stock: Dictionary = {}
var _journal: Array = []
var _initial: Dictionary = {}
var _ticket_issued: bool = false
var _native_spellcraft_used: Dictionary={}
var _finite_avenge_used: Dictionary={}
var _fixed_avenge_used: Dictionary={}
var _fixed_hand=FixedHand.new()
var _native_fixed_hand=NativeFixedHand.new()
var _rally_fixed_hand=RallyFixedHand.new()
var _fixed_spell_dr_hand=FixedSpellDRHand.new()
var _random_spell_dr_hand=RandomSpellDRHand.new()
var _random_minion_dr_hand=RandomMinionDRHand.new()
var _random_spell_avenge_hand=RandomSpellAvengeHand.new()
var _summon_get_rally_hand=SummonGetRallyHand.new()

static func _integer(value: Variant) -> bool:
	return (value is int or value is float) and not value is bool and is_finite(float(value)) and value == floor(value) and value >= 0 and value <= 2147483647

static func _tavern(card: Dictionary) -> bool:
	return card.get("kind") == "spell" and (card.get("category") in ["酒馆","酒馆法术"] or "酒馆" in card.get("categories",[]) or "酒馆法术" in card.get("categories",[]))

static func domain(engine) -> Dictionary:
	var result: Dictionary = {"policy":POLICY,"cards":{},"stock":{},"ghost":false}
	result[NativeSpellcraft.KEY]=NativeSpellcraft.pool_context(engine)
	result[Special.KEY]=Special.pool_context(engine.catalog)
	result[FiniteAvenge.KEY]=FiniteAvenge.pool_context(engine)
	result[Bounty.KEY]=Bounty.pool_context(engine.catalog)
	result[Chromatic.KEY]=Chromatic.pool_context(engine.catalog)
	result[VolumizerSpecial.KEY]=VolumizerSpecial.pool_context(engine.catalog)
	result[DamageFollowupSources.SPELLCRAFT_POOL]={"error":RandomSpellcraft.Sources.closure_error(engine.catalog),"ids":RandomSpellcraft.candidates(engine),"policy":RandomSpellcraft.Sources.POLICY}
	for kind in ["minion","spell"]:
		var pool: Dictionary = engine.pool if kind == "minion" else engine.spell_pool
		var enabled: Array = engine._enabled("minions" if kind == "minion" else "spells")
		var ids: Array = pool.keys(); ids.sort()
		for id in ids:
			if id not in enabled: continue
			var card: Dictionary = engine.catalog.get_card(str(id))
			if card.get("kind") != kind or not card.get("supported",false) or card.get("is_golden",false): continue
			if kind == "spell" and not _tavern(card): continue
			var printed: Dictionary = engine.catalog.source_catalog.get_card(str(id)) if engine.catalog.source_catalog != null else card
			var cost: Variant = printed.get("fields",{}).get("cost",printed.get("cost",card.get("cost")))
			if kind == "minion" and not _integer(cost) and NativeMana.COSTS.has(str(id)): cost=NativeMana.COSTS[str(id)]
			if kind == "spell" and not _integer(cost): continue
			result.cards[id] = {"id":id,"kind":kind,"cost":cost,"tier":card.get("tier"),"tribes":card.get("tribes",[]).duplicate(),"battlecry":engine._matches_generated_minion_filter(card,"battlecry"),"magnetic":"magnetic" in card.get("keywords",[]),"choose_one":card.get("effects",[]).any(func(e):return e.get("type")=="choose_one"),"golden_id":card.get("golden_id","")}
			result.stock[id] = int(pool[id])
	return result

# Restored adapters for existing Game call sites. Personal-pool combat
# requires per-side membership filtering, which the legacy context does not
# implement. Hold explicitly rather than silently using a shared domain.
static func combat_domain(engine, owners: Array, ghost: bool) -> Dictionary:
	if owners.size()!=2:
		return {"error":"random_resource_two_combat_owners_required"}
	if engine.EmergencyLanding.Sources.enabled(engine.room):
		return {"error":"random_resource_personal_combat_pool_adapter_held"}
	var context: Dictionary=domain(engine)
	context.ghost=ghost
	return context

static func draw_owned_minion(engine, owner: Dictionary, leaf: Dictionary) -> Dictionary:
	return draw_random_minion(engine,leaf,{},owner)

static func candidates(context: Dictionary, stock: Dictionary, leaf: Dictionary) -> Array:
	var choices: Array = []
	var ids: Array = context.get("cards",{}).keys(); ids.sort()
	for id in ids:
		var card: Dictionary = context.cards[id]
		if leaf.has("card_id") and id != leaf.card_id: continue
		if int(stock.get(id,0)) <= 0 or (leaf.kind != "card" and card.kind != leaf.kind): continue
		if leaf.get("cost",-1) >= 0 and card.cost != leaf.cost: continue
		if leaf.get("minimum_cost",-1) >= 0 and card.cost < leaf.minimum_cost: continue
		if leaf.get("tier",-1) >= 0 and card.tier != leaf.tier: continue
		if not str(leaf.get("tribe","")).is_empty() and leaf.tribe not in card.tribes and "全部" not in card.tribes and "all" not in card.tribes: continue
		if leaf.has("tribes_any"):
			var shares: bool = false
			for tribe in leaf.tribes_any:
				if tribe in ["全部","all"] and not card.tribes.is_empty() or tribe in card.tribes or "全部" in card.tribes or "all" in card.tribes: shares = true
			if not shares: continue
		if leaf.get("effect_filter","") == "battlecry" and not card.battlecry: continue
		if leaf.get("effect_filter","") in ["magnetic","choose_one"] and not card.get(leaf.effect_filter,false): continue
		choices.append({"id":id,"stock":int(stock[id])})
	return choices

static func _total(choices: Array) -> int:
	var total: int = 0
	for choice in choices: total += int(choice.stock)
	return total

static func _selected(choices: Array, ticket: int) -> String:
	for choice in choices:
		ticket -= int(choice.stock)
		if ticket < 0: return str(choice.id)
	return ""

static func draw_random_tavern_spell(engine, cost: int = -1, tier: int = -1, minimum_cost: int = -1) -> Dictionary:
	var context: Dictionary = domain(engine)
	var leaf: Dictionary = {"kind":"spell","cost":cost,"tier":tier,"minimum_cost":minimum_cost}
	var choices: Array = candidates(context,context.stock,leaf)
	var total: int = _total(choices)
	if total <= 0: return {}
	var id: String = _selected(choices,engine._random(total,"random_generated_tavern_spell"))
	engine.spell_pool[id] -= 1
	var unit: Dictionary = engine._unit(engine.catalog.get_card(id))
	if unit.is_empty(): engine.spell_pool[id] += 1; return {}
	unit.pool_id = id; unit.pool_kind = "spell"; unit.pool_count = 1
	engine._release_acquired_spell(unit)
	return unit

static func draw_filtered_card(engine,leaf: Dictionary) -> Dictionary:
	var context: Dictionary=domain(engine)
	var choices: Array=candidates(context,context.stock,leaf)
	var total: int=_total(choices)
	if total<=0: return {}
	var id: String=_selected(choices,engine._random(total,"native_mixed_card_resource"))
	var card: Dictionary=engine.catalog.get_card(id)
	var kind: String=str(card.get("kind",""))
	if kind not in ["minion","spell"]:
		engine._native_result({"ok":false,"error":"mixed_card_resource_invalid_selected_kind"});return {}
	var stock: Dictionary=engine.pool if kind=="minion" else engine.spell_pool
	if int(stock.get(id,0))<1:
		engine._native_result({"ok":false,"error":"mixed_card_resource_changed_actual_stock"});return {}
	stock[id]-=1
	var unit: Dictionary=engine._unit(card)
	if unit.is_empty(): stock[id]+=1;return {}
	unit.pool_id=id;unit.pool_kind=kind;unit.pool_count=1
	if kind=="spell": engine._release_acquired_spell(unit)
	return unit

static func draw_random_minion(engine, leaf: Dictionary, shop_owner: Dictionary = {}, resource_owner: Dictionary = {}) -> Dictionary:
	if ExactTier.handles(leaf,shop_owner):
		return ExactTier.draw(engine,int(leaf.tier),resource_owner)
	# Preserve legacy non-exact/filtered behavior, but never ignore an explicit
	# personal membership owner where that old path lacks the complete adapter.
	if engine.EmergencyLanding.Sources.enabled(engine.room):
		engine._native_result({"ok":false,"error":"random_resource_nonexact_personal_pool_adapter_held"});return {}
	var context: Dictionary = domain(engine)
	var choices: Array = candidates(context,context.stock,leaf)
	choices=choices.filter(func(choice):return BobbleheadSources.candidate_allowed(shop_owner,context.cards[choice.id]))
	var total: int = _total(choices)
	if total <= 0: return {}
	var id: String = _selected(choices,engine._random(total,"random_generated_minion"))
	engine.pool[id] -= 1
	var unit: Dictionary = engine._unit(engine.catalog.get_card(id))
	if unit.is_empty():
		engine.pool[id] += 1
		return {}
	unit.pool_id = id; unit.pool_kind = "minion"; unit.pool_count = 1
	return unit

static func golden_choices(engine, tier: int=-1, tribe: String="") -> Dictionary:
	if not Golden.Actual._actual_game_host(engine): return {"ok":false,"error":"golden_resource_actual_game_required","choices":[]}
	if tier not in [-1,1,2,3,4,5,6,7]: return {"ok":false,"error":"golden_resource_invalid_tier","choices":[]}
	var context: Dictionary=domain(engine)
	var candidates_normal: Array=candidates(context,context.stock,{"kind":"minion","tier":tier,"tribe":tribe})
	var choices: Array=[]
	var total: int=0
	for candidate in candidates_normal:
		var normal: Dictionary=engine.catalog.get_card(str(candidate.id))
		if normal.get("solo_eligible")!=true or normal.get("duos_exclusive",false) or normal.get("requires_teammate_effect",false): continue
		if not _integer(engine.pool.get(str(candidate.id))): return {"ok":false,"error":"golden_resource_invalid_actual_stock","choices":[]}
		var gold_id: String=str(normal.get("golden_id",""))
		if gold_id.is_empty() or gold_id in engine.room.get("disabled_ids",[]): continue
		var golden: Dictionary=engine.catalog.get_card(gold_id)
		if golden.get("supported")!=true or golden.get("solo_eligible")!=true or golden.get("duos_exclusive",false) or golden.get("requires_teammate_effect",false) or golden.get("kind")!="minion" or golden.get("is_golden")!=true or golden.get("normal_id")!=normal.id or golden.get("tier")!=normal.get("tier"): continue
		if not tribe.is_empty() and tribe not in golden.get("tribes",[]) and "全部" not in golden.get("tribes",[]) and "all" not in golden.get("tribes",[]): continue
		if not _integer(candidate.stock) or total>2147483647-int(candidate.stock): return {"ok":false,"error":"golden_resource_stock_weight_overflow","choices":[]}
		total+=int(candidate.stock)
		choices.append({"id":gold_id,"normal_id":normal.id,"stock":int(candidate.stock)})
	return {"ok":true,"error":"","choices":choices,"total":total}

static func draw_random_golden_minion(engine, tier: int=-1, tribe: String="", no_triple_reward: bool=true) -> Dictionary:
	var plan: Dictionary=golden_choices(engine,tier,tribe)
	if not plan.ok:
		engine._native_result(plan)
		return {}
	if int(plan.total)==0: return {}
	var ticket: int=engine._random(int(plan.total),"native_random_golden_minion")
	var id: String=_selected(plan.choices,ticket)
	var selected: Array=plan.choices.filter(func(choice):return choice.id==id)
	if selected.size()!=1:
		engine._native_result({"ok":false,"error":"golden_resource_invalid_selected_identity"})
		return {}
	var unit: Dictionary=engine._unit(engine.catalog.get_card(id))
	if unit.is_empty():
		engine._native_result({"ok":false,"error":"golden_resource_actual_factory_rejected"})
		return {}
	if unit.get("golden")!=true or unit.get("card_id")!=id:
		engine._native_result({"ok":false,"error":"golden_resource_factory_variant_changed"})
		return {}
	# Explicit generated-entity local policy. Weight by currently available
	# normal stock, without reserving or inventing three owned normal copies.
	unit.pool_count=0;unit.pool_components=[]
	unit.triple_reward=false if Aureate.minion_id(id) else not no_triple_reward
	engine._log("native_golden_resource_created",{"card_id":id,"normal_id":selected[0].normal_id,"uid":unit.uid,"tier":tier,"tribe":tribe,"pool_count":0,"triple_reward":unit.triple_reward,"policy":Golden.POLICY,"candidates":plan.choices.duplicate(true)})
	return unit

static func _recruit_random_golden(engine, player: Dictionary, source: Dictionary, leaf: Dictionary) -> bool:
	if leaf.get("type")!=Golden.TYPE: return false
	var issue: String=Sources.leaf_error(source,leaf)
	if issue.is_empty() and (Sources.identity(source) not in Golden.IDS or not Golden.Actual._actual_game_host(engine) or engine.state.get("phase") not in ["recruit","end_turn"] or not engine.state.players.any(func(owner):return is_same(owner,player)) or not player.get("alive",false) or not player.board.any(func(unit):return is_same(unit,source)) or int(source.get("health",0))<=0 or source.get("silenced",false) or source.get("abilities_disabled",false)): issue="golden_resource_requires_actual_native_battlecry"
	if issue.is_empty(): issue=Sources.source_error(engine.catalog.get_card(Sources.identity(source)))
	if not issue.is_empty(): engine._native_result({"ok":false,"error":issue});return true
	for pick in range(int(leaf.count)):
		var unit: Dictionary=draw_random_golden_minion(engine,int(leaf.tier),"",true)
		if engine.state.phase=="error": return true
		if unit.is_empty():
			engine._log("native_golden_resource_empty",{"player":player.id,"source_id":Sources.identity(source),"source_uid":source.uid,"pick":pick,"tier":leaf.tier,"policy":Golden.POLICY})
			continue
		engine._add_hand(player,unit)
		if engine.state.phase=="error": return true
		engine._log("native_golden_resource_battlecry",{"player":player.id,"source_id":Sources.identity(source),"source_uid":source.uid,"pick":pick,"card_id":unit.card_id,"uid":unit.uid,"inserted":player.hand.any(func(member):return is_same(member,unit)),"triple_reward":false,"policy":Golden.POLICY})
	return true

static func recruit(engine, player: Dictionary, source: Dictionary, leaf: Dictionary) -> bool:
	if Chamber.recruit_resource(engine,player,source,leaf): return true
	if _recruit_random_golden(engine,player,source,leaf): return true
	if Bounty.recruit(engine,player,source,leaf): return true
	if leaf.get("type")==Bounty.SPELL:
		var bounty_majority: Dictionary=Bounty.majority_leaf(engine,player,source,leaf)
		if not bounty_majority.ok: engine._native_result(bounty_majority);return true
		var majority_unit: Dictionary=draw_random_minion(engine,bounty_majority.leaf)
		if not majority_unit.is_empty(): engine._add_hand(player,majority_unit)
		return true
	if Chromatic.recruit(engine,player,source,leaf): return true
	if Special.recruit(engine,player,source,leaf): return true
	if not Sources.marker(leaf): return false
	var issue: String = Sources.leaf_error(source,leaf)
	if issue.is_empty() and leaf.get("type") not in ["battlecry_random_resource","battlecry_fixed_resource","end_turn_fixed_resource","spell_random_resource_copy"]: issue = "random_resource_requires_combat_trigger"
	if not issue.is_empty(): engine._native_result({"ok":false,"error":issue}); return true
	if leaf.type in ["battlecry_fixed_resource","end_turn_fixed_resource"]:
		var engineer_fixed: Dictionary=engine.EfficientEngineer.BulkFixed.begin(engine,player,source,leaf)
		if not engineer_fixed.ok: engine._native_result(engineer_fixed);return true
		if AvalancheCallerSources.claimed(source):
			var avalanche_caller_issue: String=AvalancheCallerSources.recruit_error(engine,player,source,leaf)
			if not avalanche_caller_issue.is_empty(): engine._native_result({"ok":false,"error":avalanche_caller_issue});return true
		var child: Dictionary = engine.catalog.get_card(str(leaf.card_id))
		if child.get("kind") != "spell" or not child.get("supported",false) or not Sources.source_error(child).is_empty():
			engine._native_result({"ok":false,"error":"fixed_resource_missing_real_child"}); return true
		for _i in range(int(leaf.count)):
			var fixed_unit: Dictionary=engine._unit(child)
			var fixed_bc_issue: String=engine.FixedResourceRetrigger.delivery(engine,player,source,leaf,fixed_unit,_i,false)
			if not fixed_bc_issue.is_empty(): engine._native_result({"ok":false,"error":fixed_bc_issue});return true
			if engineer_fixed.active:
				issue=engine.EfficientEngineer.check_fixed_copy(engine,player,engineer_fixed.capability,fixed_unit,_i,false)
				if not issue.is_empty(): engine._native_result({"ok":false,"error":issue});return true
			engine._add_hand(player,fixed_unit)
			if engine.state.phase == "error": break
			fixed_bc_issue=engine.FixedResourceRetrigger.delivery(engine,player,source,leaf,fixed_unit,_i,true)
			if not fixed_bc_issue.is_empty(): engine._native_result({"ok":false,"error":fixed_bc_issue});return true
			if engineer_fixed.active:
				issue=engine.EfficientEngineer.check_fixed_copy(engine,player,engineer_fixed.capability,fixed_unit,_i,true)
				if not issue.is_empty(): engine._native_result({"ok":false,"error":issue});return true
		return true
	for _i in range(int(leaf.count)):
		var minion_bc_issue: String=engine.RandomMinionBattlecry.copy_boundary(engine,player,source,leaf,_i,{},"before")
		if not minion_bc_issue.is_empty(): engine._native_result({"ok":false,"error":minion_bc_issue});return true
		var random_bc_issue: String=engine.RandomSpellBattlecry.copy_boundary(engine,player,source,leaf,_i,{},"before")
		if not random_bc_issue.is_empty(): engine._native_result({"ok":false,"error":random_bc_issue});return true
		var unit: Dictionary = draw_random_tavern_spell(engine,int(leaf.cost),int(leaf.tier),int(leaf.minimum_cost)) if leaf.kind == "spell" else draw_random_minion(engine,leaf)
		minion_bc_issue=engine.RandomMinionBattlecry.copy_boundary(engine,player,source,leaf,_i,unit,"drawn")
		if not minion_bc_issue.is_empty(): engine._native_result({"ok":false,"error":minion_bc_issue});return true
		random_bc_issue=engine.RandomSpellBattlecry.copy_boundary(engine,player,source,leaf,_i,unit,"drawn")
		if not random_bc_issue.is_empty(): engine._native_result({"ok":false,"error":random_bc_issue});return true
		if unit.is_empty(): continue
		var copies: Array = []
		# Same selected concrete fresh template, captured before either delivery.
		# Copies have independent host UIDs but never duplicate owned stock.
		for _copy in range(int(leaf.get("copies",0))):
			var allocated: Dictionary = engine._unit(engine.catalog.get_card(str(unit.card_id)))
			if allocated.is_empty():
				engine._return_unit(unit)
				engine._native_result({"ok":false,"error":"resource_copy_factory_failed"}); return true
			var copied: Dictionary = unit.duplicate(true)
			copied.uid = allocated.uid
			copied.pool_count = 0; copied.pool_components = []
			copies.append(copied)
		engine._add_hand(player,unit)
		if engine.state.phase == "error": break
		minion_bc_issue=engine.RandomMinionBattlecry.copy_boundary(engine,player,source,leaf,_i,unit,"after")
		if not minion_bc_issue.is_empty(): engine._native_result({"ok":false,"error":minion_bc_issue});return true
		random_bc_issue=engine.RandomSpellBattlecry.copy_boundary(engine,player,source,leaf,_i,unit,"after")
		if not random_bc_issue.is_empty(): engine._native_result({"ok":false,"error":random_bc_issue});return true
		for copied in copies:
			engine._add_hand(player,copied)
			if engine.state.phase == "error": break
		if engine.state.phase == "error": break
	return true

func initialize(context: Dictionary) -> String:
	_ticket_issued = false
	_native_spellcraft_used={}
	_finite_avenge_used={}
	_fixed_avenge_used={}
	_fixed_hand=FixedHand.new()
	_native_fixed_hand=NativeFixedHand.new()
	_rally_fixed_hand=RallyFixedHand.new()
	_fixed_spell_dr_hand=FixedSpellDRHand.new()
	_random_spell_dr_hand=RandomSpellDRHand.new()
	_random_minion_dr_hand=RandomMinionDRHand.new()
	_random_spell_avenge_hand=RandomSpellAvengeHand.new()
	_summon_get_rally_hand=SummonGetRallyHand.new()
	_context = context.duplicate(true); _journal = []; _stock = {}; _ghost_stock = {}; _initial = {}
	if context.is_empty(): return ""
	if context.get("policy") != POLICY or not context.get("cards") is Dictionary or not context.get("stock") is Dictionary or not context.get("ghost") is bool: return "random_resource_invalid_context"
	for id in context.stock:
		if not _integer(context.stock[id]) or not context.cards.has(id): return "random_resource_invalid_stock"
		var card: Variant = context.cards[id]
		if not card is Dictionary or card.get("id") != id or card.get("kind") not in ["minion","spell"]: return "random_resource_invalid_candidate"
		if card.kind == "spell" and not _integer(card.get("cost")): return "random_resource_invalid_cost"
	_stock = context.stock.duplicate(true); _ghost_stock = _stock.duplicate(true); _initial = _stock.duplicate(true)
	return ""

func activate(engine, side: int, source: Dictionary, leaf: Dictionary) -> void:
	var native_summon_grant: Dictionary={}
	if leaf.get("type")==NativeSummon.TYPE:
		if engine._summon_resource_host==null: engine._fail("summon_resource_missing_private_clock");return
		native_summon_grant=engine._summon_resource_host.native_grant_error(engine,side,source,leaf)
		if not native_summon_grant.ok: engine._fail(str(native_summon_grant.error));return
	if leaf.get("type")==Bounty.RALLY:
		activate_bounty(engine,side,source,leaf,"rally",int(engine._log[-1].get("repetition",0)) if not engine._log.is_empty() else 0)
		return
	if leaf.get("type")==Chromatic.RALLY:
		activate_chromatic(engine,side,source,leaf,"rally",int(engine._log[-1].get("repetition",0)) if not engine._log.is_empty() else 0)
		return
	var issue: String = Sources.leaf_error(source,leaf)
	if issue.is_empty() and _context.is_empty(): issue = "random_resource_missing_effective_pool_context"
	if not issue.is_empty(): engine._fail(issue); return
	var random_hand_ticket: Dictionary={}
	var random_hand_host: RefCounted=null
	if leaf.get("type")=="deathrattle_random_resource":
		if Sources.identity(source) in RandomSpellDRHand.Native.IDS: random_hand_host=_random_spell_dr_hand
		elif Sources.identity(source) in RandomMinionDRHand.Native.IDS: random_hand_host=_random_minion_dr_hand
		elif Sources.identity(source) in RandomSpellAvengeHand.Sources.IDS: random_hand_host=_random_spell_avenge_hand
	if random_hand_host!=null:
		var prepared: Dictionary=random_hand_host.begin(engine,side,source,leaf)
		if not prepared.ok: engine._fail(str(prepared.error));return
		random_hand_ticket=prepared.ticket
	var majority: Dictionary={}
	var draw_leaf: Dictionary=leaf
	if leaf.get("type")==Majority.TYPE:
		majority=Majority.resolve(engine,side,source,leaf)
		if not majority.ok: engine._fail(str(majority.error));return
		draw_leaf=majority.draw_leaf
	var ghost: bool = side == 1 and _context.ghost
	var stock: Dictionary = _ghost_stock if ghost else _stock
	for pick in range(int(leaf.count)):
		if not random_hand_ticket.is_empty() and not random_hand_host.before_pick(engine,random_hand_ticket,pick): return
		var choices: Array = candidates(_context,stock,draw_leaf)
		var total: int = _total(choices)
		if total <= 0:
			engine._emit("random_resource_empty",{"family":FAMILY,"side":side,"source":source.uid,"source_id":Sources.identity(source),"pick":pick})
			if not random_hand_ticket.is_empty() and not random_hand_host.after_empty(engine,random_hand_ticket,pick): return
			continue
		var id: String
		if leaf.has("card_id"):
			# Fixed named minion: exact ID, actual finite stock, no random call.
			id = str(leaf.card_id)
		else:
			# Avoid expanding one array entry per physical copy.
			var ticket: int = engine._rng.randi_range(0,total-1)
			id = _selected(choices,ticket)
			engine._emit("rng",{"purpose":FAMILY,"candidates":choices,"ticket":ticket,"choice":id,"total":total})
		var accepted: int = 1 if engine._hand_counts[side] < 10 else 0
		# Spells release on acquisition; burned minions return immediately.
		var selected_kind: String=str(_context.cards[id].kind)
		var reserved: int = accepted if selected_kind == "minion" else 0
		stock[id] -= reserved
		var metadata: Dictionary = {"resource_family":FAMILY,"resource_policy":POLICY,"source_id":Sources.identity(source),"resource_pick":pick,"resource_pool_count":reserved,"resource_pool_kind":selected_kind,"resource_ghost":ghost}
		if not native_summon_grant.is_empty(): metadata.native_summon_progress=int(native_summon_grant.sequence)
		if not majority.is_empty(): metadata.merge(majority.metadata,false)
		var random_hand_plan: Dictionary={}
		if not random_hand_ticket.is_empty():
			var checked: Dictionary=random_hand_host.after_draw(engine,random_hand_ticket,pick,choices,total,id)
			if not checked.ok: engine._fail(str(checked.error));return
			random_hand_plan=checked.plan
		var sequence: int = engine._log.size()
		engine._queue_card_reward(side,source,id,1,metadata)
		if not engine._error.is_empty(): return
		if not random_hand_ticket.is_empty():
			issue=FixedHand.Hand.after_error(engine,random_hand_plan)
			if issue.is_empty(): issue=random_hand_host.after_card(engine,random_hand_ticket,pick,engine._log[sequence])
			if not issue.is_empty(): engine._fail(issue);return
		_journal.append(engine._log[sequence].duplicate(true))
	if not random_hand_ticket.is_empty():
		if not random_hand_host.finish(engine,random_hand_ticket): return

func activate_dark_gift(engine,side: int,source: Dictionary,token: int) -> void:
	var grant: Dictionary=engine._dark_gift_resource_host.take_random_grant(engine,side,source,token)
	if not str(grant.error).is_empty(): engine._fail(str(grant.error));return
	var plan: Dictionary=grant.plan
	var tribe: String=""
	if plan.kind=="minion":
		tribe=str(plan.census.tied[engine._random_index(plan.census.tied.size(),"dark_gift_actual_majority_type",plan.census.tied)])
		engine._emit("dark_gift_majority_census",{"side":side,"source":source.uid,"gift_id":grant.gift_id,"census":plan.census.duplicate(true),"tribe":tribe,"policy":grant.policy})
	var choices: Array=plan.by_type[tribe].choices
	var total: int=int(plan.by_type[tribe].total)
	var ghost: bool=side==1 and _context.ghost
	var metadata: Dictionary={"dark_gift_resource_family":grant.family,"gift_id":grant.gift_id,"gift_receipt":grant.receipt.duplicate(true),"gift_origin":grant.origin.duplicate(true),"dark_gift_random_token":token,"dark_gift_random_policy":grant.policy,"dark_gift_majority_tribe":tribe}
	if total==0:
		metadata.merge({"side":side,"source":source.uid,"kind":plan.kind},false)
		engine._emit("dark_gift_random_empty",metadata)
		return
	var draw: int=engine._rng.randi_range(0,total-1)
	var id: String=_selected(choices,draw)
	engine._emit("rng",{"purpose":"dark_gift_actual_resource","candidates":choices,"ticket":draw,"choice":id,"total":total})
	var reserved: int=1 if plan.kind=="minion" and engine._hand_counts[side]<10 else 0
	var stock: Dictionary=_ghost_stock if ghost else _stock
	stock[id]-=reserved
	metadata.merge({"resource_family":FAMILY,"resource_policy":POLICY,"source_id":source.card_id,"resource_pick":0,"resource_pool_count":reserved,"resource_pool_kind":plan.kind,"resource_ghost":ghost},false)
	var sequence: int=engine._log.size()
	if plan.kind=="spell": engine._dark_gift_resource_host.queue_spell(engine,side,source,id,1,metadata)
	else: engine._queue_card_reward(side,source,id,1,metadata)
	if not engine._error.is_empty(): return
	_journal.append(engine._log[sequence].duplicate(true))

func activate_volumizer(engine,side: int,source: Dictionary,leaf: Dictionary,trigger: String,repetition: int) -> void:
	var issue: String=VolumizerSpecial.combat_error(engine,side,source,leaf,trigger,repetition)
	if issue.is_empty() and _context.is_empty(): issue="volumizer_resource_missing_actual_owner_context"
	if issue.is_empty(): issue=VolumizerSpecial.context_error(_context.get(VolumizerSpecial.KEY,{}),engine._options.get("hand_card_templates",{}))
	if not issue.is_empty(): engine._fail(issue);return
	var ghost: bool=side==1 and _context.ghost
	for pick in range(int(leaf.count)):
		var id: String=str(VolumizerSpecial.NORMALS[engine._random_index(VolumizerSpecial.NORMALS.size(),"native_volumizer_uniform_child",VolumizerSpecial.NORMALS)])
		var metadata: Dictionary={"resource_family":FAMILY,"resource_policy":POLICY,"source_id":Sources.identity(source),"resource_pick":pick,"resource_pool_count":0,"resource_pool_kind":"minion","resource_ghost":ghost,"resource_special_policy":VolumizerSpecial.POLICY,"resource_special_pool":VolumizerSpecial.NORMALS.duplicate()}
		var sequence: int=engine._log.size()
		engine._queue_card_reward(side,source,id,1,metadata)
		if not engine._error.is_empty(): return
		_journal.append(engine._log[sequence].duplicate(true))

func activate_chromatic(engine,side: int,source: Dictionary,leaf: Dictionary,trigger: String,repetition: int) -> void:
	var issue: String=Chromatic.combat_error(engine,side,source,leaf,trigger,repetition)
	if issue.is_empty() and _context.is_empty(): issue="chromatic_missing_real_resource_context"
	if issue.is_empty(): issue=Chromatic.context_error(_context.get(Chromatic.KEY,{}),engine._options.get("hand_card_templates",{}))
	if not issue.is_empty(): engine._fail(issue);return
	var ghost: bool=side==1 and _context.ghost
	for pick in range(int(leaf.count)):
		var id: String=str(Chromatic.NORMALS[engine._random_index(Chromatic.NORMALS.size(),"chromatic_uniform_child",Chromatic.NORMALS)])
		var metadata: Dictionary={"resource_family":FAMILY,"resource_policy":POLICY,"source_id":Sources.identity(source),"resource_pick":pick,"resource_pool_count":0,"resource_pool_kind":"minion","resource_ghost":ghost,"resource_special_policy":Chromatic.POLICY,"resource_special_pool":Chromatic.NORMALS.duplicate()}
		var sequence: int=engine._log.size()
		engine._queue_card_reward(side,source,id,1,metadata)
		if not engine._error.is_empty(): return
		_journal.append(engine._log[sequence].duplicate(true))

func activate_bounty(engine, side: int, source: Dictionary, leaf: Dictionary, trigger: String, repetition: int) -> void:
	var issue: String=Bounty.combat_error(engine,side,source,leaf,trigger,repetition)
	if issue.is_empty() and _context.is_empty(): issue="bounty_missing_real_resource_context"
	if issue.is_empty(): issue=Bounty.context_error(_context.get(Bounty.KEY,{}),engine._options.get("hand_card_templates",{}))
	if not issue.is_empty(): engine._fail(issue);return
	var ghost: bool=side==1 and _context.ghost
	for pick in range(int(leaf.count)):
		var id: String=str(Bounty.IDS[engine._random_index(Bounty.IDS.size(),"bounty_uniform_child",Bounty.IDS)])
		var metadata: Dictionary={"resource_family":FAMILY,"resource_policy":POLICY,"source_id":Sources.identity(source),"resource_pick":pick,"resource_pool_count":0,"resource_pool_kind":"spell","resource_ghost":ghost,"resource_special_policy":Bounty.POLICY,"resource_special_pool":Bounty.IDS.duplicate()}
		var sequence: int=engine._log.size()
		engine._queue_card_reward(side,source,id,1,metadata)
		if not engine._error.is_empty(): return
		_journal.append(engine._log[sequence].duplicate(true))

func activate_finite_avenge(engine, side: int, source: Dictionary, leaf: Dictionary, trigger: String, repetition: int) -> void:
	var issue: String=FiniteAvenge.combat_error(engine,side,source,leaf,trigger,repetition)
	if issue.is_empty() and _context.is_empty(): issue="finite_avenge_missing_private_resource_context"
	var pool: String=str(leaf.get("special_pool",""))
	if issue.is_empty(): issue=FiniteAvenge.context_error(_context.get(FiniteAvenge.KEY,{}),engine._options.get("hand_card_templates",{}),pool)
	if not issue.is_empty(): engine._fail(issue);return
	var choices: Array=_context[FiniteAvenge.KEY].pools[pool].ids
	var ghost: bool=side==1 and _context.ghost
	var trigger_sequence: int=engine._log.size()-1
	if _finite_avenge_used.has(trigger_sequence): engine._fail("finite_avenge_reused_real_trigger");return
	_finite_avenge_used[trigger_sequence]=true
	for pick in range(int(leaf.count)):
		var id: String=str(choices[engine._random_index(choices.size(),"finite_avenge_uniform_"+pool,choices)])
		var kind: String=str(FiniteAvenge.CHILDREN[id].kind)
		var metadata: Dictionary={"resource_family":FAMILY,"resource_policy":POLICY,"source_id":Sources.identity(source),"resource_pick":pick,"resource_pool_count":0,"resource_pool_kind":kind,"resource_ghost":ghost,"resource_special_policy":FiniteAvenge.POLICY,"resource_special_pool":choices.duplicate(),"finite_avenge_pool":pool,"finite_avenge_trigger":trigger_sequence}
		var sequence: int=engine._log.size()
		engine._queue_card_reward(side,source,id,1,metadata)
		if not engine._error.is_empty(): return
		_journal.append(engine._log[sequence].duplicate(true))

func activate_special(engine, side: int, source: Dictionary, leaf: Dictionary, trigger: String, repetition: int) -> void:
	var issue: String=Special.combat_error(engine,side,source,leaf,trigger,repetition)
	if issue.is_empty() and _context.is_empty(): issue="magnetic_special_missing_real_resource_context"
	if issue.is_empty(): issue=Special.context_error(_context.get(Special.KEY,{}),engine._options.get("hand_card_templates",{}))
	if not issue.is_empty(): engine._fail(issue);return
	var ghost: bool=side==1 and _context.ghost
	for pick in range(int(leaf.count)):
		var id: String=str(Special.NORMALS[engine._random_index(Special.NORMALS.size(),"magnetic_special_uniform_child",Special.NORMALS)])
		# A canonical non-stock child: do not consume an ordinary effective slot.
		var metadata: Dictionary={"resource_family":FAMILY,"resource_policy":POLICY,"source_id":Sources.identity(source),"resource_pick":pick,"resource_pool_count":0,"resource_pool_kind":"minion","resource_ghost":ghost,"resource_special_policy":Special.POLICY,"resource_special_pool":Special.NORMALS.duplicate()}
		var sequence: int=engine._log.size()
		engine._queue_card_reward(side,source,id,1,metadata)
		if not engine._error.is_empty(): return
		_journal.append(engine._log[sequence].duplicate(true))

func activate_linked_undead(engine,source: Dictionary,side: int,leaf: Dictionary,activation_sequence: int,death_sequence: int,dead_uid: String) -> void:
	var ghost: bool=side==1 and _context.ghost
	var stock: Dictionary=_ghost_stock if ghost else _stock
	for pick in range(int(leaf.count)):
		var choices: Array=candidates(_context,stock,leaf)
		var total: int=_total(choices)
		if total<=0:
			engine._emit("random_resource_empty",{"family":FAMILY,"side":side,"source":source.uid,"source_id":source.card_id,"pick":pick})
			# A missing pick creates no hand reference, but keeps native pick order.
			engine._linked_undead_host._bundles[int(source._combat_id)].next_pick+=1
			continue
		var ticket: int=engine._rng.randi_range(0,total-1)
		var id: String=_selected(choices,ticket)
		engine._emit("rng",{"purpose":"linked_undead_actual_resource","candidates":choices,"ticket":ticket,"choice":id,"total":total})
		var accepted: int=1 if engine._hand_counts[side]<10 else 0
		stock[id]-=accepted
		var metadata: Dictionary={"resource_family":FAMILY,"resource_policy":POLICY,"source_id":source.card_id,"resource_pick":pick,"resource_pool_count":accepted,"resource_pool_kind":"minion","resource_ghost":ghost,"linked_undead_trigger":activation_sequence,"linked_undead_death":death_sequence,"linked_undead_dead_uid":dead_uid}
		var sequence: int=engine._log.size()
		engine._queue_card_reward(side,source,id,1,metadata)
		if not engine._error.is_empty(): return
		_journal.append(engine._log[sequence].duplicate(true))

func activate_fixed_avenge(engine,entry: Dictionary,leaf: Dictionary,trigger: String,repetition: int) -> void:
	var issue: String=PastryAvenge.combat_error(engine,entry,leaf,trigger,repetition)
	if issue.is_empty() and _context.is_empty(): issue="pastry_avenge_missing_private_resource_context"
	if issue.is_empty(): issue=PastryAvenge.template_error(engine._options.get("hand_card_templates",{}).get(PastryAvenge.CHILD,{}))
	if not issue.is_empty(): engine._fail(issue);return
	var trigger_sequence: int=engine._log.size()-1
	if _fixed_avenge_used.has(trigger_sequence): engine._fail("pastry_avenge_reused_actual_payload");return
	_fixed_avenge_used[trigger_sequence]=true
	var side: int=int(entry.side);var source: Dictionary=entry.unit
	var ghost: bool=side==1 and _context.ghost
	for pick in range(int(leaf.count)):
		# Reuse actual fixed-spell queue/materialization and trusted stock journal.
		# This is generated identity, never an inventory draw or protected trinket.
		var metadata: Dictionary={"resource_family":FAMILY,"resource_policy":POLICY,"source_id":source.card_id,"resource_pick":pick,"resource_pool_count":0,"resource_pool_kind":"spell","resource_ghost":ghost,"fixed_avenge_trigger":trigger_sequence,"fixed_avenge_death":entry.actual_death_sequence,"fixed_avenge_dead_uid":entry.actual_dead_uid}
		var sequence: int=engine._log.size()
		engine._queue_card_reward(side,source,PastryAvenge.CHILD,1,metadata)
		if not engine._error.is_empty(): return
		_journal.append(engine._log[sequence].duplicate(true))

func activate_fixed_spell(engine, side: int, source: Dictionary, leaf: Dictionary) -> void:
	var issue: String = Sources.leaf_error(source,leaf)
	if issue.is_empty() and _context.is_empty(): issue = "fixed_resource_missing_host_context"
	var id: String = str(leaf.get("card_id",""))
	var template: Dictionary = engine._options.get("hand_card_templates",{}).get(id,{})
	var programs: Dictionary = {"BG20_GEM":[{"type":"spell_blood_gem","scope":"target","allow_shop":true,"count":1,"attack":1,"health":1}],"TB_BaconShop_HP_008a":[{"type":"spell_gold","amount":1,"temporary":false}]}
	if id in FixedEvents.CHILDREN:
		programs[id]=FixedEvents.CHILDREN[id].effects
		if issue.is_empty(): issue=FixedEvents.template_error(id,template)
	if id in ["BG35_911","BG36_880","BG28_518","BG34_689"]:
		programs[id] = Sources.program_for(id)
		if issue.is_empty(): issue = Sources.unit_error(template)
	if id==Sources.Tomb.SPELL:
		programs[id]=Sources.Tomb.PROGRAMS[id].duplicate(true)
		if issue.is_empty(): issue=Sources.Tomb.unit_error(template)
	if id==Chamber.Sources.CHILD:
		programs[id]=Chamber.Sources.program_for(id)
		if issue.is_empty(): issue=Chamber.Sources.unit_error(template)
	var native_shield: bool=Sources.identity(source) in FixedEvents.SHIELD_IDS and leaf.get("type")=="on_shield_lost_add_card" and id=="BG20_GEM"
	if issue.is_empty() and ((leaf.get("kind")!="spell" and not native_shield) or template.get("kind")!="spell" or not programs.has(id) or not Sources.same(template.get("effects"),programs.get(id))): issue="fixed_resource_missing_real_spell_template"
	if not issue.is_empty(): engine._fail(issue); return
	var fixed_ticket: Dictionary={}
	var fixed_hand_host=_fixed_spell_dr_hand if Sources.identity(source) in FixedSpellDRHand.Native.IDS else _fixed_hand
	if Sources.identity(source) in FixedEvents.IDS or Sources.identity(source) in FixedSpellDRHand.Native.IDS:
		var prepared: Dictionary=fixed_hand_host.begin(engine,side,source,leaf)
		if not prepared.ok: engine._fail(str(prepared.error));return
		fixed_ticket=prepared.ticket
	var ghost: bool = side == 1 and _context.ghost
	for pick in range(int(leaf.count)):
		# Fixed non-pool spell generation never draws or reserves inventory.
		var metadata: Dictionary = {"resource_family":FAMILY,"resource_policy":POLICY,"source_id":Sources.identity(source),"resource_pick":pick,"resource_pool_count":0,"resource_pool_kind":"spell","resource_ghost":ghost}
		var card_plan: Dictionary={}
		if not fixed_ticket.is_empty():
			card_plan=FixedHand.Hand.plan(engine,side,source,id,1)
			if not card_plan.ok: engine._fail(str(card_plan.error));return
			issue=FixedHand.Hand.before_error(engine,card_plan)
			if not issue.is_empty(): engine._fail(issue);return
		var sequence: int = engine._log.size()
		engine._queue_card_reward(side,source,id,1,metadata)
		if not engine._error.is_empty(): return
		if not fixed_ticket.is_empty():
			issue=FixedHand.Hand.after_error(engine,card_plan)
			if issue.is_empty(): issue=fixed_hand_host.after_card(engine,fixed_ticket,engine._log[sequence])
			if not issue.is_empty(): engine._fail(issue);return
		_journal.append(engine._log[sequence].duplicate(true))
	if not fixed_ticket.is_empty():
		issue=fixed_hand_host.finish(engine,fixed_ticket)
		if not issue.is_empty(): engine._fail(issue)

func activate_raptor_avenge(engine,side: int,source_uid: String,progress_sequence: int) -> void:
	if side not in [0,1] or _context.is_empty() or engine._raptor_avenge_host==null or not engine._raptor_avenge_host.consume_grant(side,source_uid,progress_sequence): engine._fail("raptor_resource_missing_actual_avenge_capability");return
	var ghost: bool=side==1 and _context.ghost
	var stock: Dictionary=_ghost_stock if ghost else _stock
	var choices: Array=candidates(_context,stock,RaptorAvengeSources.LEAF)
	var total: int=_total(choices)
	if total<=0:
		engine._emit("raptor_avenge_empty",{"side":side,"source":source_uid,"source_id":RaptorAvengeSources.ID,"progress_sequence":progress_sequence});return
	for choice in choices:
		var template: Dictionary=engine._options.get("hand_card_templates",{}).get(choice.id,{})
		if template.is_empty() or template.get("kind")!="minion" or template.get("card_id")!=choice.id: engine._fail("raptor_resource_missing_actual_minion_template");return
	var ticket: int=engine._rng.randi_range(0,total-1)
	var id: String=_selected(choices,ticket)
	engine._emit("rng",{"purpose":"raptor_avenge_effective_stock_weighted","candidates":choices,"ticket":ticket,"choice":id,"total":total})
	var accepted: int=1 if engine._hand_counts[side]<10 else 0
	stock[id]-=accepted
	var metadata: Dictionary={"resource_family":FAMILY,"resource_policy":POLICY,"source_id":RaptorAvengeSources.ID,"resource_pick":0,"resource_pool_count":accepted,"resource_pool_kind":"minion","resource_ghost":ghost,"raptor_progress":progress_sequence}
	var sequence: int=engine._log.size()
	engine._queue_card_reward(side,{"uid":source_uid,"card_id":RaptorAvengeSources.ID,"kind":"spell","effects":RaptorAvengeSources.PROGRAM.duplicate(true)},id,1,metadata)
	if not engine._error.is_empty(): return
	_journal.append(engine._log[sequence].duplicate(true))

func activate_owned_shield_trinket(engine,side: int,source_slot: String,progress: int) -> void:
	var source_id: String="BG32_MagicItem_171"
	if side not in [0,1] or _context.is_empty() or engine._owned_observer_host==null or not engine._owned_observer_host.consume_grant(side,source_slot,progress): engine._fail("shield_resource_missing_private_grant");return
	var leaf: Dictionary=DeathTrinketSources.filtered_leaf(source_id)
	var ghost: bool=side==1 and _context.ghost
	var stock: Dictionary=_ghost_stock if ghost else _stock
	var choices: Array=candidates(_context,stock,leaf)
	var total: int=_total(choices)
	if total<=0:
		engine._emit("owned_shield_resource_empty",{"side":side,"source_id":source_id,"source_slot":source_slot,"progress_sequence":progress});return
	var ticket: int=engine._rng.randi_range(0,total-1)
	var id: String=_selected(choices,ticket)
	engine._emit("rng",{"purpose":"owned_shield_trinket_stock_weighted","candidates":choices,"ticket":ticket,"choice":id,"total":total})
	if _context.cards[id].kind!="spell": engine._fail("shield_resource_nonspell_reward");return
	var metadata: Dictionary={"resource_family":FAMILY,"resource_policy":POLICY,"source_id":source_id,"source_slot":source_slot,"resource_pick":0,"resource_pool_count":0,"resource_pool_kind":"spell","resource_ghost":ghost,"resource_protected":true,"owned_shield_resource_family":"actual-owned-slot-shield-resource-v1","shield_progress_sequence":progress}
	var sequence: int=engine._log.size()
	engine._queue_card_reward(side,{"uid":source_slot,"card_id":source_id,"kind":"trinket","effects":DeathTrinketSources.PROGRAMS[source_id].duplicate(true)},id,1,metadata)
	if not engine._error.is_empty(): return
	_journal.append(engine._log[sequence].duplicate(true))

func activate_owned_death_trinket(engine,side: int,source_id: String,source_slot: String,death_sequence: int) -> void:
	if source_id not in DeathTrinketSources.DEATH_IDS or side not in [0,1] or _context.is_empty(): engine._fail("death_trinket_resource_missing_context");return
	var slot: PackedStringArray=source_slot.split(":")
	if slot.size()!=4 or slot[0]!="trinket" or slot[2]!=source_id or slot[3]!="0" or not slot[1].is_valid_int() or int(slot[1])<0: engine._fail("death_trinket_resource_invalid_slot");return
	var leaf: Dictionary=DeathTrinketSources.filtered_leaf(source_id)
	var ghost: bool=side==1 and _context.ghost
	var stock: Dictionary=_ghost_stock if ghost else _stock
	var choices: Array=candidates(_context,stock,leaf)
	var total: int=_total(choices)
	if total<=0:
		engine._emit("death_trinket_resource_empty",{"side":side,"source_id":source_id,"source_slot":source_slot,"death_sequence":death_sequence});return
	var ticket: int=engine._rng.randi_range(0,total-1)
	var id: String=_selected(choices,ticket)
	engine._emit("rng",{"purpose":"owned_death_trinket_stock_weighted","candidates":choices,"ticket":ticket,"choice":id,"total":total})
	var kind: String=str(_context.cards[id].kind)
	var reserved: int=1 if kind=="minion" else 0
	stock[id]-=reserved
	var metadata: Dictionary={"resource_family":FAMILY,"resource_policy":POLICY,"source_id":source_id,"source_slot":source_slot,"resource_pick":0,"resource_pool_count":reserved,"resource_pool_kind":kind,"resource_ghost":ghost,"resource_protected":true,"owned_death_resource_family":"actual-owned-slot-death-resource-v1","death_sequence":death_sequence}
	var sequence: int=engine._log.size()
	engine._queue_card_reward(side,{"uid":source_slot,"card_id":source_id,"kind":"trinket","effects":DeathTrinketSources.PROGRAMS[source_id].duplicate(true)},id,1,metadata)
	if not engine._error.is_empty(): return
	_journal.append(engine._log[sequence].duplicate(true))

func activate_owned_summon_trinket(engine,side: int,source_id: String,source_slot: String,summon_sequence: int) -> void:
	if source_id not in DeathTrinketSources.SUMMON_IDS or side not in [0,1] or _context.is_empty(): engine._fail("summon_trinket_resource_missing_context");return
	var slot: PackedStringArray=source_slot.split(":")
	if slot.size()!=4 or slot[0]!="trinket" or slot[2]!=source_id or slot[3]!="0" or not slot[1].is_valid_int() or int(slot[1])<0: engine._fail("summon_trinket_resource_invalid_slot");return
	var leaf: Dictionary=DeathTrinketSources.filtered_leaf(source_id)
	var ghost: bool=side==1 and _context.ghost
	var stock: Dictionary=_ghost_stock if ghost else _stock
	var choices: Array=candidates(_context,stock,leaf)
	var total: int=_total(choices)
	if total<=0:
		engine._emit("summon_trinket_resource_empty",{"side":side,"source_id":source_id,"source_slot":source_slot,"summon_sequence":summon_sequence});return
	var ticket: int=engine._rng.randi_range(0,total-1)
	var id: String=_selected(choices,ticket)
	engine._emit("rng",{"purpose":"owned_summon_trinket_stock_weighted","candidates":choices,"ticket":ticket,"choice":id,"total":total})
	var kind: String=str(_context.cards[id].kind)
	var reserved: int=1 if kind=="minion" else 0
	stock[id]-=reserved
	var metadata: Dictionary={"resource_family":FAMILY,"resource_policy":POLICY,"source_id":source_id,"source_slot":source_slot,"resource_pick":0,"resource_pool_count":reserved,"resource_pool_kind":kind,"resource_ghost":ghost,"resource_protected":true,"owned_summon_resource_family":"actual-owned-slot-summon-resource-v1","summon_sequence":summon_sequence}
	var sequence: int=engine._log.size()
	engine._queue_card_reward(side,{"uid":source_slot,"card_id":source_id,"kind":"trinket","effects":DeathTrinketSources.PROGRAMS[source_id].duplicate(true)},id,1,metadata)
	if not engine._error.is_empty(): return
	_journal.append(engine._log[sequence].duplicate(true))

func activate_energy_recycling(engine,side: int,slot: String,progress: int) -> void:
	if _context.is_empty() or not engine._energy_recycling_host.consume(engine,side,slot,progress):engine._fail("energy_recycling_missing_private_grant");return
	var choices: Array=candidates(_context,_stock,{"kind":"spell","tier":-1,"cost":-1,"minimum_cost":-1,"effect_filter":"","tribe":""})
	var total: int=_total(choices)
	if total<=0:
		engine._emit("energy_recycling_empty",{"side":side,"source_id":EnergySources.ID,"source_slot":slot,"progress":progress});return
	var draw: int=engine._rng.randi_range(0,total-1)
	var id: String=_selected(choices,draw)
	engine._emit("rng",{"purpose":"energy_recycling_native_spell_stock","candidates":choices,"ticket":draw,"choice":id,"total":total})
	var metadata: Dictionary={"resource_family":FAMILY,"resource_policy":POLICY,"source_id":EnergySources.ID,"source_slot":slot,"resource_pick":0,"resource_pool_count":0,"resource_pool_kind":"spell","resource_ghost":false,"resource_protected":true,"resource_special_policy":EnergySources.FAMILY,"energy_recycling_family":EnergySources.FAMILY,"energy_recycling_progress":progress}
	var sequence: int=engine._log.size()
	engine._queue_card_reward(side,{"uid":slot,"card_id":EnergySources.ID,"kind":"reward","effects":EnergySources.PROGRAM.duplicate(true)},id,1,metadata)
	if not engine._error.is_empty():return
	_journal.append(engine._log[sequence].duplicate(true))

func ticket() -> Dictionary:
	if _ticket_issued: return {}
	_ticket_issued = true
	if _summon_get_used: _journal.sort_custom(func(a,b):return int(a.sequence)<int(b.sequence))
	return {"policy":POLICY,"events":_journal.duplicate(true),"initial":_initial.duplicate(true),"ghost":_context.get("ghost",false)}

static func settlement_error(engine, result: Dictionary, ticket: Dictionary, ghost: bool) -> String:
	var actual: Array = []
	for event in result.get("log",[]):
		if event.has("resource_family") or event.has("resource_pool_count"): actual.append(event)
	if actual.is_empty() and ticket.is_empty(): return ""
	if ticket.get("policy") != POLICY or ticket.get("ghost") != ghost or not Sources.same(actual,ticket.get("events")): return "random_resource_untrusted_or_changed_journal"
	var required: Dictionary = {}
	for event in actual:
		if event.get("type") != "recruit_add_card" or event.get("resource_family") != FAMILY or event.get("resource_policy") != POLICY or event.get("count") != 1: return "random_resource_invalid_receipt"
		if event.has("seafloor_cast_start") or event.get("source_id") in SeafloorCastSources.IDS:
			var seafloor_receipt_issue: String=SeafloorCastSources.receipt_error(event,result.get("log",[]))
			if not seafloor_receipt_issue.is_empty(): return seafloor_receipt_issue
		if event.has("raptor_progress"):
			var raptor_receipt_issue: String=engine.RaptorAvenge.receipt_error(event,result.get("log",[]))
			if not raptor_receipt_issue.is_empty(): return raptor_receipt_issue
		if event.has("linked_undead_trigger"):
			var linked_undead_receipt_issue: String=LinkedUndeadSources.receipt_error(event,result.get("log",[]))
			if not linked_undead_receipt_issue.is_empty(): return linked_undead_receipt_issue
		if event.has("fixed_avenge_trigger"):
			var pastry_receipt_issue: String=PastryAvenge.receipt_error(event,result.get("log",[]))
			if not pastry_receipt_issue.is_empty(): return pastry_receipt_issue
		if event.has("finite_avenge_trigger"):
			var finite_receipt_issue: String=FiniteAvenge.receipt_error(event,result.get("log",[]))
			if not finite_receipt_issue.is_empty(): return finite_receipt_issue
		if event.has("summon_get_sequence"):
			var summon_get_receipt_issue: String=SummonGet.receipt_error(event,result.get("log",[]))
			if not summon_get_receipt_issue.is_empty(): return summon_get_receipt_issue
		if event.has("native_summon_progress"):
			var progress_index: Variant=event.native_summon_progress
			if event.get("source_id") not in NativeSummon.IDS or not progress_index is int or int(progress_index)<0 or int(progress_index)>=result.get("log",[]).size(): return "summon_resource_invalid_private_progress_reference"
			var progress: Dictionary=result.log[int(progress_index)]
			if progress.get("event")!=NativeSummon.PROGRESS or progress.get("native_summon_resource_family")!=NativeSummon.FAMILY or progress.get("side")!=event.get("side") or progress.get("source")!=event.get("source") or progress.get("source_id")!=event.get("source_id") or progress.get("grant")!=true: return "summon_resource_journal_progress_changed"
		if event.get("resource_spellcraft_expiry",false):
			if event.get("source_id") not in ["BG26_590","BG26_590_G"]+NativeSpellcraft.IDS+RustyTridentSources.IDS or event.get("resource_special_policy")!=RandomSpellcraft.Sources.POLICY or not RandomSpellcraft.Sources.CANDIDATES.has(event.get("card_id")) or event.get("resource_pool_count")!=0 or event.get("resource_pool_kind")!="spell": return "damage_spellcraft_invalid_real_journal_receipt"
		if event.get("source_id") in RustyTridentSources.IDS or event.has("rusty_trident_trigger"):
			var rusty_trident_receipt_issue: String=RustyTridentSources.receipt_error(event,result.get("log",[]))
			if not rusty_trident_receipt_issue.is_empty(): return rusty_trident_receipt_issue
		if event.has("native_spellcraft_trigger"):
			var trigger_index: Variant=event.native_spellcraft_trigger
			if event.get("source_id") not in NativeSpellcraft.IDS or not trigger_index is int or trigger_index<0 or trigger_index>=result.get("log",[]).size(): return "native_spellcraft_invalid_journal_trigger"
			var native_trigger: Dictionary=result.log[trigger_index]
			var native_leaf: Dictionary=NativeSpellcraft.leaf_for(str(event.source_id))
			if native_trigger.get("side")!=event.get("side") or native_trigger.get("effect")!=native_leaf.type or native_trigger.get("source")!=event.get("source"): return "native_spellcraft_journal_source_mismatch"
			if event.get("native_spellcraft_category") not in ["spellcraft","tavern"] or (event.native_spellcraft_category=="spellcraft")!=event.get("resource_spellcraft_expiry",false): return "native_spellcraft_journal_category_mismatch"
		if event.has("owned_shield_resource_family"):
			var index: Variant=event.get("shield_progress_sequence")
			if event.get("source_id")!="BG32_MagicItem_171" or not _integer(index) or index>=result.get("log",[]).size() or event.get("resource_pool_count")!=0 or event.get("resource_pool_kind")!="spell": return "shield_resource_invalid_journal_reference"
			var progress: Dictionary=result.log[int(index)]
			if progress.get("event")!="owned_shield_resource_progress" or progress.get("owned_shield_resource_family")!=event.owned_shield_resource_family or progress.get("side")!=event.get("side") or progress.get("source_id")!=event.source_id or progress.get("source_slot")!=event.get("source_slot"): return "shield_resource_journal_progress_changed"
		if event.get("source_id")==EnergySources.ID or event.has("energy_recycling_family"):
			var energy_receipt_issue: String=EnergySources.receipt_error(event,result.get("log",[]))
			if not energy_receipt_issue.is_empty():return energy_receipt_issue
		if event.get("resource_protected",false):
			if not DeathTrinketSources.protected_family_matches(event) or event.get("queued_count")!=1-int(event.get("accepted_count",-1)) or event.get("burned_count")!=0: return "death_resource_invalid_protected_receipt"
		if ghost and event.side == 1: continue
		var id: String = str(event.card_id)
		required[id] = int(required.get(id,0))+int(event.resource_pool_count)
	for id in required:
		if required[id] > int(engine.pool.get(id,0)): return "random_resource_stock_changed_before_settlement"
	return ""

static func award(engine, player: Dictionary, card: Dictionary, event: Dictionary) -> Array:
	if event.get("resource_protected",false): return engine._award_protected_trinket_resource(player,card,event)
	var added: Array = []
	if event.accepted_count == 0:
		engine._log("hand_overflow",{"player":player.id,"count":1,"message":player.name+" 手牌已满，未获得 "+str(card.get("name","卡牌"))})
		return added
	if player.hand.size() >= 10:
		engine._native_result({"ok":false,"error":"random_resource_hand_changed_before_settlement"}); return added
	var unit: Dictionary = engine._unit(card)
	if unit.is_empty(): return added
	if event.get("resource_spellcraft_expiry",false):
		unit.is_spellcraft=true;unit.expires_at_end_turn=true
	if event.resource_pool_count == 1:
		engine.pool[event.card_id] -= 1
		unit.pool_id = event.card_id; unit.pool_kind = "minion"; unit.pool_count = 1
	engine._add_hand(player,unit)
	added.append(unit)
	return added

func activate_native_spellcraft(engine,side: int,source: Dictionary,leaf: Dictionary,trigger: String,repetition: int) -> void:
	var issue: String=NativeSpellcraft.combat_error(engine,side,source,leaf,trigger,repetition)
	var context: Dictionary=_context.get(NativeSpellcraft.KEY,{})
	if issue.is_empty(): issue=NativeSpellcraft.context_error(context,engine._options.get("hand_card_templates",{}))
	var maximum_tier: int=-1
	if issue.is_empty() and leaf.current_tier_or_lower:
		var tiers: Variant=_context.get(NativeSpellcraft.TIERS)
		if not tiers is Array or tiers.size()!=2 or not tiers[side] is int or tiers[side]<1 or tiers[side]>7: issue="combat_spellcraft_missing_actual_owner_tier"
		else: maximum_tier=int(tiers[side])
	var activation_sequence: int=engine._log.size()-1
	if issue.is_empty() and _native_spellcraft_used.has(activation_sequence): issue="combat_spellcraft_reused_actual_trigger"
	if not issue.is_empty(): engine._fail(issue);return
	var ids: Array=NativeSpellcraft.selected_ids(context,maximum_tier)
	var ghost: bool=side==1 and _context.ghost
	var stock: Dictionary=_ghost_stock if ghost else _stock
	# Whole native program: one Spellcraft group followed by one Tavern group.
	# Golden quantities independently bound; every pick is a separate draw.
	_native_spellcraft_used[activation_sequence]=true
	for category in ["spellcraft","tavern"]:
		var count: int=int(leaf.spellcraft_count) if category=="spellcraft" else int(leaf.tavern_count)
		for pick in range(count):
			var id: String=""
			if category=="spellcraft":
				if not ids.is_empty(): id=str(ids[engine._random_index(ids.size(),"native_combat_spellcraft_uniform",ids)])
			else:
				var choices: Array=candidates(_context,stock,{"kind":"spell"})
				var total: int=_total(choices)
				if total>0:
					var draw: int=engine._rng.randi_range(0,total-1)
					id=_selected(choices,draw)
					engine._emit("rng",{"purpose":"native_spellcraft_tavern_group","candidates":choices,"ticket":draw,"choice":id,"total":total})
			if not engine._error.is_empty(): return
			if id.is_empty():
				engine._emit("native_spellcraft_empty_domain",{"side":side,"source":source.uid,"source_id":source.card_id,"category":category,"pick":pick,"maximum_parent_tier":maximum_tier})
				continue
			var metadata: Dictionary={"resource_family":FAMILY,"resource_policy":POLICY,"source_id":source.card_id,"resource_pick":pick,"resource_pool_count":0,"resource_pool_kind":"spell","resource_ghost":ghost,"native_spellcraft_trigger":activation_sequence,"native_spellcraft_category":category,"native_spellcraft_maximum_tier":maximum_tier}
			if category=="spellcraft": metadata.merge({"resource_special_policy":RandomSpellcraft.Sources.POLICY,"resource_special_pool":ids.duplicate(),"resource_spellcraft_expiry":true},false)
			# Tavern spells release their virtual reservation immediately; both
			# families are fresh non-owning spells. Full hand burns normally.
			var sequence: int=engine._log.size()
			engine._queue_card_reward(side,source,id,1,metadata)
			if not engine._error.is_empty(): return
			_journal.append(engine._log[sequence].duplicate(true))

func activate_received_spellcraft(engine,side: int,source: Dictionary,leaf: Dictionary,damage_sequence: int) -> void:
	var issue: String=DamageFollowupSources.unit_error(source)
	if issue.is_empty(): issue=DamageFollowupSources.effect_error(leaf)
	if issue.is_empty() and (leaf.get("type")!=DamageFollowupSources.SPELLCRAFT or side not in [0,1] or engine._kill_reward_host==null or not engine._kill_reward_host._damage_followup_host.resource_permit(source,leaf,damage_sequence)): issue="damage_spellcraft_requires_private_actual_damage_permit"
	var context: Dictionary=_context.get(DamageFollowupSources.SPELLCRAFT_POOL,{})
	if issue.is_empty() and (context.get("error")!="" or context.get("policy")!=RandomSpellcraft.Sources.POLICY or not context.get("ids") is Array or context.ids.is_empty()): issue="damage_spellcraft_missing_finite_closed_context"
	if not issue.is_empty(): engine._fail(issue);return
	var ids: Array=context.ids
	var templates: Dictionary=engine._options.get("hand_card_templates",{})
	var seen: Dictionary={}
	for id in ids:
		if seen.has(id) or not RandomSpellcraft.Sources.CANDIDATES.has(id): engine._fail("damage_spellcraft_unknown_or_duplicate_candidate");return
		seen[id]=true
		var card: Dictionary=RandomSpellcraft.Sources.CANDIDATES[id]
		var template: Dictionary=templates.get(id,{})
		if card.get("kind")!="spell" or card.get("category")!="塑造法术" or template.get("card_id")!=id or template.get("kind")!="spell" or not Sources.same(template.get("effects"),card.get("effects")): engine._fail("damage_spellcraft_changed_runtime_child");return
	var ghost: bool=side==1 and _context.ghost
	for pick in range(int(leaf.count)):
		var id: String=str(ids[engine._random_index(ids.size(),"damage_spellcraft_finite_uniform",ids)])
		if not engine._error.is_empty(): return
		var metadata: Dictionary={"resource_family":FAMILY,"resource_policy":POLICY,"source_id":source.card_id,"resource_pick":pick,"resource_pool_count":0,"resource_pool_kind":"spell","resource_ghost":ghost,"resource_special_policy":RandomSpellcraft.Sources.POLICY,"resource_special_pool":ids.duplicate(),"resource_spellcraft_expiry":true,"damage_sequence":damage_sequence}
		var sequence: int=engine._log.size()
		engine._queue_card_reward(side,source,id,1,metadata)
		if not engine._error.is_empty(): return
		_journal.append(engine._log[sequence].duplicate(true))

func temporary_choices(side: int, leaf: Dictionary) -> Dictionary:
	if _context.is_empty(): return {"ok":false,"error":"temporary_summon_missing_effective_pool_context"}
	var stock: Dictionary = _ghost_stock if side==1 and _context.ghost else _stock
	var choices: Array=candidates(_context,stock,leaf)
	for choice in choices: choice.golden_id=_context.cards[choice.id].get("golden_id","")
	return {"ok":true,"choices":choices}

# Only the genuine KillRewards removed-death proof batch calls this bridge.
# The attack receipt is linked at _attack's real exchange, not reconstructed
# from a lethal damage amount or a later public event.
func activate_attack_kills(engine,proofs: Array) -> bool:
	for proof in proofs:
		if not Nat.accepts_id(proof.source_id) or proof.kind!="attack" or not proof.get("source_active",false): continue
		var source: Dictionary=proof.source
		var side: int=int(proof.side)
		var issue: String=Nat.unit_error(source)
		if not issue.is_empty(): engine._fail(issue);return false
		if source.get("card_id")!=proof.source_id or source.get("uid")!=proof.source_uid or source.get("_combat_id")!=proof.source_combat_id: engine._fail("nat_attack_kill_source_changed");return false
		if not is_same(engine._find_unit(side,int(proof.source_combat_id)),source) or int(source.get("health",0))<=0 or source.get("_pending_destroy",false): engine._fail("nat_attack_kill_dead_killer_timing_partial");return false
		if source.get("silenced",false) or source.get("abilities_disabled",false): continue
		var attack_sequence: int=int(proof.get("attack_sequence",-1))
		var lethal_sequence: int=int(proof.sequence)
		var death_sequence: int=int(proof.death_sequence)
		if attack_sequence<0 or attack_sequence>=lethal_sequence or lethal_sequence>=death_sequence or death_sequence>=engine._log.size(): engine._fail("nat_attack_kill_missing_actual_attack");return false
		var attack: Dictionary=engine._log[attack_sequence]
		var lethal: Dictionary=engine._log[lethal_sequence]
		var death: Dictionary=engine._log[death_sequence]
		if attack.get("event")!="attack" or attack.get("side")!=side or attack.get("attacker")!=source.uid or attack.get("target")!=proof.target_uid or lethal.get("event")!="damage" or lethal.get("kind")!="attack" or lethal.get("source")!=source.uid or lethal.get("target")!=proof.target_uid or death.get("event")!="death" or death.get("unit")!=proof.target_uid or death.get("killer_id")!=source._combat_id: engine._fail("nat_attack_kill_actual_trace_changed");return false
		if _context.is_empty(): engine._fail("nat_attack_kill_missing_effective_pool_context");return false
		var leaf: Dictionary=Nat.PROGRAMS[source.card_id][0]
		var ghost: bool=side==1 and _context.ghost
		var stock: Dictionary=_ghost_stock if ghost else _stock
		for pick in range(int(leaf.count)):
			var choices: Array=candidates(_context,stock,leaf)
			var total: int=_total(choices)
			if total<=0:
				engine._emit("random_resource_empty",{"family":FAMILY,"side":side,"source":source.uid,"source_id":source.card_id,"pick":pick});continue
			var ticket: int=engine._rng.randi_range(0,total-1)
			var id: String=_selected(choices,ticket)
			engine._emit("rng",{"purpose":"nat_actual_attack_kill_stock_weighted","candidates":choices,"ticket":ticket,"choice":id,"total":total})
			var reserved: int=1 if engine._hand_counts[side]<10 else 0
			stock[id]-=reserved
			var metadata: Dictionary={"resource_family":FAMILY,"resource_policy":POLICY,"source_id":source.card_id,"resource_pick":pick,"resource_pool_count":reserved,"resource_pool_kind":"minion","resource_ghost":ghost,"attack_kill_family":"nat-actual-attack-kill-v1","attack_sequence":attack_sequence,"lethal_sequence":lethal_sequence,"death_sequence":death_sequence,"killed_uid":proof.target_uid}
			var sequence: int=engine._log.size()
			engine._queue_card_reward(side,source,id,1,metadata)
			if not engine._error.is_empty(): return false
			_journal.append(engine._log[sequence].duplicate(true))
	return true
