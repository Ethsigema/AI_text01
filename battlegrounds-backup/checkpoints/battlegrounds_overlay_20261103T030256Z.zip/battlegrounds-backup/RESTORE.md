# Godot 酒馆战棋恢复与备份

这是工程备份分支，不是发布版。旧主分支及安装包不修改。每个 snapshots/<UTC时间>/ 目录是一个独立可恢复版本。

## 组成

1. 原始完整交接包：
   https://github.com/Ethsigema/AI_text01/releases/download/battlegrounds-handoff-20261101/battlegrounds_new_scope_handoff_20261101.zip
2. 原包 SHA256：`33b3a1a12185cf9035cec33da4fff7008c7680194eb045b37234fbb934803d65`
3. 某次快照的 `manifest.json`：恢复后完整工程逐文件大小与 SHA256。
4. 同一快照 `payload/`：相比原始交接包新增或变化的全部文件。未变素材/数据/运行证据直接从原包恢复，不重复存放。
5. `tools/snapshot.py`：仅使用 Python 标准库的构建与恢复工具。

**不能只下载 payload 当成完整游戏。必须保留原包和对应快照。** 恢复仅使用快照清单所列文件，因此原包中已被该版本移除的文件不会复活。排除 Godot 导入缓存、Git 元数据与 Python 缓存；不排除游戏运行所需 research 证明文件、源脚本文本和素材。

## 恢复

下载并保留原始 ZIP、下载本备份分支或某个固定提交，选择一个具体快照。将下面路径替换为实际位置：

```sh
python3 battlegrounds-backup/tools/snapshot.py restore \
  --base-zip /path/battlegrounds_new_scope_handoff_20261101.zip \
  --snapshot battlegrounds-backup/snapshots/YYYYMMDDTHHMMSSZ \
  --destination /path/new-empty-game-folder
```

目标目录必须尚不存在；工具不覆盖已有工程。工具会校验原包 SHA256、拒绝路径穿越/符号链接，并核对恢复后全部文件的大小与 SHA256。成功输出 `verified_files` 才表示该快照的文件恢复校验通过；这不等于游戏功能测试通过。

在 Godot 4.6.3 中导入恢复目录的 `游戏工程/project.godot`。具体实现和测试状态以该快照的 PROGRESS、进度台账及原始测试日志为准。2026-11-02 的历史 153/433 记录不能移植成重建代码的验收结论。

## 后续快照

停止对工程的写入后运行 build，成功后可立即恢复开发。构建工具会比较前后完整源清单；若源文件变化则报错，该不完整快照不得提交。

```sh
python3 battlegrounds-backup/tools/snapshot.py build \
  --root /path/酒馆战棋_新范围半成品交接包_20261101 \
  --base-zip /path/battlegrounds_new_scope_handoff_20261101.zip \
  --output battlegrounds-backup/snapshots/YYYYMMDDTHHMMSSZ \
  --created-utc YYYY-MM-DDTHH:MM:SSZ
```

提交前对新增 payload 做敏感信息检查，再在新的独立目录执行 restore。推送仅使用快进提交，不强推；保留历史快照。推送后以远端提交号和重新读取的 manifest/payload 哈希核验备份，而不是只检查本地文件。
