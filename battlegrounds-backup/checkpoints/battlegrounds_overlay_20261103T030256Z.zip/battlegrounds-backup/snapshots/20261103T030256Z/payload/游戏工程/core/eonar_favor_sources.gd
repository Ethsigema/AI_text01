extends RefCounted
const Exact=preload("res://core/board_aura_effects.gd")
const ID: String="BG35_912"
const TYPE: String="spell_eonar_selected_type_shop_bonus"
const CARD: Dictionary={"id":"BG35_912","dbf_id":"130312","name":"艾欧娜尔的眷顾","kind":"spell","category":"酒馆法术","categories":["酒馆法术"],"mechanisms":[],"tier":4,"cost":2,"attack":null,"health":null,"tribes":[],"keywords":[],"is_golden":false,"text":"选择一个随从。在本局对战中，使酒馆中该类型的随从获得+3/+3。","effects":[{"type":"spell_eonar_selected_type_shop_bonus","source_id":"BG35_912","attack":3,"health":3,"allow_shop":true}],"supported":true,"pool_supported":true,"default_pool":true,"solo_eligible":true,"fields":{"status":"常规池"},"implementation_status":"written_unverified","conditional_support":{"reason":"Single selected native type only; dual/ALL/type-less and unclosed cast composition held."},"native_source_build":255790}
static func claimed(card: Dictionary) -> bool: return str(card.get("card_id",card.get("id","")))==ID or card.get("effects",[]).any(func(e):return e is Dictionary and e.get("type")==TYPE)
static func source_error(card: Dictionary) -> String:
	for key in CARD:
		if not Exact.same(card.get(key),CARD[key]): return "eonar_changed_source_"+str(key)
	return ""
static func unit_error(unit: Dictionary) -> String:
	if not claimed(unit): return ""
	if unit.has("id") and not unit.has("card_id"): return source_error(unit)
	if unit.get("card_id")!=ID or not unit.get("uid") is String or unit.uid.is_empty(): return "eonar_invalid_source_identity"
	for key in ["name","kind","tier","cost","text","effects","keywords","tribes"]:
		if not Exact.same(unit.get(key),CARD[key]): return "eonar_changed_native_body_"+key
	if unit.get("golden",false) or unit.get("temporary",false) or unit.get("is_spellcraft",false): return "eonar_unknown_source_variant"
	return ""
static func closure_error(catalog) -> String:
	for c in [catalog,catalog.source_catalog if catalog.source_catalog!=null else catalog]:
		var issue: String=source_error(c.get_card(ID))
		if not issue.is_empty(): return issue
	return ""
# Import accepts only the full supplemental row, the full canonical constant,
# or their exact merged form. Unknown metadata and eligibility conflicts fail.
# The pinned native evidence is mandatory for every accepted form.
const IMPORT_ROW: Dictionary={"attack":null,"health":null,"tier":4,"cost":2,"id":"BG35_912","card_code":"BG35_912","dbf_id":"130312","name":"艾欧娜尔的眷顾","name_en":"Eonar's Favor","kind":"spell","category":"法术","categories":["法术"],"source_groups":["supplemental"],"source_sheets":[],"mechanisms":[],"text":"选择一个随从。在本局对战中，使酒馆中该类型的随从获得+{0}/+{1}。","text_template":"选择一个随从。在本局对战中，使酒馆中该类型的随从获得+{0}/+{1}。","tribes":[],"keywords":[],"effects":[],"supported":false,"is_golden":false,"variant":"普通","normal_id":null,"golden_id":null,"image":"res://assets/cards/BG35_912_official_latest.png","image_source_url":"https://d15f34w2p8l1cc.cloudfront.net/hearthstone/fc61daf55d49c492cfed7d113f4e3cc85b866c08ba3195924554904f9b3e8f0a.png","source_url":"https://raw.githubusercontent.com/HearthSim/hsdata/27fbd2323aec20cab1c6ecc7d5f55cf12729f956/CardDefs.Bacon.xml","source":"https://raw.githubusercontent.com/HearthSim/hsdata/27fbd2323aec20cab1c6ecc7d5f55cf12729f956/CardDefs.Bacon.xml","source_urls":["https://raw.githubusercontent.com/HearthSim/hsdata/27fbd2323aec20cab1c6ecc7d5f55cf12729f956/CardDefs.Bacon.xml","https://hearthstone.blizzard.com/en-us/api/cards?pageSize=450&ids=985%2C2026%2C40641%2C41138%2C49169%2C49973%2C58372%2C58387%2C70163%2C70164%2C92405%2C92435%2C95790%2C95794%2C101574%2C101582%2C102255%2C102256%2C102965%2C102968%2C105846%2C105847%2C108739%2C108743%2C109884%2C109885%2C113126%2C113127%2C115691%2C115692%2C115693%2C115694%2C115949%2C116476%2C116477%2C120223%2C120224%2C120634%2C120635%2C120636%2C120637%2C121640%2C121642%2C122223%2C122224%2C122741%2C122742%2C126966%2C126967%2C127480%2C127481%2C127482%2C127483%2C129745%2C129746%2C130312%2C130882%2C130883%2C130884%2C130885%2C131153%2C133369&gameMode=battlegrounds&locale=zh_CN"],"quality_flags":["effect_not_implemented","dynamic_or_state_dependent_text"],"latest_validation":{"status":"verified_current_client_and_official_api","patch":"36.6.3.253932","build":253932,"data_gate":false,"implementation_gate":true,"xml_tag_omission_not_assumed_zero":true},"source_conflicts":[],"raw_fields":{"current_client":{"id":"BG35_912","dbf_id":"130312","tags":{"CARDNAME":{"enUS":"Eonar's Favor","zhCN":"艾欧娜尔的眷顾"},"CARDTEXT":{"enUS":"Choose a minion. Give minions of its type in the Tavern +{0}/+{1} this game.","zhCN":"选择一个随从。在本局对战中，使酒馆中该类型的随从获得+{0}/+{1}。"},"TAG_SCRIPT_DATA_NUM_1":"3","TAG_SCRIPT_DATA_NUM_2":"3","COST":"2","CARD_SET":"1453","CLASS":"12","FACTION":"3","CARDTYPE":"42","TECH_LEVEL":"4","SPELL_SCHOOL":"9","1":"1","IS_BACON_POOL_SPELL":"1"},"tag_ids":{"185":{"enUS":"Eonar's Favor","zhCN":"艾欧娜尔的眷顾"},"184":{"enUS":"Choose a minion. Give minions of its type in the Tavern +{0}/+{1} this game.","zhCN":"选择一个随从。在本局对战中，使酒馆中该类型的随从获得+{0}/+{1}。"},"2":"3","3":"3","48":"2","183":"1453","199":"12","201":"3","202":"42","1440":"4","1635":"9","1724":"1","3081":"1","3566":"1","4254":"1","4811":"1"},"source_file":"CardDefs.Bacon.xml"},"official_api":{"id":130312,"collectible":0,"slug":"130312-eonars-favor","classId":12,"multiClassIds":[],"spellSchoolId":9,"cardTypeId":42,"cardSetId":1453,"rarityId":null,"artistName":null,"manaCost":2,"name":"艾欧娜尔的眷顾","text":"选择一个随从。在本局对战中，使酒馆中该类型的随从获得+ /+ 。","image":"","imageGold":"","flavorText":"","cropImage":"https://d15f34w2p8l1cc.cloudfront.net/hearthstone/1467cba5012fd9375d6cfc1d50086510942310d17dadadc8bd226eac718ad838.png","isZilliaxFunctionalModule":false,"isZilliaxCosmeticModule":false,"battlegrounds":{"tier":4,"hero":false,"quest":false,"reward":false,"duosOnly":false,"solosOnly":false,"subsetTribes":[],"image":"https://d15f34w2p8l1cc.cloudfront.net/hearthstone/fc61daf55d49c492cfed7d113f4e3cc85b866c08ba3195924554904f9b3e8f0a.png","imageGold":""}}},"fields":{"status":"历史池身份；当前投放未推断","notes":"客户端动态参数模板保留；官网API将占位符留白，故不采用其不完整文字。"},"provenance":{"historical_id":"BG35_912","historical_dbf_id":"130312","current_revision":"27fbd2323aec20cab1c6ecc7d5f55cf12729f956"},"dynamic_script_parameters":{"TAG_SCRIPT_DATA_NUM_1":"3","TAG_SCRIPT_DATA_NUM_2":"3"},"solo_eligible":true,"mode_evidence":{"latest_client":{"card_code":"BG35_912","dbf_id":"130312","duos_exclusive":false,"tag_3166":null,"source_url":"https://raw.githubusercontent.com/HearthSim/hsdata/27fbd2323aec20cab1c6ecc7d5f55cf12729f956/CardDefs.Bacon.xml"},"workbook_applicable_modes":null,"effect_requires_team_mechanism":false,"basis":"Current exclusivity flag and explicit source mode/effect text. No duo-to-solo rewrite."},"image_provenance":{"source_url":"https://d15f34w2p8l1cc.cloudfront.net/hearthstone/fc61daf55d49c492cfed7d113f4e3cc85b866c08ba3195924554904f9b3e8f0a.png","sha256":"fc61daf55d49c492cfed7d113f4e3cc85b866c08ba3195924554904f9b3e8f0a","size":[404,558],"wording_currency":"official_endpoint_latest_render_not_independent_text_verification"},"duos_exclusive":false,"requires_teammate_effect":false,"pool_requirement_tribes":[],"tribe_evidence":{"primary_client_CARDRACE":null,"secondary_client_race_flags":{},"api_multiTypeIds":[],"note":"Pool subset tags are selection restrictions, not the minion race."}}
const NATIVE_PROOF: String="res://research/current_eonar_spell_20261029/native255790.json"
const NATIVE_PROOF_SHA: String="5c09974aa4e631107c86376930a8dde56274d303c11077e94125cec356dbee88"
static func import_error(card: Dictionary) -> String:
	if not FileAccess.file_exists(NATIVE_PROOF) or FileAccess.get_sha256(NATIVE_PROOF)!=NATIVE_PROOF_SHA: return "BG35_912_native_import_proof_changed"
	if Exact.same(card,IMPORT_ROW) or Exact.same(card,CARD): return ""
	var expected: Dictionary=IMPORT_ROW.duplicate(true)
	expected.merge(CARD,true)
	return "" if Exact.same(card,expected) else "BG35_912_native_import_complete_row_changed"

static func apply_overlay(cards: Dictionary) -> String:
	if not cards.has(ID): return "BG35_912_native_import_missing"
	if not cards[ID] is Dictionary: return "BG35_912_native_import_invalid_row"
	var issue: String=import_error(cards[ID])
	if not issue.is_empty(): return issue
	var merged: Dictionary=cards[ID].duplicate(true)
	merged.merge(CARD,true)
	cards[ID]=merged
	return ""
