extends RefCounted
## Selection eligibility is source metadata, never executable-program coverage.
## null is unknown. In particular the imported empty keywords/effects arrays
## are not evidence that a printed ability is absent.
static func integer(value: Variant) -> bool:
	return (value is int or value is float) and not value is bool and is_finite(float(value)) and value==floor(value) and value>=0 and value<=2147483647

static func printed_trait(card: Dictionary, printed: Dictionary, name: String) -> Variant:
	if card.get("kind")!="minion": return false
	# An explicit positive compiled keyword is useful evidence, but an empty
	# program or keyword array says nothing about an unimplemented card.
	if name=="magnetic" and card.get("keywords") is Array and "magnetic" in card.keywords: return true
	var labels: Dictionary={"battlecry":"战吼","deathrattle":"亡语","choose_one":"抉择","magnetic":"磁力","rally":"进击"}
	if not labels.has(name): return null
	if printed.get("id")!=card.get("id") or not printed.get("text") is String: return null
	if not printed.get("source_conflicts",[]) is Array or not printed.get("source_conflicts",[]).is_empty(): return null
	var text: String=str(printed.text).replace("<b>","").replace("</b>","").strip_edges()
	var fields: Variant=printed.get("fields",{})
	if not fields is Dictionary: return null
	if fields.has("text") and fields.text!=printed.text: return null
	var label: String=labels[name]
	if name=="deathrattle": label="(?:战吼和)?亡语"
	# Only an actual declaration, not a reference such as 'trigger a Battlecry'.
	var declaration: RegEx=RegEx.new()
	var ending: String="(?:和亡语)?[：:]" if name=="battlecry" else "[：:]"
	if name=="magnetic": ending="(?=$|[。；;，,\\n])"
	declaration.compile("(?:^|[。；;，,\\n])\\s*"+label+ending)
	if declaration.search(text)!=null: return true
	# Absence in a complete source text is independent of compilation support.
	# Mentions without an unambiguous declaration remain conditional.
	if not str(labels[name]) in text: return false
	return null

static func tavern(card: Dictionary) -> Variant:
	if card.get("category") in ["酒馆","酒馆法术"]: return true
	if card.get("categories") is Array:
		if "酒馆" in card.categories or "酒馆法术" in card.categories: return true
		return false
	if card.get("category") is String: return false
	return null

static func matches(card: Dictionary, leaf: Dictionary) -> Dictionary:
	var unknown: Array=[]
	var excluded: bool=false
	if not str(card.get("eligibility_issue","")).is_empty(): unknown.append(card.eligibility_issue)
	for name in ["cost","minimum_cost","tier","minimum_tier","maximum_tier"]:
		if leaf.get(name,-1)<0: continue
		var field: String="cost" if name=="minimum_cost" else "tier" if name in ["minimum_tier","maximum_tier"] else name
		var value: Variant=card.get(field)
		if not integer(value): unknown.append(field);continue
		if name in ["minimum_cost","minimum_tier"]: excluded=excluded or value<leaf[name]
		elif name=="maximum_tier": excluded=excluded or value>leaf[name]
		else: excluded=excluded or value!=leaf[name]
	var tribe: String=str(leaf.get("tribe",""))
	if not tribe.is_empty() or leaf.has("tribes_any"):
		var tribes: Variant=card.get("tribes")
		if not tribes is Array or tribes.any(func(value):return not value is String): unknown.append("tribes")
		else:
			if not tribe.is_empty(): excluded=excluded or (tribe not in tribes and "全部" not in tribes and "all" not in tribes)
			if leaf.has("tribes_any"):
				var shares: bool=false
				for requested in leaf.tribes_any:
					if requested in ["全部","all"] and not tribes.is_empty() or requested in tribes or "全部" in tribes or "all" in tribes: shares=true
				excluded=excluded or not shares
	var trait_name: String=str(leaf.get("effect_filter",""))
	if not trait_name.is_empty():
		if trait_name not in ["battlecry","deathrattle","magnetic","choose_one","rally"]: unknown.append("effect_filter:"+trait_name)
		elif not card.get(trait_name) is bool: unknown.append(trait_name)
		else: excluded=excluded or not card[trait_name]
	# A proved mismatch makes this member irrelevant even if another field is
	# unknown. Otherwise the whole request must hold, not prune this member.
	if excluded: return {"matches":false,"unknown":[]}
	return {"matches":unknown.is_empty(),"unknown":unknown}
