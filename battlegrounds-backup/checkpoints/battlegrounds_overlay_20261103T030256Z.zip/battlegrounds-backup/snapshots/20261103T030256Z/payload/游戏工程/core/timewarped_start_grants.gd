extends RefCounted
const PackagedEvidence = preload("res://core/packaged_source_evidence.gd")
const ClocksworthCopies=preload("res://core/clocksworth_sources.gd")
## Exact two Timewarped spells. All composition holds below are simulator
## coverage boundaries, not claims about official stacking or event order.
const Exact = preload("res://core/end_turn_repeats.gd")
const PoolIdentity = preload("res://core/pool_identity.gd")
const PermanentTribe = preload("res://core/permanent_tribe_effects.gd")
const Amplifier = preload("res://core/tavern_spell_amplifiers.gd")
const TYPE: String = "spell_start_turn_fixed_grant"
const SOURCE_IDS: Array = ["BG34_Treasure_608","BG34_Treasure_609"]
const DEPENDENCY_IDS: Array = ["BG28_168","BG28_512"]
const CHILDREN: Dictionary = {"BG34_Treasure_608":"BG28_168","BG34_Treasure_609":"BG28_512"}
const FOLDER: String = "res://research/timewarped_start_grants_sources/"
const STATE_KEY: String = "timewarped_start_grants_state"
const SNAPSHOT_KEY: String = "timewarped_start_grants_snapshot"
const VERSION: int = 1
const MAX_ROUND: int = 2147483647
const MAX_UID: int = 9007199254740991
const PHASES: Array = ["recruit","end_turn","combat","spectate","finished","error"]
const PROGRAMS: Dictionary = {"BG34_Treasure_608":[{"type":"spell_start_turn_fixed_grant","source_id":"BG34_Treasure_608","card_id":"BG28_168","count":1}],"BG34_Treasure_609":[{"type":"spell_start_turn_fixed_grant","source_id":"BG34_Treasure_609","card_id":"BG28_512","count":1}]}
const FILE_SHA256: Dictionary = {"SOURCE_REPORT.md":"dc89f0711af3935eef5350d7b77a61c2d4437b33fe2ed76949f8574f9349bf25","compiled/BG28_168.json":"f634650e9b3f12f0cd4392f600b7aece93d5c456539980336fbd8427c4de8172","compiled/BG28_512.json":"ee9c26dc7e07cdb045d656a7314dc037feb914f60e2bfd8627f13290939b5cea","expected_compiled.json":"1e4b4f1ecef32be002b67c135e8d596bf1f9a7b7445ee91e0c0cbeb9041fc1cd","native/BG28_168.xml":"14f64da5a1213d46b49cf45140d957005d9eb5e2dfa6626ba01230fb5b6f67d3","native/BG28_512.xml":"b008fd5d0bde58f0b73fcb2afd1878107da3432b867afaef24582ec59fc1819a","native/BG34_Treasure_608.xml":"77adc25d50a2618a1705aef41316e0d1dae4e0a9793d965a280bb97b592ff9a4","native/BG34_Treasure_608pe.xml":"75f2519120a48059aa7783e41ac5510199075661896333574e9f1b9c9d4575d3","native/BG34_Treasure_609.xml":"4106406f0bdc0b62f4a7c2c0b35955ec9b3be09ffe5494c1599bbe25127b0071","native/BG34_Treasure_609pe.xml":"d96229d038fb87957128ff1e7344edcc9a65bf0776d5db23e14c35f4b8d8b218","raw49/BG28_168.json":"8759faa5f7640181a85cb141fb28e2037b54f4cc811063dc49a899fcf644e22c","raw49/BG28_512.json":"919fda9c6f56925d67ed1375480360c2999c565fdda72a5655cf2749eb88a563","raw49/BG34_Treasure_608.json":"a1e83392c2a430c38d2063275b889ab11a08b4ae97c42e447ab408cb72697dd3","raw49/BG34_Treasure_609.json":"ac1eb883a4f08028739b4677012a248e1962cccb50f2be8de03f826a831eb168","source_contract.json":"2187a3e4f96156044ecf4e143fb249df0ae04a7a0ebab65342892e0d42e0c5fe","upstream_manifest.json":"e119d7907cb2571fdbf6a41ee391a1879475edfae2d4256719e90e3ae028e1c4","upstream_source_contract.json":"6f2b5d280320db30f00f0ee6814f4c836926d662065c75562165832363ea11a0"}

static func accepts_id(identity: Variant) -> bool:
	return identity is String and identity in SOURCE_IDS

static func _marker(value: Variant, depth: int = 0) -> bool:
	if depth > 16: return true
	if value is Dictionary:
		if Exact._same(value.get("type"),TYPE): return true
		for key in ["id","card_id","card_code","source_id"]:
			if accepts_id(value.get(key)): return true
		for child in value.values():
			if (child is Dictionary or child is Array) and _marker(child,depth+1): return true
	elif value is Array:
		for child in value:
			if _marker(child,depth+1): return true
	return false

static func claimed(source: Variant) -> bool:
	return source is Dictionary and _marker(source)

static func validate_effect(effect: Variant) -> String:
	if not effect is Dictionary: return "timewarped_start_invalid_effect"
	if not _marker(effect): return ""
	var identity: Variant = effect.get("source_id")
	return "" if accepts_id(identity) and Exact._same(effect,PROGRAMS[identity][0]) else "timewarped_start_complete_program_changed"

static func validation_evidence() -> Dictionary:
	var proof: Dictionary = PackagedEvidence.inspect(FOLDER,FILE_SHA256)
	if not str(proof.error).is_empty(): return {"error":"timewarped_start_evidence_changed:"+str(proof.changed_path)}
	var contract: Variant = JSON.parse_string(FileAccess.get_file_as_string(FOLDER+"source_contract.json"))
	var expected: Variant = JSON.parse_string(FileAccess.get_file_as_string(FOLDER+"expected_compiled.json"))
	if not contract is Dictionary or not Exact._same(contract.get("source_ids"),SOURCE_IDS) or not Exact._same(contract.get("dependency_ids"),DEPENDENCY_IDS) or not Exact._same(contract.get("programs"),PROGRAMS): return {"error":"timewarped_start_source_closure_changed"}
	if not contract.get("records") is Dictionary or contract.records.size() != 4 or not expected is Dictionary or expected.size() != 2: return {"error":"timewarped_start_incomplete_evidence"}
	for identity in SOURCE_IDS+DEPENDENCY_IDS:
		var record: Variant = contract.records.get(identity)
		var raw: Variant = JSON.parse_string(FileAccess.get_file_as_string(FOLDER+"raw49/"+identity+".json"))
		if not record is Dictionary or not record.get("expected_overlay") is Dictionary or not raw is Dictionary or raw.size() != 49 or not Exact._same(raw,record.get("raw49")): return {"error":"timewarped_start_complete_raw_changed"}
		var overlay: Variant = expected.get(identity) if identity in SOURCE_IDS else JSON.parse_string(FileAccess.get_file_as_string(FOLDER+"compiled/"+identity+".json"))
		if not Exact._same(overlay,record.expected_overlay): return {"error":"timewarped_start_overlay_changed"}
	return {"error":"","records":contract.records,"expected":expected,"missing_annotations":proof.missing_annotations,"annotation_status":proof.annotation_status}

static func raw_source_error(card: Variant, evidence: Dictionary = {}) -> String:
	if evidence.is_empty(): evidence=validation_evidence()
	if not str(evidence.get("error","timewarped_start_missing_evidence")).is_empty(): return str(evidence.error)
	if not card is Dictionary or not accepts_id(card.get("id")): return "timewarped_start_unknown_raw"
	return "" if Exact._same(card,evidence.records[card.id].raw49) else "timewarped_start_complete_raw_changed"

static func _canonical_error(card: Variant, evidence: Dictionary) -> String:
	if not card is Dictionary or not card.get("id") is String or not evidence.records.has(card.id) or card.has("card_id"): return "timewarped_start_unbound_source"
	var expected: Dictionary = evidence.records[card.id].raw49.duplicate(true)
	expected.merge(evidence.records[card.id].expected_overlay,true)
	if card.has("pool_blocker"): expected.pool_blocker=PoolIdentity.SPELL_REASON
	return "" if Exact._same(card,expected) else "timewarped_start_complete_source_changed:"+card.id

static func source_error(card: Variant, evidence: Dictionary = {}) -> String:
	if not card is Dictionary: return "timewarped_start_invalid_source"
	if not claimed(card): return ""
	if not accepts_id(card.get("id")): return "timewarped_start_unbound_source"
	if evidence.is_empty(): evidence=validation_evidence()
	if not str(evidence.get("error","timewarped_start_missing_evidence")).is_empty(): return str(evidence.error)
	return _canonical_error(card,evidence)

static func room_source_error(card: Variant, evidence: Dictionary = {}) -> String:
	if not card is Dictionary: return "timewarped_start_invalid_effective_source"
	if evidence.is_empty(): evidence=validation_evidence()
	if not str(evidence.get("error","timewarped_start_missing_evidence")).is_empty(): return str(evidence.error)
	if not card.get("id") is String or not evidence.records.has(card.id): return "timewarped_start_unbound_effective_source"
	if not card.has("custom_shop_override") and not card.has("source_shop_fields"): return _canonical_error(card,evidence)
	var override: Variant=card.get("custom_shop_override")
	if not override is Dictionary or not Exact._keys(override,["tier","cost","copies"]): return "timewarped_start_invalid_custom_shop"
	if not Exact._integer(override.tier,1,6) or not Exact._integer(override.cost,0,99) or not Exact._integer(override.copies,1,99): return "timewarped_start_invalid_custom_shop"
	var raw: Dictionary=evidence.records[card.id].raw49
	var overlay: Dictionary=evidence.records[card.id].expected_overlay
	if not Exact._same(card.get("source_shop_fields"),{"tier":raw.tier,"cost":raw.cost,"pool_supported":overlay.pool_supported}): return "timewarped_start_custom_source_changed"
	if not Exact._same(card.get("tier"),override.tier) or not Exact._same(card.get("cost"),override.cost) or not Exact._same(card.get("pool_supported"),true): return "timewarped_start_custom_projection_changed"
	var original: Dictionary=card.duplicate(true)
	original.tier=raw.tier; original.cost=raw.cost; original.pool_supported=overlay.pool_supported
	original.erase("custom_shop_override"); original.erase("source_shop_fields")
	return _canonical_error(original,evidence)

static func catalog_error(catalog, evidence: Dictionary = {}, require_templates: bool = true) -> String:
	if catalog == null: return "timewarped_start_missing_catalog"
	if evidence.is_empty(): evidence=validation_evidence()
	if not str(evidence.get("error","timewarped_start_missing_evidence")).is_empty(): return str(evidence.error)
	var canonical=catalog.get("source_catalog")
	if canonical == null: canonical=catalog
	for identity in SOURCE_IDS+DEPENDENCY_IDS:
		var issue: String=_canonical_error(canonical.get_card(identity),evidence)
		if issue.is_empty(): issue=room_source_error(catalog.get_card(identity),evidence)
		if not issue.is_empty(): return issue
		if not require_templates: continue
		for current in [canonical,catalog]:
			var raw: Dictionary=evidence.records[identity].raw49
			var overlay: Dictionary=evidence.records[identity].expected_overlay
			var template: Dictionary={"card_id":identity,"kind":"spell","name":raw.name,"effects":overlay.effects}
			if not Exact._same(current.hand_card_templates.get(identity),template) or not Exact._same(current.hand_card_kinds.get(identity),"spell"): return "timewarped_start_generation_template_changed:"+identity
	return ""

static func closure_error(catalog, identity: Variant = "", evidence: Dictionary = {}) -> String:
	if identity != "" and not accepts_id(identity): return "timewarped_start_unknown_parent"
	return catalog_error(catalog,evidence)

static func live_error(source: Variant, catalog, evidence: Dictionary = {}) -> String:
	if not source is Dictionary: return "timewarped_start_invalid_live_source"
	if not claimed(source): return ""
	if not accepts_id(source.get("card_id")): return "timewarped_start_marker_on_wrong_source"
	if evidence.is_empty(): evidence=validation_evidence()
	var issue: String=catalog_error(catalog,evidence)
	if not issue.is_empty(): return issue
	if not Exact._uid(source.get("uid")): return "timewarped_start_invalid_source_uid"
	var identity: String=source.card_id
	var raw: Dictionary=evidence.records[identity].raw49
	var effective: Dictionary=catalog.get_card(identity)
	var expected: Dictionary={"card_id":identity,"name":raw.name,"kind":"spell","tier":effective.tier,"cost":effective.cost,"attack":0,"health":1,"max_health":1,"keywords":[],"tribes":[],"golden":false,"temporary":false,"is_spellcraft":false,"text":raw.text,"image":raw.image,"attachments":[],"pool_components":[],"temporary_buffs":[],"permanent_keywords":[],"magnetic_tribes":[],"effects":PROGRAMS[identity]}
	for key in expected:
		if not Exact._same(source.get(key),expected[key]): return "timewarped_start_live_body_changed:"+key
	var allowed: Array=expected.keys()+["uid","id","card_code","excluded","stats_conflict","duos_exclusive","requires_teammate_effect","individually_frozen","quality_flags","source_conflicts","spellcraft_kept","spell_triggers","blood_gems_received_turn","recruit_shop_aura_attack","recruit_shop_aura_health","recruit_shop_bonus_applied","pool_count","pool_id","pool_kind","base_unit","_base"]
	for key in source:
		if key not in allowed: return "timewarped_start_unknown_live_field:"+str(key)
	for key in ["id","card_code"]:
		if source.has(key) and not Exact._same(source[key],identity): return "timewarped_start_live_identity_changed"
	for key in ["excluded","stats_conflict","duos_exclusive","requires_teammate_effect","individually_frozen"]:
		if not Exact._same(source.get(key,false),false): return "timewarped_start_live_gate_changed"
	for key in ["quality_flags","source_conflicts"]:
		if not Exact._same(source.get(key,[]),[]): return "timewarped_start_live_flags_changed"
	for key in ["spellcraft_kept","spell_triggers","blood_gems_received_turn","recruit_shop_aura_attack","recruit_shop_aura_health"]:
		if not Exact._same(source.get(key,0),0): return "timewarped_start_live_unrelated_state_changed"
	if not Exact._same(source.get("recruit_shop_bonus_applied",{}),{}): return "timewarped_start_live_shop_bonus_changed"
	if not Exact._integer(source.get("pool_count",0),0,1): return "timewarped_start_invalid_pool_count"
	if source.has("pool_id") and source.pool_id not in ["",identity]: return "timewarped_start_pool_identity_changed"
	if source.has("pool_kind") and not Exact._same(source.pool_kind,"spell"): return "timewarped_start_pool_kind_changed"
	var base: Dictionary={"card_id":identity,"name":raw.name,"tier":effective.tier,"attack":0,"health":1,"max_health":1,"keywords":[],"tribes":[],"effects":PROGRAMS[identity],"golden":false}
	if not Exact._same(source.get("base_unit"),base) or source.has("_base") and not Exact._same(source._base,base): return "timewarped_start_base_changed"
	return ""

static func _bad(issue: String) -> Dictionary:
	return {"ok":false,"error":issue}

static func _empty(owner: int) -> Dictionary:
	return {"schema_version":VERSION,"owner":owner,"entry":{}}

static func _entries(value: Dictionary) -> Array:
	if value.has("entries"): return value.entries
	return [] if value.get("entry",{}).is_empty() else [value.entry]

static func _store(player: Dictionary,entries: Array) -> void:
	player[STATE_KEY]={"schema_version":2,"owner":int(player.id),"entries":entries}

static func _state_error(value: Variant, owner: int, current_round: int, historical: bool, allow_previous: bool = false) -> String:
	if not value is Dictionary: return "timewarped_start_invalid_state_shape"
	var legacy: bool=value.get("schema_version")==1
	if not Exact._keys(value,["schema_version","owner","entry"] if legacy else ["schema_version","owner","entries"]): return "timewarped_start_invalid_state_shape"
	if not Exact._integer(value.schema_version,1,2) or not Exact._integer(value.owner,0,MAX_ROUND) or value.owner!=owner: return "timewarped_start_invalid_state_owner_version"
	if legacy and not value.entry is Dictionary or not legacy and not value.entries is Array: return "timewarped_start_invalid_state_entries"
	var seen: Dictionary={};var previous_round: int=0
	for e in _entries(value):
		if not e is Dictionary or not Exact._keys(e,["source_id","source_uid","cast_round","last_granted_round"]): return "timewarped_start_invalid_entry_shape"
		if not accepts_id(e.source_id) or not Exact._uid(e.source_uid) or seen.has(e.source_uid): return "timewarped_start_invalid_entry_source"
		if not Exact._integer(e.cast_round,1,current_round) or not Exact._integer(e.last_granted_round,int(e.cast_round),current_round) or e.cast_round<previous_round: return "timewarped_start_invalid_round_receipt"
		if not historical and e.last_granted_round != current_round and not (allow_previous and e.last_granted_round == current_round-1): return "timewarped_start_missing_round_receipt"
		seen[e.source_uid]=true;previous_round=e.cast_round
	return ""

static func persistent_error(player: Variant, current_round: Variant, phase: Variant) -> String:
	if not player is Dictionary or not Exact._integer(player.get("id"),0,MAX_ROUND) or not player.get("alive") is bool: return "timewarped_start_invalid_owner"
	if not Exact._integer(current_round,1,MAX_ROUND) or not phase is String or phase not in PHASES: return "timewarped_start_invalid_round_phase"
	for key in player:
		if str(key).begins_with("timewarped_start") and key != STATE_KEY: return "timewarped_start_unknown_owner_state"
	return _state_error(player[STATE_KEY],int(player.id),int(current_round),not player.alive) if player.has(STATE_KEY) else ""

static func _owner_error(engine, player: Dictionary) -> String:
	if not engine.state.get("players") is Array or not Exact._integer(player.get("id"),0,engine.state.players.size()-1) or not is_same(engine.state.players[int(player.id)],player): return "timewarped_start_requires_actual_owner"
	return ""

static func _observable(value: Variant, depth: int = 0) -> bool:
	if depth > 16: return true
	if value is Dictionary:
		var type: String=str(value.get("type",""))
		# Unproved initial cast/hand-added listeners are rejected before consume;
		# recurring acquisition does not silently pick an order among categories.
		if "start_turn" in type or "hand_added" in type or "spellcraft" in type or "spell_cast" in type or "on_spell" in type or "play_listener" in type or "on_play_card" in type or "target_spell" in type or type in ["on_play_parity_buff","hero_native_prizes","anomaly_native_prizes","hero_periodic_tavern_spell_bonus"]: return true
		if value.get("event","") in ["start_turn","hand_added","play_card","spell_cast","play_minion","turn_income"]: return true
		for child in value.values():
			if (child is Array or child is Dictionary) and _observable(child,depth+1): return true
	elif value is Array:
		for child in value:
			if _observable(child,depth+1): return true
	return false

static func _context_error(engine, player: Dictionary) -> String:
	if not player.get("hand") is Array or player.hand.size() > 10 or not player.get("board") is Array: return "timewarped_start_invalid_owner_zones"
	for key in ["spellcraft_waiting","mechanism_reward_queue","discover","discover_queue","native_prize_deferred_choices"]:
		if not player.get(key,[]) is Array or not player.get(key,[]).is_empty(): return "timewarped_start_unsupported_waiting_acquisition:"+key
	if player.has("native_prize_state") or player.has("native_buddy") or engine.room.get("native_prizes",false): return "timewarped_start_unsupported_scheduled_acquisition"
	var permanent_issue: String=PermanentTribe.ledger_error(player.get(PermanentTribe.LEDGER_KEY,{}))
	if not permanent_issue.is_empty(): return permanent_issue
	var triples: Dictionary={}
	for unit in player.hand+player.board:
		if not unit is Dictionary: return "timewarped_start_invalid_live_zone"
		if unit.get("kind") != "minion" or unit.get("golden",false): continue
		var identity: String=str(unit.get("card_id",""))
		triples[identity]=int(triples.get(identity,0))+1
		if triples[identity] >= ClocksworthCopies.copies_required(player,{}): return "timewarped_start_unsupported_pending_triple_acquisition"
	var quest: Variant=player.get("active_quest",{})
	if not quest is Dictionary or not quest.is_empty(): return "timewarped_start_unsupported_quest_composition"
	# Entire owned programs, not room presence, determine acquisition overlap.
	# These native economy domains only change income/base/carry: they neither
	# observe the spell/hand addition nor allocate cards or consume hand space.
	# Their existing EOT and owner-income dispatch stays exactly where it is.
	for ids in [engine._enabled("anomalies"),player.get("trinkets",[]),player.get("reward_active",[])]:
		if not ids is Array: return "timewarped_start_invalid_mechanism_sources"
		for identity in ids:
			if not identity is String: return "timewarped_start_invalid_mechanism_identity"
			var card: Dictionary=engine.catalog.get_card(identity)
			if card.get("id")!=identity or card.get("supported")!=true or card.get("excluded",false) or not card.get("effects") is Array or card.effects.is_empty(): return "timewarped_start_invalid_mechanism_program:"+identity
			var mechanism_issue: String=engine.catalog._validate_effects(card.effects.duplicate(true),0,card)
			if not mechanism_issue.is_empty(): return mechanism_issue
			for effect in card.effects:
				if effect.get("type") not in ["mechanism_start_gold","mechanism_carry_gold","mechanism_end_turn_max_gold"]: return "timewarped_start_actual_mechanism_acquisition_intersection_partial:"+identity+":"+str(effect.get("type",""))
	var hero: Dictionary=engine.catalog.get_card(str(player.get("hero_id","")))
	if _observable(hero.get("effects",[])): return "timewarped_start_unsupported_hero_callback"
	var totals: Dictionary=Amplifier.totals(player)
	if not totals.ok: return str(totals.error)
	if totals.attack != 0 or totals.health != 0: return "timewarped_start_unsupported_spell_amplifier"
	for unit in player.board:
		if not unit is Dictionary or not unit.get("effects") is Array: return "timewarped_start_invalid_board_source"
		var issue: String=engine.catalog._validate_effects(unit.effects)
		if not issue.is_empty(): return issue
		if _observable(unit.effects): return "timewarped_start_unsupported_start_or_hand_listener_composition"
		# Native hand/listener implementations carry identity-based callbacks.
		for identity in ["BG25_045","BG25_045_G","BG34_Giant_327","BG34_Giant_327_G"]:
			if unit.get("card_id") == identity: return "timewarped_start_unsupported_native_hand_listener"
	return ""

static func _uid_occurrences(value: Variant, uid: String, depth: int = 0) -> int:
	if depth > 24: return 2
	var found: int=0
	if value is Dictionary:
		if Exact._same(value.get("uid"),uid): found += 1
		for child in value.values():
			if child is Array or child is Dictionary: found += _uid_occurrences(child,uid,depth+1)
	elif value is Array:
		for child in value:
			if child is Array or child is Dictionary: found += _uid_occurrences(child,uid,depth+1)
	return found

static func _cast_error(engine, player: Dictionary, source: Dictionary, require_hand: bool) -> String:
	var issue: String=live_error(source,engine.catalog)
	if issue.is_empty(): issue=_owner_error(engine,player)
	if issue.is_empty(): issue=persistent_error(player,engine.state.get("round"),engine.state.get("phase"))
	if not issue.is_empty(): return issue
	if not accepts_id(source.get("card_id")) or engine.state.phase != "recruit" or not player.alive: return "timewarped_start_requires_living_recruit_manual_cast"
	if not Exact._integer(engine.next_uid,1,MAX_UID-1) or int(source.uid.substr(1)) >= engine.next_uid: return "timewarped_start_invalid_or_exhausted_uid"
	if not player.get("hand") is Array or player.hand.any(func(unit):return is_same(unit,source)) != require_hand: return "timewarped_start_requires_actual_hand_consumption"
	if _uid_occurrences(engine.state.players+engine.state.get("ghosts",[]),source.uid) != (1 if require_hand else 0): return "timewarped_start_duplicate_or_unconsumed_source"
	if player.has(STATE_KEY) and _entries(player[STATE_KEY]).any(func(entry):return entry.source_uid==source.uid): return "timewarped_start_reused_subscription_source"
	issue=_allocation_error(engine,1)
	return issue if not issue.is_empty() else _context_error(engine,player)

static func play_error(engine, player: Dictionary, source: Dictionary) -> String:
	return _cast_error(engine,player,source,true) if claimed(source) else ""

static func begin_cast_context(engine, player: Dictionary, source: Dictionary) -> Dictionary:
	if not claimed(source): return {"ok":true,"error":""}
	var issue: String=_cast_error(engine,player,source,true)
	if not issue.is_empty(): return _bad(issue)
	if not engine._timewarped_start_context.is_empty(): return _bad("timewarped_start_nested_cast_context")
	engine._timewarped_start_context={"owner":player,"source":source,"before":source.duplicate(true),"round":int(engine.state.round),"next_uid":engine.next_uid}
	return {"ok":true,"error":""}

static func _deliver(engine, player: Dictionary, entry: Dictionary, stage: String) -> Dictionary:
	var unit: Dictionary=engine._unit(engine.catalog.get_card(CHILDREN[entry.source_id]))
	if unit.is_empty(): return _bad("timewarped_start_child_factory_failed")
	unit.pool_count=0
	engine._add_hand(player,unit)
	if engine.state.phase != "recruit": return _bad("timewarped_start_listener_failed_no_retry")
	var accepted: bool=player.hand.any(func(item):return is_same(item,unit))
	engine._log("timewarped_start_grant_attempt",{"player":player.id,"round":engine.state.round,"source_id":entry.source_id,"source_uid":entry.source_uid,"uid":unit.uid,"card_id":unit.card_id,"outcome":"added" if accepted else "burned","pool_count":unit.pool_count,"stage":stage})
	return {"ok":true,"error":"","granted":true,"accepted":accepted}

static func record_cast(engine, player: Dictionary, source: Dictionary, effect: Dictionary) -> Dictionary:
	var issue: String=validate_effect(effect)
	if issue.is_empty() and (not accepts_id(source.get("card_id")) or not Exact._same(effect,PROGRAMS[source.card_id][0])): issue="timewarped_start_wrong_record_program"
	if issue.is_empty(): issue=_cast_error(engine,player,source,false)
	if not issue.is_empty(): return _bad(issue)
	var context: Variant=engine._timewarped_start_context
	if not context is Dictionary or not is_same(context.get("owner"),player) or not is_same(context.get("source"),source) or not Exact._same(context.get("before"),source) or context.get("round") != engine.state.round or context.get("next_uid") != engine.next_uid: return _bad("timewarped_start_requires_one_use_actual_cast_context")
	engine._timewarped_start_context={}
	var r: int=int(engine.state.round)
	var entries: Array=_entries(player.get(STATE_KEY,_empty(int(player.id)))).duplicate(true)
	var entry: Dictionary={"source_id":source.card_id,"source_uid":source.uid,"cast_round":r,"last_granted_round":r}
	entries.append(entry);_store(player,entries)
	return _deliver(engine,player,entry,"immediate")

## All alive subscriptions and all composition checks precede any round writes.
static func preflight_start(engine) -> Dictionary:
	if not _family_present(engine.state,engine.events): return {"ok":true,"error":""}
	if engine.state.get("phase") not in ["recruit","end_turn","combat","spectate"]: return _bad("timewarped_start_invalid_start_phase")
	var issue: String=saved_error(engine.state,engine.catalog,engine.next_uid,engine.events)
	if not issue.is_empty(): return _bad(issue)
	if not Exact._integer(engine.state.get("round"),1,MAX_ROUND-1): return _bad("timewarped_start_round_exhausted")
	var count: int=0
	for player in engine.state.players:
		if not player.alive or not player.has(STATE_KEY) or _entries(player[STATE_KEY]).is_empty(): continue
		issue=_context_error(engine,player)
		if not issue.is_empty(): return _bad(issue)
		count += _entries(player[STATE_KEY]).size()
	if count > 0:
		issue=_allocation_error(engine,count)
		if not issue.is_empty(): return _bad(issue)
	return {"ok":true,"error":""}

static func start_turn(engine, player: Dictionary) -> Dictionary:
	var issue: String=_owner_error(engine,player)
	if not issue.is_empty(): return _bad(issue)
	if engine.state.get("phase") != "recruit" or not Exact._integer(engine.state.get("round"),1,MAX_ROUND): return _bad("timewarped_start_invalid_owner_start")
	if not player.get("alive") is bool: return _bad("timewarped_start_invalid_alive")
	if not player.has(STATE_KEY): return {"ok":true,"error":"","granted":false}
	issue=_state_error(player[STATE_KEY],int(player.id),int(engine.state.round),not player.alive,true)
	if not issue.is_empty(): return _bad(issue)
	if not player.alive or _entries(player[STATE_KEY]).is_empty(): return {"ok":true,"error":"","granted":false}
	issue=_attempts_error(engine.state,engine.events,engine.next_uid)
	if not issue.is_empty(): return _bad(issue)
	var due: Array=_entries(player[STATE_KEY]).filter(func(entry):return entry.last_granted_round!=engine.state.round).duplicate(true)
	if due.is_empty(): return {"ok":true,"error":"","granted":false}
	issue=catalog_error(engine.catalog)
	if issue.is_empty(): issue=_context_error(engine,player)
	if not issue.is_empty(): return _bad(issue)
	for entry in due:
		if not Exact._integer(engine.next_uid,1,MAX_UID-1) or int(entry.source_uid.substr(1))>=engine.next_uid or _uid_occurrences(engine.state.players+engine.state.get("ghosts",[]),entry.source_uid)!=0: return _bad("timewarped_start_invalid_or_live_receipt_uid")
	issue=_allocation_error(engine,due.size())
	if not issue.is_empty(): return _bad(issue)
	# Original cast insertion order is the explicit local FIFO for this category.
	# Freeze due sources, then each actual delivery/burn consumes only its clock.
	for original in due:
		var entries: Array=_entries(player[STATE_KEY]).duplicate(true)
		var matches: Array=entries.filter(func(entry):return entry.source_uid==original.source_uid)
		if matches.size()!=1 or not Exact._same(matches[0],original): return _bad("timewarped_start_changed_group_clock")
		var entry: Dictionary=matches[0];entry.last_granted_round=int(engine.state.round)
		_store(player,entries)
		var delivered: Dictionary=_deliver(engine,player,entry,"start_turn")
		if not delivered.ok: return delivered
	return {"ok":true,"error":"","granted":true,"attempts":due.size()}

static func capture_ghost(player: Dictionary, current_round: Variant, phase: Variant, engine = null) -> Dictionary:
	if engine == null: return _bad("timewarped_start_capture_requires_actual_engine")
	var issue: String=_owner_error(engine,player)
	if issue.is_empty() and (not Exact._same(current_round,engine.state.get("round")) or not Exact._same(phase,engine.state.get("phase"))): issue="timewarped_start_capture_context_mismatch"
	if issue.is_empty(): issue=saved_error(engine.state,engine.catalog,engine.next_uid,engine.events)
	if issue.is_empty(): issue=persistent_error(player,current_round,phase)
	if not issue.is_empty(): return _bad(issue)
	if phase not in ["recruit","end_turn","combat"]: return _bad("timewarped_start_invalid_capture_phase")
	return {"ok":true,"error":"","snapshot":{"schema_version":VERSION,"owner":int(player.id),"captured_round":int(current_round),"captured_phase":phase,"snapshot_rule":"frozen-elimination-1","owner_state":player.get(STATE_KEY,_empty(int(player.id))).duplicate(true)}}

static func ghost_error(snapshot: Variant, current_round: Variant) -> String:
	if not Exact._integer(current_round,1,MAX_ROUND) or not snapshot is Dictionary or not Exact._keys(snapshot,["schema_version","owner","captured_round","captured_phase","snapshot_rule","owner_state"]): return "timewarped_start_invalid_ghost_shape"
	if not Exact._integer(snapshot.schema_version,VERSION,VERSION) or not Exact._integer(snapshot.owner,0,MAX_ROUND) or not Exact._integer(snapshot.captured_round,1,int(current_round)) or snapshot.captured_phase not in ["recruit","end_turn","combat"] or snapshot.snapshot_rule != "frozen-elimination-1": return "timewarped_start_invalid_ghost_anchor"
	return _state_error(snapshot.owner_state,int(snapshot.owner),int(snapshot.captured_round),false)

static func saved_error(state: Variant, catalog, next_uid: Variant = null, events: Variant = []) -> String:
	if not _family_present(state,events): return ""
	if not state is Dictionary or not state.get("players") is Array or not state.get("ghosts",[]) is Array: return "timewarped_start_invalid_saved_state"
	var evidence: Dictionary={}
	var receipts: Dictionary={}
	var owners: Dictionary={}
	for player in state.players:
		var issue: String=persistent_error(player,state.get("round"),state.get("phase"))
		if not issue.is_empty(): return issue
		if owners.has(player.id): return "timewarped_start_duplicate_owner"
		owners[player.id]=player
		if not player.has(STATE_KEY) or _entries(player[STATE_KEY]).is_empty(): continue
		if evidence.is_empty(): evidence=validation_evidence()
		issue=catalog_error(catalog,evidence)
		if not issue.is_empty(): return issue
		for entry in _entries(player[STATE_KEY]):
			var uid: String=entry.source_uid
			if next_uid != null and (not Exact._integer(next_uid,1,MAX_UID) or int(uid.substr(1)) >= next_uid): return "timewarped_start_cast_uid_in_future"
			if receipts.has(uid): return "timewarped_start_reused_cast_uid"
			receipts[uid]=player.id
	for ghost in state.get("ghosts",[]):
		if not ghost is Dictionary or ghost.has(STATE_KEY): return "timewarped_start_live_ledger_on_ghost"
		for key in ghost:
			if str(key).begins_with("timewarped_start") and key != SNAPSHOT_KEY: return "timewarped_start_unknown_ghost_state"
		if not ghost.has(SNAPSHOT_KEY):
			if owners.has(ghost.get("id")) and owners[ghost.id].has(STATE_KEY) and not _entries(owners[ghost.id][STATE_KEY]).is_empty(): return "timewarped_start_missing_ghost_snapshot"
			continue
		var snapshot: Dictionary=ghost[SNAPSHOT_KEY] if ghost[SNAPSHOT_KEY] is Dictionary else {}
		var issue: String=ghost_error(snapshot,state.get("round"))
		if not issue.is_empty(): return issue
		if not Exact._same(snapshot.owner,ghost.get("id")) or not owners.has(snapshot.owner) or owners[snapshot.owner].alive: return "timewarped_start_ghost_owner_mismatch"
		if not Exact._same(snapshot.owner_state,owners[snapshot.owner].get(STATE_KEY,_empty(int(snapshot.owner)))): return "timewarped_start_ghost_history_mismatch"
	for uid in receipts:
		if _uid_occurrences(state.players+state.get("ghosts",[]),uid) != 0: return "timewarped_start_consumed_source_still_live"
	for player in state.players+state.get("ghosts",[]):
		for zone in ["hand","board","shop","mechanism_reward_queue"]:
			if not player.get(zone,[]) is Array: return "timewarped_start_invalid_saved_zone"
			for unit in player.get(zone,[]):
				if not claimed(unit): continue
				if zone == "board": return "timewarped_start_spell_cannot_be_board_proxy"
				if evidence.is_empty(): evidence=validation_evidence()
				var issue: String=live_error(unit,catalog,evidence)
				if not issue.is_empty(): return issue
	return _attempts_error(state,events,next_uid)

## Retained host events independently bind consumed identity, owner, and each
## attempt. A valid-family substitution cannot turn a Ring receipt into Lasso.
static func _attempts_error(state: Dictionary, events: Variant, next_uid: Variant) -> String:
	if not events is Array: return "timewarped_start_missing_attempt_history"
	var entries: Dictionary={}
	var rounds: Dictionary={}
	var generated: Dictionary={}
	var previous_generated: int=0
	for player in state.players:
		if not player.has(STATE_KEY) or _entries(player[STATE_KEY]).is_empty(): continue
		for entry in _entries(player[STATE_KEY]):
			if entries.has(entry.source_uid): return "timewarped_start_reused_cast_uid"
			entries[entry.source_uid]={"owner":player.id,"entry":entry}
			rounds[entry.source_uid]={}
	for event in events:
		if not event is Dictionary or not Exact._same(event.get("type"),"timewarped_start_grant_attempt"): continue
		if not Exact._keys(event,["type","player","round","source_id","source_uid","uid","card_id","outcome","pool_count","stage"]): return "timewarped_start_invalid_attempt_shape"
		if not event.get("source_uid") is String or not entries.has(event.source_uid): return "timewarped_start_orphan_attempt"
		var bound: Dictionary=entries[event.source_uid]
		var entry: Dictionary=bound.entry
		if not Exact._same(event.player,bound.owner) or not Exact._same(event.source_id,entry.source_id) or not Exact._same(event.card_id,CHILDREN[entry.source_id]): return "timewarped_start_attempt_source_owner_changed"
		if not Exact._integer(event.round,int(entry.cast_round),int(entry.last_granted_round)) or rounds[event.source_uid].has(int(event.round)): return "timewarped_start_duplicate_or_future_attempt"
		if not Exact._same(event.stage,("immediate" if event.round == entry.cast_round else "start_turn")) or not event.outcome is String or event.outcome not in ["added","burned"] or not Exact._same(event.pool_count,0): return "timewarped_start_attempt_semantics_changed"
		if not Exact._uid(event.uid) or generated.has(event.uid) or entries.has(event.uid) or event.uid == event.source_uid: return "timewarped_start_invalid_generated_uid"
		if next_uid != null and (not Exact._integer(next_uid,1,MAX_UID) or int(event.uid.substr(1)) >= next_uid): return "timewarped_start_generated_uid_in_future"
		var ordinal: int=int(event.uid.substr(1))
		if ordinal <= int(event.source_uid.substr(1)) or ordinal <= previous_generated: return "timewarped_start_generated_uid_not_fresh"
		previous_generated=ordinal
		generated[event.uid]=true
		rounds[event.source_uid][int(event.round)]=true
	for uid in entries:
		var entry: Dictionary=entries[uid].entry
		if rounds[uid].size() != int(entry.last_granted_round)-int(entry.cast_round)+1: return "timewarped_start_missing_attempt_history"
	return ""

static func _allocation_error(engine, count: int) -> String:
	if not Exact._integer(engine.next_uid,1,MAX_UID-count): return "timewarped_start_uid_exhausted"
	for offset in range(count):
		var uid: String="u"+str(engine.next_uid+offset)
		if _uid_occurrences(engine.state.players+engine.state.get("ghosts",[]),uid) != 0: return "timewarped_start_next_uid_collision"
		for event in engine.events:
			if event is Dictionary and Exact._same(event.get("type"),"timewarped_start_grant_attempt") and Exact._same(event.get("uid"),uid): return "timewarped_start_generated_uid_reuse"
	return ""

## Preserve unrelated host contexts, including an ordinary pre-round-zero
## transition. No new family means no new phase/schema/round requirements.
static func _family_present(state: Variant, events: Variant = []) -> bool:
	if state is Dictionary:
		for collection in [state.get("players",[]),state.get("ghosts",[])]:
			if not collection is Array: continue
			for owner in collection:
				if not owner is Dictionary: continue
				for key in owner:
					if str(key).begins_with("timewarped_start"): return true
				for zone in ["hand","board","shop","mechanism_reward_queue"]:
					if not owner.get(zone,[]) is Array: continue
					for unit in owner.get(zone,[]):
						if claimed(unit): return true
	if events is Array:
		for event in events:
			if event is Dictionary and Exact._same(event.get("type"),"timewarped_start_grant_attempt"): return true
	return false
