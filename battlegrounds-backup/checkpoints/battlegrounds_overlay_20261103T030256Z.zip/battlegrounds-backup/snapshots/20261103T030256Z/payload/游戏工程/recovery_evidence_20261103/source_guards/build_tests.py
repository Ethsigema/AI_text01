"""Build isolated, production-method-extracted source-proof tests. No Game/Catalog."""
from pathlib import Path
import argparse, hashlib, json, re, shutil
parser=argparse.ArgumentParser(); parser.add_argument('--output',default='/tmp/source-guards-recovery/test_project');args=parser.parse_args()
root=Path(__file__).resolve().parents[2];out=Path(args.output).resolve();out.mkdir(parents=True,exist_ok=True)
names=['deft_deserter_sources','forsaken_weaver_sources','timewarped_anubarak_sources','timewarped_start_grants','timed_dragon_buff']
def method(name,fn):
 s=(root/'core'/f'{name}.gd').read_text();m=re.search(r'^static func '+re.escape(fn)+r'\(',s,re.M);assert m,fn
 tail=s[m.start():];end=re.search(r'\n(?:static func |func |const |var )',tail)
 return (tail[:end.start()] if end else tail).rstrip()+'\n'
def write(path,txt):
 p=out/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(txt)
write('project.godot','config_version=5\n[application]\nconfig/name="Isolated source evidence recovery tests"\n')
shutil.copy2(root/'core/packaged_source_evidence.gd',out/'packaged_source_evidence.gd')
write('exact.gd','extends RefCounted\n'+method('end_turn_repeats','_same'))
audit=[];cases=[]
for name in names:
 s=(root/'core'/f'{name}.gd').read_text(); lines=[line for line in s.splitlines() if line.startswith('const ') and 'preload(' not in line]
 body='extends RefCounted\nconst PackagedEvidence=preload("res://packaged_source_evidence.gd")\nconst Exact=preload("res://exact.gd")\n'+'\n'.join(lines)+'\n'+method(name,'validation_evidence')
 if name=='deft_deserter_sources':body+=method(name,'proof_error')
 write(name+'.gd',body)
 folder=re.search(r'const FOLDER:\s*String\s*=\s*"res://([^"]+)"',s);folder=folder[1] if folder else ''
 mapname=next(n for n in ['PROOF_SHA256','EVIDENCE_SHA256','FILE_SHA256'] if re.search(r'const '+n+r':',s))
 hashes=json.loads(re.search(r'const '+mapname+r':\s*Dictionary\s*=\s*(\{[^\n]+\})',s)[1]); paths={folder+k:v for k,v in hashes.items()}
 if 'RAW49_SHA256' in s:
  rows=json.loads(re.search(r'const RAW49_SHA256:\s*Dictionary\s*=\s*(\{[^\n]+\})',s)[1]);paths.update({folder+'raw49/'+k+'.json':v for k,v in rows.items()})
  for const,filename in [('CONTRACT_SHA256','source_contract.json'),('EXPECTED_SHA256','expected_compiled.json')]:
   paths[folder+filename]=re.search(r'const '+const+r':\s*String\s*=\s*"([^"]+)"',s)[1]
 missing=[];retained=[]
 for rel,want in paths.items():
  p=root/rel;actual=hashlib.sha256(p.read_bytes()).hexdigest() if p.exists() else None
  audit.append({'family':name,'path':rel,'expected_sha256':want,'actual_sha256':actual,'status':'missing_annotation' if actual is None else 'verified' if actual==want else 'changed'})
  if actual is None:
   assert rel.endswith('.md'),rel;missing.append('res://'+rel)
  else:
   assert actual==want,rel;dest=out/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dest);retained.append('res://'+rel)
 assert len(missing)==1
 cases.append({'script':name,'missing':missing,'retained':retained})
(root/'recovery_evidence_20261103/source_guards/native_file_audit.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2)+'\n')
write('cases.json',json.dumps(cases,ensure_ascii=False,indent=2)+'\n')
shutil.copy2(Path(__file__).parent/'test.gd',out/'test.gd')
print(json.dumps({'test_project':str(out),'families':len(cases),'retained_proof_files':len([a for a in audit if a['status']=='verified']),'missing_annotations':len([a for a in audit if a['status']=='missing_annotation'])}))
