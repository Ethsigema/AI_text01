extends SceneTree
## Bounded native factory/combat checks only, not complete card identity acceptance.
## Runtime loads keep --check-only lightweight while another Game smoke is running.
const IDS: Array[String] = ["BGS_119", "BGS_034", "BGS_131", "BG26_OG_248", "BG_EX1_506a", "BG_FP1_014t"]
const OUTPUT: String = "res://recovery_evidence_20261103/keyword_acceptance.json"
var report: Dictionary = {
	"scope": "bounded unchanged native Catalog -> Game._unit -> Combat.resolve keyword checks",
	"status": "not_run", "checks": [], "cases": [],
	"not_covered": ["full card identity acceptance", "normal shop acquisition for Bronze Warden/Spore", "golden variants", "buff inheritance", "hero or other effect interactions", "multi-hit survival proving second damage after venomous is spent"]
}
var failures: int = 0
var catalog: RefCounted
var game: RefCounted
var combat_script: GDScript

func record(value: bool, label: String, detail: Variant = null) -> bool:
	report.checks.append({"label": label, "passed": value, "detail": detail})
	if not value:
		failures += 1
	return value

func persist() -> void:
	var file: FileAccess = FileAccess.open(OUTPUT, FileAccess.WRITE)
	if file != null:
		file.store_string(JSON.stringify(report, "  "))

func finish() -> void:
	report.status = "passed" if failures == 0 else "failed"
	report.failures = failures
	persist()
	print("RECOVERY_KEYWORD_ACCEPTANCE ", JSON.stringify(report))
	quit(0 if failures == 0 else 1)

func events(result: Dictionary, event_name: String, field: String = "", value: Variant = null) -> Array:
	var found: Array = []
	for entry in result.get("log", []):
		if entry.get("event", "") != event_name:
			continue
		if not field.is_empty() and entry.get(field) != value:
			continue
		found.append(entry)
	return found

func native_unit(identity: String) -> Dictionary:
	var source: Dictionary = catalog.get_card(identity)
	var unit: Dictionary = game._unit(source)
	if not record(not unit.is_empty(), "native factory " + identity):
		return {}
	record(unit.get("card_id") == identity, "factory preserves identity " + identity)
	for field in ["attack", "health", "tier", "keywords", "effects", "tribes"]:
		record(unit.get(field) == source.get(field), "factory preserves " + identity + "." + field)
	return unit

func resolve_case(label: String, left: Array, right: Array, seed_value: int) -> Dictionary:
	var before_left: Array = left.duplicate(true)
	var before_right: Array = right.duplicate(true)
	var result: Dictionary = combat_script.new().resolve(left, right, seed_value, {"max_iterations": 100, "left_tier": 1, "right_tier": 1})
	record(str(result.get("error", "missing error field")).is_empty(), label + ": native resolve succeeds", result.get("error"))
	record(events(result, "error").is_empty(), label + ": no error events")
	record(events(result, "combat_start").size() == 1 and events(result, "combat_end").size() == 1, label + ": complete actual combat trace")
	record(left == before_left and right == before_right, label + ": recruit input remains unchanged")
	report.cases.append({"label": label, "seed": seed_value, "left_input": before_left, "right_input": before_right, "result": result})
	persist()
	return result

func check_cyclone() -> void:
	var cyclone: Dictionary = native_unit("BGS_119")
	var scout: Dictionary = native_unit("BG_EX1_506a")
	var sturdy: Dictionary = native_unit("BG26_OG_248")
	if cyclone.is_empty() or scout.is_empty() or sturdy.is_empty():
		return
	var left: Array = [cyclone, scout]
	var right: Array = [sturdy]
	var result: Dictionary = resolve_case("cyclone_windfury_and_shield", left, right, 202611031)
	var declarations: Array = events(result, "attack_declared")
	var cyclone_attacks: Array = events(result, "attack_declared", "attacker", cyclone.uid)
	record(declarations.size() >= 2 and declarations[0].get("attacker") == cyclone.uid and declarations[1].get("attacker") == cyclone.uid, "Cyclone makes two consecutive actual attacks before opposing turn")
	record(cyclone_attacks.size() == 2 and cyclone_attacks[0].get("strike") == 1 and cyclone_attacks[1].get("strike") == 2, "normal Cyclone has exactly strikes 1 and 2, not mega-windfury")
	var shield_losses: Array = events(result, "shield_lost", "target", cyclone.uid)
	var taken: Array = events(result, "damage", "target", cyclone.uid)
	record(shield_losses.size() == 1 and shield_losses[0].get("blocked") == sturdy.attack, "Cyclone shield absorbs first positive retaliation")
	record(taken.size() == 1 and taken[0].get("health_before") == cyclone.health and taken[0].get("amount") == sturdy.attack and taken[0].get("health") == 0, "first shield hit did not reduce health; second retaliation kills Cyclone")
	if shield_losses.size() == 1 and taken.size() == 1:
		record(shield_losses[0].sequence < taken[0].sequence, "shield loss precedes actual health damage")
	var replay: Dictionary = resolve_case("cyclone_exact_seed_replay", left, right, 202611031)
	record(result == replay, "unchanged native inputs and identical seed reproduce complete combat result")

func check_warden() -> void:
	var warden: Dictionary = native_unit("BGS_034")
	var scout: Dictionary = native_unit("BG_EX1_506a")
	var thaddius: Dictionary = native_unit("BG_FP1_014t")
	if warden.is_empty() or scout.is_empty() or thaddius.is_empty():
		return
	var result: Dictionary = resolve_case("bronze_warden_reborn_and_new_shield", [warden, scout], [thaddius], 202611032)
	var reborns: Array = events(result, "summon", "kind", "reborn")
	record(reborns.size() == 1, "Bronze Warden emits exactly one real Reborn summon")
	if reborns.size() != 1:
		return
	var summoned: Dictionary = reborns[0].get("unit", {})
	record(reborns[0].get("source") == warden.uid and summoned.get("card_id") == "BGS_034", "Reborn source and newborn preserve actual Warden identity")
	record(not str(summoned.get("uid", "")).is_empty() and summoned.get("uid") != warden.uid, "Reborn creates a fresh combat entity")
	record(summoned.get("health") == 1 and summoned.get("attack") == warden.base_unit.attack, "Reborn has 1 health and native base attack")
	record("divine_shield" in summoned.get("keywords", []) and "reborn" not in summoned.get("keywords", []), "Reborn refreshes native shield but consumes Reborn")
	var original_deaths: Array = events(result, "death", "unit", warden.uid)
	var newborn_deaths: Array = events(result, "death", "unit", summoned.get("uid"))
	record(original_deaths.size() == 1 and original_deaths[0].sequence < reborns[0].sequence, "original Warden death occurs before actual summon")
	record(events(result, "shield_lost", "target", warden.uid).size() == 1 and events(result, "shield_lost", "target", summoned.get("uid")).size() == 1, "both original and newborn shields each absorb a real hit")
	record(newborn_deaths.size() == 1 and newborn_deaths[0].sequence > reborns[0].sequence, "newborn dies without a second Reborn")

func check_spore() -> void:
	var spore: Dictionary = native_unit("BGS_131")
	var scout: Dictionary = native_unit("BG_EX1_506a")
	var sturdy: Dictionary = native_unit("BG26_OG_248")
	if spore.is_empty() or scout.is_empty() or sturdy.is_empty():
		return
	var result: Dictionary = resolve_case("spore_venomous_on_positive_damage", [spore, scout], [sturdy], 202611033)
	var spent: Array = events(result, "venomous_used", "source", spore.uid)
	var dealt: Array = events(result, "damage", "source", spore.uid)
	record(spent.size() == 1 and spent[0].get("target") == sturdy.uid, "Spore consumes venomous exactly once on actual damage")
	record(dealt.size() == 1 and dealt[0].get("amount") == 1 and dealt[0].get("health_before") == 5 and dealt[0].get("health") == 0 and dealt[0].get("lethal_keyword") == true, "1 damage kills native 5-health target via venomous")
	record(events(result, "death", "unit", sturdy.uid).size() == 1, "venomous target actually dies")
	record(events(result, "damage", "source", sturdy.uid).size() == 1 and events(result, "death", "unit", spore.uid).size() == 1, "lethally hit target still retaliates in same damage batch")

func check_spore_shield() -> void:
	var spore: Dictionary = native_unit("BGS_131")
	var scout: Dictionary = native_unit("BG_EX1_506a")
	var cyclone: Dictionary = native_unit("BGS_119")
	if spore.is_empty() or scout.is_empty() or cyclone.is_empty():
		return
	var result: Dictionary = resolve_case("spore_blocked_by_native_divine_shield", [spore, scout], [cyclone], 202611034)
	var blocks: Array = events(result, "shield_lost", "source", spore.uid)
	record(blocks.size() == 1 and blocks[0].get("target") == cyclone.uid and blocks[0].get("blocked") == 1, "native shield blocks Spore's first attack")
	record(events(result, "damage", "source", spore.uid).is_empty(), "blocked Spore hit deals no actual damage")
	record(events(result, "venomous_used", "source", spore.uid).is_empty(), "shield block does not consume venomous")

func _initialize() -> void:
	report.status = "running"
	persist()
	var catalog_script: GDScript = load("res://core/catalog.gd")
	var room_script: GDScript = load("res://core/room_config.gd")
	var game_script: GDScript = load("res://core/game.gd")
	combat_script = load("res://core/combat.gd")
	catalog = catalog_script.new()
	catalog.load_catalog()
	report.catalog_errors = catalog.load_errors
	if not record(catalog.load_errors.is_empty(), "full native catalog loads cleanly"):
		finish()
		return
	for identity in IDS:
		var source: Dictionary = catalog.get_card(identity)
		if not record(not source.is_empty() and source.get("supported", false) and source.get("kind") == "minion" and source.get("effects") == [], "unchanged supported effect-free native source " + identity):
			finish()
			return
	var expected: Dictionary = {"BGS_119": ["divine_shield", "windfury"], "BGS_034": ["divine_shield", "reborn"], "BGS_131": ["venomous"]}
	for identity in expected:
		if not record(catalog.get_card(identity).get("keywords") == expected[identity], "exact compiled native keywords " + identity):
			finish()
			return
	var room: RefCounted = room_script.new()
	room.reset(catalog)
	room.data.bot_count = 1
	room.data.seed = 20261103
	room.data.enabled_minions = ["BGS_119"]
	room.data.enabled_spells = []
	room.data.enabled_heroes = ["TB_BaconShop_HERO_34"]
	room.data.selected_hero = "TB_BaconShop_HERO_34"
	for key in ["enabled_anomalies", "enabled_trinkets", "enabled_quests", "enabled_rewards"]:
		room.data[key] = []
	var room_errors: Array = room.validate(catalog)
	if not record(room_errors.is_empty(), "neutral native room is valid", room_errors):
		finish()
		return
	game = game_script.new()
	var started: Dictionary = game.start(room.data, catalog)
	if not record(started.get("ok", false), "real Game initializes native factory context", started):
		finish()
		return
	check_cyclone()
	check_warden()
	check_spore()
	check_spore_shield()
	finish()
