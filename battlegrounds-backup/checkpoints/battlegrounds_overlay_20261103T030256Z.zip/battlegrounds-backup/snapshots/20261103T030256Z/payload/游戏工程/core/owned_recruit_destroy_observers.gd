extends RefCounted
## One cumulative owner-slot prefix, never one callback per Deathrattle repeat.
const Blightborne=preload("res://core/blightborne_portrait_host.gd")
const Maw=preload("res://core/maw_caster_portrait_host.gd")
const Kelthuzad=preload("res://core/kelthuzad_portrait_host.gd")
static func active(player: Dictionary) -> bool:
	return not Blightborne.Sources.slots(player).is_empty() or not Maw.Sources.slots(player).is_empty() or not Kelthuzad.Sources.slots(player).is_empty()
static func project(engine,shadow: Dictionary,cursor: Dictionary={},victim: Dictionary={}) -> Dictionary:
	var result: Dictionary={"ok":true,"error":"","slots":shadow.get("trinkets",[]).duplicate(true),"records":[]}
	for slot in range(result.slots.size()):
		var id: String=str(result.slots[slot])
		var plan: Dictionary={}
		if id==Maw.Sources.ID: plan=Maw.project(engine,shadow,slot,cursor)
		elif id==Kelthuzad.Sources.ID: plan=Kelthuzad.project(engine,shadow,slot,cursor)
		elif id==Blightborne.Sources.ID: plan=Blightborne.project(engine,shadow,slot,cursor,victim)
		else: continue
		if not plan.ok: return plan
		result.records.append({"id":id,"plan":plan})
	if not cursor.is_empty(): result.cursor_after=cursor.duplicate(true)
	return result
static func commit(engine,player: Dictionary,ticket: Dictionary,receipt: Dictionary,plan: Dictionary) -> String:
	if not Maw.Sources.same(player.get("trinkets",[]),plan.get("slots")): return "owned_destroy_portrait_slots_changed"
	for record in plan.get("records",[]):
		var issue: String=Maw.commit(engine,player,ticket,receipt,record.plan) if record.id==Maw.Sources.ID else Kelthuzad.commit(engine,player,ticket,receipt,record.plan) if record.id==Kelthuzad.Sources.ID else Blightborne.commit(engine,player,ticket,receipt,record.plan)
		if not issue.is_empty(): return issue
	if plan.has("cursor_after"):
		var actual: Dictionary={"player":player,"totals":engine._attack_gain_health_totals,"next_uid":engine.next_uid,"rng_seed":engine.rng.seed,"rng_state":engine.rng.state,"pool":engine.pool,"spell_pool":engine.spell_pool}
		for key in actual:
			if not Maw.Sources.same(actual[key],plan.cursor_after[key]): return "owned_destroy_portrait_complete_cursor_mismatch:"+key
	return ""

# Rally self-destruction has a different issued capability and receipt reason.
# The existing portrait hosts only accept RecruitDeath destroy tickets. Keep
# this boundary explicit until those hosts implement a native removed adapter;
# never fabricate an old ticket or rewrite the real death receipt.
static func commit_removed(engine,player: Dictionary,authority: Dictionary,wave: Dictionary,record: Dictionary,plan: Dictionary) -> String:
	var issue: String=engine.OwnedRallyEOT.Damage.Removed._record_error(engine,player,authority,wave,record)
	if not issue.is_empty(): return issue
	if not record.has("self_destroy"): return "owned_rally_portrait_requires_actual_destruction"
	if not Maw.Sources.same(player.get("trinkets",[]),plan.get("slots")): return "owned_destroy_portrait_slots_changed"
	return "owned_rally_removed_portrait_commit_authority_partial"
