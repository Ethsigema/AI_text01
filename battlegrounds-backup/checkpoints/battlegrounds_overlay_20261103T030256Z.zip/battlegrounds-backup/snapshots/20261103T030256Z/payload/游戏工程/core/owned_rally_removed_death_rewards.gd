extends RefCounted
## Existing 214/809 removed records feed persistent death rewards. Natural
## damage deaths count for Ini, but only an earned exact self-destruction is
## a destruction for the three outside-combat portraits.
const Portraits=preload("res://core/owned_recruit_destroy_observers.gd")
const Heroes=preload("res://core/milestone_hero_host.gd")
const Resources=preload("res://core/death_resource_trinkets.gd")

static func admission(engine,p: Dictionary) -> String:
 var issue: String=Heroes.player_error(p,engine.catalog)
 if issue.is_empty():issue=Resources.owned_rally_error(engine,p)
 if not issue.is_empty():return issue
 for host in [Portraits.Maw,Portraits.Kelthuzad,Portraits.Blightborne]:
  if host.Sources.slots(p).is_empty():continue
  issue=host.Sources.closure_error(engine.catalog)
  if not issue.is_empty():return issue
 # Their existing commits require ordinary RecruitDeath tickets. Hold this
 # owned-Rally combination before any damage/removal, even for natural deaths,
 # until the distinct removed-wave portrait authority has an implementation.
 if Portraits.active(p):return "owned_rally_removed_portrait_commit_authority_partial"
 return ""

static func owned_reader(effect: Dictionary) -> bool:
 return Heroes.Sources.same([effect],Heroes.Sources.PROGRAMS[Heroes.Sources.INI]) or Resources.owned_rally_reader(effect)

static func destroy_error(engine,p: Dictionary,authority: Dictionary,wave: Dictionary,record: Dictionary) -> String:
 var issue: String=engine.OwnedRallyEOT.Damage.Removed._record_error(engine,p,authority,wave,record)
 if not issue.is_empty():return issue
 return "" if record.has("self_destroy") else "owned_rally_portrait_requires_actual_destruction"

static func execute(engine,p: Dictionary,authority: Dictionary,wave: Dictionary,record: Dictionary) -> String:
 var issue: String=engine.OwnedRallyEOT.Damage.Removed._record_error(engine,p,authority,wave,record)
 if not issue.is_empty():return issue
 if record.get("death_rewards_completed",false):return "owned_rally_removed_replayed_death_rewards"
 record.death_rewards_completed=true
 if record.has("self_destroy") and Portraits.active(p):
  # The complete original wave has already left the board and returned stock.
  # Reuse the original cumulative portrait projections, including gold readers,
  # accepted-hand callbacks, UID allocation and RNG, in original slot order.
  var cursor: Dictionary=Portraits.Blightborne.current(engine,p).duplicate(true)
  var plan: Dictionary=Portraits.project(engine,cursor.player,cursor,record.source)
  if not plan.ok:return str(plan.error)
  issue=Portraits.commit_removed(engine,p,authority,wave,record,plan)
  if not issue.is_empty():return issue
 issue=Heroes.after_owned_rally_death(engine,p,authority,wave,record)
 if not issue.is_empty():return issue
 # Keep the original RecruitDeath prefix order: Ini, then slot-ordered cyclic
 # death resources, before this removed body executes its native DR.
 return Resources.after_owned_rally_death(engine,p,authority,wave,record)
