extends RefCounted
const TurnDeath=preload("res://core/turn_recruit_death_sources.gd")
const Sources=preload("res://core/cyclic_resource_trinkets.gd")
const CONTEXT: String="owned_death_resource_contexts"
const SNAPSHOT: String="owned_death_resource_snapshot"
const PROGRESS: String="owned_death_resource_progress"
const FAMILY: String="actual-owned-slot-death-resource-v1"
var _contexts: Array=[{},{}]
var _states: Array=[{},{}]
var _consumed: Dictionary={}
var _events: Array=[]
var _sealed: Array=[]
var _seed: int=0
var _completed: bool=false
var _authenticated: bool=false
var _used: bool=false
var _owners: Array=[]
var _settlement: Array=[]
var _cursor: int=0
var _avenge_settlement: Dictionary={}
static func integer(value: Variant,low: int=0,high: int=2147483647) -> bool:
	return not value is bool and (value is int or value is float) and is_finite(float(value)) and value==floor(float(value)) and value>=low and value<=high
static func snapshot_progress(owner: Dictionary) -> Dictionary:
	var result: Dictionary={}
	for index in range(owner.get("trinkets",[]).size()):
		var id: String=str(owner.trinkets[index])
		if id not in Sources.DEATH_IDS: continue
		var key: String="trinket:%d:%s:0:interval" % [index,id]
		result[key]=0 if id in Sources.COMBAT_AVENGE_IDS else owner.get("mechanism_state",{}).get(key,0)
	return result
static func context_for(owner: Dictionary,catalog) -> Dictionary:
	if not owner.get("trinkets",[]) is Array or not owner.get("mechanism_state",{}) is Dictionary: return {"error":"death_resource_invalid_owner_shape"}
	var entries: Array=[]
	var ghost: bool=owner.has("snapshot_rule")
	var progress: Dictionary=snapshot_progress(owner)
	if ghost and owner.get("trinkets",[]).any(func(id):return id in Sources.DEATH_IDS):
		if not owner.get(SNAPSHOT) is Dictionary: return {"error":"death_resource_legacy_ghost_progress_unknown_partial"}
		progress=owner[SNAPSHOT]
	for index in range(owner.get("trinkets",[]).size()):
		var id: String=str(owner.trinkets[index])
		if id not in Sources.DEATH_IDS: continue
		var issue: String=Sources.source_error(catalog.get_card(id))
		if not issue.is_empty(): return {"error":issue}
		var slot: String="trinket:%d:%s:0" % [index,id]
		var value: Variant=0 if id in Sources.COMBAT_AVENGE_IDS else progress.get(slot+":interval",0)
		var threshold: int=int(Sources.PROGRAMS[id][0].get("interval",1))
		if not integer(value,0,threshold-1): return {"error":"death_resource_invalid_saved_progress"}
		entries.append({"source_id":id,"source_slot":slot,"progress":int(value)})
	return {"error":"","owner_id":owner.get("id",-1),"trinkets":owner.get("trinkets",[]).duplicate(true),"entries":entries}
static func attach(options: Dictionary,left: Dictionary,right: Dictionary,catalog) -> String:
	var contexts: Array=[context_for(left,catalog),context_for(right,catalog)]
	for context in contexts:
		if not str(context.error).is_empty(): return str(context.error)
	options[CONTEXT]=contexts
	return ""
func initialize(engine) -> String:
	var contexts: Variant=engine._options.get(CONTEXT,[{},{}])
	if not contexts is Array or contexts.size()!=2: return "death_resource_invalid_contexts"
	for side in range(2):
		var context: Variant=contexts[side]
		if not context is Dictionary: return "death_resource_invalid_context"
		if context.is_empty(): continue
		if context.size()!=4 or context.get("error")!="" or not context.get("trinkets") is Array or not context.get("entries") is Array: return "death_resource_changed_context"
		if context.entries.is_empty(): continue
		if not integer(context.get("owner_id")): return "death_resource_invalid_owner"
		var expected: Array=[]
		for index in range(context.trinkets.size()):
			var id: String=str(context.trinkets[index])
			if id not in Sources.DEATH_IDS: continue
			var slot: String="trinket:%d:%s:0" % [index,id]
			var matching: Array=context.entries.filter(func(entry):return entry is Dictionary and entry.get("source_slot")==slot)
			if matching.size()!=1: return "death_resource_missing_owned_slot"
			var entry: Dictionary=matching[0]
			if entry.size()!=3 or entry.get("source_id")!=id or not integer(entry.get("progress"),0,int(Sources.PROGRAMS[id][0].get("interval",1))-1): return "death_resource_changed_owned_slot"
			expected.append(entry)
			_states[side][slot]=int(entry.progress)
		if expected!=context.entries: return "death_resource_slot_order_changed"
		_contexts[side]=context.duplicate(true)
	return ""
func removed_death_batch(engine,queue: Array) -> bool:
	for entry in queue:
		var side: int=int(entry.side)
		if _contexts[side].is_empty(): continue
		var dead: Dictionary=entry.unit
		var sequence: int=int(entry.get("milestone_death_sequence",-1))
		var key: String=str(side)+":"+str(dead._combat_id)
		if sequence<0 or sequence>=engine._log.size() or _consumed.has(key) or engine._boards[side].any(func(unit):return is_same(unit,dead)): engine._fail("death_resource_requires_actual_removed_death");return false
		var actual: Dictionary=engine._log[sequence]
		if actual.get("event")!="death" or actual.get("side")!=side or actual.get("unit")!=dead.get("uid"): engine._fail("death_resource_changed_death_receipt");return false
		_consumed[key]=true
		for listener in _contexts[side].entries:
			var program: Dictionary=Sources.PROGRAMS[listener.source_id][0]
			if program.get("trigger_tribeless",false) and not dead.get("tribes",[]).is_empty(): continue
			var before: int=int(_states[side][listener.source_slot])
			var threshold: int=int(program.get("interval",1))
			var after: int=(before+1)%threshold
			var grant: bool=before+1>=threshold
			_states[side][listener.source_slot]=after
			var event_sequence: int=engine._log.size()
			engine._emit(PROGRESS,{"type":PROGRESS,"owned_death_resource_family":FAMILY,"side":side,"owner_id":_contexts[side].owner_id,"source_id":listener.source_id,"source_slot":listener.source_slot,"before":before,"after":after,"death_sequence":sequence,"dead_uid":dead.uid,"dead_combat_id":dead._combat_id,"grant":grant})
			if not engine._error.is_empty(): return false
			_events.append(engine._log[event_sequence].duplicate(true))
			if grant:
				engine._bulk_resource_host.activate_owned_death_trinket(engine,side,str(listener.source_id),str(listener.source_slot),sequence)
				if not engine._error.is_empty(): return false
	return true
func complete(engine) -> void:
	_completed=true;_seed=engine._seed;_sealed=engine._log.duplicate(true)
static func result_claimed(events: Array) -> bool:
	return events.any(func(event):return event is Dictionary and (event.has("owned_death_resource_family") or event.get("event")==PROGRESS))
func authenticate(result: Dictionary,left: Dictionary,right: Dictionary,ghost: bool) -> String:
	if _used or _authenticated or not _completed or result.get("seed")!=_seed or result.get("log")!=_sealed or result.get("error")!="" or _sealed.is_empty() or _sealed[-1].get("event")!="combat_end": return "death_resource_not_actual_successful_result"
	_owners=[left,right]
	for side in range(2):
		if _contexts[side].is_empty() or ghost and side==1: continue
		if _owners[side].get("id")!=_contexts[side].owner_id or _owners[side].get("trinkets",[])!=_contexts[side].trinkets: return "death_resource_changed_owner_or_slots"
		for listener in _contexts[side].entries:
			if listener.source_id in Sources.COMBAT_AVENGE_IDS: continue
			if _owners[side].get("mechanism_state",{}).get(listener.source_slot+":interval",0)!=listener.progress: return "death_resource_changed_owner_progress"
	_settlement=_events.filter(func(event):return not (ghost and event.side==1))
	_authenticated=true
	return ""
func commit_progress(owner: Dictionary,event: Dictionary) -> String:
	if _used or not _authenticated or _cursor>=_settlement.size() or event!=_settlement[_cursor]: return "death_resource_stale_or_replayed_progress"
	var side: int=int(event.side)
	var key: String=event.source_slot+":interval"
	if event.source_id in Sources.COMBAT_AVENGE_IDS:
		var local_key: String=str(side)+":"+key
		if not is_same(owner,_owners[side]) or owner.get("id")!=_contexts[side].owner_id or owner.get("trinkets",[])!=_contexts[side].trinkets or _avenge_settlement.get(local_key,0)!=event.before: return "death_resource_changed_combat_avenge_settlement"
		_avenge_settlement[local_key]=int(event.after)
		_cursor+=1
		return ""
	if not is_same(owner,_owners[side]) or owner.get("id")!=_contexts[side].owner_id or owner.get("trinkets",[])!=_contexts[side].trinkets or owner.get("mechanism_state",{}).get(key,0)!=event.before: return "death_resource_changed_progress_owner"
	if not owner.has("mechanism_state"): owner.mechanism_state={}
	owner.mechanism_state[key]=int(event.after)
	_cursor+=1
	return ""
func finish() -> String:
	if _used or not _authenticated or _cursor!=_settlement.size(): return "death_resource_unfinished_progress"
	_used=true;_owners=[]
	return ""
static func after_recruit_death(engine,owner: Dictionary,victim: Dictionary,receipt: Dictionary) -> String:
	if not owner.get("trinkets",[]).any(func(id):return id in Sources.DEATH_IDS): return ""
	var issue: String=Sources.player_error(engine.catalog,owner)
	if not issue.is_empty(): return issue
	if (engine.state.get("phase")!="recruit" and not TurnDeath.window_active(engine,owner)) or not integer(owner.get("id"),0,engine.state.players.size()-1) or not is_same(engine.state.players[int(owner.id)],owner): return "death_resource_requires_actual_recruit_owner"
	var receipt_index: int=-1
	for index in range(engine.events.size()):
		if is_same(engine.events[index],receipt): receipt_index=index;break
	if receipt_index<0 or receipt.get("type")!="recruit_death" or receipt.get("player")!=owner.id or receipt.get("uid")!=victim.get("uid") or receipt.get("card_id")!=victim.get("card_id") or receipt.get("round")!=engine.state.round or owner.board.any(func(unit):return is_same(unit,victim)): return "death_resource_requires_actual_recruit_death"
	return _after_removed_death(engine,owner,victim,receipt,receipt_index)

# The owned Rally caller carries its own actual removed-wave capability. Do
# not borrow a TurnDeath window or weaken the ordinary recruit entry above.
static func owned_rally_error(engine,owner: Dictionary) -> String:
	if not owner.get("trinkets",[]) is Array or not owner.get("mechanism_state",{}) is Dictionary: return "death_resource_invalid_owner_shape"
	if not owner.get("trinkets",[]).any(func(id):return id in Sources.DEATH_IDS): return ""
	return Sources.player_error(engine.catalog,owner)

static func owned_rally_reader(effect: Dictionary) -> bool:
	# Exact combat-only Avenge programs are dormant here; on_event still
	# matches friendly_death, never combat_friendly_death.
	return effect.get("cyclic_resource_source") in Sources.DEATH_IDS and Sources.effect_error(effect).is_empty()

static func after_owned_rally_death(engine,owner: Dictionary,authority: Dictionary,wave: Dictionary,record: Dictionary) -> String:
	var issue: String=owned_rally_error(engine,owner)
	if not issue.is_empty(): return issue
	if not owner.get("trinkets",[]).any(func(id):return id in Sources.DEATH_IDS): return ""
	issue=engine.OwnedRallyEOT.Damage.Removed._record_error(engine,owner,authority,wave,record)
	if not issue.is_empty(): return issue
	if engine.state.get("phase")!="end_turn" or not integer(owner.get("id"),0,engine.state.players.size()-1) or not is_same(engine.state.players[int(owner.id)],owner): return "death_resource_requires_actual_owned_rally_owner"
	return _after_removed_death(engine,owner,record.source,record.receipt,int(record.receipt_index))

static func _after_removed_death(engine,owner: Dictionary,victim: Dictionary,receipt: Dictionary,receipt_index: int) -> String:
	var key: String=str(engine.state.round)+":"+str(engine.state.command_sequence)+":"+str(receipt_index)+":"+str(victim.uid)
	if engine._death_resource_recruit_used.has(key): return "death_resource_replayed_recruit_death"
	engine._death_resource_recruit_used[key]=true
	engine.Mechanisms.on_event(engine,owner,"friendly_death",{"unit":victim,"actual_recruit_death":receipt})
	return "death_resource_recruit_delivery_failed" if engine.state.phase=="error" else ""
