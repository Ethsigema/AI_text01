extends SceneTree
const Death=preload("res://death.gd")
const Hero=preload("res://hero.gd")
const Portrait=preload("res://observers.gd")
const Admission=preload("res://admission.gd")
const Source=preload("res://death_sources.gd")
const EOT=preload("res://eot.gd")
var checks: int=0
var failures: int=0
class Catalog:
 var portrait_error: String=""
 func get_card(id): return Source.SOURCES.get(id,{}).duplicate(true)
class Mechanisms:
 static func on_event(engine,owner,event,context):
  engine.deliveries.append({"owner":owner,"event":event,"context":context})
  if engine.delivery_failed: engine.state.phase="error"
class FakeEngine:
 var OwnedRallyEOT=EOT
 var Mechanisms=load("res://test.gd").Mechanisms
 var catalog=Catalog.new()
 var state: Dictionary={}
 var events: Array=[]
 var _death_resource_recruit_used: Dictionary={}
 var _milestone_recruit_death_used: Dictionary={}
 var _owned_timed_event_context: Dictionary={}
 var deliveries: Array=[]
 var logs: Array=[]
 var turn_window: bool=false
 var event_error: String=""
 var self_destroy_error: String=""
 var empty_domain: bool=false
 var empty_factory: bool=false
 var delivery_failed: bool=false
 func _log(type,payload): logs.append({"type":type,"payload":payload})
 func _add_hand(owner,reward):
  owner.hand.append(reward)
  if delivery_failed: state.phase="error"
func expect(value: bool,label: String):
 checks+=1
 if not value:
  failures+=1
  printerr("FAIL: "+label)
func fixture() -> Dictionary:
 var e=FakeEngine.new()
 var cause: Dictionary={"uid":"rally","card_id":"BG29_809","health":8,"max_health":8}
 var dead: Dictionary={"uid":"dead","card_id":"fixture-minion","health":0,"max_health":3,"kind":"minion","tribes":[]}
 var p: Dictionary={"id":0,"hero_id":Hero.Sources.INI,"trinkets":[Source.DEATH_IDS[0]],"board":[cause],"hand":[],"mechanism_state":{},Hero.Trade.STATE:{"progress":0}}
 e.state={"players":[p],"phase":"end_turn","round":1,"command_sequence":2}
 var damage: Dictionary={"health_after":0,"target_uid":"dead","amount":1,"batch_index":0}
 var receipt: Dictionary={"type":"recruit_death","player":0,"uid":"dead","card_id":"fixture-minion","source":"rally","source_id":"BG29_809","reason":"native_owned_rally_damage","batch_index":0,"literal":1,"round":1}
 e.events=[damage,receipt]
 var packet: Dictionary={"index":0,"receipt":damage,"body":dead}
 var record: Dictionary={"source":dead,"frozen":dead.duplicate(true),"receipt":receipt,"receipt_index":1,"stage":"executing","groups":[],"max_health":3,"packet":packet}
 var wave: Dictionary={"stage":"executing","dead":[dead],"records":[record],"active":record}
 var batch: Dictionary={"stage":"death_running","dr_wave":wave,"dead":wave.dead,"index":0,"literal":1,"damaged":[packet]}
 var parent: Dictionary={"stage":"executing","rally_repeat":1,"effect":{},"context":{},"selected":cause}
 var authority: Dictionary={"running":true,"engine":e,"owner":p,"round":1,"sequence":2,"origin_engine":e,"origin_owner":p,"origin_source":cause,"source":cause,"parent":parent,"mode":"actual","rally_repeat":1,"batch":batch}
 parent.damage_record=authority
 e._owned_timed_event_context={"rally_eot_group":parent}
 return {"e":e,"p":p,"authority":authority,"wave":wave,"record":record}
func destroy(f: Dictionary):
 f.authority.parent.erase("damage_record")
 f.e._owned_timed_event_context.clear()
 f.authority.clear()
func _init():
 for id in Source.DEATH_IDS:
  var effect: Dictionary=Source.PROGRAMS[id][0].duplicate(true)
  expect(Death.owned_rally_reader(effect),"exact death reader "+id)
  effect.count=17
  expect(not Death.owned_rally_reader(effect),"changed death reader rejected "+id)
 expect(not Death.owned_rally_reader({"cyclic_resource_source":"unknown"}),"unknown reader rejected")
 var f=fixture()
 expect(Death.owned_rally_error(f.e,{"trinkets":"bad"})=="death_resource_invalid_owner_shape","malformed trinkets rejected")
 expect(Death.owned_rally_error(f.e,{"trinkets":[],"mechanism_state":[]})=="death_resource_invalid_owner_shape","malformed progress rejected")
 expect(Death.owned_rally_error(f.e,f.p).is_empty(),"valid owned cyclic source")
 f.p.mechanism_state["trinket:0:%s:0:interval"%Source.DEATH_IDS[0]]=6
 expect(Death.owned_rally_error(f.e,f.p)=="cyclic_resource_invalid_saved_progress","invalid cycle rejected")
 f.p.mechanism_state.clear()
 f.e.event_error="original_parent_error"
 var before: Dictionary=f.p.duplicate(true)
 expect(Death.after_owned_rally_death(f.e,f.p,f.authority,f.wave,f.record)=="original_parent_error","resource preserves parent authority error")
 expect(Hero.after_owned_rally_death(f.e,f.p,f.authority,f.wave,f.record)=="original_parent_error","Ini preserves parent authority error")
 expect(f.p==before and f.e.deliveries.is_empty() and f.e.logs.is_empty(),"denied authority does not reward")
 f.e.event_error=""
 expect(Death.after_recruit_death(f.e,f.p,f.record.source,f.record.receipt)=="death_resource_requires_actual_recruit_owner","ordinary recruit resource guard preserved")
 expect(Hero.after_recruit_death(f.e,f.p,f.record.source,f.record.receipt)=="ini_requires_actual_recruit_owner","ordinary recruit Ini guard preserved")
 expect(Death.after_owned_rally_death(f.e,f.p,f.authority,f.wave,f.record).is_empty(),"authenticated resource bridge")
 expect(f.e.deliveries.size()==1 and f.e.deliveries[0].event=="friendly_death" and is_same(f.e.deliveries[0].context.actual_recruit_death,f.record.receipt),"resource dispatch preserves actual receipt and event")
 expect(Death.after_owned_rally_death(f.e,f.p,f.authority,f.wave,f.record)=="death_resource_replayed_recruit_death","resource replay rejected")
 expect(f.e.deliveries.size()==1,"resource replay does not redispatch")
 expect(Hero.after_owned_rally_death(f.e,f.p,f.authority,f.wave,f.record).is_empty(),"authenticated Ini bridge")
 expect(f.p[Hero.Trade.STATE].progress==1 and f.e.logs.size()==1,"Ini increments once")
 expect(Hero.after_owned_rally_death(f.e,f.p,f.authority,f.wave,f.record)=="ini_replayed_recruit_death","Ini replay rejected")
 expect(f.p[Hero.Trade.STATE].progress==1,"Ini replay preserves progress")
 destroy(f)
 for corruption in ["record","receipt","body","wave","owner"]:
  f=fixture();before=f.p.duplicate(true)
  if corruption=="record": f.wave.active=f.record.duplicate(true)
  elif corruption=="receipt": f.e.events[1]=f.record.receipt.duplicate(true)
  elif corruption=="body": f.p.board.append(f.record.source);before=f.p.duplicate(true)
  elif corruption=="wave": f.authority.batch.dr_wave={}
  elif corruption=="owner": f.e.state.players[0]=f.p.duplicate(true)
  expect(not Death.after_owned_rally_death(f.e,f.p,f.authority,f.wave,f.record).is_empty(),"resource rejects detached "+corruption)
  expect(not Hero.after_owned_rally_death(f.e,f.p,f.authority,f.wave,f.record).is_empty(),"Ini rejects detached "+corruption)
  expect(f.p==before and f.e.deliveries.is_empty() and f.e.logs.is_empty(),"detached "+corruption+" leaves rewards untouched")
  destroy(f)
 f=fixture();f.p[Hero.Trade.STATE].progress=8
 expect(Hero.after_owned_rally_death(f.e,f.p,f.authority,f.wave,f.record).is_empty(),"Ini ninth death reward")
 expect(f.p[Hero.Trade.STATE].progress==0 and f.p.hand.size()==1,"Ini ninth death resets and delivers")
 destroy(f)
 f=fixture();f.p[Hero.Trade.STATE].progress=8;f.e.empty_domain=true
 expect(Hero.after_owned_rally_death(f.e,f.p,f.authority,f.wave,f.record).is_empty(),"Ini empty domain preserves existing no-card success")
 expect(f.p.hand.is_empty() and f.e.logs.back().type=="ini_random_mech_empty","Ini empty domain logged")
 destroy(f)
 f=fixture();f.p[Hero.Trade.STATE].progress=8;f.e.empty_factory=true
 expect(Hero.after_owned_rally_death(f.e,f.p,f.authority,f.wave,f.record)=="ini_recruit_mech_factory_failed","Ini factory failure explicit")
 destroy(f)
 f=fixture();f.e.delivery_failed=true
 expect(Death.after_owned_rally_death(f.e,f.p,f.authority,f.wave,f.record)=="death_resource_recruit_delivery_failed","resource delivery failure explicit")
 destroy(f)
 f=fixture();expect(Admission.admission(f.e,f.p).is_empty(),"unaffected admission allowed")
 f.p.test_portrait=true;before=f.p.duplicate(true)
 expect(Admission.admission(f.e,f.p)=="owned_rally_removed_portrait_commit_authority_partial","portrait combination held at admission")
 expect(f.p==before and f.e.deliveries.is_empty() and f.e.logs.is_empty(),"portrait admission hold has no mutation")
 f.e.catalog.portrait_error="original_closure_error"
 expect(Admission.admission(f.e,f.p)=="original_closure_error","portrait source error preserved")
 expect(Portrait.commit_removed(f.e,f.p,f.authority,f.wave,f.record,{"slots":f.p.trinkets})=="owned_rally_portrait_requires_actual_destruction","natural death not portrait destruction")
 f.record.self_destroy={"destroy_index":2}
 f.record.receipt.merge({"source":"dead","source_id":"fixture-minion","reason":"exact_damage_self_destroy","destroy_index":2,"damage_index":0,"damage_source_uid":"rally"},true)
 expect(Portrait.commit_removed(f.e,f.p,f.authority,f.wave,f.record,{"slots":f.p.trinkets})=="owned_rally_removed_portrait_commit_authority_partial","distinct self-destroy adapter explicitly held")
 destroy(f)
 print("ISOLATED_RALLY_BRIDGE checks=%d failures=%d"%[checks,failures])
 quit(1 if failures else 0)
