extends SceneTree
const Exact = preload("res://exact.gd")
var assertions: int = 0
var failures: Array = []
var reproductions: Array = []
func check(value: bool, label: String) -> void:
	assertions += 1
	if not value: failures.append(label); printerr("FAIL: "+label)
func write_text(path: String,text: String) -> void:
	var file: FileAccess=FileAccess.open(path,FileAccess.WRITE);file.store_string(text);file.close()
func check_program(guard,unit: Dictionary,label: String) -> void:
	check(guard.program_error(unit).is_empty(),label+": integral JSON numbers accepted")
	var key: String=""
	for field in unit.effects[0]:
		if unit.effects[0][field] is int or unit.effects[0][field] is float: key=field;break
	for bad in [true,false,"1",null,INF,NAN,0.5,999999.0]:
		var changed: Dictionary=unit.duplicate(true);changed.effects[0][key]=bad
		check(not guard.program_error(changed).is_empty(),label+": altered number/type rejected: "+str(bad))
	var extra: Dictionary=unit.duplicate(true);extra.effects[0].unexpected=true
	check(not guard.program_error(extra).is_empty(),label+": extra leaf field rejected")
	var unknown: Dictionary=unit.duplicate(true);unknown.id="unrelated"
	check(not guard.program_error(unknown).is_empty(),label+": unrelated identity rejected")
func _initialize() -> void:
	check(Exact.same({"n":1}, {"n":1.0}),"numeric helper: JSON 1.0 equals literal 1")
	for bad in [true,false,"1",null,INF,NAN,1.5,9223372036854775808.0]: check(not Exact.same({"n":1},{"n":bad}),"numeric helper rejects "+str(bad))
	for name in ["elise_refresh_sources","parasitic_fleshling_sources","mutated_lasher_sources","determined_defender_sources"]:
		var guard=load("res://"+name+".gd")
		for id in guard.IDS:
			var unit: Dictionary={"id":id,"effects":JSON.parse_string(JSON.stringify(guard.PROGRAMS[id])),"kind":"minion","is_golden":id.ends_with("_G")}
			check_program(guard,unit,name+":"+id)
	var upbeat=load("res://upbeat_upstart_sources.gd")
	var overlay_path: String="res://data/upbeat_upstart_overlay.json"
	var original_overlay: String=FileAccess.get_file_as_string(overlay_path)
	var source_cards: Dictionary={};for id in upbeat.IDS: source_cards[id]={"id":id}
	check(upbeat.apply_overlay(source_cards.duplicate(true)).is_empty(),"upbeat JSON overlay accepted")
	for bad in [true,false,"2",null,0.5,3]:
		var parsed: Dictionary=JSON.parse_string(original_overlay);parsed.cards[0].effects[0].period=bad;write_text(overlay_path,JSON.stringify(parsed))
		check(not upbeat.apply_overlay(source_cards.duplicate(true)).is_empty(),"upbeat altered period rejected: "+str(bad))
	write_text(overlay_path,original_overlay)
	var rows: Dictionary=JSON.parse_string(FileAccess.get_file_as_string("res://rows.json"))
	for name in ["eonar_favor_sources","winner_bread_sources"]:
		var guard=load("res://"+name+".gd")
		var row: Dictionary=rows[guard.ID]
		check(guard.import_error(row).is_empty(),name+": original supplemental row accepted")
		var canonical: Dictionary=guard.CARD if name=="eonar_favor_sources" else guard.ROW
		check(guard.import_error(canonical).is_empty(),name+": canonical row accepted")
		for key in guard.IMPORT_ROW:
			var changed: Dictionary=row.duplicate(true);var value: Variant=changed[key]
			if value is bool: changed[key]=not value
			elif value is int or value is float: changed[key]=value+1
			elif value is Array: changed[key]=["unexpected"]
			else: changed[key]=str(value)+"?"
			check(not guard.import_error(changed).is_empty(),name+": pinned field mutation rejected: "+key)
		for mutation in [{"solo_eligible":false},{"duos_exclusive":true},{"requires_teammate_effect":true},{"source_conflicts":["audit_conflict"]},{"mechanisms":["audit_conflict"]},{"card_id":"unrelated"},{"dynamic_script_parameters":{"TAG_SCRIPT_DATA_NUM_1":"999"}}]:
			var changed: Dictionary=row.duplicate(true);changed.merge(mutation,true)
			var issue: String=guard.import_error(changed);var cards: Dictionary={guard.ID:changed};var overlay_issue: String=guard.apply_overlay(cards)
			check(not issue.is_empty(),name+": conflicting supplemental metadata must reject: "+str(mutation.keys()[0]))
			if issue.is_empty(): reproductions.append({"family":name,"changed":mutation,"import_error":issue,"apply_overlay_error":overlay_issue,"result_solo_eligible":cards[guard.ID].get("solo_eligible"),"retained_card_id":cards[guard.ID].get("card_id"),"retained_source_conflicts":cards[guard.ID].get("source_conflicts")})
		var proof_path: String=guard.NATIVE_PROOF;var proof: String=FileAccess.get_file_as_string(proof_path)
		write_text(proof_path,proof+" ");check(not guard.import_error(row).is_empty(),name+": changed native proof rejected");write_text(proof_path,proof)
		check(DirAccess.rename_absolute(proof_path,proof_path+".hold")==OK,name+": isolate proof")
		check(not guard.import_error(row).is_empty(),name+": absent native proof rejected")
		check(DirAccess.rename_absolute(proof_path+".hold",proof_path)==OK,name+": restore proof")
		var output: Dictionary={guard.ID:row.duplicate(true)};check(guard.apply_overlay(output).is_empty(),name+": canonical import succeeds")
		check(Exact.same(output[guard.ID].effects,canonical.effects),name+": exact canonical program retained")
		check(Exact.same(output[guard.ID].default_pool,canonical.default_pool),name+": original canonical default-pool flag retained")
		var first: Dictionary=output.duplicate(true)
		check(guard.apply_overlay(output).is_empty() and Exact.same(first,output),name+": merged canonical repeat is idempotent")
		var standalone: Dictionary={guard.ID:canonical.duplicate(true)}
		check(guard.apply_overlay(standalone).is_empty() and Exact.same(standalone[guard.ID],canonical),name+": standalone canonical overlay accepted")
		check(guard.apply_overlay(standalone).is_empty() and Exact.same(standalone[guard.ID],canonical),name+": standalone canonical repeat is idempotent")
		for input in [null,[],true,"invalid"]:
			check(not guard.apply_overlay({guard.ID:input}).is_empty(),name+": malformed input rejected")
		for shape in [canonical,first[guard.ID]]:
			for mutation in [{"solo_eligible":false},{"duos_exclusive":true},{"requires_teammate_effect":true},{"source_conflicts":["audit_conflict"]},{"mechanisms":["audit_conflict"]},{"card_id":"unrelated"},{"unexpected":true}]:
				var changed: Dictionary=shape.duplicate(true);changed.merge(mutation,true)
				check(not guard.import_error(changed).is_empty(),name+": conflicting canonical metadata rejected: "+str(mutation.keys()[0]))

	var result: Dictionary={"assertions":assertions,"failures":failures,"reproductions":reproductions,"scope":"Isolated production source scripts, exact comparator methods and real copied proof/overlay/supplemental JSON. No Game or Catalog."}
	write_text("res://results.json",JSON.stringify(result,"\t"));print(JSON.stringify(result));quit(0 if failures.is_empty() else 1)
