extends RefCounted
const Exact=preload("res://core/board_aura_effects.gd")
## Native Upbeat Upstart family. Implementation written, not tested or accepted.
## Normal and golden quantities come from their independent terminal definitions.
const IDS: Array = ["BG26_120", "BG26_120_G"]
const TYPE: String = "end_turn_periodic_resource"
const PROGRAMS: Dictionary = {
	"BG26_120": [{"type":"end_turn_periodic_resource","source_id":"BG26_120","period":2,"mode":"highest_health","scope":"self","multiplier":1}],
	"BG26_120_G": [{"type":"end_turn_periodic_resource","source_id":"BG26_120_G","period":2,"mode":"highest_health","scope":"self","multiplier":2}]
}

static func apply_overlay(cards: Dictionary) -> String:
	var data: Variant = JSON.parse_string(FileAccess.get_file_as_string("res://data/upbeat_upstart_overlay.json"))
	if not data is Dictionary or not data.get("cards") is Array:
		return "upbeat_upstart_missing_overlay"
	for row in data.cards:
		if not row is Dictionary or row.get("id") not in IDS or not cards.has(row.id):
			return "upbeat_upstart_missing_native_identity"
		if not Exact.same(row.get("effects"),PROGRAMS[row.id]): return "upbeat_upstart_changed_overlay_program"
		var merged: Dictionary = cards[row.id].duplicate(true)
		merged.merge(row, true)
		merged.quality_flags = merged.get("quality_flags", []).duplicate()
		merged.quality_flags.erase("effect_not_implemented")
		cards[row.id] = merged
	return ""
