extends RefCounted
## Ordinary live-pool Discover eligibility only, written_unverified.
## The host still owns the original unique-ID sampling, offer, stock transfer,
## hand acquisition, completion listeners and true-empty triple compensation.
const Eligibility=preload("res://core/bulk_resource_eligibility.gd")

static func filtered_trait(card: Dictionary, printed: Dictionary, trait_name: String) -> Variant:
	if card.get("kind")!="minion" or card.get("is_golden")==true: return false
	if not card.get("is_golden") is bool: return null
	return Eligibility.printed_trait(card,printed,trait_name)

static func candidate_plan(engine, player: Dictionary, tier: int, tribe: String, effect_filter: String, keyword_filter: String) -> Dictionary:
	if tier < -1 or effect_filter not in ["","battlecry","deathrattle"] or keyword_filter not in ["","magnetic"]:
		return {"ok":false,"error":"minion_discover_unknown_filter_held","candidates":[]}
	var emergency_issue: String=engine.EmergencyLanding.draw_error(engine,player)
	if not emergency_issue.is_empty(): return {"ok":false,"error":emergency_issue,"candidates":[]}
	if tier==-1 and not Eligibility.integer(player.get("tier")):
		return {"ok":false,"error":"minion_discover_unknown_owner_tier_held","candidates":[]}
	var leaf: Dictionary={"tier":tier,"tribe":tribe}
	if tier==-1: leaf.maximum_tier=player.tier
	if not effect_filter.is_empty(): leaf.effect_filter=effect_filter
	var candidates: Array=[]
	var unresolved: Array=[]
	# The original sorted actual pool is the domain. Do not reconstruct an
	# alternate pool from supported cards, printed tiers or generated children.
	for id in engine._pool_ids():
		if not engine.EmergencyLanding.Sources.candidate_allowed(player,str(id)): continue
		var stock: Variant=engine.pool.get(id)
		if Eligibility.integer(stock) and stock==0: continue
		var card: Dictionary=engine.catalog.get_card(str(id))
		if card.get("kind") in ["minion","spell"] and card.kind!="minion": continue
		if card.get("is_golden")==true and not engine.Aureate.Sources.minion_id(id): continue
		var identity_issue: String=""
		if card.get("id")!=id or card.get("kind")!="minion" or not card.get("is_golden") is bool: identity_issue="normal_identity"
		var record: Dictionary={"tier":card.get("tier"),"tribes":card.get("tribes"),"eligibility_issue":identity_issue}
		var printed: Dictionary=engine.catalog.source_catalog.get_card(str(id)) if engine.catalog.source_catalog!=null else card
		for trait_name in [effect_filter,keyword_filter]:
			if not trait_name.is_empty(): record[trait_name]=filtered_trait(card,printed,trait_name)
		var match_result: Dictionary=Eligibility.matches(record,leaf)
		if not match_result.matches and match_result.unknown.is_empty(): continue
		if not keyword_filter.is_empty():
			var keyword_match: Dictionary=Eligibility.matches(record,{"effect_filter":keyword_filter})
			if not keyword_match.matches and keyword_match.unknown.is_empty(): continue
			match_result.unknown.append_array(keyword_match.unknown)
		if not Eligibility.integer(stock): match_result.unknown.append("stock")
		if not match_result.unknown.is_empty():
			unresolved.append({"id":id,"fields":match_result.unknown});continue
		if id==engine.Devilish.Acquisition.ID:
			var devilish_candidate_issue: String=engine.Devilish.Acquisition.Standard.candidate_error(engine,player,card)
			if not devilish_candidate_issue.is_empty():
				unresolved.append({"id":id,"fields":[devilish_candidate_issue]});continue
		candidates.append(id)
	if not unresolved.is_empty():
		return {"ok":false,"error":"minion_discover_eligibility_conditional_held:"+JSON.stringify(unresolved),"candidates":[],"unresolved":unresolved}
	return {"ok":true,"error":"","candidates":candidates}

static func selection_error(engine, player: Dictionary, index: int) -> String:
	if index<0 or index>=player.get("discover",[]).size(): return ""
	var offer: Dictionary=player.discover[index]
	# Independent special Discover hosts retain their own eligibility and rules.
	if offer.get("choice_kind","")!="" or offer.get("kind")!="minion": return ""
	var id: String=str(offer.get("id",""))
	if offer.get("is_golden")==true:
		if not engine.Aureate.Sources.minion_id(id): return "minion_discover_generated_golden_variant_held"
		var aureate_issue: String=engine.Aureate.Sources.source_error(offer)
		if not aureate_issue.is_empty(): return aureate_issue
	if offer.get("supported")!=true or engine.catalog.get_card(id).get("supported")!=true:
		return "minion_discover_selected_unimplemented_held:"+id
	return ""
