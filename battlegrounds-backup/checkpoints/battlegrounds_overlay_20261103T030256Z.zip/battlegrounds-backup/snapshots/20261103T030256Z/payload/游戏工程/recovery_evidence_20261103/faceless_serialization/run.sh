#!/bin/sh
set -eu
here=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
root=$(CDPATH= cd -- "$here/../.." && pwd)
scratch=$(mktemp -d /tmp/faceless-serialization-test.XXXXXX)
mkdir -p "$scratch/home" "$scratch/config" "$scratch/data" "$scratch/cache" "$scratch/project/core"
for file in faceless_sources phase_undead_army_sources pool_identity; do cp "$root/core/$file.gd" "$scratch/project/core/"; done
cp "$here/test.gd" "$scratch/project/test.gd"
printf 'config_version=5\n[application]\nconfig/name="Faceless serialization regression"\n' > "$scratch/project/project.godot"
HOME="$scratch/home" XDG_CONFIG_HOME="$scratch/config" XDG_DATA_HOME="$scratch/data" XDG_CACHE_HOME="$scratch/cache" timeout 30s godot --headless --path "$scratch/project" --script test.gd
