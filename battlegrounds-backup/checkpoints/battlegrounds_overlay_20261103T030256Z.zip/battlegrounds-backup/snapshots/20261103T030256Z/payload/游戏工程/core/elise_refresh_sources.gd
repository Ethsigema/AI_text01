extends RefCounted
const Exact=preload("res://core/board_aura_effects.gd")
## Written implementation; not yet run or validated.
const TYPE: String = "elise_refresh_golden_monkey"
const KEY: String = "elise_refresh_progress"
const NORMAL: String = "BG23_353"
const GOLDEN: String = "BG23_353_G"
const CHILD: String = "BG23_353_Gt"
const IDS: Array = [NORMAL, GOLDEN]
const PROGRAMS: Dictionary = {
	"BG23_353": [{"type":"elise_refresh_golden_monkey","source_id":"BG23_353","refreshes":5,"count":1,"card_id":"BG23_353_Gt"}],
	"BG23_353_G": [{"type":"elise_refresh_golden_monkey","source_id":"BG23_353_G","refreshes":5,"count":2,"card_id":"BG23_353_Gt"}]
}

static func identity(source: Dictionary) -> String:
	return str(source.get("card_id", source.get("id", "")))

static func accepts(source: Dictionary) -> bool:
	return identity(source) in IDS

static func integer(value: Variant, lower: int, upper: int) -> bool:
	return (value is int or value is float) and value >= lower and value <= upper and value == floor(value)

static func program_error(source: Dictionary) -> String:
	var id: String = identity(source)
	if id not in IDS or not Exact.same(source.get("effects", []),PROGRAMS[id]):
		return "elise_refresh_native_program_changed"
	if source.has(KEY) and not integer(source[KEY], 0, 4):
		return "elise_refresh_invalid_saved_progress"
	return ""

static func initialize(unit: Dictionary) -> void:
	if accepts(unit): unit[KEY] = 0

static func apply_overlay(cards: Dictionary) -> String:
	var parsed: Variant = JSON.parse_string(FileAccess.get_file_as_string("res://data/elise_refresh_native_overlay.json"))
	if not parsed is Dictionary or not parsed.get("cards") is Array:
		return "elise_refresh_missing_overlay"
	for overlay in parsed.cards:
		if not overlay is Dictionary or overlay.get("id") not in IDS or not cards.has(overlay.id):
			return "elise_refresh_missing_native_parent"
		var merged: Dictionary = cards[overlay.id].duplicate(true)
		merged.merge(overlay, true)
		var issue: String = program_error(merged)
		if not issue.is_empty(): return issue
		cards[overlay.id] = merged
	return ""

static func closure_error(catalog) -> String:
	for id in IDS:
		var parent: Dictionary = catalog.get_card(id)
		if parent.is_empty(): return "elise_refresh_missing_native_parent"
		var issue: String = program_error(parent)
		if not issue.is_empty(): return issue
	var child: Dictionary = catalog.get_card(CHILD)
	if child.is_empty() or child.get("supported") != true:
		return "elise_refresh_missing_golden_monkey_leaf"
	if child.get("is_golden") != true or child.get("tier") != 1 or child.get("attack") != 6 or child.get("health") != 6 or child.get("tribes") != [] or child.get("keywords") != ["taunt"] or child.get("effects") != []:
		return "elise_refresh_changed_native_monkey_body"
	return ""

static func inheritance_error(originals: Array) -> String:
	for unit in originals:
		if accepts(unit) and int(unit.get(KEY, 0)) != 0:
			return "elise_refresh_progress_merge_or_golden_rebase_partial"
	return ""
