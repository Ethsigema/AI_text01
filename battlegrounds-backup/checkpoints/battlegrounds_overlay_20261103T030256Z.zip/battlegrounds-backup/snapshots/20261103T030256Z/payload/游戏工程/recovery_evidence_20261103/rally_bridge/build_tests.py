from pathlib import Path
import json,re,sys
root=Path(sys.argv[1])
out=Path(sys.argv[2]);out.mkdir(parents=True,exist_ok=True)
def method(file,name):
 s=(root/file).read_text();m=re.search(r'^static func '+re.escape(name)+r'\(',s,re.M);assert m
 tail=s[m.start():];end=re.search(r'\n(?:static func |func |const |var )',tail)
 return (tail[:end.start()] if end else tail).rstrip()+'\n'
def constant(file,name):
 for l in (root/file).read_text().splitlines():
  if re.match(r'const '+name+r'\b',l):return l+'\n'
 raise Exception(name)
def write(name,body): (out/name).write_text(body)
write('project.godot','config_version=5\n[application]\nconfig/name="Isolated owned Rally bridge recovery tests"\n')
write('death.gd','extends RefCounted\nconst Sources=preload("res://death_sources.gd")\nconst TurnDeath=preload("res://turn.gd")\n'+''.join(method('death_resource_trinkets.gd',n) for n in ['integer','after_recruit_death','owned_rally_error','owned_rally_reader','after_owned_rally_death','_after_removed_death']))
write('death_sources.gd','extends RefCounted\n'+''.join(constant('cyclic_resource_trinkets.gd',n) for n in ['IDS','DEATH_IDS','COMBAT_AVENGE_IDS','PROGRAMS','SOURCES','FIXED_CHILDREN','RUNTIME_FIELDS'])+''.join(method('cyclic_resource_trinkets.gd',n) for n in ['same','claimed','source_error','effect_error','player_error']))
write('turn.gd','extends RefCounted\nstatic func window_active(engine,_owner): return engine.turn_window\n')
write('hero.gd','extends RefCounted\nconst Sources=preload("res://hero_sources.gd")\nconst TurnDeath=preload("res://turn.gd")\nconst Trade=preload("res://trade.gd")\nconst Resources=preload("res://resources.gd")\n'+constant('milestone_hero_host.gd','PROGRESS')+''.join(method('milestone_hero_host.gd',n) for n in ['player_error','after_recruit_death','after_owned_rally_death','_after_removed_death']))
write('hero_sources.gd','extends RefCounted\n'+''.join(constant('milestone_hero_sources.gd',n) for n in ['INI','INI_LEAF','DEATH_POLICY'])+'static func accepts_id(id): return id==INI\n')
write('trade.gd','extends RefCounted\n'+constant('trade_hero_resources.gd','STATE')+method('death_resource_trinkets.gd','integer')+'static func player_error(player,_catalog): return player.get("test_trade_error", "")\n')
write('resources.gd','extends RefCounted\nconst POLICY="fixture-resource-policy"\nstatic func domain(engine): return {"stock":{},"engine":engine}\nstatic func candidates(domain,_stock,_leaf): return [] if domain.engine.empty_domain else [{"id":"mech"}]\nstatic func draw_random_minion(engine,_leaf): return {} if engine.empty_factory else {"uid":"new-mech","card_id":"mech"}\n')
write('observers.gd','extends RefCounted\nconst Maw=preload("res://maw.gd")\n'+method('owned_recruit_destroy_observers.gd','commit_removed'))
write('maw.gd','extends RefCounted\nconst Sources=preload("res://death_sources.gd")\n')
write('removed.gd','extends RefCounted\nconst Exact=preload("res://death_sources.gd")\nconst Pure=preload("res://pure.gd")\n'+method('owned_rally_deathrattle_host.gd','_wave_error')+method('owned_rally_deathrattle_host.gd','_record_error')+'static func groups_for(_engine,source): return {"error":"","groups":source.get("test_groups",[])}\nstatic func groups_error(_engine,_owner,_source,_groups): return ""\n')
write('pure.gd','extends RefCounted\n'+method('death_resource_trinkets.gd','integer').replace('func integer(', 'func _integer('))
write('damage.gd','extends RefCounted\nconst Removed=preload("res://removed.gd")\nconst Bubblette=preload("res://bubblette.gd")\n'+method('owned_rally_damage_host.gd','_continuation_error'))
write('bubblette.gd','extends RefCounted\nstatic func removed_error(engine,_owner,_authority,_source,_destroy,_packet): return engine.self_destroy_error\n')
write('eot.gd','extends RefCounted\nconst Damage=preload("res://damage.gd")\nstatic func _event_error(engine,_owner,_effect,_context): return engine.event_error\n')
write('admission.gd','extends RefCounted\nconst Heroes=preload("res://hero.gd")\nconst Resources=preload("res://death.gd")\nconst Portraits=preload("res://portrait_fixture.gd")\n'+method('owned_rally_removed_death_rewards.gd','admission'))
write('portrait_fixture.gd','extends RefCounted\nconst Maw=preload("res://portrait_source_fixture.gd")\nconst Kelthuzad=Maw\nconst Blightborne=Maw\nstatic func active(player): return player.get("test_portrait",false)\n')
write('portrait_source_fixture.gd','extends RefCounted\nconst Sources=preload("res://portrait_slot_fixture.gd")\n')
write('portrait_slot_fixture.gd','extends RefCounted\nstatic func slots(player): return [0] if player.get("test_portrait",false) else []\nstatic func closure_error(catalog): return catalog.portrait_error\n')
# Manifest makes extraction and fixture boundaries visible; no full-engine claims.
write('README.txt','These isolated tests extract the final bridge functions verbatim from production. The actual owned-rally _continuation_error, _wave_error and _record_error validators are also extracted verbatim. Peripheral engine, catalog hero validation, resource generation, mechanism delivery, native death groups and portrait source closure are fixtures. This does not execute Game, the full mechanism dispatcher, actual RNG, inventory, or gameplay acceptance.\n')
