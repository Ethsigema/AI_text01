extends SceneTree
const Evidence = preload("res://packaged_source_evidence.gd")
var assertions: int = 0
var failures: Array = []
var details: Array = []
func check(value: bool, label: String) -> void:
	assertions += 1
	if not value: failures.append(label); printerr("FAIL: "+label)
func write_bytes(path: String, bytes: PackedByteArray) -> void:
	var file: FileAccess = FileAccess.open(path,FileAccess.WRITE)
	file.store_buffer(bytes)
	file.close()
func _initialize() -> void:
	var cases: Array = JSON.parse_string(FileAccess.get_file_as_string("res://cases.json"))
	for entry in cases:
		var guard = load("res://"+str(entry.script)+".gd")
		var baseline: Dictionary = guard.validation_evidence()
		check(str(baseline.get("error","missing")).is_empty(),entry.script+": baseline proof")
		check(baseline.get("annotation_status")=="missing_annotations",entry.script+": omission status explicit")
		check(baseline.get("missing_annotations")==entry.missing,entry.script+": exact missing annotation path")
		if entry.script == "deft_deserter_sources": check(guard.proof_error().is_empty(),"deft: legacy string proof result")
		for path in entry.retained:
			var original: PackedByteArray = FileAccess.get_file_as_bytes(path)
			var changed: PackedByteArray = original.duplicate(); changed.append(32)
			write_bytes(path,changed)
			check(not str(guard.validation_evidence().get("error","")).is_empty(),entry.script+": changed proof rejected: "+path)
			write_bytes(path,original)
			check(DirAccess.rename_absolute(path,path+".hold")==OK,"isolate proof file: "+path)
			check(not str(guard.validation_evidence().get("error","")).is_empty(),entry.script+": missing proof rejected: "+path)
			check(DirAccess.rename_absolute(path+".hold",path)==OK,"restore isolated proof file: "+path)
		for path in entry.missing:
			write_bytes(path,"Unverified replacement must fail.\n".to_utf8_buffer())
			check(not str(guard.validation_evidence().get("error","")).is_empty(),entry.script+": changed annotation rejected")
			check(DirAccess.remove_absolute(path)==OK,"remove isolated annotation")
		check(str(guard.validation_evidence().get("error","missing")).is_empty(),entry.script+": proof remains valid after mutation checks")
		details.append({"family":entry.script,"native_proof_files":entry.retained.size(),"missing_annotations":baseline.get("missing_annotations",[]),"annotation_status":baseline.get("annotation_status")})
	var unknown: Dictionary = Evidence.inspect("res://",{"research/forsaken_weaver_sources/OTHER.md":"not-a-hash"})
	check(not str(unknown.error).is_empty(),"unlisted missing Markdown remains fatal")
	var annotation: String = "res://research/activate_minion_rules.md"
	write_bytes(annotation,"isolated helper fixture\n".to_utf8_buffer())
	var matched: Dictionary = Evidence.inspect("res://",{"research/activate_minion_rules.md":FileAccess.get_sha256(annotation)})
	check(str(matched.error).is_empty() and matched.annotation_status=="complete" and matched.missing_annotations.is_empty(),"present matching annotation reports complete")
	check(DirAccess.remove_absolute(annotation)==OK,"remove helper fixture")
	var result: Dictionary = {"assertions":assertions,"failures":failures,"families":details,"scope":"Isolated production evidence methods and exact recursive equality, with real copied proof bytes. No Game/Catalog, command execution, gameplay or acceptance count."}
	var file: FileAccess = FileAccess.open("res://results.json",FileAccess.WRITE);file.store_string(JSON.stringify(result,"\t"));file.close()
	print(JSON.stringify(result))
	quit(0 if failures.is_empty() else 1)
