extends SceneTree
const Catalog=preload("res://core/catalog.gd")
func _initialize() -> void:
	var catalog=Catalog.new()
	catalog.load_catalog()
	var report={"errors":catalog.load_errors,"coverage":catalog.coverage()}
	var file=FileAccess.open("res://recovery_evidence_20261103/catalog_audit.json",FileAccess.WRITE)
	file.store_string(JSON.stringify(report,"  "))
	print("RECOVERY_CATALOG_AUDIT ",JSON.stringify(report))
	quit(0 if catalog.load_errors.is_empty() else 1)
