# Source-proof recovery, 2026-11-03

## Findings

The five source failures were caused by missing human-readable Markdown, not changed native evidence. The original handoff explanation says historical narrative and reports were excluded, while machine-readable shared runtime sources were retained. All 67 retained pre-existing file guards checked here match their original pinned SHA256, including native XML, source/expected JSON, raw rows, host snapshots, seals and manifests. The retained `research/activate_minion_rules.json` also records the Activate mechanic and its exact once-per-turn source references; it is now additionally mandatory and pinned (SHA256 `2f5f617d04ad7b8456c0b7ca9bbc64e64c21adb80b7e516f66e8f1bb1e99b0ce`). Thus 68 retained proof files are checked after this repair.

Exact missing annotation paths:

- `research/activate_minion_rules.md`
- `research/forsaken_weaver_sources/README.md`
- `research/timewarped_anubarak_sources/README.md`
- `research/timewarped_start_grants_sources/SOURCE_REPORT.md`
- `research/timed_dragon_buff_sources/PROPOSAL.md`

## Narrow repair

`core/packaged_source_evidence.gd` permits absence only at the five exact paths above. It does not grant a generic Markdown exception. All prior digest constants remain unchanged. A present but modified Markdown report still fails. Any native/JSON/host proof that is missing or changed still fails. The five existing guards retain their error names and expose `annotation_status: missing_annotations` with exact missing paths through `validation_evidence()`. No missing prose was fabricated. No card effect, native identity, pool membership, coverage status or gameplay rule was changed. This does not reconstruct the historical reports or claim their contents verified.

Changed production files: the new helper and `core/deft_deserter_sources.gd`, `core/forsaken_weaver_sources.gd`, `core/timewarped_anubarak_sources.gd`, `core/timewarped_start_grants.gd`, `core/timed_dragon_buff.gd`. `changes.patch` and `source_hashes.json` record the exact changes.

## Verification

Run `./recovery_evidence_20261103/source_guards/run.sh` from any directory. It creates a temporary isolated Godot project, copies the actual proof bytes, extracts the production validation methods and exact recursive comparator verbatim, and executes only those methods. It does not preload Game or Catalog and has no game-engine fixtures. Mutations are limited to the temporary proof copies.

Godot 4.6.3: 306 assertions passed, zero failures, no script or parse errors. Each of the 68 retained proof files was separately changed and removed; both cases were rejected, with original bytes restored between cases. Each omitted annotation was temporarily replaced with unverified prose and correctly rejected. An unlisted missing Markdown file remained fatal. A present annotation matching its supplied test digest reported complete. All five baseline methods reported their precise annotation omission, with native proof accepted.

These are source-proof tests only. No commands, battles, UI, complete dependency graph or save/load execution was tested here. They do not add to the 433 gameplay acceptance count. The parent task owns any full Catalog recheck and actual gameplay verification.
