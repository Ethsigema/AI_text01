extends RefCounted
const Exact=preload("res://core/board_aura_effects.gd")
## Native BG36_114/G; written_unverified. Growth magnitude remains unresolved.
const TYPE: String = "end_turn_parasitic_fleshling"
const COUNT: String = "native_lifetime_discards"
const IDS: Array = ["BG36_114", "BG36_114_G"]
# These amounts are independent native NUM_1/NUM_2 values, not a golden guess.
const PROGRAMS: Dictionary = {
	"BG36_114": [{"type":"end_turn_parasitic_fleshling","source_id":"BG36_114","attack":2,"health":2,"scope":"leftmost","growth":"discard_increment_unresolved"}],
	"BG36_114_G": [{"type":"end_turn_parasitic_fleshling","source_id":"BG36_114_G","attack":4,"health":4,"scope":"leftmost","growth":"discard_increment_unresolved"}]
}
static func identity(unit: Dictionary) -> String:
	return str(unit.get("card_id",unit.get("id","")))
static func claimed(unit: Dictionary) -> bool:
	return identity(unit) in IDS
static func program_error(unit: Dictionary) -> String:
	return "" if claimed(unit) and Exact.same(unit.get("effects",[]),PROGRAMS[identity(unit)]) else "parasitic_fleshling_changed_native_program"
static func counter_error(owner: Dictionary) -> String:
	var count: Variant=owner.get(COUNT)
	if not (count is int or count is float) or not is_finite(float(count)) or count<0 or count>2147483646 or float(count)!=floor(float(count)):
		return "parasitic_fleshling_missing_or_invalid_lifetime_discard_history"
	return ""
static func apply_overlay(cards: Dictionary) -> String:
	var data: Variant=JSON.parse_string(FileAccess.get_file_as_string("res://data/parasitic_fleshling_overlay.json"))
	if not data is Dictionary or not data.get("cards") is Array: return "parasitic_fleshling_missing_overlay"
	for row in data.cards:
		if not row is Dictionary or row.get("id") not in IDS or not cards.has(row.id): return "parasitic_fleshling_missing_native_identity"
		var merged: Dictionary=cards[row.id].duplicate(true)
		merged.merge(row,true)
		var issue: String=program_error(merged)
		if not issue.is_empty(): return issue
		cards[row.id]=merged
	return ""
