#!/usr/bin/env bash
set -euo pipefail
HERE="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
WORK="$(mktemp -d /tmp/source-guards-tests.XXXXXX)"
python "$HERE/build_tests.py" --output "$WORK/project"
HOME="$WORK/home" XDG_CONFIG_HOME="$WORK/config" XDG_DATA_HOME="$WORK/data" XDG_CACHE_HOME="$WORK/cache" \
  godot --headless --path "$WORK/project" --script res://test.gd > "$WORK/test.log" 2>&1
cat "$WORK/test.log"
if grep -qE 'SCRIPT ERROR|Parse Error|FAIL:' "$WORK/test.log"; then exit 1; fi
python - "$WORK/project/results.json" <<'PY'
import json,sys
result=json.load(open(sys.argv[1])); assert result['assertions'] == 306 and not result['failures'], result
PY
printf 'Isolated proof results: %s\n' "$WORK/project/results.json"
