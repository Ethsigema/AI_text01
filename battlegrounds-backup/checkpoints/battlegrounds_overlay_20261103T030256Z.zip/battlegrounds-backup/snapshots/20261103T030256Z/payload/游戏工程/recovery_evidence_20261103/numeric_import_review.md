# Numeric and import recovery review

Reviewed 2026-11-03. Compared the seven requested source files and `data/catalog.json` with the original 2026-11-01 ZIP. No full Game/Catalog run was performed by this review.

## Numeric comparisons: accepted

The changes in Elise Refresh, Parasitic Fleshling, Mutated Lasher, Determined Defender and Upbeat Upstart replace only nested container equality with the existing `board_aura_effects.same` comparator. It accepts equivalent bounded integer/JSON-float values while retaining exact dictionary keys, array order/length and scalar types. Booleans, strings, null, fractional values, non-finite numbers, wrong IDs and extra effect fields do not become valid programs. No source IDs, effect values, native bodies, pool flags or implementation boundaries changed.

## BG28_504: accepted

A structural comparison of the entire original and recovered `data/catalog.json` found exactly one semantic difference: `BG28_504.temporary` is now explicitly `false`. This matches its pre-existing definition in `core/current_spell_stock_acquisition.gd`. `default_pool:false`, `pool_supported:false` and the existing program remain unchanged; this does not open new stock eligibility.

## Two import guards: gap found and fixed

The first recovery version checked only 16 supplemental fields. Isolated tests reproduced 14 improper acceptances across Eonar's Favor and Winner's Bread: altered solo/duo eligibility, teammate requirements, source conflicts, mechanisms, contradictory `card_id` and native script parameters were accepted. In particular, `solo_eligible:false` was silently replaced with `true`. The native-file hash did not bind the supplied row's unexamined metadata.

With the parent's explicit authorization, changed only `core/eonar_favor_sources.gd` and `core/winner_bread_sources.gd`. Each now requires one of three exact full shapes: its complete original supplemental row, its complete pre-existing canonical constant, or the exact merge of those two. Unknown/contradictory fields and malformed non-dictionary inputs fail closed. All original canonical constants and native JSON SHA256 pins remain byte-for-byte unchanged. Thus the existing Eonar default-pool setting and Winner's Bread restricted default-pool setting are not broadened. Missing identities are not created silently.

## Evidence and limits

Godot 4.6.3 isolated review: **266 assertions passed, zero failures**, including valid JSON-number programs, numeric/type/shape mutations, mutations of every supplemental top-level field, all 14 reproduced conflicts, native-proof removal/change, exact original imports, standalone canonical forms, repeated merged/standalone overlays, and canonical metadata conflicts. No script/parse errors in the final run. The repaired import outputs are idempotent.

Rerun: `./recovery_evidence_20261103/numeric_import_tests/run.sh`. This copies production source scripts and evidence into a temporary project; only the recursive comparator is extracted to avoid the heavy dependency graph. Test evidence includes `results.json`, `test.log`, source hashes and `import_guard_changes.patch`. The initial failed reproductions are preserved as `before_results.json` and `before_test.log`.

This review verifies the source/import boundary, not gameplay, targeting, battle resolution, stock transactions or save/load. It adds no identities to the 433 gameplay acceptance count. The parent owns the final full-graph recheck after these two changes.
