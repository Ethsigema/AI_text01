#!/bin/sh
set -eu
here=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
root=$(CDPATH= cd -- "$here/../.." && pwd)
scratch=$(mktemp -d /tmp/rally-bridge-test.XXXXXX)
mkdir -p "$scratch/home" "$scratch/config" "$scratch/data" "$scratch/cache"
python "$here/build_tests.py" "$root/core" "$scratch/project"
cp "$here/test.gd" "$scratch/project/test.gd"
HOME="$scratch/home" XDG_CONFIG_HOME="$scratch/config" XDG_DATA_HOME="$scratch/data" XDG_CACHE_HOME="$scratch/cache" timeout 45s godot --headless --path "$scratch/project" --script test.gd
