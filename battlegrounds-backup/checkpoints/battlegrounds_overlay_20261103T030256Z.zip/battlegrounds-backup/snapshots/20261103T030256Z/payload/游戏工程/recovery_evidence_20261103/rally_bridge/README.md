# Owned Rally bridge recovery: isolated evidence

Date: 2026-11-03. Engine: Godot 4.6.3.stable.official.7d41c59c4.

## Changes

- death_resource_trinkets.gd: added owned_rally_error, owned_rally_reader, after_owned_rally_death. The ordinary recruit entry keeps its original validation. Both authenticated entries call the unchanged reward payload through a shared private helper. The cyclic source validator remains exact; combat-only Avenge is not relabeled friendly_death.
- milestone_hero_host.gd: added after_owned_rally_death with actual removed-record validation and actual end-turn owner identity checks. Existing replay key, progress, ninth-death reward, empty-domain handling and delivery errors are reused. Ordinary recruit admission is unchanged.
- owned_recruit_destroy_observers.gd: added commit_removed as an explicit error hold after record validation. It does not forge a normal destruction ticket, alter receipt reasons, or report skipped portrait effects as success.
- owned_rally_removed_death_rewards.gd: admission now holds owners with Maw, Kelthuzad or Blightborne portraits after original source validation. This is deliberately conservative, including natural deaths while those portraits are owned. The admission call is present in the prospective lethal-target scan before that wave's packets; no gameplay rollback claim is made.

The portrait authority remains unimplemented: owned_rally_removed_portrait_commit_authority_partial.

## Verification

`sh recovery_evidence_20261103/rally_bridge/run.sh` builds a small temporary project and runs 55 assertions. Final result: 55 checks, 0 failures. HOME and all XDG directories are isolated below /tmp. No full Game run is performed.

The fixture extracts the final bridge methods verbatim, plus existing _continuation_error, _wave_error, _record_error and cyclic source validation methods. It tests source mutation rejection, original recruit guards, actual receipt forwarding, detached record/receipt/body/wave/owner rejection, replay rejection, Ini counter/reward/error branches and the early explicit portrait hold. Native groups, hero source closure, resource generation, mechanism dispatch, and portrait source closure are fixtures.

This is compile/bridge-contract recovery evidence, not full gameplay, RNG/stock, actual mechanism-dispatch, simultaneous-death, portrait, or main-pool acceptance. The 433-card acceptance denominator is unchanged. The parent owns full source-graph parse evidence separately.

changes.patch preserves the exact four-file diff. source_hashes.json records before and after hashes. build_tests.py and test.gd preserve the runnable focused harness.
