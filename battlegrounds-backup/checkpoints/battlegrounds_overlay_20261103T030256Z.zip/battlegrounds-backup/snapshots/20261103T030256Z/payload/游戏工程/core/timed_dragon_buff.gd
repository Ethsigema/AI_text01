extends RefCounted
const PackagedEvidence = preload("res://core/packaged_source_evidence.gd")
## Source-exact Guzzle: one manual living-owner cast and three ordinary EOTs.
## Unsupported compositions below are implementation boundaries, not official prohibitions.
const HandBuffs=preload("res://core/hand_acquisition_buffs.gd")
const Exact = preload("res://core/end_turn_repeats.gd")
const PoolIdentity = preload("res://core/pool_identity.gd")
const SOURCE_ID: String = "BG28_602"
const TYPE: String = "owner_timed_dragon_attack"
const FOLDER: String = "res://research/timed_dragon_buff_sources/"
const MAX_STAT: int = 9223372036854775807
const MAX_JSON_INTEGER: int = 9007199254740991
const PROGRAM: Array = [{"type":"owner_timed_dragon_attack","source_id":"BG28_602","scope":"owner","tribe":"龙","attack":4,"health":0,"turns":3}]
const FILE_SHA256: Dictionary = {"BG28_602_latest.xml":"892b126317a5de1d4acad82b0b16a41bc96c81635b8d7f89de94f7b5d981a1a8","BG28_602_raw_complete.json":"120c104ffff358ae707eb4509a65abdc8295f36f2e1c8108b58926e70cb35780","BG28_602_terminal_225000.xml":"d2aeb8eff55db4ec1eb84544738b82b55ca200ae67819caa44130b62d05d06cd","BG28_602e_latest.xml":"f006ca26f485074d3c9a7e2e1f08acfbe0ecf75a0d5567b6e6effd7ab622d711","BG28_602e_terminal_225000.xml":"db3b67a1e9534171fe00b265845db15791b5f97d849f26d7f3fd6b06ceda7470","OFFICIAL_LOOKUP.json":"e5b2aca1e4c5b12bbd185bd9ea46a991f55b1718e8af89f27c21b3bfbd37a632","PROPOSAL.md":"c10d6ee5eab81f947d61141924c41fecbb76dc56277067997f05247c8ffb9ac5","RELEVANT_PRIOR_EVIDENCE.json":"2b32334369aa87ba7f473e50a4ca72fd668318f5e6adfd8491d5f363a281ebd3","SEALED_PACKET.json":"9c5274a40a1cf815a7470baab1fd502744367e89100c07b2bb9e24b2613c14d5","expected_compiled.json":"8889db9420ea65afa22b3ffd2c358a7fcb00f7ca1f7762fd1e1739b9ae0b2474","source_contract.json":"85dc08737fc220ea4ed55c650055262278d90cced040e10aa1f8d23f0d533eac","source_manifest.json":"9f6d8c20f5490b935b0a20607b875b6c2c4c666d5dbd853e7ff159c71e6e2d75"}

static func _integer(value: Variant, minimum: int = 0) -> bool:
	if value is int: return value >= minimum and value <= MAX_STAT
	return value is float and is_finite(value) and value >= minimum and value <= MAX_JSON_INTEGER and value == floor(value)

static func _marker(value: Variant, depth: int = 0) -> bool:
	if depth > 16: return true
	if value is Dictionary:
		if Exact._same(value.get("type"),TYPE) or Exact._same(value.get("source_id"),SOURCE_ID) or Exact._same(value.get("card_id"),SOURCE_ID) or Exact._same(value.get("id"),SOURCE_ID): return true
		for child in value.values():
			if (child is Dictionary or child is Array) and _marker(child,depth+1): return true
	elif value is Array:
		for child in value:
			if _marker(child,depth+1): return true
	return false

static func claimed(source: Variant) -> bool:
	return source is Dictionary and _marker(source)

static func validate_effect(effect: Variant) -> String:
	if not effect is Dictionary: return "timed_dragon_buff_invalid_effect"
	if not Exact._same(effect.get("type"),TYPE) and not Exact._same(effect.get("source_id"),SOURCE_ID): return ""
	return "" if Exact._same(effect,PROGRAM[0]) else "timed_dragon_buff_incomplete_program"

static func validation_evidence() -> Dictionary:
	# Local, synchronous evidence only. Nothing is persisted in a card or save.
	var proof: Dictionary = PackagedEvidence.inspect(FOLDER,FILE_SHA256)
	if not str(proof.error).is_empty(): return {"error":"timed_dragon_buff_evidence_changed:"+str(proof.changed_path)}
	var contract: Variant = JSON.parse_string(FileAccess.get_file_as_string(FOLDER+"source_contract.json"))
	var expected: Variant = JSON.parse_string(FileAccess.get_file_as_string(FOLDER+"expected_compiled.json"))
	if not contract is Dictionary or not Exact._same(contract.get("source_ids"),[SOURCE_ID]) or not contract.get("records") is Dictionary or contract.records.size() != 1: return {"error":"timed_dragon_buff_source_closure_changed"}
	if not expected is Dictionary or expected.size() != 1 or not expected.get(SOURCE_ID) is Dictionary or not contract.records[SOURCE_ID].get("raw49") is Dictionary: return {"error":"timed_dragon_buff_incomplete_evidence"}
	return {"error":"","raw":contract.records[SOURCE_ID].raw49,"expected":expected[SOURCE_ID],"missing_annotations":proof.missing_annotations,"annotation_status":proof.annotation_status}

static func raw_source_error(card: Variant, evidence: Dictionary = {}) -> String:
	if evidence.is_empty(): evidence = validation_evidence()
	if not str(evidence.get("error","timed_dragon_buff_missing_evidence")).is_empty(): return str(evidence.error)
	return "" if Exact._same(card,evidence.raw) else "timed_dragon_buff_complete_raw_source_changed"

static func source_error(card: Variant, evidence: Dictionary = {}) -> String:
	if not card is Dictionary: return "timed_dragon_buff_invalid_source"
	if not claimed(card): return ""
	if not Exact._same(card.get("id"),SOURCE_ID) or card.has("card_id"): return "timed_dragon_buff_unbound_source"
	if evidence.is_empty(): evidence = validation_evidence()
	if not str(evidence.get("error","timed_dragon_buff_missing_evidence")).is_empty(): return str(evidence.error)
	var expected: Dictionary = evidence.raw.duplicate(true)
	expected.merge(evidence.expected,true)
	if card.has("pool_blocker"): expected.pool_blocker = PoolIdentity.SPELL_REASON
	return "" if Exact._same(card,expected) else "timed_dragon_buff_complete_source_changed"

static func catalog_error(catalog, evidence: Dictionary = {}) -> String:
	if catalog == null: return "timed_dragon_buff_missing_catalog"
	if evidence.is_empty(): evidence = validation_evidence()
	if not str(evidence.get("error","timed_dragon_buff_missing_evidence")).is_empty(): return str(evidence.error)
	var canonical = catalog.get("source_catalog")
	if canonical == null: canonical = catalog
	for current in [canonical,catalog]:
		var card: Dictionary = current.get_card(SOURCE_ID)
		if not Exact._same(card.get("id"),SOURCE_ID): return "timed_dragon_buff_missing_canonical_or_effective_source"
		var issue: String = room_source_error(card,evidence)
		if not issue.is_empty(): return issue
	return ""

static func live_error(source: Variant, catalog, evidence: Dictionary = {}) -> String:
	if not source is Dictionary: return "timed_dragon_buff_invalid_live_source"
	if not claimed(source): return ""
	if not Exact._same(source.get("card_id"),SOURCE_ID): return "timed_dragon_buff_marker_on_wrong_source"
	if evidence.is_empty(): evidence = validation_evidence()
	var issue: String = catalog_error(catalog,evidence)
	if not issue.is_empty(): return issue
	if not Exact._uid(source.get("uid")): return "timed_dragon_buff_invalid_live_uid"
	var effective: Dictionary = catalog.get_card(SOURCE_ID)
	var expected: Dictionary = {"card_id":SOURCE_ID,"name":evidence.raw.name,"kind":"spell","tier":effective.tier,"cost":effective.cost,"attack":0,"health":1,"max_health":1,"keywords":[],"tribes":[],"golden":false,"temporary":false,"is_spellcraft":false,"text":evidence.raw.text,"image":evidence.raw.image,"attachments":[],"pool_components":[],"temporary_buffs":[],"permanent_keywords":[],"magnetic_tribes":[]}
	for key in expected:
		if not Exact._same(source.get(key),expected[key]): return "timed_dragon_buff_live_body_changed:"+key
	if not Exact._same(source.get("effects"),PROGRAM): return "timed_dragon_buff_live_program_changed"
	for key in ["id","card_code"]:
		if source.has(key) and not Exact._same(source[key],SOURCE_ID): return "timed_dragon_buff_live_identity_changed"
	for key in ["excluded","stats_conflict","duos_exclusive","requires_teammate_effect"]:
		if not Exact._same(source.get(key,false),false): return "timed_dragon_buff_live_gate_changed"
	for key in ["quality_flags","source_conflicts"]:
		if not Exact._same(source.get(key,[]),[]): return "timed_dragon_buff_live_flags_changed"
	for key in ["spellcraft_kept","spell_triggers","blood_gems_received_turn","recruit_shop_aura_attack","recruit_shop_aura_health"]:
		if not Exact._same(source.get(key,0),0): return "timed_dragon_buff_live_unrelated_state_changed"
	if not Exact._integer(source.get("pool_count",0),0,1): return "timed_dragon_buff_invalid_pool_count"
	if source.has("pool_id") and source.pool_id not in ["",SOURCE_ID]: return "timed_dragon_buff_pool_identity_changed"
	if source.has("pool_kind") and not Exact._same(source.pool_kind,"spell"): return "timed_dragon_buff_pool_kind_changed"
	var base: Dictionary = {"card_id":SOURCE_ID,"name":evidence.raw.name,"tier":effective.tier,"attack":0,"health":1,"max_health":1,"keywords":[],"tribes":[],"effects":PROGRAM.duplicate(true),"golden":false}
	if not Exact._same(source.get("base_unit"),base): return "timed_dragon_buff_base_changed"
	if source.has("_base") and not Exact._same(source._base,base): return "timed_dragon_buff_base_changed"
	return ""

static func room_source_error(card: Variant, evidence: Dictionary = {}) -> String:
	if not card is Dictionary: return "timed_dragon_buff_invalid_room_source"
	if not card.has("custom_shop_override") and not card.has("source_shop_fields"): return source_error(card,evidence)
	var override: Variant = card.get("custom_shop_override")
	var original: Variant = card.get("source_shop_fields")
	if not override is Dictionary or not Exact._keys(override,["tier","cost","copies"]): return "timed_dragon_buff_invalid_custom_shop"
	if not Exact._integer(override.tier,1,6) or not Exact._integer(override.cost,0,99) or not Exact._integer(override.copies,1,99): return "timed_dragon_buff_invalid_custom_shop"
	if not Exact._same(original,{"tier":4,"cost":4,"pool_supported":false}): return "timed_dragon_buff_custom_source_changed"
	if not Exact._same(card.get("tier"),override.tier) or not Exact._same(card.get("cost"),override.cost) or not Exact._same(card.get("pool_supported"),true): return "timed_dragon_buff_custom_view_changed"
	var canonical: Dictionary = card.duplicate(true)
	canonical.tier=4; canonical.cost=4; canonical.pool_supported=false
	canonical.erase("custom_shop_override"); canonical.erase("source_shop_fields")
	return source_error(canonical,evidence)

const OwnerRepeats = preload("res://core/turn_repeat_spells.gd")
const Amplifier = preload("res://core/tavern_spell_amplifiers.gd")
const PeriodicHero = preload("res://core/periodic_spell_hero.gd")
const AuraRuntime = preload("res://core/board_aura_runtime.gd")
const Damage = preload("res://core/damage_listener_host.gd")
const STATE_KEY: String = "timed_dragon_buff_state"
const SNAPSHOT_KEY: String = "timed_dragon_buff_snapshot"
const VERSION: int = 1
const MAX_ROUND: int = 2147483647
const PHASES: Array = ["recruit","end_turn","combat","spectate","finished","error"]

static func _bad(issue: String) -> Dictionary:
	return {"ok":false,"error":issue}

static func _empty(owner: int) -> Dictionary:
	return {"schema_version":VERSION,"owner":owner,"entry":{}}

static func _entries(value: Dictionary) -> Array:
	if value.has("entries"): return value.entries
	return [] if value.get("entry",{}).is_empty() else [value.entry]
static func _store(player: Dictionary,entries: Array) -> void:
	player[STATE_KEY]={"schema_version":2,"owner":int(player.id),"entries":entries}
static func _state_error(value: Variant, owner: int, current_round: int, phase: String, historical: bool) -> String:
	if not value is Dictionary: return "timed_dragon_buff_invalid_state_shape"
	var legacy: bool=value.get("schema_version")==1
	if not Exact._keys(value,["schema_version","owner","entry"] if legacy else ["schema_version","owner","entries"]): return "timed_dragon_buff_invalid_state_shape"
	if not Exact._integer(value.schema_version,1,2) or not Exact._integer(value.owner,0,MAX_ROUND) or value.owner!=owner: return "timed_dragon_buff_invalid_state_owner_version"
	if legacy and not value.entry is Dictionary or not legacy and not value.entries is Array: return "timed_dragon_buff_invalid_state_entries"
	var seen: Dictionary={};var previous_round: int=0
	for e in _entries(value):
		if not e is Dictionary: return "timed_dragon_buff_invalid_entry_shape"
		if not Exact._keys(e,["source_id","source_uid","cast_round","expires_round","last_paid_round","program"]): return "timed_dragon_buff_invalid_entry_shape"
		if not Exact._same(e.source_id,SOURCE_ID) or not Exact._uid(e.source_uid) or not Exact._same(e.program,PROGRAM[0]): return "timed_dragon_buff_invalid_entry_source_program"
		if not Exact._integer(e.cast_round,1,MAX_ROUND-3) or e.cast_round > current_round: return "timed_dragon_buff_invalid_cast_round"
		if not Exact._integer(e.expires_round,4,MAX_ROUND) or e.expires_round != e.cast_round+3: return "timed_dragon_buff_invalid_expiry"
		if not Exact._integer(e.last_paid_round,int(e.cast_round)-1,mini(current_round,int(e.expires_round)-1)): return "timed_dragon_buff_invalid_round_receipt"
		if not historical:
			if current_round >= e.expires_round: return "timed_dragon_buff_expired_live_record"
			if e.last_paid_round < current_round-1: return "timed_dragon_buff_missing_previous_round_receipt"
			if phase == "recruit" and e.last_paid_round != current_round-1: return "timed_dragon_buff_recruit_receipt_in_future"
			if phase in ["combat","spectate"] and e.last_paid_round != current_round: return "timed_dragon_buff_missing_eot_receipt"
		if seen.has(e.source_uid) or e.cast_round<previous_round: return "timed_dragon_buff_duplicate_or_reordered_entry"
		seen[e.source_uid]=true;previous_round=e.cast_round
	return ""

static func persistent_error(player: Variant, current_round: Variant, phase: Variant) -> String:
	if not player is Dictionary or not Exact._integer(player.get("id"),0,MAX_ROUND): return "timed_dragon_buff_invalid_owner"
	if not Exact._integer(current_round,1,MAX_ROUND) or not phase is String or phase not in PHASES: return "timed_dragon_buff_invalid_round_phase"
	if player.has("alive") and not player.alive is bool: return "timed_dragon_buff_invalid_alive"
	for key in player:
		if str(key).begins_with("timed_dragon_buff") and key != STATE_KEY: return "timed_dragon_buff_unknown_owner_state"
	if not player.has(STATE_KEY): return ""
	# Eliminated players retain auditable history at its original dates. They
	# never pay again and must not make a later save invalid simply by aging.
	return _state_error(player[STATE_KEY],int(player.id),int(current_round),phase,not player.get("alive",true))

static func _actual_owner_error(engine, player: Dictionary) -> String:
	if not engine.state.get("players") is Array or not engine.state.players.any(func(owner): return is_same(owner,player)): return "timed_dragon_buff_requires_actual_owner"
	return persistent_error(player,engine.state.get("round"),engine.state.get("phase"))

static func _observable_eot(value: Variant, depth: int = 0) -> bool:
	if depth > 16: return true
	if value is Dictionary:
		var type: String = str(value.get("type",""))
		if type.begins_with("end_turn_") or "end_turn" in type or type in ["hero_frozen_shop",TYPE] or value.get("event","") == "end_turn": return true
		for child in value.values():
			if (child is Array or child is Dictionary) and _observable_eot(child,depth+1): return true
	elif value is Array:
		for child in value:
			if _observable_eot(child,depth+1): return true
	return false

static func _context_error(engine, player: Dictionary) -> String:
	var issue: String = OwnerRepeats.persistent_error(player,engine.state.round,str(engine.state.phase))
	if not issue.is_empty(): return issue
	var quest: Variant = player.get("active_quest",{})
	if not quest is Dictionary: return "timed_dragon_buff_invalid_quest"
	if not quest.is_empty() and not quest.get("complete",false): return "timed_dragon_buff_unsupported_other_active_objective"
	# Armed/due return effects are other observable owner EOT payloads.
	var coin: Variant = player.get("prize_returning_coin_state",{})
	if not coin is Dictionary or not coin.get("entries",{}) is Dictionary: return "timed_dragon_buff_invalid_other_eot_state"
	for e in coin.get("entries",{}).values():
		if not e is Dictionary or e.get("status","") in ["armed","due"]: return "timed_dragon_buff_unsupported_other_eot_payload"
	var bonus: Dictionary = Amplifier.totals(player)
	if not bonus.ok: return str(bonus.error)
	issue = PeriodicHero.persistent_error(player,engine.catalog,engine.state.round)
	if not issue.is_empty(): return issue
	if bonus.attack != 0 or bonus.health != 0 or player.get("hero_id","") == PeriodicHero.HERO: return "timed_dragon_buff_unsupported_nonzero_spell_bonus"
	var plan: Dictionary = Exact.build_plan(player,engine.catalog,engine._eot_effect_error,engine.state.round,str(engine.state.phase))
	if not plan.ok: return str(plan.error)
	if not plan.programs.is_empty(): return "timed_dragon_buff_unsupported_other_eot_payload"
	if _observable_eot(engine.catalog.get_card(str(player.get("hero_id",""))).get("effects",[])): return "timed_dragon_buff_unsupported_hero_eot_payload"
	for ids in [engine._enabled("anomalies"),player.get("trinkets",[]),player.get("reward_active",[])]:
		if not ids is Array: return "timed_dragon_buff_invalid_mechanism_sources"
		for identity in ids:
			if not identity is String: return "timed_dragon_buff_invalid_mechanism_identity"
			var card: Dictionary = engine.catalog.get_card(identity)
			if not Exact._same(card.get("supported"),true) or not card.get("effects") is Array: return "timed_dragon_buff_invalid_mechanism_source"
			issue = engine.catalog._validate_effects(card.effects)
			if not issue.is_empty(): return issue
			if _observable_eot(card.effects): return "timed_dragon_buff_unsupported_mechanism_eot_payload"
	return ""

static func _cast_error(engine, player: Dictionary, source: Dictionary, require_hand: bool) -> String:
	var issue: String = live_error(source,engine.catalog)
	if issue.is_empty(): issue = _actual_owner_error(engine,player)
	if not issue.is_empty(): return issue
	if not Exact._same(source.get("card_id"),SOURCE_ID) or engine.state.phase != "recruit" or not player.get("alive",false): return "timed_dragon_buff_requires_living_recruit_manual_cast"
	if not Exact._integer(engine.state.round,1,MAX_ROUND-3): return "timed_dragon_buff_round_overflow"
	if not _integer(engine.next_uid,1) or int(source.uid.substr(1)) >= engine.next_uid: return "timed_dragon_buff_cast_uid_in_future"
	if not player.get("hand") is Array: return "timed_dragon_buff_invalid_hand"
	var held: bool = player.hand.any(func(unit): return is_same(unit,source))
	if held != require_hand: return "timed_dragon_buff_requires_manual_hand_consumption"
	if player.has(STATE_KEY) and _entries(player[STATE_KEY]).any(func(entry):return entry.source_uid==source.uid): return "timed_dragon_buff_reused_cast_uid"
	issue = _context_error(engine,player)
	if not issue.is_empty(): return issue
	return str(_recipient_plan(engine,player).error)

static func play_error(engine, player: Dictionary, source: Dictionary) -> String:
	if not claimed(source): return ""
	return _cast_error(engine,player,source,true)

## Called only by Game's real manual-spell branch AFTER its pure preflight and
## hand removal. Generic effect dispatch explicitly refuses this opcode.
static func record_cast(engine, player: Dictionary, source: Dictionary, effect: Dictionary) -> Dictionary:
	var issue: String = validate_effect(effect)
	if issue.is_empty() and not Exact._same(effect,PROGRAM[0]): issue = "timed_dragon_buff_wrong_record_program"
	if issue.is_empty(): issue = _cast_error(engine,player,source,false)
	if not issue.is_empty(): return _bad(issue)
	var r: int = int(engine.state.round)
	var entries: Array=_entries(player.get(STATE_KEY,_empty(int(player.id)))).duplicate(true)
	entries.append({"source_id":SOURCE_ID,"source_uid":source.uid,"cast_round":r,"expires_round":r+3,"last_paid_round":r-1,"program":PROGRAM[0].duplicate(true)})
	_store(player,entries)
	return {"ok":true,"error":""}

static func _prepare(engine, player: Dictionary) -> Dictionary:
	var issue: String = _actual_owner_error(engine,player)
	if not issue.is_empty(): return _bad(issue)
	if not player.get("alive",false) or not player.has(STATE_KEY) or _entries(player[STATE_KEY]).is_empty(): return {"ok":true,"error":"","plan":{}}
	if engine.state.phase not in ["recruit","end_turn"]: return _bad("timed_dragon_buff_invalid_eot_phase")
	issue = catalog_error(engine.catalog)
	if issue.is_empty(): issue = _context_error(engine,player)
	if not issue.is_empty(): return _bad(issue)
	var due: Array=_entries(player[STATE_KEY]).filter(func(entry):return entry.last_paid_round!=engine.state.round).duplicate(true)
	if due.is_empty(): return {"ok":true,"error":"","plan":{}}
	var targets: Dictionary=_recipient_plan(engine,player)
	if not targets.ok: return targets
	var repeated: Dictionary=Exact.multiplier(player,engine.catalog,engine.state.round,str(engine.state.phase))
	if not repeated.ok: return repeated
	var shadow: Dictionary=player.duplicate(true);var totals: Dictionary=engine._attack_gain_health_totals.duplicate(true);var actions: Array=[]
	for entry in due:
		for repetition in range(int(repeated.count)):
			for item in targets.recipients:
				var target: Dictionary=HandBuffs.Gains._find(shadow.board,item.uid)
				issue=HandBuffs._shadow_buff(engine,shadow,target,4,0,totals)
				if not issue.is_empty(): return _bad(issue)
				actions.append({"source_uid":entry.source_uid,"repetition":repetition,"target_uid":item.uid,"after":HandBuffs._snapshot(shadow,totals)})
	return {"ok":true,"error":"","plan":{"owner":int(player.id),"round":int(engine.state.round),"entries":due,"repeat_count":repeated.count,"recipients":targets.recipients,"actions":actions,"totals_before":engine._attack_gain_health_totals.duplicate(true)}}

static func _recipient_plan(engine, player: Dictionary) -> Dictionary:
	var issue: String = ""
	var recipients: Array = []
	var seen: Dictionary = {}
	for unit in player.board:
		if not unit is Dictionary or not Exact._uid(unit.get("uid")) or seen.has(unit.uid): return _bad("timed_dragon_buff_invalid_recipient_uid")
		seen[unit.uid] = true
		if not engine._tribe_match(unit,"龙"): continue
		if not Exact._same(unit.get("kind"),"minion") or not engine._valid_unit_state(unit,engine.state.round): return _bad("timed_dragon_buff_invalid_recipient")
		for key in ["attack","health","max_health"]:
			if not _integer(unit.get(key),0 if key == "attack" else 1): return _bad("timed_dragon_buff_invalid_recipient_body")
		if unit.health > unit.max_health or int(unit.attack) > MAX_STAT-4: return _bad("timed_dragon_buff_recipient_overflow")
		# Preserve the proven ordinary _buff host. Dynamic stat layers need their
		# own composition evidence before admission; do not silently flatten them.
		if AuraRuntime.managed(unit) or not unit.get("temporary_buffs",[]).is_empty() or not unit.get("dynamic_spell_enchantments",[]).is_empty() or unit.get("recruit_shop_aura_attack",0) != 0 or unit.get("recruit_shop_aura_health",0) != 0: return _bad("timed_dragon_buff_unsupported_dynamic_recipient")
		if Damage.enabled(engine.room):
			issue = Damage.adjust_error(unit,4,0)
			if not issue.is_empty(): return _bad(issue)
		recipients.append({"uid":unit.uid,"before":unit.duplicate(true)})
	return {"ok":true,"error":"","recipients":recipients}

## All owners, all selected targets, and all overflows precede any EOT write.
static func preflight(engine) -> Dictionary:
	if engine.state.get("phase") not in ["recruit","end_turn"]: return _bad("timed_dragon_buff_invalid_eot_phase")
	var issue: String = saved_error(engine.state,engine.catalog,engine.next_uid)
	if not issue.is_empty(): return _bad(issue)
	var plans: Dictionary = {}
	for player in engine.state.players:
		var result: Dictionary = _prepare(engine,player)
		if not result.ok: return result
		if not result.plan.is_empty(): plans[player.id] = result.plan
	return {"ok":true,"error":"","plans":plans}

static func execute(engine, player: Dictionary, plan: Dictionary) -> Dictionary:
	if engine.state.get("phase") != "end_turn": return _bad("timed_dragon_buff_requires_real_eot")
	var fresh: Dictionary = _prepare(engine,player)
	if not fresh.ok: return fresh
	if fresh.plan.is_empty(): return {"ok":true,"error":"","paid":false}
	if not Exact._same(plan,fresh.plan): return _bad("timed_dragon_buff_stale_eot_plan")
	for entry in plan.entries:
		var repeated: Dictionary=Exact.execute_payload(player,engine.catalog,func(repetition: int,_occurrence: int):return _execute_group(engine,player,plan,entry.source_uid,repetition),1,engine.state.round,str(engine.state.phase))
		if not repeated.ok: return repeated
		if repeated.count!=plan.repeat_count or repeated.completed!=plan.repeat_count: return _bad("timed_dragon_buff_changed_repeat_group")
	# Empty boards still consume each independent owner's duration once.
	var entries: Array=_entries(player[STATE_KEY]).duplicate(true)
	for paid in plan.entries:
		for entry in entries:
			if entry.source_uid==paid.source_uid: entry.last_paid_round=int(engine.state.round)
	_store(player,entries)
	return {"ok":true,"error":"","paid":true,"groups":plan.entries.size()}

static func _execute_group(engine,player: Dictionary,plan: Dictionary,source_uid: String,repetition: int) -> String:
	for action in plan.actions:
		if action.source_uid!=source_uid or action.repetition!=repetition: continue
		var target: Dictionary=HandBuffs.Gains._find(player.board,action.target_uid)
		engine._buff(target,4,0)
		if engine.state.phase=="error": return "timed_dragon_buff_host_buff_failed"
		if not Exact._same(player.board,action.after.board) or not Exact._same(player.hand,action.after.hand) or not Exact._same(player.shop,action.after.shop) or not Exact._same(engine._attack_gain_health_totals,action.after.totals): return "timed_dragon_buff_cumulative_shadow_mismatch"
		engine._log("timed_dragon_buff_application",{"player":player.id,"source_uid":action.source_uid,"target_uid":action.target_uid,"round":engine.state.round,"attack":4,"repetition":repetition+1})
	return ""

static func start_turn(player: Dictionary, current_round: Variant, phase: Variant) -> Dictionary:
	if not Exact._integer(current_round,1,MAX_ROUND) or phase != "recruit" or not Exact._integer(player.get("id"),0,MAX_ROUND): return _bad("timed_dragon_buff_invalid_cleanup_context")
	if player.has("alive") and not player.alive is bool: return _bad("timed_dragon_buff_invalid_alive")
	for key in player:
		if str(key).begins_with("timed_dragon_buff") and key != STATE_KEY: return _bad("timed_dragon_buff_unknown_owner_state")
	if not player.has(STATE_KEY): return {"ok":true,"error":"","expired":0}
	var issue: String = _state_error(player[STATE_KEY],int(player.id),int(current_round),"recruit",true)
	if not issue.is_empty(): return _bad(issue)
	if not player.get("alive",true): return {"ok":true,"error":"","expired":0}
	var retained: Array=[];var expired: int=0
	for entry in _entries(player[STATE_KEY]):
		if entry.expires_round<=current_round:
			if current_round!=entry.expires_round or entry.last_paid_round!=current_round-1: return _bad("timed_dragon_buff_missing_final_round_receipt")
			expired+=1
		else: retained.append(entry.duplicate(true))
	_store(player,retained)
	issue=persistent_error(player,current_round,phase)
	return _bad(issue) if not issue.is_empty() else {"ok":true,"error":"","expired":expired}

static func capture_ghost(player: Dictionary, current_round: Variant, phase: Variant) -> Dictionary:
	var issue: String = persistent_error(player,current_round,phase)
	if not issue.is_empty(): return _bad(issue)
	if phase not in ["recruit","end_turn","combat"]: return _bad("timed_dragon_buff_invalid_capture_phase")
	return {"ok":true,"error":"","snapshot":{"schema_version":VERSION,"owner":int(player.id),"captured_round":int(current_round),"captured_phase":phase,"snapshot_rule":"frozen-elimination-1","owner_state":player.get(STATE_KEY,_empty(int(player.id))).duplicate(true)}}

static func ghost_error(snapshot: Variant, current_round: Variant) -> String:
	if not Exact._integer(current_round,1,MAX_ROUND) or not snapshot is Dictionary or not Exact._keys(snapshot,["schema_version","owner","captured_round","captured_phase","snapshot_rule","owner_state"]): return "timed_dragon_buff_invalid_ghost_shape"
	if not Exact._integer(snapshot.schema_version,VERSION,VERSION) or not Exact._integer(snapshot.owner,0,MAX_ROUND) or not Exact._integer(snapshot.captured_round,1,int(current_round)) or snapshot.captured_phase not in ["recruit","end_turn","combat"] or snapshot.snapshot_rule != "frozen-elimination-1": return "timed_dragon_buff_invalid_ghost_anchor"
	return _state_error(snapshot.owner_state,int(snapshot.owner),int(snapshot.captured_round),str(snapshot.captured_phase),true)

static func saved_error(state: Variant, catalog, next_uid: Variant = null) -> String:
	if not state is Dictionary or not state.get("players") is Array or not state.get("ghosts",[]) is Array: return "timed_dragon_buff_invalid_saved_state"
	var evidence: Dictionary = {}
	var receipt_uids: Dictionary = {}
	for player in state.players:
		var issue: String = persistent_error(player,state.get("round"),state.get("phase"))
		if not issue.is_empty(): return issue
		if player.has(STATE_KEY) and not _entries(player[STATE_KEY]).is_empty():
			if evidence.is_empty(): evidence = validation_evidence()
			issue = catalog_error(catalog,evidence)
			if not issue.is_empty(): return issue
			for entry in _entries(player[STATE_KEY]):
				var uid: String = entry.source_uid
				if next_uid != null and (not _integer(next_uid,1) or int(uid.substr(1)) >= next_uid): return "timed_dragon_buff_cast_uid_in_future"
				if receipt_uids.has(uid): return "timed_dragon_buff_reused_cast_uid"
				receipt_uids[uid] = player.id
	for ghost in state.get("ghosts",[]):
		if not ghost is Dictionary or ghost.has(STATE_KEY): return "timed_dragon_buff_invalid_ghost_state"
		for key in ghost:
			if str(key).begins_with("timed_dragon_buff") and key != SNAPSHOT_KEY: return "timed_dragon_buff_unknown_ghost_state"
		if ghost.has(SNAPSHOT_KEY):
			var issue: String = ghost_error(ghost[SNAPSHOT_KEY],state.get("round"))
			if not issue.is_empty(): return issue
			if not Exact._same(ghost[SNAPSHOT_KEY].owner,ghost.get("id")): return "timed_dragon_buff_ghost_owner_mismatch"
			if not _entries(ghost[SNAPSHOT_KEY].owner_state).is_empty():
				if evidence.is_empty(): evidence = validation_evidence()
				issue = catalog_error(catalog,evidence)
				if not issue.is_empty(): return issue
				for entry in _entries(ghost[SNAPSHOT_KEY].owner_state):
					var uid: String = entry.source_uid
					if next_uid != null and (not _integer(next_uid,1) or int(uid.substr(1)) >= next_uid): return "timed_dragon_buff_ghost_cast_uid_in_future"
	for player in state.players + state.get("ghosts",[]):
		for zone in ["hand","board","shop","mechanism_reward_queue"]:
			if not player.get(zone,[]) is Array: return "timed_dragon_buff_invalid_saved_zone"
			for unit in player.get(zone,[]):
				if unit is Dictionary and receipt_uids.has(unit.get("uid")): return "timed_dragon_buff_consumed_source_still_live"
				if not claimed(unit): continue
				if zone == "board": return "timed_dragon_buff_spell_cannot_be_board_proxy"
				if evidence.is_empty(): evidence = validation_evidence()
				var issue: String = live_error(unit,catalog,evidence)
				if not issue.is_empty(): return issue
	return ""
