extends RefCounted
## Native715 bounded stable-tier surviving-owner result -> both real reward paths.
## Tier1 nonwin, empty domains and competing lifecycle sources remain held.
const Sources=preload("res://core/gladiator_spoils_sources.gd")
const Exact=preload("res://core/board_aura_effects.gd")
const Admission=preload("res://core/gladiator_spoils_admission.gd")
const MinionResource=preload("res://core/exact_tier_minion_resource.gd")
const KIND="gladiator_spoils_win_discover"
static func records(p: Dictionary) -> Array: return p.get(Sources.STATE,{}).get("records",[])
static func request_claimed(request: Dictionary) -> bool: return request.get("kind")==KIND
static func find(p: Dictionary,round_number: int,seed: int) -> Dictionary:
	for record in records(p):
		if record.round==round_number and record.seed==seed: return record
	return {}
static func begin_round(game) -> String:
	if not Sources.enabled(game.room): return ""
	var issue: String=Admission.precombat(game)
	if not issue.is_empty(): return issue
	var tiers: Dictionary={}
	for p in game.state.players:
		if p.get("alive",false): tiers[p.id]=p.tier
	game._gladiator_round_scope={"round":game.state.round,"sequence":game.state.command_sequence,"tiers":tiers,"used":[]}
	return ""
static func issue_result(game,left: Dictionary,right: Dictionary,ghost: bool,result: Dictionary,seed: int) -> String:
	if not Sources.enabled(game.room): return ""
	var scope: Dictionary=game._gladiator_round_scope
	if scope.is_empty() or scope.round!=game.state.round or scope.sequence!=game.state.command_sequence or game.state.phase!="combat" or not game._gladiator_result_scope.is_empty(): return "gladiator_unissued_round_result"
	var players: Array=[left] if ghost else [left,right]
	var demand: Dictionary={}
	for side in range(players.size()):
		var p: Dictionary=players[side]
		if p.id in scope.used or scope.tiers.get(p.id)!=p.tier or result.get("left_player" if side==0 else "right_player")!=p.id: return "gladiator_changed_actual_result_owner"
		var issue: String=Admission.owner(game,p)
		if issue.is_empty(): issue=Admission.candidates(game,p)
		if not issue.is_empty(): return issue
		if result.winner!=side: demand[int(p.tier)-1]=int(demand.get(int(p.tier)-1,0))+1
	for tier in demand:
		var plan: Dictionary=MinionResource.plan(game,int(tier),left)
		if not plan.ok: return str(plan.error)
		if plan.total<int(demand[tier]): return "gladiator_full_nonwin_group_empty_after_prior_claim_held"
	game._gladiator_result_scope={"left":left,"right":right,"ghost":ghost,"result":result,"round":game.state.round,"sequence":game.state.command_sequence,"seed":seed,"tiers":[left.tier,right.tier],"used":false}
	return ""
static func record_result(game) -> String:
	if not Sources.enabled(game.room): return ""
	var cap: Dictionary=game._gladiator_result_scope
	if cap.is_empty() or cap.used or game.state.phase!="combat" or cap.round!=game.state.round or cap.sequence!=game.state.command_sequence: return "gladiator_unissued_actual_result"
	var result: Dictionary=cap.result
	if not Sources.integer(result.get("winner"),-1,1): return "gladiator_invalid_actual_winner"
	var participants: Array=[cap.left] if cap.ghost else [cap.left,cap.right]
	for side in range(participants.size()):
		var p: Dictionary=participants[side]
		if not game.state.players.any(func(owner):return is_same(owner,p)) or not p.get("alive",false) or p.get("health",0)<=0: return "gladiator_survival_precondition_changed"
		if p.tier!=cap.tiers[side] or not find(p,int(cap.round),int(cap.seed)).is_empty(): return "gladiator_tier_changed_or_result_replayed"
	var source_event: int=game.events.size()
	game._log("gladiator_actual_result",{"source_id":Sources.ID,"left":cap.left.id,"right":cap.right.id,"ghost":cap.ghost,"winner":result.winner,"seed":cap.seed,"tiers":cap.tiers.duplicate(true),"sequence":cap.sequence})
	for side in range(participants.size()):
		var p: Dictionary=participants[side]
		var branch: Dictionary=Sources.branch(result.winner,side,p.tier)
		if not branch.ok: return str(branch.error)
		var win: bool=result.winner==side
		var request: Dictionary={"kind":KIND,"source_id":Sources.ID,"owner":p.id,"round":cap.round,"seed":cap.seed,"tier":p.tier}
		var row: Dictionary={"source_id":Sources.ID,"owner":p.id,"round":cap.round,"sequence":cap.sequence,"seed":cap.seed,"side":side,"winner":result.winner,"result_event":source_event,"owner_tier":p.tier,"kind":"discover" if win else "random","status":"queued" if win else "issuing","reason":"","request":request if win else {},"offers":[],"receipt":{},"issue_event":game.events.size()}
		if not p.has(Sources.STATE): p[Sources.STATE]={"records":[]}
		p[Sources.STATE].records.append(row)
		game._log("gladiator_result_obligation",{"player":p.id,"record":row.duplicate(true)})
		if win:
			p.discover_queue.append(request.duplicate(true));game._next_discover(p)
			if game.state.phase=="error" or row.status!="offered": return "gladiator_original_offer_parent_failed"
		else:
			var issue: String=grant_random(game,p,row)
			if not issue.is_empty(): return issue
		game._gladiator_round_scope.used.append(p.id)
	cap.used=true;game._gladiator_result_scope={}
	return ""
static func grant_random(game,p: Dictionary,row: Dictionary) -> String:
	var plan: Dictionary=MinionResource.plan(game,int(row.owner_tier)-1,p)
	if not plan.ok: return str(plan.error)
	if plan.total==0: return "gladiator_true_empty_random_domain_held"
	var outcomes: Dictionary={}
	for item in plan.candidates:
		var projection: Dictionary=Admission.delivery(game,p,str(item.id),"combat")
		if not projection.ok: return str(projection.error)
		outcomes[item.id]=projection
	var unit: Dictionary=MinionResource.draw(game,int(row.owner_tier)-1,p,plan)
	if unit.is_empty(): return "gladiator_original_random_factory_failed"
	var expected: Dictionary=outcomes[unit.card_id]
	var accepted: bool=p.hand.size()<10
	game._add_hand(p,unit)
	if game.state.phase=="error" or p.hand.any(func(body):return is_same(body,unit))!=accepted: return "gladiator_original_random_delivery_failed"
	# No synthetic successful receipt: bind the real allocated entity, whole
	# original hand suffix and retained owner totals to the admitted branch.
	var expected_player: Dictionary=expected.player.duplicate(true)
	expected_player[Sources.STATE]=p[Sources.STATE].duplicate(true)
	if not Exact.same(expected_player,p) or not Exact.same(expected.totals,game._attack_gain_health_totals): return "gladiator_random_actual_suffix_changed"
	row.status="completed"
	row.receipt={"uid":unit.uid,"card_id":unit.card_id,"accepted":accepted,"round":game.state.round,"sequence":game.state.command_sequence,"tier":int(row.owner_tier)-1,"policy":MinionResource.POLICY,"pool_before":plan.pool.duplicate(true),"pool_after":game.pool.duplicate(true),"event_index":game.events.size()}
	game._log("gladiator_random_delivered",{"player":p.id,"result_round":row.round,"seed":row.seed,"receipt":row.receipt.duplicate(true)})
	return ""
static func finish_round(game) -> String:
	if not Sources.enabled(game.room): return ""
	if game._gladiator_round_scope.is_empty() or not game._gladiator_result_scope.is_empty(): return "gladiator_missing_round_completion"
	for owner in game._gladiator_round_scope.tiers:
		if owner not in game._gladiator_round_scope.used: return "gladiator_live_result_obligation_missing"
	game._gladiator_round_scope={}
	return ""
static func prepare(game,p: Dictionary,request: Dictionary) -> String:
	if game.state.phase not in ["recruit","combat"] or not game.state.players.any(func(owner):return is_same(owner,p)) or not p.get("alive",false) or not p.discover.is_empty(): return "gladiator_actual_offer_owner_required"
	var row: Dictionary=find(p,int(request.get("round",-1)),int(request.get("seed",-1)))
	if row.is_empty() or row.status!="queued" or not Exact.same(row.request,request) or request.get("owner")!=p.id or p.tier!=row.owner_tier: return "gladiator_changed_win_obligation_or_tier"
	var issue: String=Sources.closure_error(game.catalog)
	if not issue.is_empty(): return issue
	var domain: Dictionary=game._discover_candidate_plan(p,int(row.owner_tier))
	if not domain.ok: return str(domain.error)
	if domain.candidates.is_empty(): return "gladiator_true_empty_discover_domain_held"
	for id in domain.candidates:
		var projected: Dictionary=Admission.delivery(game,p,str(id),"recruit")
		if not projected.ok: return str(projected.error)
	# Enabled ordinary exact-tier provider, not owned-trinket LOCAL sampling.
	# Its whole candidate domain includes unsupported choices; selected unknown
	# bodies retain the original actual selection guard rather than disappearing.
	if not game._prepare_discover(p,int(row.owner_tier)): return "gladiator_original_discover_prepare_failed"
	row.offers=p.discover.duplicate(true);row.status="offered"
	game._log("gladiator_win_offered",{"player":p.id,"round":row.round,"seed":row.seed,"tier":row.owner_tier,"offers":row.offers.duplicate(true)})
	return ""
static func choice_begin(game,p: Dictionary,index: int) -> Dictionary:
	var offered: Array=records(p).filter(func(row):return row.status=="offered")
	if offered.is_empty(): return {"ok":true,"error":"","active":false}
	if offered.size()!=1 or not game._gladiator_choice_scope.is_empty() or game.state.phase!="recruit" or not game.state.players.any(func(owner):return is_same(owner,p)): return {"ok":false,"error":"gladiator_unbound_or_nested_actual_choice"}
	var row: Dictionary=offered[0]
	if not Exact.same(p.discover,row.offers) or p.tier!=row.owner_tier or index<0 or index>=p.discover.size(): return {"ok":false,"error":"gladiator_changed_original_win_offer"}
	var issue: String=Sources.closure_error(game.catalog)
	if issue.is_empty(): issue=Admission.owner(game,p)
	if not issue.is_empty(): return {"ok":false,"error":issue}
	var projected: Dictionary=Admission.delivery(game,p,str(p.discover[index].id),"recruit")
	if not projected.ok: return projected
	var complete: Dictionary=Admission.choice(game,p,index)
	if not complete.ok: return complete
	var cap: Dictionary={"ok":true,"error":"","active":true,"owner":p,"row":row,"card_id":p.discover[index].id,"stage":"issued","round":game.state.round,"sequence":game.state.command_sequence,"unit":{},"accepted":false,"projection":projected,"complete":complete}
	game._gladiator_choice_scope=cap
	return cap
static func before_hand(game,p: Dictionary,unit: Dictionary) -> String:
	var cap: Dictionary=game._gladiator_choice_scope
	if cap.is_empty(): return ""
	if cap.stage!="issued" or not is_same(cap.owner,p) or cap.round!=game.state.round or cap.sequence!=game.state.command_sequence or unit.get("card_id")!=cap.card_id or unit.get("pool_id")!=cap.card_id or unit.get("pool_count")!=1 or not unit.get("uid") is String: return "gladiator_original_factory_stock_receipt_changed"
	cap.unit=unit;cap.accepted=p.hand.size()<10;cap.stage="delivering"
	return ""
static func after_hand(game,p: Dictionary,unit: Dictionary) -> String:
	var cap: Dictionary=game._gladiator_choice_scope
	if cap.is_empty(): return ""
	if cap.stage!="delivering" or not is_same(cap.owner,p) or not is_same(cap.unit,unit) or game.state.phase!="recruit": return "gladiator_unissued_actual_hand_suffix"
	if p.hand.any(func(body):return is_same(body,unit))!=cap.accepted: return "gladiator_changed_actual_accept_or_burn"
	var expected_player: Dictionary=cap.projection.player.duplicate(true)
	# The source offer still exists at the original hand callback boundary.
	if not Exact.same(expected_player,p) or not Exact.same(cap.projection.totals,game._attack_gain_health_totals): return "gladiator_choice_original_hand_suffix_changed"
	cap.stage="delivered"
	return ""
static func choice_finish(game,p: Dictionary,cap: Dictionary,result: Dictionary) -> String:
	if not cap.get("active",false): return ""
	if not is_same(game._gladiator_choice_scope,cap) or not is_same(cap.owner,p): return "gladiator_unissued_choice_completion"
	if not result.get("ok",false):
		game._gladiator_choice_scope={}
		return ""
	if cap.stage!="delivered" or cap.row.status!="offered" or not p.discover.is_empty(): return "gladiator_original_choice_parent_incomplete"
	if not Exact.same(cap.complete.player,p) or not Exact.same(cap.complete.pool,game.pool) or not Exact.same(cap.complete.spell_pool,game.spell_pool) or cap.complete.next_uid!=game.next_uid or cap.complete.rng_state!=game.rng.state or not Exact.same(cap.complete.totals,game._attack_gain_health_totals): return "gladiator_original_complete_choice_changed"
	cap.row.status="completed";cap.row.offers=[]
	cap.row.receipt={"uid":cap.unit.uid,"card_id":cap.card_id,"accepted":cap.accepted,"round":game.state.round,"sequence":game.state.command_sequence,"event_index":game.events.size()}
	game._log("gladiator_win_delivered",{"player":p.id,"result_round":cap.row.round,"seed":cap.row.seed,"receipt":cap.row.receipt.duplicate(true)})
	cap.stage="completed";game._gladiator_choice_scope={}
	return ""
static func saved_error(state: Dictionary,catalog,events: Array) -> String:
	for p in state.get("players",[]):
		if not p.has(Sources.STATE): continue
		if not p[Sources.STATE] is Dictionary or not p[Sources.STATE].get("records") is Array: return "gladiator_invalid_result_ledger"
		var source_issue: String=Sources.closure_error(catalog)
		if not source_issue.is_empty(): return source_issue
		var seen: Dictionary={}
		for row in records(p):
			if not row is Dictionary or row.get("owner")!=p.id or row.get("source_id")!=Sources.ID or not Sources.integer(row.get("round"),1,int(state.get("round",1))) or not Sources.integer(row.get("sequence"),0,int(state.get("command_sequence",0))) or not Sources.integer(row.get("seed"),0,9223372036854775807) or row.get("side") not in [0,1] or row.get("winner") not in [-1,0,1]: return "gladiator_invalid_result_coordinate"
			var key: String=str(row.round)+":"+str(row.seed)
			if seen.has(key): return "gladiator_duplicate_result_obligation"
			seen[key]=true
			if not Sources.integer(row.get("issue_event"),0,events.size()-1): return "gladiator_missing_actual_result_event"
			var event: Dictionary=events[int(row.issue_event)]
			if event.get("type")!="gladiator_result_obligation" or event.get("player")!=p.id: return "gladiator_changed_actual_result_event"
			for field in ["source_id","owner","round","sequence","seed","side","winner","result_event","owner_tier","kind","request","issue_event"]:
				if not Exact.same(event.get("record",{}).get(field),row.get(field)): return "gladiator_changed_original_obligation"
			if not Sources.integer(row.get("result_event"),0,int(row.issue_event)-1): return "gladiator_missing_result_source_receipt"
			var result_event: Dictionary=events[int(row.result_event)]
			if result_event.get("type")!="gladiator_actual_result" or result_event.get("source_id")!=Sources.ID or result_event.get("winner")!=row.winner or result_event.get("seed")!=row.seed or result_event.get("round")!=row.round or result_event.get("sequence")!=row.sequence or result_event.get("left" if row.side==0 else "right")!=p.id or not result_event.get("tiers") is Array or result_event.tiers.size()!=2 or result_event.tiers[int(row.side)]!=row.owner_tier or (row.side==1 and result_event.get("ghost",true)): return "gladiator_changed_actual_result_source"
			var actual_matches: Array=events.filter(func(e):return e.get("type")=="combat_result" and e.get("round")==row.round and e.get("seed")==row.seed and e.get("left")==result_event.left and e.get("right")==result_event.right)
			if actual_matches.size()!=1: return "gladiator_missing_original_terminal_result"
			if row.winner!=row.side:
				var receipt: Dictionary=row.get("receipt",{})
				if row.status!="completed" or row.owner_tier<2 or not row.offers.is_empty() or receipt.get("tier")!=int(row.owner_tier)-1 or receipt.get("policy")!=MinionResource.POLICY or not receipt.get("uid") is String or not receipt.get("accepted") is bool or not Sources.integer(receipt.get("event_index"),0,events.size()-1): return "gladiator_invalid_random_delivery_receipt"
				var delivered: Dictionary=events[int(receipt.event_index)]
				if delivered.get("type")!="gladiator_random_delivered" or delivered.get("player")!=p.id or delivered.get("result_round")!=row.round or delivered.get("seed")!=row.seed or not Exact.same(delivered.get("receipt"),receipt): return "gladiator_random_delivery_without_actual_writer"
				var expected_stock: Dictionary=receipt.get("pool_before",{}).duplicate(true)
				if int(expected_stock.get(receipt.card_id,0))<1: return "gladiator_random_claim_without_stock"
				if receipt.accepted: expected_stock[receipt.card_id]-=1
				if not Exact.same(expected_stock,receipt.get("pool_after")): return "gladiator_random_stock_receipt_changed"
				continue
			if row.status=="queued":
				if p.get("discover_queue",[]).filter(func(request):return Exact.same(request,row.request)).size()!=1 or not row.offers.is_empty() or not row.receipt.is_empty(): return "gladiator_missing_pending_win_request"
			elif row.status=="offered":
				if row.offers.is_empty() or row.offers.size()>3 or not Exact.same(row.offers,p.discover) or not row.receipt.is_empty(): return "gladiator_changed_saved_win_offer"
				var offers: Array=events.filter(func(e):return e.get("type")=="gladiator_win_offered" and e.get("player")==p.id and e.get("round")==row.round and e.get("seed")==row.seed)
				if offers.size()!=1 or not Exact.same(offers[0].get("offers"),row.offers): return "gladiator_offer_without_actual_provider_event"
			elif row.status=="completed":
				var receipt: Dictionary=row.receipt
				if not row.offers.is_empty() or not receipt.get("uid") is String or not receipt.get("accepted") is bool or not Sources.integer(receipt.get("event_index"),0,events.size()-1): return "gladiator_invalid_delivery_receipt"
				var delivered: Dictionary=events[int(receipt.event_index)]
				if delivered.get("type")!="gladiator_win_delivered" or delivered.get("player")!=p.id or delivered.get("result_round")!=row.round or delivered.get("seed")!=row.seed or not Exact.same(delivered.get("receipt"),receipt): return "gladiator_delivery_without_original_choice"
			else: return "gladiator_unknown_persistent_stage"
	return ""

static func room_error(room: Dictionary,catalog) -> String:
	if not Sources.enabled(room): return ""
	var issue: String=Sources.closure_error(catalog)
	if not issue.is_empty(): return issue
	if Sources.active_ids(room,"enabled_anomalies")!=[Sources.ID]: return "gladiator_other_anomaly_composition_held"
	return ""
static func state_error(game) -> String:
	if not Sources.enabled(game.room):
		for p in game.state.get("players",[]):
			if p.has(Sources.STATE): return "gladiator_saved_ledger_without_room_source"
	return saved_error(game.state,game.catalog,game.events)
