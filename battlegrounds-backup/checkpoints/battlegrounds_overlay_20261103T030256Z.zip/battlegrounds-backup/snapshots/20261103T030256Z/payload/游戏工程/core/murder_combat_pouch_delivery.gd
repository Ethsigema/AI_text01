extends RefCounted
## Actual terminal-combat independent123 slot delivery; no recruit/EOT authority.
const Exact=preload("res://core/board_aura_effects.gd")
static func fail(issue: String) -> Dictionary: return {"ok":false,"error":issue}
static func prepare(engine,result: Dictionary,participants: Array,sides: Array,plans: Dictionary,journal: Dictionary) -> Dictionary:
	var records: Array=[]
	for side in sides:
		var p: Dictionary=participants[side]
		var plan: Dictionary=plans[side]
		if not plan.get("slots",[]).any(func(staged):return staged.projection.get("completed_now",false)): continue
		if engine.state.phase!="combat" or not engine.state.players.any(func(owner):return is_same(owner,p)) or not p.get("alive",false) or result.get("left_player" if side==0 else "right_player")!=p.id or plan.get("owner")!=p.id or not plan.get("ok",false): return fail("murder_combat_pouch_actual_owner_required")
		var issue: String=engine.MurderWeapon.MinionPlay.Refresh.lifecycle_owner_error(engine,p)
		if issue.is_empty(): issue=engine.MurderWeapon.InitialOwner.Pouch.Admission.admission(engine,p)
		if not issue.is_empty(): return fail(issue)
		for staged in plan.slots:
			var row: Dictionary=engine.Aristocrat.row_for(p,str(staged.source_uid))
			if not Exact.same(row,staged.before) or row.get("status")!="active" or row.get("quest",{}).get("id")!=engine.MurderWeapon.Sources.ID or row.get("pouch_uid","")!="" or row.get("accepted",false): return fail("murder_combat_pouch_changed_original_slot")
			var receipt: Dictionary=staged.receipt
			if receipt.get("round")!=engine.state.round or receipt.get("side")!=side or receipt.get("seed")!=journal.seed or receipt.get("end_index")!=journal.combat_end_index or not Exact.same(receipt.get("counters"),journal.totals[side]): return fail("murder_combat_pouch_changed_terminal_receipt")
			if not staged.projection.get("completed_now",false): continue
			issue=engine.MurderWeapon.MinionPlay.Refresh.Combat.projection_error(engine,p,side,staged.projection,journal,true)
			if not issue.is_empty(): return fail(issue)
			records.append({"owner":p,"row":row,"staged":staged,"side":side,"plan":plan})
	return {"ok":true,"error":"","records":records,"cursor":0,"round":engine.state.round,"sequence":engine.state.command_sequence,"seed":journal.seed,"pending":{}}
static func begin(engine,p: Dictionary,row: Dictionary) -> Dictionary:
	var cap: Dictionary=engine._murder_combat_pouch_scope
	if cap.is_empty(): return {"ok":true,"error":"","active":false}
	if engine.state.phase!="combat" or cap.round!=engine.state.round or cap.sequence!=engine.state.command_sequence or cap.cursor>=cap.records.size() or not cap.pending.is_empty(): return fail("murder_combat_pouch_unissued_or_nested_delivery")
	var record: Dictionary=cap.records[cap.cursor]
	if not is_same(record.owner,p) or not is_same(record.row,row): return fail("murder_combat_pouch_original_slot_order_changed")
	# Original commit_combat stages every slot of this owner before any delivery.
	for staged in record.plan.slots:
		var actual: Dictionary=engine.Aristocrat.row_for(p,str(staged.source_uid))
		var projection: Dictionary=staged.projection
		if not Exact.same(actual.quest,projection.active_quest) or not Exact.same(actual.combat_stats,projection.stats) or actual.progress!=projection.quest_progress[str(actual.quest.id)] or actual.status!=("complete" if actual.quest.complete else "active") or actual.combat_receipts.is_empty() or not Exact.same(actual.combat_receipts.back(),staged.receipt): return fail("murder_combat_pouch_original_all_slot_stage_changed")
	if row.get("pouch_uid","")!="" or row.get("accepted",false): return fail("murder_combat_pouch_replayed_delivery")
	var card: Dictionary=engine.catalog.get_card(str(row.pouch_id))
	var uid: String="u"+str(engine.next_uid)
	var body: Dictionary=engine._factory_unit(card,uid)
	if body.is_empty() or body.get("kind")!="spell" or body.get("pool_count",0)!=0 or (not Exact.integer(engine.next_uid,1) or engine.next_uid>9007199254740990): return fail("murder_combat_pouch_original_factory_required")
	for owner in engine.state.players:
		if (owner.hand+owner.board+owner.shop).any(func(unit):return unit.get("uid")==uid): return fail("murder_combat_pouch_factory_uid_collision")
	var ticket: Dictionary={"ok":true,"error":"","active":true,"cap":cap,"record":record,"owner":p,"row":row,"body":body,"uid":uid,"next_uid":engine.next_uid,"hand":p.hand.duplicate(true),"accepted":p.hand.size()<10,"gold":p.gold,"used":false}
	cap.pending=ticket
	return ticket
static func finish(engine,p: Dictionary,row: Dictionary,ticket: Dictionary) -> String:
	if not ticket.get("active",false): return ""
	var cap: Dictionary=engine._murder_combat_pouch_scope
	if cap.is_empty() or not is_same(ticket.get("cap"),cap) or not is_same(cap.pending,ticket) or ticket.used or not is_same(ticket.owner,p) or not is_same(ticket.row,row) or engine.state.phase!="combat" or cap.round!=engine.state.round or cap.sequence!=engine.state.command_sequence: return "murder_combat_pouch_unissued_delivery_suffix"
	if row.pouch_uid!=ticket.uid or row.accepted!=ticket.accepted or engine.next_uid!=ticket.next_uid+1 or p.gold!=ticket.gold: return "murder_combat_pouch_actual_factory_or_currency_changed"
	var expected: Array=ticket.hand.duplicate(true)
	if ticket.accepted: expected.append(ticket.body)
	if not Exact.same(p.hand,expected): return "murder_combat_pouch_actual_accepted_or_burn_changed"
	var deliveries: Array=engine.events.filter(func(event):return event.get("type")=="aristocrat_actual_quest_completed" and event.get("player")==p.id and event.get("source_uid")==row.source_uid)
	if deliveries.size()!=1 or deliveries[0].get("pouch_uid")!=ticket.uid or deliveries[0].get("accepted")!=ticket.accepted or not Exact.same(deliveries[0].get("completed_at"),row.quest.completed_at): return "murder_combat_pouch_original_delivery_event_missing"
	ticket.used=true
	cap.pending={}
	cap.cursor+=1
	# Documentary only: original slot, terminal receipt, and actual delivery
	# event remain the durable authority. Restore never replays this writer.
	engine._log("murder_actual_terminal_pouch_delivery",{"player":p.id,"source_uid":row.source_uid,"pouch_uid":row.pouch_uid,"accepted":row.accepted,"side":ticket.record.side,"seed":cap.seed,"round":cap.round,"sequence":cap.sequence,"completed_at":row.quest.completed_at.duplicate(true)})
	return ""
