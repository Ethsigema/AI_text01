extends RefCounted
## Actual paid targeted Hero use, then same-slot higher-tier stock replacement.
## Selection is not minion acquisition or a Discover payoff event.
const Sources=preload("res://core/galakrond_replace_sources.gd")
const ShopEvolve=preload("res://core/shop_evolve_host.gd")
const ShopProjection=preload("res://core/consume_observer_host.gd")
const Recruit=preload("res://core/recruit_extensions.gd")
const Factory=preload("res://core/gold_threshold_sources.gd")
const Actual=preload("res://core/duelist_refresh.gd")
const KEY: String="native_galakrond_replace_discover"
const KIND: String="native_galakrond_replace_choice"
const CAUSE: String="native_galakrond_replace"
const POLICY: String="native_plus_one_tier_uniform_distinct_same_slot_real_stock_v1"
static func fail(issue: String) -> Dictionary: return {"ok":false,"error":issue}
static func fields(value: Variant,keys: Array) -> bool:
	return value is Dictionary and value.size()==keys.size() and keys.all(func(key):return value.has(key))
static func request_claimed(request: Variant) -> bool: return request is Dictionary and request.get("kind")==KIND
static func request_error(request: Variant) -> String:
	if not fields(request,["kind","source_id","use_id","owner","round","sequence","policy"]) or request.kind!=KIND or request.source_id!=Sources.HERO or not Sources.uid(request.use_id) or not Sources.integer(request.owner,0,7) or not Sources.integer(request.round,1) or not Sources.integer(request.sequence,0) or request.policy!=POLICY: return "galakrond_replace_invalid_request"
	return "" if request.use_id=="galakrond:%s:%s:%s"%[int(request.owner),int(request.round),int(request.sequence)] else "galakrond_replace_changed_use_identity"
static func child_error(catalog,id: String) -> String:
	var card: Dictionary=catalog.get_card(id)
	if card.is_empty() or card.get("id")!=id or card.get("kind")!="minion" or card.get("supported")!=true: return "galakrond_replace_unimplemented_identity_partial:"+id
	if card.get("is_golden",false): return "galakrond_replace_golden_identity_partial:"+id
	for flag in ["excluded","duos_exclusive","requires_teammate_effect","stats_conflict"]:
		if card.get(flag,false): return "galakrond_replace_candidate_data_gate:"+id
	return "galakrond_replace_candidate_data_gate:"+id if card.get("latest_validation",{}).get("data_gate",false) else ""
static func _target_error(engine,player: Dictionary,target: int) -> String:
	if target<0 or target>=player.shop.size(): return "galakrond_replace_choose_shop_minion"
	var unit: Dictionary=player.shop[target]
	if unit.get("kind")!="minion" or unit.get("golden")!=false: return "galakrond_replace_normal_minion_required_partial"
	if not Sources.integer(unit.get("tier"),1,5): return "galakrond_replace_tier_six_to_seven_partial"
	if player.get("frozen",false) or unit.get("individually_frozen",false): return "galakrond_replace_frozen_target_partial"
	if ShopEvolve.TierPolicy.exact_tier_enabled(engine.room,engine.catalog): return "galakrond_replace_exact_tier_priority_partial"
	if not engine._valid_unit_state(unit,int(engine.state.round)): return "galakrond_replace_invalid_target_state"
	var card: Dictionary=engine.catalog.get_card(str(unit.card_id))
	if card.get("supported")!=true or card.get("kind")!="minion" or card.get("tier")!=unit.tier: return "galakrond_replace_changed_native_target"
	var seen: Array=[]
	for owner in engine.state.players:
		for zone in ["board","hand","shop","mechanism_reward_queue"]:
			for held in owner.get(zone,[]):
				if not held is Dictionary or not Sources.uid(held.get("uid")) or held.uid in seen: return "galakrond_replace_ambiguous_entity_identity"
				seen.append(held.uid)
	var returned: Dictionary=engine.pool.duplicate(true)
	for part in engine.Magnetic.pool_returns(unit):
		if part.get("pool_kind")!="minion" or part.get("pool_id")!=unit.card_id or part.get("pool_count")!=1 or not returned.has(part.pool_id) or not Sources.integer(returned[part.pool_id],0,2147483646): return "galakrond_replace_old_stock_return_partial"
		returned[part.pool_id]+=1
	return ""
static func _factory(engine,card: Dictionary,uid: String) -> Dictionary:
	var unit: Dictionary=Factory.factory_projection(card,uid,int(engine.state.round))
	# Same pure native initializers as actual Game._unit; no UID allocation or RNG.
	engine.TurnGolden.Sources.initialize(unit)
	engine.TradeQuotas.Sources.initialize(unit,int(engine.state.round))
	engine.Zesty.Sources.initialize(unit)
	engine.SaleCycles.Sources.initialize(unit)
	engine.HandAcquisition.Sources.initialize(unit)
	engine.PurchaseStats.Sources.initialize(unit,int(engine.state.round))
	unit.pool_id=card.id;unit.pool_kind="minion";unit.pool_count=1
	return unit
static func _preview(engine,player: Dictionary,target: int,id: String,uid: String) -> Dictionary:
	var card: Dictionary=engine.catalog.get_card(id)
	var unit: Dictionary=_factory(engine,card,uid)
	var shadow: Dictionary=ShopProjection.StatPlan._state(engine,player)
	var issue: String=engine.PermanentTribe.receive(shadow.player,unit)
	if issue.is_empty(): issue=engine.GlobalCards.receive(shadow.player,unit,"shop")
	if not issue.is_empty(): return fail(issue)
	shadow.player.shop[target]=unit
	issue=ShopProjection._project_shop(engine,shadow,0,0)
	if not issue.is_empty(): return fail(issue)
	return {"ok":true,"error":"","expected":ShopProjection.view(shadow.player,shadow.totals)}
static func domain(engine,player: Dictionary,target: int) -> Dictionary:
	var issue: String=_target_error(engine,player,target)
	if not issue.is_empty(): return fail(issue)
	var original: Dictionary=player.shop[target]
	var tier: int=int(original.tier)+1
	var choice_plan: Dictionary=ShopEvolve._choices(engine,{"minion":engine.pool,"spell":engine.spell_pool},"minion",tier,"",player,player)
	if not choice_plan.ok: return fail(str(choice_plan.error))
	var choices: Array=choice_plan.choices
	if choices.is_empty(): return fail("galakrond_replace_empty_next_tier_partial")
	var candidates: Array=[]
	for entry in choices:
		var id: String=str(entry.id)
		issue=child_error(engine.catalog,id)
		if not issue.is_empty(): return fail(issue)
		var preview: Dictionary=_preview(engine,player,target,id,"galakrond_preview")
		if not preview.ok: return preview
		if engine.VashjResources.has_listener(player):
			var child: Dictionary=engine.VashjResources.Sources.appearing_child(engine.catalog,_factory(engine,engine.catalog.get_card(id),"galakrond_appearance"))
			if not child.ok: return child
		candidates.append(id)
	return {"ok":true,"error":"","domain":{"round":engine.state.round,"owner":player.id,"target_index":target,"target_before":original.duplicate(true),"tier":tier,"candidates":candidates}}
static func _request_owner_error(player: Dictionary,request: Variant) -> String:
	var issue: String=request_error(request)
	if not issue.is_empty(): return issue
	if request.owner!=player.get("id") or player.get("hero_id")!=Sources.HERO: return "galakrond_replace_wrong_owner"
	var ledger: Variant=player.get(KEY,{})
	if not ledger is Dictionary: return "galakrond_replace_invalid_ledger"
	var record: Variant=ledger.get(request.use_id)
	if not fields(record,["request","domain","offers","status"]) or not Sources.same(record.request,request) or record.status!="pending": return "galakrond_replace_unissued_or_replayed_request"
	return ""
static func _domain_error(value: Variant,round_number: int,catalog,owner: int) -> String:
	if not fields(value,["round","owner","target_index","target_before","tier","candidates"]) or value.round!=round_number or value.owner!=owner or not Sources.integer(value.target_index,0,6) or not value.target_before is Dictionary or not Sources.uid(value.target_before.get("uid")) or value.target_before.get("kind")!="minion" or value.target_before.get("golden")!=false or not Sources.integer(value.target_before.get("tier"),1,5) or value.tier!=int(value.target_before.tier)+1: return "galakrond_replace_invalid_domain_receipt"
	if not value.candidates is Array or value.candidates.is_empty(): return "galakrond_replace_invalid_candidate_receipt"
	var seen: Array=[]
	for id in value.candidates:
		if not id is String or id in seen: return "galakrond_replace_duplicate_candidate"
		seen.append(id)
		var issue: String=child_error(catalog,id)
		if not issue.is_empty(): return issue
		var card: Dictionary=catalog.get_card(id)
		if card.get("tier")!=value.tier or card.get("pool_supported")!=true: return "galakrond_replace_changed_candidate_tier"
	return ""
static func _pending_target(player: Dictionary,record: Dictionary) -> String:
	var index: int=int(record.domain.target_index)
	if index>=player.shop.size(): return "galakrond_replace_pending_target_changed_partial"
	var current: Dictionary=player.shop[index];var original: Dictionary=record.domain.target_before
	for key in ["uid","card_id","kind","tier","golden"]:
		if not Sources.same(current.get(key),original.get(key)): return "galakrond_replace_pending_target_changed_partial"
	# Subsequent legitimate stat buffs do not change this same replacement identity.
	return ""
static func _actual(engine,player: Dictionary) -> bool:
	return Actual._actual_game_host(engine) and engine.state.phase=="recruit" and player.get("alive",false) and engine.state.players.any(func(owner):return is_same(owner,player))
static func power_error(engine,player: Dictionary,target: int=-1,zone: String="shop") -> String:
	if player.get("hero_id")!=Sources.HERO: return ""
	if not _actual(engine,player) or zone!="shop": return "galakrond_replace_actual_shop_target_required"
	var issue: String=Sources.closure_error(engine.catalog)
	if issue.is_empty(): issue=saved_error(engine.state,engine.room,engine.catalog,engine.last_combats,engine.events)
	if not issue.is_empty(): return issue
	if not player.discover.is_empty() or not player.discover_queue.is_empty(): return "galakrond_replace_waiting_choice"
	if player.get(KEY,{}).size()>=4096: return "galakrond_replace_history_budget_partial"
	return str(domain(engine,player,target).get("error",""))
static func prepare_power(engine,player: Dictionary,target: int,zone: String) -> Dictionary:
	if player.get("hero_id")!=Sources.HERO: return {"ok":true,"error":"","active":false}
	var issue: String=power_error(engine,player,target,zone)
	if not issue.is_empty(): return fail(issue)
	var command: Dictionary=engine._bounty_spend_command
	if not engine._galakrond_replace_power_context.is_empty() or not is_same(command.get("owner"),player) or command.get("action")!="hero_power" or command.get("round")!=engine.state.round or command.get("sequence")!=engine.state.command_sequence: return fail("galakrond_replace_actual_hero_command_required")
	for key in ["hero_uses","hero_total_uses"]:
		if not Sources.integer(player.get(key,0),0,2147483646): return fail("galakrond_replace_usage_overflow")
	var captured: Dictionary=domain(engine,player,target)
	if not captured.ok: return captured
	return {"ok":true,"error":"","active":true,"owner":player,"command":command,"domain":captured.domain,"round":engine.state.round,"sequence":engine.state.command_sequence,"cost":engine.hero_power_cost(player),"gold":player.gold,"uses":int(player.get("hero_uses",0)),"total":int(player.get("hero_total_uses",0)),"target":target,"stage":"prepared"}
static func _power_ticket(engine,player: Dictionary,ticket: Dictionary,stage: String) -> String:
	if not is_same(engine._galakrond_replace_power_context,ticket) or not is_same(ticket.get("owner"),player) or not is_same(ticket.get("command"),engine._bounty_spend_command) or ticket.get("stage")!=stage: return "galakrond_replace_unissued_or_replayed_power"
	if not _actual(engine,player) or player.hero_id!=Sources.HERO or ticket.round!=engine.state.round or ticket.sequence!=engine.state.command_sequence: return "galakrond_replace_stale_power_owner"
	return Sources.closure_error(engine.catalog)
static func mark_paid(engine,player: Dictionary,cost: int) -> String:
	if engine._galakrond_replace_power_context.is_empty(): return ""
	var ticket: Dictionary=engine._galakrond_replace_power_context
	var issue: String=_power_ticket(engine,player,ticket,"prepared")
	if not issue.is_empty(): return issue
	if cost!=ticket.cost or player.gold!=int(ticket.gold)-cost or player.get("hero_uses",0)!=ticket.uses or player.get("hero_total_uses",0)!=ticket.total: return "galakrond_replace_actual_payment_required"
	ticket.stage="paid"
	return ""
static func commit_power(engine,player: Dictionary,ticket: Dictionary) -> Dictionary:
	var issue: String=_power_ticket(engine,player,ticket,"paid")
	if not issue.is_empty(): return fail(issue)
	if int(player.get("hero_uses",0))!=int(ticket.uses)+1 or int(player.get("hero_total_uses",0))!=int(ticket.total)+1 or not player.discover.is_empty() or not player.discover_queue.is_empty(): return fail("galakrond_replace_actual_use_commit_required")
	var captured: Dictionary=domain(engine,player,int(ticket.target))
	if not captured.ok: return captured
	if not Sources.same(ticket.domain.target_before,captured.domain.target_before): return fail("galakrond_replace_paid_warband_changed")
	var use_id: String="galakrond:%s:%s:%s"%[player.id,engine.state.round,engine.state.command_sequence]
	if player.get(KEY,{}).has(use_id): return fail("galakrond_replace_duplicate_use")
	var request: Dictionary={"kind":KIND,"source_id":Sources.HERO,"use_id":use_id,"owner":player.id,"round":engine.state.round,"sequence":engine.state.command_sequence,"policy":POLICY}
	if not player.has(KEY): player[KEY]={}
	player[KEY][use_id]={"request":request.duplicate(true),"domain":captured.domain.duplicate(true),"offers":[],"status":"pending"}
	ticket.stage="committing"
	player.discover_queue.append(request)
	engine._log("galakrond_replace_requested",{"player":player.id,"request":request.duplicate(true),"domain":captured.domain.duplicate(true),"policy":POLICY})
	engine._next_discover(player)
	if engine.state.phase=="error": return fail("galakrond_replace_actual_prepare_failed")
	ticket.stage="completed"
	return {"ok":true,"error":""}
static func prepare(engine,player: Dictionary,request: Dictionary) -> String:
	var issue: String=_request_owner_error(player,request)
	if not issue.is_empty(): return issue
	if not player.discover.is_empty(): return "galakrond_replace_existing_choice"
	var record: Dictionary=player[KEY][request.use_id]
	if not record.offers.is_empty(): return "galakrond_replace_offer_replayed"
	issue=_pending_target(player,record)
	if not issue.is_empty(): return issue
	issue=_domain_error(record.domain,int(request.round),engine.catalog,int(player.id))
	if not issue.is_empty(): return issue
	var candidates: Array=record.domain.candidates.duplicate();var offers: Array=[]
	for _pick in range(mini(3,candidates.size())):
		var index: int=engine._random(candidates.size(),"galakrond_replace_uniform_distinct_identity")
		var id: String=str(candidates[index]);candidates.remove_at(index)
		var choice: Dictionary=engine.catalog.get_card(id).duplicate(true)
		choice.choice_kind=KIND;choice.replace_request=request.duplicate(true);offers.append(choice)
	record.offers=offers.map(func(choice):return choice.id);player.discover=offers
	engine._log("galakrond_replace_offered",{"player":player.id,"request":request.duplicate(true),"offers":record.offers.duplicate(),"policy":POLICY})
	return ""
static func offer_error(player: Dictionary,choice: Dictionary,catalog) -> String:
	if choice.get("choice_kind")!=KIND: return "galakrond_replace_wrong_offer_kind"
	var request: Variant=choice.get("replace_request")
	var issue: String=_request_owner_error(player,request)
	if not issue.is_empty(): return issue
	var record: Dictionary=player[KEY][request.use_id]
	if choice.get("id") not in record.offers or choice.get("id") not in record.domain.candidates: return "galakrond_replace_not_issued_offer"
	issue=child_error(catalog,str(choice.id))
	if not issue.is_empty(): return issue
	var expected: Dictionary=catalog.get_card(str(choice.id)).duplicate(true)
	expected.choice_kind=KIND;expected.replace_request=request.duplicate(true)
	return "" if Sources.same(expected,choice) else "galakrond_replace_changed_complete_offer"
static func appearance_error(engine,player: Dictionary) -> String:
	var ticket: Dictionary=engine._galakrond_replace_choice_context
	if not is_same(ticket.get("owner"),player) or ticket.get("stage")!="commit" or ticket.get("round")!=engine.state.round or ticket.get("sequence")!=engine.state.command_sequence: return "galakrond_replace_unissued_appearance_capability"
	return Sources.closure_error(engine.catalog)
static func choose(engine,player: Dictionary,index: int) -> Dictionary:
	if not _actual(engine,player) or not engine._galakrond_replace_choice_context.is_empty(): return engine._fail("galakrond_replace_actual_choice_required")
	engine._galakrond_replace_choice_context={"owner":player,"index":index,"round":engine.state.round,"sequence":engine.state.command_sequence,"stage":"prepared"}
	var outcome: Dictionary=_choose(engine,player,index)
	var ticket: Dictionary=engine._galakrond_replace_choice_context
	if ticket.has("appearance") and is_same(engine._shop_spellcraft_appearance_context,ticket.appearance): engine._shop_spellcraft_appearance_context={}
	engine._galakrond_replace_choice_context={}
	return outcome
static func _choose(engine,player: Dictionary,index: int) -> Dictionary:
	if index<0 or index>=player.discover.size(): return engine._fail("galakrond_replace_choice_index")
	var choice: Dictionary=player.discover[index]
	var issue: String=offer_error(player,choice,engine.catalog)
	if not issue.is_empty(): return engine._fail(issue)
	var request: Dictionary=choice.replace_request
	var record: Dictionary=player[KEY][request.use_id]
	issue=_pending_target(player,record)
	if issue.is_empty(): issue=_target_error(engine,player,int(record.domain.target_index))
	if not issue.is_empty(): return engine._fail(issue)
	if str(choice.id) not in engine._enabled("minions") or not Sources.integer(engine.pool.get(choice.id),1): return engine._fail("galakrond_replace_selected_stock_unavailable")
	if not Sources.integer(engine.next_uid,1,2147483646): return engine._fail("galakrond_replace_uid_limit")
	var target: int=int(record.domain.target_index)
	var projected: Dictionary=_preview(engine,player,target,str(choice.id),"u"+str(engine.next_uid))
	if not projected.ok: return engine._fail(str(projected.error))
	var before: Dictionary=ShopProjection.view(player,engine._attack_gain_health_totals)
	var pools: Dictionary={"minion":engine.pool.duplicate(true),"spell":engine.spell_pool.duplicate(true)}
	var original: Dictionary=player.shop[target]
	var returns: Array=engine.Magnetic.pool_returns(original)
	var expected_pool: Dictionary=engine.pool.duplicate(true)
	for part in returns: expected_pool[part.pool_id]+=int(part.pool_count)
	expected_pool[choice.id]-=1
	var unit: Dictionary=engine._unit(engine.catalog.get_card(str(choice.id)))
	if unit.is_empty(): return engine._fail("galakrond_replace_actual_factory_rejected")
	unit.pool_id=choice.id;unit.pool_kind="minion";unit.pool_count=1
	if not Sources.same(unit,_factory(engine,engine.catalog.get_card(str(choice.id)),str(unit.uid))): return engine._fail("galakrond_replace_factory_projection_changed_partial")
	if not engine._receive_permanent(player,unit,"shop"): return engine._fail("galakrond_replace_owner_projection_failed")
	if not Sources.same(before,ShopProjection.view(player,engine._attack_gain_health_totals)) or not Sources.same(pools.minion,engine.pool) or not Sources.same(pools.spell,engine.spell_pool): return engine._fail("galakrond_replace_changed_commit_inputs")
	var ticket: Dictionary=engine._galakrond_replace_choice_context
	ticket.stage="commit"
	var appearance: Dictionary=engine.VashjResources.begin_appearance(engine,player,CAUSE)
	if not appearance.ok: return engine._fail(str(appearance.error))
	ticket.appearance=appearance
	engine._return_unit(original)
	engine.pool[choice.id]-=1
	player.shop[target]=unit
	Recruit.refresh_shop_modifiers(engine,player)
	if engine.state.phase=="error": return engine._fail("galakrond_replace_actual_shop_modifiers_failed")
	if not Sources.same(ShopProjection.view(player,engine._attack_gain_health_totals),projected.expected) or not Sources.same(engine.pool,expected_pool) or not Sources.same(engine.spell_pool,pools.spell): return engine._fail("galakrond_replace_actual_replacement_mismatch")
	issue=engine.VashjResources.finish_appearance(engine,player,appearance)
	if not issue.is_empty(): return engine._fail(issue)
	record.status="completed";record.offers=[];ticket.stage="completed"
	engine._log("galakrond_replace_selected",{"player":player.id,"request":request.duplicate(true),"old_uid":original.uid,"old_id":original.card_id,"card_id":unit.card_id,"uid":unit.uid,"slot":target,"tier":unit.tier,"pool_count":1,"refresh":false,"buy":false,"minion_discover":false,"policy":POLICY})
	player.discover.clear();engine._next_discover(player)
	return engine._ok()
static func saved_error(state: Dictionary,_room: Dictionary,catalog,_last_combats: Array,events: Array) -> String:
	var global_seen: Array=[]
	var hero_issue: String=""
	for player in state.get("players",[]):
		if player.get("hero_id")==Sources.HERO:
			if player.has("hero_power_id") and player.hero_power_id!=Sources.POWER: return "galakrond_replace_hero_power_migration_partial"
			hero_issue=Sources.closure_error(catalog)
			if not hero_issue.is_empty(): return hero_issue
		elif player.has(KEY): return "galakrond_replace_changed_hero_history_partial"
		var ledger: Variant=player.get(KEY,{})
		if not ledger is Dictionary: return "galakrond_replace_invalid_saved_ledger"
		if ledger.size()>4096: return "galakrond_replace_history_budget_partial"
		if player.get("hero_id")==Sources.HERO and (not Sources.integer(player.get("hero_total_uses",0)) or ledger.size()!=int(player.get("hero_total_uses",0))): return "galakrond_replace_legacy_use_history_partial"
		var waiting: Dictionary={}
		for request in player.get("discover_queue",[]):
			if not request_claimed(request): continue
			var issue: String=_request_owner_error(player,request)
			if not issue.is_empty(): return issue
			if waiting.has(request.use_id): return "galakrond_replace_duplicate_pending"
			waiting[request.use_id]=[]
		var offers: Array=player.get("discover",[]).filter(func(choice):return choice.get("choice_kind")==KIND)
		if not offers.is_empty():
			if offers.size()!=player.discover.size() or offers.size()>3: return "galakrond_replace_mixed_active_group"
			var active_uid: String=str(offers[0].get("replace_request",{}).get("use_id",""))
			if waiting.has(active_uid): return "galakrond_replace_active_request_requeued"
			var ids: Array=[]
			for choice in offers:
				var issue: String=offer_error(player,choice,catalog)
				if not issue.is_empty(): return issue
				if choice.id in ids or not Sources.same(choice.replace_request,offers[0].replace_request): return "galakrond_replace_mixed_request_or_duplicate_offer"
				ids.append(choice.id)
			waiting[active_uid]=ids
		for uid in ledger:
			var record: Variant=ledger[uid]
			if not Sources.uid(uid) or uid in global_seen or not fields(record,["request","domain","offers","status"]) or not record.offers is Array or record.status not in ["pending","completed","cancelled"]: return "galakrond_replace_changed_saved_record"
			global_seen.append(uid)
			var issue: String=request_error(record.request)
			if issue.is_empty(): issue=Sources.closure_error(catalog)
			if not issue.is_empty(): return issue
			if record.request.use_id!=uid or record.request.owner!=player.id or int(record.request.round)>int(state.round) or int(record.request.sequence)>int(state.command_sequence): return "galakrond_replace_saved_owner_or_future_cast"
			issue=_domain_error(record.domain,int(record.request.round),catalog,int(player.id))
			if not issue.is_empty(): return issue
			var receipts: Array=events.filter(func(event):return event is Dictionary and event.get("type")=="galakrond_replace_requested" and event.get("request") is Dictionary and event.request.get("use_id")==uid)
			if receipts.size()!=1 or receipts[0].get("player")!=player.id or receipts[0].get("round")!=record.request.round or receipts[0].get("policy")!=POLICY or not Sources.same(receipts[0].get("request"),record.request) or not Sources.same(receipts[0].get("domain"),record.domain): return "galakrond_replace_missing_actual_use_receipt"
			if record.status=="pending":
				if not waiting.has(uid) or not Sources.same(record.offers,waiting[uid]) or record.request.round!=state.round: return "galakrond_replace_lost_or_stale_pending"
				issue=_pending_target(player,record)
				if not issue.is_empty(): return issue
			elif waiting.has(uid) or not record.offers.is_empty(): return "galakrond_replace_closed_request_reused"
	return ""
static func cancel(player: Dictionary) -> void:
	for record in player.get(KEY,{}).values():
		if record.status=="pending": record.status="cancelled";record.offers=[]
	player.discover_queue=player.get("discover_queue",[]).filter(func(request):return not request_claimed(request))
	if player.get("discover",[]).any(func(choice):return choice.get("choice_kind")==KIND): player.discover=[]
