extends RefCounted
# Bounded real result parent. Detached projections execute no live capabilities.
const Sources=preload("res://core/gladiator_spoils_sources.gd")
const DevilishStandard=preload("res://core/devilish_standard_acquisition.gd")
const MinionResource=preload("res://core/exact_tier_minion_resource.gd")
const Exact=preload("res://core/board_aura_effects.gd")
static func clone_game(game):
	var shadow=game.get_script().new()
	shadow.catalog=game.catalog
	for key in ["room","state","events","command_log","last_combats","pool","spell_pool","_attack_gain_health_totals"]:
		shadow.set(key,game.get(key).duplicate(true))
	shadow.next_uid=game.next_uid
	shadow.rng=RandomNumberGenerator.new();shadow.rng.seed=game.rng.seed;shadow.rng.state=game.rng.state
	shadow._gladiator_projecting=true
	return shadow
static func owner(game,p: Dictionary) -> String:
	if not game.state.players.any(func(actual):return is_same(actual,p)) or not p.get("alive",false): return "gladiator_actual_living_owner_required"
	if not Sources.integer(p.get("tier"),2,6): return "gladiator_tier1_or_dynamic_high_tier_domain_held"
	if not p.get("active_quest",{}).is_empty() or not p.get("reward_active",[]).is_empty() or not p.get("trinkets",[]).is_empty() or not p.get(game.Aristocrat.STATE,[]).is_empty() or not p.get(game.Denathrius.Sources.STATE,{}).is_empty(): return "gladiator_competing_owned_acquisition_held"
	if game.HeroPowerIdentity.identity_id(p)!=game.HeroPowerIdentity.power_source_id(p) or p.has(game.HeroPowerIdentity.HISTORY): return "gladiator_replaced_hero_held"
	for effect in game.catalog.get_card(str(p.get("hero_id",""))).get("effects",[]):
		if effect.get("type")!="hero_keyword": return "gladiator_hero_result_start_or_acquisition_reader_held"
	var allowed: Array=["id","name","bot","hero_id","health","armor","tier","gold","max_gold","upgrade_cost","shop","hand","board","frozen","alive","ready","hero_used","quest_progress","reward_active","trinkets","discover","free_rolls","hero_counter","stats","active_quest","mechanic_counters","discover_queue","permanent_tribe_bonuses","hero_uses","hero_total_uses",game.HeroPowerIdentity.IDENTITY,game.HeroPowerIdentity.PORTRAIT,game.ParasiticFleshling.Sources.COUNT,game.MarketStats.STATE,game.GlobalCards.STATE,game.DiscardGemCopy.Sources.HISTORY,game.OwnedPurchases.Sources.HISTORY,game.PlainCopies.STATE,game.TradeHeroes.STATE,game.BulkTurnCounters.STATE,game.RecruitClock.STATE,DevilishStandard.OFFER,Sources.STATE]
	for key in p:
		if key in allowed: continue
		if (p[key] is Dictionary or p[key] is Array) and p[key].is_empty(): continue
		return "gladiator_unadmitted_owner_lifecycle_state:"+str(key)
	var standard_offer_issue: String=DevilishStandard.offers_error(p,game.catalog,int(game.state.round))
	if not standard_offer_issue.is_empty(): return standard_offer_issue
	var effects: Array=game.Mechanisms._effects(game,p)
	if effects.size()!=1 or not Sources.effect_error(effects[0]).is_empty(): return "gladiator_complete_owned_stream_required"
	for unit in p.get("board",[]):
		if not unit.get("effects",[]).is_empty() or not unit.get("attachments",[]).is_empty() or "reborn" in unit.get("keywords",[]) or unit.has("combat_triggers"): return "gladiator_competing_board_lifecycle_held"
	for zone in ["board","hand"]:
		for unit in p.get(zone,[]):
			var fresh: Dictionary=game._preview_native_minion(game.catalog.get_card(str(unit.get("card_id",""))),str(unit.get("uid",""))) if unit.get("kind")=="minion" else {}
			if unit.get("kind")!="minion": return "gladiator_pending_spell_source_domain_held"
			if fresh.is_empty(): return "gladiator_existing_body_factory_held"
			for key in ["attack","health","max_health","keywords","permanent_keywords","pool_id","pool_kind","pool_count"]:
				if unit.has(key): fresh[key]=unit[key]
			if unit.get("pool_components")==[]: fresh.pool_components=[]
			if unit.has(DevilishStandard.KEY):
				var standard_body_issue: String=DevilishStandard.unit_error(unit,int(p.id))
				if not standard_body_issue.is_empty(): return standard_body_issue
				fresh[DevilishStandard.KEY]=unit[DevilishStandard.KEY].duplicate(true)
			if not Exact.same(fresh,unit): return "gladiator_private_body_lifecycle_held"
	return ""
static func delivery(game,p: Dictionary,card_id: String,phase: String) -> Dictionary:
	var shadow=clone_game(game);shadow.state.phase=phase
	var owners: Array=shadow.state.players.filter(func(q):return q.id==p.id)
	if owners.size()!=1: return {"ok":false,"error":"gladiator_delivery_projection_owner"}
	var target: Dictionary=owners[0]
	var card: Dictionary=shadow.catalog.get_card(card_id)
	if card.get("supported")!=true: return {"ok":false,"error":"gladiator_full_delivery_domain_unimplemented:"+card_id}
	var unit: Dictionary=shadow._unit(card)
	if unit.is_empty(): return {"ok":false,"error":"gladiator_full_delivery_domain_factory:"+card_id}
	unit.pool_id=card_id;unit.pool_count=1
	if phase=="combat": unit.pool_kind="minion"
	if shadow.rng.state!=game.rng.state: return {"ok":false,"error":"gladiator_randomized_factory_composition_held"}
	unit=DevilishStandard.projected(shadow,target,unit,"exact_tier_random" if phase=="combat" else "ordinary_discover",int(game.pool.get(card_id,0)),int(card.get("tier",-1)))
	var accepted: bool=target.hand.size()<10
	shadow._add_hand(target,unit)
	if shadow.state.phase=="error": return {"ok":false,"error":"gladiator_full_delivery_domain_suffix:"+card_id}
	if target.hand.any(func(body):return is_same(body,unit))!=accepted: return {"ok":false,"error":"gladiator_delivery_acceptance_changed"}
	return {"ok":true,"error":"","accepted":accepted,"player":target.duplicate(true),"unit":unit.duplicate(true),"totals":shadow._attack_gain_health_totals.duplicate(true)}
static func candidates(game,p: Dictionary) -> String:
	var domain: Dictionary=game._discover_candidate_plan(p,int(p.tier))
	if not domain.ok: return str(domain.error)
	if domain.candidates.is_empty(): return "gladiator_empty_win_discover_held"
	for id in domain.candidates:
		var received: Dictionary=delivery(game,p,str(id),"recruit")
		if not received.ok: return str(received.error)
	var random: Dictionary=MinionResource.plan(game,int(p.tier)-1,p)
	if not random.ok: return str(random.error)
	if random.total==0: return "gladiator_empty_lower_tier_resource_held"
	for item in random.candidates:
		var received: Dictionary=delivery(game,p,str(item.id),"combat")
		if not received.ok: return str(received.error)
	return ""
static func precombat(game) -> String:
	if not Sources.enabled(game.room): return ""
	var issue: String=Sources.closure_error(game.catalog)
	if not issue.is_empty(): return issue
	if game._enabled("anomalies")!=[Sources.ID]: return "gladiator_multiple_anomalies_held"
	for p in game.state.players:
		if not p.get("alive",false): continue
		issue=owner(game,p)
		if not issue.is_empty(): return issue
		if not p.get("discover",[]).is_empty() or not p.get("discover_queue",[]).is_empty(): return "gladiator_pending_choice_before_combat_held"
		# Bound every possible original opponent before EOT/health mutation.
		# No native source in this admitted board can summon or change tier.
		for opponent in game.state.players+game.state.get("ghosts",[]):
			if opponent.get("id")==p.id: continue
			for effect in game.catalog.get_card(str(opponent.get("hero_id",""))).get("effects",[]):
				if effect.get("type")!="hero_keyword": return "gladiator_opponent_hero_combat_lifecycle_held"
			var ceiling: int=int(opponent.get("tier",6))
			for unit in opponent.get("board",[]):
				if not unit.get("effects",[]).is_empty() or not unit.get("attachments",[]).is_empty() or "reborn" in unit.get("keywords",[]): return "gladiator_opponent_growth_or_resource_domain_held"
				var tier: Variant=unit.get("tier",game.catalog.get_card(str(unit.get("card_id",""))).get("tier"))
				if not Sources.integer(tier,1,7): return "gladiator_damage_ceiling_unknown_tier"
				ceiling+=int(tier)
			if int(p.health)+int(p.get("armor",0))<=ceiling: return "gladiator_lethal_result_timing_domain_held"
		issue=candidates(game,p)
		if not issue.is_empty(): return issue
	return ""

static func choice(game,p: Dictionary,index: int) -> Dictionary:
	var shadow=clone_game(game)
	var target: Dictionary=shadow.state.players.filter(func(q):return q.id==p.id)[0]
	var result: Dictionary=shadow._choose_discover(target,index)
	if not result.get("ok",false) or shadow.state.phase=="error": return {"ok":false,"error":"gladiator_complete_original_choice_suffix_held"}
	if not target.discover.is_empty() or not target.get("discover_queue",[]).is_empty(): return {"ok":false,"error":"gladiator_choice_nested_reward_or_triple_held"}
	return {"ok":true,"error":"","player":target.duplicate(true),"pool":shadow.pool.duplicate(true),"spell_pool":shadow.spell_pool.duplicate(true),"next_uid":shadow.next_uid,"rng_state":shadow.rng.state,"totals":shadow._attack_gain_health_totals.duplicate(true)}
