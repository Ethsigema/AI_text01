extends RefCounted
const Exact=preload("res://core/board_aura_effects.gd")
## Exact native normal/golden Determined Defender, written_unverified.
## NUM_1/NUM_2 are independent per-entity values; no golden multiplier inference.
const TYPE: String = "deathrattle_determined_defender"
const IDS: Array = ["BG35_122", "BG35_122_G"]
const PROGRAMS: Dictionary = {
	"BG35_122": [{"type":"deathrattle_determined_defender","source_id":"BG35_122","scope":"adjacent","attack":5,"health":5,"keyword":"taunt"}],
	"BG35_122_G": [{"type":"deathrattle_determined_defender","source_id":"BG35_122_G","scope":"adjacent","attack":10,"health":10,"keyword":"taunt"}]
}
static func identity(unit: Dictionary) -> String:
	return str(unit.get("card_id", unit.get("id", "")))
static func claimed(unit: Dictionary) -> bool:
	return identity(unit) in IDS
static func effect_error(effect: Dictionary) -> String:
	var id: String = str(effect.get("source_id", ""))
	return "" if id in IDS and Exact.same(effect,PROGRAMS[id][0]) else "determined_defender_changed_native_leaf"
static func program_error(unit: Dictionary) -> String:
	var id: String = identity(unit)
	if id not in IDS or not Exact.same(unit.get("effects"),PROGRAMS[id]):
		return "determined_defender_changed_complete_native_program"
	if unit.get("kind", "minion") != "minion": return "determined_defender_wrong_kind"
	if unit.get("golden", unit.get("is_golden", false)) != (id == "BG35_122_G"):
		return "determined_defender_changed_native_variant"
	return ""
static func apply_overlay(cards: Dictionary) -> String:
	var data: Variant = JSON.parse_string(FileAccess.get_file_as_string("res://data/determined_defender_overlay.json"))
	if not data is Dictionary or not data.get("cards") is Array: return "determined_defender_missing_overlay"
	for row in data.cards:
		if not row is Dictionary or row.get("id") not in IDS or not cards.has(row.id):
			return "determined_defender_missing_native_identity"
		var merged: Dictionary = cards[row.id].duplicate(true)
		merged.merge(row, true)
		var issue: String = program_error(merged)
		if not issue.is_empty(): return issue
		# Preserve raw values, historical pool identity, normal/golden links and
		# independent native proof. This only removes the superseded missing-DSL flag.
		merged.quality_flags = merged.get("quality_flags", []).duplicate()
		merged.quality_flags.erase("effect_not_implemented")
		cards[row.id] = merged
	return ""
