from pathlib import Path
import re,json,shutil,hashlib,argparse
parser=argparse.ArgumentParser();parser.add_argument('--output',default='/tmp/numeric-import-review/project');args=parser.parse_args()
root=Path(__file__).resolve().parents[2];out=Path(args.output);out.mkdir(parents=True,exist_ok=True)
names=['elise_refresh_sources','parasitic_fleshling_sources','mutated_lasher_sources','determined_defender_sources','upbeat_upstart_sources','eonar_favor_sources','winner_bread_sources']
def method(source,name):
 m=re.search(r'^static func '+name+r'\(',source,re.M);assert m;tail=source[m.start():];end=re.search(r'\n(?:static func |func |const |var )',tail);return(tail[:end.start()] if end else tail).rstrip()+'\n'
(out/'project.godot').write_text('config_version=5\n[application]\nconfig/name="Numeric and import review"\n')
s=(root/'core/board_aura_effects.gd').read_text();(out/'exact.gd').write_text('extends RefCounted\n'+method(s,'signed_integer')+method(s,'same'))
hashes={}
for name in names:
 p=root/'core'/f'{name}.gd';s=p.read_text();hashes[str(p.relative_to(root))]=hashlib.sha256(p.read_bytes()).hexdigest();s=s.replace('res://core/board_aura_effects.gd','res://exact.gd');(out/f'{name}.gd').write_text(s)
for rel in ['data/upbeat_upstart_overlay.json','research/current_eonar_spell_20261029/native255790.json','research/current_winner_bread_20261029/native255790.json']:
 p=out/rel;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(root/rel,p)
supp=json.loads((root/'data/supplemental_missing_catalog.json').read_text())['cards'];rows={r['id']:r for r in supp if r['id'] in ['BG35_912','BG36_883']};(out/'rows.json').write_text(json.dumps(rows,ensure_ascii=False))
shutil.copy2(Path(__file__).parent/'test.gd',out/'test.gd');(Path(__file__).parent/'reviewed_source_hashes.json').write_text(json.dumps(hashes,indent=2)+'\n');print(out)
