extends SceneTree
const Catalog=preload("res://core/catalog.gd")
const Room=preload("res://core/room_config.gd")
const Game=preload("res://core/game.gd")
var report: Dictionary={"scope":"explicit custom two-player Cyclone/Patchwerk basic command smoke; no card identity acceptance","checks":[],"commands":[],"loads":0}
func verify(value: bool,label: String) -> bool:
	report.checks.append({"label":label,"passed":value})
	print("SMOKE_CHECK ",label," ",value)
	if not value:
		finish(1)
	return value
func finish(code: int) -> void:
	var f=FileAccess.open("res://recovery_evidence_20261103/game_smoke.json",FileAccess.WRITE)
	f.store_string(JSON.stringify(report,"  "))
	print("RECOVERY_GAME_SMOKE ",JSON.stringify(report))
	quit(code)
func _initialize() -> void:
	var catalog=Catalog.new()
	catalog.load_catalog()
	report.catalog_errors=catalog.load_errors
	if not verify(catalog.load_errors.is_empty(),"catalog clean"): return
	var room=Room.new()
	room.reset(catalog)
	room.data.bot_count=1
	room.data.seed=20261103
	room.data.enabled_minions=["BGS_119"]
	room.data.enabled_spells=[]
	room.data.enabled_heroes=["TB_BaconShop_HERO_34"]
	room.data.selected_hero="TB_BaconShop_HERO_34"
	for key in ["enabled_anomalies","enabled_trinkets","enabled_quests","enabled_rewards"]: room.data[key]=[]
	report.room_errors=room.validate(catalog)
	if not verify(report.room_errors.is_empty(),"explicit room valid"): return
	var game=Game.new()
	var started=game.start(room.data,catalog)
	report.start=started
	if not verify(started.get("ok",false),"real Game start"): return
	if not verify(game.state.players.size()==2 and game.state.phase=="recruit","two real players recruiting"): return
	for command in [{"type":"buy","index":0},{"type":"play","index":0,"position":0},{"type":"freeze"},{"type":"end_turn"},{"type":"sell","index":0}]:
		var result=game.apply_command(0,command)
		report.commands.append({"command":command,"result":result,"phase":game.state.phase})
		if not verify(result.get("ok",false),"actual command "+command.type): return
		var save_path="user://recovery_smoke_"+str(report.commands.size())+".json"
		var saved=game.save_to(save_path)
		if not verify(saved==OK,"native save "+str(report.commands.size())): return
		var restored=Game.new()
		var loaded=restored.load_from(save_path,catalog)
		if not verify(loaded==OK,"fresh native load "+str(report.commands.size())): return
		if not verify(restored.state==game.state and restored.pool==game.pool and restored.spell_pool==game.spell_pool and str(restored.rng.state)==str(game.rng.state),"native roundtrip state "+str(report.commands.size())): return
		report.loads+=1
		game=restored
	finish(0)
