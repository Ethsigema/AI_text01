extends RefCounted
const PackagedEvidence = preload("res://core/packaged_source_evidence.gd")
## Exact Forsaken Weaver pair. Existing committed owner hand-cast clock and Army ledger.
## No automatic cast, choice or source-creation timing rule is invented here.
const Army = preload("res://core/permanent_tribe_effects.gd")
const DeferredPotential = preload("res://core/native_discover_choice.gd")
const Exact = preload("res://core/end_turn_repeats.gd")
const Numbers = preload("res://core/delayed_minion_gold.gd")
const PoolIdentity = preload("res://core/pool_identity.gd")
const FOLDER: String = "res://research/forsaken_weaver_sources/"
const RULE: String = "forsaken_weaver_complete_native_v1"
const TYPE: String = "on_tavern_cast_undead_army_attack"
const IDS: Array = ["BG34_692","BG34_692_G"]
const CONTRACT_SHA256: String = "54a4f70b25e06ac64d1676f313a50f874ab72231e8a5aef646b9cfcccfa5e143"
const EXPECTED_SHA256: String = "4b1638b2190849449af4458e4862df349b15083911739e0df4828eea633619a0"
const PROGRAMS: Dictionary = {"BG34_692":[{"type":"on_tavern_cast_undead_army_attack","tribe":"亡灵","attack":3,"health":0,"duration":"game"}],"BG34_692_G":[{"type":"on_tavern_cast_undead_army_attack","tribe":"亡灵","attack":6,"health":0,"duration":"game"}]}
const ENTITY_SHA256: Dictionary = {"BG34_692":"10c41eb7cb1645c387416cb76b225a980ef9eb8e20e884bcdb23e2c41c4cf24d","BG34_692_G":"ca666a73b8fba0040cdb1137bf5e89934bc7f815fefb528891827c39a8697bb1"}
const EVIDENCE_SHA256: Dictionary = {"pool_scope_amendment.json":"c0591c621cf0e8531dcab0bc6f1ebcb8bd27bd0c49a8c980443f271a47aed7f7","README.md":"48de0746ac1f3e1c29cc966b61377ee32032540056c33350b94e2dacde6d62d0","SHA256SUMS":"01da148490d762c2fadbff319b1b087fd4b5fe7c8f81876d4537591aad2a02d5","host/game.gd.txt":"241a42b34a8e0bf4c603ef5b56b5575faa0a83bf6727e405477447cb57a53315","host/mechanism_army.gd.txt":"08e1b03e68b04eff5ca80e241710f4e38893d8b3f0de70754d63a311658e2135","host/mechanism_effects.gd.txt":"ce41906f79deae6ae9a3b68a7e0dbf981a0b1cf4a0a9b2b0f3993d71154c89dc","host/permanent_tribe_effects.gd.txt":"dbd11d23d8496f5a89215df6499eb7214dcb567f6b19e54b22375b12bdf14bbd","host/permanent_tribe_room.gd.txt":"e7f93a71c3f66d166f0c4398311e8ba962b22c0387571dbbd5c62f137df34cf5","host/spell_cast_listeners.gd.txt":"c3eaae7227efda3393c01ca4ff7af096f05725abc1363f1a5d17f86046efc843","input_manifest.json":"47f0f7a174d6f8e768028c581815afbb2bcedee233a563e7b6b3301736763673","native/BG34_692.xml":"10c41eb7cb1645c387416cb76b225a980ef9eb8e20e884bcdb23e2c41c4cf24d","native/BG34_692_G.xml":"ca666a73b8fba0040cdb1137bf5e89934bc7f815fefb528891827c39a8697bb1","seal.json":"eb72d5e37b3614bd7fa094f6995f901841d3c66bb3d412040b5c7d72de142191"}
const RAW49_SHA256: Dictionary = {"BG34_692":"185a1675337c80f0bd871d55bcc6699b4bd22b4c2dd3cd240cd0b32b4d7f71ca","BG34_692_G":"554d791c7063d45e6228573559c3b043ef87bced186aa0ed1e864d11ef10541b"}
const SOURCES: Dictionary = {"BG34_692":{"name":"被遗忘者纺织工","kind":"minion","category":"随从","tier":6,"attack":3,"health":8,"cost":null,"tribes":["亡灵"],"is_golden":false,"text":"在你施放一个酒馆法术后，你的亡灵在本局对战中拥有+3攻击力（无论它们在哪）。","normal_id":null,"golden_id":"BG34_692_G"},"BG34_692_G":{"name":"被遗忘者纺织工","kind":"minion","category":"随从","tier":6,"attack":6,"health":16,"cost":null,"tribes":["亡灵"],"is_golden":true,"text":"在你施放一个酒馆法术后，你的亡灵在本局对战中拥有+6攻击力（无论它们在哪）。","normal_id":"BG34_692","golden_id":null}}
const DBF: Dictionary = {"BG34_692":"126733","BG34_692_G":"126734"}

static func effect_claimed(effect: Dictionary) -> bool:
	return Exact._same(effect.get("type"),TYPE)

static func effect_error(effect: Dictionary) -> String:
	if not effect_claimed(effect): return ""
	for program in PROGRAMS.values():
		if Exact._same(effect,program[0]): return Army.tavern_cast_army_effect_error(effect)
	return "forsaken_weaver_incomplete_reserved_program"

static func accepts_id(identity: Variant) -> bool:
	return identity is String and identity in IDS

static func program_for(identity: Variant) -> Array:
	return PROGRAMS[identity].duplicate(true) if accepts_id(identity) else []

static func _marker(value: Variant, depth: int = 0) -> bool:
	if depth > 16: return true
	if value is Dictionary:
		if effect_claimed(value) or accepts_id(value.get("card_id")) or accepts_id(value.get("source_id")): return true
		for child in value.values():
			if (child is Dictionary or child is Array) and _marker(child,depth+1): return true
	elif value is Array:
		for child in value:
			if _marker(child,depth+1): return true
	return false

static func claimed(source: Variant) -> bool:
	if not source is Dictionary: return false
	if accepts_id(source.get("id")) or accepts_id(source.get("card_id")): return true
	for key in ["base_unit","_base"]:
		if source.get(key) is Dictionary and (accepts_id(source[key].get("id")) or accepts_id(source[key].get("card_id"))): return true
	return _marker(source.get("effects",[]))

## Fresh local verification binds every retained source byte; no mutable global trust cache.
static func validation_evidence() -> Dictionary:
	if FileAccess.get_sha256(FOLDER+"source_contract.json") != CONTRACT_SHA256: return {"error":"forsaken_weaver_contract_changed"}
	if FileAccess.get_sha256(FOLDER+"expected_compiled.json") != EXPECTED_SHA256: return {"error":"forsaken_weaver_expected_program_changed"}
	var contract: Variant = JSON.parse_string(FileAccess.get_file_as_string(FOLDER+"source_contract.json"))
	var expected: Variant = JSON.parse_string(FileAccess.get_file_as_string(FOLDER+"expected_compiled.json"))
	if not contract is Dictionary or not Exact._same(contract.get("ids"),IDS): return {"error":"forsaken_weaver_source_closure_changed"}
	if not contract.get("records") is Dictionary or contract.records.size() != 2 or not expected is Dictionary or expected.size() != 2: return {"error":"forsaken_weaver_incomplete_evidence"}
	var records: Dictionary = {}
	for identity in IDS:
		var path: String = "raw49/"+identity+".json"
		if FileAccess.get_sha256(FOLDER+path) != RAW49_SHA256[identity]: return {"error":"forsaken_weaver_raw49_changed"}
		var row: Variant = JSON.parse_string(FileAccess.get_file_as_string(FOLDER+path))
		if not row is Dictionary or row.size() != 49 or not Exact._same(row.get("id"),identity): return {"error":"forsaken_weaver_raw49_shape_changed"}
		if not Exact._same(expected[identity].get("effects"),PROGRAMS[identity]): return {"error":"forsaken_weaver_complete_program_changed"}
		records[identity] = row
	var proof: Dictionary = PackagedEvidence.inspect(FOLDER,EVIDENCE_SHA256)
	if not str(proof.error).is_empty(): return {"error":"forsaken_weaver_native_evidence_changed"}
	return {"error":"","records":records,"expected":expected,"missing_annotations":proof.missing_annotations,"annotation_status":proof.annotation_status}

static func raw_source_error(card: Dictionary, evidence: Dictionary = {}) -> String:
	if not accepts_id(card.get("id")): return "forsaken_weaver_unknown_raw_source"
	if evidence.is_empty(): evidence = validation_evidence()
	if not str(evidence.get("error","forsaken_weaver_missing_evidence")).is_empty(): return str(evidence.get("error","forsaken_weaver_missing_evidence"))
	return "" if Exact._same(card,evidence.records[card.id]) else "forsaken_weaver_complete_raw_source_changed"

static func source_error(card: Variant, custom_projection: bool = false, evidence: Dictionary = {}) -> String:
	if not card is Dictionary: return "forsaken_weaver_invalid_source"
	if not claimed(card): return ""
	if not accepts_id(card.get("id")) or card.has("card_id"): return "forsaken_weaver_unbound_canonical_source"
	if evidence.is_empty(): evidence = validation_evidence()
	if not str(evidence.get("error","forsaken_weaver_missing_evidence")).is_empty(): return str(evidence.get("error","forsaken_weaver_missing_evidence"))
	var identity: String = card.id
	var expected: Dictionary = evidence.records[identity].duplicate(true)
	expected.merge(evidence.expected[identity],true)
	var actual: Dictionary = card.duplicate(true)
	if actual.has("pool_blocker"):
		# Catalog's established acquisition gate may add only this exact text.
		expected.pool_blocker = PoolIdentity.MINION_REASON
	if actual.has("source_shop_fields"):
		if not custom_projection or identity not in IDS: return "forsaken_weaver_nonparent_custom_shop"
		if not Exact._same(actual.source_shop_fields,{"tier":expected.tier,"cost":expected.cost,"pool_supported":expected.pool_supported}): return "forsaken_weaver_custom_source_changed"
		if not Numbers.integer(actual.get("tier"),1,6): return "forsaken_weaver_custom_tier_changed"
		if identity == IDS[0]:
			if not Numbers.integer(actual.get("cost"),0,9223372036854775807) or not Exact._same(actual.get("pool_supported"),true): return "forsaken_weaver_custom_parent_price_or_pool"
			if not actual.get("custom_shop_override") is Dictionary or actual.has("custom_shop_derived_from"): return "forsaken_weaver_custom_parent_metadata"
			var entry: Dictionary = actual.custom_shop_override
			if entry.size() != 3 or not Numbers.integer(entry.get("tier"),1,6) or not Numbers.integer(entry.get("cost"),0,99) or not Numbers.integer(entry.get("copies"),1,99): return "forsaken_weaver_custom_shop_parameters_changed"
			if not Exact._same(entry.tier,actual.tier) or not Exact._same(entry.cost,actual.cost): return "forsaken_weaver_custom_shop_projection_changed"
		else:
			if actual.has("custom_shop_override") or not Exact._same(actual.get("custom_shop_derived_from"),IDS[0]): return "forsaken_weaver_custom_golden_metadata"
			if not Exact._same(actual.get("cost"),expected.cost) or not Exact._same(actual.get("pool_supported"),false): return "forsaken_weaver_custom_golden_cannot_be_stock"
		actual.tier = expected.tier; actual.cost = expected.cost; actual.pool_supported = expected.pool_supported
		for key in ["source_shop_fields","custom_shop_override","custom_shop_derived_from"]: actual.erase(key)
	return "" if Exact._same(actual,expected) else "forsaken_weaver_complete_source_changed:"+identity

static func card_error(card: Variant, custom_projection: bool = false, evidence: Dictionary = {}) -> String:
	return source_error(card,custom_projection,evidence)

static func closure_error(catalog, identity: Variant, evidence: Dictionary = {}) -> String:
	if catalog == null or not accepts_id(identity): return "forsaken_weaver_unknown_family_or_catalog"
	if evidence.is_empty(): evidence = validation_evidence()
	if not str(evidence.get("error","forsaken_weaver_missing_evidence")).is_empty(): return str(evidence.get("error","forsaken_weaver_missing_evidence"))
	var original = catalog.source_catalog if catalog.source_catalog != null else catalog
	for member in IDS:
		var canonical: Dictionary = original.get_card(member)
		if not Exact._same(canonical.get("id"),member): return "forsaken_weaver_missing_source:"+member
		var issue: String = source_error(canonical,false,evidence)
		if not issue.is_empty(): return issue
		if catalog.source_catalog != null:
			var effective: Dictionary = catalog.get_card(member)
			if not Exact._same(effective.get("id"),member): return "forsaken_weaver_missing_effective_source:"+member
			issue = source_error(effective,true,evidence)
			if not issue.is_empty(): return issue
	if catalog.source_catalog != null:
		var parent: Dictionary = catalog.get_card(IDS[0])
		var golden: Dictionary = catalog.get_card(IDS[1])
		if not Exact._same(parent.get("tier"),golden.get("tier")): return "forsaken_weaver_effective_parent_pair_tier_changed"
		if parent.has("source_shop_fields") != golden.has("source_shop_fields"): return "forsaken_weaver_effective_parent_pair_projection_changed"
	return ""

static func room_error(room: Dictionary, catalog) -> String:
	for identity in room.get("enabled_minions",[]) + room.get("enabled_spells",[]):
		if accepts_id(identity) and identity not in room.get("disabled_ids",[]):
			var issue: String = closure_error(catalog,identity)
			return issue if not issue.is_empty() else template_catalog_error(catalog)
	return ""

static func _identity_error(source: Dictionary, identity: String) -> String:
	var expected: Dictionary = SOURCES[identity]
	for key in ["id","card_id","card_code"]:
		if source.has(key) and not Exact._same(source[key],identity): return "forsaken_weaver_conflicting_identity"
	if source.has("dbf_id") and not Exact._same(source.dbf_id,DBF[identity]): return "forsaken_weaver_conflicting_dbf_identity"
	if not Exact._same(source.get("kind",expected.kind),expected.kind): return "forsaken_weaver_wrong_kind"
	if not Exact._same(source.get("golden",source.get("is_golden")),expected.is_golden): return "forsaken_weaver_wrong_variant"
	if source.has("is_golden") and not Exact._same(source.is_golden,expected.is_golden): return "forsaken_weaver_conflicting_variant"
	if not Exact._same(source.get("tribes"),expected.tribes): return "forsaken_weaver_wrong_tribes"
	for key in ["name","text"]:
		if source.has(key) and not Exact._same(source[key],expected[key]): return "forsaken_weaver_changed_"+key
	if not Exact._same(source.get("effects"),PROGRAMS[identity]): return "forsaken_weaver_incomplete_program"
	if source.has("choose_one_branch_id"): return "forsaken_weaver_unrelated_branch_provenance"
	return ""

static func _base_error(base: Variant, identity: String, templates: Dictionary) -> String:
	if not base is Dictionary or not Exact._same(base.get("card_id",base.get("id")),identity): return "forsaken_weaver_base_identity_changed"
	var issue: String = _identity_error(base,identity)
	if not issue.is_empty(): return issue
	if not Exact._same(base.get("keywords",[]),[]): return "forsaken_weaver_base_keywords_changed"
	for key in ["attachments","pool_components"]:
		if not Exact._same(base.get(key,[]),[]): return "forsaken_weaver_base_attachment_changed"
	if base.has("base_unit") or base.has("_base"): return "forsaken_weaver_nested_base"
	if identity in IDS:
		for key in ["attack","health"]:
			if not Exact._same(base.get(key),SOURCES[identity][key]): return "forsaken_weaver_native_base_body_changed"
		if not Exact._same(base.get("max_health",base.get("health")),SOURCES[identity].health): return "forsaken_weaver_native_base_max_health_changed"
		var tier: Variant = SOURCES[identity].tier
		if templates.has(identity):
			var template: Variant = templates[identity]
			if not template is Dictionary: return "forsaken_weaver_invalid_source_template"
			issue = _identity_error(template,identity)
			if not issue.is_empty(): return issue
			if not Numbers.integer(template.get("tier"),1,6): return "forsaken_weaver_invalid_template_tier"
			for key in ["attack","health"]:
				if not Exact._same(template.get(key),SOURCES[identity][key]): return "forsaken_weaver_template_body_changed"
			tier = template.tier
		if not Exact._same(base.get("tier"),tier): return "forsaken_weaver_native_base_tier_changed"
	return ""

static func unit_error(source: Variant, templates: Dictionary = {}, is_base: bool = false) -> String:
	if not source is Dictionary: return "forsaken_weaver_invalid_runtime_source"
	if not claimed(source): return ""
	var evidence: Dictionary = validation_evidence()
	if not str(evidence.get("error", "forsaken_weaver_missing_evidence")).is_empty(): return str(evidence.error)
	if source.has("id") and not source.has("card_id"): return source_error(source,source.has("source_shop_fields"))
	var identity: Variant = source.get("card_id",source.get("id"))
	if not accepts_id(identity): return "forsaken_weaver_marker_on_wrong_source"
	var issue: String = _identity_error(source,identity)
	if not issue.is_empty(): return issue
	issue = templates_error(templates)
	if not issue.is_empty(): return issue
	if is_base: return _base_error(source,identity,templates)
	if not source.has("uid") and templates.has(identity) and Exact._same(source,templates[identity]): return _base_error(source,identity,templates)
	var uid_valid: bool = source.get("uid") is String and not source.uid.is_empty()
	if not uid_valid: return "forsaken_weaver_invalid_runtime_uid"
	if not Exact._same(source.get("kind"),"minion"): return "forsaken_weaver_runtime_kind_changed"
	for flag in ["temporary","is_spellcraft","excluded","stats_conflict","duos_exclusive","requires_teammate_effect"]:
		if not Exact._same(source.get(flag,false),false): return "forsaken_weaver_runtime_gate:"+flag
	for flag in ["silenced","abilities_disabled","_pending_destroy"]:
		if source.has(flag) and not source[flag] is bool: return "forsaken_weaver_invalid_activity_flag:"+flag
	if source.has("solo_eligible") and not Exact._same(source.solo_eligible,true): return "forsaken_weaver_runtime_not_solo"
	for key in ["attachments","pool_components","quality_flags","source_conflicts"]:
		if not Exact._same(source.get(key,[]),[]): return "forsaken_weaver_unverified_runtime_attachment_or_flag:"+key
	if not Numbers.integer(source.get("attack"),0,9223372036854775807): return "forsaken_weaver_invalid_live_attack"
	if not Numbers.integer(source.get("health"),-9223372036854775807,9223372036854775807): return "forsaken_weaver_invalid_live_health"
	if not Numbers.integer(source.get("max_health",source.get("health")),1,9223372036854775807): return "forsaken_weaver_invalid_live_max_health"
	if source.health > source.get("max_health",source.health): return "forsaken_weaver_live_health_exceeds_maximum"
	if not Numbers.integer(source.get("tier"),1,6): return "forsaken_weaver_invalid_live_tier"
	var expected_tier: Variant = SOURCES[identity].tier
	if templates.has(identity):
		issue = _base_error(templates[identity],identity,templates)
		if not issue.is_empty(): return issue
		expected_tier = templates[identity].tier
	if not Exact._same(source.tier,expected_tier): return "forsaken_weaver_live_tier_differs_from_source"
	if not source.get("keywords",[]) is Array: return "forsaken_weaver_invalid_live_keywords"
	for keyword in source.get("keywords",[]):
		if not keyword is String: return "forsaken_weaver_invalid_live_keyword"
	for key in ["base_unit","_base"]:
		if source.has(key):
			issue = _base_error(source[key],identity,templates)
			if not issue.is_empty(): return issue
	if not source.get("temporary_buffs",[]) is Array: return "forsaken_weaver_invalid_temporary_layers"
	for buff in source.get("temporary_buffs",[]):
		if not buff is Dictionary or not Numbers.integer(buff.get("attack"),-9223372036854775807,9223372036854775807) or not Numbers.integer(buff.get("health"),-9223372036854775807,9223372036854775807) or not buff.get("keywords") is Array: return "forsaken_weaver_invalid_temporary_layer"
		for keyword in buff.keywords:
			if not keyword is String: return "forsaken_weaver_invalid_temporary_keyword"
	return ""

static func play_error(engine, _player: Dictionary, source: Dictionary) -> String:
	if not claimed(source): return ""
	var identity: Variant = source.get("card_id",source.get("id"))
	var templates: Dictionary = engine.catalog.hand_card_templates
	var issue: String = unit_error(source,templates)
	if not issue.is_empty(): return issue
	issue = closure_error(engine.catalog,identity)
	return issue if not issue.is_empty() else template_catalog_error(engine.catalog)


static func saved_unit_error(unit: Dictionary, catalog, depth: int = 0) -> String:
	if depth > 16: return "forsaken_weaver_nested_depth"
	if claimed(unit):
		var issue: String = unit_error(unit,catalog.hand_card_templates)
		if not issue.is_empty(): return issue
		issue = closure_error(catalog,unit.get("card_id",unit.get("id")))
		if not issue.is_empty(): return issue
		issue = template_catalog_error(catalog)
		if not issue.is_empty(): return issue
	for key in ["base_unit","_base"]:
		if unit.get(key) is Dictionary:
			# The containing source authenticates its exact base; do not reinterpret
			# a pristine UID-free base as an independently active live minion.
			if claimed(unit[key]) and not claimed(unit): return "forsaken_weaver_foreign_parent_base"
	return ""

static func templates_error(templates: Dictionary) -> String:
	# Both pristine templates are required; one changed mate cannot authorize the other.
	for identity in IDS:
		if not templates.has(identity): return "forsaken_weaver_missing_pair_template"
		var issue: String = _base_error(templates[identity],identity,templates)
		if not issue.is_empty(): return issue
		if not Exact._same(templates[identity],_native_template(identity,templates[identity].tier)): return "forsaken_weaver_complete_template_changed"
	if not Exact._same(templates[IDS[0]].tier,templates[IDS[1]].tier): return "forsaken_weaver_pair_template_tier_changed"
	return ""

static func _native_template(identity: String, tier: int) -> Dictionary:
	var native: Dictionary = SOURCES[identity]
	return {"card_id":identity,"kind":"minion","name":native.name,"effects":PROGRAMS[identity].duplicate(true),"attack":native.attack,"health":native.health,"tier":tier,"keywords":[],"tribes":["亡灵"],"max_health":native.health,"golden":native.is_golden}

## Catalog.load validates complete cards before generating templates. Runtime
## and room admission additionally bind every template field to the final
## effective card, including explicitly declared custom tier projection.
static func template_catalog_error(catalog) -> String:
	for identity in IDS:
		var card: Dictionary = catalog.get_card(identity)
		if not Numbers.integer(card.get("tier"),1,6): return "forsaken_weaver_catalog_template_tier_changed"
		if not Exact._same(catalog.hand_card_templates.get(identity),_native_template(identity,int(card.tier))): return "forsaken_weaver_catalog_template_changed"
		if not Exact._same(catalog.hand_card_kinds.get(identity),"minion"): return "forsaken_weaver_template_kind_changed"
	return ""

static func inactive(source: Dictionary) -> bool:
	if not Numbers.integer(source.get("health"),-9223372036854775807,9223372036854775807): return false
	return source.health <= 0 or Exact._same(source.get("_pending_destroy",false),true) or Exact._same(source.get("silenced",false),true) or Exact._same(source.get("abilities_disabled",false),true)

static func call_error(source: Dictionary, effect: Dictionary, _templates: Dictionary = {}) -> String:
	if not claimed(source) and not effect_claimed(effect): return ""
	return "forsaken_weaver_requires_actual_hand_cast"

## This capability is created only inside the public command's actual hand cast.
## It is transient, owner/reference-bound, and spent once per current live source.
static func _contains_same(units: Array, unit: Dictionary) -> bool:
	for member in units:
		if is_same(member,unit): return true
	return false

static func cast_scope_error(card: Dictionary) -> String:
	# This exact original only queues native Discover offers. Selection and
	# acquisition happen in later public commands, after the complete original
	# cast listener loop. It cannot create/replace a source in this cast slot.
	if card.get("id")==DeferredPotential.PARENT:
		if not Exact._same(card.get("effects"),DeferredPotential.PROGRAM): return "forsaken_weaver_changed_deferred_potential_program"
		for key in DeferredPotential.FIELDS:
			if not Exact._same(card.get(key),DeferredPotential.FIELDS[key]): return "forsaken_weaver_changed_deferred_potential_source:"+str(key)
		return ""
	# Existing direct payloads do not create, return, transform or choose a source.
	# Their payload amplification is allowed; it still produces one hand-cast event.
	if not card.get("effects") is Array or card.effects.is_empty(): return "forsaken_weaver_missing_canonical_spell_program"
	for effect in card.effects:
		if not effect is Dictionary or effect.get("type") not in ["spell_buff","spell_keyword","spell_gold"]: return "forsaken_weaver_compound_cast_timing_unreviewed"
	return ""

static func _family_reachable(engine) -> bool:
	for card in engine.RoomConfig.PermanentTribeRoom.reachable(engine.room,engine.catalog):
		if claimed(card): return true
	for owner in engine.state.get("players",[]):
		for zone in ["board","hand","shop"]:
			for unit in owner.get(zone,[]):
				if claimed(unit): return true
	return false

static func capture_cast(engine, player: Dictionary, spell: Dictionary) -> Dictionary:
	var result: Dictionary = {"ok":true,"error":""}
	if spell.get("kind") != "spell": return result
	var canonical: Dictionary = engine.catalog.get_card(str(spell.get("card_id","")))
	# Acquisition origin is deliberately irrelevant. Only current canonical type
	# and a genuine hand command qualify, including a Tavern card generated earlier.
	if not engine.Mechanisms.is_tavern_spell_card(canonical): return result
	if not _family_reachable(engine): return result
	var issue: String = cast_scope_error(canonical)
	if not issue.is_empty(): return {"ok":false,"error":issue}
	if not Exact._same(canonical.get("supported"),true) or not Exact._same(spell.get("effects"),canonical.get("effects")): return {"ok":false,"error":"forsaken_weaver_noncanonical_cast_program"}
	if not Exact._same(spell.get("temporary",false),false) or not Exact._same(spell.get("is_spellcraft",false),false) or spell.has("choose_one_branch_id"): return {"ok":false,"error":"forsaken_weaver_temporary_or_choice_cast_unreviewed"}
	var command: Dictionary = engine._weaver_command_context
	if command.is_empty() or not is_same(command.get("owner"),player) or not is_same(command.get("spell"),spell): return {"ok":false,"error":"forsaken_weaver_requires_public_hand_command"}
	if not Exact._same(command.get("sequence"),engine.state.command_sequence) or not Exact._same(command.get("round"),engine.state.round): return {"ok":false,"error":"forsaken_weaver_stale_command"}
	if engine.state.get("phase") != "recruit" or not _contains_same(engine.state.get("players",[]),player) or not _contains_same(player.get("hand",[]),spell): return {"ok":false,"error":"forsaken_weaver_not_actual_owner_hand"}
	if not spell.get("uid") is String or spell.uid.is_empty(): return {"ok":false,"error":"forsaken_weaver_invalid_cast_uid"}
	# The existing listener slot is reused. A different listener that creates or
	# moves a source during this same cast remains outside this initial bridge.
	for other in player.get("board",[]):
		for effect in other.get("effects",[]):
			if not effect is Dictionary: return {"ok":false,"error":"forsaken_weaver_invalid_listener_program"}
			if effect.get("type") == "on_spell_effect":
				var action: Variant = effect.get("effect")
				if not action is Dictionary or action.get("type") not in ["battlecry_buff","spell_buff","battlecry_gold","spell_gold","battlecry_keyword","spell_keyword"]: return {"ok":false,"error":"forsaken_weaver_listener_source_change_timing_unreviewed"}
	var listeners: Array = []
	var seen: Dictionary = {}
	var budget: int = 0
	for source in player.get("board",[]):
		if not claimed(source): continue
		issue = play_error(engine,player,source)
		if not issue.is_empty(): return {"ok":false,"error":issue}
		if inactive(source): continue
		if seen.has(source.uid) or source.uid == spell.uid: return {"ok":false,"error":"forsaken_weaver_duplicate_source_uid"}
		seen[source.uid] = true
		listeners.append({"source":source,"uid":source.uid,"card_id":source.card_id})
		budget += int(PROGRAMS[source.card_id][0].attack)
	if listeners.is_empty(): return result
	var plan: Dictionary = Army.recruit_attack_plan(player,budget)
	if not str(plan.error).is_empty(): return {"ok":false,"error":str(plan.error)}
	result.merge({"owner":player,"spell":spell,"spell_uid":spell.uid,"spell_id":spell.card_id,"canonical":canonical.duplicate(true),"listeners":listeners,"used":{},"resolved":false,"consumed":false,"dispatch_source":{},"round":engine.state.round,"command_sequence":engine.state.command_sequence,"command":command},true)
	return result

static func resolve_cast(engine, player: Dictionary, spell: Dictionary, context: Dictionary) -> String:
	if not context.has("listeners"): return ""
	if not is_same(context,engine._weaver_cast_context) or not is_same(context.get("owner"),player) or not is_same(context.get("spell"),spell): return "forsaken_weaver_invalid_resolved_cast"
	if _contains_same(player.get("hand",[]),spell): return "forsaken_weaver_unconsumed_hand_cast"
	var budget: int = 0
	for entry in context.listeners:
		var source: Dictionary = entry.source
		if _contains_same(player.get("board",[]),source) and not inactive(source): budget += int(PROGRAMS[source.card_id][0].attack)
	if budget > 0:
		var plan: Dictionary = Army.recruit_attack_plan(player,budget)
		if not str(plan.error).is_empty(): return str(plan.error)
	context.resolved = true
	return ""

static func on_cast(engine, player: Dictionary, source: Dictionary, spell: Dictionary, context: Dictionary = {}) -> String:
	if not claimed(source): return ""
	var issue: String = play_error(engine,player,source)
	if not issue.is_empty(): return issue
	if inactive(source) or not _contains_same(player.get("board",[]),source): return ""
	var canonical: Dictionary = engine.catalog.get_card(str(spell.get("card_id","")))
	if not engine.Mechanisms.is_tavern_spell_card(canonical): return ""
	if context.is_empty() or not is_same(context,engine._weaver_cast_context): return "forsaken_weaver_requires_actual_hand_cast"
	if not Exact._same(context.get("resolved"),true) or not Exact._same(context.get("consumed"),false): return "forsaken_weaver_unresolved_or_consumed_cast"
	if not is_same(context.get("command"),engine._weaver_command_context) or not is_same(context.get("dispatch_source"),source): return "forsaken_weaver_outside_current_listener_slot"
	if not is_same(context.get("owner"),player) or not is_same(context.get("spell"),spell): return "forsaken_weaver_wrong_owner_or_cast_reference"
	if engine.state.get("phase") != "recruit" or not _contains_same(engine.state.get("players",[]),player): return "forsaken_weaver_outside_owner_recruit"
	if not Exact._same(context.get("round"),engine.state.round) or not Exact._same(context.get("command_sequence"),engine.state.command_sequence): return "forsaken_weaver_stale_cast"
	if not Exact._same(context.get("spell_uid"),spell.get("uid")) or not Exact._same(context.get("spell_id"),spell.get("card_id")): return "forsaken_weaver_changed_cast_identity"
	if not Exact._same(context.get("canonical"),canonical) or not Exact._same(spell.get("kind"),"spell") or not Exact._same(spell.get("effects"),canonical.get("effects")): return "forsaken_weaver_changed_cast_program"
	if _contains_same(player.get("hand",[]),spell): return "forsaken_weaver_unconsumed_hand_cast"
	if not context.get("listeners") is Array or not context.get("used") is Dictionary: return "forsaken_weaver_invalid_cast_context"
	var witness: Dictionary = {}
	for entry in context.listeners:
		if entry is Dictionary and is_same(entry.get("source"),source): witness = entry; break
	if witness.is_empty() or not Exact._same(witness.get("uid"),source.uid) or not Exact._same(witness.get("card_id"),source.card_id): return "forsaken_weaver_source_creation_timing_unreviewed"
	if context.used.has(source.uid): return "forsaken_weaver_listener_replay"
	var effect: Dictionary = PROGRAMS[source.card_id][0]
	var planned: Dictionary = Army.recruit_attack_plan(player,effect.attack)
	if not str(planned.error).is_empty(): return str(planned.error)
	context.used[source.uid] = true
	var changed: Dictionary = Army.add_recruit_attack(player,effect.attack)
	if not str(changed.error).is_empty(): return str(changed.error)
	engine._log("forsaken_weaver_army",changed.event.merged({"player":player.id,"source_uid":source.uid,"source_id":source.card_id,"cast_uid":spell.uid,"cast_id":spell.card_id},true))
	return ""
