extends RefCounted
const TurnDeath=preload("res://core/turn_recruit_death_sources.gd")
const Sources=preload("res://core/milestone_hero_sources.gd")
const Trade=preload("res://core/trade_hero_resources.gd")
const Resources=preload("res://core/bulk_random_resource_host.gd")
const Gains=preload("res://core/attack_gain_listeners.gd")
const Additive=preload("res://core/tavern_spell_amplifier_host.gd")
const Threshold=preload("res://core/threshold_damage_listeners.gd")
const Expiry=preload("res://core/prize_buff_effects.gd")
const CONTEXT: String="ini_actual_death_contexts"
const PROGRESS: String="native_death_hero_progress"
const FAMILY: String="actual-friendly-death-hero-progress-v1"
var _contexts: Array=[{},{}]
var _states: Array=[{},{}]
var _consumed: Dictionary={}
var _events: Array=[]
var _sealed: Array=[]
var _seed: int=0
var _completed: bool=false
var _authenticated: bool=false
var _used: bool=false
var _owners: Array=[]
var _settlement: Array=[]
var _cursor: int=0

static func player_error(player: Dictionary,catalog) -> String:
	return Trade.player_error(player,catalog) if Sources.accepts_id(player.get("hero_id")) else ""

static func attach(options: Dictionary,left: Dictionary,right: Dictionary,catalog) -> String:
	var contexts: Array=[]
	for owner in [left,right]:
		if owner.get("hero_id")!=Sources.INI: contexts.append({});continue
		var issue: String=Trade.player_error(owner,catalog)
		if not issue.is_empty(): return issue
		contexts.append({"owner_id":int(owner.id),"hero_id":Sources.INI,"power_id":Sources.POWERS[Sources.INI],"state":owner[Trade.STATE].duplicate(true)})
	options[CONTEXT]=contexts
	return ""

func initialize(engine) -> String:
	var contexts: Variant=engine._options.get(CONTEXT,[{},{}])
	if not contexts is Array or contexts.size()!=2: return "ini_invalid_contexts"
	for side in range(2):
		var context: Variant=contexts[side]
		if not context is Dictionary: return "ini_invalid_context"
		if context.is_empty(): continue
		if context.size()!=4 or context.get("hero_id")!=Sources.INI or context.get("power_id")!=Sources.POWERS[Sources.INI] or not Trade.integer(context.get("owner_id")): return "ini_changed_context"
		var saved: Variant=context.get("state")
		if not saved is Dictionary or saved.size()!=5 or not Trade.integer(saved.get("version"),1,1) or saved.get("owner_id")!=context.owner_id or saved.get("hero_id")!=Sources.INI or not Trade.integer(saved.get("progress"),0,8) or not saved.get("completed") is bool or saved.completed: return "ini_invalid_initial_progress"
		if not engine._options.get("left_hand" if side==0 else "right_hand") is Array: return "ini_requires_complete_actual_hand"
		_contexts[side]=context.duplicate(true);_states[side]=saved.duplicate(true)
	return ""

func removed_death_batch(engine,queue: Array) -> bool:
	for entry in queue:
		var side: int=int(entry.side)
		if _contexts[side].is_empty(): continue
		var dead: Dictionary=entry.unit
		var sequence: int=int(entry.get("milestone_death_sequence",-1))
		var key: String=str(side)+":"+str(dead._combat_id)
		if sequence<0 or sequence>=engine._log.size() or _consumed.has(key) or engine._boards[side].any(func(unit):return is_same(unit,dead)): engine._fail("ini_requires_unique_actual_removed_death");return false
		var actual: Dictionary=engine._log[sequence]
		if actual.get("event")!="death" or actual.get("side")!=side or actual.get("unit")!=dead.get("uid"): engine._fail("ini_changed_actual_death_receipt");return false
		_consumed[key]=true
		var before: Dictionary=_states[side].duplicate(true)
		var after: Dictionary=before.duplicate(true)
		var grant: bool=int(before.progress)==8
		after.progress=(int(before.progress)+1)%9
		_states[side]=after
		var event_sequence: int=engine._log.size()
		engine._emit(PROGRESS,{"type":PROGRESS,"milestone_hero_family":FAMILY,"side":side,"owner_id":_contexts[side].owner_id,"source_id":Sources.INI,"before":before,"after":after.duplicate(true),"death_sequence":sequence,"dead_uid":dead.uid,"dead_combat_id":dead._combat_id,"grant":grant,"policy":Sources.DEATH_POLICY})
		if not engine._error.is_empty(): return false
		_events.append(engine._log[event_sequence].duplicate(true))
		if grant:
			engine._bulk_resource_host.activate(engine,side,Sources.actor(int(_contexts[side].owner_id)),Sources.INI_LEAF.duplicate(true))
			if not engine._error.is_empty(): return false
	return true

func complete(engine) -> void:
	_completed=true;_seed=engine._seed;_sealed=engine._log.duplicate(true)
static func result_claimed(events: Array) -> bool:
	return events.any(func(event):return event is Dictionary and (event.has("milestone_hero_family") or event.get("event")==PROGRESS))
func authenticate(result: Dictionary,left: Dictionary,right: Dictionary,ghost: bool) -> String:
	if _used or _authenticated or not _completed or result.get("seed")!=_seed or result.get("log")!=_sealed or result.get("error")!="" or _sealed.is_empty() or _sealed[-1].get("event")!="combat_end": return "ini_not_actual_successful_result"
	_owners=[left,right]
	for side in range(2):
		if _contexts[side].is_empty() or ghost and side==1: continue
		if _owners[side].get("id")!=_contexts[side].owner_id or _owners[side].get("hero_id")!=Sources.INI or _owners[side].get(Trade.STATE)!=_contexts[side].state: return "ini_changed_owner_progress"
	_settlement=_events.filter(func(event):return not (ghost and event.side==1))
	_authenticated=true
	return ""
func commit_progress(owner: Dictionary,event: Dictionary) -> String:
	if _used or not _authenticated or _cursor>=_settlement.size() or event!=_settlement[_cursor]: return "ini_stale_or_replayed_settlement_event"
	var side: int=int(event.side)
	if not is_same(owner,_owners[side]) or owner.get("id")!=_contexts[side].owner_id or owner.get("hero_id")!=Sources.INI or owner.get(Trade.STATE)!=event.get("before"): return "ini_changed_settlement_owner"
	_cursor+=1
	owner[Trade.STATE]=event.after.duplicate(true)
	return ""
func finish() -> String:
	if _used or not _authenticated or _cursor!=_settlement.size(): return "ini_unfinished_settlement"
	_used=true;_owners=[]
	return ""

# A receipt is the actual Game.events object emitted by the real destruction
# commit. Replay protection is private to this Game, not copied into a card.
static func after_recruit_death(engine,player: Dictionary,victim: Dictionary,receipt: Dictionary) -> String:
	if player.get("hero_id")!=Sources.INI: return ""
	var issue: String=Trade.player_error(player,engine.catalog)
	if not issue.is_empty(): return issue
	if (engine.state.get("phase")!="recruit" and not TurnDeath.window_active(engine,player)) or not Trade.integer(player.get("id"),0,engine.state.players.size()-1) or not is_same(engine.state.players[int(player.id)],player): return "ini_requires_actual_recruit_owner"
	var receipt_index: int=-1
	for index in range(engine.events.size()):
		if is_same(engine.events[index],receipt): receipt_index=index;break
	if receipt_index<0 or receipt.get("type")!="recruit_death" or receipt.get("player")!=player.id or receipt.get("uid")!=victim.get("uid") or receipt.get("card_id")!=victim.get("card_id") or receipt.get("round")!=engine.state.round or player.board.any(func(unit):return is_same(unit,victim)): return "ini_requires_actual_recruit_death_receipt"
	return _after_removed_death(engine,player,victim,receipt_index)

# Share only the reward payload with recruit deaths. The original recruit
# guards above remain unchanged; actual Rally records are separately issued.
static func after_owned_rally_death(engine,player: Dictionary,authority: Dictionary,wave: Dictionary,record: Dictionary) -> String:
	if player.get("hero_id")!=Sources.INI: return ""
	var issue: String=Trade.player_error(player,engine.catalog)
	if not issue.is_empty(): return issue
	issue=engine.OwnedRallyEOT.Damage.Removed._record_error(engine,player,authority,wave,record)
	if not issue.is_empty(): return issue
	if engine.state.get("phase")!="end_turn" or not Trade.integer(player.get("id"),0,engine.state.players.size()-1) or not is_same(engine.state.players[int(player.id)],player): return "ini_requires_actual_owned_rally_owner"
	return _after_removed_death(engine,player,record.source,int(record.receipt_index))

static func _after_removed_death(engine,player: Dictionary,victim: Dictionary,receipt_index: int) -> String:
	var key: String=str(engine.state.round)+":"+str(engine.state.command_sequence)+":"+str(receipt_index)+":"+str(victim.uid)
	if engine._milestone_recruit_death_used.has(key): return "ini_replayed_recruit_death"
	engine._milestone_recruit_death_used[key]=true
	var progress: int=int(player[Trade.STATE].progress)+1
	var grant: bool=progress==9
	player[Trade.STATE].progress=progress%9
	engine._log(PROGRESS,{"player":player.id,"source_id":Sources.INI,"dead_uid":victim.uid,"progress":player[Trade.STATE].progress,"grant":grant,"phase":engine.state.phase,"policy":Sources.DEATH_POLICY})
	if not grant: return ""
	var domain: Dictionary=Resources.domain(engine)
	if Resources.candidates(domain,domain.stock,Sources.INI_LEAF).is_empty():
		engine._log("ini_random_mech_empty",{"player":player.id,"policy":Resources.POLICY});return ""
	var reward: Dictionary=Resources.draw_random_minion(engine,Sources.INI_LEAF)
	if reward.is_empty(): return "ini_recruit_mech_factory_failed"
	engine._add_hand(player,reward)
	return "ini_recruit_mech_delivery_failed" if engine.state.phase=="error" else ""

static func end_turn(engine,player: Dictionary) -> String:
	if player.get("hero_id")!=Sources.RAGNAROS: return ""
	var issue: String=Trade.player_error(player,engine.catalog)
	if not issue.is_empty(): return issue
	if not player[Trade.STATE].completed: return ""
	if engine.state.phase!="end_turn" or not is_same(engine.state.players[int(player.id)],player): return "sulfuras_requires_actual_end_turn_owner"
	if player.board.is_empty(): return ""
	var seen: Dictionary={}
	for unit in player.board:
		if not unit.get("uid") is String or str(unit.uid).is_empty() or seen.has(unit.uid): return "sulfuras_duplicate_board_uid"
		seen[unit.uid]=true
	var before: Dictionary=player.duplicate(true)
	var shadow: Dictionary=player.duplicate(true)
	var totals: Dictionary=engine._attack_gain_health_totals.duplicate(true)
	var totals_before: Dictionary=totals.duplicate(true)
	var steps: Array=[]
	# Endpoints are two ordered operations, including the same UID twice on a
	# one-minion board. The entire two-operation payload is preflighted first.
	for index in [0,shadow.board.size()-1]:
		var target: Dictionary=shadow.board[index]
		var old_attack: int=Gains.attack_value(target)
		if Gains.Received.enabled(engine.room):
			issue=Gains.Received.adjust_error(target,8,8)
			if not issue.is_empty(): return issue
		issue=Additive._apply_delta(target,int(player.id),8,8)
		if not issue.is_empty(): return issue
		if Gains.attack_value(target)>old_attack:
			var reactions: Dictionary=Gains.reaction_plan(shadow.board,target,Gains.Received.enabled(engine.room))
			if not reactions.ok: return str(reactions.error)
			for reaction in reactions.records:
				var total: int=int(totals.get(reaction.target_uid,0))
				if total<0 or total>Gains.MAX-int(reaction.health): return "sulfuras_reaction_counter_overflow"
				totals[reaction.target_uid]=total+int(reaction.health)
				var changed: Dictionary=Gains._find(shadow.board,str(reaction.target_uid))
				if changed!=reaction.before: return "sulfuras_reaction_shadow_changed"
				changed.clear();changed.merge(reaction.after.duplicate(true),true)
		issue=Threshold.project_recruit_check(shadow,target,engine.catalog)
		if not issue.is_empty(): return issue
		for member in shadow.board+shadow.shop:
			if member.get("kind")!="minion": continue
			issue=Expiry._expiry_error(member,int(player.id))
			if not issue.is_empty(): return issue
		steps.append({"target_uid":target.uid,"board_after":shadow.board.duplicate(true),"shop_after":shadow.shop.duplicate(true),"totals_after":totals.duplicate(true)})
	if player!=before or engine._attack_gain_health_totals!=totals_before: return "sulfuras_stale_plan"
	for step in steps:
		var target: Dictionary=Gains._find(player.board,str(step.target_uid))
		engine._buff(target,8,8)
		if engine.state.phase=="error": return "sulfuras_actual_buff_failed"
		if player.board!=step.board_after or player.shop!=step.shop_after or engine._attack_gain_health_totals!=step.totals_after: return "sulfuras_actual_shadow_mismatch"
		engine._log("sulfuras_end_turn_buff",{"player":player.id,"source_id":Sources.RAGNAROS,"power_id":Sources.SULFURAS,"target_uid":target.uid,"attack_delta":8,"health_delta":8,"policy":Sources.EOT_POLICY})
	return ""
