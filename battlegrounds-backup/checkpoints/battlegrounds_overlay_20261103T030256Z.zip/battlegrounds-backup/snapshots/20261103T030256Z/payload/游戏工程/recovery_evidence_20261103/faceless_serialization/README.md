# Faceless serialization recovery

Date: 2026-11-03. Godot 4.6.3.stable.official.7d41c59c4.

## Root cause and fix

The real Game smoke reached start, buy, and native save, then fresh load visited JSON player records in Faceless.serialized_error. JSON numeric IDs are floats; directly comparing such an ID to the portrait String raises a GDScript runtime error. The recursive validator must inspect unrelated dictionaries without assuming their id/type fields are Strings.

core/faceless_sources.gd now uses its existing strict type-aware same() for six String comparisons: generic marker type, effect type, native unit kind, serialized portrait ID, portrait choice kind, and serialized leaf type. Nothing is string-coerced. Native source/program validation and recursive traversal are unchanged. Non-Faceless numeric records are ignored; malformed actual Faceless records still return explicit errors.

## Regression

Run: sh recovery_evidence_20261103/faceless_serialization/run.sh

The isolated project copies the actual full faceless_sources.gd and its two actual small dependencies (phase_undead_army_sources.gd and pool_identity.gd), without stubs or Game. It uses private /tmp HOME and XDG directories.

- Before fix: same 59 checks, 17 failures, repeated mixed-type SCRIPT ERRORs, exit 1 (baseline.log).
- After fix: 59 checks, 0 failures, no SCRIPT ERROR, exit 0 (test.log).

Checks cover numeric JSON player/event IDs; varied unrelated field types; valid complete portrait source, offer and JSON round trip; valid native normal/golden units and JSON round trips; nested valid/malformed effects; malformed portrait choice kinds and native unit kinds; and continued rejection of malformed nested Faceless data behind numeric outer fields.

This is serialization-helper regression evidence, not a full Game load or card gameplay acceptance. The parent owns the actual smoke retry and separate Game catalog-binding fix. changes.patch and source_hashes.json preserve the exact delta.
