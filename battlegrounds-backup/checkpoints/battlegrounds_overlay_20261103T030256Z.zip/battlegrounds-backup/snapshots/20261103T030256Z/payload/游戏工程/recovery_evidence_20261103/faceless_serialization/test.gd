extends SceneTree
const Sources=preload("res://core/faceless_sources.gd")
var checks: int=0
var failures: int=0
func expect(value: bool,label: String) -> void:
 checks+=1
 if not value:
  failures+=1
  printerr("FAIL: "+label)
func _init() -> void:
 var unrelated=JSON.parse_string('{"state":{"players":[{"id":0,"board":[],"hand":[]},{"id":1,"health":60}],"round":1},"events":[{"id":19,"type":4.5}],"other":[0,true,null,"hello"]}')
 expect(unrelated.state.players[0].id is float,"fixture contains real JSON float IDs")
 expect(Sources.serialized_error(unrelated).is_empty(),"numeric player/event IDs accepted without runtime exception")
 var primitives: Array=[null,0,0.5,-1.5,true,false,"",[],{},[0,1]]
 for value in primitives:
  expect(Sources.serialized_error({"id":value,"type":value,"card_id":value,"uid":"generic","effects":[]}).is_empty(),"unrelated mixed field types "+str(value))
  expect(not Sources.marker({"id":value,"type":value,"source_id":value,"effects":[]}),"mixed unrelated marker types "+str(value))
 var portrait: Dictionary=Sources.RAW[Sources.PORTRAIT].duplicate(true)
 portrait.merge(Sources.EXPECTED[Sources.PORTRAIT],true)
 expect(Sources.serialized_error(portrait).is_empty(),"valid full portrait source")
 var offer: Dictionary=portrait.duplicate(true);offer.choice_kind="trinket"
 expect(Sources.serialized_error(offer).is_empty(),"valid portrait offer")
 expect(Sources.serialized_error(JSON.parse_string(JSON.stringify(offer))).is_empty(),"valid portrait offer JSON round trip")
 for wrong in [0,0.5,true,null,[],{},"minion"]:
  var bad: Dictionary=offer.duplicate(true);bad.choice_kind=wrong
  expect(Sources.serialized_error({"nested":[bad]})=="faceless_portrait_offer_kind_changed","wrong portrait choice kind rejected "+str(wrong))
 var bad_source: Dictionary=portrait.duplicate(true);bad_source.name="changed"
 expect(Sources.serialized_error([{"nested":[bad_source]}])=="faceless_whole_source_changed","nested malformed source still rejected")
 for id in Sources.MINIONS:
  var unit: Dictionary=Sources.native_template(id)
  unit.uid="unit-"+id
  expect(Sources.serialized_error(unit).is_empty(),"valid native unit "+id)
  expect(Sources.serialized_error(JSON.parse_string(JSON.stringify(unit))).is_empty(),"valid native unit JSON round trip "+id)
  var leaf: Dictionary=Sources.PROGRAMS[id][0].duplicate(true)
  expect(Sources.serialized_error([{"nested":[leaf]}]).is_empty(),"valid nested leaf "+id)
  leaf.count=2
  expect(Sources.serialized_error([{"nested":[leaf]}])=="faceless_native_effect_changed","changed nested leaf rejected "+id)
  var bad_unit: Dictionary=unit.duplicate(true);bad_unit.effects=[]
  expect(Sources.serialized_error(bad_unit)=="faceless_program_changed","missing native effects rejected "+id)
  for wrong in [0,0.5,true,null,[],{}]:
   bad_unit=unit.duplicate(true);bad_unit.kind=wrong
   expect(Sources.serialized_error(bad_unit)=="faceless_identity_changed","bad native kind rejected "+id+" "+str(wrong))
  bad_unit=unit.duplicate(true);bad_unit.effects[0].type=0.5
  expect(Sources.serialized_error(bad_unit)=="faceless_program_changed","numeric native effect marker rejected "+id)
 expect(Sources.effect_error({"type":0.5})=="faceless_native_effect_changed","numeric effect type safely rejected")
 expect(Sources.serialized_error({"id":0.0,"type":0.0,"nested":{"type":Sources.TYPE,"count":99}})=="faceless_native_effect_changed","numeric outer fields do not hide nested malformed leaf")
 print("FACELESS_SERIALIZATION_RECOVERY checks=%d failures=%d"%[checks,failures])
 quit(1 if failures else 0)
