extends RefCounted
const Exact=preload("res://core/board_aura_effects.gd")
## Independently defined normal/golden Mutated Lasher; written_unverified.
const TYPE: String = "deathrattle_mutated_lasher"
const IDS: Array = ["BG31_852", "BG31_852_G"]
const LAYER: String = "__mutated_lasher_odd_tier"
const PROGRAMS: Dictionary = {
	"BG31_852": [{"type":"deathrattle_mutated_lasher","source_id":"BG31_852","attack":3,"health":3,"duration":"combat","tier_parity":"odd"}],
	"BG31_852_G": [{"type":"deathrattle_mutated_lasher","source_id":"BG31_852_G","attack":6,"health":6,"duration":"combat","tier_parity":"odd"}]
}
const NATIVE_TEXT: Dictionary = {
	"BG31_852":"亡语： 在本场战斗的剩余时间内，你的奇数等级的随从拥有+3/+3。",
	"BG31_852_G":"亡语： 在本场战斗的剩余时间内，你的奇数等级的随从拥有+6/+6。"
}
const NATIVE_BODY: Dictionary = {"BG31_852":[9,3],"BG31_852_G":[18,6]}
static func identity(unit: Dictionary) -> String:
	return str(unit.get("card_id", unit.get("id", "")))
static func claimed(unit: Dictionary) -> bool:
	if identity(unit) in IDS: return true
	var effects: Variant = unit.get("effects",[])
	return effects is Array and effects.any(func(effect): return effect is Dictionary and effect.get("type") == TYPE)
static func effect_error(effect: Dictionary) -> String:
	var id: String = str(effect.get("source_id", ""))
	return "" if id in IDS and Exact.same(effect,PROGRAMS[id][0]) else "mutated_lasher_changed_native_leaf"
static func program_error(unit: Dictionary) -> String:
	var id: String = identity(unit)
	if id not in IDS or not Exact.same(unit.get("effects"),PROGRAMS[id]): return "mutated_lasher_changed_complete_native_program"
	if unit.get("kind", "minion") != "minion": return "mutated_lasher_wrong_kind"
	if unit.get("golden", unit.get("is_golden", false)) != (id == "BG31_852_G"): return "mutated_lasher_changed_native_variant"
	return ""
static func apply_overlay(cards: Dictionary) -> String:
	var data: Variant = JSON.parse_string(FileAccess.get_file_as_string("res://data/mutated_lasher_overlay.json"))
	if not data is Dictionary or not data.get("cards") is Array or data.cards.size() != IDS.size(): return "mutated_lasher_missing_overlay"
	var merged_rows: Dictionary = {}
	for row in data.cards:
		if not row is Dictionary or row.get("id") not in IDS or not cards.has(row.id) or merged_rows.has(row.id): return "mutated_lasher_missing_native_identity"
		var native: Dictionary = cards[row.id]
		if native.get("text") != NATIVE_TEXT[row.id] or native.get("attack") != NATIVE_BODY[row.id][0] or native.get("health") != NATIVE_BODY[row.id][1]: return "mutated_lasher_changed_independent_source"
		var merged: Dictionary = native.duplicate(true)
		merged.merge(row, true)
		var issue: String = program_error(merged)
		if not issue.is_empty(): return issue
		merged.quality_flags = merged.get("quality_flags", []).duplicate()
		merged.quality_flags.erase("effect_not_implemented")
		merged_rows[row.id] = merged
	for id in IDS: cards[id] = merged_rows[id]
	return ""
