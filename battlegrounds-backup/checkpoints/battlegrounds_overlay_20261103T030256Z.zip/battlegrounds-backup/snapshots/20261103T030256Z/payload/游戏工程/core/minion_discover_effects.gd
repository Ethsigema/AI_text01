extends RefCounted
const Domain=preload("res://core/minion_discover_domain.gd")
const PatientScoutTransport=preload("res://core/patient_scout_discover.gd")
const Clunker=preload("res://core/clunker_discover_host.gd")
const XaviusGift=preload("res://core/xavius_dark_gift_host.gd")
const DarkGift=preload("res://core/dark_gift_hero_host.gd")
const HeroTrinkets=preload("res://core/hero_trinket_turn_host.gd")
const Faelin=preload("res://core/faelin_deferred_host.gd")
const Thorim=preload("res://core/thorim_deferred_host.gd")
const BarovWager=preload("res://core/barov_wager_host.gd")
const Brukan=preload("res://core/brukan_elements_host.gd")
const Galewing=preload("res://core/galewing_host.gd")
const ScabbsSpy=preload("res://core/scabbs_spy_host.gd")
const GalakrondReplace=preload("res://core/galakrond_replace_host.gd")
const CookiePot=preload("res://core/cookie_pot_host.gd")
const HolmesGuess=preload("res://core/holmes_guess_host.gd")
const ReclaimedSouls=preload("res://core/reclaimed_souls_host.gd")
const HandLocks=preload("res://core/hand_lock_host.gd")
const WarpDiscover=preload("res://core/timewarp_minion_discover.gd")
const LockedTimewarp=preload("res://core/locked_timewarp_discover.gd")
const PrizeResources=preload("res://core/prize_resource_host.gd")
const PrizeChain=preload("res://core/prize_chain_host.gd")
const OwnedTurnResources=preload("res://core/owned_turn_resource_host.gd")
const Bigglesworth=preload("res://core/bigglesworth_host.gd")
const OpponentDiscover=preload("res://core/opponent_discover_host.gd")
const HighDiscover=preload("res://core/high_minion_discover.gd")
const OwnedMinionDiscover=preload("res://core/owned_minion_discover.gd")
const BulkDiscover = preload("res://core/bulk_recruit_discover_effects.gd")
const TrinketDiscover=preload("res://core/trinket_discover_resources.gd")
const GeneratedDiscover = preload("res://core/generated_tier7_discover.gd")
## Existing recruit Discover, exact filtered spells/leaves, and Millificent hero.
const RecruitEvents = preload("res://core/recruit_events.gd")
const Exact = preload("res://core/end_turn_repeats.gd")
const PoolIdentity = preload("res://core/pool_identity.gd")
const PARTNER_IDS: Array = ["BG26_355t2","BG26_355_Gt2"]
const PARTNER_FOLDER: String = "res://research/partner_up_sources/"
const PARTNER_FILES: Dictionary = {"expected_compiled.json":"e91732992e072d66122f6d068f3bf54ead86bc0d4a0516df4216d29a473091ba","native/archive_BG26_355_Gt2.xml":"b4b03774bb3c4bd16c01b0f29d711ed719e9f4cde45574e6ba761569547de88e","native/archive_BG26_355t2.xml":"5704d0b65e912f63b8daac05f54b0a0caa494cd576776fbee0a3d8f91de5a6d9","native/latest_BG26_355_Gt2.xml":"d3964718bf8a507ba655e1fe6f7a4a764d34a2d15d046b6d2f7ba719cf14ec91","native/latest_BG26_355t2.xml":"96b4c10d65222a2774e82b369240e8a78a273a44c87196b49148cd3db858244c","raw49/BG26_355_Gt2.json":"04cd13bb2a1043c554cebb9c80be37c08e8973f75f6697155ccafb77e1874f80","raw49/BG26_355t2.json":"448450803c7dafc723e439b9eb607286c4dda3bb948a58ec406e14e56baf4b35","source_contract.json":"a001dae4191456e4250cc4f8c9f2e93d09108d887d09636e8b94465f5612704f"}
const FILTERED_SPELLS: Dictionary = {
	"BG28_882":{"dbf_id":"105265","name":"预订遗体","text":"发现一张亡语随从牌。","effect_filter":"deathrattle"},
	"BG28_GIL_836":{"dbf_id":"105264","name":"猎头招聘","text":"发现一张战吼随从牌。","effect_filter":"battlecry"},
	"BG26_355t2":{"dbf_id":"100946","name":"新伙伴上台","text":"发现一张战吼随从牌。","effect_filter":"battlecry"},
	"BG26_355_Gt2":{"dbf_id":"100948","name":"新伙伴上台","text":"发现2张战吼随从牌。","effect_filter":"battlecry"}
}
const EFFECT_FILTERS: Array = ["battlecry", "deathrattle"]
const TYPES: Array = ["battlecry_discover_minion", "on_sell_discover_minion"]
const TRIBES: Array = ["", "野兽", "恶魔", "龙", "元素", "机械", "鱼人", "纳迦", "海盗", "野猪人", "亡灵"]

const MAGNETIC_HERO: String = "TB_BaconShop_HERO_17"

static func magnetic_hero_program() -> Array:
	return [{"type":"hero_discover","tribe":"机械","min_tier":4,"keyword_filter":"magnetic"}]

static func magnetic_hero_source_error(card: Dictionary) -> String:
	var identity: Variant = card.get("id")
	var claimed: bool = identity is String and identity == MAGNETIC_HERO
	var effects: Variant = card.get("effects")
	if effects is Array:
		for effect in effects:
			if effect is Dictionary and effect.get("type")=="hero_discover" and effect.has("keyword_filter"): claimed = true
	if not claimed: return ""
	for pair in [["id",MAGNETIC_HERO],["dbf_id","57946"],["name","米尔菲丝·法力风暴"],["text","修补匠（1费）：发现一个磁力机械。（等级4时解锁。）"],["kind","hero"],["category","英雄池"]]:
		if not card.get(pair[0]) is String or card[pair[0]] != pair[1]: return "Magnetic Discover requires the complete native Millificent hero identity/text."
	for pair in [["health",30],["armor",15],["power_cost",1]]:
		if not integer(card.get(pair[0])) or card[pair[0]] != pair[1]: return "Millificent native health, solo Armor, or power cost drift."
	if not card.get("is_golden") is bool or card.is_golden or not card.get("solo_eligible") is bool or not card.solo_eligible or not card.get("duos_exclusive") is bool or card.duos_exclusive or not card.get("requires_teammate_effect") is bool or card.requires_teammate_effect: return "Millificent requires the ordinary solo hero source."
	if not effects is Array or effects != magnetic_hero_program() or not card.get("keywords") is Array or card.keywords != []: return "Millificent requires its exact whole native power program."
	return validate_effect(effects[0])

static func magnetic_hero_power_error(engine, player: Dictionary) -> String:
	var identity: Variant = player.get("hero_id")
	if not identity is String: return "Magnetic Discover requires a String hero identity."
	if identity != MAGNETIC_HERO: return ""
	var issue: String = magnetic_hero_source_error(engine.catalog.get_card(MAGNETIC_HERO))
	if not issue.is_empty(): return issue
	# Source-specific empty-pool outcome is not established. Reject
	# only this action before payment, use counters, entity allocation or RNG.
	if engine._discover_candidates(player,-1,"机械","","magnetic").is_empty(): return "此技能当前没有合法磁力机械库存；空池补偿尚未核实，未消耗铸币或技能次数。"
	return ""

static func matches_keyword_filter(card: Dictionary, keyword_filter: Variant) -> bool:
	if not keyword_filter is String: return false
	if keyword_filter.is_empty(): return true
	if keyword_filter != "magnetic" or not card.get("kind") is String or card.kind != "minion": return false
	if not card.get("supported") is bool or not card.supported or not card.get("is_golden") is bool or card.is_golden: return false
	if not card.get("keywords") is Array: return false
	for keyword in card.keywords:
		if not keyword is String: return false
	# Printed source keyword only; owned/granted keywords and ReferencedTag are
	# not candidate declarations. Existing _tribe_match independently checks Mech.
	return "magnetic" in card.keywords

static func filtered_program(identity: String) -> Array:
	if not FILTERED_SPELLS.has(identity): return []
	var program: Array = [{"type":"spell_discover","tier":-1,"tribe":"","effect_filter":FILTERED_SPELLS[identity].effect_filter}]
	if identity == "BG26_355_Gt2": program[0].count = 2
	return program

static func filtered_source_error(card: Dictionary, evidence: Dictionary = {}) -> String:
	var identity: Variant = card.get("id")
	var claimed: bool = identity is String and FILTERED_SPELLS.has(identity)
	var effects: Variant = card.get("effects")
	if effects is Array:
		for effect in effects:
			if effect is Dictionary and effect.get("type")=="spell_discover" and effect.has("effect_filter"): claimed = true
	if not claimed: return ""
	if not identity is String or not FILTERED_SPELLS.has(identity): return "Filtered Discover requires a complete registered native source identity."
	if partner_id(identity): return partner_source_error(card,evidence)
	var spec: Dictionary = FILTERED_SPELLS[identity]
	for key in ["dbf_id","name","text"]:
		if not card.get(key) is String or card[key] != spec[key]: return "Filtered Discover source identity/text drift: " + key
	if not card.get("kind") is String or card.kind != "spell" or not card.get("category") is String or card.category != "酒馆": return "Filtered Discover requires its ordinary Tavern spell source."
	if not card.get("categories") is Array or card.categories != ["酒馆"] or not card.get("is_golden") is bool or card.is_golden: return "Filtered Discover requires its ordinary Tavern spell source."
	if not integer(card.get("tier")) or card.tier != 5 or not integer(card.get("cost")) or card.cost != 3: return "Filtered Discover native tier/cost drift."
	if not effects is Array or effects.size() != 1 or not effects[0] is Dictionary: return "Filtered Discover requires the exact whole source program."
	var issue: String = validate_effect(effects[0])
	if not issue.is_empty(): return issue
	if effects != filtered_program(identity) or not card.get("keywords") is Array or card.keywords != [] or not card.get("temporary") is bool or card.temporary: return "Filtered Discover requires the exact whole source program."
	return ""

static func filtered_play_error(engine, player: Dictionary, source: Dictionary) -> String:
	var identity: Variant = source.get("card_id")
	var claimed: bool = identity is String and FILTERED_SPELLS.has(identity)
	var effects: Variant = source.get("effects")
	if effects is Array:
		for effect in effects:
			if effect is Dictionary and effect.get("type")=="spell_discover" and effect.has("effect_filter"): claimed = true
	if not claimed: return ""
	if not identity is String or not FILTERED_SPELLS.has(identity): return "Filtered Discover source identity is invalid."
	if not source.get("kind") is String or source.kind != "spell" or not effects is Array or effects.size() != 1 or not effects[0] is Dictionary: return "Filtered Discover requires a complete owned spell."
	var issue: String = validate_effect(effects[0])
	if not issue.is_empty(): return issue
	if not Exact._same(effects,filtered_program(identity)): return "Filtered Discover source/program mismatch."
	if partner_id(identity):
		issue = partner_live_error(source,engine.catalog)
		if not issue.is_empty(): return issue
		# Count stock copies, not distinct offers. This is a pre-consumption
		# conditional admission, not an invented empty-Discover outcome.
		var needed: int = 2 if identity == "BG26_355_Gt2" else 1
		var available: int = 0
		for candidate in engine._discover_candidates(player,-1,"","battlecry"):
			var stock: Variant = engine.pool.get(candidate)
			if not integer(stock) or stock <= 0: return "Partner Up requires valid finite candidate stock."
			available += mini(int(stock),needed-available)
			if available == needed: return ""
		return "Partner Up requires enough eligible stock for every sequential choice; the leaf was not consumed."
	# Read-only public cast preflight. An empty candidate pool is not proof of
	# either no-op or Consolation Coin; keep the owned spell and whole room valid.
	if engine._discover_candidates(player,-1,"",FILTERED_SPELLS[identity].effect_filter).is_empty(): return "此发现当前没有合法库存候选；空池补偿尚未核实，未消耗手牌。"
	return ""


static func partner_id(identity: Variant) -> bool:
	return identity is String and identity in PARTNER_IDS

static func partner_evidence() -> Dictionary:
	for path in PARTNER_FILES:
		if FileAccess.get_sha256(PARTNER_FOLDER+path) != PARTNER_FILES[path]: return {"error":"partner_up_evidence_changed:"+path}
	var contract: Variant = JSON.parse_string(FileAccess.get_file_as_string(PARTNER_FOLDER+"source_contract.json"))
	var expected: Variant = JSON.parse_string(FileAccess.get_file_as_string(PARTNER_FOLDER+"expected_compiled.json"))
	if not contract is Dictionary or not Exact._same(contract.get("source_ids"),PARTNER_IDS) or not contract.get("records") is Dictionary or contract.records.size() != 2 or not expected is Dictionary or expected.size() != 2: return {"error":"partner_up_incomplete_source_closure"}
	var rows: Dictionary = {}
	for identity in PARTNER_IDS:
		var raw: Variant = JSON.parse_string(FileAccess.get_file_as_string(PARTNER_FOLDER+"raw49/"+identity+".json"))
		if not raw is Dictionary or raw.size() != 49 or not Exact._same(raw.get("id"),identity) or not expected.get(identity) is Dictionary or not Exact._same(expected[identity].get("effects"),filtered_program(identity)): return {"error":"partner_up_incomplete_source_program"}
		rows[identity] = raw
	return {"error":"","rows":rows,"expected":expected}

static func partner_raw_error(card: Variant, evidence: Dictionary = {}) -> String:
	if not card is Dictionary or not partner_id(card.get("id")): return "partner_up_unknown_raw_source"
	if evidence.is_empty(): evidence = partner_evidence()
	if not str(evidence.get("error","partner_up_missing_evidence")).is_empty(): return str(evidence.error)
	return "" if Exact._same(card,evidence.rows[card.id]) else "partner_up_complete_raw49_changed"

static func partner_source_error(card: Variant, evidence: Dictionary = {}) -> String:
	if not card is Dictionary or not partner_id(card.get("id")) or card.has("card_id"): return "partner_up_unknown_effective_source"
	if evidence.is_empty(): evidence = partner_evidence()
	if not str(evidence.get("error","partner_up_missing_evidence")).is_empty(): return str(evidence.error)
	var expected: Dictionary = evidence.rows[card.id].duplicate(true)
	expected.merge(evidence.expected[card.id],true)
	if card.has("pool_blocker"): expected.pool_blocker = PoolIdentity.SPELL_REASON
	return "" if Exact._same(card,expected) else "partner_up_complete_source_or_variant_changed"

static func partner_catalog_error(catalog, evidence: Dictionary = {}) -> String:
	if catalog == null: return "partner_up_missing_catalog"
	if evidence.is_empty(): evidence = partner_evidence()
	if not str(evidence.get("error","partner_up_missing_evidence")).is_empty(): return str(evidence.error)
	var canonical = catalog.get("source_catalog")
	if canonical == null: canonical = catalog
	for current in [canonical,catalog]:
		for identity in PARTNER_IDS:
			var issue: String = partner_source_error(current.get_card(identity),evidence)
			if not issue.is_empty(): return issue
	return ""

static func partner_live_error(source: Dictionary, catalog) -> String:
	var identity: Variant = source.get("card_id")
	if not partner_id(identity): return "partner_up_unknown_owned_source"
	var evidence: Dictionary = partner_evidence()
	var issue: String = partner_catalog_error(catalog,evidence)
	if not issue.is_empty(): return issue
	if not source.get("uid") is String or source.uid.is_empty(): return "partner_up_invalid_owned_uid"
	var raw: Dictionary = evidence.rows[identity]
	var golden: bool = identity == "BG26_355_Gt2"
	var expected: Dictionary = {"card_id":identity,"name":raw.name,"kind":"spell","tier":1,"cost":0,"attack":0,"health":1,"max_health":1,"keywords":[],"tribes":[],"golden":golden,"temporary":false,"is_spellcraft":false,"text":raw.text,"image":raw.image,"effects":filtered_program(identity),"attachments":[],"pool_components":[],"temporary_buffs":[],"permanent_keywords":[],"magnetic_tribes":[]}
	for key in expected:
		if not Exact._same(source.get(key),expected[key]): return "partner_up_owned_body_or_program_changed:"+key
	for key in ["id","card_code"]:
		if source.has(key) and not Exact._same(source[key],identity): return "partner_up_owned_identity_changed"
	for key in ["is_golden","variant","normal_id","golden_id","category","categories","quality_flags","source_conflicts"]:
		if source.has(key) and not Exact._same(source[key],raw[key]): return "partner_up_owned_raw_identity_changed"
	for key in ["excluded","stats_conflict","duos_exclusive","requires_teammate_effect"]:
		if not Exact._same(source.get(key,false),false): return "partner_up_owned_gate_changed"
	var base: Dictionary = {"card_id":identity,"name":raw.name,"tier":1,"attack":0,"health":1,"max_health":1,"keywords":[],"tribes":[],"effects":filtered_program(identity),"golden":golden}
	if not Exact._same(source.get("base_unit"),base) or source.has("_base") and not Exact._same(source._base,base): return "partner_up_owned_base_changed"
	return ""

static func matches_effect_filter(card: Dictionary, effect_filter: Variant) -> bool:
	if not effect_filter is String: return false
	if effect_filter.is_empty(): return true # Preserve every unfiltered legacy request.
	if effect_filter not in EFFECT_FILTERS or not card.get("kind") is String or card.kind != "minion": return false
	if not card.get("supported") is bool or not card.supported or not card.get("is_golden") is bool or card.is_golden: return false
	if not card.get("effects") is Array or not card.get("keywords") is Array: return false
	for effect in card.effects:
		if not effect is Dictionary or not effect.get("type") is String: return false
	for keyword in card.keywords:
		if not keyword is String: return false
	# This receives a Catalog-validated printed source, never an owned unit with
	# a temporary/granted Deathrattle. Reuse the recruit host's family semantics;
	# repeat-only passives and listeners are not their own Battlecry/Deathrattle.
	if effect_filter == "battlecry": return RecruitEvents.has_battlecry(card)
	return RecruitEvents.has_deathrattle(card)

static func validate_effect(effect: Dictionary) -> String:
	if effect.get("type")=="hero_discover" and effect.has("keyword_filter"):
		if effect.size() != 4 or not effect.get("type") is String or effect.type != "hero_discover" or not effect.get("tribe") is String or effect.tribe != "机械" or not integer(effect.get("min_tier")) or effect.min_tier != 4 or not effect.keyword_filter is String or effect.keyword_filter != "magnetic": return "Magnetic Discover requires its exact native hero program."
		return ""
	if effect.get("type")=="spell_discover" and effect.has("effect_filter"):
		if effect.size() not in [4,5] or effect.size() == 5 and (not effect.has("count") or not integer(effect.count) or effect.count != 2 or not effect.get("effect_filter") is String or effect.get("effect_filter") != "battlecry") or effect.size() == 4 and effect.has("count") or not effect.get("type") is String or effect.type != "spell_discover" or not integer(effect.get("tier")) or effect.tier != -1 or not effect.get("tribe") is String or effect.tribe != "": return "Filtered Discover requires its complete current-and-below program."
		if not effect.effect_filter is String or effect.effect_filter not in EFFECT_FILTERS: return "Unknown minion Discover effect filter."
		return ""
	if effect.get("type","") not in TYPES: return ""
	if effect.keys().size()!=5: return "随从发现效果必须完整声明五个字段。"
	for key in ["type","tier","tribe","count","condition"]:
		if not effect.has(key): return "随从发现缺少参数："+key
	if not integer(effect.tier) or int(effect.tier) not in [-1,1,2,3,4,5,6]:return "随从发现星级须为当前及以下或1–6。"
	if not effect.tribe is String or effect.tribe not in TRIBES:return "随从发现种族未知。"
	if not integer(effect.count) or int(effect.count)<1 or int(effect.count)>4:return "随从发现次数须为1–4整数。"
	if not effect.condition is String or effect.condition not in ["always","previous_loss"]:return "随从发现条件未知。"
	return ""

static func handle_effect(engine,p: Dictionary,_source: Dictionary,effect: Dictionary,_target: int=-1,_target_zone: String="board") -> bool:
	if effect.get("type","") not in TYPES:return false
	if engine.state.get("phase","") != "recruit":
		engine.state.phase="error"
		engine._log("coverage_error",{"message":"随从发现只支持真实招募阶段的使用或出售。"})
		return true
	var issue: String=validate_effect(effect)
	if not issue.is_empty():
		engine.state.phase="error"
		engine._log("coverage_error",{"message":issue})
		return true
	if effect.condition=="previous_loss" and p.get("last_combat_result","none")!="loss":return true
	for _i in range(int(effect.count)):
		p.discover_queue.append({"tier":int(effect.tier),"tribe":str(effect.tribe)})
	engine._next_discover(p)
	return true

static func integer(value: Variant) -> bool:
	return value is int or (value is float and is_finite(value) and value==floor(value) and value>-9223372036854775808.0 and value<9223372036854775807.0)


static func valid_request(request: Variant) -> bool:
	if PatientScoutTransport.request_claimed(request): return PatientScoutTransport.request_error(request).is_empty()
	if Clunker.request_claimed(request): return Clunker.request_error(request).is_empty()
	if BarovWager.request_claimed(request): return BarovWager.request_error(request).is_empty()
	if Brukan.request_claimed(request): return Brukan.request_error(request).is_empty()
	if Galewing.request_claimed(request): return Galewing.request_error(request).is_empty()
	if OwnedTurnResources.request_claimed(request): return OwnedTurnResources.request_error(request).is_empty()
	if HandLocks.request_claimed(request): return HandLocks.request_error(request).is_empty()
	if HighDiscover.request_claimed(request): return HighDiscover.request_error(request).is_empty()
	if Bigglesworth.request_claimed(request): return Bigglesworth.request_error(request).is_empty()
	if OpponentDiscover.request_claimed(request): return OpponentDiscover.request_error(request).is_empty()
	if ScabbsSpy.request_claimed(request): return ScabbsSpy.request_error(request).is_empty()
	if GalakrondReplace.request_claimed(request): return GalakrondReplace.request_error(request).is_empty()
	if CookiePot.request_claimed(request): return CookiePot.request_error(request).is_empty()
	if HolmesGuess.request_claimed(request): return HolmesGuess.request_error(request).is_empty()
	if ReclaimedSouls.request_claimed(request): return ReclaimedSouls.request_error(request).is_empty()
	if XaviusGift.request_claimed(request): return XaviusGift.request_error(request).is_empty()
	if DarkGift.request_claimed(request): return DarkGift.request_error(request).is_empty()
	if Faelin.request_claimed(request): return Faelin.request_error(request).is_empty()
	if Thorim.request_claimed(request): return Thorim.request_error(request).is_empty()
	if HeroTrinkets.request_claimed(request): return HeroTrinkets.request_error(request).is_empty()
	if PrizeChain.request_claimed(request): return PrizeChain.request_error(request).is_empty()
	if PrizeResources.request_claimed(request): return PrizeResources.request_error(request).is_empty()
	if LockedTimewarp.request_claimed(request): return LockedTimewarp.request_error(request).is_empty()
	if WarpDiscover.request_claimed(request): return WarpDiscover.request_error(request).is_empty()
	if OwnedMinionDiscover.request_claimed(request): return OwnedMinionDiscover.request_error(request).is_empty()
	if TrinketDiscover.request_claimed(request): return TrinketDiscover.request_error(request).is_empty()
	if request is Dictionary and BulkDiscover.request_claimed(request): return BulkDiscover.request_error(request).is_empty()
	if request is Dictionary and GeneratedDiscover.request_claimed(request): return GeneratedDiscover.request_error(request).is_empty()
	if not request is Dictionary:return false
	for key in request:
		if key not in ["tier","tribe","triple_reward","effect_filter"]:return false
	if not integer(request.get("tier")) or int(request.tier) not in [-1,1,2,3,4,5,6]:return false
	if not request.get("tribe") is String or request.tribe not in TRIBES:return false
	if request.has("triple_reward") and not request.triple_reward is bool:return false
	if request.get("triple_reward",false) and (int(request.tier)<2 or not str(request.tribe).is_empty()):return false
	if request.has("effect_filter"):
		if not request.effect_filter is String or request.effect_filter not in EFFECT_FILTERS: return false
		if int(request.tier) != -1 or request.tribe != "" or request.get("triple_reward",false): return false
	return true
