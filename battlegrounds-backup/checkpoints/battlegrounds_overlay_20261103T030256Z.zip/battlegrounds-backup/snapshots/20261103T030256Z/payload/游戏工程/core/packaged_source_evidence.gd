extends RefCounted
## The 2026-11-01 handoff omitted historical human-readable reports, but
## retained their native/XML/JSON proof packets. Only these audited omissions
## are non-fatal. Every original digest remains pinned; a present report with
## different bytes, or any missing/changed machine-readable proof, still fails.
const OMITTED_ANNOTATIONS: Array = [
	"res://research/activate_minion_rules.md",
	"res://research/forsaken_weaver_sources/README.md",
	"res://research/timewarped_anubarak_sources/README.md",
	"res://research/timewarped_start_grants_sources/SOURCE_REPORT.md",
	"res://research/timed_dragon_buff_sources/PROPOSAL.md",
]

static func inspect(folder: String, hashes: Dictionary) -> Dictionary:
	var missing_annotations: Array = []
	for path in hashes:
		var full_path: String = folder + str(path)
		if full_path in OMITTED_ANNOTATIONS and not FileAccess.file_exists(full_path):
			missing_annotations.append(full_path)
			continue
		if FileAccess.get_sha256(full_path) != hashes[path]:
			return {"error":"source_evidence_changed", "changed_path":path, "missing_annotations":missing_annotations, "annotation_status":"proof_failed"}
	return {"error":"", "changed_path":"", "missing_annotations":missing_annotations, "annotation_status":"complete" if missing_annotations.is_empty() else "missing_annotations"}
