extends RefCounted
const PackagedEvidence = preload("res://core/packaged_source_evidence.gd")
## Exact Timewarped Anub'arak pair. Inherited after-play clock and Army ledger only.
## Own-play exclusion is inherited host behavior, not independent native timing evidence.
const Army = preload("res://core/permanent_tribe_effects.gd")
const Exact = preload("res://core/end_turn_repeats.gd")
const Numbers = preload("res://core/delayed_minion_gold.gd")
const PoolIdentity = preload("res://core/pool_identity.gd")
const FOLDER: String = "res://research/timewarped_anubarak_sources/"
const RULE: String = "timewarped_anubarak_complete_native_v1"
const TYPE: String = "on_play_undead_army_attack"
const IDS: Array = ["BG34_PreMadeChamp_083","BG34_PreMadeChamp_083_G"]
const CONTRACT_SHA256: String = "9c89625972f677b93516b791d9d0d1232153c075206c663d1f53e4e44b4cf0ef"
const EXPECTED_SHA256: String = "a76e3c632384cfb8592d4a13777a665bdd7e5f627c2904bd7614b9c16373ecad"
const PROGRAMS: Dictionary = {"BG34_PreMadeChamp_083":[{"type":"on_play_undead_army_attack","tribe":"亡灵","attack":3,"health":0,"duration":"game"}],"BG34_PreMadeChamp_083_G":[{"type":"on_play_undead_army_attack","tribe":"亡灵","attack":6,"health":0,"duration":"game"}]}
const ENTITY_SHA256: Dictionary = {"BG34_PreMadeChamp_083":"8e9b9c3b029c5b78ee5035cc5fe22c477b7f1cecd1a607271848db007d7c7d4f","BG34_PreMadeChamp_083_G":"b5b107f3e44bc2d48649bdc7ed672a8030b7046d727152f3afbed87481c00122"}
const EVIDENCE_SHA256: Dictionary = {"README.md":"673936e83ce001234cad6349237f28ce8dfd6ffa8bb538c0b8a1d1a212296554","accepted_host_examples.json":"e368df08f8e670ecc8c47f27e714afcfb6236c5a555acb344b04e3907ec7d68a","entities/253932_BG22_HERO_200_Buddy.xml":"c34233ff100547488d8174019270d842a990562ab6998d300bce9f274b17e509","entities/253932_BG22_HERO_200_Buddy_G.xml":"92eb543c88c064dd53bcb2aa4a9c498ff1a30fb0809f690ac550a8de7e50ab48","entities/253932_BG34_PreMadeChamp_083.xml":"8e9b9c3b029c5b78ee5035cc5fe22c477b7f1cecd1a607271848db007d7c7d4f","entities/253932_BG34_PreMadeChamp_083_G.xml":"b5b107f3e44bc2d48649bdc7ed672a8030b7046d727152f3afbed87481c00122","host/catalog.gd.txt":"5ddcedfa3a97865a95ee471cb512e7fd431f67a1efc478111215f21adcc536b6","host/combat.gd.txt":"cc2408d7d4e76d3b0f1bc6177aed9a7edbc6aa4dcabc4c6136920ab687c036d4","host/game.gd.txt":"d86c8586446fce9ba96fd99ae84209f101f2c18ebdce1989dd1ae863fcf166ba","host/permanent_tribe_effects.gd.txt":"94695c603a8b147258b77d94aa61f36e68af204cd8c08aea33aad2a38f26e6a4","host/permanent_tribe_room.gd.txt":"200081c702419daab947e75049fc7945524fd27d4c60ff6b643697d0d9459dcb","host/test_binding_six_smoke.gd.txt":"6d910d86fb44652e83d07a020531a66126bc63f998ea94cd1f6b94ea5a29cade","input_manifest.json":"a6d1fd051c7872a5ef83ae23f09e8e30f90f57c6b187ce64550081a70203ae00","seal.json":"893198d7304b3c7ad49f9b1b1c3115ac8b844e145e0344bcb53b1e4aa55bb8ec","self_play_review.json":"66708fa9f8e00adb030a554ddb43f38daf6a41aa71841b1432e65da09c0cc193"}
const RAW49_SHA256: Dictionary = {"BG34_PreMadeChamp_083":"014c1f03c87b92ffa6f8f514bceb16d768a26b59067796dec4b61927d7f454ac","BG34_PreMadeChamp_083_G":"e2ef471024e922ee2864a7abef6e7a40d0fcb7d34ebbc2b91605658785c039ac"}
const SOURCES: Dictionary = {"BG34_PreMadeChamp_083":{"name":"时空扭曲阿努巴拉克","kind":"minion","category":"随从","tier":5,"attack":12,"health":8,"cost":null,"tribes":["亡灵"],"is_golden":false,"text":"在你使用一张亡灵牌后，在本局对战中，你的亡灵额外拥有+3攻击力。","normal_id":null,"golden_id":"BG34_PreMadeChamp_083_G"},"BG34_PreMadeChamp_083_G":{"name":"时空扭曲阿努巴拉克","kind":"minion","category":"随从","tier":5,"attack":24,"health":16,"cost":null,"tribes":["亡灵"],"is_golden":true,"text":"在你使用一张亡灵牌后，在本局对战中，你的亡灵额外拥有+6攻击力。","normal_id":"BG34_PreMadeChamp_083","golden_id":null}}
const DBF: Dictionary = {"BG34_PreMadeChamp_083":"126584","BG34_PreMadeChamp_083_G":"127394"}

static func effect_claimed(effect: Dictionary) -> bool:
	return Exact._same(effect.get("type"),TYPE)

static func effect_error(effect: Dictionary) -> String:
	if not effect_claimed(effect): return ""
	for program in PROGRAMS.values():
		if Exact._same(effect,program[0]): return Army.on_play_army_effect_error(effect)
	return "timewarped_anubarak_incomplete_reserved_program"

static func accepts_id(identity: Variant) -> bool:
	return identity is String and identity in IDS

static func program_for(identity: Variant) -> Array:
	return PROGRAMS[identity].duplicate(true) if accepts_id(identity) else []

static func _marker(value: Variant, depth: int = 0) -> bool:
	if depth > 16: return true
	if value is Dictionary:
		if effect_claimed(value) or accepts_id(value.get("card_id")) or accepts_id(value.get("source_id")): return true
		for child in value.values():
			if (child is Dictionary or child is Array) and _marker(child,depth+1): return true
	elif value is Array:
		for child in value:
			if _marker(child,depth+1): return true
	return false

static func claimed(source: Variant) -> bool:
	if not source is Dictionary: return false
	if accepts_id(source.get("id")) or accepts_id(source.get("card_id")): return true
	for key in ["base_unit","_base"]:
		if source.get(key) is Dictionary and (accepts_id(source[key].get("id")) or accepts_id(source[key].get("card_id"))): return true
	return _marker(source.get("effects",[]))

## Fresh local verification binds every retained source byte; no mutable global trust cache.
static func validation_evidence() -> Dictionary:
	if FileAccess.get_sha256(FOLDER+"source_contract.json") != CONTRACT_SHA256: return {"error":"timewarped_anubarak_contract_changed"}
	if FileAccess.get_sha256(FOLDER+"expected_compiled.json") != EXPECTED_SHA256: return {"error":"timewarped_anubarak_expected_program_changed"}
	var contract: Variant = JSON.parse_string(FileAccess.get_file_as_string(FOLDER+"source_contract.json"))
	var expected: Variant = JSON.parse_string(FileAccess.get_file_as_string(FOLDER+"expected_compiled.json"))
	if not contract is Dictionary or not Exact._same(contract.get("ids"),IDS): return {"error":"timewarped_anubarak_source_closure_changed"}
	if not contract.get("records") is Dictionary or contract.records.size() != 2 or not expected is Dictionary or expected.size() != 2: return {"error":"timewarped_anubarak_incomplete_evidence"}
	var records: Dictionary = {}
	for identity in IDS:
		var path: String = "raw49/"+identity+".json"
		if FileAccess.get_sha256(FOLDER+path) != RAW49_SHA256[identity]: return {"error":"timewarped_anubarak_raw49_changed"}
		var row: Variant = JSON.parse_string(FileAccess.get_file_as_string(FOLDER+path))
		if not row is Dictionary or row.size() != 49 or not Exact._same(row.get("id"),identity): return {"error":"timewarped_anubarak_raw49_shape_changed"}
		if not Exact._same(expected[identity].get("effects"),PROGRAMS[identity]): return {"error":"timewarped_anubarak_complete_program_changed"}
		records[identity] = row
	var proof: Dictionary = PackagedEvidence.inspect(FOLDER,EVIDENCE_SHA256)
	if not str(proof.error).is_empty(): return {"error":"timewarped_anubarak_native_evidence_changed"}
	return {"error":"","records":records,"expected":expected,"missing_annotations":proof.missing_annotations,"annotation_status":proof.annotation_status}

static func raw_source_error(card: Dictionary, evidence: Dictionary = {}) -> String:
	if not accepts_id(card.get("id")): return "timewarped_anubarak_unknown_raw_source"
	if evidence.is_empty(): evidence = validation_evidence()
	if not str(evidence.get("error","timewarped_anubarak_missing_evidence")).is_empty(): return str(evidence.get("error","timewarped_anubarak_missing_evidence"))
	return "" if Exact._same(card,evidence.records[card.id]) else "timewarped_anubarak_complete_raw_source_changed"

static func source_error(card: Variant, custom_projection: bool = false, evidence: Dictionary = {}) -> String:
	if not card is Dictionary: return "timewarped_anubarak_invalid_source"
	if not claimed(card): return ""
	if not accepts_id(card.get("id")) or card.has("card_id"): return "timewarped_anubarak_unbound_canonical_source"
	if evidence.is_empty(): evidence = validation_evidence()
	if not str(evidence.get("error","timewarped_anubarak_missing_evidence")).is_empty(): return str(evidence.get("error","timewarped_anubarak_missing_evidence"))
	var identity: String = card.id
	var expected: Dictionary = evidence.records[identity].duplicate(true)
	expected.merge(evidence.expected[identity],true)
	var actual: Dictionary = card.duplicate(true)
	if actual.has("pool_blocker"):
		# Catalog's established acquisition gate may add only this exact text.
		expected.pool_blocker = PoolIdentity.MINION_REASON
	if actual.has("source_shop_fields"):
		if not custom_projection or identity not in IDS: return "timewarped_anubarak_nonparent_custom_shop"
		if not Exact._same(actual.source_shop_fields,{"tier":expected.tier,"cost":expected.cost,"pool_supported":expected.pool_supported}): return "timewarped_anubarak_custom_source_changed"
		if not Numbers.integer(actual.get("tier"),1,6): return "timewarped_anubarak_custom_tier_changed"
		if identity == IDS[0]:
			if not Numbers.integer(actual.get("cost"),0,9223372036854775807) or not Exact._same(actual.get("pool_supported"),true): return "timewarped_anubarak_custom_parent_price_or_pool"
			if not actual.get("custom_shop_override") is Dictionary or actual.has("custom_shop_derived_from"): return "timewarped_anubarak_custom_parent_metadata"
			var entry: Dictionary = actual.custom_shop_override
			if entry.size() != 3 or not Numbers.integer(entry.get("tier"),1,6) or not Numbers.integer(entry.get("cost"),0,99) or not Numbers.integer(entry.get("copies"),1,99): return "timewarped_anubarak_custom_shop_parameters_changed"
			if not Exact._same(entry.tier,actual.tier) or not Exact._same(entry.cost,actual.cost): return "timewarped_anubarak_custom_shop_projection_changed"
		else:
			if actual.has("custom_shop_override") or not Exact._same(actual.get("custom_shop_derived_from"),IDS[0]): return "timewarped_anubarak_custom_golden_metadata"
			if not Exact._same(actual.get("cost"),expected.cost) or not Exact._same(actual.get("pool_supported"),false): return "timewarped_anubarak_custom_golden_cannot_be_stock"
		actual.tier = expected.tier; actual.cost = expected.cost; actual.pool_supported = expected.pool_supported
		for key in ["source_shop_fields","custom_shop_override","custom_shop_derived_from"]: actual.erase(key)
	return "" if Exact._same(actual,expected) else "timewarped_anubarak_complete_source_changed:"+identity

static func card_error(card: Variant, custom_projection: bool = false, evidence: Dictionary = {}) -> String:
	return source_error(card,custom_projection,evidence)

static func closure_error(catalog, identity: Variant, evidence: Dictionary = {}) -> String:
	if catalog == null or not accepts_id(identity): return "timewarped_anubarak_unknown_family_or_catalog"
	if evidence.is_empty(): evidence = validation_evidence()
	if not str(evidence.get("error","timewarped_anubarak_missing_evidence")).is_empty(): return str(evidence.get("error","timewarped_anubarak_missing_evidence"))
	var original = catalog.source_catalog if catalog.source_catalog != null else catalog
	for member in IDS:
		var canonical: Dictionary = original.get_card(member)
		if not Exact._same(canonical.get("id"),member): return "timewarped_anubarak_missing_source:"+member
		var issue: String = source_error(canonical,false,evidence)
		if not issue.is_empty(): return issue
		if catalog.source_catalog != null:
			var effective: Dictionary = catalog.get_card(member)
			if not Exact._same(effective.get("id"),member): return "timewarped_anubarak_missing_effective_source:"+member
			issue = source_error(effective,true,evidence)
			if not issue.is_empty(): return issue
	if catalog.source_catalog != null:
		var parent: Dictionary = catalog.get_card(IDS[0])
		var golden: Dictionary = catalog.get_card(IDS[1])
		if not Exact._same(parent.get("tier"),golden.get("tier")): return "timewarped_anubarak_effective_parent_pair_tier_changed"
		if parent.has("source_shop_fields") != golden.has("source_shop_fields"): return "timewarped_anubarak_effective_parent_pair_projection_changed"
	return ""

static func room_error(room: Dictionary, catalog) -> String:
	for identity in room.get("enabled_minions",[]) + room.get("enabled_spells",[]):
		if accepts_id(identity) and identity not in room.get("disabled_ids",[]):
			var issue: String = closure_error(catalog,identity)
			return issue if not issue.is_empty() else template_catalog_error(catalog)
	return ""

static func _identity_error(source: Dictionary, identity: String) -> String:
	var expected: Dictionary = SOURCES[identity]
	for key in ["id","card_id","card_code"]:
		if source.has(key) and not Exact._same(source[key],identity): return "timewarped_anubarak_conflicting_identity"
	if source.has("dbf_id") and not Exact._same(source.dbf_id,DBF[identity]): return "timewarped_anubarak_conflicting_dbf_identity"
	if not Exact._same(source.get("kind",expected.kind),expected.kind): return "timewarped_anubarak_wrong_kind"
	if not Exact._same(source.get("golden",source.get("is_golden")),expected.is_golden): return "timewarped_anubarak_wrong_variant"
	if source.has("is_golden") and not Exact._same(source.is_golden,expected.is_golden): return "timewarped_anubarak_conflicting_variant"
	if not Exact._same(source.get("tribes"),expected.tribes): return "timewarped_anubarak_wrong_tribes"
	for key in ["name","text"]:
		if source.has(key) and not Exact._same(source[key],expected[key]): return "timewarped_anubarak_changed_"+key
	if not Exact._same(source.get("effects"),PROGRAMS[identity]): return "timewarped_anubarak_incomplete_program"
	if source.has("choose_one_branch_id"): return "timewarped_anubarak_unrelated_branch_provenance"
	return ""

static func _base_error(base: Variant, identity: String, templates: Dictionary) -> String:
	if not base is Dictionary or not Exact._same(base.get("card_id",base.get("id")),identity): return "timewarped_anubarak_base_identity_changed"
	var issue: String = _identity_error(base,identity)
	if not issue.is_empty(): return issue
	if not Exact._same(base.get("keywords",[]),[]): return "timewarped_anubarak_base_keywords_changed"
	for key in ["attachments","pool_components"]:
		if not Exact._same(base.get(key,[]),[]): return "timewarped_anubarak_base_attachment_changed"
	if base.has("base_unit") or base.has("_base"): return "timewarped_anubarak_nested_base"
	if identity in IDS:
		for key in ["attack","health"]:
			if not Exact._same(base.get(key),SOURCES[identity][key]): return "timewarped_anubarak_native_base_body_changed"
		if not Exact._same(base.get("max_health",base.get("health")),SOURCES[identity].health): return "timewarped_anubarak_native_base_max_health_changed"
		var tier: Variant = SOURCES[identity].tier
		if templates.has(identity):
			var template: Variant = templates[identity]
			if not template is Dictionary: return "timewarped_anubarak_invalid_source_template"
			issue = _identity_error(template,identity)
			if not issue.is_empty(): return issue
			if not Numbers.integer(template.get("tier"),1,6): return "timewarped_anubarak_invalid_template_tier"
			for key in ["attack","health"]:
				if not Exact._same(template.get(key),SOURCES[identity][key]): return "timewarped_anubarak_template_body_changed"
			tier = template.tier
		if not Exact._same(base.get("tier"),tier): return "timewarped_anubarak_native_base_tier_changed"
	return ""

static func unit_error(source: Variant, templates: Dictionary = {}, is_base: bool = false) -> String:
	if not source is Dictionary: return "timewarped_anubarak_invalid_runtime_source"
	if not claimed(source): return ""
	var evidence: Dictionary = validation_evidence()
	if not str(evidence.get("error", "timewarped_anubarak_missing_evidence")).is_empty(): return str(evidence.error)
	if source.has("id") and not source.has("card_id"): return source_error(source,source.has("source_shop_fields"))
	var identity: Variant = source.get("card_id",source.get("id"))
	if not accepts_id(identity): return "timewarped_anubarak_marker_on_wrong_source"
	var issue: String = _identity_error(source,identity)
	if not issue.is_empty(): return issue
	issue = templates_error(templates)
	if not issue.is_empty(): return issue
	if is_base: return _base_error(source,identity,templates)
	if not source.has("uid") and templates.has(identity) and Exact._same(source,templates[identity]): return _base_error(source,identity,templates)
	var uid_valid: bool = source.get("uid") is String and not source.uid.is_empty()
	if not uid_valid: return "timewarped_anubarak_invalid_runtime_uid"
	if not Exact._same(source.get("kind"),"minion"): return "timewarped_anubarak_runtime_kind_changed"
	for flag in ["temporary","is_spellcraft","excluded","stats_conflict","duos_exclusive","requires_teammate_effect"]:
		if not Exact._same(source.get(flag,false),false): return "timewarped_anubarak_runtime_gate:"+flag
	for flag in ["silenced","abilities_disabled","_pending_destroy"]:
		if source.has(flag) and not source[flag] is bool: return "timewarped_anubarak_invalid_activity_flag:"+flag
	if source.has("solo_eligible") and not Exact._same(source.solo_eligible,true): return "timewarped_anubarak_runtime_not_solo"
	for key in ["attachments","pool_components","quality_flags","source_conflicts"]:
		if not Exact._same(source.get(key,[]),[]): return "timewarped_anubarak_unverified_runtime_attachment_or_flag:"+key
	if not Numbers.integer(source.get("attack"),0,9223372036854775807): return "timewarped_anubarak_invalid_live_attack"
	if not Numbers.integer(source.get("health"),-9223372036854775807,9223372036854775807): return "timewarped_anubarak_invalid_live_health"
	if not Numbers.integer(source.get("max_health",source.get("health")),1,9223372036854775807): return "timewarped_anubarak_invalid_live_max_health"
	if source.health > source.get("max_health",source.health): return "timewarped_anubarak_live_health_exceeds_maximum"
	if not Numbers.integer(source.get("tier"),1,6): return "timewarped_anubarak_invalid_live_tier"
	var expected_tier: Variant = SOURCES[identity].tier
	if templates.has(identity):
		issue = _base_error(templates[identity],identity,templates)
		if not issue.is_empty(): return issue
		expected_tier = templates[identity].tier
	if not Exact._same(source.tier,expected_tier): return "timewarped_anubarak_live_tier_differs_from_source"
	if not source.get("keywords",[]) is Array: return "timewarped_anubarak_invalid_live_keywords"
	for keyword in source.get("keywords",[]):
		if not keyword is String: return "timewarped_anubarak_invalid_live_keyword"
	for key in ["base_unit","_base"]:
		if source.has(key):
			issue = _base_error(source[key],identity,templates)
			if not issue.is_empty(): return issue
	if not source.get("temporary_buffs",[]) is Array: return "timewarped_anubarak_invalid_temporary_layers"
	for buff in source.get("temporary_buffs",[]):
		if not buff is Dictionary or not Numbers.integer(buff.get("attack"),-9223372036854775807,9223372036854775807) or not Numbers.integer(buff.get("health"),-9223372036854775807,9223372036854775807) or not buff.get("keywords") is Array: return "timewarped_anubarak_invalid_temporary_layer"
		for keyword in buff.keywords:
			if not keyword is String: return "timewarped_anubarak_invalid_temporary_keyword"
	return ""

static func play_error(engine, _player: Dictionary, source: Dictionary) -> String:
	if not claimed(source): return ""
	var identity: Variant = source.get("card_id",source.get("id"))
	var templates: Dictionary = engine.catalog.hand_card_templates
	var issue: String = unit_error(source,templates)
	if not issue.is_empty(): return issue
	issue = closure_error(engine.catalog,identity)
	return issue if not issue.is_empty() else template_catalog_error(engine.catalog)


static func saved_unit_error(unit: Dictionary, catalog, depth: int = 0) -> String:
	if depth > 16: return "timewarped_anubarak_nested_depth"
	if claimed(unit):
		var issue: String = unit_error(unit,catalog.hand_card_templates)
		if not issue.is_empty(): return issue
		issue = closure_error(catalog,unit.get("card_id",unit.get("id")))
		if not issue.is_empty(): return issue
		issue = template_catalog_error(catalog)
		if not issue.is_empty(): return issue
	for key in ["base_unit","_base"]:
		if unit.get(key) is Dictionary:
			# The containing source authenticates its exact base; do not reinterpret
			# a pristine UID-free base as an independently active live minion.
			if claimed(unit[key]) and not claimed(unit): return "timewarped_anubarak_foreign_parent_base"
	return ""

static func templates_error(templates: Dictionary) -> String:
	# Both pristine templates are required; one changed mate cannot authorize the other.
	for identity in IDS:
		if not templates.has(identity): return "timewarped_anubarak_missing_pair_template"
		var issue: String = _base_error(templates[identity],identity,templates)
		if not issue.is_empty(): return issue
		if not Exact._same(templates[identity],_native_template(identity,templates[identity].tier)): return "timewarped_anubarak_complete_template_changed"
	if not Exact._same(templates[IDS[0]].tier,templates[IDS[1]].tier): return "timewarped_anubarak_pair_template_tier_changed"
	return ""

static func _native_template(identity: String, tier: int) -> Dictionary:
	var native: Dictionary = SOURCES[identity]
	return {"card_id":identity,"kind":"minion","name":native.name,"effects":PROGRAMS[identity].duplicate(true),"attack":native.attack,"health":native.health,"tier":tier,"keywords":[],"tribes":["亡灵"],"max_health":native.health,"golden":native.is_golden}

## Catalog.load validates complete cards before generating templates. Runtime
## and room admission additionally bind every template field to the final
## effective card, including explicitly declared custom tier projection.
static func template_catalog_error(catalog) -> String:
	for identity in IDS:
		var card: Dictionary = catalog.get_card(identity)
		if not Numbers.integer(card.get("tier"),1,6): return "timewarped_anubarak_catalog_template_tier_changed"
		if not Exact._same(catalog.hand_card_templates.get(identity),_native_template(identity,int(card.tier))): return "timewarped_anubarak_catalog_template_changed"
		if not Exact._same(catalog.hand_card_kinds.get(identity),"minion"): return "timewarped_anubarak_template_kind_changed"
	return ""

static func inactive(source: Dictionary) -> bool:
	if not Numbers.integer(source.get("health"),-9223372036854775807,9223372036854775807): return false
	return source.health <= 0 or Exact._same(source.get("_pending_destroy",false),true) or Exact._same(source.get("silenced",false),true) or Exact._same(source.get("abilities_disabled",false),true)

static func call_error(source: Dictionary, effect: Dictionary, _templates: Dictionary = {}) -> String:
	if not claimed(source) and not effect_claimed(effect): return ""
	return "timewarped_anubarak_requires_actual_hand_play"

## A transient capability is captured only by _play after preflight and before
## removal from the actual hand. It neither registers a new event nor survives save.
static func _contains_same(units: Array, unit: Dictionary) -> bool:
	for member in units:
		if is_same(member,unit): return true
	return false

static func capture_play(engine, player: Dictionary, played: Dictionary) -> Dictionary:
	var result: Dictionary = {"ok":true,"error":""}
	if played.get("kind","minion") != "minion" or not engine._tribe_match(played,Army.TRIBE): return result
	var listeners: Array = []
	var seen: Dictionary = {}
	for source in player.get("board",[]):
		if not claimed(source): continue
		var issue: String = play_error(engine,player,source)
		if not issue.is_empty(): return {"ok":false,"error":issue}
		if inactive(source): continue
		if seen.has(source.uid): return {"ok":false,"error":"timewarped_anubarak_duplicate_listener_uid"}
		seen[source.uid] = true
		listeners.append({"source":source,"uid":source.uid,"card_id":source.card_id})
	if listeners.is_empty(): return result
	if engine.state.get("phase") != "recruit" or not _contains_same(engine.state.get("players",[]),player) or not _contains_same(player.get("hand",[]),played): return {"ok":false,"error":"timewarped_anubarak_not_actual_owner_hand"}
	if not played.get("uid") is String or played.uid.is_empty() or seen.has(played.uid): return {"ok":false,"error":"timewarped_anubarak_played_uid_conflict"}
	result.merge({"owner":player,"played":played,"played_uid":played.uid,"played_id":played.card_id,"listeners":listeners,"used":{},"resolved":false,"consumed":false,"round":engine.state.round,"command_sequence":engine.state.command_sequence},true)
	return result

static func magnetic_error(engine, player: Dictionary, hand_index: int) -> String:
	if hand_index < 0 or hand_index >= player.get("hand",[]).size(): return ""
	var played: Dictionary = player.hand[hand_index]
	if not engine._tribe_match(played,Army.TRIBE): return ""
	for source in player.get("board",[]):
		if claimed(source) and not inactive(source): return "timewarped_anubarak_undead_magnetic_play_unreviewed"
	return ""

static func on_played(engine, player: Dictionary, source: Dictionary, played: Dictionary, context: Dictionary = {}) -> String:
	if not claimed(source): return ""
	var issue: String = play_error(engine,player,source)
	if not issue.is_empty(): return issue
	if inactive(source) or source.get("uid") == played.get("uid") or not engine._tribe_match(played,Army.TRIBE): return ""
	if context.is_empty() or not is_same(context,engine._anubarak_play_context): return "timewarped_anubarak_requires_actual_hand_play"
	if not Exact._same(context.get("resolved"),true) or not Exact._same(context.get("consumed"),false): return "timewarped_anubarak_unresolved_or_consumed_play"
	if not is_same(context.get("owner"),player) or not is_same(context.get("played"),played): return "timewarped_anubarak_wrong_owner_or_played_reference"
	if engine.state.get("phase") != "recruit" or not _contains_same(engine.state.get("players",[]),player): return "timewarped_anubarak_outside_owner_recruit"
	if not Exact._same(context.get("round"),engine.state.round) or not Exact._same(context.get("command_sequence"),engine.state.command_sequence): return "timewarped_anubarak_stale_play"
	if not Exact._same(context.get("played_uid"),played.get("uid")) or not Exact._same(context.get("played_id"),played.get("card_id")): return "timewarped_anubarak_changed_played_identity"
	if _contains_same(player.get("hand",[]),played) or not _contains_same(player.get("board",[]),played) or not _contains_same(player.get("board",[]),source): return "timewarped_anubarak_unresolved_or_detached_source"
	if not context.get("listeners") is Array or not context.get("used") is Dictionary: return "timewarped_anubarak_invalid_play_context"
	var witness: Dictionary = {}
	for entry in context.listeners:
		if entry is Dictionary and is_same(entry.get("source"),source): witness = entry; break
	if witness.is_empty() or not Exact._same(witness.get("uid"),source.uid) or not Exact._same(witness.get("card_id"),source.card_id): return "timewarped_anubarak_not_preplay_listener"
	if context.used.has(source.uid): return "timewarped_anubarak_listener_replay"
	var effect: Dictionary = PROGRAMS[source.card_id][0]
	var planned: Dictionary = Army.recruit_attack_plan(player,effect.attack)
	if not str(planned.error).is_empty(): return str(planned.error)
	context.used[source.uid] = true
	var changed: Dictionary = Army.add_recruit_attack(player,effect.attack)
	if not str(changed.error).is_empty(): return str(changed.error)
	engine._log("timewarped_anubarak_army",changed.event.merged({"player":player.id,"source_uid":source.uid,"source_id":source.card_id,"played_uid":played.uid},true))
	return ""
