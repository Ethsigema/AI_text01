#!/usr/bin/env python3
"""Baseline-anchored, SHA256-verified game backups. Standard library only."""
import argparse, hashlib, json, pathlib, shutil, stat, urllib.request, zipfile
BASE_SHA='33b3a1a12185cf9035cec33da4fff7008c7680194eb045b37234fbb934803d65'
BASE_URL='https://github.com/Ethsigema/AI_text01/releases/download/battlegrounds-handoff-20261101/battlegrounds_new_scope_handoff_20261101.zip'
BASE_ROOT='酒馆战棋_新范围半成品交接包_20261101'
SKIP={'.git','.godot','__pycache__'}
def sha(p):
 h=hashlib.sha256()
 with open(p,'rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def safe(s):
 p=pathlib.PurePosixPath(s)
 if not s or p.is_absolute() or '..' in p.parts or '\\' in s:raise ValueError('Unsafe path: '+s)
 return p

def inventory(root):
 out={}
 for p in sorted(root.rglob('*')):
  rel=p.relative_to(root).as_posix()
  if any(x in SKIP for x in p.relative_to(root).parts) or p.name=='.DS_Store' or p.suffix=='.pyc':continue
  if p.is_symlink():raise ValueError('Symlink not allowed: '+rel)
  if not p.is_file():continue
  if p.name.lower() in {'.env','credentials','credentials.json','id_rsa','id_ed25519','hosts.yml'} or p.name.lower().startswith('.env.'):raise ValueError('Potential secret file: '+rel)
  out[rel]={'sha256':sha(p),'size':p.stat().st_size}
 return out

def build(a):
 root=pathlib.Path(a.root).resolve();out=pathlib.Path(a.output).resolve();base=pathlib.Path(a.base_zip)
 if out.exists():raise ValueError('Output must not already exist')
 if out==root or root in out.parents:raise ValueError('Output must be outside source root')
 if sha(base)!=BASE_SHA:raise ValueError('Baseline SHA mismatch')
 before=inventory(root);changed=[];out.mkdir(parents=True)
 with zipfile.ZipFile(base) as z:
  byname={x.filename:x for x in z.infolist()}
  for rel,meta in before.items():
   zi=byname.get(BASE_ROOT+'/'+rel);identical=False
   if zi and zi.file_size==meta['size']:
    h=hashlib.sha256()
    with z.open(zi) as f:
     for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    identical=h.hexdigest()==meta['sha256']
   if not identical:
    dest=out/'payload'/safe(rel);dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(root/rel,dest)
    if sha(dest)!=meta['sha256']:raise ValueError('Source changed during copy: '+rel)
    changed.append(rel)
 after=inventory(root)
 if before!=after:raise ValueError('Source changed during snapshot; do not publish')
 manifest={'format':'battlegrounds-baseline-overlay-v1','created_utc':a.created_utc,'baseline':{'url':BASE_URL,'sha256':BASE_SHA,'zip_root':BASE_ROOT},'excluded_directory_names':sorted(SKIP),'files':before,'payload_paths':changed,'note':'Exact current recovered tree only. Historical 153/433 is not acceptance of this restored source.'}
 (out/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
 print(json.dumps({'files':len(before),'payload_files':len(changed),'payload_bytes':sum(before[x]['size'] for x in changed),'manifest_sha256':sha(out/'manifest.json')},ensure_ascii=False))

def restore(a):
 snap=pathlib.Path(a.snapshot).resolve();m=json.loads((snap/'manifest.json').read_text());base=pathlib.Path(a.base_zip);dest=pathlib.Path(a.destination).resolve()
 if m['format']!='battlegrounds-baseline-overlay-v1' or m['baseline']['sha256']!=BASE_SHA:raise ValueError('Unknown manifest/baseline')
 if dest.exists():raise ValueError('Destination must not exist; never overwrite an existing project')
 if sha(base)!=BASE_SHA:raise ValueError('Baseline SHA mismatch')
 payload=set(m['payload_paths']);files=m['files']
 if not payload.issubset(files):raise ValueError('Unexpected payload entry')
 with zipfile.ZipFile(base) as z:
  dest.mkdir(parents=True)
  for rel,meta in files.items():
   target=dest/safe(rel);target.parent.mkdir(parents=True,exist_ok=True)
   if rel in payload:
    source=snap/'payload'/safe(rel)
    if source.is_symlink():raise ValueError('Symlink payload')
    shutil.copyfile(source,target)
   else:
    zi=z.getinfo(m['baseline']['zip_root']+'/'+rel)
    if stat.S_ISLNK(zi.external_attr>>16):raise ValueError('Symlink baseline entry')
    with z.open(zi) as f,open(target,'wb') as g:shutil.copyfileobj(f,g)
   if target.stat().st_size!=meta['size'] or sha(target)!=meta['sha256']:raise ValueError('Restored file mismatch: '+rel)
 if inventory(dest)!=files:raise ValueError('Restored tree differs')
 print(json.dumps({'verified_files':len(files),'destination':str(dest),'manifest_sha256':sha(snap/'manifest.json')}))

p=argparse.ArgumentParser(description=__doc__);s=p.add_subparsers(dest='command',required=True)
b=s.add_parser('build');b.add_argument('--root',required=True);b.add_argument('--base-zip',required=True);b.add_argument('--output',required=True);b.add_argument('--created-utc',required=True)
r=s.add_parser('restore');r.add_argument('--snapshot',required=True);r.add_argument('--base-zip',required=True);r.add_argument('--destination',required=True)
a=p.parse_args();{'build':build,'restore':restore}[a.command](a)
