#!/usr/bin/env python3
"""Read-only inventory of candidate minions; never infer acceptance from mappings.

Writes to a NEW output directory. Reference hits are navigation aids, not evidence
of execution. No Godot or external code is executed by this tool.
"""
import argparse
import csv
import hashlib
import json
from pathlib import Path
import re

SCHEMA = 1

def sha(data):
    return hashlib.sha256(data).hexdigest()

def read(root, relative, inputs):
    data = (root / relative).read_bytes()
    inputs[relative] = {'sha256': sha(data), 'size': len(data)}
    return json.loads(data)

def select_ids(manifest):
    excluded = set(manifest['excluded_aberration_minion_ids'])
    base = set(manifest['official']['minion_ids']) - excluded
    naga = set(manifest['naga_overlay']['minion_ids']) - excluded
    return sorted(base | naga), base, naga

def index_references(root, ids, inputs):
    # Exact identifiers only: BGxx_1 must not match BGxx_10 or BGxx_1_G.
    pattern = re.compile(r'(?<![A-Za-z0-9_])(' + '|'.join(re.escape(x) for x in sorted(ids, key=len, reverse=True)) + r')(?![A-Za-z0-9_])')
    references = {i: [] for i in ids}
    for folder in ('core', 'tests'):
        for path in sorted((root / folder).rglob('*')):
            if not path.is_file() or path.suffix not in ('.gd', '.md', '.json'):
                continue
            data = path.read_bytes()
            relative = path.relative_to(root).as_posix()
            # Only code/tests in this verified snapshot, not arbitrary old logs.
            inputs[relative] = {'sha256': sha(data), 'size': len(data)}
            lines = {}
            for n, line in enumerate(data.decode('utf-8').splitlines(), 1):
                for card_id in set(pattern.findall(line)):
                    lines.setdefault(card_id, []).append(n)
            for card_id, numbers in lines.items():
                references[card_id].append({'path': relative, 'lines': numbers,
                                           'kind': 'test_or_document_reference' if folder == 'tests' else 'source_reference',
                                           'execution_verified': False})
    return references

def build(root, source_revision):
    inputs = {}
    m = read(root, 'data/current_scope_manifest.json', inputs)
    cards = read(root, 'data/catalog.json', inputs)['cards']
    if len({c['id'] for c in cards}) != len(cards):
        raise ValueError('duplicate catalog IDs: resolve before inventory')
    catalog = {c['id']: c for c in cards}
    identities = {}
    for name in ('catalog_raw.json', 'supplemental_missing_catalog.json'):
        for c in read(root, 'data/' + name, inputs)['cards']:
            # Keep conflicts visible rather than silently replacing the identity.
            if c['id'] in identities and identities[c['id']].get('golden_id') != c.get('golden_id'):
                raise ValueError('conflicting golden mapping: ' + c['id'])
            identities[c['id']] = c
    ids, base, naga = select_ids(m)
    golden_ids = {identities.get(i, {}).get('golden_id') for i in ids} - {None, ''}
    refs = index_references(root, set(ids) | golden_ids, inputs)
    rows = []
    for normal_id in ids:
        identity = identities.get(normal_id, {})
        golden_id = identity.get('golden_id')  # never guess the suffix
        row = {'normal_id': normal_id, 'name': identity.get('name'),
               'scope_membership': [x for x, s in (('base', base), ('naga_overlay', naga)) if normal_id in s],
               'golden_id': golden_id, 'golden_identity_basis': 'data/catalog_raw.json or data/supplemental_missing_catalog.json; not current-patch acceptance',
               'completion_status': 'unverified', 'count_as_complete': False,
               'normal': {}, 'golden': {}}
        for variant, card_id in [('normal', normal_id), ('golden', golden_id)]:
            c = catalog.get(card_id)
            row[variant] = {'card_id': card_id, 'identity_present': card_id in identities,
                'catalog_mapping_present': c is not None,
                'catalog_supported_flag': c.get('supported') if c else None,
                'declared_implementation_status': c.get('implementation_status') if c else None,
                'conditional_support': c.get('conditional_support') if c else None,
                'coverage_rule': c.get('coverage_rule') if c else None,
                'effects': c.get('effects', []) if c else [],
                'references': refs.get(card_id, []),
                'implementation_review': 'pending', 'functional_acceptance': 'pending',
                'accepted_evidence': []}
        row['open_checks'] = ['confirm_latest_pool_membership_and_card_text', 'review_normal_and_golden_effect_handlers',
                              'verify_normal_and_golden_functional_evidence_on_source_revision',
                              'resolve_conditions_partial_paths_and_interactions']
        rows.append(row)
    return {'schema_version': SCHEMA, 'source_revision': source_revision,
        'scope_revision': m['revision'], 'scope_id': m['scope_id'],
        'scope_is_verified_latest_full_pool': False,
        'limitations': ['Candidate inventory, not gameplay acceptance. Source reference hits do not prove effect dispatch or passing tests.',
                       'Catalog flags may be overridden at runtime. This tool does not simulate the Godot loading/overlay chain.',
                       'Unknown unpublished interrupted work is not included. No gameplay tests were run.',
                       'Zero accepted ledger entries means unreviewed, not zero implemented minions.'],
        'completion_policy': 'One type requires reviewed complete normal AND golden behavior, version-correct content and functional evidence; registration, partial or conditional mappings alone do not count.',
        'summary': {'completed_types': None, 'verified_latest_total_types': None,
                    'candidate_types': len(rows), 'base_types': len(base), 'naga_overlay_types': len(naga),
                    'accepted_ledger_entries': 0, 'unreviewed_types': len(rows),
                    'normal_supported_mapping_count': sum(r['normal']['catalog_supported_flag'] is True for r in rows),
                    'golden_supported_mapping_count': sum(r['golden']['catalog_supported_flag'] is True for r in rows)},
        'input_files': inputs, 'minions': rows}

def validate(ledger):
    rows = ledger['minions']
    if len({r['normal_id'] for r in rows}) != len(rows):
        raise ValueError('duplicate type')
    if ledger['summary']['candidate_types'] != len(rows):
        raise ValueError('candidate count mismatch')
    # This generated inventory cannot issue completion claims. A separate reviewed
    # acceptance workflow must be added before this invariant can be relaxed.
    if ledger['summary']['completed_types'] is not None or ledger['summary']['verified_latest_total_types'] is not None:
        raise ValueError('unreviewed inventory cannot claim completed/latest total')
    if any(r['count_as_complete'] or r['completion_status'] != 'unverified' for r in rows):
        raise ValueError('mapping/reference inventory is not acceptance')
    for r in rows:
        if r['normal']['card_id'] != r['normal_id'] or r['golden']['card_id'] != r['golden_id']:
            raise ValueError('variant identity mismatch')
    return True

def write(ledger, out):
    validate(ledger)
    out.mkdir(parents=True, exist_ok=False)
    (out / 'minion_acceptance_ledger.json').write_text(json.dumps(ledger, ensure_ascii=False, indent=2)+'\n')
    with (out / 'minion_acceptance_ledger.csv').open('w', newline='', encoding='utf-8-sig') as f:
        w = csv.writer(f)
        w.writerow(['普通ID', '名称', '金色ID', '范围', '普通支持映射', '普通声明状态', '金色支持映射', '金色声明状态', '完整完成判定', '普通功能验收', '金色功能验收'])
        for r in ledger['minions']:
            w.writerow([r['normal_id'], r['name'], r['golden_id'], '+'.join(r['scope_membership']),
                r['normal']['catalog_supported_flag'], r['normal']['declared_implementation_status'],
                r['golden']['catalog_supported_flag'], r['golden']['declared_implementation_status'], '待核实', '待核实', '待核实'])
    s = ledger['summary']
    (out/'README.md').write_text(f'''# 随从逐卡验收台账（候选清单）

随从：已完成数量待核实／最新版总计数量待核实。

本次候选范围 {s['candidate_types']} 种，来自 {s['base_types']} 基础池 + {s['naga_overlay_types']} 娜迦。
源码固定版本：`{ledger['source_revision']}`。此范围不是已确认最新版完整卡池。

每行区分普通、金色、支持映射、条件限制、代码/测试引用和待验收状态。
普通与金色都完整实现并有对应功能证据才计为一种完成。当前全部行尚待逐卡审查，
完成数保留为 null；accepted_ledger_entries=0 不等于游戏实际实现数为 0。
引用是查阅入口，不表示测试执行或通过；运行时覆盖逻辑未在本工具中模拟。

下步按行确认现行文本、处理器和运行路径，补齐版本固定的正常/金色功能证据及交互边界，
再经过独立复核更新验收结论。禁止直接按 supported、引用数量或局部测试数换算完成数。

本次只运行台账生成/校验测试，没有运行 Godot 游戏测试，也未恢复未知未上传成果。
''', encoding='utf-8')
    (out/'SHA256SUMS.txt').write_text(''.join(f'{sha(p.read_bytes())}  {p.name}\n' for p in sorted(out.iterdir()) if p.is_file()))

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--project', type=Path, required=True)
    parser.add_argument('--source-revision', required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    ledger = build(args.project.resolve(), args.source_revision)
    write(ledger, args.output)
    print(json.dumps(ledger['summary'], ensure_ascii=False))
