import importlib.util
import json
from pathlib import Path
import tempfile
import unittest

SPEC = importlib.util.spec_from_file_location('ledger', Path(__file__).parents[2]/'tools/build_minion_acceptance_ledger.py')
m = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(m)

class LedgerTests(unittest.TestCase):
    def fixture(self, root):
        (root/'data').mkdir()
        (root/'core').mkdir()
        (root/'tests').mkdir()
        files = {
            'current_scope_manifest.json': {'official': {'minion_ids':['A', 'X']},
                'excluded_aberration_minion_ids':['X'], 'naga_overlay':{'minion_ids':['N','X']},
                'revision':'partial-test', 'scope_id':'test'},
            'catalog_raw.json': {'cards':[{'id':'A','golden_id':'Z','name':'test'}, {'id':'Z'}, {'id':'N'}]},
            'supplemental_missing_catalog.json': {'cards':[]},
            'catalog.json': {'cards':[{'id':'A','supported':True}, {'id':'Z','supported':True}]}}
        for name, data in files.items():
            (root/'data'/name).write_text(json.dumps(data))
        (root/'core/x.gd').write_text('"A" "A_G" "AA"\n"Z"\n')
        (root/'tests/x.gd').write_text('"A" # reference is not a passing test\n')
        return files

    def test_scope_exclusion_and_overlay(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d); self.fixture(root)
            ledger=m.build(root,'fixed'); self.assertEqual([r['normal_id'] for r in ledger['minions']],['A','N'])

    def test_supported_and_reference_do_not_complete(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);self.fixture(root); ledger=m.build(root,'fixed')
            self.assertIsNone(ledger['summary']['completed_types'])
            self.assertFalse(any(r['count_as_complete'] for r in ledger['minions']))
            self.assertTrue(m.validate(ledger))

    def test_golden_uses_explicit_identity_not_suffix(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);self.fixture(root);rows=m.build(root,'fixed')['minions']
            self.assertEqual(rows[0]['golden_id'],'Z'); self.assertIsNone(rows[1]['golden_id'])

    def test_exact_reference_and_line_numbers(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);self.fixture(root);inputs={}
            refs=m.index_references(root,{'A','Z'},inputs)
            self.assertEqual(refs['A'][0]['lines'],[1]);self.assertEqual(refs['Z'][0]['lines'],[2])
            self.assertTrue(all(not r['execution_verified'] for r in refs['A']))
            self.assertEqual(inputs['core/x.gd']['sha256'],m.sha((root/'core/x.gd').read_bytes()))

    def test_refuses_completion_claim(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);self.fixture(root);ledger=m.build(root,'fixed')
            ledger['minions'][0]['count_as_complete']=True
            with self.assertRaises(ValueError):m.validate(ledger)

    def test_refuses_numeric_latest_total(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);self.fixture(root);ledger=m.build(root,'fixed')
            ledger['summary']['verified_latest_total_types']=2
            with self.assertRaises(ValueError):m.validate(ledger)

    def test_no_overwrite_and_checksum_outputs(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);self.fixture(root);ledger=m.build(root,'fixed');out=root/'out'
            m.write(ledger,out)
            for line in (out/'SHA256SUMS.txt').read_text().splitlines():
                digest,name=line.split('  ');self.assertEqual(digest,m.sha((out/name).read_bytes()))
            with self.assertRaises(FileExistsError):m.write(ledger,out)

    def test_duplicate_mapping_fails_closed(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);files=self.fixture(root)
            files['catalog.json']['cards'].append({'id':'A','supported':False})
            (root/'data/catalog.json').write_text(json.dumps(files['catalog.json']))
            with self.assertRaises(ValueError):m.build(root,'fixed')

if __name__=='__main__':unittest.main()
