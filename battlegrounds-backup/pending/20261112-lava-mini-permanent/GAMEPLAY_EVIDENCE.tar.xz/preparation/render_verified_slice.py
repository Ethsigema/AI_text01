"""Pure Chinese evidence renderer. No reads, writes, Game or upload at import."""
import run_remote_lava_permanent as runner

def render_slice(summary,audit,final,scenario,commit):
 from packaging_common import outcome_metadata
 outcome=outcome_metadata(summary,audit,final)
 assert all(x.get('source_commit')==commit for x in [summary,audit]+([final] if final else []))
 if outcome=='failure':
  assert scenario is None
  classes={k:v['classification'] for k,v in audit['tests'].items()}
  return '# 本批测试未获验收\n\n源码：'+commit+'。本次实际尝试失败或未完成，不把未运行项目计为通过。\n\n本轮 9 份纯合同未运行，不能计为通过。预冻结纯合同 340 项只属此前局部检查，不是本轮 Game 验收。\n\n错误记录：'+str(summary.get('error'))+'\n\n测试分类：'+str(classes)+'\n\n保留原日志和失败源码，修复需另建候选。此页不表示玩法成功、默认启用或全量验收。\n'
 assert isinstance(scenario,dict)
 full=final['tests']['lava_permanent_real_matrix'];assert full['verified_scenario_fields']==scenario
 checks=full['passed_checks'];assert type(checks) is int and checks>0
 pure={k:v['passed_checks'] for k,v in final['tests'].items() if k!='lava_permanent_real_matrix'}
 assert len(pure)==9 and sum(pure.values())==3057
 assert len(scenario['casts'])==2 and len(scenario['combats'])==3 and scenario['darkcrest_final_tier']==4
 assert [(x['attack_before'],x['attack_after'],x['health'],x['kept']) for x in scenario['casts']]==[(2,4,5,1),(4,6,5,1)]
 assert [(x['recruit_attack'],x['recruit_health'],x['recruit_kept']) for x in scenario['combats']]==[(4,5,0),(6,5,0),(6,5,0)]
 expiry=scenario['unused_token_expiry'];assert expiry['old_token_uid']!=expiry['new_token_uid'] and expiry['cast_count_before']==expiry['cast_count_after'] and expiry['attack']==6 and expiry['kept']==0
 assert scenario['coin_pre_source_fixture'] is True and scenario['entirely_natural_game'] is False and scenario['same_turn_second_cast_tested'] is False
 assert audit['status']=='PASS_POST_ATTEMPT_SOURCE_AND_EVIDENCE_AUDIT'
 return f'''# 已验证的有限玩法：暗潮与迷你、熔岩兼容

源码：{commit}。

暗潮在场，单个普通迷你通过原生机制发出三叉戟，连续两轮分别对同一个普通熔岩潜伏者施放本轮第一张法术。实际身材由 2/5 → 4/5 → 6/5。两次施法、三次非空战斗及后续招募均有真实回执，并不是同一轮施放第二张法术。

每次下轮招募，原生 kept 标记重置为 0，永久攻击仍保留。第三轮特意不使用三叉戟，旧票到期消失，未增加施法计数；随后真实发出不同 UID 的新票，熔岩仍为 6/5、kept 0。暗潮独立从 1 级成长至 4 级。

原熔岩永久效果算法早已存在，本批新增的是暗潮有限房间中的兼容准入、来源认证和生命周期观察，不是新写永久算法。

实际测试：Game {checks} 项，9 份纯合同 {sum(pure.values())} 项，总计 {checks+sum(pure.values())} 项。仅执行一个新远端恢复源码树；候选树与该恢复树在测试后分别完整核验。这不是两棵独立恢复树，也不是再次执行 Game。

资金使用明确的暗潮激活前 Coin 测试夹具：原生 factory/add_hand 后公开施放，不称为无夹具自然对局。未重复旧完整矩阵。第二个迷你、同轮第二次施法、其他目标、永久增益后出售/重买、金色与其他扩展仍未开放或未验证；不代表默认启用、完整卡池或全游戏验收。

早期 overlay edbaa960 与恢复工具备份 1224f23 保留不动。此页来自实际结果，不替代原始日志、SHA 或后续远端发布核验。
'''
