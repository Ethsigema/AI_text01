"""Synthetic renderer tests, not gameplay evidence. No live logs read."""
import copy,json
from render_verified_slice import render_slice,runner
labels=[t[0] for t in runner.TESTS];commit='a'*40
s={'source_commit':commit,'runtime_mode':runner.RUNTIME_MODE,'two_runtime_copies':False,'status':'TESTS_VALIDATED_SOURCE_INTEGRITY_PASS','error':None,'validated_tests':labels}
a={'source_commit':commit,'runtime_mode':runner.RUNTIME_MODE,'two_runtime_copies':False,'runner_suite_accepted':True,'status':'PASS_POST_ATTEMPT_SOURCE_AND_EVIDENCE_AUDIT','tests':{k:{'classification':'executed_validated'} for k in labels}}
scenario={'casts':[{'attack_before':2,'attack_after':4,'health':5,'kept':1},{'attack_before':4,'attack_after':6,'health':5,'kept':1}],'combats':[{'recruit_attack':x,'recruit_health':5,'recruit_kept':0} for x in [4,6,6]],'darkcrest_final_tier':4,'unused_token_expiry':{'old_token_uid':'u10','new_token_uid':'u11','cast_count_before':2,'cast_count_after':2,'attack':6,'kept':0},'coin_pre_source_fixture':True,'entirely_natural_game':False,'same_turn_second_cast_tested':False}
f={'source_commit':commit,'status':runner.FINAL_STATUS,'tests':{t[0]:{'passed_checks':t[3]} for t in runner.TESTS},'full_game_processes':1,'full_game_acceptance':False,'default_pool_promoted':False}
f['tests'][labels[0]]={'passed_checks':123,'verified_scenario_fields':scenario}
assert '3180' in render_slice(s,a,f,scenario,commit)
checks=['synthetic_success_dynamic_count']
for name,mut in [('missing_test',lambda x:x[2]['tests'].pop(labels[-1])),('wrong_commit',lambda x:x[0].update(source_commit='b'*40)),('unvalidated',lambda x:x[1]['tests'][labels[0]].update(classification='omitted')),('wrong_cast_count',lambda x:x[3]['casts'].pop()),('wrong_pure_count',lambda x:x[2]['tests'][labels[-1]].update(passed_checks=1)),('claimed_natural',lambda x:x[3].update(entirely_natural_game=True))]:
 x=copy.deepcopy([s,a,f,scenario]);mut(x)
 try:render_slice(*x,commit)
 except AssertionError:checks.append(name)
 else:raise AssertionError('accepted '+name)
fs={**s,'status':'FAILED_OR_INCOMPLETE_ATTEMPT','error':'synthetic failure','validated_tests':[]};fa={**a,'runner_suite_accepted':False,'tests':{labels[0]:{'classification':'executed_failed'},labels[1]:{'classification':'omitted'}}}
assert '未获验收' in render_slice(fs,fa,None,None,commit);checks.append('failure_not_success')
try:render_slice({**fs,'status':'NOT_RUN'},fa,None,None,commit)
except AssertionError:checks.append('unrun_no_attempt_rejected')
else:raise AssertionError('accepted unrun')
print(json.dumps({'status':'PASS_SYNTHETIC_RENDERER_ONLY','passed':len(checks),'checks':checks,'read_live_logs':False,'game_started':False,'package_created':False},indent=2))
