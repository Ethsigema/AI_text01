extends "res://tests/darkcrest_lava_rebuy_20261112/real_matrix.gd"
# One new permanent-buff scenario. No prior full matrix initializer is run.
const MINI="BG23_000"
const TRIDENT="BG23_000t"
var mini_casts=[]
var buff_combats=[]
var acquisition=[]
func observed_private_value(value: Variant,depth: int=0) -> Variant:
 # Observation only: preserve Object identity without serializing native authority.
 if depth>64:return {"snapshot_depth_exceeded":true}
 if value is WeakRef:
  var target=value.get_ref()
  return {"observed_weakref_instance":value.get_instance_id(),"target_instance":target.get_instance_id() if target!=null else 0}
 if value is Object:return {"observed_object_instance":value.get_instance_id()}
 if value is Dictionary:
  var result={}
  for key in value:result[key]=observed_private_value(value[key],depth+1)
  return result
 if value is Array:
  var result=[]
  for item in value:result.append(observed_private_value(item,depth+1))
  return result
 return value
func observer_snapshot() -> Dictionary:
 var helper=game._darkcrest_host._mini;var result={}
 for key in ["_play","_board","_delivery","_tokens","_flush_tokens","_cast","_reset","_poison","_flush_owner","_flush_window","_expiry"]:result[key]=observed_private_value(helper.get(key))
 result.game_context=observed_private_value(game._darkcrest_mini_context)
 result.game_nonce=observed_private_value(game._darkcrest_mini_nonce)
 return result
func original_mini_token(spell: Dictionary,mini: Dictionary) -> bool:
 var p=game.state.players[0];var h=game._darkcrest_host;var helper=h._mini
 var record=helper._tokens.get(spell.uid,{})
 return must(not record.is_empty() and is_same(record.get("unit"),spell) and is_same(record.get("owner"),p) and record.get("source_uid")==mini.uid and record.get("round")==game.state.round and record.get("ready")==true and record.get("used")==false and helper.token_error(h,game,p,spell).is_empty(),"original_waiting_token_bound_to_exact_mini_owner_round")
func token_negative_checks(spell: Dictionary,mini: Dictionary,lava: Dictionary) -> bool:
 var p=game.state.players[0];var h=game._darkcrest_host;var helper=h._mini;var before=live_snapshot()
 if not must(not helper.token_error(h,game,p,spell.duplicate(true)).is_empty(),"copied_mini_token_rejected"):return false
 if not must(not helper.token_error(h,game,game.state.players[1],spell).is_empty(),"wrong_owner_mini_token_rejected"):return false
 if not must(not helper.cast_preflight(h,game,p,spell,lava.duplicate(true)).is_empty(),"copied_lava_target_rejected"):return false
 if not must(not helper.begin(h,game,p,p.hand.find(spell),{}).is_empty(),"fabricated_mini_cast_context_rejected"):return false
 return must(game.Darkcrest.Sources.same(before,live_snapshot()),"mini_preconsume_negative_calls_leave_full_state_unchanged")
func live_snapshot() -> Dictionary:
 var out=super.live_snapshot();out.mini_permanent=observer_snapshot();return out
func buy_before_source(id: String,max_rolls: int) -> Dictionary:
 var p=game.state.players[0]
 for attempt in range(max_rolls+1):
  var offers=p.shop.filter(func(u):return u.card_id==id and not u.golden)
  if not offers.is_empty():
   if not fund(6):return {}
   var unit=offers[0]
   if not must(command(0,{"type":"buy","index":p.shop.find(unit)}).get("ok",false) and p.hand.any(func(u):return is_same(u,unit)),"pre_source_original_purchase_"+id):return {}
   acquisition.append({"id":id,"uid":unit.uid,"rolls":attempt,"source_owned":false});return unit
  if attempt==max_rolls:break
  if not fund(4) or not command(0,{"type":"roll"}).get("ok",false):return {}
 must(false,"bounded_pre_source_purchase_exhausted_"+id);return {}
func prepare_room() -> Dictionary:
 game=load("res://core/game.gd").new()
 var room=load("res://core/room_config.gd").new();room.reset(cat)
 room.data.enabled_minions=ROOM6.duplicate();room.data.enabled_spells=["BG28_810"]
 room.data.selected_hero="TB_BaconShop_HERO_01";room.data.enabled_heroes=["TB_BaconShop_HERO_01"];room.data.bot_count=3;room.data.seed=20261120
 for key in ["enabled_anomalies","enabled_quests","enabled_rewards","enabled_trinkets"]:room.data[key]=[]
 if not must(game.start(room.data,cat).get("ok",false) and game.state.players.size()==4,"native_four_player_full_23_card_room"):return {}
 var p=game.state.players[0];var mini=buy_before_source(MINI,80)
 if mini.is_empty():return {}
 if not fund(int(p.upgrade_cost)+3) or not command(0,{"type":"upgrade"}).get("ok",false):return {}
 var lava=buy_before_source(LAVA,100)
 if lava.is_empty():return {}
 for tier in [3,4,5]:
  if not fund(int(p.upgrade_cost)+3):return {}
  if not must(command(0,{"type":"upgrade"}).get("ok",false) and p.tier==tier,"pre_source_public_tavern_upgrade_"+str(tier)):return {}
 var parent=quick_parent()
 if parent.is_empty() or not source_play(parent):return {}
 if not must(p.hand.any(func(u):return is_same(u,mini)) and p.hand.any(func(u):return is_same(u,lava)),"mini_lava_original_hand_before_play"):return {}
 return {"mini":mini,"lava":lava,"parent":parent}
func rejected_public(command_value: Dictionary,label: String) -> bool:
 var before=live_snapshot();var refs=receipt_refs();var result=game.apply_command(0,command_value)
 return must(not result.get("ok",true) and game.Darkcrest.Sources.same(before,live_snapshot()) and same_receipt_refs(refs),label)
func trident() -> Dictionary:
 var found=game.state.players[0].hand.filter(func(u):return u.card_id==TRIDENT)
 if not must(found.size()==1,"one_real_mini_trident_in_original_hand"):return {}
 return found[0]
func cast_first(mini: Dictionary,lava: Dictionary,parent: Dictionary,expected_attack: int) -> bool:
 var p=game.state.players[0];var spell=trident()
 if spell.is_empty():return false
 if not original_mini_token(spell,mini) or not token_negative_checks(spell,mini,lava):return false
 if not must(spell.is_spellcraft and spell.temporary and spell.expires_at_end_turn and lava.spellcraft_kept==0,"real_temporary_spell_and_reset_lava_before_cast"):return false
 # Real wrong-target request is held before hand consumption; no target is forged.
 if not rejected_public({"type":"play","index":p.hand.find(spell),"target":p.board.find(parent),"target_zone":"board","position":-1},"other_original_board_target_held_no_consumption"):return false
 var uid=game.next_uid;var rng=game.rng.state;var pool=game.pool.duplicate(true);var spell_pool=game.spell_pool.duplicate(true);var stats=p.stats.spells
 var old= lava.attack;var parent_values=parent.duplicate(true);var mini_values=mini.duplicate(true)
 var parent_record=game._darkcrest_host._parents[parent.uid];var parent_record_values=parent_record.duplicate(true)
 if not must(command(0,{"type":"play","index":p.hand.find(spell),"target":p.board.find(lava),"target_zone":"board","position":-1}).get("ok",false),"public_native_first_trident_cast"):return false
 if not must(p.board.any(func(u):return is_same(u,lava)) and lava.attack==expected_attack and lava.attack==old+2 and lava.health==5 and lava.max_health==5 and lava.spellcraft_kept==1 and lava.temporary_buffs.is_empty(),"first_trident_permanent_exact_plus2_kept1_no_temporary_layer"):return false
 if not must(not p.hand.any(func(u):return is_same(u,spell) or u.uid==spell.uid) and p.stats.spells==stats+1 and game.next_uid==uid and game.rng.state==rng and game.Darkcrest.Sources.same(pool,game.pool) and game.Darkcrest.Sources.same(spell_pool,game.spell_pool),"cast_consumes_original_token_only_no_factory_rng_stock"):return false
 if not must(game.Darkcrest.Sources.same(parent_values,parent) and game.Darkcrest.Sources.same(mini_values,mini) and is_same(game._darkcrest_host._parents[parent.uid],parent_record) and game.Darkcrest.Sources.same(parent_record_values,parent_record),"mini_cast_does_not_consume_darkcrest_growth_or_source_state"):return false
 var helper=game._darkcrest_host._mini
 if not must(helper._tokens[spell.uid].used==true and helper._cast.is_empty() and helper._poison.is_empty() and game._darkcrest_host._lava_play._board[lava.uid].mini_steps==mini_casts.size()+1,"actual_completed_cast_updates_only_observer_receipt"):return false
 var after=live_snapshot()
 if not must(not helper.token_error(game._darkcrest_host,game,p,spell).is_empty() and game.Darkcrest.Sources.same(after,live_snapshot()),"used_original_token_replay_rejected_without_mutation"):return false
 if not rejected_public({"type":"sell","index":p.board.find(lava)},"buffed_lava_sale_remains_held_no_consumption"):return false
 mini_casts.append({"round":game.state.round,"source_uid":mini.uid,"token_uid":spell.uid,"target_uid":lava.uid,"attack_before":old,"attack_after":lava.attack,"health":lava.health,"kept":lava.spellcraft_kept});return true
func inspect_permanent_combat(lava: Dictionary,attack: int,round_number: int) -> bool:
 var p=game.state.players[0];var matches=game.last_combats.filter(func(c):return c.get("left_player")==0 or c.get("right_player")==0)
 if not must(matches.size()==1,"one_actual_mixed_board_combat"):return false
 var result=matches[0];var side="left" if result.left_player==0 else "right";var enemy="right" if side=="left" else "left"
 var starts=result.log.filter(func(e):return e.get("event")=="combat_start")
 if not must(result.get("error","")=="" and starts.size()==1 and not starts[0][enemy].is_empty(),"actual_nonempty_combat_for_permanent_buff"):return false
 var copies=starts[0][side].filter(func(u):return u.get("uid")==lava.uid)
 if not must(copies.size()==1 and copies[0].attack==attack and copies[0].health==5,"actual_combat_copy_includes_permanent_buff"):return false
 if not must(p.board.any(func(u):return is_same(u,lava)) and lava.attack==attack and lava.health==5 and lava.max_health==5 and lava.spellcraft_kept==0 and lava.temporary_buffs.is_empty(),"next_recruit_preserves_buff_and_native_kept_reset"):return false
 buff_combats.append({"round":round_number,"target_uid":lava.uid,"combat_start":copies[0].duplicate(true),"recruit_attack":lava.attack,"recruit_health":lava.health,"recruit_kept":lava.spellcraft_kept});return true
func permanent_case() -> bool:
 var setup=prepare_room()
 if setup.is_empty():return false
 var mini=setup.mini;var lava=setup.lava;var parent=setup.parent;var p=game.state.players[0]
 if not public_lava_play(lava,0):return false
 var before_uid=game.next_uid;var before_hand=p.hand.map(func(u):return u.uid)
 if not must(command(0,{"type":"play","index":p.hand.find(mini),"target":-1,"position":1}).get("ok",false),"public_original_mini_play_and_waiting_grant"):return false
 if not must(p.board.any(func(u):return is_same(u,mini)) and not p.hand.any(func(u):return is_same(u,mini)),"mini_original_hand_to_board"):return false
 var token=trident()
 if token.is_empty():return false
 if not must(token.uid not in before_hand and game.next_uid==before_uid+1,"mini_play_native_waiting_one_fresh_spell_uid"):return false
 if not cast_first(mini,lava,parent,4) or not prepare_real_opponents():return false
 if not next_round(parent,2) or not inspect_permanent_combat(lava,4,1):return false
 var next_token=trident()
 if next_token.is_empty():return false
 if not must(next_token.uid!=token.uid and not is_same(next_token,token),"next_recruit_waiting_issues_distinct_original_spell"):return false
 if not must(command(0,{"type":"move","from":p.board.find(lava),"to":2}).get("ok",false),"public_move_before_second_round_target"):return false
 if not cast_first(mini,lava,parent,6):return false
 if not next_round(parent,3) or not inspect_permanent_combat(lava,6,2):return false
 # Third round deliberately leaves the native Mini token unused.
 var unused=trident()
 if unused.is_empty():return false
 var unused_uid=unused.uid;var spell_count=p.stats.spells
 if not must(lava.attack==6 and lava.spellcraft_kept==0,"unused_round_starts_permanent6_kept0"):return false
 if not next_round(parent,4) or not inspect_permanent_combat(lava,6,3):return false
 if not must(not p.hand.any(func(u):return is_same(u,unused) or u.uid==unused_uid) and p.stats.spells==spell_count,"unused_original_mini_token_expires_without_cast_counter"):return false
 if not must(game._darkcrest_host._mini._tokens[unused_uid].get("expired")==true and game._darkcrest_host._mini._tokens[unused_uid].get("used")==false and game._darkcrest_host._mini._expiry.is_empty(),"unused_original_token_native_expiry_observed_not_cast"):return false
 var replacement=trident()
 if replacement.is_empty():return false
 if not must(replacement.uid!=unused_uid and not is_same(replacement,unused) and replacement.is_spellcraft and replacement.expires_at_end_turn,"unused_expiry_followed_by_distinct_native_regrant"):return false
 if not original_mini_token(replacement,mini):return false
 var expiry={"old_token_uid":unused_uid,"new_token_uid":replacement.uid,"cast_count_before":spell_count,"cast_count_after":p.stats.spells,"attack":lava.attack,"kept":lava.spellcraft_kept,"round":game.state.round}
 var result={"scope":"one ordinary Mini authentic first Spellcraft per turn permanently buffs one Lava in finite Darkcrest room","seed":20261120,"checks":checks,"acquisitions":acquisition,"mini_uid":mini.uid,"lava_uid":lava.uid,"darkcrest_uid":parent.uid,"darkcrest_final_tier":4,"casts":mini_casts,"combats":buff_combats,"unused_token_expiry":expiry,"coin_pre_source_fixture":true,"entirely_natural_game":false,"same_turn_second_cast_tested":false,"buffed_sale_rebuy_opened":false,"old_matrices_repeated":false}
 var file=FileAccess.open(get_script().resource_path.get_base_dir()+"/DARKCREST_LAVA_PERMANENT_MATRIX_RESULT.json",FileAccess.WRITE)
 if not must(file!=null,"matrix_result_file"):return false
 file.store_string(JSON.stringify(result,"  ")+"\n");file.close();return true
func _initialize():
 print("DARKCREST_LAVA_PERMANENT_MATRIX_LOAD_BEGIN")
 var Game=load("res://core/game.gd")
 if not must(Game!=null and Game.can_instantiate(),"complete_game_script"):return
 cat=load("res://core/catalog.gd").new();cat.load_catalog()
 if not must(cat.load_errors.is_empty(),"complete_catalog"):return
 if not permanent_case():return
 print("DARKCREST_LAVA_PERMANENT_REAL_MATRIX_PASS cases=1 casts=2 combats=3 checks=",checks)
 quit(0)
