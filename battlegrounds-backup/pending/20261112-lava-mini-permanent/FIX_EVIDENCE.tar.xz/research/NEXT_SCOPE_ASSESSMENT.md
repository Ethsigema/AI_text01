# Next finite combination: Mini Trident on certified ordinary Lava

2026-11-12; read-only source: develop_lava_rebuy_20261112/candidate. No source changes, tree copies or Game/Godot execution. Prior evidence: develop_lava_followup_20261112/research/LAVA_PERMANENT_NEXT_ASSESSMENT.md. Source identity remains Darkcrest BG31_920.

## Recommendation

Proceed only as a separately bounded combination: one ordinary native Mini Myrmidon BG23_000, one certified ordinary Lava BG23_009, ordinary shop-origin Darkcrest; one actually delivered BG23_000t per round targeting that original board Lava. Verify the first spell's permanent +2 through native combat and next recruit, then optionally the next round's first +2. Do not call the permanent effect a new implementation: original Game already implements it. New work is authentic admission/observation across currently held content boundaries.

Hold second Mini, second same-round targeted cast, other targets/spells, golden/triples, automatic/repeated casts, Mini purchase under active Darkcrest, Mini sale, buffed-Lava sale/rebuy, projections with Mini, external listeners and after-Tier6 EOT. This is materially smaller than the prior two-Mini first-versus-second-temporary matrix. It proves first-permanent and reset, not full second-spell-temporary behavior.

## Source evidence and unchanged native behavior

Use local research/bubble_crown_spellcraft/native/{BG23_009,BG23_000,BG23_000t}.xml and current manifest/source records cited by the previous report. Mini1/4 tier1 grants child83914/BG23_000t; child single +2 attack temporary target spell; Lava count1. Child is a dependency, not a new Tavern-spell-pool entry. Revalidate mirrored effective fields when implementing, not ID-only admission.

Current game.gd:5264 calls _grant_spellcraft after native insertion/summon listeners; :15946-49 queues and immediately flushes Mini's real ticket. :5337-42 first-hand-Spellcraft logic changes local duration and kept0->1; native payload performs attack increase. :12040-60 expires temporary layers then resets kept; :12164-67 next recruit queues actual sources and flushes. LimitedTurn.validate_unit_state:111-133 independently validates native counters/effect identity. Do not rewrite any of these arithmetic effects or fabricate reset.

## Required authority boundaries

1. Mini actual hand-play and board custody. Acquire ordinary Mini before Darkcrest, keep it in hand while buying/playing Darkcrest; existing hand admission already recognizes Mini. New actual play observer must bind original Game/owner/hand index/unit/UID/context before native insertion, original board placement afterwards. Mini board value is immutable1/4 and count single. Do not use hand shape as birth proof or copy Lava _board permission by ID.

2. Important new timing distinction: Lava has no own Spellcraft, so its prior play completion safely happened before OUTER flush. Mini calls _grant_spellcraft INSIDE native play, before stats.played++ and later suffix callbacks. The old 'hand exactly minus1 at wrapper completion' cannot be reused. Establish a narrow original play insertion checkpoint before native _grant_spellcraft, not a pre-signed final play receipt. Waiting can validate that original in-flight source through the same actual play window; final native suffix validates full result. Partial play failure must retain/report actual insertion/delivery rather than invent rollback or orphan reusable authorization.

3. Mini native Waiting issue ledger. Hook only the exact source/ticket and original active flush window, child factory original object/UID and successful _add_hand. Reuse structural Waiting semantics, not Darkcrest token authority. Bind owner/round/sourceUID/childUID/effect index/count and original refs; fail before token consumption if missing/duplicated/copied/expired. Token shape in hand_error alone cannot authorize casting. Next-recruit actual Mini tickets need the same lifecycle, not special fixture issuance. Full hand/pending delivery can remain held for this first finite release.

4. Original targeted hand cast. Before consume validate issued token, authentic Lava record, unique board target object/index, kept0, no pending/copies/repeat modifiers. Bind exact original Game cast window/selected target; call the existing native cast. Observe +2 attack only, unchanged health/keywords/base/source/effects, kept0->1, no added temporary_buffs, real token gone/spells+1. Update private expected Lava state only from this completed native transition; never rewrite unit attack or copy arbitrary current snapshot on validation. Partial-effect errors must be handled explicitly, not falsely unconsumed or repeatable.

5. Real next-recruit observer. Verify original prior attack+kept state immediately before native expiry/reset; afterwards require attack unchanged, kept1->0, no unexpected layer changes, same object/UID and exact round progression. Then update private expected state before native source grant preflight. Combat uses normal copied values, not new combat logic. One successful board cast is insufficient without the next-recruit proof.

6. Host/EOT integration. owner_error permits only certified Mini body/token and transitioned Lava. Preserve full-board identities/order/value snapshots, map only Darkcrest programs to actual board indices; skip Mini only after authentication. Mini has no EOT growth callback, but next-recruit grant is real. All disposable purchase projections must continue held for Mini-bearing owners; this extension cannot expose Mini/Lava grant/cast/reset authority through projection. Existing sale routine remains limited to2/5 kept0, so permanently buffed Lava sale stays explicitly held.

## One finite native case

Four-player ordinary verified route, existing Edwin without ability, no anomaly/quest/trinket/repeat effects. Naturally acquire Lava and Mini in hand before active source, acquire/play shop-origin Darkcrest, then native Lava play and Mini play. Receive real Mini token during Mini native play and target exact Lava:2/5->4/5 kept1, no temporary +2 entry, token consumed. Keep Darkcrest finite growth below6; EOT actual nonempty combat should use4attack, next recruit original Lava still4/5 kept0 and real Mini produces next token. A second round's first token can prove4->6 permanent and a further real recruit keeps6, but do not substitute that for second-same-round temporary coverage. Use intact native pools and public commands, no direct tokens/UID/RNG/tier/stock assignment.

Negative preconsume cases: wrong token/source/owner/round/ref, sameUID copy, shop target/other board target, kept1/repeated cast, second Mini, buffs/golden/foreign spells, fake/released shadow, malformed context, altered target index. Pure shape/transition tests must be labeled content-only; actual provenance needs real Game logs. Record source-play ticket ordering, delivered child UID, consumed hand ref, owner counters, full board pre/post, combat attack and recruit reset separately.

## Complexity / comparison

This is medium-high complexity, likely a small separate Mini lifecycle helper plus Host, existing Lava helper, Game checkpoint wiring, Waiting integration and source/mirror changes (roughly6-8 production surfaces; exact count after design). Highest risks are in-play flush before final play receipt and current-to-next-round custody, not +2 arithmetic. Budget source backup before long native tests; current1.5GB disk means no new full copy here.

Smaller alternative: ordinary Mini native play+real token issuance in the Darkcrest board, but keep all Mini casts held and verify token expiry/regrant only. It covers a real delivery lifecycle with fewer Lava cast/reset transitions, yet offers less gameplay value and cannot claim Lava permanent behavior. Recommend the bounded first-permanent combination if this lifecycle work is acceptable; otherwise split at this explicit intermediate acceptance point, not a whitelist-only milestone.
