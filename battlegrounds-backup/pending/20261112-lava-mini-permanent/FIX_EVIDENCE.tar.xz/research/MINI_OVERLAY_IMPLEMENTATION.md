# Mini overlay v2, unaccepted

Seven files only; unchanged full-tree source remains untouched. Existing six-file SHA preimage in implementation_overlay/PREIMAGE_SHA256.json. New core/darkcrest_mini.gd observes original play insertion, native Waiting active flush factory/add_hand/full-flush, original targeted cast and next-recruit reset. No stat/counter/UID/pool writes. Changes to helper expected records are observations only. V1 early source archive preserved.

Mini strict body admission uses an explicit new branch, not changed STRICT_HAND_BODIES five-card constant. Child source complete effective record comes from existing Crown contract and raw image path. Child full native factory dictionary is checked before saving expected values; no extra markers allowed. Delivery final receipt revalidates original window, owner/source/ticket count0, round and factory cursor, exact hand append. Token ready only after full native flush suffix.

Actual Game context has9 exact fields (owner/unit/target/nonce references; index/position/round/sequence ints; kind). Source insertion is tentative only within that original play. Full native play suffix confirms board/hand refs and values; partial failure poisons combination without fictitious rollback. Cast validates target in real _play before native consumption even though outer command_error only checks token. Cast intermediate expected states are confined to original context, full native suffix commits +2 expected snapshot and used token.

Game native temporary expiry/reset bracket observes old expected snapshot -> kept0 while attack stays; next-round unchanged-cast skipped rounds work by advancing verified mini_round. Native hand expiry bracket records unused token expiry, and subsequent grants reject unobserved old unused departure. These observer contexts do not manufacture native tickets. Shadow taint rejects all Mini actual endpoints.

No arbitrary lifetime2 cap: two rounds are tests, not skill rules. Each round's first cast only; added safe signed-int attack increment limit and bounded mini_steps; Darkcrest MAX6 EOT boundary unchanged. SecondMini/same-turn secondcast/other targets/Mini sale/permanentLava sale/rebuy held. Original native +2/permanence/reset remains unchanged.

Validation: helper standalone check-only against base project passes; parent must overlay and perform integrated Host/Game/Waiting parse before any full test. No Game run. APIs provided to test/review; review has not yet declared final acceptance.

## v3
Added pure flush_matches(active,guard,flush): nonnull RefCounted, existing guard, guard value RefCounted and exact reference. All delivery begin/factory/complete/close use it, so missing guard plus null cannot satisfy proof. Source fullshape requires explicit card.has for nullable fields before comparison. Only overlay helper changed; v2 applied candidate untouched. Helper standalone syntax exit0; no Game.
