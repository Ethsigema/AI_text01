# Mini→Lava 首次永久附魔：独立只读审查要点

来源：develop_lava_rebuy_20261112/candidate与NEXT_SCOPE_ASSESSMENT.md。未复制树、未改生产、未运行Godot/Game。只评估本批单Mini/单Lava、暗潮前购买、首张原生Trident每轮永久+2的有限组合；原算术/kept/reset已存在，不算新增效果。

## 原链实际核对

Game原minion play在_notify_summoned后调用_grant_spellcraft（约5264），然后才stats.played++和Panther/Boogie等suffix。原Waiting.flush签发factory→stamp→ticket.count减1/移除→_add_hand→入手确认，再Greta/Delivery/其它generation记录，最终才移除_active_flushes guard。故“入手已发生”与“flush及整个play成功”是三个不同阶段。

Game原cast约5339先把kept0变1、temporary变false，之后才payload和后监听。下一recruit约12040先原temporary层过期，再LimitedTurn.reset_turn，后面再发新一轮来源票。不得手工增加attack或把kept清零代替这两条原生链。

## 必须绑定的三阶段

1. 原hand→board：实际Game/Host/helper、owner、原Mini对象/UID/index/position、round/sequence、原hand和board全引用/值。插入checkpoint仅准绑定窗口中的该source参与一次内部Waiting，不是最终稳定board许可；不能仅复制字典或改card_id取得。
2. 原Waiting：给Mini独立真实flush capability，绑定_active_flushes的实际当前窗口、原source/ticket身份和值、effect index/count/round、factory前UID、实际新child对象、原hand唯一append。不能借Darkcrest _spells/_grants证书或复用单纯bool guard作为任意调用授权。当前可能同批有Darkcrest票，必须保留其原窗口语义，不能替换导致旧来源凭证断裂。
3. 原play suffix：只在原body完成且所有阶段一致时稳定Mini custody；hand应原手牌减Mini加真实签发child（以及明确认证的原发放结果），不是旧Lava的严格减一。若插入/发票已发生但后续失败，记录真实部分作用并失效该未完成链，不rollback、不再签票、不把现状重新采样当成功。

## Token与Lava transition

cast消费前：issued原token对象、owner/sourceUID/round/未消费、真实hand唯一；原目标必须同一已认证Lava board对象和当前index，kept0、没有其他buff/repeat、只有本轮首张。拒复制/错owner/同UID替代/旧票/同轮第二张/其他目标/投影。token未通过不得先移出hand。

成功观察按旧私有expected派生：attack+2，health/max_health不变，kept0→1，无temporary_buffs新增，其余完整字段与原对象不变；原token确实离手，原spell计数+1，UID/RNG/pool只允许原路径有据可查的变化。禁止宽松地把任何当前unit复制为新expected。native kept已变但payload失败、或payload完成尾部失败均不可复用票或冒称整命令成功；失效状态应使后续受保护动作held。

下一recruit观察必须始于原expiry/reset之前的已认证expected，结束于原reset之后且在新Waiting owner/source检查之前。准确绑定同Game/owner/unit、旧轮→新轮一次，期望永久attack不变、kept1→0，其余限定层不变。战斗副本不是live unit权限来源；不把战斗伤害或副本状态写回expected。第二轮4→6是下一轮首张，不证明同轮第二张temporary行为。

## 生命周期与边界

Mini来源/issued票/已consume记录应分别保存原身份，pending完成即消耗，异常保留拒绝状态而非重新打开窗口。投影taint对Mini play、delivery、cast、reset全入口拒；既有buy projection在Mini-bearing owner held。Mini售出、附魔后Lava售出/rebuy、双Mini/golden/triple、外来target spell、Tier6后EOT均保持held。

EOT仍冻结完整board身份/值，只映射Darkcrest真实index；跳过Mini前必须其稳定custody已核。Lava owner_error需要精确transition值而非放宽所有attack；售出仍保持原2/5边界。手满/排队竞争若暂未覆盖应在原play/投递前held，而不是先消耗后发现无法认证。

## 有限证据建议

一条真实四人原生路线：暗潮前publicbuy Mini/Lava，实际play暗潮→Lava→Mini，内部真实ticket/factory/append，publiccast同Lava4/5 kept1，实际combat非空对手，原nextrecruit4/5 kept0并重发新票，下一轮原cast6/5再combat/recruit。记录每段UID/对象、source index、ticket round与日志。纯负例验证上下文复制/篡改、重入/旧窗口、错owner/目标、partial failure不能升级、reset越轮/重复、影子。未实际运行，不把静态或纯内容检查当真实来源凭证证明。
