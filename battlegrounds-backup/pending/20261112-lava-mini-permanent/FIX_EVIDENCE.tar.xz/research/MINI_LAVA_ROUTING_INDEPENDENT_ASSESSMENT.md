# 单普通 Mini → 原始 Mini-Trident → 普通 Lava：最新独立路由评估

只读输入 `develop_lava_rebuy_20261112/candidate`；不改候选、不复制1.5GB树、不运行Game。以下行号对应本输入。已读取软件工程技能。当前范围保留纳迦、排除畸变；不新增英雄/其它机制。父任务已选择单Mini两轮方案进行生产，本文只是证据和最小边界。

## 推荐及定义

推荐 1 普通 BG31_920 暗潮仍在场 + 1 普通 BG23_009 Lava + 1 普通 BG23_000 Mini，每轮只接受该Mini原生发出的BG23_000t，从真实手牌对已认证board Lava施放。两轮观察2/5→4/5永久，下一招募kept0，再4/5→6/5永久。**原Game早已有“首个手牌塑造永久”算法；新增仅是Darkcrest有限房间的来源/cast/custody/回合兼容，不是新增能力。** 不开放金色、第二Mini、多Lava、额外自动施法、词条/生命值法术、空位v1-v3、复制、save或任意目标。

仅move after rebuy更小但不构成新内容：`game.gd:7189-7195`已原对象remove/insert并同步光环；Darkcrest command允许move、Lava custody不绑定固定board index，旧Lava矩阵已经验证move与动态暗潮索引。rebuy后再move属于有用回归，不宜单列下一实现批。

## 1. 独立来源证据

- `data/catalog_raw.json` + `data/catalog.json`：Mini Tier1 1/4，完整effects仅 `spellcraft,card_id=BG23_000t`；Lava Tier2 2/5，完整effects仅 `spellcraft_permanent,count=1`。两父卡在current_scope_manifest的official+naga_overlay中。
- Mini token cost0、category塑造法术、temporary=true，完整payload是target `spell_buff,attack=2,health=0,allow_shop=true,temporary=true`。token是依赖，不是酒馆法术池成员。有限host只开放board Lava目标，不能通过改canonical allow_shop来伪造更窄卡牌文本。
- native：`research/bubble_crown_spellcraft/native/BG23_000.xml` Entity80738 的BACON_SPELLCRAFT_ID83914，精确连接BG23_000t Entity83914。普通文本“直到下个回合，使一个随从获得+2攻击力。”Lava Entity80747、NUM1=1，文本“每回合从手牌对本随从使用的第一张塑造法术…永久有效”。
- XML SHA256：Mini `013e0c5222d8f63c02fc87fb994c3b7956b103f7d32ff4c70c1e78b54e40e0c1`；token `9a85c7c8bc9925220e095e18658666c8f909cb93f4c28f2dd2a9ac6814484246`；Lava `a45d79387a0ff61b40e8c56a984e20a364bac8b58a44fcc6988662814008edda`。
- 已存源revision链接：Mini https://wiki.ifindhs.com/index.php?title=%E9%85%92%E9%A6%86%E6%88%98%E6%A3%8B/%E8%BF%B7%E4%BD%A0%E4%BE%8D%E4%BB%8E&oldid=166019 ；token https://wiki.ifindhs.com/index.php?title=酒馆战棋/迷你三叉戟&oldid=166020 ；Lava https://wiki.ifindhs.com/index.php?title=%E9%85%92%E9%A6%86%E6%88%98%E6%A3%8B/%E7%86%94%E5%B2%A9%E6%BD%9C%E4%BC%8F%E8%80%85&oldid=142997 。本次只读工程证据，未联网再核。

## 2. 原生完整路由和两个容易漏掉的交接点

1. `game.gd:4032-4055` 外层play先Darkcrest command_error，随后原play链。`5031`原hand.remove，`5040`原board.insert，`5261`原 `_grant_spellcraft`，`15946-15949`原Waiting.queue_grants/flush。
2. **Mini first grant在原play body内部，早于外层complete。** 若仿Lava只在外层返回后建Mini source custody，5261的第一次真实发牌会没有权限。须绑定真实hand-play context，在原board插入后形成有界pending/真实source观察供该grant使用，成功suffix再完成。Mini原生hand差值是“移除Mini + 新生成token”，不等于LavaPlay.complete目前只允许hand减一的合同。
3. `spellcraft_waiting.gd:59-83`验证完整catalog源程序与真实child；`225-247`验证live source并创建六字段ticket；`255-268`原queue写票。`274-282`按当前board顺序和效果顺序选择票，不是保存FIFO。
4. `330-362`原 `_unit`唯一分配child UID，is_spellcraft=true、expires_at_end_turn=true，debit原ticket，再 `_add_hand`；不扣普通随从库存，不发明复制实体。
5. **Mini-only flush现无Darkcrest capability。** `296-302`仅待票含Darkcrest parents时创建RefCounted窗口，纯旧来源用bool guard。`325-365`只有Darkcrest来源走host snapshot/bind/complete。`darkcrest_host.gd:234-235`非parent直接inactive。因此不能把Mini token当BG31_920t、借用managed暗潮grant或让unissued自动合法。Mini需要绑定真实flush/ticket/source/原factory子对象的独立有限证明；如加窗口，只为本次实际Mini delivery建立，不把bool或形状当权限。
6. 真实cast前：`game.gd:4586-4588` LimitedTurn.target_error；原手牌消费仍在5031。`5332-5342`读取temporary/is_spellcraft和真实target passive，首个将kept0→1且该cast temporary=false。`6538-6555`原buff payload仍执行；不应另写攻击数值代替原payload。
7. `5537-5542`只给仍临时的cast记temporary_buffs，因此首个Mini cast应无临时层。`5547`原spells+1；5548之后酒馆法术归因独立，不因Mini误增tavern_spells。后续所有原cast/target/listener suffix仍保留。
8. 未用child在`11042`真实EOT从hand到期移除；Waiting原cancel_end_turn在phase变化前取消票（Waiting217-223）。下一招募`12041-12060`原临时层清除后LimitedTurn.reset_turn；`limited_turn_state.gd:102-105`kept归零。`12164-12167`随后真实board Mini+暗潮一起queue/flush新轮资源。**必须先完成Lava reset的私有状态观察，再让新轮Darkcrest.queue_error/owner_error读取它。**

## 3. 当前三组阻塞及最小开放入口

A. Mini真实来源：`darkcrest_host.gd:80-85` board只认暗潮或已认证Lava；`193-204` active只买暗潮/窄Lava，play非parent只窄Lava。`begin_eot:487-494`非Lava均强制普通暗潮程序。Mini只有Spellcraft、没有EOT效果，因此可在精确源身份/已认证Mini custody后把它作为无EOT程序实体保留，仍要求原完整EndTurn plan恰等于所有暗潮程序。不可用任意ID白名单跳过source完整检查。

B. 原始Mini token：`hand_error:140-145`非暗潮hand只接受普通minion，token直接other_hand_listener_held；`command_error:204`非暗潮token仍other_play_held。应只接受该实际Mini原生发的同对象/UID/owner/round/token完整程序，并在真实手牌cast target为已认证同owner普通Lava时建立独立nonce/context。复制、同UID替身、过期、已用、外部factory、不同目标、不同zone拒绝在消费前；不要把Mini权限写进暗潮 `_spells/_grants`，也不要恢复projection-only的任何issuance能力。

C. Lava状态迁移：`darkcrest_lava_play.gd:11-20`不只是snapshot，而是调用严格hand_state_error并要求attack2/health5/max5/kept0；`77-81`还要求当前完整字典等于旧snapshot。因此只更新snapshot仍不够，fresh factory admission与已认证board演化验证必须分离。原base_unit仍2/5；current attack只允许被这次真实Mini cast原payload精确+2，health/max/keywords/attachments等不变，kept0→1，临时层仍空。随后实际招募reset只允许kept1→0、永久attack保留。每步基于原对象/真实回合边界观察，不每次“重抄live即合法”，不通过通用放宽hand_shape来接受任意buff。

有限新增入口建议仅为：真实Mini play→该次Waiting原发牌→真实手牌Mini目标cast→Lava private expected状态提交→原EOT完整性→原next recruit reset与新票发放。继续拒绝额外购买投影（先预购）、buff后sell如未独立review、Mini出售/重放/变形、任意二次外部塑造、黄金、第二Mini、更多目标。已有Lava sale不能因board_error放宽而无意开放未验buffed sale；要明确保留hold或单独验证，而非忘记该后门。

## 4. 一间真实Game、单case两轮可达方案

- 沿原ROOM6完整23个纳迦/all候选和Edwin四玩家测试房，不启额外英雄技能/anomaly/quest/reward/trinket。不改随机域、不改库存/UID/RNG。先公开买普通Mini和Lava留在hand，再公开买普通暗潮并play。Mini/Lava在source取得前可顺序搜索，不需要罕见三者同shop；最后暗潮shop搜索仍有界。Coin若用既有factory/add_hand/public Coin fixture，只能source取得前，显式披露，不称整局纯自然。
- **先play Lava，再play Mini。** 当前Lava.preflight:42要求它入场前board全是parent；这样无需额外修改“Mini已在场时Lava入场”的边界，也不需要active Mini购买。三实体都是真实原shop→hand→board对象。
- Mini play原发1张token；验证UID只增1、原ticket耗尽、原hand加该子对象、Mini仍1/4。Darkcrest本轮token可保持手中直至原EOT到期，无须消耗随机source token来碰运气选Mini。
- 第一次public cast原Mini token给实际Lava：2/5→4/5，kept1，无temporary buff，消耗原token、spells+1、pool/UID/RNG不因cast改变，原暗潮grant/tier不受影响。可先move再按实际新index选Lava，作为有意义target稳定性回归，不作为新功能宣称。
- 设置真实非空敌方（对手原购买/出牌），完整EOT→combat→next recruit：战斗Lava4攻击，招募原对象仍4/5，kept0；Darkcrest实际tier1→2。原Waiting为同Mini发新UIDtoken，也为暗潮发其本轮token，source UID不串线。
- 第二轮public cast新Mini token到同原Lava：4/5→6/5、kept1，无临时层；第二次真实EOT/combat/next recruit后仍6/5、kept0，暗潮tier2→3。这同时证明永久保留和下一轮额度恢复，不需要直接调用reset或写stats。
- 保持hand远低于10、无pending空位竞争。单Mini每轮只有1张本源token，因此不宣称“同轮第二张临时”的实际覆盖；若后续要测它应另审第二Mini或其他合法来源，不能复制token凑数。Golden/三连/复制/额外自动cast未开放。
- 负例：复制token、错owner、已用token原引用/副本、前轮过期token、非board-Lava目标、手工/外部factorytoken都不获权限；严格在原消费前全state/原私有receipt不变。后期suffix失败只报告实际已发生状态，不冒充事务回滚。projection-only直接grant/cast/EO T/play/sale仍必须拒绝。
- 取得路径可达由原代码及数据支持，**未运行，seed与搜索次数未知**。先自然获得Mini/Lava，再找暗潮，比要求三同shop更稳；失败预算必须如实保留，不恢复/重写RNG或删候选补救。

## 输入关键SHA256

- game.gd `5f90d18d2a57a5caa2f2bf9a81064425ed9b11489a0caaaf3d4364aa974b62f0`
- darkcrest_host.gd `3bfd545025c07db225cb21a5d0463a4509649201ccbf6f386874f9a946c91443`
- darkcrest_lava_play.gd `ef2cb15d3ee2c3b99a415e75bea4c1f7a009ca15abc5cade59ff0b6049f40f1f`
- spellcraft_waiting.gd `3cac313e25dbcf963547cffcc946bdeb8fa4968dba782db08744faf012cc6093`
- limited_turn_state.gd `4eb982da8bff08a07b5f1fbd710a9cea397ef2df7fa9fe370ad688bce1e0543c`
