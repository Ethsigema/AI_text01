# Mini/Lava V3 最终静态补核

只读核对implementation_overlay及MINI_OVERLAY_V3_FROZEN_SHA256.json，7/7文件SHA256实际匹配。helper为ccce713779cb5d06239aff7d3792804a58c0253ed5ea899cf4146333f9bfd9df。其它六文件与V2冻结相同，延续MINI_LAVA_FROZEN_REVIEW.md中的完整审查边界。

## 最后修复

flush_matches明确要求参数为实际RefCounted、active字典有guard、guard值为RefCounted且同对象。null、缺guard、legacy bool、其它窗口均不能以is_same(null,null)通过。begin/factory/complete/close四处统一使用该谓词；close在无pending早返之前先校验实际host和原窗口。真实Waiting仍在删除active guard之前调用close，保留原Darkcrest/Mini共享窗口身份。

CHILD_SOURCE逐项比较前加card.has(key)，null值字段不再把缺字段误判为相同。完整unit形状/原factory UID、原source/owner/ticket和唯一append核验未被放宽。

## 结论

本次已报告的确定静态阻塞全部修复，未发现新的冻结阻塞，可继续既定短parse/pure、源码早备份及独立有限Game验证。不宣称原生Mini发行/永久+2/三次combat/自然expiry-regrant已通过；这些仍等待真实测试。原永久效果与reset是既有Game行为，本批只增加有限身份准入与观察凭证；不扩大同轮第二cast、其它目标、双Mini、附魔后售出重购或活跃Mini购买。

本审核未修改生产、未运行Godot/Game、未repin或上传。父线程报告的V2整Game脚本check-only exit0属于其单独执行结果，不混作本次实战证据。
