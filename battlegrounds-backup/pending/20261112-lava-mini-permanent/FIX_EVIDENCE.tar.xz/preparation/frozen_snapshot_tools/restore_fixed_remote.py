"""Explicit fixed-commit fresh download/independent byte restore; never Game/upload.
Metadata must be the complete GitHub contents listing for the fixed commit/folder.
"""
from common import *
import argparse,re,subprocess,concurrent.futures

def main():
 assert STATUS != "UNSET_PENDING_STAGE_DECISION" and REMOTE_FOLDER != "UNSET_PENDING_STAGE_DECISION", "Stage scope/folder/status not approved; do not build or restore a new candidate"
 ap=argparse.ArgumentParser(description=__doc__)
 ap.add_argument('--execute',action='store_true',required=True)
 ap.add_argument('--commit',required=True)
 ap.add_argument('--metadata',type=Path,required=True)
 ap.add_argument('--destination',type=Path,required=True)
 a=ap.parse_args();assert re.fullmatch('[0-9a-f]{40}',a.commit)
 root=a.destination.resolve();assert not root.exists()
 assert not root.is_relative_to(ROOT.parent/'candidate') and not root.is_relative_to(ROOT/'restored_base')
 rows=json.loads(a.metadata.read_text());assert isinstance(rows,list) and rows
 required={'MANIFEST.json','SOURCE_MAP.json.gz','delta.tar.xz','restore_increment.py','SHA256SUMS.txt','RECONSTRUCTION_NOTE.md','CURRENT_INPUTS_VERIFIED.json','BUILD_VERIFIED.json'}
 assert required<={row['name'] for row in rows} and len({row['name'] for row in rows})==len(rows)
 for row in rows:
  assert row['type']=='file' and safe(row['name']) and '/' not in row['name']
  assert row['path']==REMOTE_FOLDER+'/'+row['name']
  expected_url='https://raw.githubusercontent.com/Ethsigema/AI_text01/'+a.commit+'/'+row['path']
  assert row['download_url']==expected_url
 root.mkdir(parents=True);package=root/'package';package.mkdir()
 write(root/'REMOTE_METADATA.json',rows)
 def fetch(row):
  p=package/row['name'];part=Path(str(p)+'.partial')
  subprocess.run(['curl','-fsSL','--retry','3','--connect-timeout','30','--max-time','600',row['download_url'],'-o',str(part)],check=True)
  b=part.read_bytes();git=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
  assert len(b)==row['size'] and git==row['sha'],row['name'];part.rename(p)
  return {'filename':row['name'],'url':row['download_url'],'bytes':len(b),'sha256':sha(b),'git_sha':git}
 with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex:records=list(ex.map(fetch,rows))
 write(root/'FRESH_PACKAGE_DOWNLOAD_VERIFIED.json',{'status':'PASS_FIXED_COMMIT_FRESH_DOWNLOAD','source_commit':a.commit,'checked_at_utc':utc(),'files':len(records),'records':records})
 # Validate safe checksum entries ourselves before executing the remote restore script.
 lines=(package/'SHA256SUMS.txt').read_text().splitlines();names=set()
 for line in lines:
  digest,n=line.split('  ',1);assert safe(n) and '/' not in n and n not in names and n!='SHA256SUMS.txt'
  assert re.fullmatch('[0-9a-f]{64}',digest) and sha((package/n).read_bytes())==digest,n;names.add(n)
 assert names=={r['name'] for r in rows}-{'SHA256SUMS.txt'}
 m=json.loads((package/'MANIFEST.json').read_text());assert m['status']==STATUS and m['remote_folder']==REMOTE_FOLDER
 assert m['base_content_commit']==BASE_COMMIT and not m['unknown_unuploaded_tier5_recovered'] and not m['gameplay_tests_run_for_this_snapshot']
 b=gzip.decompress((ROOT/'base_package/SOURCE_MAP.json.gz').read_bytes());assert sha(b)==m['base_map_sha256'];base=json.loads(b)
 # Re-read same-batch dependencies; never label them as another new download.
 deps=json.loads((ROOT/'FRESH_DOWNLOAD_VERIFIED.json').read_text());assert deps['files']==55
 for row in deps['records']:
  data=(ROOT/row['filename']).read_bytes();assert len(data)==row['bytes'] and sha(data)==row['sha256']
 target=dict(base)
 for n in m['removed']:del target[n]
 target.update(m['changed_files']);encoded=gzip.decompress((package/'SOURCE_MAP.json.gz').read_bytes())
 assert json.loads(encoded)==target and sha(encoded)==sha(dump(target))==m['source_map_sha256']
 assert all(safe(n) for n in target) and len(target)==m['source_files'] and sum(x['bytes'] for x in target.values())==m['source_bytes']
 assert (package/'restore_increment.py').read_bytes()==(ROOT/'rebuy_package/restore_increment.py').read_bytes()
 assert (package/'restore_low_disk.py').read_bytes()==(ROOT/'snapshot_tools/restore_low_disk.py').read_bytes()
 lock=ROOT.parent.parent/'develop_empty_ghost_20261112/.independent_full_game.lock'
 with (root/'RESTORE.log').open('x') as log:
  subprocess.run(['python',str(package/'restore_low_disk.py'),'--execute','--base-package',str(ROOT/'base_package'),'--release',str(ROOT/'original_release.zip'),'--candidate-package',str(package),'--new-workspace',str(root/'single_tree_restore'),'--lock-file',str(lock)],stdout=log,stderr=subprocess.STDOUT,check=True)
 report=json.loads((root/'single_tree_restore/SINGLE_TREE_RESTORE_VERIFIED.json').read_text());assert report['status']=='PASS_FRESH_SINGLE_TREE_CUMULATIVE_RESTORE'
 tree=root/'single_tree_restore/restored_snapshot';verified=verify(tree,target,m['aggregate_sha256'])
 write(root/'INDEPENDENT_RESTORE_VERIFIED.json',{'status':'PASS_REMOTE_UNACCEPTED_SINGLE_TREE_SOURCE_RESTORE_BYTES_ONLY','source_commit':a.commit,'checked_at_utc':utc(),'snapshot_status':STATUS,'source_map_sha256':m['source_map_sha256'],'restored':verified,'restored_tree':str(tree),'same_current_batch_dependencies_rehashed':55,'new_snapshot_files_downloaded':len(records),'fresh_base_checkpoint_then_single_target_tree':True,'separate_runtime_copy_created':False,'game_started':False,'uploads':0,'unknown_unuploaded_tier5_recovered':False,'gameplay_acceptance':False})
 print('PASS_REMOTE_UNACCEPTED_SINGLE_TREE_SOURCE_RESTORE_BYTES_ONLY',tree)
if __name__=='__main__':main()
