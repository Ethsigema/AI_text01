from pathlib import Path,PurePosixPath
import json,hashlib,subprocess,concurrent.futures,tarfile,datetime,sys
R=Path(__file__).resolve().parent.parent;C='edbaa960a3828e9e12094f1dffb82d4f608d55d7'
sha=lambda b:hashlib.sha256(b).hexdigest()
def safe(n):return bool(n) and not PurePosixPath(n).is_absolute() and all(x not in {'','.','..'} for x in n.split('/')) and '\\' not in n
meta=json.loads((R/'EARLY_OVERLAY_UPLOAD_METADATA.json').read_text());pins=meta['files'];assert len(pins)==8 and len({x['name'] for x in pins})==8
out=R/'early_overlay_remote_edbaa960';resume='--verify-downloaded' in sys.argv
if resume:assert out.is_dir()
else:out.mkdir(exist_ok=False)
def get(x):
 n=x['name'];assert safe(n) and '/' not in n;url=f"https://raw.githubusercontent.com/Ethsigema/AI_text01/{C}/{meta['folder']}/{n}";p=out/n;partial=Path(str(p)+'.partial')
 if not resume:subprocess.run(['curl','-fsSL','--retry','3','--connect-timeout','30','--max-time','300',url,'-o',str(partial)],check=True)
 b=(p if resume else partial).read_bytes();git=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();assert len(b)==x['bytes'] and sha(b)==x['sha256'] and git==x['git_sha'];
 if not resume:partial.rename(p)
 return {'name':n,'bytes':len(b),'sha256':sha(b),'git_sha':git,'url':url}
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:rows=list(pool.map(get,pins))
checked=set()
for line in (out/'SHA256SUMS.txt').read_text().splitlines():
 h,n=line.split('  ',1);assert safe(n) and '/' not in n and n not in checked;assert sha((out/n).read_bytes())==h;checked.add(n)
assert checked=={x['name'] for x in pins}-{'SHA256SUMS.txt'}
m=json.loads((out/'MANIFEST.json').read_text());f=json.loads((out/'MINI_OVERLAY_V1_FROZEN_SHA256.json').read_text());assert m['status']=='EARLY_SOURCE_OVERLAY_ONLY_UNACCEPTED_KNOWN_REVIEW_BLOCKERS_NOT_COMPLETE_RESTORE';assert not m['full_new_candidate_restoration_completed'] and m['known_review_blockers']
seen={};archive_names=set();directories=[]
with tarfile.open(out/'MINI_OVERLAY_V1_UNACCEPTED.tar.gz','r:gz') as t:
 for member in t:
  assert safe(member.name) and member.name not in archive_names;archive_names.add(member.name)
  if member.isdir():
   assert member.name in {'implementation_overlay','implementation_overlay/data','implementation_overlay/core'} and member.size==0;directories.append(member.name);continue
  assert member.isfile() and member.name.startswith('implementation_overlay/')
  n=member.name.removeprefix('implementation_overlay/');assert safe(n) and n not in seen
  b=t.extractfile(member).read();seen[n]={'bytes':len(b),'sha256':sha(b)}
assert seen==m['members'] and len(seen)==8
for n,h in f['files'].items():assert seen[n]['sha256']==h
report={'status':'PASS_FIXED_EARLY_OVERLAY_BYTES_ONLY_KNOWN_BLOCKERS_NOT_COMPLETE_RESTORE','commit':C,'folder':meta['folder'],'verified_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'files':len(rows),'bytes':sum(x['bytes'] for x in rows),'records':rows,'sha256sums_entries':len(checked),'sha256sums_sha256':sha((out/'SHA256SUMS.txt').read_bytes()),'archive_file_members_verified':8,'safe_directory_entries_verified':directories,'archive_prefix':'implementation_overlay/','initial_verifier_schema_adjustment':'Initial strict file-only assumption stopped on safe directory entries; verifier was adjusted for actual fixed archive prefix and safe directories, then reused and rehashed the same freshly downloaded8 files without repeating download','freeze_map_matches':True,'known_review_blockers':m['known_review_blockers'],'full_new_candidate_restoration_completed':False,'gameplay_acceptance':False,'game_started':False,'current_v2_source_read_or_modified':False}
with (R/'EARLY_OVERLAY_PUBLICATION_VERIFIED.json').open('x') as w:json.dump(report,w,indent=2)
print(json.dumps({k:v for k,v in report.items() if k!='records'},indent=2))
