from pathlib import Path
import sys,os,json,subprocess,datetime,time,hashlib,re,fcntl
r=Path(__file__).resolve().parents[1];sys.path.insert(0,str(r/'fresh_remote/snapshot_tools'));from common import scan,sha,dump,write
p=r/'candidate';e=r/'evidence';lock=r.parent/'develop_empty_ghost_20261112/.independent_full_game.lock'
with lock.open('r') as f:
 fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB);before,agg=scan(p)
 write(e/'FROZEN_SOURCE_MAP_PRE_PURE.json',before)
 env=os.environ.copy()
 for k,n in [('HOME','pure_home'),('XDG_CACHE_HOME','pure_cache'),('XDG_CONFIG_HOME','pure_config'),('XDG_DATA_HOME','pure_data')]:
  q=e/n;q.mkdir();env[k]=str(q)
 log=e/'permanent_pre_freeze_pure.log';started=datetime.datetime.now(datetime.timezone.utc).isoformat();t=time.monotonic()
 with log.open('x') as out:result=subprocess.run(['godot','--headless','--path',str(p),'--script','res://tests/darkcrest_lava_permanent_20261112/content_contract.gd'],stdout=out,stderr=subprocess.STDOUT,env=env,timeout=180)
 after,a=scan(p);text=log.read_text();rows=[json.loads(x.removeprefix('DARKCREST_LAVA_PERMANENT_CONTENT_CONTRACT ')) for x in text.splitlines() if x.startswith('DARKCREST_LAVA_PERMANENT_CONTENT_CONTRACT ')]
 status={'status':'PASS_PURE_ONLY_NO_GAME' if result.returncode==0 and len(rows)==1 and rows[0]['passed']==340 and rows[0]['failed']==0 and after==before and a==agg and not any(x in text for x in ['SCRIPT ERROR','ERROR:','WARNING','FAIL ']) else 'FAIL_PURE_OR_SOURCE_INTEGRITY','started':started,'elapsed':time.monotonic()-t,'exit':result.returncode,'log_sha256':sha(log.read_bytes()),'source_map_sha256':sha(dump(before)),'aggregate_sha256':agg,'source_files':len(before),'source_bytes':sum(x['bytes'] for x in before.values()),'before_after_identical':before==after and a==agg,'summary':rows,'game_started':False}
 write(e/'PERMANENT_PURE_VERIFIED.json',status);print(json.dumps(status,indent=2));print(text[-3000:]);assert status['status']=='PASS_PURE_ONLY_NO_GAME'
