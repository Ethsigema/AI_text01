"""Read-only: old completed development copies, NOT deletion authorization."""
from pathlib import Path
import json,gzip,hashlib,fcntl,datetime,sys,shutil
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT/'develop_lava_followup_20261112/fresh_remote/snapshot_tools'));from common import verify
sha=lambda b:hashlib.sha256(b).hexdigest();read=lambda p:json.loads(p.read_text());lockpath=ROOT/'develop_empty_ghost_20261112/.independent_full_game.lock'
with lockpath.open('r') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);rows=[]
 for stage,snap,source,final in [('develop_darkcrest_tier6_20261112','remote_snapshot_dd428c2','dd428c21867d4c15340ff6d4d8868d027d1067e4','15dcc5752827322968ca08d5643fa03ba7cf6934'),('develop_darkcrest_lava_20261112','remote_snapshot_5d98887','5d988875054ad4eea47d6615f8a9fdd65bfe7b4d','527decb1dead1b309faaa0086563ab88780968b8')]:
  s=ROOT/stage;r=s/snap;p=r/'package';target=s/'candidate';restore=r/'restored_snapshot';m=read(p/'MANIFEST.json');raw=gzip.decompress((p/'SOURCE_MAP.json.gz').read_bytes());assert sha(raw)==m['source_map_sha256'];expected=json.loads(raw)
  pub=read(s/'FINAL_PUBLICATION_VERIFIED.json');assert pub['commit']==final and pub['source_commit']==source and pub['status'].startswith('PASS_FINAL_PUBLICATION_FRESH_BYTES')
  original=read(r/'FRESH_PACKAGE_DOWNLOAD_VERIFIED.json');assert original['source_commit']==source
  for entry in original['records']:
   b=(p/entry['filename']).read_bytes();assert len(b)==entry['bytes'] and sha(b)==entry['sha256']
  for n in ['MANIFEST.json','SOURCE_MAP.json.gz','delta.tar.xz']:assert sha((p/n).read_bytes())==pub['immutable_source_files_match_fixed_source_commit'][n]
  final_package=s/'final_package';assert final_package.is_dir();final_pins={x['name']:x for x in pub['records']}
  for n,x in final_pins.items():
   b=(final_package/n).read_bytes();assert len(b)==x['bytes'] and sha(b)==x['sha256']
  a=verify(target,expected,m['aggregate_sha256']);b=verify(restore,expected,m['aggregate_sha256']);assert a==b
  paths=list(target.rglob('*'));assert all(x.is_file() or x.is_dir() for x in paths);assert all(x.stat().st_nlink==1 for x in paths if x.is_file())
  # Full byte equality in addition to independent SHA scans, not sampling.
  for n in expected:assert (target/n).read_bytes()==(restore/n).read_bytes()
  preserved=[restore,r/'package',r/'independent_tests',s/'unaccepted_package',s/'restore_receipt_package',s/'final_package'];assert all(x.is_dir() for x in preserved)
  rows.append({'candidate_path':str(target),'definition':'Completed development working copy named candidate; NOT the unique source, NOT the immutable restore or backup package. It exactly matches its fixed published source.','equivalent_preserved_restore':str(restore),'source_commit':source,'final_commit':final,'source_map_sha256':sha(raw),'manifest_sha256':sha((p/'MANIFEST.json').read_bytes()),'candidate_full_check':a,'restore_full_check':b,'every_file_byte_equal':True,'unique_files':[],'symlinks':[],'non_single_link_files':[],'estimated_allocated_bytes':sum(x.stat().st_blocks*512 for x in paths)+target.stat().st_blocks*512,'publication_receipt':str(s/'FINAL_PUBLICATION_VERIFIED.json'),'publication_receipt_sha256':sha((s/'FINAL_PUBLICATION_VERIFIED.json').read_bytes()),'original_package_files_rehashed':len(original['records']),'final_package_files_rehashed':len(final_pins),'preserved_directories':[str(x) for x in preserved]})
 out={'status':'READ_ONLY_COMPLETED_DEVELOPMENT_COPY_EQUIVALENCE_VERIFIED_NO_DELETE','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'common_lock':str(lockpath),'exclusive_lock_held_during_all_checks':True,'cooperating_game_runner_inactive_by_lock':True,'no_process_list_inference':True,'targets':rows,'total_logical_bytes':sum(x['candidate_full_check']['bytes'] for x in rows),'total_estimated_allocated_bytes':sum(x['estimated_allocated_bytes'] for x in rows),'deleted_paths':[],'current_rebuy_candidate_and_remote_source_preserved':True,'failed_unaccepted_trees_preserved':True,'disk':shutil.disk_usage(ROOT)._asdict(),'requires_parent_explicit_delete_authorization':True}
 with (Path(__file__).parent/'OLD_CANDIDATE_CLEANUP_PREFLIGHT.json').open('x') as f:json.dump(out,f,indent=2)
 print(json.dumps(out,indent=2))
