from pathlib import Path,PurePosixPath
import json,hashlib,tarfile,shutil,datetime
r=Path(__file__).resolve().parents[1];p=r/'early_overlay_v1_package';p.mkdir(exist_ok=False)
sha=lambda b:hashlib.sha256(b).hexdigest()
freeze=json.loads((r/'research/MINI_OVERLAY_V1_FROZEN_SHA256.json').read_text());seen={}
with tarfile.open(r/'research/MINI_OVERLAY_V1_UNACCEPTED.tar.gz','r:gz') as t:
 for m in t:
  if m.isdir():continue
  assert m.isfile() and not m.name.startswith('/') and '..' not in PurePosixPath(m.name).parts
  name=m.name.removeprefix('implementation_overlay/');assert name not in seen
  b=t.extractfile(m).read();seen[name]={'bytes':len(b),'sha256':sha(b)}
  if name!='PREIMAGE_SHA256.json':assert freeze['files'][name]==sha(b)
assert set(seen)==set(freeze['files'])|{'PREIMAGE_SHA256.json'}
for src in ['research/MINI_OVERLAY_V1_FROZEN_SHA256.json','research/MINI_OVERLAY_V1_UNACCEPTED.tar.gz','preparation/CLEANUP_EXECUTED.json','preparation/CANDIDATE_PREIMAGE_VERIFIED.json','research/SOURCE_EVIDENCE_CHECK.json']:
 shutil.copyfile(r/src,p/Path(src).name)
manifest={'status':'EARLY_SOURCE_OVERLAY_ONLY_UNACCEPTED_KNOWN_REVIEW_BLOCKERS_NOT_COMPLETE_RESTORE','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'base_source_commit':'b40bc9b7701afbca41defd5f35a9c931a8b5ee9e','base_final_commit':'53c4fe49b1fcf97c335c5ef343f59f574c41f229','base_folder':'battlegrounds-backup/pending/20261112-lava-native-rebuy','base_source_map_sha256':'9c79ddf64f3de4cfff3b9080b2a60b3408ff9e039cab2b215042d51718731a03','members':seen,'new_source_files':7,'game_started':False,'full_dependency_downloads_completed':55,'full_new_candidate_restoration_completed':False,'known_review_blockers':['Mini strict hand ID needs dedicated admission','child complete factory shape not yet checked','delivery completion owner/window/ticket rechecks incomplete'],'will_not_promote_to_default':True,'old_backups_preserved':True}
(p/'MANIFEST.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
(p/'README.md').write_text('''# 迷你侍从→熔岩永久附魔桥：最早源码草稿备份\n\n这是未验收的小源码覆盖包，不是可直接运行的完整工程，也不是新候选的完整独立恢复证明。已知的 Mini 准入、完整子牌形状与投递末端复核问题仍在修正；本快照仅为防止未上传工作丢失，绝不并入默认版本。未运行 Game。\n\n原引擎早已有熔岩首次塑造永久保留效果，本批新增的是暗潮有限房间下单 Mini 的真实来源、施法和跨回合兼容观察。第二 Mini、同轮第二施法、其他目标、附魔后出售/回购仍不在本批。\n\n覆盖包相对固定源码 b40bc9b7701afbca41defd5f35a9c931a8b5ee9e；完整基线与恢复说明：https://github.com/Ethsigema/AI_text01/blob/53c4fe49b1fcf97c335c5ef343f59f574c41f229/battlegrounds-backup/pending/20261112-lava-native-rebuy/RECOVERY.md\n\n保存步骤：按固定基线说明完整恢复并校验全部 27,978 文件，再核本包 PREIMAGE_SHA256.json 的 6 个旧文件前像，仅在新隔离副本应用 archive 中 7 个源码文件。仍需依赖 pin 重算、综合语法及真实玩法验收；不要把早版通过少量解析等同整体可用。后续修正将另存，不覆盖本快照。\n\n本次只清理两份逐文件等价已验的旧开发工作副本；所有备份包、独立恢复树、失败、日志、唯一及未核验成果均保留。删除与最新前像复制的实际证据随包。\n''')
(p/'SHA256SUMS.txt').write_text(''.join(sha(f.read_bytes())+'  '+f.name+'\n' for f in sorted(p.iterdir())))
files=[]
for f in sorted(p.iterdir()):
 b=f.read_bytes();files.append({'name':f.name,'path':str(f.resolve()),'bytes':len(b),'sha256':sha(b),'git_sha':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()})
(r/'EARLY_OVERLAY_UPLOAD_METADATA.json').write_text(json.dumps({'folder':'battlegrounds-backup/pending/20261112-lava-mini-permanent-early-overlay-v1','files':files},indent=2)+'\n')
print(json.dumps({'files':len(files),'bytes':sum(v['bytes'] for v in files),'verified_archive_members':len(seen),'status':manifest['status']}))
