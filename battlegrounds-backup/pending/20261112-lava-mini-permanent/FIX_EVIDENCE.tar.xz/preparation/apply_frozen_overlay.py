from pathlib import Path
import hashlib,json,shutil,datetime
r=Path(__file__).resolve().parents[1]; src=r/'implementation_overlay'; dst=r/'candidate'; version='V2'; f=json.loads((r/f'research/MINI_OVERLAY_{version}_FROZEN_SHA256.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for n,v in f['preimage']['files'].items():assert sha(dst/n)==v,('changed preimage',n)
for n,v in f['files'].items():assert sha(src/n)==v,('changed overlay',n)
for n,v in f['files'].items():
 if n not in f['preimage']['files']:assert not (dst/n).exists(),('existing new target',n)
for n,v in f['files'].items():
 (dst/n).parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src/n,dst/n);assert sha(dst/n)==v
(r/'evidence/APPLIED_OVERLAY_V2.json').write_text(json.dumps({'status':'APPLIED_FROZEN_V2_ONLY_NO_GAME','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'files':f['files'],'preimage_files':f['preimage']['files']},indent=2)+'\n')
shutil.copyfile(r/'preparation/CANDIDATE_PREIMAGE_SOURCE_SHA256.json',r/'PREIMAGE_HASHES.json')
print('applied',len(f['files']))
