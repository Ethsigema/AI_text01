from pathlib import Path
import sys,json,gzip,hashlib,fcntl,shutil,datetime
ROOT=Path(__file__).resolve().parents[2];P=Path(__file__).parent;sys.path.insert(0,str(ROOT/'develop_lava_followup_20261112/fresh_remote/snapshot_tools'));from common import verify
sha=lambda b:hashlib.sha256(b).hexdigest();read=lambda p:json.loads(p.read_text());utc=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
old=ROOT/'develop_lava_rebuy_20261112/preparation';archive=P/'prior_cleanup_evidence';archive.mkdir(exist_ok=False)
for n in ['OLD_CANDIDATE_CLEANUP_PREFLIGHT.json','verify_completed_candidate_duplicates.py','NEXT_STAGE_SPACE_ASSESSMENT.json']:shutil.copyfile(old/n,archive/n)
shutil.copytree(old/'space_cow_probe',archive/'space_cow_probe')
pre=read(archive/'OLD_CANDIDATE_CLEANUP_PREFLIGHT.json');allowed=[ROOT/'develop_darkcrest_tier6_20261112/candidate',ROOT/'develop_darkcrest_lava_20261112/candidate'];assert [Path(x['candidate_path']) for x in pre['targets']]==allowed
with Path(pre['common_lock']).open('r') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);before=shutil.disk_usage(ROOT)._asdict();checks=[];preserved=[]
 for row in pre['targets']:
  target=Path(row['candidate_path']);restore=Path(row['equivalent_preserved_restore']);r=restore.parent;pkg=r/'package';assert target.resolve()==target and restore.resolve()==restore
  assert sha((pkg/'MANIFEST.json').read_bytes())==row['manifest_sha256'];assert sha(Path(row['publication_receipt']).read_bytes())==row['publication_receipt_sha256']
  m=read(pkg/'MANIFEST.json');raw=gzip.decompress((pkg/'SOURCE_MAP.json.gz').read_bytes());assert sha(raw)==row['source_map_sha256'];expected=json.loads(raw)
  a=verify(target,expected,m['aggregate_sha256']);b=verify(restore,expected,m['aggregate_sha256']);assert a==b==row['candidate_full_check']
  for entry in read(r/'FRESH_PACKAGE_DOWNLOAD_VERIFIED.json')['records']:
   data=(pkg/entry['filename']).read_bytes();assert len(data)==entry['bytes'] and sha(data)==entry['sha256']
  preserved += [Path(x) for x in row['preserved_directories']];checks.append({'target':str(target),'replacement':str(restore),'full_rehash':a})
 assert all(x.is_dir() for x in preserved)
 for target in allowed:shutil.rmtree(target)
 assert all(not x.exists() for x in allowed) and all(x.is_dir() for x in preserved)
 after=shutil.disk_usage(ROOT)._asdict();report={'status':'AUTHORIZED_TWO_COMPLETED_DEVELOPMENT_WORK_COPIES_REMOVED_NOT_BACKUPS','utc':utc(),'deleted_paths':[str(x) for x in allowed],'preflight_sha256':sha((archive/'OLD_CANDIDATE_CLEANUP_PREFLIGHT.json').read_bytes()),'exclusive_common_lock':True,'rechecks':checks,'preserved_directories':[str(x) for x in preserved],'before_disk':before,'after_disk':after,'available_bytes_change':after['free']-before['free'],'backups_deleted':False,'game_started':False}
 with (P/'CLEANUP_EXECUTED.json').open('x') as f:json.dump(report,f,indent=2)
 print('CLEANUP_EXECUTED',report['available_bytes_change'],after,flush=True)
 source=ROOT/'develop_lava_rebuy_20261112/remote_snapshot_b40bc9b/single_tree_restore/restored_snapshot';pkg=source.parent.parent/'package';raw=gzip.decompress((pkg/'SOURCE_MAP.json.gz').read_bytes());expected=json.loads(raw);m=read(pkg/'MANIFEST.json')
 assert sha(raw)=='9c79ddf64f3de4cfff3b9080b2a60b3408ff9e039cab2b215042d51718731a03' and m['aggregate_sha256']=='65baa3dfa80eb642b7f36f516fa2d915e57980d6cb9ed2d987f627d97e286f92'
 first=verify(source,expected,m['aggregate_sha256']);second=verify(source,expected,m['aggregate_sha256']);assert first==second and first['files']==27978 and first['bytes']==1550796458
 candidate=P.parent/'candidate';assert not candidate.exists();shutil.copytree(source,candidate);copied=verify(candidate,expected,m['aggregate_sha256']);assert copied==first
 (P/'CANDIDATE_PREIMAGE_SOURCE_MAP.json').write_bytes(raw)
 (P/'CANDIDATE_PREIMAGE_SOURCE_SHA256.json').write_text(json.dumps({n:x['sha256'] for n,x in expected.items()},indent=2,sort_keys=True)+'\n')
 result={'status':'PASS_LATEST_REBUY_SOURCE_DOUBLE_READ_AND_INDEPENDENT_CANDIDATE_COPY','utc':utc(),'source':str(source),'candidate':str(candidate),'source_commit':'b40bc9b7701afbca41defd5f35a9c931a8b5ee9e','final_commit':'53c4fe49b1fcf97c335c5ef343f59f574c41f229','source_map_sha256':sha(raw),'source_first_read':first,'source_second_read':second,'candidate_verified':copied,'disk':shutil.disk_usage(ROOT)._asdict(),'no_hardlinks_or_cow_used':True,'game_started':False}
 with (P/'CANDIDATE_PREIMAGE_VERIFIED.json').open('x') as f:json.dump(result,f,indent=2)
 print('LATEST_REBUY_COPY_VERIFIED',result['disk'],flush=True)
