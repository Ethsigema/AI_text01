# Permanent compatibility evidence tools, prepared only

These tools do not invoke Godot or upload. Import is read-only. `--execute` must be expressly authorized later. The fixed source commit resolves from SOURCE_PUBLICATION.json or an explicit CLI value; map/aggregate must match the finalized runner pins. Unknown V4 pins cannot pass context validation. Destination is the requested 20261112-lava-mini-permanent folder.

Order:
1. prepare_restore_receipt.py --execute --remote-root <fresh root>: validates fixed downloaded source and exact single-runtime restore status, base/full checkpoint and target double-hash evidence, then archives tools and real bytes-only restore receipts. It does not lock or wait for Game and never represents Game acceptance.
2. prepare_publication_outcome.py --execute --remote-root <root> --outcome success|failure: requires completed attempt and source audit, takes exclusive common Game lock, rehashes candidate/restored trees and actual process logs/results. Success requires all 10 tests validated; failed, uncertain and omitted evidence remains distinct. Only 9 pure expected counts total3057 are known now; full Game checks are always read from actual evidence. No fabricated completed Game count.
3. verify_final_publication.py --execute --remote-root <root>: fresh fixed-commit downloads, all file SHA/GitSHA/size and every archive member, source package unchanged, actual permanent scenario validation. Accepts remote_folder metadata.
4. prepare_final_verification_audit.py --execute --audit-remote-folder <audit folder>: requires actual publication verification and archives its receipts/tools. No automatic upload.

All outputs create new files/folders; original source package remains unchanged. The new package copy alone updates SHA256SUMS. The early overlay edbaa960 and local withdrawn V3 package are not touched.

The actual scope is compatibility admission/observation in finite Darkcrest for the existing native Lava permanence algorithm. One Mini, one Lava; intended two authentic first casts and three nonempty combat/recruit cycles, including unused third-round token expiry/regrant and Darkcrest4. Pre-source native factory/add_hand/public Coin funding is a disclosed fixture. Same-turn second cast, second Mini, other targets, buffed sale/rebuy, golden and broader game acceptance are not claimed. Failure requires a separate candidate, not rewriting a failed attempt.

Synthetic tests exercise metadata only, never gameplay or real recovery. Help/compile outputs and a SHA manifest are recorded in PACKAGING_PREPARATION_V1.json. Runner/audit are independently maintained and will receive final source pins later; the manifest records the observed preparation versions, not future bytes.
