"""Synthetic metadata classification only. No package creation, download or Game."""
import copy,json
from packaging_common import outcome_metadata,runner,safe,validate_restore_shape,ROOT

def main():
 labels=[x[0] for x in runner.TESTS]
 summary={'runtime_mode':runner.RUNTIME_MODE,'two_runtime_copies':False,'status':'TESTS_VALIDATED_SOURCE_INTEGRITY_PASS','error':None,'validated_tests':labels}
 audit={'runtime_mode':runner.RUNTIME_MODE,'two_runtime_copies':False,'runner_suite_accepted':True,'tests':{k:{'classification':'executed_validated'} for k in labels}}
 final={'status':runner.FINAL_STATUS,'tests':{k:{} for k in labels},'full_game_processes':1,'full_game_acceptance':False,'default_pool_promoted':False}
 checks=[]
 assert outcome_metadata(summary,audit,final)=='success';checks.append('complete_synthetic_suite_only')
 def reject(name,mutate):
  s,a,f=copy.deepcopy([summary,audit,final]);mutate(s,a,f)
  try:outcome_metadata(s,a,f)
  except AssertionError:checks.append(name);return
  raise AssertionError('accepted '+name)
 reject('missing_test',lambda s,a,f:f['tests'].pop(labels[-1]))
 reject('failed_classification',lambda s,a,f:a['tests'][labels[0]].update(classification='executed_failed'))
 reject('unknown_classification',lambda s,a,f:a['tests'][labels[0]].update(classification='launch_or_execution_without_completion_receipt'))
 reject('incomplete_summary',lambda s,a,f:s.update(status='FAILED_OR_INCOMPLETE_ATTEMPT',error='failed'))
 reject('two_runtime_copies',lambda s,a,f:s.update(two_runtime_copies=True))
 reject('false_full_game_promotion',lambda s,a,f:f.update(full_game_acceptance=True))
 reject('two_full_games',lambda s,a,f:f.update(full_game_processes=2))
 reject('conflicting_failed_with_final',lambda s,a,f:a.update(runner_suite_accepted=False))
 failed_summary={**summary,'status':'FAILED_OR_INCOMPLETE_ATTEMPT','error':'synthetic validation failure','validated_tests':[]}
 failed_audit={**audit,'runner_suite_accepted':False}
 assert outcome_metadata(failed_summary,failed_audit,None)=='failure';checks.append('real_failure_metadata_not_success')
 failed_summary['error']=None;failed_summary['validated_tests']=labels[:1]
 assert outcome_metadata(failed_summary,failed_audit,None)=='failure';checks.append('incomplete_metadata_not_success')
 assert not safe('../escape') and not safe('/absolute') and safe('battlegrounds-backup/pending/20261112-lava-mini-permanent');checks.append('remote_folder_safe_paths')
 r=ROOT/'synthetic_remote_root';m={'source_map_sha256':'a'*64,'aggregate_sha256':'b'*64,'source_files':1,'source_bytes':2};commit='c'*40
 receipt={'status':'PASS_REMOTE_UNACCEPTED_SINGLE_TREE_SOURCE_RESTORE_BYTES_ONLY','source_commit':commit,'source_map_sha256':m['source_map_sha256'],'fresh_base_checkpoint_then_single_target_tree':True,'separate_runtime_copy_created':False,'game_started':False,'gameplay_acceptance':False,'restored_tree':str(r/'single_tree_restore/restored_snapshot'),'restored':{'files':1,'bytes':2,'aggregate_sha256':'b'*64,'missing':[],'extra':[],'mismatched':[]}}
 validate_restore_shape(receipt,r,m,commit);checks.append('exact_single_tree_restore_metadata')
 for key,value in [('status','PASS_REMOTE_UNACCEPTED_SOURCE_RESTORE_BYTES_ONLY'),('fresh_base_checkpoint_then_single_target_tree',False),('separate_runtime_copy_created',True),('restored_tree',str(r/'restored_snapshot')),('gameplay_acceptance',True)]:
  bad=copy.deepcopy(receipt);bad[key]=value
  try:validate_restore_shape(bad,r,m,commit)
  except AssertionError:checks.append('reject_restore_'+key)
  else:raise AssertionError('accepted invalid restore '+key)
 print(json.dumps({'status':'PASS_SYNTHETIC_PACKAGING_METADATA_ONLY','passed':len(checks),'checks':checks,'package_created':False,'game_started':False,'downloaded':False,'uploaded':False},indent=2))
if __name__=='__main__':main()
