extends SceneTree
const Source=preload("res://core/titanic_guardian_sources.gd")
const Pool=preload("res://core/pool_identity.gd")
class ProbeCatalog extends RefCounted:
	var cards: Dictionary={}
	var source_catalog=null
	func get_card(identity): return cards.get(identity,{})
func _init(): call_deferred("_run")

func _key(container: Variant,key: Variant)->Variant:
	return int(key) if container is Array else key

func _all_floats(value: Variant)->Variant:
	if value is int: return float(value)
	if value is Dictionary:
		var result: Dictionary={}
		for key in value: result[key]=_all_floats(value[key])
		return result
	if value is Array:
		var result: Array=[]
		for item in value: result.append(_all_floats(item))
		return result
	return value

func _mutate(value: Variant,entry: Dictionary)->Variant:
	var op: String=entry.op
	var path: Array=entry.path
	if op=="canonical": return value
	if op=="all_numbers_float": return _all_floats(value)
	if op=="merged_card":
		value.merge(Source.EXPECTED[value.id].duplicate(true),true)
		return value
	if op=="custom_card":
		value.merge(Source.EXPECTED[value.id].duplicate(true),true)
		value.source_shop_fields={"tier":3,"cost":null,"pool_supported":false}
		value.tier=4
		return value
	if op=="swap_rows": return {Source.IDS[0]:value[Source.IDS[1]],Source.IDS[1]:value[Source.IDS[0]]}
	if op=="duplicate_normal": return {Source.IDS[0]:value[Source.IDS[0]],Source.IDS[1]:value[Source.IDS[0]].duplicate(true)}
	if op=="duplicate_golden": return {Source.IDS[0]:value[Source.IDS[1]],Source.IDS[1]:value[Source.IDS[1]].duplicate(true)}
	if op=="invalid_root": return entry.value.duplicate(true) if entry.value is Array or entry.value is Dictionary else entry.value
	if op=="id_only": return {"id":value.id}
	if op=="extra_unrelated":
		value["not-a-source"]={"id":"not-a-source"}
		return value
	if op=="invalid_member":
		value[path[0]]=null
		return value
	var parent: Variant=value
	for at in range(path.size()-1): parent=parent[_key(parent,path[at])]
	var key: Variant=_key(parent,path[-1]) if not path.is_empty() else null
	var prior: Variant=parent[key] if not path.is_empty() else value
	if op=="delete":
		if parent is Array: parent.remove_at(int(key))
		else: parent.erase(key)
		return value
	var changed: Variant=null
	match op:
		"replace_value": changed=entry.value.duplicate(true) if entry.value is Dictionary or entry.value is Array else entry.value
		"id_swap": changed=Source.IDS[1] if prior==Source.IDS[0] else Source.IDS[0]
		"replace_null": changed=null
		"replace_array": changed=[]
		"replace_dict": changed={}
		"null_to_zero": changed=0
		"reverse_dict":
			changed={}
			var keys: Array=prior.keys()
			keys.reverse()
			for entry_key in keys: changed[entry_key]=prior[entry_key]
		"bool_to_int": changed=int(prior)
		"bool_to_float": changed=float(prior)
		"toggle_bool": changed=not prior
		"numeric_float": changed=float(prior)
		"numeric_int": changed=int(prior)
		"number_delta": changed=prior+1
		"number_string": changed=str(prior)
		"number_bool": changed=bool(prior)
		"change_string": changed=prior+"__changed__"
		"null_to_false": changed=false
		"extra_key":
			changed=prior.duplicate(true)
			changed["__extra__"]=true
		"append_item":
			changed=prior.duplicate(true)
			changed.append("__extra__")
		"reverse_list":
			changed=prior.duplicate(true)
			changed.reverse()
		"nan": changed=NAN
		"pos_inf": changed=INF
		"neg_inf": changed=-INF
		_: assert(false,"Unknown mutation: "+op)
	if not path.is_empty(): parent[key]=changed
	else: value=changed
	return value

func _strict_ingress(card: Variant,cards: Variant)->bool:
	# A diagnostic composition of the actual per-row raw gate, plus the explicit
	# keyed identity invariant enforced by actual closure_error after compilation.
	if not card is Dictionary or not cards is Dictionary: return false
	if not Source.raw_source_error(card).is_empty(): return false
	for identity in Source.IDS:
		var row: Variant=cards.get(identity)
		if not row is Dictionary or not Source.raw_source_error(row).is_empty() or row.get("id")!=identity: return false
	return true

func _compiled(cards: Dictionary,outputs: Dictionary)->ProbeCatalog:
	var c=ProbeCatalog.new()
	c.cards=cards.duplicate(true)
	for identity in Source.IDS: c.cards[identity].merge(outputs[identity],true)
	return c

func _project(canonical: ProbeCatalog)->ProbeCatalog:
	var room=ProbeCatalog.new()
	room.cards=canonical.cards.duplicate(true)
	room.source_catalog=canonical
	for identity in Source.IDS:
		var row: Dictionary=room.cards[identity]
		row.source_shop_fields={"tier":Source.RAW[identity].tier,"cost":Source.RAW[identity].cost,"pool_supported":false}
		row.tier=4
		if identity==Source.IDS[0]:
			row.cost=3
			row.pool_supported=true
			row.custom_shop_override={"tier":4,"cost":3,"copies":2}
		else: row.custom_shop_derived_from=Source.IDS[0]
	return room

func _run():
	var folder: String=ProjectSettings.globalize_path("res://").path_join("..").simplify_path()
	var cases: Array=JSON.parse_string(FileAccess.get_file_as_string(folder.path_join("CASES.json")))
	var py: Dictionary=JSON.parse_string(FileAccess.get_file_as_string(folder.path_join("PYTHON_REPORT.json")))
	var outputs: Dictionary=JSON.parse_string(FileAccess.get_file_as_string(folder.path_join("CANDIDATE_OUTPUTS.json")))
	var failures: Array=[]
	var results: Array=[]
	var counts: Dictionary={}
	for identity in Source.IDS:
		if not Source.same(outputs[identity],Source.EXPECTED[identity]): failures.append({"kind":"python_output_constant_mismatch","identity":identity})
	for index in range(cases.size()):
		var entry: Dictionary=cases[index]
		var identity: String=entry.identity
		var cards: Variant=Source.RAW.duplicate(true)
		var card: Variant=Source.RAW[identity].duplicate(true)
		if entry.regime=="detached": card=_mutate(card,entry)
		elif entry.regime=="coupled":
			cards[identity]=_mutate(cards[identity],entry)
			card=cards[identity]
		elif entry.regime=="companion":
			var target: String=Source.IDS[1] if identity==Source.IDS[0] else Source.IDS[0]
			cards[target]=_mutate(cards[target],entry)
			card=cards[identity]
		else: cards=_mutate(cards,entry)
		var before: PackedByteArray=var_to_bytes([card,cards])
		var raw_accept: bool=card is Dictionary and Source.raw_source_error(card).is_empty()
		var accepted: bool=_strict_ingress(card,cards)
		var prior: Dictionary=py.results[index]
		if prior.label!=entry.label: failures.append({"kind":"case_alignment","label":entry.label})
		if accepted!=prior.candidate_accept: failures.append({"kind":"candidate_raw_gate_disagreement","label":entry.label})
		var hook_expected_ids: Array=[]
		if cards is Dictionary:
			for source_id in Source.IDS:
				if _strict_ingress(cards.get(source_id),cards): hook_expected_ids.append(source_id)
			if prior.candidate_hook_error!=null or prior.candidate_hook_accepted_ids!=hook_expected_ids: failures.append({"kind":"candidate_hook_disagreement","label":entry.label})
		elif prior.candidate_hook_error!="AttributeError": failures.append({"kind":"malformed_root_boundary_not_preserved","label":entry.label})
		var compiled_issue=null
		if prior.candidate_accept:
			var compiled: ProbeCatalog=_compiled(cards,outputs)
			compiled_issue=Source.closure_error(compiled)
			if not compiled_issue.is_empty(): failures.append({"kind":"accepted_closure_reject","label":entry.label,"error":compiled_issue})
			for source_id in Source.IDS:
				if not Source.source_error(compiled.get_card(source_id)).is_empty(): failures.append({"kind":"accepted_source_reject","label":entry.label})
		if before!=var_to_bytes([card,cards]): failures.append({"kind":"input_mutation","label":entry.label})
		if not counts.has(entry.regime): counts[entry.regime]={"cases":0,"original_accept":0,"candidate_accept":0,"strict_ingress_accept":0,"original_accept_gd_reject":0,"candidate_disagreement":0,"original_exception":0,"candidate_exception":0,"candidate_hook_exception":0,"candidate_accept_compiled_closure_reject":0}
		counts[entry.regime].cases+=1
		if prior.original_accept: counts[entry.regime].original_accept+=1
		if prior.candidate_accept: counts[entry.regime].candidate_accept+=1
		if accepted: counts[entry.regime].strict_ingress_accept+=1
		if prior.original_accept and not accepted: counts[entry.regime].original_accept_gd_reject+=1
		if prior.candidate_accept!=accepted: counts[entry.regime].candidate_disagreement+=1
		if prior.original_error!=null: counts[entry.regime].original_exception+=1
		if prior.candidate_error!=null: counts[entry.regime].candidate_exception+=1
		if prior.candidate_hook_error!=null: counts[entry.regime].candidate_hook_exception+=1
		if compiled_issue!=null and not compiled_issue.is_empty(): counts[entry.regime].candidate_accept_compiled_closure_reject+=1
		results.append({"label":entry.label,"regime":entry.regime,"original_accept":prior.original_accept,"candidate_accept":prior.candidate_accept,"actual_supplied_card_raw_gate_accept":raw_accept,"strict_ingress_accept":accepted,"compiled_closure_error":compiled_issue,"candidate_hook_expected_ids":hook_expected_ids,"candidate_hook_error":prior.candidate_hook_error,"compiled_input_projection":"actual_mapping_plus_fixed_outputs_no_detached_replacement"})
	var structure: Array=[]
	for op in ["canonical","swap_rows","duplicate_normal","duplicate_golden","missing_normal","missing_golden","both_pool_blockers","invalid_pool_blocker","valid_custom","custom_float_tier","custom_pair_tier_mismatch","custom_without_canonical","canonical_has_projection"]:
		var canonical: ProbeCatalog=_compiled(Source.RAW,outputs)
		var current: ProbeCatalog=canonical
		if op in ["swap_rows","duplicate_normal","duplicate_golden"]: current.cards=_mutate(current.cards,{"op":op,"path":[]})
		elif op=="missing_normal": current.cards.erase(Source.IDS[0])
		elif op=="missing_golden": current.cards.erase(Source.IDS[1])
		elif op=="both_pool_blockers":
			for identity in Source.IDS: current.cards[identity].pool_blocker=Pool.MINION_REASON
		elif op=="invalid_pool_blocker": current.cards[Source.IDS[0]].pool_blocker="wrong"
		elif op.begins_with("custom") or op=="valid_custom" or op=="canonical_has_projection":
			current=_project(canonical)
			if op=="custom_float_tier":
				current.cards[Source.IDS[0]].tier=4.0
				current.cards[Source.IDS[0]].custom_shop_override.tier=4.0
			elif op=="custom_pair_tier_mismatch": current.cards[Source.IDS[1]].tier=5
			elif op=="custom_without_canonical": current.source_catalog=null
			elif op=="canonical_has_projection": canonical.cards=current.cards.duplicate(true)
		var issue: String=Source.closure_error(current)
		var accepted: bool=issue.is_empty()
		if accepted!=(op in ["canonical","both_pool_blockers","valid_custom"]): failures.append({"kind":"structural_probe","op":op,"issue":issue})
		structure.append({"case":op,"accepted":accepted,"closure_error":issue})
	var effects: Array=[]
	for identity in Source.IDS:
		for op in ["canonical","float_equal","bool_multiplier","wrong_amount","extra_field","nonfinite"]:
			var effect: Dictionary=outputs[identity].effects[0].duplicate(true)
			if op=="float_equal": effect.health_multiplier=float(effect.health_multiplier)
			elif op=="bool_multiplier": effect.health_multiplier=true
			elif op=="wrong_amount": effect.health_multiplier=99
			elif op=="extra_field": effect.extra=true
			elif op=="nonfinite": effect.health_multiplier=INF
			var issue: String=Source.effect_error(effect)
			if issue.is_empty()!=(op in ["canonical","float_equal"]): failures.append({"kind":"effect_probe","identity":identity,"op":op})
			effects.append({"identity":identity,"op":op,"accepted":issue.is_empty(),"error":issue})
	var report: Dictionary={"case_count":cases.size(),"counts":counts,"results":results,"structural_probes":structure,"effect_probes":effects,"failures":failures,"godot_version":Engine.get_version_info(),"strict_ingress_is_composed_diagnostic_not_single_project_entry":true,"actual_source_raw_effect_closure_functions_used":true,"catalog_interface_is_minimal_probe_not_full_catalog":true,"game_catalog_host_or_save_run":false,"new_correction_created":true,"candidate_installed":false,"raw_gate_comparison_scope":"fixed_RAW_plain_JSON_shapes_not_arbitrary_Variant_universal_equivalence"}
	var output: String=OS.get_cmdline_user_args()[0]
	var writer=FileAccess.open(output,FileAccess.WRITE)
	writer.store_string(JSON.stringify(report,"\t")+"\n")
	writer.close()
	print("Cases ",cases.size(),"; failures ",failures.size(),"; differences ",counts)
	quit(0 if failures.is_empty() else 1)
