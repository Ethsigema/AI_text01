"""Replay only the bounded, isolated candidate probes. Never install or run the full driver."""
from pathlib import Path
import hashlib,json,subprocess,sys,resource
resource.setrlimit(resource.RLIMIT_AS,(128*1024**2,resource.RLIM_INFINITY))
H=Path(__file__).resolve().parent;assert len(sys.argv)==2;D=Path(sys.argv[1]).resolve();assert not D.exists();D.mkdir(parents=True)
files=json.loads((H/'REPLAY_INPUTS.json').read_text())
for rel,pin in files.items():
 b=(H/rel).read_bytes();assert len(b)==pin['bytes'] and hashlib.sha256(b).hexdigest()==pin['sha256'];p=D/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b);assert p.stat().st_ino!=(H/rel).stat().st_ino
# The Godot launcher raises only its child address-space limit to 2 GiB while
# enforcing the documented 192 MiB RSS/45 s stop conditions. Start it separately.
for script in ['test_candidate.py','check_native_inputs.py']:subprocess.run([sys.executable,'-B',str(D/script)],check=True)
subprocess.run([sys.executable,'-B',str(D/'run_godot.py')],check=True)
gd=json.loads((D/'GODOT_first.json').read_text());assert gd==json.loads((D/'GODOT_repeat.json').read_text()) and not gd['failures'];assert gd['case_count']==3622
assert sum(v['candidate_accept'] for v in gd['counts'].values())==362
assert sum(v['candidate_disagreement'] for v in gd['counts'].values())==0
assert sum(v['candidate_accept_compiled_closure_reject'] for v in gd['counts'].values())==0
assert sum(v['candidate_hook_exception'] for v in gd['counts'].values())==16
for rel,pin in files.items():assert hashlib.sha256((D/rel).read_bytes()).hexdigest()==pin['sha256']
result={'status':'PASS_BOUNDED_CANDIDATE_REPLAY_NOT_INSTALLATION_OR_GAME_ACCEPTANCE','destination':str(D),'copied_files':len(files),'source_runtime_needed':False,'case_count':3622,'candidate_positive_cases':362,'candidate_GD_diagnostic_disagreements':0,'candidate_direct_exceptions':0,'unchanged_historical_hook_invalid_root_exceptions':16,'candidate_installed':False,'full_driver_Catalog_Game_host_or_saves_run':False}
(D/'REPLAY_RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
