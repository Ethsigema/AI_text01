extends SceneTree
## Parent-only source/syntax admission. Never instantiate Game or execute effects.
const Game=preload("res://core/game.gd")
const Catalog=preload("res://core/catalog.gd")
const Sources=preload("res://core/titanic_guardian_sources.gd")
const Host=preload("res://core/master_realities_host.gd")
func _initialize() -> void:
	var catalog=Catalog.new()
	catalog.load_catalog()
	var rows: Array=[]
	var ok: bool=catalog.load_errors.is_empty()
	for id in Sources.IDS:
		var card: Dictionary=catalog.get_card(id)
		var template: Dictionary=catalog.hand_card_templates.get(id,{})
		var issue: String=Sources.source_error(card)
		if issue.is_empty(): issue=Sources.unit_error(template)
		ok=ok and issue.is_empty() and not template.is_empty() and card.get("supported")==true and card.get("default_pool")==false and card.get("pool_supported")==false
		rows.append({"id":id,"error":issue,"supported":card.get("supported"),"default_pool":card.get("default_pool"),"pool_supported":card.get("pool_supported"),"blocker":card.get("coverage_blocker"),"template":template})
	var closure: String=Sources.closure_error(catalog)
	ok=ok and closure.is_empty()
	var result: Dictionary={"ok":ok,"load_errors":catalog.load_errors,"closure_error":closure,"rows":rows,"game_preloaded":Game!=null,"host_preloaded":Host!=null,"game_instantiated":false,"effects_executed":false,"gameplay_acceptance":"not_run"}
	var file=FileAccess.open("res://research/titanic_guardian_native_recovery/admission.json",FileAccess.WRITE)
	if file==null: quit(2);return
	file.store_string(JSON.stringify(result,"  ")+"\n")
	print(JSON.stringify(result))
	quit(0 if ok else 1)
