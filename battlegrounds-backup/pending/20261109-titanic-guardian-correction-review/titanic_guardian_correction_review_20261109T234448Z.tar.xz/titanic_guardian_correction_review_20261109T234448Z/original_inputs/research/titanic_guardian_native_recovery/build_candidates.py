from pathlib import Path
import json,hashlib,difflib,re,ast,xml.etree.ElementTree as ET
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent;C=OUT/'candidates';R='research/titanic_guardian_native_recovery/'
IDS=['TB_BaconShop_HERO_39_Buddy','TB_BaconShop_HERO_39_Buddy_G'];TYPE='after_other_friendly_hand_board_health_gained';RULE='titanic_guardian_native_actual_health_partial_v1'
def sha(s):return hashlib.sha256(s if isinstance(s,bytes) else s.encode()).hexdigest()
def save(p,s):
 d=C/p;d.parent.mkdir(parents=True,exist_ok=True);d.write_text(s)
def data(p,obj):save(p,json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
raw={r['id']:r for r in json.loads((ROOT/'data/catalog_raw.json').read_text())['cards'] if r['id'] in IDS}
input_path=Path('/tmp/master_realities_native.xml');xml=input_path.read_text();assert sha(input_path.read_bytes())=='c385e3d67bfc2c52408059fbb0399b41164c8d1b78d3dd1619a6fb1882116690'
quantities={};programs={}
texts={IDS[0]:('[x]Whenever a different minion\nin your hand or board gains\nHealth, this also gains it.',1),IDS[1]:('[x]Whenever a different minion\nin your hand or board gains\nHealth, this also gains\ntwice that amount.',2)}
for identity in IDS:
 start=xml.index('<Entity CardID="'+identity+'"');end=xml.index('</Entity>',start)+9;native=xml[start:end]+'\n';save(R+'native/'+identity+'.xml',native)
 entity=ET.fromstring(native);tags={t.get('name'):t for t in entity.findall('Tag')};text=tags['CARDTEXT'].findtext('enUS');expected_text,multiplier=texts[identity]
 assert text==expected_text and tags['CARDTEXT'].findtext('zhCN')==raw[identity]['text']
 q={'dbf_id':entity.get('ID'),'name_enUS':tags['CARDNAME'].findtext('enUS'),'name_zhCN':tags['CARDNAME'].findtext('zhCN'),'attack':int(tags['ATK'].get('value')),'health':int(tags['HEALTH'].get('value')),'tier':int(tags['TECH_LEVEL'].get('value')),'race':int(tags['CARDRACE'].get('value')),'health_multiplier':multiplier,'operations':1,'enUS':text,'zhCN':tags['CARDTEXT'].findtext('zhCN'),'native_links':{k:int(tags[k].get('value')) for k in ['BACON_TRIPLE_UPGRADE_MINION_ID','BACON_TRIPLED_BASE_MINION_ID'] if k in tags},'native_sha256':sha(native)}
 assert all(raw[identity][k]==q[k] for k in ['dbf_id','attack','health','tier']) and q['race']==18 and raw[identity]['tribes']==['元素'] and raw[identity]['name']==q['name_zhCN']
 quantities[identity]=q;programs[identity]=[{'type':TYPE,'source_id':identity,'subject':'other_physical_minion','subject_zones':['hand','board'],'listener_zone':'board','scope':'self','gain':'actual_max_health','health_multiplier':multiplier}]
assert quantities[IDS[0]]['native_links']['BACON_TRIPLE_UPGRADE_MINION_ID']==int(raw[IDS[1]]['dbf_id'])
assert quantities[IDS[1]]['native_links']['BACON_TRIPLED_BASE_MINION_ID']==int(raw[IDS[0]]['dbf_id'])
reason='Whole independently sourced Titanic Guardian normal/golden Elemental buddy pair, DBF77819/77820, tier3 bodies5/2 and10/4. A different physical friendly hand or battlefield minion actually gaining maximum Health causes the active battlefield Guardian itself to receive one real Health grant equal to that realized delta; golden doubles the amount, not operation count. Exact raw/native identity, independent whole programs, native pair links, custom-shop tier inheritance, restored source fingerprints and complete-command preflight are retained. Recruit real additive and established positive ordinary SET/multiply writers and Combat private per-operation board and common hand writers issue exact object/UID/combat-generation/hand-reference receipts. Public events cannot mint grants. Actual native output invokes the existing real buff queue; hand inputs retain owned or generated reward references, while the Guardian output is Combat-local unless a separately validated retention system applies. Recruit observer-owned Health is excluded from temporary Spellcraft expiry using a private realized-output counter. Two active Guardians with positive reciprocal Health, same-origin hand/body copies, cross-family recursive or incomplete projections, unknown hand producers, cumulative specialized projections, dynamic owner/aura layers, mixed-signed gains and special permanence are precise partial boundaries, never same-card-ID exclusions. Source/static admission is not gameplay acceptance; default_pool=false, pool_supported=false, no metrics or full/core promotion.'
expected={i:{'id':i,'supported':True,'effects':programs[i],'keywords':[],'coverage_rule':RULE,'coverage_text_sha256':sha(raw[i]['text']),'default_pool':False,'pool_supported':False,'implementation_status':'partial_implementation_supported_pending_unified_validation','conditional_support':{'rule':RULE,'reason':reason}} for i in IDS}
manifest_native={'source_url':'https://raw.githubusercontent.com/HearthSim/hsdata/27fbd2323aec20cab1c6ecc7d5f55cf12729f956/CardDefs.Bacon.xml','cached_input_sha256':sha(input_path.read_bytes()),'native_build':'253932','entities':quantities,'golden_semantics':'Independent selected enUS/zhCN: one Health grant at twice the realized Health amount. Not a repeated operation.','scope':'Other physical friendly minions in hand or battlefield; listener and recipient are the same actual active battlefield Guardian. No shop and no listener activation in hand.','historical_difference':{'cached_file':'/tmp/enhanced-spawn-225000-CardDefs.xml','sha256':'2797d31426338a8a9b9d436383350d7610558b2af9bb1e6063e5cc975c9c6ea0','tier':4,'race':None,'text_domain':'different friendly minion, without explicit hand phrase','selected':False},'raw_conflicts':[]}
proof={'raw_rows.json':raw,'programs.json':programs,'expected_compiled.json':expected,'native_quantities.json':quantities,'native_source_manifest.json':manifest_native,'pending_catalog_overlay.json':list(expected.values())}
for p,o in proof.items():data(R+p,o)
paths=['core/titanic_guardian_sources.gd','core/master_realities_host.gd','tools/titanic_guardian_patterns.py']+[R+p for p in list(proof)[:5]+['native/'+i+'.xml' for i in IDS]]
source=(ROOT/'core/stormbringer_gain_sources.gd').read_text().replace('stormbringer_gain','titanic_guardian').replace('after_other_friendly_dragon_attack_gained',TYPE)
for key,val in [('IDS',IDS),('RAW',raw),('PROGRAMS',programs),('EXPECTED',expected),('RUNTIME_PATHS',paths)]:source=re.sub(r'^const '+key+r': [^=]+=.*$',lambda m:'const '+key+': '+('Array' if isinstance(val,list) else 'Dictionary')+'='+json.dumps(val,ensure_ascii=False,separators=(',',':')),source,flags=re.M)
save('core/titanic_guardian_sources.gd',source)
save('tools/titanic_guardian_patterns.py','"""Independent Titanic Guardian whole pair; golden doubles one Health grant."""\nfrom copy import deepcopy\nSOURCE_IDS = '+repr(tuple(IDS))+'\nRAW = '+repr(raw)+'\nEXPECTED = '+repr(expected)+'\ndef compile_card(card,cards):\n    if not isinstance(card,dict) or card.get("id") not in SOURCE_IDS:\n        return None\n    if any(cards.get(identity)!=RAW[identity] for identity in SOURCE_IDS):\n        return None\n    return deepcopy(EXPECTED[card["id"]])\n')
changes={}
def read(p):
 if p not in changes: changes[p]=[(ROOT/p).read_text(),(ROOT/p).read_text()]
 return changes[p][1]
def put(p,t):changes[p][1]=t
def rep(p,a,b,n=1):
 t=read(p);assert t.count(a)==n,(p,a[:100],t.count(a),n);put(p,t.replace(a,b))
p='core/master_realities_host.gd'
rep(p,'const Ragescale=','const Titanic=preload("res://core/titanic_guardian_sources.gd")\nconst Ragescale=')
rep(p,'var _observed: Dictionary={}','var _observed: Dictionary={}\nvar _combat_ordinal: int=0\nvar _titanic_health_totals: Dictionary={}\nfunc titanic_health_total(uid: String) -> int: return int(_titanic_health_totals.get(uid,0))')
rep(p,'or Ragescale.claimed(unit)','or Ragescale.claimed(unit) or Titanic.claimed(unit)')
rep(p,'\treturn Ragescale.unit_error(unit) if issue.is_empty() else issue','\tif issue.is_empty(): issue=Ragescale.unit_error(unit)\n\treturn Titanic.unit_error(unit) if issue.is_empty() else issue')
anchor='static func _subject_matches(board: Array,subject: Dictionary) -> bool:\n'
rep(p,anchor,'''static func _titanic_matches(board: Array,subject: Dictionary) -> bool:
	if not Gains.living(subject): return false
	return board.any(func(source):return Titanic.claimed(source) and Gains.active(source) and not is_same(source,subject) and (not subject.has("uid") or source.get("uid")!=subject.get("uid")))
static func _hand_reference(subject: Dictionary) -> Variant:
	if subject.get("generated",false): return {"reward_sequence":subject.get("reward_sequence"),"reward_index":subject.get("reward_index")}
	return subject.get("uid")
'''+anchor)
rep(p,anchor+'\tif _ragescale_matches',anchor+'\tif _titanic_matches(board,subject): return true\n\tif _ragescale_matches')
rep(p,'static func _gain_matches(board: Array,subject: Dictionary,attack: int,health: int) -> bool:\n','static func _gain_matches(board: Array,subject: Dictionary,attack: int,health: int) -> bool:\n\tif health>0 and _titanic_matches(board,subject): return true\n')
rep(p,'if owner.get("alive",false) and _present(owner.get("board",[]),subject): return owner','if owner.get("alive",false) and (_present(owner.get("board",[]),subject) or _present(owner.get("hand",[]),subject) and _titanic_matches(owner.get("board",[]),subject)): return owner')
rep(p,'multiply: bool=false,reserved: Dictionary={}) -> Dictionary:','multiply: bool=false,reserved: Dictionary={},hand: Array=[]) -> Dictionary:')
rep(p,'\tif not _present(board,subject) or not Gains.living(subject) or not _subject_matches(board,subject): return result','''	var on_board: bool=_present(board,subject)
	var in_hand: bool=_present(hand,subject)
	if not Gains.living(subject) or not (on_board and _subject_matches(board,subject) or in_hand and _titanic_matches(board,subject)): return result
	if on_board and in_hand: return _fail("titanic_guardian_aliased_hand_board_subject")
	if in_hand:
		var reference: Variant=_hand_reference(subject)
		if reference==null or hand.filter(func(card):return Sources.same(_hand_reference(card),reference)).size()!=1: return _fail("titanic_guardian_ambiguous_hand_reference")
		for body in board:
			if subject.has("uid") and body.get("uid")==subject.uid: return _fail("titanic_guardian_aliased_hand_board_uid")
			if Titanic.claimed(body) and Gains.active(body) and Sources.same(body.get("_hand_source_reference"),reference): return _fail("titanic_guardian_same_origin_copy_semantics_partial")''')
rep(p,'\tif not _gain_matches(board,subject,attack,health): return result','\tif not (_gain_matches(board,subject,attack,health) if on_board else health>0 and _titanic_matches(board,subject)): return result')
rep(p,'\tif attack>0 and _dragon(subject) and storm_count>1:', '\tif on_board and attack>0 and _dragon(subject) and storm_count>1:')
rep(p,'\tvar seen: Dictionary={}\n','\tif health>0 and _titanic_matches(board,subject) and board.filter(func(unit):return Titanic.claimed(unit) and Gains.active(unit)).size()>1: return _fail("titanic_guardian_mutual_health_cycle_partial")\n\tvar seen: Dictionary={}\n')
rep(p,'\t\tif ragescale:\n','''		var titanic: bool=Titanic.accepts_id(source.get("card_id"))
		if titanic:
			if health<=0 or is_same(source,subject) or subject.has("uid") and source.uid==subject.uid: continue
			if on_board and subject.has("_hand_source_reference") and Sources.same(subject._hand_source_reference,source.get("_hand_source_reference")): return _fail("titanic_guardian_shared_hand_origin_semantics_partial")
			var multiplier: int=int(Titanic.PROGRAMS[source.card_id][0].health_multiplier)
			if multiplier==2 and health>Gains.MAX-health: return _fail("titanic_guardian_realized_health_multiplier_overflow")
			effect={"type":Titanic.TYPE,"attack":0,"health":health*multiplier}
		elif not on_board: continue
		elif ragescale:
''')
rep(p,'\t\tvar changed_subject: Dictionary=Gains._find(shadow,str(subject.uid))\n\t\tchanged_subject.clear();changed_subject.merge(after.duplicate(true),true)','\t\tif on_board:\n\t\t\tvar changed_subject: Dictionary=Gains._find(shadow,str(subject.uid))\n\t\t\tchanged_subject.clear();changed_subject.merge(after.duplicate(true),true)')
rep(p,'\t\t\tvar suffix: Dictionary=Gains.reaction_plan(shadow,target,received,combat)','''			if titanic and _gain_matches(shadow,target,Gains.attack_value(target)-Gains.attack_value(prior_target),int(target.max_health)-int(prior_target.max_health)): return _fail("titanic_guardian_downstream_actual_gain_cycle_or_projection_partial")
			if not titanic and int(target.max_health)>int(prior_target.max_health) and _titanic_matches(shadow,target): return _fail("titanic_guardian_cross_family_projection_partial")
			var suffix: Dictionary={"ok":true,"records":[]}
			if Gains.attack_value(target)>Gains.attack_value(prior_target): suffix=Gains.reaction_plan(shadow,target,received,combat)''')
rep(p,'\t\t\t\tvar suffix_target: Dictionary=Gains._find(shadow,str(reaction.target_uid))','\t\t\t\tvar suffix_target: Dictionary=Gains._find(shadow,str(reaction.target_uid))\n\t\t\t\tif int(reaction.after.max_health)>int(reaction.before.max_health) and _titanic_matches(shadow,suffix_target): return _fail("titanic_guardian_cross_family_health_suffix_projection_partial")')
rep(p,'result.subject=subject;result.uid=subject.uid;','result.subject=subject;result.uid=subject.get("uid");result.in_hand=in_hand;result.hand_reference=_hand_reference(subject);')
rep(p,'false,multiply,_reserved)','false,multiply,_reserved,owner.get("hand",[]))')
rep(p,'\t\tvar counter_issue: String=_ragescale_counter_error(result)','\t\tvar counter_issue: String=_titanic_counter_error(result)\n\t\tif counter_issue.is_empty(): counter_issue=_ragescale_counter_error(result)')
a='\t\tif issue.is_empty() and result.listeners.any(func(listener):return listener.type==Ragescale.TYPE): issue=Ragescale.closure_error(engine.catalog)'
rep(p,a,a+'\n\t\tif issue.is_empty() and result.listeners.any(func(listener):return listener.type==Titanic.TYPE): issue=Titanic.closure_error(engine.catalog)')
anchor='func _ragescale_counter_error(prepared: Dictionary) -> String:\n'
start=read(p).index(anchor);end=read(p).index('\nfunc prepare_recruit',start);block=read(p)[start:end]
rep(p,anchor,block.replace('_ragescale_counter_error','_titanic_counter_error').replace('_ragescale_attack_totals','_titanic_health_totals').replace('Ragescale.TYPE','Titanic.TYPE').replace('vector.attack','vector.health').replace('listener.attack','listener.health').replace('ragescale_','titanic_guardian_').replace('_attack_counter','_health_counter')+'\n\n'+anchor)
rep(p,'_stats(subject)!=prepared.after or not _layers_match(subject,prepared):','_stats(subject)!=prepared.after or not _layers_match(subject,prepared) or not Sources.same(_hand_reference(subject),prepared.hand_reference):',2)
a='\t\t\tvar ragescale_before: int=Gains.attack_value(target)'
rep(p,a,a+'\n\t\t\tvar titanic_before: int=int(target.max_health)\n\t\t\tif listener.type==Titanic.TYPE and titanic_health_total(str(target.uid))>Gains.MAX-int(listener.health): issue="titanic_guardian_private_health_counter_overflow";break')
a='\t\t\tvar audit: Dictionary={"player":owner.id'
rep(p,a,'''\t\t\tif listener.type==Titanic.TYPE:
				var titanic_received: int=int(target.max_health)-titanic_before
				if titanic_received!=int(listener.health): issue="titanic_guardian_actual_output_receipt_changed";break
				_titanic_health_totals[target.uid]=titanic_health_total(str(target.uid))+titanic_received
'''+a)
rep(p,'engine._log("ragescale_gain" if listener.type==Ragescale.TYPE else ("stormbringer_gain" if listener.type==Storm.TYPE else "master_realities_gain"),audit)','engine._log("titanic_guardian_gain" if listener.type==Titanic.TYPE else ("ragescale_gain" if listener.type==Ragescale.TYPE else ("stormbringer_gain" if listener.type==Storm.TYPE else "master_realities_gain")),audit)')
# Private combat issuance order is distinct from delayed public receipt order.
# Root reservations precede immediate hand suffix reservations. Do not drain
# any of them before every producer has published its matching private receipt.
rep(p,'\tprepared.scalar=false\n\t_pending.append(prepared)','\t_combat_ordinal+=1;prepared.ordinal=_combat_ordinal\n\tprepared.scalar=false\n\t_pending.append(prepared)')
rep(p,'\tprepared.scalar=true;prepared.event=event;prepared.reason=reason','\t_combat_ordinal+=1;prepared.ordinal=_combat_ordinal\n\tprepared.scalar=true;prepared.event=event;prepared.reason=reason')
anchor='func _find(engine,uid: String) -> Dictionary:\n'
rep(p,anchor,'''# Called only by genuine hand writers, before their actual mutation. The
# recipient is still an owned/generated hand object; output is the board source.
func prepare_combat_hand(engine,side: int,subject: Dictionary,after: Dictionary) -> Dictionary:
	if side not in [0,1] or not _titanic_matches(engine._boards[side],subject): return _empty()
	if not engine._combat_hand.available[side] or not _present(engine._combat_hand.hands[side],subject): return _fail("titanic_guardian_actual_combat_hand_required")
	var owner: int=int(engine._options.get("left_global_card_state" if side==0 else "right_global_card_state",{}).get("id",-1))
	if owner<0: return _fail("titanic_guardian_original_hand_owner_required")
	if not Sources.same(_hand_reference(subject),_hand_reference(after)): return _fail("titanic_guardian_hand_reference_changed")
	var result: Dictionary=plan(engine._boards[side],subject,after,engine._options.has(Gains.Received.CONTEXT),true,false,_reserved,engine._combat_hand.hands[side])
	if not result.ok or result.listeners.is_empty(): return result
	for listener in result.listeners:
		if engine._keep_gains_host!=null and engine._keep_gains_host._multiplier(engine,listener.unit)>0: return _fail("titanic_guardian_hand_input_special_retention_partial")
	if not engine._error.is_empty(): return _fail(engine._error)
	if result.listeners.size()>engine._max_steps-engine._steps: return _fail("titanic_guardian_hand_suffix_iteration_preflight")
	result.side=side;result.owner_id=owner
	return result
func capture_combat_hand(engine,subject: Dictionary,prepared: Dictionary) -> String:
	if prepared.get("listeners",[]).is_empty(): return ""
	var side: int=int(prepared.side)
	if not is_same(subject,prepared.subject) or not _present(engine._combat_hand.hands[side],subject) or subject.get("uid")!=prepared.uid or subject.get("card_id")!=prepared.card_id or _stats(subject)!=prepared.after or not _layers_match(subject,prepared) or not Sources.same(_hand_reference(subject),prepared.hand_reference): return "titanic_guardian_actual_hand_write_changed"
	for listener in prepared.listeners: _reserve(listener)
	_combat_ordinal+=1;prepared.ordinal=_combat_ordinal
	prepared.scalar=false
	_pending.append(prepared)
	return ""
func _begin_hand_event(engine,record: Dictionary) -> void:
	var side: int=int(record.get("side",-1))
	if side not in [0,1]: return
	var reference: Variant={"reward_sequence":record.reward_sequence,"reward_index":record.get("reward_index")} if record.has("reward_sequence") else record.get("target_uid")
	var matches: Array=engine._combat_hand.hands[side].filter(func(card):return Sources.same(_hand_reference(card),reference))
	if matches.size()!=1:
		if _pending.any(func(item):return item.get("in_hand",false) and item.side==side and Sources.same(item.hand_reference,reference)): engine._fail("titanic_guardian_queued_hand_reference_missing")
		return
	var subject: Dictionary=matches[0]
	for index in range(_pending.size()):
		var pending: Dictionary=_pending[index]
		if not pending.get("in_hand",false) or not is_same(pending.subject,subject): continue
		var owner: int=int(engine._options.get("left_global_card_state" if side==0 else "right_global_card_state",{}).get("id",-1))
		if pending.side!=side or pending.owner_id!=owner or subject.get("uid")!=pending.uid or subject.get("card_id")!=pending.card_id or _stats(subject)!=pending.after or not _layers_match(subject,pending) or not Sources.same(reference,pending.hand_reference) or record.get("max_health")!=subject.max_health or record.get("health")!=subject.health or record.get("attack")!=subject.attack:
			engine._fail("titanic_guardian_private_hand_receipt_changed");return
		_pending.remove_at(index);pending.sequence=record.sequence
		_queue.append(pending)
		return
	if int(record.get("health_delta",0))>0 and _titanic_matches(engine._boards[side],subject): engine._fail("titanic_guardian_unbridged_hand_producer_partial")
'''+anchor)
rep(p,'\tif event=="combat_start":','\tif event=="hand_buff":\n\t\t_begin_hand_event(engine,record);return\n\tif event=="combat_start":')
rep(p,'\t\tif not is_same(pending.subject,unit): continue','\t\tif pending.get("in_hand",false) or not is_same(pending.subject,unit): continue')
rep(p,'if _depth>0 or _draining or not engine._error.is_empty(): return','if _depth>0 or _draining or not engine._error.is_empty() or not _pending.is_empty(): return')
rep(p,'\twhile not _queue.is_empty() and engine._error.is_empty():','\t_queue.sort_custom(func(a,b):return int(a.ordinal)<int(b.ordinal))\n\twhile not _queue.is_empty() and engine._error.is_empty():')
rep(p,'"trigger_unit":gain.uid,','"trigger_unit":str(gain.uid) if gain.uid!=null else "",')
# Pure board/hand projections: never issue native receipts or manufacture IDs.
rep(p,'\tif not _present(state.player.board,subject): return ""\n\tvar shadow: Array=state.player.board.duplicate(true)\n\tvar prior: Dictionary=Gains._find(shadow,str(subject.uid))\n\tprior.clear();prior.merge(before.duplicate(true),true)\n\tvar prepared: Dictionary=plan(shadow,prior,subject if after.is_empty() else after,Gains.Received.enabled(engine.room),false,multiply)', '''	var in_hand: bool=_present(state.player.get("hand",[]),subject)
	if not _present(state.player.board,subject) and not in_hand: return ""
	var shadow: Array=state.player.board.duplicate(true)
	var hand: Array=state.player.get("hand",[]).duplicate(true)
	var prior: Dictionary=Gains._find(hand if in_hand else shadow,str(subject.uid))
	prior.clear();prior.merge(before.duplicate(true),true)
	var prepared: Dictionary=plan(shadow,prior,subject if after.is_empty() else after,Gains.Received.enabled(engine.room),false,multiply,{},hand)''')
rep(p,'\t\tvar issue: String=Gains._adjust(target,int(listener.attack),int(listener.health),Gains.Received.enabled(engine.room))','\t\tvar output_before: Dictionary=target.duplicate(true)\n\t\tvar issue: String=Gains._adjust(target,int(listener.attack),int(listener.health),Gains.Received.enabled(engine.room))')
rep(p,'\t\tvar suffix: Dictionary=Gains.reaction_plan(state.player.board,target,Gains.Received.enabled(engine.room),false)','\t\tvar suffix: Dictionary={"ok":true,"records":[]}\n\t\tif Gains.attack_value(target)>Gains.attack_value(output_before): suffix=Gains.reaction_plan(state.player.board,target,Gains.Received.enabled(engine.room),false)')
rep(p,'\tfor prior in before.get("board",[]):','\tfor prior in before.get("board",[])+before.get("hand",[]):')
rep(p,'Gains._find(after.get("board",[]),str(prior.get("uid","")))','Gains._find(after.get("board",[])+after.get("hand",[]),str(prior.get("uid","")))')
# Exact source, save validation, compile registration and source fingerprint.
p='core/catalog.gd';rep(p,'extends RefCounted\n','extends RefCounted\nconst TitanicSources=preload("res://core/titanic_guardian_sources.gd")\n');rep(p,'const EXTRA_EFFECTS: Array = [','const EXTRA_EFFECTS: Array = [TitanicSources.TYPE,')
a='\tfor path in RagescaleSources.RUNTIME_PATHS:\n\t\tfingerprints.append(path+":"+FileAccess.get_file_as_string("res://"+path).sha256_text())';rep(p,a,a.replace('RagescaleSources','TitanicSources')+'\n'+a)
t=read(p);a='\t\t\t\tif path != "res://data/catalog.json" and RagescaleSources.accepts_id(raw_card.get("id")):';starts=[m.start() for m in re.finditer(re.escape(a),t)];assert len(starts)==4
for pos in reversed(starts):
 end=t.index('\n\t\t\t\tif ',pos+len(a));block=t[pos:end];t=t[:pos]+block.replace('RagescaleSources','TitanicSources').replace('ragescale_','titanic_guardian_')+'\n'+t[pos:]
for a,indent in [('\t\tif RagescaleSources.claimed(card):','\n\t\tif '),('\tif RagescaleSources.claimed(source):','\n\tif ')]:
 pos=t.index(a);end=t.index(indent,pos+len(a));block=t[pos:end];t=t[:pos]+block.replace('RagescaleSources','TitanicSources').replace('ragescale_','titanic_guardian_')+'\n'+t[pos:]
put(p,t)
p='core/combat_hand.gd';rep(p,'extends RefCounted\n','extends RefCounted\nconst TitanicSources=preload("res://core/titanic_guardian_sources.gd")\n');rep(p,'const EFFECT_TYPES: Array = [','const EFFECT_TYPES: Array = [TitanicSources.TYPE,')
rep(p,'static func effect_error(effect: Dictionary) -> String:\n','static func effect_error(effect: Dictionary) -> String:\n\tif effect.get("type")==TitanicSources.TYPE: return TitanicSources.effect_error(effect)\n')
a='\tvar ragescale_issue: String=RagescaleSources.unit_error(card)\n\tif not ragescale_issue.is_empty(): return ragescale_issue';rep(p,a,a.replace('RagescaleSources','TitanicSources').replace('ragescale_issue','titanic_issue')+'\n'+a)
p='core/game.gd'
a='\t\tvar ragescale_attack_before: int=_master_realities_host.ragescale_attack_total(str(target_unit.get("uid","")))';rep(p,a,a+'\n\t\tvar titanic_health_before: int=_master_realities_host.titanic_health_total(str(target_unit.get("uid","")))')
rep(p,'"health":target_unit.health-before_cast.health-(AttackGains.health_total(self,str(target_unit.get("uid","")))-reaction_health_before),','"health":target_unit.health-before_cast.health-(AttackGains.health_total(self,str(target_unit.get("uid","")))-reaction_health_before)-(_master_realities_host.titanic_health_total(str(target_unit.get("uid","")))-titanic_health_before),')
a='\tif MasterRealities.Ragescale.claimed(card) and (not MasterRealities.Ragescale.source_error(card).is_empty() or not MasterRealities.Ragescale.closure_error(catalog).is_empty()): return {}';rep(p,a,a.replace('MasterRealities.Ragescale','MasterRealities.Titanic')+'\n'+a)
a='\tif not MasterRealities.Ragescale.unit_error(unit).is_empty(): return false';rep(p,a,a.replace('MasterRealities.Ragescale','MasterRealities.Titanic')+'\n'+a)
p='core/combat.gd';rep(p,'const COMBAT_EFFECTS: Array[String] = [','const COMBAT_EFFECTS: Array[String] = [MasterRealities.Titanic.TYPE,')
a='\tvar ragescale_issue: String=MasterRealities.Ragescale.unit_error(unit)\n\tif not ragescale_issue.is_empty(): return ragescale_issue';rep(p,a,a.replace('MasterRealities.Ragescale','MasterRealities.Titanic').replace('ragescale_issue','titanic_issue')+'\n'+a)
a='\t\t\tMasterRealities.Ragescale.TYPE:\n\t\t\t\tvar ragescale_effect_issue: String=MasterRealities.Ragescale.effect_error(effect)\n\t\t\t\tif not ragescale_effect_issue.is_empty(): return ragescale_effect_issue';rep(p,a,a.replace('MasterRealities.Ragescale','MasterRealities.Titanic').replace('ragescale_effect_issue','titanic_effect_issue')+'\n'+a)
anchor='func _apply_hand_buff(side: int, source: Dictionary, effect: Dictionary, repetition: int, reason: String = "deathrattle_hand_buff_target") -> void:\n'
rep(p,anchor,'''# Genuine producer boundary shared by existing hand writers. Preparing a
# projection or emitting hand_buff alone cannot issue an actual-gain receipt.
func _commit_native_hand_stats(side: int,subject: Dictionary,after: Dictionary) -> bool:
	var prepared: Dictionary=_master_realities_host.prepare_combat_hand(self,side,subject,after)
	if not prepared.ok: _fail(str(prepared.error));return false
	subject.clear();subject.merge(after.duplicate(true),true)
	var issue: String=_master_realities_host.capture_combat_hand(self,subject,prepared)
	if not issue.is_empty(): _fail(issue);return false
	return true

'''+anchor)
start=read(p).index('\tif LocPrince.Sources.claimed(recipient):',read(p).index(anchor));end=read(p).index('\n\tvar payload:',start)
block='''	var native_hand_after: Dictionary=recipient.duplicate(true)
	if LocPrince.Sources.claimed(recipient):
		var hand_owner: int=int(_options.get("left_global_card_state" if side==0 else "right_global_card_state",{}).get("id",-1))
		var native_hand_plan: Dictionary=KillRewards.KillHand.adjust_copy(recipient,hand_owner,attack_delta,health_delta,_options.has(DamageListenerHost.CONTEXT))
		if not str(native_hand_plan.error).is_empty(): _fail(str(native_hand_plan.error));return
		native_hand_after=native_hand_plan.after
	else:
		if not CombatHand.buff_fits(recipient,attack_delta,health_delta): _fail("Combat hand permanent buff exceeds the supported integer range");return
		native_hand_after.attack=int(recipient.attack)+attack_delta
		native_hand_after.health=int(recipient.health)+health_delta
		native_hand_after.max_health=int(recipient.max_health)+health_delta
	if not _commit_native_hand_stats(side,recipient,native_hand_after): return'''
put(p,read(p)[:start]+block+read(p)[end:])
# Main independently owned hand producers. Keep their own public settlement
# events, deltas, reward references and permanence untouched.
p='core/kill_hand_host.gd';rep(p,'\t\trecipient.clear();recipient.merge(plan.after,true)','\t\tif not engine._commit_native_hand_stats(side,recipient,plan.after): return false')
for p in ['core/timewarped_expeditioner_host.gd','core/brinescale_transfer_host.gd']:
 a='\t\ttarget.clear();target.merge(record.after.duplicate(true),true)'
 # Only normal immediate commit: Deathwing has a separately sealed delayed receipt group.
 t=read(p);pos=t.index(a,t.index('static func commit_combat('));t=t[:pos]+t[pos:].replace(a,'\t\tif not engine._commit_native_hand_stats(side,target,record.after): return str(engine._error)',1);put(p,t)
 # Pure transfer projections are deliberately held rather than silently
 # dropping observer output; ordinary actual recursive buff paths are wired.
 a='static func prepare_shadow(engine,state: Dictionary,subject: Dictionary,attack: int,health: int) -> Dictionary:\n'
 rep(p,a,a+'\tif health>0 and state.player.get("hand",[]).any(func(card):return engine.MasterRealities._titanic_matches(state.player.board,card)) and _eligible(state.player.board,subject): return _fail("titanic_guardian_recruit_transfer_projection_partial")\n')
p='core/hand_murloc_gain_host.gd';rep(p,'\t\trecord.target.clear();record.target.merge(record.after.duplicate(true),true)\n\t\tengine._emit("hand_buff",payload(prepared,record))','\t\tif not engine._commit_native_hand_stats(side,record.target,record.after): return str(engine._error)\n\t\tengine._emit("hand_buff",payload(prepared,record))')
a='\tfor record in prepared.records:\n\t\trecord.target.clear();record.target.merge(record.after.duplicate(true),true);state.operations+=1'
rep(p,a,'\tfor record in prepared.records:\n\t\tif int(record.after.max_health)>int(record.before.max_health) and engine.MasterRealities._titanic_matches(state.player.board,record.target): return "titanic_guardian_recruit_hand_murloc_projection_partial"\n\t\trecord.target.clear();record.target.merge(record.after.duplicate(true),true);state.operations+=1')
a='\t\tvar cursor: Dictionary={"player":{"board":state.board,"hand":state.native_hand},"operations":0}'
rep(p,a,'\t\tif transfer.records.any(func(record):return int(record.after.max_health)>int(record.before.max_health) and engine.MasterRealities._titanic_matches(state.board,record.target)): return "titanic_guardian_accepted_transfer_projection_partial"\n'+a)
a='\tfor record in prepared.records:\n\t\trecord.target.clear();record.target.merge(record.after.duplicate(true),true)\n\t\tvar event: Dictionary=payload(prepared,record);event.event="hand_buff"'
rep(p,a,'\tfor record in prepared.records:\n\t\tif int(record.after.max_health)>int(record.before.max_health) and engine.MasterRealities._titanic_matches(state.board,record.target): return "titanic_guardian_accepted_hand_murloc_projection_partial"\n\t\trecord.target.clear();record.target.merge(record.after.duplicate(true),true)\n\t\tvar event: Dictionary=payload(prepared,record);event.event="hand_buff"')
# Explicit specialized producer preflights before their first actual write.
p='core/avenge_hand_board_host.gd';a='\tvar source: Dictionary=entry.unit;var side: int=int(entry.side)';rep(p,a,a+'\n\tif int(effect.get("health",0))>0 and engine._boards[side].any(func(unit):return engine.MasterRealities.Titanic.claimed(unit) and Gains.active(unit)): engine._fail("titanic_guardian_avenge_hand_board_group_projection_partial");return false')
p='core/bulk_hand_summon_sources.gd';a='\tif prepared.status!="ready": return true';rep(p,a,a+'\n\tif int(prepared.after.max_health)>int(prepared.before.max_health) and engine.MasterRealities._titanic_matches(engine._boards[side],selected): engine._fail("titanic_guardian_buff_then_hand_summon_projection_partial");return false')
p='core/trigore_hand_retention.gd';a='\tif not str(projected.error).is_empty(): return projected';rep(p,a,a+'\n\tif int(projected.after.max_health)>int(card.max_health) and engine.MasterRealities._titanic_matches(engine._boards[side],card): return {"error":"titanic_guardian_hand_origin_permanence_partial"}')
p='core/timewarped_expeditioner_host.gd';a='\t\t\t\tif not gain.ok: return gain';rep(p,a,a+'\n\t\t\t\tif gain.records.any(func(record):return int(record.after.max_health)>int(record.before.max_health) and engine.MasterRealities._titanic_matches(boards[side],record.target)): return _fail("titanic_guardian_deathwing_delayed_hand_projection_partial")')
p='core/combat_accepted_hand_stats.gd';a='\tif int(target.max_health)>int(hand_murloc_before.max_health) and engine.MasterRealities._ragescale_matches(state.board,target): return "ragescale_accepted_card_native_projection_partial"';rep(p,a,a+'\n\tif int(target.max_health)>int(hand_murloc_before.max_health) and engine.MasterRealities._titanic_matches(state.board,target): return "titanic_guardian_accepted_board_projection_partial"')
a='\t\tif int(changed.max_health)>int(hand_murloc_reaction_before.max_health) and engine.MasterRealities._ragescale_matches(state.board,changed): return "ragescale_accepted_reaction_native_projection_partial"';rep(p,a,a+'\n\t\tif int(changed.max_health)>int(hand_murloc_reaction_before.max_health) and engine.MasterRealities._titanic_matches(state.board,changed): return "titanic_guardian_accepted_reaction_projection_partial"')
p='tools/build_effect_catalog.py';t=read(p);start=t.index('from ragescale_gain_patterns import ');end=t.index('\nfrom ',start);block=t[start:end];put(p,t[:start]+block.replace('ragescale_gain','titanic_guardian').replace('RAGESCALE_GAIN','TITANIC_GUARDIAN')+'\n'+t[start:])
p='data/catalog.json';catalog=json.loads(read(p));catalog['cards']=[r for r in catalog['cards'] if r['id'] not in IDS]+list(expected.values());put(p,json.dumps(catalog,ensure_ascii=False,indent=2)+'\n')
p='core/bulk_global_card_stats.gd';rep(p,'extends RefCounted\n','extends RefCounted\nconst TitanicSources=preload("res://core/titanic_guardian_sources.gd")\n')
a='\t\t\tupdates.append({"unit":unit,"before":unit.duplicate(true),"after":plan.unit,"zone":zone,"reference":reference})'
b='\t\t\tif zone=="hand" and not is_same(unit,inserted) and int(plan.unit.get("max_health",0))>int(unit.get("max_health",0)) and player.get("board",[]).any(func(holder):return TitanicSources.claimed(holder) and int(holder.get("health",0))>0 and not holder.get("_pending_destroy",false) and not holder.get("silenced",false) and not holder.get("abilities_disabled",false)): return {"ok":false,"error":"titanic_guardian_dynamic_hand_owner_layer_partial"}\n'+a
rep(p,a,b)
# Prepared for the parent's source-only admission, never executed here.
admission=(ROOT/'research/ragescale_gain_native_recovery/check_admission.gd').read_text().replace('ragescale_gain','titanic_guardian')
save(R+'check_admission.gd',admission)
p='core/knitted_sunfin_host.gd';a='\tvar before: Dictionary={"attack":selected.attack,"health":selected.health,"max_health":selected.max_health}'
rep(p,a,'\tif int(owned.effect.health)>0 and engine.MasterRealities._titanic_matches(engine._boards[side],selected): engine._fail("titanic_guardian_temporary_hand_summon_projection_partial");return false\n'+a)
p='core/efficient_engineer_host.gd'
a='static func _hand_buff_shadow(engine,state: Dictionary,target: Dictionary,attack: int,health: int) -> String:\n'
rep(p,a,a+'\tvar titanic_before: Dictionary=target.duplicate(true)\n')
a='\t# Real Game._buff finds no board owner for a hand body: no board\n\t# AttackGain/Threshold, no hand-added event. Offboard threshold stays partial.'
b='\tissue=engine.MasterRealities.project_gain(engine,state,target,titanic_before)\n\tif not issue.is_empty(): return issue\n\t# No hand-added event or board AttackGain on the hand subject. The native\n\t# board Guardian may independently observe this real hand Health grant.'
rep(p,a,b)
p='core/rivendare_portrait_host.gd';a='\tif target.health!=target.max_health: return "rivendare_portrait_wounded_health_semantics_partial"'
rep(p,a,a+'\n\tif engine.MasterRealities._titanic_matches(engine._boards[side],target): return "titanic_guardian_rivendare_cumulative_scalar_projection_partial"')
# Fingerprint every changed implementation boundary used by this family.
paths=list(dict.fromkeys(paths+[p for p in changes if p.endswith(('.gd','.py'))]))
source=re.sub(r'^const RUNTIME_PATHS: Array=.*$',lambda m:'const RUNTIME_PATHS: Array='+json.dumps(paths,ensure_ascii=False,separators=(',',':')),source,flags=re.M)
save('core/titanic_guardian_sources.gd',source)
# Serialize candidate-only before/after artifacts. Never touch live sources.
manifest=[];patch=[]
for p,(before,after) in changes.items():
 save(p,after);manifest.append({'path':p,'before_sha256':sha(before),'after_sha256':sha(after),'candidate':str((C/p).relative_to(ROOT))});patch.extend(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='a/'+p,tofile='b/'+p))
(OUT/'shared_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');(OUT/'shared_changes.patch').write_text(''.join(patch))
new={str(p.relative_to(C)):sha(p.read_bytes()) for p in sorted(C.rglob('*')) if p.is_file() and str(p.relative_to(C)) not in changes}
(OUT/'new_files_sha256.json').write_text(json.dumps(new,indent=2)+'\n')
for p in C.rglob('*.py'):ast.parse(p.read_text(),filename=str(p))
for p in (C/R/'native').glob('*.xml'):ET.fromstring(p.read_text())
print('Candidate shared paths',len(changes),'new paths',len(new))
