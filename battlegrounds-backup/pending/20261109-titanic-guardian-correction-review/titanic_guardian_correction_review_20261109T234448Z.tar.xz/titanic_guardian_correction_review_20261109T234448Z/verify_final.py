"""Read-only source and result checks for this new correction review."""
from pathlib import Path
import ast,hashlib,json,resource,collections
resource.setrlimit(resource.RLIMIT_AS,(128*1024**2,128*1024**2))
H=Path(__file__).resolve().parent;W=H.parent;R=W/'historical_tools_batch14_20261109T191857Z/runtime';OLD=W/'titanic_guardian_readonly_probe_20261109T232356Z'
def read(p):return json.loads(p.read_text())
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
pins=read(H/'INPUT_PINS.json');baseline=read(R.parent/'SOURCE_MAP.json')
for rel,pin in pins.items():
 assert pin==baseline[rel]
 for p in [R/rel,H/'original_inputs'/rel]:assert sha(p)==pin['sha256'] and p.stat().st_size==pin['bytes'],str(p)
 if rel.startswith('core/'):assert sha(H/'gd_minimal'/rel)==pin['sha256']
original=H/'original_inputs/research/titanic_guardian_native_recovery/candidates/tools/titanic_guardian_patterns.py';candidate=H/'candidate/tools/titanic_guardian_patterns.py'
assert sha(original)=='fc3dba9438f89860267b8db034b88415ba8d78ff6f905ba556beee29db248a29';assert sha(candidate)=='a2ce74f710d473b652ecd4faebaad3af848b345ba11fc8b665be43266a77827b'
def constants(p):return {n.targets[0].id:ast.literal_eval(n.value) for n in ast.parse(p.read_text()).body if isinstance(n,ast.Assign)}
assert constants(original)==constants(candidate)
assert candidate.read_bytes().startswith(original.read_bytes().split(b'def compile_card(')[0])
source_checks=read(OLD/'static_contract/FINAL_RECHECK.json')['checks']
for item in source_checks:assert sha(W/item['path'])==item['expected_sha256'],item['path']
(H/'SOURCE_RECHECK.json').write_text(json.dumps({'all_match':True,'checks':source_checks},indent=2)+'\n')
cases=read(H/'CASES.json');py=read(H/'PYTHON_REPORT.json');gd=read(H/'GODOT_first.json');ids=constants(original)['SOURCE_IDS'];assert len(cases)==py['case_count']==gd['case_count']==3622
assert gd==read(H/'GODOT_repeat.json') and not gd['failures'];assert cases[:218]==read(OLD/'CASES.json')
assert sum(x['candidate_accept'] for x in py['results'])==362
assert sum(x['candidate_disagreement'] for x in gd['counts'].values())==0
assert sum(x['candidate_exception'] for x in gd['counts'].values())==0
assert sum(x['candidate_accept_compiled_closure_reject'] for x in gd['counts'].values())==0
assert sum(x['candidate_hook_exception'] for x in gd['counts'].values())==16
assert all(x['input_unchanged'] for x in py['results'])
unique=set();counts=collections.Counter();baseline_fixed=0;old_gd=read(OLD/'GODOT_first.json')
for i,(c,p,g) in enumerate(zip(cases,py['results'],gd['results'])):
 assert c['label']==p['label']==g['label'] and p['candidate_accept']==g['strict_ingress_accept']
 if i<218:assert g['strict_ingress_accept']==old_gd['results'][i]['strict_ingress_accept']
 if p['original_accept'] and not p['candidate_accept']:
  counts[c['regime']]+=1
  if i<218:baseline_fixed+=1
  if c['regime'] in ['coupled','companion']:
   affected=c['identity'] if c['regime']=='coupled' else next(j for j in ids if j!=c['identity']);unique.add((affected,tuple(c['path']),c['op']))
assert baseline_fixed==108 and len(unique)==30 and counts['coupled']==counts['companion']==30 and counts['detached']==1048
assert all(x['original_accept']==p['original_accept'] for x,p in zip(read(OLD/'PYTHON_REPORT.json')['results'],py['results'][:218]))
for n in ['first','repeat']:
 for stream in ['stdout','stderr']:
  text=(H/f'GODOT_{n}.{stream}.log').read_text();assert 'SCRIPT ERROR' not in text and 'ERROR:' not in text
for rel,pin in read(H/'REPLAY_INPUTS.json').items():assert sha(H/rel)==pin['sha256'] and (H/rel).stat().st_size==pin['bytes']
replay=read(H/'PORTABLE_REPLAY_RESULT.json');D=Path(replay['destination']);assert replay['copied_files']==34 and not replay['source_runtime_needed']
assert sha(D/'GODOT_first.json')==sha(H/'GODOT_first.json') and sha(D/'GODOT_repeat.json')==sha(H/'GODOT_repeat.json')
a=read(D/'PYTHON_REPORT.json');b=read(H/'PYTHON_REPORT.json');a.pop('max_rss_kib');b.pop('max_rss_kib');assert a==b
oldverify=read(OLD/'FINAL_VERIFICATION.json');oldpins=oldverify['old_archives_unchanged'];oldpins[OLD.name+'.tar.xz']='b7ea490684bb5b9ef1db93f4ad0c8c5d0c46c8da431ac4e8007fe5c28ecc75ca'
for rel,digest in oldpins.items():assert sha(W/rel)==digest
assert sha(H/'history'/OLD.with_suffix('.tar.xz').name)==oldpins[OLD.name+'.tar.xz']
remaining=read(W/'historical_tools_batch15_20261109T195018Z/REMAINING_SCOPE.json')['remaining_targets'];assert len(remaining)==345 and all(not (R/n).exists() for n in remaining)
assert not (R/'evidence/portable_legacy/CardDefs.Bacon_latest.xml').exists()
result={'status':'PASS_FIXED_RAW_CANDIDATE_REVIEW_INSTALLATION_DEFERRED','new_correction_not_historical_restoration':True,'candidate_sha256':sha(candidate),'candidate_bytes':candidate.stat().st_size,'original_sha256':sha(original),'original_inputs_unchanged':len(pins),'current_source_and_data_rechecks':len(source_checks),'original_constant_assignments_and_prefix_unchanged':True,'cases':3622,'candidate_positive_cases':362,'candidate_direct_exceptions':0,'candidate_GD_diagnostic_disagreements':0,'candidate_accept_closure_rejects':0,'preserved_hook_invalid_root_exceptions':16,'legacy_218_fixed_rejections':baseline_fixed,'legacy_218_preserved_positive_cases':sum(p['candidate_accept'] for p in py['results'][:218]),'differential_rejections_by_regime':dict(counts),'coupled_companion_fixed_calls':60,'unique_fixed_mapping_mutations':len(unique),'bool_to_number_unique_mappings':28,'number_one_to_bool_unique_mappings':2,'separate_structure_probes':len(gd['structural_probes']),'separate_effect_probes':len(gd['effect_probes']),'portable_replay_files':34,'remaining_missing_tools':len(remaining),'XML_candidate_not_installed':True,'prior_archives_unchanged':oldpins,'full_driver_Catalog_Game_host_or_saves_run':False,'candidate_installed':False,'max_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
(H/'FINAL_VERIFICATION.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps(result,ensure_ascii=False,indent=2))
