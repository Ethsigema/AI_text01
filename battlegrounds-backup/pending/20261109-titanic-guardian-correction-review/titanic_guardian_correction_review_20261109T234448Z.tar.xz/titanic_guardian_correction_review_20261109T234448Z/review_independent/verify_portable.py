from pathlib import Path
import hashlib,json,resource
resource.setrlimit(resource.RLIMIT_AS,(128*1024**2,128*1024**2))
D=Path(__file__).resolve().parent;H=D.parent;P=H.parent/'titanic_guardian_correction_replay_20261109T235400Z'
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(65536),b''):h.update(b)
 return h.hexdigest()
manifest=json.loads((H/'REPLAY_INPUTS.json').read_text());verified=[]
for rel,pin in manifest.items():
 assert sha(H/rel)==sha(P/rel)==pin['sha256']
 assert (H/rel).stat().st_size==(P/rel).stat().st_size==pin['bytes']
 verified.append(rel)
for rel in ['GODOT_first.json','GODOT_repeat.json','CANDIDATE_OUTPUTS.json','DRIVER_EXACT_FRAGMENTS.py']:assert (H/rel).read_bytes()==(P/rel).read_bytes()
a=json.loads((H/'PYTHON_REPORT.json').read_text());b=json.loads((P/'PYTHON_REPORT.json').read_text());a.pop('max_rss_kib');b.pop('max_rss_kib');assert a==b
for target,source in [('PORTABLE_REPLAY_RESULT.json','REPLAY_RESULT.json'),('PORTABLE_GODOT_RUNS.json','GODOT_RUNS.json')]:assert (H/target).read_bytes()==(P/source).read_bytes()
for name in ['GODOT_first.stderr.log','GODOT_repeat.stderr.log','GODOT_first.stdout.log','GODOT_repeat.stdout.log']:
 s=(P/name).read_text();assert 'SCRIPT ERROR' not in s and 'ERROR:' not in s
runs=json.loads((P/'GODOT_RUNS.json').read_text());assert len(runs)==2 and all(r['exit_code']==0 and r['stopped'] is None for r in runs)
old=H/'harness_diagnostics/attempt1/gate_before_guard_order.gd';new=H/'gd_minimal/gate.gd'
assert old.read_text().replace('not row is Dictionary or row.get("id")!=identity or not Source.raw_source_error(row).is_empty()','not row is Dictionary or not Source.raw_source_error(row).is_empty() or row.get("id")!=identity')==new.read_text()
assert 'SCRIPT ERROR' in (H/'harness_diagnostics/attempt1/GODOT_first.stderr.log').read_text()
patch=json.loads((H/'PATCH_ROUNDTRIP.json').read_text());assert len(patch['checks'])==3 and all(x['exit_code']==0 and x['exact_expected_bytes'] for x in patch['checks'])
result={'status':'PASS_STORED_PORTABLE_REPLAY_AND_DIAGNOSTIC_SEPARATION','files_verified':len(verified),'GD_reports_exact':True,'Python_semantics_exact_except_resource_peak':True,'actual_replay_executed_by_reviewer':False,'failed_GD_attempt_separately_retained':True,'diagnostic_wrapper_only_one_boolean_operand_order_changed':True,'patch_roundtrip_record_consistent':True,'reviewed_files_sha256':{str(p.relative_to(H)):sha(p) for p in [H/'REPLAY_INPUTS.json',H/'PORTABLE_REPLAY_RESULT.json',H/'PORTABLE_GODOT_RUNS.json',H/'PATCH_ROUNDTRIP.json',old,H/'harness_diagnostics/README.md']},'max_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
(D/'PORTABLE_REVIEW.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps(result,ensure_ascii=False,indent=2))
