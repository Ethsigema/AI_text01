from pathlib import Path
import hashlib,json,resource
resource.setrlimit(resource.RLIMIT_AS,(128*1024**2,128*1024**2))
D=Path(__file__).resolve().parent;H=D.parent;W=H.parent
R=W/'historical_tools_batch14_20261109T191857Z/runtime'
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(65536),b''):h.update(b)
 return h.hexdigest()
src=json.loads((H/'SOURCE_RECHECK.json').read_text());assert src['all_match'] and len(src['checks'])==34
for x in src['checks']:assert sha(W/x['path'])==x['expected_sha256']==x['actual_sha256']
f=json.loads((H/'FINAL_VERIFICATION.json').read_text());a=json.loads((D/'REVIEW.json').read_text())
for rel,pin in f['prior_archives_unchanged'].items():assert sha(W/rel)==pin
assert f['candidate_sha256']==a['candidate_sha256'] and f['original_sha256']==a['original_sha256']
assert f['cases']==a['case_count']==3622 and f['candidate_positive_cases']==sum(x['candidate_accepts'] for x in a['counts'].values())==362
assert f['unique_fixed_mapping_mutations']==a['unique_bad_mapping_variants_original_accepted']==30
assert f['preserved_hook_invalid_root_exceptions']==sum(x['hook_exceptions'] for x in a['counts'].values())==16
assert not f['candidate_installed'] and not f['full_driver_Catalog_Game_host_or_saves_run']
assert not (R/'tools/titanic_guardian_patterns.py').exists()
text=(H/'REPORT.md').read_text()
for phrase in ['不是历史原件恢复','尚未安装','不属于本次兼容证明域','不是全输入空间','30种唯一 mapping','16个非法根','正式结论只使用后续没有错误日志的运行','当前完整驱动']:
 assert phrase in text,phrase
result={'final_report_scope_and_counts_consistent':True,'current_source_data_pins_rehashed':34,'prior_archives_rehashed':len(f['prior_archives_unchanged']),'target_runtime_tool_still_absent':True,'missing_tool_count_345_not_independently_recounted_here':True,'reviewed_hashes':{p:sha(H/p) for p in ['REPORT.md','FINAL_VERIFICATION.json','SOURCE_RECHECK.json']},'max_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
(D/'FINAL_TEXT_REVIEW.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps(result,ensure_ascii=False,indent=2))
