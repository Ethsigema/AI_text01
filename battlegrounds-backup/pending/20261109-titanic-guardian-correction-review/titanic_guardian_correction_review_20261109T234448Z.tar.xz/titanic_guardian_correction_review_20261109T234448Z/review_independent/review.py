from pathlib import Path
import ast, collections, copy, difflib, gc, hashlib, json, math, resource, sys, types
resource.setrlimit(resource.RLIMIT_AS,(128*1024**2,128*1024**2))
resource.setrlimit(resource.RLIMIT_CPU,(45,45))
sys.dont_write_bytecode=True
D=Path(__file__).resolve().parent; H=D.parent; W=H.parent
R=W/'historical_tools_batch14_20261109T191857Z/runtime'; OLD=W/'titanic_guardian_readonly_probe_20261109T232356Z'
F='research/titanic_guardian_native_recovery/'
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(65536),b''):h.update(b)
 return h.hexdigest()
def exact(v):
 t=type(v)
 if t is dict:return ('dict',tuple((exact(k),exact(x)) for k,x in v.items()))
 if t in (list,tuple):return (t.__name__,tuple(map(exact,v)))
 if t is float:return ('float',v.hex())
 return (t.__name__,v)
def unordered_exact(v):
 if type(v) is dict:return ('dict',tuple(sorted((k,unordered_exact(x)) for k,x in v.items())))
 if type(v) in (list,tuple):return (type(v).__name__,tuple(map(unordered_exact,v)))
 if type(v) is float:return ('float',v.hex())
 return (type(v).__name__,v)
def shape(v):
 # Independent fixed-RAW oracle, not the candidate recursive comparator.
 t=type(v)
 if t is dict:
  if any(type(k) is not str for k in v):return ('invalid-keys',)
  return ('object',tuple(sorted((k,shape(x)) for k,x in v.items())))
 if t is list:return ('array',tuple(map(shape,v)))
 if t is int:return ('number',v)
 if t is float:return ('number',int(v)) if math.isfinite(v) and v.is_integer() else ('invalid-raw-number',v.hex())
 return (t.__name__,v)
def graph(v):
 if type(v) is dict:return ('dict',id(v),tuple((exact(k),graph(x)) for k,x in v.items()))
 if type(v) is list:return ('list',id(v),tuple(map(graph,v)))
 return exact(v)
def module(path):
 s=path.read_text();tree=ast.parse(s)
 assert [n.module for n in tree.body if isinstance(n,ast.ImportFrom)]==['copy']
 assert not any(isinstance(n,ast.Import) for n in ast.walk(tree))
 n={};exec(compile(tree,str(path),'exec'),n);return n
op=H/'original_inputs'/F/'candidates/tools/titanic_guardian_patterns.py';cp=H/'candidate/tools/titanic_guardian_patterns.py'
o=module(op);c=module(cp);IDS=o['SOURCE_IDS'];RAW=o['RAW'];EXPECTED=o['EXPECTED']
assert sha(op)=='fc3dba9438f89860267b8db034b88415ba8d78ff6f905ba556beee29db248a29'
assert sha(cp)=='a2ce74f710d473b652ecd4faebaad3af848b345ba11fc8b665be43266a77827b'
assert op.read_bytes().split(b'def compile_card(')[0]==cp.read_bytes().split(b'# NEW CORRECTION')[0]
for k in ['SOURCE_IDS','RAW','EXPECTED']:assert unordered_exact(o[k])==unordered_exact(c[k])
patch=''.join(difflib.unified_diff(op.read_text().splitlines(True),cp.read_text().splitlines(True),fromfile='a/tools/titanic_guardian_patterns.py',tofile='b/tools/titanic_guardian_patterns.py'))
assert patch==(H/'CANDIDATE.patch').read_text()
pins=json.loads((H/'INPUT_PINS.json').read_text());checked=[]
for rel,pin in pins.items():
 assert sha(H/'original_inputs'/rel)==sha(R/rel)==pin['sha256']
 assert (H/'original_inputs'/rel).stat().st_size==(R/rel).stat().st_size==pin['bytes']
 checked.append(rel)
for p in (H/'gd_minimal/core').glob('*.gd'):assert sha(p)==sha(R/'core'/p.name)
assert sha(H/'history'/OLD.with_suffix('.tar.xz').name)==sha(OLD.with_suffix('.tar.xz'))=='b7ea490684bb5b9ef1db93f4ad0c8c5d0c46c8da431ac4e8007fe5c28ecc75ca'
gdconst=json.loads((H/'GD_CONSTANTS.json').read_text())
assert unordered_exact(gdconst['RAW'])==unordered_exact(RAW) and unordered_exact(gdconst['EXPECTED'])==unordered_exact(EXPECTED)
# Exact source extraction, not execution of the full compiler.
driver=(H/'original_inputs'/F/'candidates/tools/build_effect_catalog.py').read_text();tree=ast.parse(driver)
emit=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='emit')
hook=next(n for n in tree.body if isinstance(n,ast.For) and ast.unparse(n.iter)=='sorted(TITANIC_GUARDIAN_IDS)')
at=tree.body.index(hook);nodes=[emit]+tree.body[at:at+3]
assert '\n\n'.join(ast.get_source_segment(driver,n) for n in nodes)+'\n'==(H/'DRIVER_EXACT_FRAGMENTS.py').read_text()
assert [type(n).__name__ for n in nodes]==['FunctionDef','For','Assign','Expr']
hookcode=compile(ast.Module(body=nodes,type_ignores=[]),'independently_extracted_original_four_nodes','exec')
del driver,tree,emit,hook,nodes;gc.collect()
# Independent mutations, then cross-check the supplied Python mutator.
m=module(H/'mutations.py');m['IDS']=IDS;m['original']=types.SimpleNamespace(EXPECTED=EXPECTED)
def float_tree(v):
 if type(v) is int:return float(v)
 if type(v) is list:return list(map(float_tree,v))
 if type(v) is dict:return {k:float_tree(x) for k,x in v.items()}
 return v
def alter(input_value,case):
 value=copy.deepcopy(input_value);op=case['op'];path=case['path']
 if op=='canonical':return value
 if op=='invalid_root':return copy.deepcopy(case['value'])
 if op=='all_numbers_float':return float_tree(value)
 if op in ('merged_card','custom_card'):
  value.update(copy.deepcopy(EXPECTED[value['id']]))
  if op=='custom_card':value.update(source_shop_fields={'tier':3,'cost':None,'pool_supported':False},tier=4)
  return value
 if op=='swap_rows':return dict(zip(IDS,[value[IDS[1]],value[IDS[0]]]))
 if op.startswith('duplicate_'):return {i:copy.deepcopy(value[IDS[int(op=='duplicate_golden')]]) for i in IDS}
 if op=='id_only':return {'id':value['id']}
 if op=='extra_unrelated':value['not-a-source']={'id':'not-a-source'};return value
 if op=='invalid_member':value[path[0]]=None;return value
 parent=value
 for key in path[:-1]:parent=parent[key]
 prior=parent[path[-1]] if path else value
 if op=='delete':del parent[path[-1]];return value
 fn={'replace_value':lambda:copy.deepcopy(case['value']),'id_swap':lambda:IDS[1-IDS.index(prior)],'replace_null':lambda:None,'replace_array':list,'replace_dict':dict,'null_to_zero':lambda:0,'reverse_dict':lambda:{k:prior[k] for k in reversed(prior)},'bool_to_int':lambda:int(prior),'bool_to_float':lambda:float(prior),'toggle_bool':lambda:not prior,'numeric_float':lambda:float(prior),'numeric_int':lambda:int(prior),'number_delta':lambda:prior+1,'number_string':lambda:str(prior),'number_bool':lambda:bool(prior),'change_string':lambda:prior+'__changed__','null_to_false':lambda:False,'extra_key':lambda:{**prior,'__extra__':True},'append_item':lambda:prior+['__extra__'],'reverse_list':lambda:prior[::-1],'nan':lambda:float('nan'),'pos_inf':lambda:float('inf'),'neg_inf':lambda:float('-inf')}
 changed=fn[op]()
 if path:parent[path[-1]]=changed;return value
 return changed
cases=json.loads((H/'CASES.json').read_text());baseline=json.loads((OLD/'CASES.json').read_text())
assert cases[:218]==baseline==json.loads((H/'BASELINE_CASES.json').read_text())
assert len(cases)==3622
signatures={(x['regime'],x['identity'],tuple(x['path']),x['op'],json.dumps(x.get('value'),sort_keys=True)) for x in cases}
assert len(signatures)==len(cases)
def walk(v,p=()):
 yield p,v
 if type(v) is dict:
  for k,x in v.items():yield from walk(x,p+(k,))
 if type(v) is list:
  for k,x in enumerate(v):yield from walk(x,p+(k,))
coverage=collections.Counter();node_types={};maximum_number=0
for target,row in RAW.items():
 types_count=collections.Counter()
 for path,value in walk(row):
  t=type(value);types_count[t.__name__]+=1
  if t is int:
   maximum_number=max(maximum_number,abs(value));assert abs(value)<2**53
   ops=['numeric_float','number_bool','number_delta','number_string','nan','pos_inf','neg_inf']
  elif t is bool:ops=['toggle_bool','bool_to_int','bool_to_float']
  elif t is str:ops=['change_string']
  elif t is type(None):ops=['null_to_false','null_to_zero']
  elif t is dict:ops=['extra_key','replace_array','replace_null','reverse_dict']
  elif t is list:ops=['append_item','replace_dict','replace_null']+(['reverse_list'] if len(value)>1 else [])
  for regime in ['detached','coupled','companion']:
   caller=IDS[1-IDS.index(target)] if regime=='companion' else target
   for op in ops:
    assert (regime,caller,path,op,'null') in signatures,(regime,caller,path,op)
    coverage[op]+=1
 node_types[target]=dict(types_count)
# Stored real-GD results are used only after source and log validation.
assert (H/'GODOT_first.json').read_bytes()==(H/'GODOT_repeat.json').read_bytes()
gdr=json.loads((H/'GODOT_first.json').read_text());pyr=json.loads((H/'PYTHON_REPORT.json').read_text())
assert gdr['case_count']==pyr['case_count']==len(cases)
assert gdr['failures']==[]
for name in ['GODOT_first.stderr.log','GODOT_repeat.stderr.log','GODOT_first.stdout.log','GODOT_repeat.stdout.log']:
 text=(H/name).read_text();assert 'SCRIPT ERROR' not in text and 'ERROR:' not in text
runs=json.loads((H/'GODOT_RUNS.json').read_text());assert len(runs)==2 and all(x['exit_code']==0 and x['stopped'] is None for x in runs)
raw_shapes={i:shape(RAW[i]) for i in IDS}
def rawok(v):return type(v) is dict and type(v.get('id')) is str and v['id'] in IDS and shape(v)==raw_shapes[v['id']]
def ingress(card,cards):return type(cards) is dict and rawok(card) and all(rawok(cards.get(i)) and cards[i]['id']==i for i in IDS)
counts=collections.defaultdict(collections.Counter);details=[];bad_maps=set();restored_old_diff=0
constant_before=exact([c['RAW'],c['EXPECTED'],c['SOURCE_IDS']])
for index,case in enumerate(cases):
 regime=case['regime'];identity=case['identity'];cards=copy.deepcopy(RAW);card=copy.deepcopy(RAW[identity])
 if regime=='mapping_root':base=cards
 elif regime=='companion':base=cards[IDS[1-IDS.index(identity)]]
 elif regime=='coupled':base=cards[identity]
 else:base=card
 changed=alter(base,case);assert exact(changed)==exact(m['mutate'](copy.deepcopy(base),case))
 if regime=='mapping_root':cards=changed
 elif regime=='companion':cards[IDS[1-IDS.index(identity)]]=changed;card=cards[identity]
 elif regime=='coupled':cards[identity]=changed;card=cards[identity]
 else:card=changed
 before=graph([card,cards]); expected=ingress(card,cards)
 # Snapshot each actual input separately: outer temporary list identity is irrelevant.
 before=(graph(card),graph(cards))
 output=c['compile_card'](card,cards)
 assert (graph(card),graph(cards))==before
 assert (output is not None)==expected
 if output is not None:assert unordered_exact(output)==unordered_exact(EXPECTED[card['id']])
 olderror=None
 try:oldout=o['compile_card'](card,cards)
 except Exception as e:oldout=None;olderror=type(e).__name__
 pr=pyr['results'][index];gr=gdr['results'][index]
 assert pr['label']==gr['label']==case['label']
 assert pr['candidate_error'] is None and pr['candidate_accept']==expected==gr['strict_ingress_accept']==gr['candidate_accept']
 assert gr['actual_supplied_card_raw_gate_accept']==rawok(card)
 assert (oldout is not None)==pr['original_accept']==gr['original_accept'] and olderror==pr['original_error']
 if index<218 and oldout is not None and not expected:restored_old_diff+=1
 calls=[];keep={'unrelated':True};out={i:{'stale':True} for i in IDS};out['unrelated']=keep
 def intercepted(row,mapping):
  calls.append((frame['identity'],row is mapping.get(frame['identity'])))
  return c['compile_card'](row,mapping)
 frame={'cards':cards,'out':out,'ordered_ids':[IDS[1],'unrelated',IDS[0]],'TITANIC_GUARDIAN_IDS':IDS,'compile_titanic_guardian':intercepted,'hashlib':hashlib}
 hookerror=None
 try:exec(hookcode,frame)
 except Exception as e:hookerror=type(e).__name__
 assert (graph(card),graph(cards))==before and out['unrelated'] is keep
 assert hookerror==pr['candidate_hook_error']==gr['candidate_hook_error']
 expected_ids=[i for i in IDS if ingress(cards.get(i),cards)] if type(cards) is dict else []
 assert expected_ids==gr['candidate_hook_expected_ids']
 if hookerror is None:
  actual_ids=sorted(i for i in IDS if i in out)
  assert actual_ids==expected_ids==pr['candidate_hook_accepted_ids']
  assert frame['ordered_ids']==['unrelated']+expected_ids
  assert all(same_object for key,same_object in calls)
  for i in expected_ids:assert unordered_exact(out[i])==unordered_exact(EXPECTED[i])
 else:
  assert type(cards) is not dict and hookerror=='AttributeError' and not calls
  assert IDS[0] not in out and IDS[1] in out # precise interrupted stale-output boundary
 if expected:
  assert gr['compiled_closure_error']==''
  merged={i:{**cards[i],**EXPECTED[i]} for i in IDS}
  assert all(shape(merged[i])==shape({**RAW[i],**EXPECTED[i]}) for i in IDS)
 else:assert gr['compiled_closure_error'] is None
 z=counts[regime];z['cases']+=1;z['candidate_accepts']+=expected;z['original_accepts']+=oldout is not None;z['original_exceptions']+=olderror is not None;z['hook_exceptions']+=hookerror is not None;z['disagreements']+=0
 if regime in ['coupled','companion'] and oldout is not None and not expected:bad_maps.add(repr(unordered_exact(cards)))
 details.append({'label':case['label'],'mutation_reproduced':True,'candidate_equals_independent_oracle':True,'stored_real_gd_matches':True,'exact_hook_reproduced':True,'typed_input_graph_unchanged':True})
assert restored_old_diff==108
assert sum(x['candidate_accepts'] for x in counts.values())==362
assert constant_before==exact([c['RAW'],c['EXPECTED'],c['SOURCE_IDS']])
for i in IDS:
 a=c['compile_card'](copy.deepcopy(RAW[i]),copy.deepcopy(RAW));b=c['compile_card'](copy.deepcopy(RAW[i]),copy.deepcopy(RAW))
 assert a is not b and a['effects'] is not b['effects'] and a['conditional_support'] is not b['conditional_support']
 a['effects'][0]['mutated']=True;a['conditional_support']['rule']='mutated'
 assert unordered_exact(b)==unordered_exact(EXPECTED[i])==unordered_exact(c['EXPECTED'][i])
 assert b['default_pool'] is False and b['pool_supported'] is False and b['implementation_status']=='partial_implementation_supported_pending_unified_validation'
assert len(gdr['structural_probes'])==13 and [x['case'] for x in gdr['structural_probes'] if x['accepted']]==['canonical','both_pool_blockers','valid_custom']
assert len(gdr['effect_probes'])==12 and all(x['accepted']==(x['op'] in ['canonical','float_equal']) for x in gdr['effect_probes'])
# Typed Python subclasses are outside the stated domain; independent smoke checks only.
class SubDict(dict):pass
class SubInt(int):pass
class SubStr(str):pass
nonjson=[]
for label,card,cards in [('dict_subclass_card',SubDict(RAW[IDS[0]]),RAW),('dict_subclass_mapping',RAW[IDS[0]],SubDict(RAW)),('str_subclass_id',{**RAW[IDS[0]],'id':SubStr(IDS[0])},RAW),('int_subclass_field',{**RAW[IDS[0]],'tier':SubInt(3)},RAW)]:
 assert c['compile_card'](card,cards) is None;nonjson.append(label)
reviewed=['candidate/tools/titanic_guardian_patterns.py','CANDIDATE.patch','CANDIDATE_PROVENANCE.json','BASELINE_CASES.json','CASES.json','mutations.py','test_candidate.py','gd_minimal/gate.gd','GODOT_first.json','GODOT_repeat.json','GODOT_RUNS.json','PYTHON_REPORT.json','DRIVER_EXACT_FRAGMENTS.py','INPUT_PINS.json']
report={'status':'PASS_FIXED_RAW_CANDIDATE_LOCAL_CONTRACT_NOT_INSTALLATION_APPROVAL','candidate_sha256':sha(cp),'original_sha256':sha(H/'original_inputs'/F/'candidates/tools/titanic_guardian_patterns.py'),'prefix_and_constant_identity_verified':True,'patch_regenerated_exactly':True,'original_input_pins_verified':len(checked),'current_gd_source_byte_identical':3,'case_count':len(cases),'baseline_known_differences_now_rejected':restored_old_diff,'counts':{k:dict(v) for k,v in counts.items()},'node_types':node_types,'required_per_node_mutation_coverage':dict(coverage),'maximum_RAW_integer':maximum_number,'unique_bad_mapping_variants_original_accepted':len(bad_maps),'no_candidate_exceptions':True,'type_and_alias_preserving_input_graphs_unchanged':True,'fixed_deepcopy_outputs_and_flags_preserved':True,'actual_GD_reexecuted_by_reviewer':False,'two_stored_real_GD_reports_byte_identical_and_error_free':True,'full_compiler_Game_Catalog_or_save_executed':False,'out_of_domain_subclass_smokes':nonjson,'reviewed_sha256':{p:sha(H/p) for p in reviewed},'max_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'cases':details}
(D/'REVIEW.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in ['cases','reviewed_sha256']},ensure_ascii=False,indent=2))
