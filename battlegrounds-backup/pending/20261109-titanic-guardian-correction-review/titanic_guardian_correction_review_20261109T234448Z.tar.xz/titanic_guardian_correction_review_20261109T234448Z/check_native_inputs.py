from pathlib import Path
import ast,hashlib,json,resource,xml.etree.ElementTree as ET
resource.setrlimit(resource.RLIMIT_AS,(128*1024**2,128*1024**2))
H=Path(__file__).resolve().parent;P=H/'original_inputs/research/titanic_guardian_native_recovery';G=json.loads((H/'GD_CONSTANTS.json').read_text());M=json.loads((P/'native_source_manifest.json').read_text());Q=json.loads((P/'native_quantities.json').read_text());rows=[]
for identity in G['IDS']:
 b=(P/'native'/f'{identity}.xml').read_bytes();e=ET.fromstring(b);tags={t.get('name'):t for t in e.findall('Tag')};q=Q[identity];raw=G['RAW'][identity];record=M['entities'][identity]
 assert e.get('CardID')==identity and e.get('ID')==raw['dbf_id']==q['dbf_id']
 assert hashlib.sha256(b).hexdigest()==q['native_sha256']==record['native_sha256']
 for tag,field in [('ATK','attack'),('HEALTH','health'),('TECH_LEVEL','tier')]:assert int(tags[tag].get('value'))==raw[field]==q[field]
 assert int(tags['CARDRACE'].get('value'))==q['race']==18 and raw['tribes']==['元素']
 assert tags['CARDNAME'].findtext('zhCN')==raw['name']==q['name_zhCN']
 assert tags['CARDTEXT'].findtext('zhCN')==raw['text']==q['zhCN']
 assert tags['CARDTEXT'].findtext('enUS')==q['enUS']==record['enUS']
 expected_multiplier=1 if identity==G['IDS'][0] else 2
 assert q['operations']==1 and q['health_multiplier']==expected_multiplier and G['PROGRAMS'][identity][0]['health_multiplier']==expected_multiplier
 if expected_multiplier==2:assert 'twice that amount' in q['enUS']
 for tag,value in q['native_links'].items():assert int(tags[tag].get('value'))==value
 rows.append({'id':identity,'native_bytes':len(b),'native_sha256':hashlib.sha256(b).hexdigest(),'raw_body_and_text_match_native':True,'declared_multiplier':expected_multiplier,'declared_operations':q['operations'],'independent_golden_entity_used':identity==G['IDS'][1]})
report={'checks':rows,'source_manifest_commit_url':M['source_url'],'cached_input_sha256':M['cached_input_sha256'],'current_XML_fragments_verified_locally':True,'aggregate_XML_opened_or_downloaded':False,'native_source_fetch_repeated':False,'proof_files_read_by_compile_card':False,'proof_files_read_by_raw_source_error':False,'scope':'Static local source/provenance check. Original tool and GD gate compare embedded constants; source metadata pins are not claimed as a runtime proof gate. Source URL attribution is from preserved historical manifest, not independently fetched now.','max_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
(H/'NATIVE_INPUT_CHECKS.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps(report,ensure_ascii=False,indent=2))
