from pathlib import Path
import ast,hashlib,json,difflib,resource
resource.setrlimit(resource.RLIMIT_AS,(128*1024**2,128*1024**2))
H=Path(__file__).resolve().parent;OLD=H.parent/'titanic_guardian_readonly_probe_20261109T232356Z'
def sha(b):return hashlib.sha256(b).hexdigest()
files=json.loads((OLD/'FILES_SHA256.json').read_text())
copy=list(json.loads((OLD/'REPLAY_INPUTS.json').read_text()))
copy=[p for p in copy if p!='test_original.py' and p!='gd_minimal/gate.gd' and p!='CASES.json']
copy+=['DRIVER_EXACT_FRAGMENTS.py']
for rel in copy:
 b=(OLD/rel).read_bytes();assert sha(b)==files[rel]['sha256'];p=H/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
(H/'BASELINE_CASES.json').write_bytes((OLD/'CASES.json').read_bytes())
archive=OLD.with_suffix('.tar.xz');b=archive.read_bytes();assert sha(b)=='b7ea490684bb5b9ef1db93f4ad0c8c5d0c46c8da431ac4e8007fe5c28ecc75ca';(H/'history').mkdir(exist_ok=True);(H/'history'/archive.name).write_bytes(b)
rel='original_inputs/research/titanic_guardian_native_recovery/candidates/tools/titanic_guardian_patterns.py';original=(H/rel).read_text();assert sha(original.encode())=='fc3dba9438f89860267b8db034b88415ba8d78ff6f905ba556beee29db248a29'
replacement='''# NEW CORRECTION CANDIDATE, not historical-original recovery or release.
# Match the actual GD raw gate against these fixed RAW constants only.
# Supported input domain: plain acyclic JSON-like Python values.
def _same_raw_value(value, expected):
    value_type, expected_type = type(value), type(expected)
    if value_type in (int, float) and expected_type in (int, float):
        # RAW numbers are finite small integers. NaN/Inf cannot equal them.
        return value == expected
    if value_type is not expected_type:
        return False
    if value_type is dict:
        return len(value) == len(expected) and all(
            key in expected and _same_raw_value(item, expected[key])
            for key, item in value.items()
        )
    if value_type is list:
        return len(value) == len(expected) and all(
            _same_raw_value(item, reference)
            for item, reference in zip(value, expected)
        )
    return value == expected


def compile_card(card, cards):
    if type(card) is not dict or type(cards) is not dict:
        return None
    identity = card.get("id")
    if type(identity) is not str or identity not in SOURCE_IDS:
        return None
    if not _same_raw_value(card, RAW[identity]):
        return None
    for source_id in SOURCE_IDS:
        row = cards.get(source_id)
        if type(row) is not dict or row.get("id") != source_id:
            return None
        if not _same_raw_value(row, RAW[source_id]):
            return None
    return deepcopy(EXPECTED[identity])
'''
candidate=original[:original.index('def compile_card(')]+replacement
p=H/'candidate/tools/titanic_guardian_patterns.py';p.parent.mkdir(parents=True,exist_ok=True);p.write_text(candidate)
patch=''.join(difflib.unified_diff(original.splitlines(True),candidate.splitlines(True),fromfile='a/tools/titanic_guardian_patterns.py',tofile='b/tools/titanic_guardian_patterns.py'));(H/'CANDIDATE.patch').write_text(patch)
def constants(s):return {n.targets[0].id:ast.literal_eval(n.value) for n in ast.parse(s).body if isinstance(n,ast.Assign)}
a=constants(original);assert a==constants(candidate)
cases=json.loads((H/'BASELINE_CASES.json').read_text());seen={(c['regime'],c['identity'],tuple(c['path']),c['op'],json.dumps(c.get('value'),sort_keys=True)) for c in cases};node_counts={};numbers=[]
def add(regime,identity,path,op,**extra):
 key=(regime,identity,tuple(path),op,json.dumps(extra.get('value'),sort_keys=True))
 if key in seen:return
 seen.add(key);cases.append({'label':f'{len(cases):04d}:{regime}:{identity}:{op}:'+'.'.join(map(str,path)),'regime':regime,'identity':identity,'path':path,'op':op,**extra})
def walk(v,path):
 yield path,v
 if type(v) is dict:
  for k,x in v.items():yield from walk(x,path+[k])
 elif type(v) is list:
  for i,x in enumerate(v):yield from walk(x,path+[i])
for identity,row in a['RAW'].items():
 node_counts[identity]={}
 for path,v in walk(row,[]):
  typ=type(v).__name__;node_counts[identity][typ]=node_counts[identity].get(typ,0)+1
  if type(v) is bool:ops=['toggle_bool','bool_to_int','bool_to_float']
  elif type(v) is int:numbers.append(v);ops=['numeric_float','number_bool','number_delta','number_string','nan','pos_inf','neg_inf']
  elif type(v) is str:ops=['change_string']
  elif v is None:ops=['null_to_false','null_to_zero']
  elif type(v) is dict:ops=['extra_key','replace_array','replace_null','reverse_dict']
  elif type(v) is list:ops=['append_item','replace_dict','replace_null']+(['reverse_list'] if len(v)>1 else [])
  for regime in ['detached','coupled','companion']:
   for op in ops:add(regime,next(i for i in a['SOURCE_IDS'] if i!=identity) if regime=='companion' else identity,path,op)
 for regime in ['detached','coupled','companion']:
  add(regime,identity,[],'all_numbers_float')
  add(regime,identity,['id'],'id_swap')
 for v in [None,False,0,0.0,'',[],{},['bad']]:
  add('mapping_root',identity,[],'invalid_root',value=v)
  add('detached',identity,[],'invalid_root',value=v)
 for v in [None,False,1,1.0,[],{},['bad'],'unrecognized']:
  for regime in ['detached','coupled','companion']:add(regime,identity,['id'],'replace_value',value=v)
 for regime in ['detached','coupled','companion']:
  add(regime,identity,[],'merged_card')
  add(regime,identity,[],'custom_card')
assert all(type(x) is int and abs(x)<2**53 for x in numbers)
(H/'CASES.json').write_text(json.dumps(cases,ensure_ascii=False,indent=2)+'\n')
meta={'status':'new_correction_candidate_not_installed','original_sha256':sha(original.encode()),'candidate_sha256':sha(candidate.encode()),'patch_sha256':sha(patch.encode()),'constant_assignments_unchanged':list(a),'original_prefix_before_compile_card_byte_identical':True,'source_numeric_constants_small_finite_ints':len(numbers),'node_counts':node_counts,'baseline_cases':218,'case_count':len(cases),'copied_original_inputs':20,'copied_old_probe_archive_sha256':sha(b),'no_new_runtime_dependency':True,'full_driver_not_run':True,'max_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
(H/'CANDIDATE_PROVENANCE.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2)+'\n');print(json.dumps(meta,ensure_ascii=False,indent=2))
