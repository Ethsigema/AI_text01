from pathlib import Path
from copy import deepcopy
import ast,hashlib,json,resource,sys,types
resource.setrlimit(resource.RLIMIT_AS,(128*1024**2,128*1024**2));resource.setrlimit(resource.RLIMIT_CPU,(40,40));sys.dont_write_bytecode=True
H=Path(__file__).resolve().parent;F='research/titanic_guardian_native_recovery/'
def load(p,allowed):
 s=p.read_text();t=ast.parse(s)
 for n in t.body:
  if isinstance(n,ast.Assign):ast.literal_eval(n.value)
  elif isinstance(n,ast.ImportFrom):assert n.module=='copy' and [v.name for v in n.names]==['deepcopy']
  elif isinstance(n,ast.Expr):assert isinstance(n.value,ast.Constant) and isinstance(n.value.value,str)
  else:assert isinstance(n,ast.FunctionDef) and n.name in allowed
 m=types.ModuleType(p.stem);exec(compile(t,str(p),'exec'),m.__dict__);return m
original=load(H/'original_inputs'/F/'candidates/tools/titanic_guardian_patterns.py',{'compile_card'})
candidate=load(H/'candidate/tools/titanic_guardian_patterns.py',{'compile_card','_same_raw_value'})
IDS=original.SOURCE_IDS
import mutations
mutations.IDS=IDS;mutations.original=original
mutate=mutations.mutate

def frozen(v):return json.dumps(v,ensure_ascii=False,sort_keys=True)
def inputs(case):
 identity=case['identity'];cards=deepcopy(original.RAW);card=deepcopy(original.RAW[identity]);regime=case['regime']
 if regime=='detached':card=mutate(card,case)
 elif regime=='coupled':cards[identity]=mutate(cards[identity],case);card=cards[identity]
 elif regime=='companion':
  target=next(i for i in IDS if i!=identity);cards[target]=mutate(cards[target],case);card=cards[identity]
 elif regime=='mapping_root':cards=mutate(cards,case)
 return card,cards
s=(H/'original_inputs'/F/'candidates/tools/build_effect_catalog.py').read_text();t=ast.parse(s)
emit=next(n for n in t.body if isinstance(n,ast.FunctionDef) and n.name=='emit');hook=next(n for n in t.body if isinstance(n,ast.For) and isinstance(n.iter,ast.Call) and isinstance(n.iter.func,ast.Name) and n.iter.func.id=='sorted' and isinstance(n.iter.args[0],ast.Name) and n.iter.args[0].id=='TITANIC_GUARDIAN_IDS');pos=t.body.index(hook);nodes=[emit,hook]+t.body[pos+1:pos+3]
assert '\n\n'.join(ast.get_source_segment(s,n) for n in nodes)+'\n'==(H/'DRIVER_EXACT_FRAGMENTS.py').read_text()
code=compile(ast.Module(body=nodes,type_ignores=[]),'original_exact_titanic_hook','exec')
results=[]
for case in json.loads((H/'CASES.json').read_text()):
 card,cards=inputs(case);before=frozen([card,cards]);outputs=[];errors=[]
 for module in [original,candidate]:
  try:out=module.compile_card(card,cards);err=None
  except Exception as e:out=None;err=type(e).__name__
  assert frozen([card,cards])==before
  if out is not None:assert frozen(out)==frozen(original.EXPECTED[card['id']])
  outputs.append(out);errors.append(err)
 assert errors[1] is None
 calls=[]
 def instrument(c,all_cards):
  calls.append({'loop_key':ns.get('identity'),'exact_key_object':type(all_cards) is dict and c is all_cards.get(ns.get('identity'))})
  return candidate.compile_card(c,all_cards)
 stale={i:{'id':i,'stale':True} for i in IDS};stale['unrelated']={'id':'unrelated','keep':True}
 ns={'cards':cards,'out':deepcopy(stale),'ordered_ids':['unrelated']+list(reversed(IDS)),'TITANIC_GUARDIAN_IDS':IDS,'compile_titanic_guardian':instrument,'hashlib':hashlib}
 hook_error=None
 try:exec(code,ns)
 except Exception as e:hook_error=type(e).__name__
 assert frozen([card,cards])==before
 hookids=sorted(i for i in IDS if i in ns['out'])
 if hook_error is None:
  assert ns['out']['unrelated']==stale['unrelated']
  for ident in hookids:assert frozen(ns['out'][ident])==frozen(original.EXPECTED[ident])
  assert ns['ordered_ids']==['unrelated']+hookids
  assert all(call['exact_key_object'] for call in calls)
 results.append({'label':case['label'],'regime':case['regime'],'op':case['op'],'original_accept':outputs[0] is not None,'original_error':errors[0],'candidate_accept':outputs[1] is not None,'candidate_error':errors[1],'candidate_hook_accepted_ids':hookids if hook_error is None else [],'candidate_hook_error':hook_error,'hook_stale_and_order_checks_pass':hook_error is None,'hook_exact_key_objects':all(c['exact_key_object'] for c in calls),'input_unchanged':True})
canonical={i:candidate.compile_card(deepcopy(original.RAW[i]),deepcopy(original.RAW)) for i in IDS}
for i in IDS:
 a=candidate.compile_card(deepcopy(original.RAW[i]),deepcopy(original.RAW));b=candidate.compile_card(deepcopy(original.RAW[i]),deepcopy(original.RAW));a['effects'][0]['extra']=True
 assert 'extra' not in b['effects'][0] and 'extra' not in candidate.EXPECTED[i]['effects'][0]
 assert frozen(b)==frozen(original.EXPECTED[i]);assert b['default_pool'] is False and b['pool_supported'] is False and 'partial' in b['implementation_status']
(H/'CANDIDATE_OUTPUTS.json').write_text(json.dumps(canonical,ensure_ascii=False,indent=2)+'\n')
report={'case_count':len(results),'candidate_sha256':hashlib.sha256((H/'candidate/tools/titanic_guardian_patterns.py').read_bytes()).hexdigest(),'original_sha256':hashlib.sha256((H/'original_inputs'/F/'candidates/tools/titanic_guardian_patterns.py').read_bytes()).hexdigest(),'executed_driver_nodes':[{'kind':type(n).__name__,'first':n.lineno,'last':n.end_lineno} for n in nodes],'full_driver_executed':False,'input_unchanged_all_cases':True,'deepcopy_and_partial_pool_flags_preserved':True,'results':results,'by_regime':{},'max_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
for regime in sorted({r['regime'] for r in results}):
 rows=[r for r in results if r['regime']==regime];report['by_regime'][regime]={'cases':len(rows),'original_accepts':sum(r['original_accept'] for r in rows),'candidate_accepts':sum(r['candidate_accept'] for r in rows),'original_exceptions':sum(r['original_error'] is not None for r in rows),'candidate_exceptions':sum(r['candidate_error'] is not None for r in rows),'candidate_hook_exceptions':sum(r['candidate_hook_error'] is not None for r in rows)}
(H/'PYTHON_REPORT.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k!='results'},indent=2))
