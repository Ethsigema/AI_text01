extends RefCounted
## Pinned Cursed Crystal revision. Partial holds and previous proof boundaries remain.
const REVISION: String="partial-37.0.2-timewarp_rodeo-rebuilt-20261107"
const ID: String="BG34_Giant_670"
const OVERLAY: String="data/patch_3702_timewarp_rodeo_overlay.json"
const FILE_SHA256: Dictionary={"data/patch_3702_timewarp_rodeo_overlay.json":"a19d8462578daf541d49b43208ad1700e4d32e5fcb5ccab807834d3f50f52acf","research/patch_3702_timewarp_rodeo/BG34_Giant_670.native.xml":"2f87e43fa803341dc6d82a0aee03fc65605f45cd6fd5b72a4a63637acd382ca6","research/patch_3702_timewarp_rodeo/evidence.json":"20909466167bde623f2bf7030ea86dd0ebc2835c7449c11a93f96ae67e2dc07c","core/timewarp_rodeo_host.gd":"154b90238c7264b3239ca3e91faa02e20896a657937c748f2d9ef4f10e071d61","core/game.gd":"2d89d4ff7a3ae41bef8da397c2595d0d3cb302b4c849c87ff44fff86f67b9aa8","core/combat.gd":"d341b6c2afd08018822ffbdb1399382c95c072916269425fdf8b50b8484683ca","core/bulk_recruit_discover_effects.gd":"a6f4b55e5a58eecbf74c6d3013906f6dd8cf6ab3ae16b7f16845dc10b79a3838","core/temporary_deathrattle_enchantments.gd":"66071ff470fedc906dc4cfe8ebe81adb634514116190a80e598621305a0e4df2"}
const RUNTIME_PATHS: Array=["core/patch_3702_timewarp_rodeo_sources.gd","core/catalog.gd","data/patch_3702_timewarp_rodeo_overlay.json","research/patch_3702_timewarp_rodeo/BG34_Giant_670.native.xml","research/patch_3702_timewarp_rodeo/evidence.json","core/timewarp_rodeo_host.gd","core/game.gd","core/combat.gd","core/bulk_recruit_discover_effects.gd","core/temporary_deathrattle_enchantments.gd"]
const EXPECTED_RAW: Dictionary={}
const EXPECTED_COMPILED: Dictionary={}
const EXPECTED_BASELINE: Dictionary={}
const EFFECTIVE_FIELDS: Dictionary={"attack":5,"health":6,"text":"在你的回合开始时，发现一张酒馆法术牌。直到下回合，获得“亡语：获取一张该牌的复制。”","supported":true,"effects":[{"type":"start_turn_timewarp_rodeo_discover","source_id":"BG34_Giant_670","mode":"tavern_spell","minimum_cost":0,"count":1}],"keywords":[],"pool_supported":false,"default_pool":false,"coverage_text_sha256":"4169afd783ed6ada14b9e671c75473c5049ddb440554037347648fa6a0d4e6c4","implementation_status":"partial_start_discover_temporary_spell_reward","conditional_support":{"rule":"timewarp_rodeo_temporary_spell_rebuilt_20261107","reason":"Actual owner-start Tavern spell Discover grants a source-bound temporary Deathrattle for one copy, golden two, expiring next owner turn. Natural acquisition, golden gameplay, overflow and broad combinations require validation."},"pool_blocker":"没有已确认的普通商店随从资格；衍生物、伙伴或时空扭曲内容需由对应机制生成，或显式配置自定义入店参数。","id":"BG34_Giant_670","card_code":"BG34_Giant_670","dbf_id":"128915","name":"时空扭曲竞技表演者","kind":"minion","category":"随从","categories":["随从","时空扭曲"],"mechanisms":["时空扭曲"],"tier":3,"cost":null,"tribes":[],"is_golden":false,"normal_id":null,"golden_id":"BG34_Giant_670_G","image":"","solo_eligible":true,"source_url":"https://github.com/HearthSim/hsdata","native_source_build":"37.0.2.256589"}
const EXPECTED_CURRENT: Dictionary={"attack":5,"health":6,"text":"在你的回合开始时，发现一张酒馆法术牌。直到下回合，获得“亡语：获取一张该牌的复制。”","supported":true,"effects":[{"type":"start_turn_timewarp_rodeo_discover","source_id":"BG34_Giant_670","mode":"tavern_spell","minimum_cost":0,"count":1}],"keywords":[],"pool_supported":false,"default_pool":false,"coverage_text_sha256":"4169afd783ed6ada14b9e671c75473c5049ddb440554037347648fa6a0d4e6c4","implementation_status":"partial_start_discover_temporary_spell_reward","conditional_support":{"rule":"timewarp_rodeo_temporary_spell_rebuilt_20261107","reason":"Actual owner-start Tavern spell Discover grants a source-bound temporary Deathrattle for one copy, golden two, expiring next owner turn. Natural acquisition, golden gameplay, overflow and broad combinations require validation."},"pool_blocker":"没有已确认的普通商店随从资格；衍生物、伙伴或时空扭曲内容需由对应机制生成，或显式配置自定义入店参数。","id":"BG34_Giant_670","card_code":"BG34_Giant_670","dbf_id":"128915","name":"时空扭曲竞技表演者","kind":"minion","category":"随从","categories":["随从","时空扭曲"],"mechanisms":["时空扭曲"],"tier":3,"cost":null,"tribes":[],"is_golden":false,"normal_id":null,"golden_id":"BG34_Giant_670_G","image":"","solo_eligible":true,"source_url":"https://github.com/HearthSim/hsdata","native_source_build":"37.0.2.256589"}

static func accepts_id(value: Variant) -> bool:
	return value is String and value==ID

static func same(actual: Variant,expected: Variant) -> bool:
	# JSON integral floats are admissible. Booleans/strings/fractions/nonfinite values are not numbers.
	if expected is int or expected is float:
		return (actual is int or actual is float) and not actual is bool and is_finite(float(actual)) and is_finite(float(expected)) and actual==floor(actual) and expected==floor(expected) and actual==expected
	if typeof(actual)!=typeof(expected): return false
	if expected is Dictionary:
		if actual.size()!=expected.size(): return false
		for key in expected:
			if not actual.has(key) or not same(actual[key],expected[key]): return false
		return true
	if expected is Array:
		if actual.size()!=expected.size(): return false
		for index in range(expected.size()):
			if not same(actual[index],expected[index]): return false
		return true
	return actual==expected

static func proof_error() -> String:
	# Startup-only disk proof. Hot source_error/program/get_card never calls this.
	for path in FILE_SHA256:
		if not FileAccess.file_exists("res://"+path) or FileAccess.get_sha256("res://"+path)!=FILE_SHA256[path]: return "partial_3702_timewarp_rodeo_evidence_changed:"+str(path)
	var packet: Variant=JSON.parse_string(FileAccess.get_file_as_string("res://"+OVERLAY))
	var expected_packet: Dictionary={"revision":REVISION,"cards":[{"id":ID,"expected_raw":EXPECTED_RAW,"expected_compiled":EXPECTED_COMPILED,"expected_baseline":EXPECTED_BASELINE,"effective_fields":EFFECTIVE_FIELDS}]}
	if not same(packet,expected_packet): return "partial_3702_timewarp_rodeo_changed_packet"
	var baseline: Dictionary=EXPECTED_RAW.duplicate(true);baseline.merge(EXPECTED_COMPILED,true)
	if not same(baseline,EXPECTED_BASELINE): return "partial_3702_timewarp_rodeo_invalid_baseline_derivation"
	baseline.merge(EFFECTIVE_FIELDS,true)
	if not same(baseline,EXPECTED_CURRENT) or str(EXPECTED_CURRENT.text).sha256_text()!=EXPECTED_CURRENT.coverage_text_sha256: return "partial_3702_timewarp_rodeo_invalid_current_derivation"
	return ""

static func input_error(decoded: Variant,path: String) -> String:
	# Called before generic numeric normalization. Historical input is authenticated in full.
	var expected: Dictionary={}
	if path=="res://data/catalog_raw.json": expected=EXPECTED_RAW
	elif path=="res://data/catalog.json": expected=EXPECTED_COMPILED
	if not decoded is Dictionary or not decoded.get("cards") is Array:
		return "partial_3702_timewarp_rodeo_missing_input:"+path if not expected.is_empty() else ""
	var matches: Array=[]
	for card in decoded.cards:
		if card is Dictionary and accepts_id(card.get("id")): matches.append(card)
	if expected.is_empty(): return "" if matches.is_empty() else "partial_3702_timewarp_rodeo_unexpected_input:"+path
	if matches.size()!=1: return "partial_3702_timewarp_rodeo_missing_or_duplicate_input:"+path
	return "" if same(matches[0],expected) else "partial_3702_timewarp_rodeo_changed_whole_input:"+path

static func apply_overlay(cards: Dictionary) -> String:
	if cards.has(ID): return "timewarp_rodeo_unexpected_existing_source"
	cards[ID]=EXPECTED_CURRENT.duplicate(true)
	return ""

static func source_error(card: Dictionary) -> String:
	# Small in-memory, typed, exact whole-current-row guard. No file access or hashing.
	if not accepts_id(card.get("id")): return "partial_3702_timewarp_rodeo_unknown_source"
	return "" if same(card,EXPECTED_CURRENT) else "partial_3702_timewarp_rodeo_changed_whole_effective_source"
