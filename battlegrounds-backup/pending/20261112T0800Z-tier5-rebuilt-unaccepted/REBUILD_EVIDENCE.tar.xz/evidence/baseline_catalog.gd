extends SceneTree
func _initialize():
 var cat=load("res://core/catalog.gd").new();cat.load_catalog()
 if not cat.load_errors.is_empty():print("FAIL ",JSON.stringify(cat.load_errors));quit(1);return
 var records={}
 for id in ["BG23_008","BG31_920","BG31_925","BG32_111","BG32_820","BG32_835"]:
  var card=cat.get_card(id)
  if card.is_empty() or card.tier!=5 or card.kind!="minion" or not card.supported:print("FAIL ",id);quit(1);return
  records[id]=card
 var file=FileAccess.open(get_script().resource_path.get_base_dir()+"/BASELINE_TIER5_CATALOG_RECORDS.json",FileAccess.WRITE)
 if file==null:quit(1);return
 file.store_string(JSON.stringify(records,"  ")+"\n");file.close()
 print("BASELINE_COMPLETE_SIX_CATALOG_RECORDS_PASS")
 quit(0)
