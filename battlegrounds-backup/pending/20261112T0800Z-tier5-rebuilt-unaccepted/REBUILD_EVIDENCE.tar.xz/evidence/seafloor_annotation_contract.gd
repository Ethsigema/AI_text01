extends "res://tests/darkcrest_20261112/seafloor_annotation_contract.gd"
