extends "res://tests/darkcrest_20261112/source_eot_contract.gd"
