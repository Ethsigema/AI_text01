extends "res://tests/darkcrest_tier5_20261112/content_contract.gd"
