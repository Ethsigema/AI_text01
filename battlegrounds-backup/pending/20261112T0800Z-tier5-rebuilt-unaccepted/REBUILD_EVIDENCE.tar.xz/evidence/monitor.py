import sys,subprocess,os,time,json,pathlib,signal,hashlib
root=pathlib.Path(__file__).resolve().parent; project=pathlib.Path(sys.argv[3]).resolve() if len(sys.argv)>3 else root.parent/'game_candidate_shatterer'
name=sys.argv[1] if len(sys.argv)>1 else 'baseline_load'
budget=int(sys.argv[2]) if len(sys.argv)>2 else 120
files={str(p.relative_to(project)):hashlib.sha256(p.read_bytes()).hexdigest() for p in project.rglob('*') if p.is_file() and '.godot' not in p.parts}
(root/(name+'_hashes.json')).write_text(json.dumps(files,sort_keys=True,indent=2))
avail=int(next(l.split()[1] for l in pathlib.Path('/proc/meminfo').read_text().splitlines() if l.startswith('MemAvailable:')))*1024
limit=min(4*1024**3,avail//2)
env=os.environ.copy(); env.update(HOME=str(root/'home'),XDG_CACHE_HOME=str(root/'cache'),XDG_CONFIG_HOME=str(root/'config'),XDG_DATA_HOME=str(root/'data'))
for k in ['HOME','XDG_CACHE_HOME','XDG_CONFIG_HOME','XDG_DATA_HOME']: pathlib.Path(env[k]).mkdir(exist_ok=True)
cmd=['godot','--headless','--path',str(project),'--script',str(root/(name+'.gd'))]
t=time.monotonic();peak=0;reason='exited'
with (root/(name+'.log')).open('w') as log:
 p=subprocess.Popen(cmd,stdout=log,stderr=subprocess.STDOUT,env=env,start_new_session=True)
 while p.poll() is None:
  rss=0
  for x in pathlib.Path('/proc').iterdir():
   if not x.name.isdigit(): continue
   try:
    stat=(x/'stat').read_text().rsplit(')',1)[1].split()
    if int(stat[2])==p.pid: rss+=int((x/'statm').read_text().split()[1])*os.sysconf('SC_PAGE_SIZE')
   except (OSError,ValueError,IndexError): pass
  peak=max(peak,rss)
  if rss>limit or time.monotonic()-t>budget:
   reason='rss_soft_limit' if rss>limit else 'timeout';os.killpg(p.pid,signal.SIGTERM)
   try:p.wait(timeout=2)
   except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
   break
  time.sleep(.02)
 result={'command':cmd,'exit':p.wait(),'reason':reason,'elapsed':time.monotonic()-t,'sampled_process_group_peak_rss':peak,'rss_soft_limit':limit,'available_start':avail,'hard_limit':'unavailable: cgroup filesystem not exposed','timeout_seconds':budget}
(root/(name+'_result.json')).write_text(json.dumps(result,indent=2)); print(json.dumps(result))
