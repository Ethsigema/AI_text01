extends "res://tests/darkcrest_20261112/hand_shape_contract.gd"
