extends "res://tests/darkcrest_tier4_20261112/real_matrix.gd"
# Reconstructed test, not byte-for-byte recovery or inherited test acceptance.
const T5=["BG23_008","BG31_920","BG31_925","BG32_111","BG32_820","BG32_835"]
const ROOM_IDS=["BG36_921","BG31_330","BG23_000","BG23_009","BG23_002","BG31_924","BG23_007","BG23_004","BG26_505","BG34_925","BG33_319","BG36_508","BG35_921","BG23_008","BG31_920","BG31_925","BG32_111","BG32_820","BG32_835"]
const FIXTURE_SEEDS=[20261120,20261121,20261122,20261123,20261126,20261142]
func setup_room(seed_value: int) -> bool:
 game=load("res://core/game.gd").new()
 var room=load("res://core/room_config.gd").new();room.reset(cat)
 room.data.enabled_minions=ROOM_IDS.duplicate();room.data.enabled_spells=["BG28_810"]
 room.data.selected_hero="TB_BaconShop_HERO_01";room.data.enabled_heroes=["TB_BaconShop_HERO_01"];room.data.bot_count=3;room.data.seed=seed_value
 for key in ["enabled_anomalies","enabled_quests","enabled_rewards","enabled_trinkets"]:room.data[key]=[]
 if not must(game.start(room.data,cat).get("ok",false) and game.state.players.size()==4,"native_four_player_room_"+str(seed_value)):return false
 var p=game.state.players[0]
 for tier in [2,3,4,5]:
  if not must(fund(int(p.upgrade_cost)+3),"native_coin_funding_"+str(tier)):return false
  if not must(command(0,{"type":"upgrade"}).get("ok",false) and p.tier==tier,"native_tavern_upgrade_"+str(tier)):return false
 return true
func ready_opponents() -> bool:
 for opponent in game.state.players:
  if opponent.id==0 or not opponent.alive:continue
  if not must(command(opponent.id,{"type":"end_turn"}).get("ok",false),"native_opponent_ready_"+str(opponent.id)):return false
 return true
func next_round(parent: Dictionary,next_tier: int) -> bool:
 var old=game.state.round
 if not ready_opponents():return false
 if not must(command(0,{"type":"end_turn"}).get("ok",false) and game.state.phase=="recruit" and game.state.round==old+1,"native_eot_combat_next_recruit_"+str(old)):return false
 var events=game.events.filter(func(e):return e.get("type")=="darkcrest_tier_upgraded" and e.get("source_uid")==parent.uid and e.get("round")==old)
 if not must(events.size()==1 and events[0].before==next_tier-1 and events[0].after==next_tier,"native_growth_exact_once_"+str(old)):return false
 return must(game._darkcrest_host._eot.is_empty() and game._darkcrest_eot_callback.is_empty(),"native_eot_context_released")
func live_snapshot() -> Dictionary:
 var out=super.live_snapshot()
 out.generation_active=game._darkcrest_host._generation._active.duplicate(true)
 out.generated_origins=game._darkcrest_host._generation._origins.duplicate(true)
 return out
func generation_rejections(unit: Dictionary) -> bool:
 var p=game.state.players[0];var host=game._darkcrest_host;var gen=host._generation
 var before=live_snapshot()
 if not must(not gen.begin(host,game,p).is_empty(),"no_generation_without_active_issued_cast"):return false
 if not must(not gen.drawn(host,game,p,unit).is_empty(),"no_draw_receipt_replay"):return false
 if not must(not gen.received(host,game,p,unit).is_empty(),"no_hand_receipt_replay"):return false
 if not must(not gen.completion_error(host,game,p).is_empty(),"no_completion_outside_cast"):return false
 if unit.card_id=="BG31_920":
  if not must(not host.parent_error(unit.duplicate(true)).is_empty(),"copied_generated_parent_has_no_original_identity"):return false
  if not must(not gen.owner_error(host,unit,game.state.players[1]).is_empty(),"generated_origin_cannot_authorize_other_owner"):return false
  var detached=game.Darkcrest.Generation.new();detached._origins=gen._origins.duplicate(true)
  if not must(not detached.parent_error(host,unit).is_empty(),"copied_private_values_cannot_bind_another_generation_host"):return false
  gen.cancel()
  if not must(host.parent_error(unit).is_empty() and gen.owner_error(host,unit,p).is_empty(),"clearing_active_window_preserves_successful_origin"):return false
 return must(game.Darkcrest.Sources.same(before,live_snapshot()),"all_generation_rejections_preserve_live_state")
func cast_tier5(parent: Dictionary,seed_value: int) -> Dictionary:
 var p=game.state.players[0];var host=game._darkcrest_host
 var tokens=p.hand.filter(func(u):return u.card_id=="BG31_920t")
 if not must(tokens.size()==1 and host._spells[tokens[0].uid].tier==5 and host._spells[tokens[0].uid].source_uid==parent.uid,"actual_tier5_issued_source_snapshot"):return {}
 var token=tokens[0];var domain=game.BulkResourceHost.domain(game)
 var choices=game.BulkResourceHost.candidates(domain,domain.stock,{"kind":"minion","tier":5,"tribe":"纳迦"})
 if not must(choices.map(func(c):return c.id)==T5 and choices.all(func(c):return c.stock>0),"complete_six_positive_stock_candidates"):return {}
 var total=0
 for choice in choices:total+=choice.stock
 var old_hand=p.hand.duplicate();var before_uids=p.hand.map(func(u):return u.uid);var before_pool=game.pool.duplicate(true);var uid_before=game.next_uid;var event_before=game.events.size();var spell_before=p.stats.spells;var history=p[game.GlobalCards.STATE].tavern_spells
 # Observe one native RNG step using an isolated generator, never the live RNG.
 var probe=RandomNumberGenerator.new();probe.seed=game.rng.seed;probe.state=game.rng.state
 var predicted_ticket=probe.randi_range(0,total-1)
 if not must(command(0,{"type":"play","index":p.hand.find(token),"target":-1,"position":-1}).get("ok",false),"native_tier5_public_cast"):return {}
 var added=p.hand.filter(func(u):return u.uid not in before_uids)
 if not must(added.size()==1,"single_original_tier5_delivery"):return {}
 var unit=added[0]
 if not must(unit.card_id in T5 and unit.tier==5 and unit.uid=="u"+str(uid_before) and game.next_uid==uid_before+1 and unit.pool_kind=="minion" and unit.pool_id==unit.card_id and unit.pool_count==1,"native_owned_factory_uid_and_stamp"):return {}
 var changed=[]
 for id in before_pool:
  if before_pool[id]!=game.pool.get(id):changed.append(id)
 if not must(game.pool.size()==before_pool.size() and changed==[unit.card_id] and game.pool[unit.card_id]==before_pool[unit.card_id]-1,"single_exact_native_stock_debit"):return {}
 var random_events=game.events.slice(event_before).filter(func(e):return e.get("type")=="rng" and e.get("reason")=="random_generated_minion")
 if not must(random_events.size()==1 and random_events[0].range==total,"original_full_weight_random_draw"):return {}
 if not must(game.rng.state==probe.state and random_events[0].value==predicted_ticket,"one_exact_native_rng_state_step"):return {}
 var ticket=random_events[0].value;var expected=""
 for choice in choices:
  if ticket<choice.stock:expected=choice.id;break
  ticket-=choice.stock
 if not must(expected==unit.card_id,"actual_ticket_selects_actual_output"):return {}
 if not must(not p.hand.has(token) and p.stats.spells==spell_before+1 and p[game.GlobalCards.STATE].tavern_spells==history,"single_consumption_not_tavern_spell_history"):return {}
 if not must(host._cast.is_empty() and host._generation._active.is_empty(),"public_play_clears_transient_generation_window"):return {}
 if not must(host.owner_error(game,p).is_empty() and host.hand_state_error(unit,cat.get_card(unit.card_id),game.Rider.UNIT_FIELDS).is_empty(),"actual_tier5_owner_and_native_hand_shape_valid"):return {}
 for old in old_hand:
  if is_same(old,token):continue
  if not must(p.hand.any(func(u):return is_same(u,old)),"existing_hand_original_object_retained"):return {}
 if unit.card_id=="BG31_920":
  var record=host._parents[unit.uid];var origin=host._generation._origins.get(unit.uid,{})
  if not must(record.shop_origin==false and record.tier==1 and record.last_eot==-1 and not host._grants.has(unit.uid),"generated_parent_starts_fresh_tier1_not_shop_or_inherited"):return {}
  if not must(is_same(origin.get("unit"),unit) and is_same(origin.get("parent_record"),record) and is_same(origin.get("owner"),p) and origin.owner_id==p.id and origin.birth_round==game.state.round and origin.birth_tier==1 and origin.cast_tier==5 and origin.source_uid==parent.uid and origin.token_uid==token.uid,"private_origin_bound_to_actual_source_cast_and_hand"):return {}
 else:
  if not must(not host._generation.claimed(unit),"ordinary_output_does_not_receive_parent_origin"):return {}
 if not rejection_contracts(unit) or not generation_rejections(unit):return {}
 records.append({"seed":seed_value,"id":unit.card_id,"uid":unit.uid,"source_uid":parent.uid,"token_uid":token.uid,"choices":choices,"rng":random_events[0],"tavern_history":history})
 return unit
func tier5_case(seed_value: int,lower_regression: bool) -> bool:
 if not setup_room(seed_value):return false
 var p=game.state.players[0];var parent=quick_parent()
 if parent.is_empty() or not source_play(parent):return false
 for tier in [1,2,3,4]:
  var old=p.hand.filter(func(u):return u.card_id=="BG31_920t")
  if lower_regression and not cast_level(parent,tier):return false
  if not next_round(parent,tier+1):return false
  if not lower_regression and not must(not p.hand.any(func(u):return u.uid==old[0].uid),"native_uncast_expiry_tier"+str(tier)):return false
 var unit=cast_tier5(parent,seed_value)
 if unit.is_empty():return false
 if not must(command(0,{"type":"freeze"}).get("ok",false) and command(0,{"type":"freeze"}).get("ok",false),"recruit_commands_accept_generated_hand"):return false
 var before=held_snapshot();var held=game.apply_command(0,{"type":"end_turn"})
 if not must(not held.get("ok",true) and held.error=="darkcrest_next_tier_outside_finite_candidate" and game.Darkcrest.Sources.same(before,held_snapshot()),"tier5_to6_still_held_without_mutation"):return false
 if unit.card_id!="BG31_920":
  before=held_snapshot();held=game.apply_command(0,{"type":"play","index":p.hand.find(unit),"target":-1,"position":-1})
  if not must(not held.get("ok",true) and held.error=="darkcrest_other_play_held" and game.Darkcrest.Sources.same(before,held_snapshot()),"other_output_play_remains_held_with_darkcrest"):return false
 if not must(command(0,{"type":"sell","index":p.board.find(parent)}).get("ok",false),"native_sell_old_tier5_source"):return false
 if unit.card_id=="BG31_920":
  if not must(game._darkcrest_host.parent_error(unit).is_empty(),"generated_origin_survives_old_source_sale"):return false
  if not source_play(unit) or not cast_level(unit,1):return false
  if not next_round(unit,2):return false
  var tokens=p.hand.filter(func(u):return u.card_id=="BG31_920t")
  if not must(tokens.size()==1 and game._darkcrest_host._spells[tokens[0].uid].tier==2 and game._darkcrest_host._spells[tokens[0].uid].source_uid==unit.uid and game._darkcrest_host._parents[unit.uid].shop_origin==false,"generated_source_own_tier2_next_recruit_snapshot"):return false
  if not cast_level(unit,2):return false
  if not must(game._darkcrest_host._parents[unit.uid].tier==2 and game._darkcrest_host.owner_error(game,p).is_empty(),"generated_parent_persists_with_independent_growth"):return false
 else:
  var round_before=game.state.round
  if not ready_opponents():return false
  if not must(command(0,{"type":"end_turn"}).get("ok",false) and game.state.phase=="recruit" and game.state.round==round_before+1 and p.hand.any(func(u):return is_same(u,unit)) and game._darkcrest_host.hand_error(game,unit,p).is_empty(),"native_tier5_hand_retained_next_recruit"):return false
 if lower_regression and not unowned_factory_rejection():return false
 coverage[unit.card_id]=int(coverage.get(unit.card_id,0))+1
 records[-1].coverage=coverage.duplicate(true)
 print("TIER5_CASE_PASS ",JSON.stringify(records[-1]))
 return true
func unowned_factory_rejection() -> bool:
 # Diagnostic only: original factory, no stock acquisition or hand insertion.
 var p=game.state.players[0];var host=game._darkcrest_host
 var hand=p.hand.duplicate(true);var pool=game.pool.duplicate(true);var rng=game.rng.state;var uid=game.next_uid;var origins=host._generation._origins.duplicate(true)
 var unit=game._unit(cat.get_card("BG31_920"))
 if not must(not unit.is_empty() and unit.uid=="u"+str(uid) and game.next_uid==uid+1 and unit.pool_count==0,"diagnostic_original_unowned_factory_only"):return false
 var record=host._parents.get(unit.uid,{})
 if not must(is_same(record.get("unit"),unit) and record.get("shop_origin")==false and record.get("tier")==1 and record.get("last_eot")==-1,"diagnostic_real_fresh_record_is_not_acquisition"):return false
 if not must(not host.parent_error(unit).is_empty() and not host._generation.claimed(unit),"unknown_real_factory_birth_remains_held"):return false
 return must(game.Darkcrest.Sources.same(hand,p.hand) and game.Darkcrest.Sources.same(pool,game.pool) and game.rng.state==rng and game.Darkcrest.Sources.same(origins,host._generation._origins),"unowned_diagnostic_never_inserts_hand_or_issues_origin")
func triple_boundary_case() -> bool:
 if not setup_room(20261220):return false
 var p=game.state.players[0];var parents=buy_two_parents()
 if not must(parents.size()==2,"two_native_shop_sources_before_grants"):return false
 var parent=parents[0]
 if not source_play(parent):return false
 for next_tier in [2,3,4,5]:
  if not next_round(parent,next_tier):return false
 if not must(p.hand.has(parents[1]) and game._darkcrest_host._parents[parents[1].uid].tier==1 and game._darkcrest_host._parents[parents[1].uid].last_eot==-1,"second_shop_source_stays_unplayed_tier1"):return false
 var token=p.hand.filter(func(u):return u.card_id=="BG31_920t")[0]
 var domain=game.BulkResourceHost.domain(game);var choices=game.BulkResourceHost.candidates(domain,domain.stock,{"kind":"minion","tier":5,"tribe":"纳迦"})
 if not must(choices.map(func(c):return c.id)==T5 and choices.all(func(c):return c.stock>0),"triple_refusal_keeps_complete_domain"):return false
 var before=held_snapshot();var held=game.apply_command(0,{"type":"play","index":p.hand.find(token),"target":-1,"position":-1})
 if not must(not held.get("ok",true) and held.error=="darkcrest_random_output_triple_held" and game.Darkcrest.Sources.same(before,held_snapshot()),"possible_third_source_refused_before_any_random_resource_mutation"):return false
 if not must(game._darkcrest_host._generation._active.is_empty() and game._darkcrest_host._generation._origins.is_empty() and not game._darkcrest_host._spells[token.uid].used,"triple_refusal_has_no_origin_or_consumption"):return false
 print("TIER5_TRIPLE_BOUNDARY_PASS")
 return true
func _initialize():
 print("TIER5_RECONSTRUCTED_LOAD_BEGIN")
 var Game=load("res://core/game.gd")
 if not must(Game!=null and Game.can_instantiate(),"complete_game_script"):return
 cat=load("res://core/catalog.gd").new();cat.load_catalog()
 if not must(cat.load_errors.is_empty(),"complete_catalog"):print(JSON.stringify(cat.load_errors));return
 for index in range(FIXTURE_SEEDS.size()):
  if not tier5_case(FIXTURE_SEEDS[index],index==0):return
 if not must(coverage.size()==6,"all_six_real_original_rng_outputs_observed"):return
 if not triple_boundary_case() or not waiting_case():return
 var result={"scope":"reconstructed ordinary Darkcrest full tier5 random domain and private native generated-parent origin; not all output abilities or whole game","checks":checks,"coverage":coverage,"cases":records,"four_player_rooms":true,"lower_tier_regression":true,"triple_refusal":true,"waiting_regression":true,"unowned_factory_rejection":true,"reconstructed":true}
 var file=FileAccess.open(get_script().resource_path.get_base_dir()+"/TIER5_MATRIX_RESULT.json",FileAccess.WRITE)
 if not must(file!=null,"matrix_result_file"):return
 file.store_string(JSON.stringify(result,"  ")+"\n");file.close()
 print("DARKCREST_TIER5_REAL_MATRIX_PASS cases=",records.size()," checks=",checks," coverage=",JSON.stringify(coverage))
 quit(0)
