extends "res://tests/darkcrest_20261112/hand_shape_contract.gd"
# Pure observations of detached fixtures. Not a native acquisition or authority.
const Generation=preload("res://core/darkcrest_generation.gd")
const T5=["BG23_008","BG31_920","BG31_925","BG32_111","BG32_820","BG32_835"]
class FakeCatalog:
 extends RefCounted
 var cards: Dictionary={}
 func get_card(id: String) -> Dictionary:
  return cards.get(id,{})
func _initialize() -> void:
 var host=Host.new();var gen=Generation.new();var catalog=FakeCatalog.new()
 for id in T5:catalog.cards[id]=Sources.EXPECTED_HAND.get(id,{}).duplicate(true)
 var fake_game={"catalog":catalog,"Rider":{"UNIT_FIELDS":Rider.UNIT_FIELDS},"pool":{}}
 check(Generation.IDS==T5,"exact_six_tier5_receipt_domain")
 check(Sources.proof_error().is_empty(),"complete_source_and_runtime_proof")
 for id in T5:
  var card: Dictionary=catalog.cards[id]
  check(not card.is_empty() and card.get("tier")==5,"complete_frozen_tier5_card_"+id)
  if card.is_empty():continue
  var unit=fixture(card,true)
  check(Host.candidate_source_error(id,card).is_empty(),"complete_candidate_source_"+id)
  check(Host.hand_state_error(unit,card,Rider.UNIT_FIELDS).is_empty(),"exact_unplayed_hand_shape_"+id)
  check(gen._body_error(host,fake_game,unit).is_empty(),"owned_stamp_shape_observation_"+id)
  for field in card:
   var bad=card.duplicate(true);bad.erase(field)
   check(not Host.candidate_source_error(id,bad).is_empty(),"missing_complete_source_field_"+id+"_"+str(field))
  for field in unit:
   var bad=unit.duplicate(true);bad.erase(field)
   check(not gen._body_error(host,fake_game,bad).is_empty(),"missing_owned_body_field_"+id+"_"+str(field))
  for field in ["effects","tribes","keywords"]:
   for bad_value in [null,7,"invalid",{}]:
    var bad=unit.duplicate(true);bad[field]=bad_value
    var before=bad.duplicate(true)
    check(not gen._body_error(host,fake_game,bad).is_empty(),"malformed_body_"+id+"_"+field+"_"+str(bad_value))
    check(Sources.same(before,bad),"malformed_check_read_only_"+id+"_"+field+"_"+str(bad_value))
  for bad_value in [null,[],7,"invalid"]:
   var bad=unit.duplicate(true);bad.base_unit=bad_value
   check(not gen._body_error(host,fake_game,bad).is_empty(),"malformed_base_"+id+"_"+str(bad_value))
  var bad=unit.duplicate(true);bad.extra_unregistered_state=true
  check(not gen._body_error(host,fake_game,bad).is_empty(),"unknown_body_field_"+id)
  bad=unit.duplicate(true);bad.pool_kind="spell"
  check(not gen._body_error(host,fake_game,bad).is_empty(),"foreign_pool_stamp_"+id)
  check(not gen.claimed(unit),"shape_does_not_grant_origin_"+id)
  check(not gen.begin(host,fake_game,{"id":0}).is_empty(),"dictionary_game_cannot_open_real_window_"+id)
  check(not gen.drawn(host,fake_game,{"id":0},unit).is_empty(),"dictionary_game_cannot_claim_draw_"+id)
  check(not gen.received(host,fake_game,{"id":0},unit).is_empty(),"dictionary_game_cannot_claim_delivery_"+id)
  check(not gen.completion_error(host,fake_game,{"id":0}).is_empty(),"dictionary_game_cannot_claim_completion_"+id)
  check(gen._active.is_empty() and gen._origins.is_empty(),"all_fixture_probes_leave_no_authority_"+id)
 var first={"uid":"same-value"};var second={"uid":"second"}
 check(Generation._same_objects([first,second],[first,second]),"same_original_ordered_objects")
 check(not Generation._same_objects([first,second],[second,first]),"reordered_objects_rejected")
 check(not Generation._same_objects([first],[first.duplicate(true)]),"equal_deep_copy_is_not_identity")
 check(not Generation._same_objects([first],[]),"missing_object_rejected")
 # Pure numeric admission and detached identity/stock observations only.
 for sample in [{"value":0,"valid":true},{"value":1,"valid":true},{"value":2147483647,"valid":true},{"value":2147483648,"valid":false},{"value":-1,"valid":false},{"value":2.0,"valid":false},{"value":2.5,"valid":false},{"value":"2","valid":false},{"value":true,"valid":false},{"value":null,"valid":false}]:
  check(Generation._integer(sample.value,0,2147483647)==sample.valid,"bounded_integral_stock_scalar_"+str(sample.value))
 var seen={"uid":"observed_u","card_id":"BG31_920"}
 var zones={"state":{"players":[{"hand":[seen],"board":[],"shop":[]}],"ghosts":[]}}
 var before_zones=zones.duplicate(true)
 check(Generation._occurrences(zones,seen)==1,"one_original_hand_occurrence")
 check(Sources.same(before_zones,zones),"occurrence_observation_read_only")
 zones.state.players[0].board.append(seen.duplicate(true))
 check(Generation._occurrences(zones,seen)==2,"same_uid_copy_counts_as_duplicate")
 zones.state.ghosts.append({"hand":[],"board":[seen],"shop":[]})
 check(Generation._occurrences(zones,seen)==3,"ghost_occurrence_not_ignored")
 gen._active={"pool":{"a":3,"b":2}}
 for pool in [{"a":2,"b":2},{"a":3,"b":2},{"a":1,"b":2},{"a":2,"b":1},{"a":2},{"a":2,"b":2,"extra":1},{"a":"2","b":2},{"a":2.0,"b":2},{"a":-1,"b":2}]:
  var original=pool.duplicate(true);var active=gen._active.duplicate(true)
  var issue=gen._pool_error({"pool":pool},"a")
  var valid=pool.get("a") is int and pool.get("b") is int and Sources.same(pool,{"a":2,"b":2})
  check(issue.is_empty() if valid else not issue.is_empty(),"exact_whole_stock_observation_"+JSON.stringify(pool))
  check(Sources.same(original,pool) and Sources.same(active,gen._active),"stock_observation_read_only_"+JSON.stringify(pool))
 gen.cancel()
 check(gen._active.is_empty() and gen._origins.is_empty(),"cancel_without_origin_never_creates_one")
 var forged=fixture(catalog.cards["BG31_920"],true)
 gen._origins[forged.uid]={"unit":forged,"parent_record":{},"owner":{"id":0},"owner_id":0,"birth_tier":1,"cast_tier":5}
 check(not gen.parent_error(host,forged).is_empty(),"unbound_private_values_never_establish_actual_origin")
 var origins=gen._origins.duplicate(true);gen._active={"phase":"fixture"};gen.cancel()
 check(gen._active.is_empty() and Sources.same(origins,gen._origins),"cancel_clears_window_without_erasing_record_values")
 check(not gen.parent_error(host,forged).is_empty(),"cancel_does_not_upgrade_forged_values_to_authority")
 print("DARKCREST_TIER5_CONTENT_CONTRACT ",JSON.stringify({"passed":passed,"failed":failed,"failures":failures,"ids":T5,"reconstructed":true,"scope":"pure fixture content and identity observations only, not actual acquisition or provenance"}))
 quit(0 if failed==0 else 1)
