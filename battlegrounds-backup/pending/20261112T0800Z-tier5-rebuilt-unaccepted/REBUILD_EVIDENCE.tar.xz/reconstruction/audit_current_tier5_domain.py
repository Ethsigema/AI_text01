from pathlib import Path
import json,hashlib
r=Path(__file__).resolve().parents[1];p=r/'candidate_rebuilt';file=p/'data/catalog_raw.json';cards=json.loads(file.read_text())['cards'];considered=[]
for c in cards:
 if c.get('kind')!='minion' or c.get('tier')!=5 or c.get('is_golden') or not any(t in c.get('tribes',[]) for t in ['纳迦','全部','all']):continue
 eligible=c.get('status')=='在池' and c.get('solo_eligible')==True and c.get('duos_exclusive')==False
 considered.append({'id':c['id'],'name':c.get('name'),'tribes':c.get('tribes'),'status':c.get('status'),'solo_eligible':c.get('solo_eligible'),'duos_exclusive':c.get('duos_exclusive'),'current_ordinary_solo_domain':eligible})
ids=sorted(c['id'] for c in considered if c['current_ordinary_solo_domain']);assert ids==['BG23_008','BG31_920','BG31_925','BG32_111','BG32_820','BG32_835']
report={'status':'PASS_COMPLETE_FROZEN_CURRENT_ORDINARY_SOLO_TIER5_DOMAIN','source':'data/catalog_raw.json','source_sha256':hashlib.sha256(file.read_bytes()).hexdigest(),'ids':ids,'considered':considered,'limitation':'Frozen repository source audit, not a new online patch verification; historical/unspecified/duos entries excluded, no runtime draw candidates removed.'}
(r/'evidence/CURRENT_TIER5_DOMAIN_AUDIT.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(report['status'],ids)
