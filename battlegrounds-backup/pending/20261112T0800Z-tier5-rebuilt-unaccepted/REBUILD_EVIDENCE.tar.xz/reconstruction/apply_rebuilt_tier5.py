from pathlib import Path
import json,re,hashlib,shutil
r=Path(__file__).resolve().parents[1];p=r/'candidate_rebuilt';e=r/'evidence';e.mkdir(exist_ok=True)
assert (p/'core/darkcrest_host.gd').is_file()
pre={f.relative_to(p).as_posix():hashlib.sha256(f.read_bytes()).hexdigest() for f in p.rglob('*') if f.is_file()}
(e/'PREIMAGE_HASHES.json').write_text(json.dumps(pre,sort_keys=True,indent=2)+'\n')
T5=['BG23_008','BG31_920','BG31_925','BG32_111','BG32_820','BG32_835']
f=p/'core/darkcrest_host.gd';s=f.read_text()
def replace(a,b,n=1):
 global s
 assert s.count(a)==n,(a,s.count(a));s=s.replace(a,b)
replace('const MAX_TIER: int=4','const MAX_TIER: int=5')
replace('const TierFour=preload("res://core/darkcrest_tier_four.gd")','const TierFour=preload("res://core/darkcrest_tier_four.gd")\nconst Generation=preload("res://core/darkcrest_generation.gd")\nvar _generation=Generation.new()')
for name in ['HAND_BODIES']:
 m=re.search(r'const '+name+r': Array=(\[[^\n]+\])',s);assert m
 ids=json.loads(m[1]);ids+=T5;s=s[:m.start(1)]+json.dumps(ids,separators=(',',':'))+s[m.end(1):]
replace('raw_id not in STRICT_HAND_BODIES and raw_id not in TierFour.IDS','raw_id not in STRICT_HAND_BODIES and raw_id not in TierFour.IDS and raw_id not in Generation.IDS')
replace('if id in STRICT_HAND_BODIES:', 'if id in STRICT_HAND_BODIES or id in Generation.IDS:')
replace('\tif r.get("shop_origin")!=true: return "darkcrest_nonshop_birth_held"','\tif r.get("shop_origin")==true:\n\t\tif _generation.claimed(u): return "darkcrest_ambiguous_birth_origin"\n\telse:\n\t\tissue=_generation.parent_error(self,u)\n\t\tif not issue.is_empty(): return issue')
replace('\t\tissue=parent_error(u)\n\t\tif not issue.is_empty(): return issue','\t\tissue=parent_error(u)\n\t\tif not issue.is_empty(): return issue\n\t\tissue=_generation.owner_error(self,u,p)\n\t\tif not issue.is_empty(): return issue')
replace('\t\t\tissue=parent_error(u)\n\t\t\tif not issue.is_empty(): return issue','\t\t\tissue=parent_error(u)\n\t\t\tif not issue.is_empty(): return issue\n\t\t\tissue=_generation.owner_error(self,u,p)\n\t\t\tif not issue.is_empty(): return issue')
replace('"tier":fields.tier,"used":fields.used}', '"tier":fields.tier,"used":fields.used,"source_uid":_delivery.original_ticket.source_uid}')
replace('func finish_cast() -> void: _cast={}', '''func finished_cast_error(game,p: Dictionary) -> String:
	if _cast.is_empty() or int(_cast.record.get("tier",0))!=5: return ""
	return _generation.completion_error(self,game,p)
func finish_cast() -> void:
	_generation.cancel()
	_cast={}''')
replace('\t_parents={};_grants={};_spells={};_cast={};_delivery={};_eot={};_delivery_receipts=[]','\t_parents={};_grants={};_spells={};_cast={};_delivery={};_eot={};_delivery_receipts=[]\n\t_generation=Generation.new()')
f.write_text(s)
f=p/'core/game.gd';s=f.read_text()
replace('\t_darkcrest_host.finish_cast()\n\treturn darkcrest_play_result','\tif darkcrest_play_result.get("ok",false):\n\t\tdarkcrest_play_issue=_darkcrest_host.finished_cast_error(self,p)\n\t\tif not darkcrest_play_issue.is_empty(): darkcrest_play_result=_fail(darkcrest_play_issue)\n\t_darkcrest_host.finish_cast()\n\treturn darkcrest_play_result')
a='''			if not _native_result(darkcrest_cast): return
			for naga_index in range(naga_count):
				var naga_generated: Dictionary=BulkResourceHost.draw_owned_minion(self,p,{"kind":"minion","tier":int(darkcrest_cast.tier),"tribe":"纳迦"})
				if state.phase=="error": return
				if naga_generated.is_empty(): break
				_add_hand(p,naga_generated)
				if state.phase=="error": return'''
b='''			if not _native_result(darkcrest_cast): return
			var tier5: bool=int(darkcrest_cast.tier)==5
			var generation_issue: String=""
			if tier5:
				generation_issue=_darkcrest_host._generation.begin(_darkcrest_host,self,p)
				if not generation_issue.is_empty(): _native_result({"ok":false,"error":generation_issue});return
			for naga_index in range(naga_count):
				var naga_generated: Dictionary=BulkResourceHost.draw_owned_minion(self,p,{"kind":"minion","tier":int(darkcrest_cast.tier),"tribe":"纳迦"})
				if state.phase=="error": return
				if naga_generated.is_empty():
					if tier5: _native_result({"ok":false,"error":"darkcrest_generation_empty_original_draw"});return
					break
				if tier5:
					generation_issue=_darkcrest_host._generation.drawn(_darkcrest_host,self,p,naga_generated)
					if not generation_issue.is_empty(): _native_result({"ok":false,"error":generation_issue});return
				_add_hand(p,naga_generated)
				if state.phase=="error": return
				if tier5:
					generation_issue=_darkcrest_host._generation.received(_darkcrest_host,self,p,naga_generated)
					if not generation_issue.is_empty(): _native_result({"ok":false,"error":generation_issue});return'''
replace(a,b);f.write_text(s)
shutil.copyfile(r/'reconstruction/darkcrest_generation.gd',p/'core/darkcrest_generation.gd')
# Complete, actual baseline Catalog records. Update only this candidate's
# admission metadata; never rewrite original source text or native effects.
f=p/'core/darkcrest_sources.gd';s=f.read_text()
def read(name):return json.loads(next(l.split(' = ',1)[1] for l in s.splitlines() if l.startswith('const '+name+' = ')))
def write(name,obj):
 global s
 prefix='const '+name+' = ';lines=s.splitlines();matches=[i for i,l in enumerate(lines) if l.startswith(prefix)];assert len(matches)==1;lines[matches[0]]=prefix+json.dumps(obj,ensure_ascii=False,separators=(',',':'));s='\n'.join(lines)+'\n'
effective=read('EFFECTIVE_FIELDS');current=read('EXPECTED_CURRENT');revision='darkcrest-tier5-generated-parent-rebuilt-candidate-20261112'
reason='Rebuilt isolated candidate from verified Tier4 after environment replacement; private original Tier5 draw/factory/hand origin, independent generated Darkcrest Spellcraft level1 to2. Complete enabled six-card Tier5 Naga/ALL domain. Tier5 is an admission boundary, not an official cap. Golden, mixed boards, post-grant purchase, copies/triples and saves held. Pending fresh final verification.'
for id in effective:
 effective[id]['implementation_status']='partial_darkcrest_tier5_generated_parent_rebuilt_candidate'
 effective[id]['conditional_support']={'rule':'darkcrest_tier5_generated_parent_rebuilt_20261112','reason':reason}
 current[id].update(effective[id])
write('REVISION',revision);write('EFFECTIVE_FIELDS',effective);write('EXPECTED_CURRENT',current)
hand=read('EXPECTED_HAND');native=json.loads((e/'BASELINE_TIER5_CATALOG_RECORDS.json').read_text());assert set(native)==set(T5)
hand.update(native);hand['BG31_920']=current['BG31_920'];write('EXPECTED_HAND',hand)
(p/'research/darkcrest/hand_candidate_records.json').write_text(json.dumps(hand,ensure_ascii=False,sort_keys=True,indent=2)+'\n')
packet=json.loads((p/'data/darkcrest_overlay.json').read_text());packet['revision']=revision
for row in packet['cards']:row['effective_fields']=effective[row['id']]
(p/'data/darkcrest_overlay.json').write_text(json.dumps(packet,ensure_ascii=False,indent=2)+'\n')
pins=read('FILE_SHA256');pins['core/darkcrest_generation.gd']=hashlib.sha256((p/'core/darkcrest_generation.gd').read_bytes()).hexdigest();write('FILE_SHA256',pins)
paths=read('RUNTIME_PATHS');assert 'core/darkcrest_generation.gd' not in paths;paths.append('core/darkcrest_generation.gd');write('RUNTIME_PATHS',paths)
f.write_text(s)
for test in ['real_matrix.gd','content_contract.gd','README.md']:
 src=r/'reconstruction/tests'/test
 if src.exists():
  dst=p/'tests/darkcrest_tier5_20261112'/test;dst.parent.mkdir(exist_ok=True);shutil.copyfile(src,dst)
for old in ['tests/darkcrest_20261112/README.md','tests/darkcrest_tier4_20261112/README.md']:
 f=p/old;f.write_text(f.read_text()+'\nCurrent rebuilt Tier5 candidate entry: tests/darkcrest_tier5_20261112/real_matrix.gd. Old Tier4 refusal assertions are historical, not current acceptance.\n')
print('Rebuilt Tier5 source integrated; not yet verified. Repin, pure checks and freeze backup required before long Game.')
