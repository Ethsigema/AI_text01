extends RefCounted
const Delivery=preload("res://core/spellcraft_waiting_delivery.gd")
const Slither=preload("res://core/slither_death_retention.gd")
const Deadscale=preload("res://core/deadscale_spellcraft_sources.gd")
const Volcanic = preload("res://core/volcanic_visitor_sources.gd")
## User-approved custom policy, not a claim of fully verified official behavior.
const POLICY: String = "spellcraft-wait-1"
const KEY: String = "spellcraft_waiting"
const POLICY_KEY: String = "spellcraft_waiting_policy"
const HAND_LIMIT: int = 10
const MAX_TICKETS: int = 64
const MAX_COUNT: int = 1000
const MAX_ROUND: int = 2147483647
const TICKET_FIELDS: Array = ["source_uid", "source_card_id", "spell_card_id", "effect_index", "round", "count"]
static var _active_flushes: Dictionary = {}
const DARKCREST_PARENTS: Array=["BG31_920","BG31_920_G"]
static func _darkcrest_engine_error(engine) -> String:
	if not engine is RefCounted: return "darkcrest_actual_waiting_game_required"
	var script: Variant=engine.get_script()
	if not script is Script or script.resource_path!="res://core/game.gd": return "darkcrest_actual_waiting_game_required"
	if not engine.get_property_list().any(func(property):return property.name=="_darkcrest_host"): return "darkcrest_actual_waiting_host_required"
	var host: Variant=engine.get("_darkcrest_host")
	if not host is RefCounted: return "darkcrest_actual_waiting_host_required"
	var host_script: Variant=host.get_script()
	if not host_script is Script or host_script.resource_path!="res://core/darkcrest_host.gd": return "darkcrest_actual_waiting_host_required"
	return ""

static func _integer(value: Variant, minimum: int, maximum: int) -> bool:
	return (value is int or (value is float and is_finite(value) and value == floor(value))) and value >= minimum and value <= maximum

static func _uid_valid(value: Variant) -> bool:
	if not value is String or not value.begins_with("u"): return false
	var number: String = value.substr(1)
	return number.is_valid_int() and str(int(number)) == number and int(number) > 0

static func _result(issue: String = "", delivered: int = 0, waiting: int = 0, cancelled: int = 0) -> Dictionary:
	return {"ok":issue.is_empty(), "error":issue, "delivered":delivered, "waiting":waiting, "cancelled":cancelled}

static func pending_count(player: Dictionary) -> int:
	var total: int = 0
	var tickets: Variant = player.get(KEY, [])
	if not tickets is Array: return 0
	for ticket in tickets:
		if ticket is Dictionary and _integer(ticket.get("count"), 1, MAX_COUNT): total += int(ticket.count)
	return total

static func _source_by_uid(player: Dictionary, uid: String) -> Dictionary:
	for source in player.get("board", []):
		if source is Dictionary and source.get("uid") == uid: return source
	return {}

static func _spellcraft_effects(effects: Variant) -> Array:
	var found: Array = []
	if not effects is Array: return found
	for effect in effects:
		if effect is Dictionary and effect.get("type") == "spellcraft": found.append(effect)
	return found

static func _source_contract(catalog, source: Dictionary) -> Dictionary:
	var slither_contract_issue: String=Slither.Sources.contract_error(catalog,source)
	if not slither_contract_issue.is_empty(): return {"error":slither_contract_issue}
	var deadscale_contract_issue: String=Deadscale.contract_error(catalog,source)
	if not deadscale_contract_issue.is_empty(): return {"error":deadscale_contract_issue}
	if not _uid_valid(source.get("uid")) or not source.get("card_id") is String:
		return {"error":"塑造待发来源必须有真实随从 UID 与卡牌 ID。"}
	var native: Dictionary = catalog.get_card(source.card_id)
	if native.get("id") != source.card_id or native.get("kind") != "minion" or not native.get("supported", false) or native.get("excluded", false):
		return {"error":"塑造待发来源身份尚未支持：" + source.card_id}
	if not source.get("kind") is String or source.kind != "minion": return {"error":"塑造待发来源不是场上随从。"}
	if _spellcraft_effects(source.get("effects")) != _spellcraft_effects(native.get("effects")):
		return {"error":"塑造待发来源效果与已核目录映射不一致。"}
	var grants: Array = []
	for index in range(native.get("effects", []).size()):
		var effect: Dictionary = native.effects[index]
		if effect.get("type") != "spellcraft": continue
		if not effect.get("card_id") is String or not _integer(effect.get("count", 1), 1, MAX_COUNT):
			return {"error":"塑造来源的发牌身份或数量格式无效。"}
		var spell: Dictionary = catalog.get_card(effect.card_id)
		# Real golden spells may have category="法术". Exact source mapping wins.
		if spell.get("id") != effect.card_id or spell.get("kind") != "spell" or not spell.get("supported", false) or spell.get("excluded", false):
			return {"error":"塑造来源指向的真实塑造卡尚未支持：" + effect.card_id}
		grants.append({"spell_card_id":effect.card_id, "effect_index":index, "count":int(effect.get("count", 1))})
	return {"error":"", "grants":grants}

## Shape-only validation lets cancellation safely handle a source already removed.
## It never repairs malformed saved data or silently assumes an older policy.
static func _shape_error(player: Dictionary, round_number: Variant, phase: String) -> String:
	if not _integer(round_number, 1, MAX_ROUND): return "塑造待发记录的当前回合无效。"
	if not player.has(KEY):
		return "塑造等待政策标记缺少对应 ticket 数组。" if player.has(POLICY_KEY) else ""
	if not player.get(POLICY_KEY) is String or player[POLICY_KEY] != POLICY: return "塑造等待政策版本缺失或不兼容，必须为 " + POLICY + "。"
	var tickets: Variant = player[KEY]
	if not tickets is Array or tickets.size() > MAX_TICKETS: return "塑造待发记录必须是有界 ticket 数组。"
	if tickets.is_empty(): return ""
	if phase not in ["recruit", "spectate", "error"]: return "塑造待发记录应在回合末取消，不能跨入战斗。"
	if not player.get("board") is Array or player.board.size() > 7 or not player.get("hand") is Array or player.hand.size() > HAND_LIMIT:
		return "塑造待发记录的战队或手牌区域无效。"
	var seen_board: Dictionary = {}
	for unit in player.board:
		if not unit is Dictionary or not _uid_valid(unit.get("uid")): return "塑造待发记录所在战队包含无效 UID。"
		if seen_board.has(unit.uid): return "塑造待发来源 UID 在战队中重复。"
		seen_board[unit.uid] = true
	var seen: Dictionary = {}
	for ticket in tickets:
		if not ticket is Dictionary or ticket.size() != TICKET_FIELDS.size(): return "塑造待发 ticket 字段不完整或含未知字段。"
		for key in TICKET_FIELDS:
			if not ticket.has(key): return "塑造待发 ticket 缺少字段：" + key
		if not _uid_valid(ticket.source_uid) or not ticket.source_card_id is String or not ticket.spell_card_id is String:
			return "塑造待发 ticket 身份字段无效。"
		if not _integer(ticket.round, 1, MAX_ROUND) or int(ticket.round) != int(round_number): return "塑造待发 ticket 不属于当前回合；不能跨回合滚存。"
		if not _integer(ticket.count, 1, MAX_COUNT) or not _integer(ticket.effect_index, 0, MAX_TICKETS): return "塑造待发 ticket 数量或效果序号无效。"
		var identity: Array = [ticket.source_uid, ticket.effect_index]
		if seen.has(identity): return "同一来源效果有重复 ticket；不能重复发放。"
		seen[identity] = true
	return ""

## Read-only validator. Host must also check ordinary units/global UID/next_uid.
static func validate_persistent_state(player: Dictionary, catalog, round_number: Variant, phase: String = "recruit") -> String:
	var issue: String = _shape_error(player, round_number, phase)
	if not issue.is_empty() or player.get(KEY, []).is_empty(): return issue
	if not player.get("alive", true) is bool or not player.get("ready", false) is bool: return "塑造待发记录的存活/准备状态格式无效。"
	if not player.get("alive", true): return "已离场玩家的塑造待发记录应先取消。"
	for ticket in player[KEY]:
		var source: Dictionary = _source_by_uid(player, ticket.source_uid)
		if source.is_empty() or not source.get("card_id") is String or source.card_id != ticket.source_card_id: return "塑造待发来源已离场或变形；运行时应先取消，存档不能保留此票。"
		var contract: Dictionary = _source_contract(catalog, source)
		if not contract.error.is_empty(): return contract.error
		var matched: bool = false
		for grant in contract.grants:
			if grant.effect_index == int(ticket.effect_index) and grant.spell_card_id == ticket.spell_card_id and int(ticket.count) <= grant.count:
				matched = true
				break
		if not matched: return "塑造待发卡牌、效果序号或剩余数量与真实来源效果不一致。"
	return ""

static func _engine_error(engine, player: Dictionary) -> String:
	return validate_persistent_state(player, engine.catalog, engine.state.get("round"), str(engine.state.get("phase", "")))

## A departed source is no longer live, but its stored card/effect identity must
## still be genuine. Cancellation must not hide malformed semantic fields.
static func _cancel_identity_error(engine, player: Dictionary) -> String:
	for ticket in player.get(KEY, []):
		var native: Dictionary = engine.catalog.get_card(ticket.source_card_id)
		var recorded: Dictionary = {"uid":ticket.source_uid, "card_id":ticket.source_card_id, "kind":"minion", "effects":native.get("effects", [])}
		var contract: Dictionary = _source_contract(engine.catalog, recorded)
		if not contract.error.is_empty(): return contract.error
		var matched: bool = false
		for grant in contract.grants:
			if grant.effect_index == int(ticket.effect_index) and grant.spell_card_id == ticket.spell_card_id and int(ticket.count) <= grant.count:
				matched = true
				break
		if not matched: return "不能取消格式损坏的塑造待发卡牌、效果序号或数量；请先报告状态错误。"
	return ""

static func _competition_error(player: Dictionary, free_slots: int, other_incoming: int) -> String:
	if free_slots < 0 or free_slots > HAND_LIMIT or other_incoming < 0: return "塑造待发腾位预检参数无效。"
	if player.get(KEY, []).is_empty() or free_slots == 0: return ""
	var rewards: Variant = player.get("mechanism_reward_queue", [])
	if not rewards is Array: return "跨机制奖励待发队列格式无效。"
	if rewards.size() + other_incoming > 0 and pending_count(player) + rewards.size() + other_incoming > free_slots:
		return "塑造待发与其他生牌/机制奖励争夺手牌空位的先后尚未批准。"
	return ""

## Call BEFORE a command mutates state; pass projected space and competing gains.
static func preflight_space(engine, player: Dictionary, free_slots: int, other_incoming: int = 0) -> String:
	var issue: String = _engine_error(engine, player)
	return issue if not issue.is_empty() else _competition_error(player, free_slots, other_incoming)

## Compatibility preflights: approved source changes/EOT/triples no longer block.
## They validate current state; host must invoke the cancellation hooks below.
static func preflight_source_change(engine, player: Dictionary, _source_uids: Array, _action: String = "") -> String:
	return _engine_error(engine, player)

static func preflight_end_turn(engine, player: Dictionary) -> String:
	return _engine_error(engine, player)

static func preflight_triples(engine, player: Dictionary, _additional_units: Array = [], _removed_uids: Array = []) -> String:
	return _engine_error(engine, player)

static func _commit_cancel(engine, player: Dictionary, kept: Array, cancelled: int) -> Dictionary:
	var preview: Dictionary = player.duplicate()
	if preview.has(KEY): preview[KEY] = kept
	var issue: String = validate_persistent_state(preview, engine.catalog, engine.state.get("round"), str(engine.state.get("phase", "")))
	if not issue.is_empty(): return _result(issue, 0, pending_count(player))
	if player.has(KEY): player[KEY] = kept
	return _result("", 0, pending_count(player), cancelled)

## Call before or just after an approved source removal/identity change. Hand untouched.
static func cancel_source(engine, player: Dictionary, source_uids: Array) -> Dictionary:
	var issue: String = _shape_error(player, engine.state.get("round"), str(engine.state.get("phase", "")))
	if not issue.is_empty(): return _result(issue, 0, pending_count(player))
	issue = _cancel_identity_error(engine, player)
	if not issue.is_empty(): return _result(issue, 0, pending_count(player))
	for uid in source_uids:
		if not _uid_valid(uid): return _result("取消塑造待发的来源 UID 无效。", 0, pending_count(player))
	var kept: Array = []
	var cancelled: int = 0
	for ticket in player.get(KEY, []):
		if ticket.source_uid in source_uids: cancelled += int(ticket.count)
		else: kept.append(ticket.duplicate(true))
	return _commit_cancel(engine, player, kept, cancelled)

## Policy-authorized only: UID absent from board or same UID has a different card ID.
## This is runtime reconciliation, NEVER a save migration/repair step.
static func prune_sources(engine, player: Dictionary) -> Dictionary:
	var issue: String = _shape_error(player, engine.state.get("round"), str(engine.state.get("phase", "")))
	if not issue.is_empty(): return _result(issue, 0, pending_count(player))
	var removed: Array = []
	for ticket in player.get(KEY, []):
		var source: Dictionary = _source_by_uid(player, ticket.source_uid)
		if not source.is_empty() and not source.get("card_id") is String:
			return _result("塑造来源卡牌身份字段无效，不能当作变形取消。", 0, pending_count(player))
		if source.is_empty() or source.get("card_id") != ticket.source_card_id:
			if not ticket.source_uid in removed: removed.append(ticket.source_uid)
	return cancel_source(engine, player, removed)

## Call at actual end-of-turn BEFORE expiry removes hand cards or round/phase changes.
static func cancel_end_turn(engine, player: Dictionary) -> Dictionary:
	var issue: String = _shape_error(player, engine.state.get("round"), str(engine.state.get("phase", "")))
	if not issue.is_empty(): return _result(issue, 0, pending_count(player))
	issue = _cancel_identity_error(engine, player)
	if not issue.is_empty(): return _result(issue, 0, pending_count(player))
	return _commit_cancel(engine, player, [], pending_count(player))

static func _prepared_grants(engine, player: Dictionary, sources: Array) -> Dictionary:
	for slither_source in sources:
		if slither_source is Dictionary and slither_source.get("card_id") in Slither.Sources.PARENTS:
			var slither_grant_issue: String=Slither.play_error(engine,player,slither_source)
			if not slither_grant_issue.is_empty(): return {"error":slither_grant_issue}
	var deadscale_grant_issue: String=Deadscale.grant_error(engine,player,sources)
	if not deadscale_grant_issue.is_empty(): return {"error":deadscale_grant_issue}
	var issue: String = _engine_error(engine, player)
	if not issue.is_empty(): return {"error":issue}
	if engine.state.get("phase") != "recruit": return {"error":"塑造发放只支持同一招募回合。"}
	var tickets: Array = player.get(KEY, []).duplicate(true)
	for source in sources:
		if not source is Dictionary: return {"error":"塑造发放来源格式无效。"}
		var contract: Dictionary = _source_contract(engine.catalog, source)
		if not contract.error.is_empty(): return contract
		var live: Dictionary = _source_by_uid(player, source.uid)
		if live.is_empty() or live.get("card_id") != source.card_id or _spellcraft_effects(live.get("effects")) != _spellcraft_effects(source.get("effects")):
			return {"error":"塑造发放来源必须仍在当前战队。"}
		for grant in contract.grants:
			for pending in tickets:
				if pending.source_uid == source.uid and pending.effect_index == grant.effect_index:
					return {"error":"同一来源效果仍有塑造卡待发，不能重复登记同一发放。"}
			tickets.append({"source_uid":source.uid, "source_card_id":source.card_id, "spell_card_id":grant.spell_card_id, "effect_index":grant.effect_index, "round":int(engine.state.round), "count":grant.count})
	var preview: Dictionary = player.duplicate()
	preview[KEY] = tickets
	preview[POLICY_KEY] = POLICY
	issue = validate_persistent_state(preview, engine.catalog, engine.state.round, "recruit")
	return {"error":issue, "tickets":tickets, "preview":preview}

## Atomic registration only. Host emits each real trigger once and batches simultaneous sources.
static func queue_grants(engine, player: Dictionary, sources: Array) -> Dictionary:
	var darkcrest_sources: bool=sources.any(func(u):return u is Dictionary and u.get("card_id") in DARKCREST_PARENTS)
	if darkcrest_sources:
		var darkcrest_queue_issue: String=_darkcrest_engine_error(engine)
		if darkcrest_queue_issue.is_empty(): darkcrest_queue_issue=engine._darkcrest_host.queue_error(engine,player,sources)
		if not darkcrest_queue_issue.is_empty(): return _result(darkcrest_queue_issue,0,pending_count(player))
	var prepared: Dictionary = _prepared_grants(engine, player, sources)
	if not prepared.error.is_empty(): return _result(prepared.error, 0, pending_count(player))
	if darkcrest_sources:
		var darkcrest_register_issue: String=engine._darkcrest_host.register_grants(engine,player,sources)
		if not darkcrest_register_issue.is_empty(): return _result(darkcrest_register_issue,0,pending_count(player))
	player[KEY] = prepared.tickets
	player[POLICY_KEY] = POLICY
	return _result("", 0, pending_count(player))

static func preflight_grants(engine, player: Dictionary, sources: Array, free_slots: int, other_incoming: int = 0) -> String:
	var prepared: Dictionary = _prepared_grants(engine, player, sources)
	return prepared.error if not prepared.error.is_empty() else _competition_error(prepared.preview, free_slots, other_incoming)

## Current board order, then the source's exact catalog effect order; never stored FIFO.
static func _next_ticket_index(engine, player: Dictionary) -> int:
	for source in player.board:
		var contract: Dictionary = _source_contract(engine.catalog, source)
		if not contract.error.is_empty(): continue
		for grant in contract.grants:
			for index in range(player.get(KEY, []).size()):
				var ticket: Dictionary = player[KEY][index]
				if ticket.source_uid == source.uid and int(ticket.effect_index) == grant.effect_index: return index
	return -1

## Only this function allocates cards and fires the successful host hand-added path.
static func flush(engine, player: Dictionary, other_incoming: int = 0) -> Dictionary:
	var issue: String = _engine_error(engine, player)
	if not issue.is_empty(): return _result(issue, 0, pending_count(player))
	if engine.state.get("phase") != "recruit": return _result("塑造待发只支持同回合招募阶段补发。", 0, pending_count(player))
	issue = _competition_error(player, HAND_LIMIT - player.get("hand", []).size(), other_incoming)
	if not issue.is_empty(): return _result(issue, 0, pending_count(player))
	var guard: String = str(engine.get_instance_id()) + ":" + str(player.get("id", 0))
	if _active_flushes.has(guard): return _result("塑造待发正在入手，不能重入补发。", 0, pending_count(player))
	var callback_plan: Dictionary=Delivery.plan(engine,player)
	if not callback_plan.ok: return _result(str(callback_plan.error),0,pending_count(player))
	var darkcrest_window: RefCounted=null
	if player.get(KEY,[]).any(func(t):return t.get("source_card_id") in DARKCREST_PARENTS):
		issue=_darkcrest_engine_error(engine)
		if not issue.is_empty(): return _result(issue,0,pending_count(player))
		darkcrest_window=RefCounted.new()
	# Pure legacy flushes retain the original bool guard and require no new host.
	_active_flushes[guard] = true if darkcrest_window==null else darkcrest_window
	var delivered: int = 0
	while pending_count(player) > 0 and player.hand.size() < HAND_LIMIT:
		issue = _engine_error(engine, player)
		if not issue.is_empty(): break
		issue = _competition_error(player, HAND_LIMIT - player.hand.size(), other_incoming)
		if not issue.is_empty(): break
		var index: int = _next_ticket_index(engine, player)
		if index < 0:
			issue = "无法按已批准的塑造等待政策定位下一来源效果。"
			break
		var ticket: Dictionary = player[KEY][index]
		if callback_plan.get("active",false) and (delivered>=callback_plan.steps.size() or not engine.Faceless.Sources.same(ticket,callback_plan.steps[delivered].ticket)):
			issue="spellcraft_waiting_planned_ticket_changed";break
		if Deadscale.accepts_id(ticket.source_card_id):
			issue=Deadscale.play_error(engine,player,_source_by_uid(player,ticket.source_uid))
			if not issue.is_empty(): break
		var clunker_zarjira_generation: Dictionary=engine.ClunkerZarjiraTriples.capture_generation(engine,player,ticket)
		if not clunker_zarjira_generation.ok:
			issue=str(clunker_zarjira_generation.error);break
		var weary_generation: Dictionary=engine.WearyPortrait.capture_generation(engine,player,ticket)
		if not weary_generation.ok:
			issue=str(weary_generation.error);break
		var darkcrest_active: bool=ticket.source_card_id in DARKCREST_PARENTS
		var darkcrest_snapshot: Dictionary={"ok":true,"error":"","active":false}
		if darkcrest_active:
			darkcrest_snapshot=engine._darkcrest_host.snapshot(engine,player,ticket,darkcrest_window)
			if not darkcrest_snapshot.ok: issue=str(darkcrest_snapshot.error);break
		var spell: Dictionary = engine._unit(engine.catalog.get_card(ticket.spell_card_id))
		if darkcrest_active and spell.is_empty():
			issue="spellcraft_actual_factory_failed"
			var abort_issue: String=engine._darkcrest_host.abort_delivery(engine,player,darkcrest_snapshot,issue)
			if not abort_issue.is_empty(): issue=abort_issue
			break
		spell.is_spellcraft = true
		spell.expires_at_end_turn = true
		var greta_stamp_issue: String=engine.Greta.stamp(engine,player,_source_by_uid(player,ticket.source_uid),spell,ticket)
		if not greta_stamp_issue.is_empty():
			issue=greta_stamp_issue
			if darkcrest_active:
				var abort_issue: String=engine._darkcrest_host.abort_delivery(engine,player,darkcrest_snapshot,issue)
				if not abort_issue.is_empty(): issue=abort_issue
			break
		var slither_stamp_issue: String=Slither.stamp_resource(engine,player,_source_by_uid(player,ticket.source_uid),spell)
		if not slither_stamp_issue.is_empty():
			issue=slither_stamp_issue
			if darkcrest_active:
				var abort_issue: String=engine._darkcrest_host.abort_delivery(engine,player,darkcrest_snapshot,issue)
				if not abort_issue.is_empty(): issue=abort_issue
			break
		if darkcrest_active:
			var darkcrest_prepare_issue: String=engine._darkcrest_host.bind_delivery(engine,player,spell,darkcrest_snapshot)
			if darkcrest_prepare_issue.is_empty(): darkcrest_prepare_issue=engine._darkcrest_host.begin_delivery(engine,player,darkcrest_snapshot)
			if not darkcrest_prepare_issue.is_empty():
				issue=darkcrest_prepare_issue
				var abort_issue: String=engine._darkcrest_host.abort_delivery(engine,player,darkcrest_snapshot,issue)
				if not abort_issue.is_empty(): issue=abort_issue
				break
		ticket.count = int(ticket.count) - 1
		if ticket.count == 0: player[KEY].remove_at(index)
		engine._add_hand(player, spell)
		var darkcrest_complete: Dictionary={}
		if darkcrest_active:
			darkcrest_complete=engine._darkcrest_host.complete_delivery(engine,player,darkcrest_snapshot)
			if not darkcrest_complete.ok: issue=str(darkcrest_complete.error);break
		var inserted: bool = false
		for held in player.hand:
			if held.get("uid") == spell.get("uid"): inserted = true; break
		if darkcrest_active: inserted=darkcrest_complete.outcome=="committed"
		if not inserted:
			ticket.count = int(ticket.count) + 1
			if not ticket in player[KEY]: player[KEY].append(ticket)
			issue = "宿主未将塑造卡实际加入手牌，待发票已保留；请停止结算。"
			break
		var greta_received_issue: String=engine.Greta.received(engine,player,spell)
		if not greta_received_issue.is_empty(): issue=greta_received_issue;break
		if Slither.Sources.spell(spell): engine._log("slither_spellcraft_received",{"player":player.id,"receipt":spell[Slither.RESOURCE].duplicate(true)})
		issue=Delivery.completed(engine,player,callback_plan,delivered,spell)
		if not issue.is_empty(): break
		issue=engine.WearyPortrait.record_generation(engine,player,spell,weary_generation)
		if not issue.is_empty(): break
		issue=engine.ClunkerZarjiraTriples.record_generation(engine,player,spell,clunker_zarjira_generation)
		if not issue.is_empty(): break
		delivered += 1
		if engine.state.get("phase") != "recruit":
			issue = "塑造入手监听中止了招募结算；已入手卡与剩余票均已保留。"
			break
	_active_flushes.erase(guard)
	return _result(issue, delivered, pending_count(player))

## Only a commuting, no-generation command subset resumes old waiting spells.
## Approval covers source cancellation and Spellcraft source order, not interactions
## with other hand producers/readers, RNG-consuming listeners or new rewards.
static func command_preflight(engine, player: Dictionary, command: Dictionary) -> String:
	var action_name: String = str(command.get("type",command.get("action","")))
	var hand_index: int = int(command.get("index",-1))
	if action_name in ["play","spell"] and hand_index >= 0 and hand_index < player.hand.size() and player.board.size() < 7:
		var incoming: Dictionary = player.hand[hand_index]
		if not _spellcraft_effects(incoming.get("effects",[])).is_empty():
			var preview: Dictionary = player.duplicate(true)
			preview.hand.remove_at(hand_index)
			var position: int = int(command.get("position",-1))
			if position < 0 or position > preview.board.size(): position = preview.board.size()
			preview.board.insert(position,incoming)
			var grant_issue: String = preflight_grants(engine,preview,[incoming],HAND_LIMIT-preview.hand.size())
			if not grant_issue.is_empty(): return grant_issue
	if pending_count(player) == 0: return ""
	var issue: String = _engine_error(engine,player)
	if not issue.is_empty(): return issue
	var action: String = str(command.get("type",command.get("action","")))
	if action not in ["play","spell","magnetize"]: return ""
	var index: int = int(command.get("index",-1))
	if index < 0 or index >= player.hand.size(): return ""
	var unit: Dictionary = player.hand[index]
	issue = preflight_space(engine,player,HAND_LIMIT-player.hand.size()+1)
	if not issue.is_empty(): return issue
	var reason: String = "塑造待发与此操作的生牌/读取手牌/触发先后尚未核实；请先用不含这些触发的卡腾位，或出售来源取消待发。"
	if unit.get("triple_reward",false): return reason
	var is_spell: bool = unit.get("kind") == "spell"
	# This exact two-branch family only adds literal board stats. It neither
	# reads nor produces a hand card; keep every existing observer/order gate.
	var volcanic_choice: bool = false
	if is_spell and unit.get("card_id") is String and unit.card_id in Volcanic.HAND_IDS:
		issue = Volcanic.unit_error(unit)
		if not issue.is_empty(): return issue
		volcanic_choice = true
	for effect in unit.get("effects",[]):
		var kind: String = str(effect.type)
		if is_spell and kind not in ["spell_prize_returning_coin","spell_prize_minion_price","spell_prize_tavern_spell_discount","spell_prize_battlecry_bonus","spell_prize_target_buff","spell_prize_shop_buff","spell_prize_free_roll_income","spell_gold","spell_free_rolls","spell_upgrade_discount","spell_buff","spell_keyword","spell_blood_gem","spell_blood_gem_bonus","spell_set_armor","spell_queue_gold","spell_increase_max_gold"] and not (volcanic_choice and kind == "choose_one"): return reason
		if kind.begins_with("battlecry_") and kind != "battlecry_repeat": return reason
		if kind == "choose_one" and not volcanic_choice: return reason
		if kind in ["spell_buff","spell_keyword"] and effect.get("scope","target") not in ["target","all","all_other","all_friendly","self"]: return reason
	for source in player.board + player.hand:
		for effect in source.get("effects",[]):
			var kind: String = str(effect.type)
			if is_spell and kind == "on_spell_effect":
				var nested: Dictionary = effect.get("effect",{})
				# Fixed additive board buffs commute with actual hand delivery;
				# they neither select with RNG nor inspect/generate the new card.
				if nested.get("type") != "spell_buff" or nested.get("scope") not in ["self","target","all_friendly"]: return reason
				for key in nested:
					if key not in ["type","scope","attack","health","tribe","allow_shop"]: return reason
			if is_spell and kind in ["on_target_spell_hand_buff","on_blood_gem"]: return reason
			if not is_spell and (kind.begins_with("on_play_") or kind == "in_hand_on_play_buff" or (kind == "on_friendly_summon_buff" and not effect.get("combat_only",false))): return reason
	for effect in engine._mechanic_effects(player):
		if effect.get("type") == "mechanism_trigger" and effect.get("event") in ["play_card","spell_cast" if is_spell else "play_minion"]: return reason
	var quest: Dictionary = player.get("active_quest",{})
	if not quest.get("complete",false) and quest.get("counter","") in ["played","battlecries_played","spells"]: return reason
	return ""
