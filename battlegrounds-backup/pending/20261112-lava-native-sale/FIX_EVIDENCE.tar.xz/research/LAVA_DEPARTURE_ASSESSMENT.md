# 普通 Lava 出售/退场：独立只读评估

基线：develop_darkcrest_lava_20261112/remote_snapshot_5d98887/restored_snapshot。未改源码、未运行Game、未复制工程。空位失败候选仍暂停。

## 建议

值得把“已认证、未受增益的普通Lava真实出售，原pool归还，私有play记录退役，Darkcrest继续原生流程”作为下一有限交付。它解除当前用户无法腾出该战队格的实际限制，范围明显小于引入目标Spellcraft永久增益、owner层和计数生命周期。普通出售已有完整执行器，不应重写。

但“仍有Darkcrest时重新购买Lava”存在独立购买投影门禁，不应顺手承诺。一批可验证出售后的原Darkcrest成长/原生生成，并明确再购买仍held。若必须形成卖出再入场闭环，优先评估已存在的原生生成来源或事先合法持有的另一普通Lava再play；不伪造stock/UID，也不把后续抽取域缩成Lava。是否允许预持第二张须保持现single-copy/triple边界，不可未经设计宣称已经支持。

## 实际代码链

- Darkcrest.command_error约182直接返回darkcrest_lava_sale_held，是当前明确前置阻塞。
- Game._sell:6912 → _sell_before_upset → _native_sale_operation_begin:6896 → _sell_native_body:7157。
- 原operation绑定实际owner、sold原对象、sold_uid、index、sales_before、round、sequence，拒嵌套。prefix.begin/prepare检查原board位置和原对象。
- _sale_prefix_execute约7035移除board原对象；原_sale_payout经SaleIncome及_grant_actual_gold执行；7112调用_return_unit，随后p.stats.sold+=1；原本还有多层sale/listener/triple/完成尾部，不能绕过。
- _return_unit:10010调用Magnetic.pool_returns。正常无attachments/components的Lava有pool_id=BG23_009、pool_count=1，pool_kind为minion或shop默认minion，原pool已有该key时加1。返回的是库存计数，不是把同一个unit对象放回shop。
- 原_uid:9543生成u+next_uid并递增。将来新的shop factory有新uid、新Dictionary；不能用card_id相同复用旧Lava记录。
- 当前Lava helper._board[uid]只在真实play完成写入，cancel只清pending，没有出售回收；board_error要求原对象仍在board且全局唯一，离场后旧record自然不能立即授权，但留下僵尸记录并非完整退场实现。

## 最小安全接线

消费前仍要求实际Game/Host/ownedhelper、同一owner、当前board[index]原Lava、真实_board custody、原生未增益2/5/kept0/无marker、无嵌套play/EOT/sale；不能把任意shape当可出售的helper来源。

可复用现_native_sale_operation_context及prefix完成边界，私有短票绑定同一operation/sold/owner/round/sequence。只在原真实sale确认离场和原stock/payout/sold计数完成后退役精确旧record。核旧unit跨zones为0、其它board原引用/值不变、本pool唯一+1、next_uid/RNG不变（当前无外来机制范围）、原生1金币入账及sold+1。不要由helper自己付钱、返pool或再运行原sale一次。

operation在_sell_before_upset返回前会被_native_sale_operation_end清空，应在清空前观察完成，或由外wrapper持有同一真实短票；不能事后用事件相似度重新铸造权限。外层command等待/机制flush在局部sale之后，不把局部sale回执当整command成功。

失败时区分真实阶段：失败可发生在board移除后或pool归还后。保留失败结果，不假装回滚；pending清理不应恢复旧board授权。若单位已真实离场但尾部失败，旧record至少必须被标记退役/失效，且不得让重试重复付钱/返库存。不可仅“result.ok则删record”而忽略部分生效，亦不可在原sale前先删除许可掩盖失败。

成功退役后重播旧complete、旧operation、旧uid对象、复制对象、wrong owner均拒绝。新实体的正常play重新走原hand→board事务，不借用旧record。建议保留有界退役证据或至少确保旧票已consume、旧unit不再可通过entry重签；不要为了清理而重置整个helper并丢掉其他玩家合法记录。

## 再购买为何不是现成能力

Darkcrest.command_error buy只准普通Darkcrest，Lava先遇darkcrest_other_purchase_held。即使改白名单，OwnedPurchaseHost（core/owned_purchase_host.gd:30）调用bind_purchase_projection；Darkcrest Host:542起要求_grants/_spells等为空，且board为空、spellcraft_waiting为空，否则post_grant/nonfresh_purchase_projection_held。原投影仅复制shop/hand的fresh Darkcrest记录，未复制持久Lava实际play custody。

所以活跃Darkcrest组合的Lava再购买需要新的独立只读投影范围和正确shadow记录处理，不能把live helper/owner引用塞给shadow，更不能跳过购买预检。新shop uid本身不和旧记录冲突，真正阻塞是购买授权/投影边界。用户若仅需腾格，出售本批即可交付，不应为追求闭环扩成任意购买组合。

## 有限验证建议

真实四人原生房间取得并play Lava→至少一次原战斗/下一recruit→公开sell；验证原board对象离场、pool+1、gold+1、sold+1、uid/RNG不变、真实日志及helper旧record不可复用；随后同一Darkcrest原EOT/下一招募/完整候选域生成继续。至少两种board index及move后出售，避免复用过期位置。

负例：复制/错owner/同uid替换、改pool_count或pool_kind、增益/kept非零、正在EOT或play/嵌套sale、旧票重播；未授权buy与golden/triple/外来targeted Spellcraft仍消费前拒绝。若决定加入再入场，必须真实取得另一新uid再play并验证新记录与旧退役记录分离，不用手工塞unit证明。

本审查未运行上述流程，未保证所有现sale子host无后续阻塞。结论是可优先实施和有限验收的方向，不是已完成玩法。

## 本批最小接线与实际副作用顺序（追加只读核对）

已选普通Lava出售/退场，不放开active Darkcrest rebuy，不增加永久Spellcraft联动。原operation恰好8字段：owner、sold、sold_uid、index、sales_before、round、sequence、generated_tier7_plan。原operation没有nonce；额外私有nonce不能代替Game当前operation原引用。需绑定全部值及引用对象，尤其GeneratedDiscover.prepare_sale返回plan的身份和深值。

原执行顺序及失败边界：
1. operation_begin与prefix_begin/prepare执行GeneratedDiscover、CyclicResources、SaleIncome、FodderSale及各sale计划，尚未移除。新begin_sale最小位置是operation_begin成功后、body之前；cap128须此时或更早held，begin失败也须清operation。
2. prefix_execute取消source待发，board.remove_at；随后VolatileVenom.release_sold、_sync_board_aura、_trade_ticket都可在付款前失败。gold/pool未变不代表仍在场。
3. SaleIncome.credit_before → 原_grant_actual_gold(sale_payout) → credit_after，再MarketStats、HeroPowerRefresh、自身效果、BulkRecruit、Aristocrat、NativeSale、BulkDiscover、GeneratedDiscover。付款后通用observer仍可失败；Lava无on_sell效果不等于这些可跳过。
4. _return_unit和stats.sold+=1之后，仍有FodderSale、timed mechanisms、TradeHeroes、PlainCopies、hero passive、DancingHats、board trade listeners、SaleGems/SaleCycles、triples、Ozumat；guard失败可能已有离场/金币/库存/sold全部变化。prefix.stage=completed仅在这些后面。
5. body随后还有SaleSpellGroups.commit_sale。因此prefix completed不等于body成功。finish_sale必须在body返回之后、operation_end之前无条件执行；公开command尾部flush仍在后面，局部成功不等于整command成功。

成功凭据应要求原body确实ok且无错误phase；原board只减该对象、其他引用与深值不变；原hand引用/值不变；pool全键/类型不变且仅BG23_009+1；gold+1、sold+1；next_uid及RNG seed/state不变。不能由helper补发金币/库存或修改结果迎合预期。原日志可以正常新增，不要求全部log相等。

失败finish：仍在原board的对象保留在场record、清pending；已经真实离场则撤权并退休UID，即便数值/最终context异常也不能留下可复活许可。不rollback、不重跑body、不覆盖原错误为成功。离场证明绑定真实Game/owner/原对象遍历，不信复制payload；其它zone残留同对象/同UID属于污染，不是新入手授权。二次finish不得再写任何经济值或重复退休。

## 三组关键负例和下一实战

1. 复制/错owner/假Game与Host/同UID替换/复制operation/任一8字段改动（尤其plan身份及深值）/旧context重放/直接finish。必须证明权限来自原事务，不是shape。
2. 移除前、移除后付款前、付款后归池前、归池后observer失败分别观察：原错误保留、实际值不rollback、已离场撤权、未离场保留。单独伪造result.ok=false不能宣称已证明真实observer失败；纯故障注入和Game原生失败需分开说明。
3. retiredUID达到128消费前held、不evict；旧对象/UID不可再play，新真实UID不误拒；不得清除其他玩家有效record。

真实矩阵首选[Darkcrest A,Lava,Darkcrest B]公开sell中间Lava，下一EOT按实际indices0/1而非旧0/2执行，后续原战斗/下一recruit和完整随机域继续。若knownseed可用，再真实生成新Lava、新UID原hand→board，以独立record证明重复play；不缩域、不塞unit、不借active rebuy完成闭环。

这些为基线只读设计审查，尚未review新实现diff或运行Game，不能宣称原sale所有observer已通过。
