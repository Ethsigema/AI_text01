# Ordinary Lava native sale candidate

Five production files changed; no repin/Game/upload. Original sale operation/body/prefix hosts remain untouched internally. Wrapper binds before body and observes finish unconditionally before operation end. Full operation 8 fields and generated_tier7_plan original reference plus deep snapshot are bound. Pure _sale_context_matches checks only content, not authority.

API: sale_preflight(host,game,owner,unit), begin_sale(host,game,owner,index,operation), finish_sale(host,game,owner,operation,native_result). Private _sale_pending owns the active observation; _retired maps UID to owner/round/sequence, cap128 with no eviction and preconsumption held. Existing preflight rejects retired UIDs. Original native new UID is not blocked by retired old UID. Active Darkcrest rebuy remains held.

Actual departure from captured owner's board revokes exact prior play record and records captured original UID regardless of native result success. Cleanup requires actual Game/ownedhelper/owner and exact private record/entity. Invalid calls cannot revoke a still-present record. Native errors preserved; cleanup error added as separate field. No economic repair/rollback/retry. A failed body before removal leaves original custody; successful body must prove no residual entity/UID in any player/ghost zone, exact board-minus-object/unchanged hand, gold+1/pool+1/sold+1, no spell_pool/UID/RNG changes and recruit phase. All accounting writes remain native.

This completion covers the local native sale body only, not later outer command waiting/flush. No claims of injected partial-native-failure test coverage: implementation is static plus short helper/Host syntax validation. Full Game tests and source fingerprint repin are pending parent coordination.

## v2 local strict accounting correction
Only helper changed relative to v1. _sale_inventory_valid requires Dictionary/String keys/int nonnegative values; _sale_inventory_matches checks exact full key/value inventories with both sides validated. Preflight validates both entire inventories, native next_uid int>=1 and pool_count int1. Completion validates unchanged int next_uid, int gold/sold and full strict inventories (expected minion pool adds only Lava1). No global Sources.same changes. Predicates check content only, not actual authority. V1 SHA file retained; v2 short helper syntax passed, no Game execution.

## v3 finite owner preflight
After actual Game/owned helper/owner and recruit checks, sale_preflight invokes Host.owner_error before any native sale mutation. This also covers retained Lava custody after all Darkcrest sources leave, when command_error otherwise returns early. External owner/board/hand mechanisms remain held before consumption. No recursion: owner_error uses board_error/hand_error, not sale_preflight. Prior strict inventory and partial-failure semantics unchanged. V1/V2 freeze evidence retained; helper check-only exit0, no Game.
