# 普通 Lava 永久保留：后续评估（本批不实施）

输入是 `develop_darkcrest_lava_20261112/remote_snapshot_5d98887/restored_snapshot`。本次仅只读源码与本地源证据；未编辑源码、未复制工程、未运行 Godot/Game。原2974验收结论来自父任务，本次不重新计数。

**本批决定：实现普通未修改 Lava 在 Darkcrest 有限房间中的真实 sale/departure；不扩 Mini 永久联动。** 下面是留给后续批次的机制与验收设计，绝不把无 Darkcrest 时已经存在的原生实现称为新增效果。

## 1. 最小来源和独立证据

选普通 `BG23_009` 熔岩潜伏者 + 普通 `BG23_000` 迷你侍从 → `BG23_000t` 迷你三叉戟。

- 两个父随从都在 `data/current_scope_manifest.json` 的普通/保留纳迦范围。子牌是合法源依赖，不应要求它出现在商店随从名单，更不能直接加到酒馆法术池。
- Lava：Tier2、2/5，完整效果 `spellcraft_permanent,count=1`；native明确“每回合从手牌对本随从使用的第一张塑造法术……永久有效”，`TAG_SCRIPT_DATA_NUM_1=1`。
- Mini：Tier1、1/4，native `BACON_SPELLCRAFT_ID=83914`，连接 child BG23_000t 的 Entity ID83914。
- Mini-Trident：完整 native 文本仅“直到下个回合……+2攻击力”，现有程序只有单个 target `spell_buff,attack=2,health=0,allow_shop=true,temporary=true`。不会引入生命值、关键词、随机目标或混合时效。
- 本地独立证据：`research/bubble_crown_spellcraft/native/{BG23_009,BG23_000,BG23_000t}.xml`；`data/catalog_raw.json` + `data/catalog.json`。本报告旁 `source_evidence.json` 记录三个XML散列、原文/数值、范围断言、相关源码散列。静态断言 PASS，不是运行验收。
- 源链接：[Lava](https://wiki.ifindhs.com/index.php?title=%E9%85%92%E9%A6%86%E6%88%98%E6%A3%8B/%E7%86%94%E5%B2%A9%E6%BD%9C%E4%BC%8F%E8%80%85&oldid=142997)、[Mini](https://wiki.ifindhs.com/index.php?title=%E9%85%92%E9%A6%86%E6%88%98%E6%A3%8B/%E8%BF%B7%E4%BD%A0%E4%BE%8D%E4%BB%8E&oldid=166019)、[Mini-Trident](https://wiki.ifindhs.com/index.php?title=酒馆战棋/迷你三叉戟&oldid=166020)。只从工程中读取这些既存来源，没有声称本次联网复核。

## 2. 当前原生路径已经做了什么

行号均为输入 immutable tree。

1. **获取/原始生成**：公开购买→原 `_unit`→`_add_hand`→公开出牌。`core/game.gd:5261` 在真实随从入场后调用 `_grant_spellcraft`；`15932-15935` 调原 `SpellcraftWaiting.queue_grants/flush`。
2. **Waiting发放**：`core/spellcraft_waiting.gd:59-83,225-247` 验真实在场source、catalog效果和真实ticket。`330-362` 原 `_unit` 分配UID，设置 is_spellcraft/到期标记，扣ticket，再 `_add_hand`。不可在测试中手写token、伪造ticket或改私有账。
3. **消费前验证**：`core/game.gd:4586-4588` 对真实目标手牌塑造调用 `LimitedTurn.target_error`；`core/limited_turn_state.gd:111-145` 验普通上限1、独立ID完整效果，不能把非法 kept 或变金继承清洗掉。
4. **首次保留**：`core/game.gd:5332-5342` 从真实手牌的 temporary/is_spellcraft 与真实 target 效果判定，kept0→1，当前cast局部 temporary=false；原payload正常执行。
5. **其后临时**：`5537-5542` 只有仍temporary的cast记入 temporary_buffs；首次永久不记临时层。`5547` 原施法计数+1，之后完整施法/目标/机制监听仍照常执行。
6. **回合生命周期**：`11028` 清掉未用完的 expires_at_end_turn 手牌，不等于永久附魔失效。下次实际招募 `12027-12046` 清理临时层，然后 `LimitedTurn.reset_turn`；它在 `limited_turn_state.gd:102-105` 令 kept归零。`12150-12153` 真实board塑造源再次排票/发牌。
7. **战斗**：临时层应保留到真实战斗、下次招募才清除。需要在真实战斗日志/下回合原实体上观察，不能直接调用 reset_turn 代替完整回合。

普通 BG23_009 和 `core/timewarped_lava_host.gd` 的时空扭曲复制机制不是同一个来源。后者处理 Giant678家族；普通Lava不应为本次永久保留新增该自动cast体系。无相关modifier时，Balinda等prepare返回 inactive/times1（如 `balinda_spell_host.gd:200-201`），原手牌路径照常走。

## 3. Darkcrest混合房间的三个独立阻塞

**A. 原生Mini来源的获取/入场/EOT还未桥接。**

- `darkcrest_host.gd:77-81` 只承认已登记Lava和暗潮父卡board；Mini会报 other_board_listener_held。
- `184-197` 暗潮激活后只能买暗潮；普通Lava是唯一新增可play的非暗潮随从。即使原Tier1随机结果发出了Mini，公开play仍拒绝。
- `471-478` 完整EOT序列只允许跳过已验证Lava、登记普通暗潮源；不能简单把Mini加入owner白名单后忽略完整EOT观察。

**B. Mini token的实际手牌接纳与cast尚未桥接。**

- `darkcrest_host.gd:86-97,136-139` 将所有非暗潮token交给只接受普通随从的hand_error；BG23_000t会报 other_hand_listener_held。
- `189-197` 非暗潮token也不是许可的play；`begin_cast`的暗潮权限不能借给它。
- 应绑定真实Waiting/factory/手牌命令和精确对象，不得用“看起来像BG23_000t”或只列ID作为成功凭证。提前在无暗潮时发牌再买暗潮，也会撞同一个hand gate。

**C. Lava当前只有未变化身体的custody，没有附魔/kept/回合重置的状态转移。**

- `darkcrest_lava_play.gd:8-17` 调严格hand形状并锁定2/5、kept0；`67,72-76` 将真实入场后完整snapshot固定，任何变化都拒绝。
- 只放开token和Mini也不够：第一张真实+2会变4/5、kept1，立刻不匹配；第二张temporary账和下回合kept重置仍是不同转移。
- 未来必须在真实已认证cast、原临时层清除、原计数重置处观察并提交新的私有expected状态。不能随每次校验重抄live snapshot，不能主动写unit属性来“适配”，不能只允许attack任意增加或kept任意0/1。

所以这项混合联动至少覆盖来源play/Waiting、target cast、跨回合状态三处边界，不是本批sale修复可顺手加的一条白名单。

## 4. 后续最小真实验收方案

### 第一阶段：无Darkcrest的既存原生行为基线（不是新增实现）

- 现有Edwin测试英雄，不用技能；无anomaly/quest/reward/trinket，当前范围room，仅普通Mini和Lava作为目标内容，实际普通池/库存。不启用时空扭曲Lava、Crown、Sushi、Balinda、Portrait、攻击增长监听。
- 通过公开购买/出牌获得1只Lava和2只普通Mini，同一turn各原生发1个token；两Mini不足三连。也可先有一只Mini、同turn再购买并使用第二只。不要直接赋gold/tier/stock/RNG/UID；筹资若沿既有Coin fixture须显式标注，目标卡及token仍必须自然来源。
- 先cast真实第一张到Lava：2/5→4/5、kept1、temporary_buffs无新增、token消费、spells+1。
- 再cast第二张到同一原对象：4/5→6/5、kept仍1、临时账只新增+2攻击一层、又一次真实消费/计数。
- 真实EOT→非空战斗→下次招募：原Lava为4/5、kept0、临时层清掉；永久+2不丢。观察combat使用6攻击，但不要把战斗副本伤害写回招募实体。
- 下一轮由真实Mini再次发牌，再cast第一张：4/5→6/5、kept1、无新临时层；再过一轮永久累积仍6/5。记录未使用新token的真实EOT到期与Waiting取消，不打开满手空位v1-v3。
- 另测本回合第一张打Mini而非Lava不消耗Lava名额；target index随着真实move仍按当前原对象正确选择。
- 有限对照：不同ID/金色/非手牌自动来源/不支持目标不应借此通过。变金、三连、重复自动cast、混合关键词法术另立后续任务。

### 第二阶段：真正新的Darkcrest混合扩展

在第一阶段基线实跑通过后，再精确桥A/B/C，复用真实商店/暗潮输出获得Mini、原Waiting、原cast、原EOT。必须保留原Darkcrest完整随机域，不删候选、不换seed结果后假称随机完整性；若采用有限测试room应独立声明它验证的是组合而非之前全23候选矩阵。

验证至少包括：实际Lava来源身份在cast前后保持；第一/第二/下轮第一次的完整状态转移；暗潮成长/发牌不被Lava计数误消费；原managed token并非目标塑造、不得推进kept；拒绝发生在消费前时所有手牌/RNG/stock/UID/counter不变。第一阶段通过不能替代第二阶段，更不能提升整族支持状态。

## 5. 本批sale/departure的边界提醒

源码已有原生sale operation：`game.gd:6896-6905` 捕获真实owner/sold/index/round/sequence；`7033-7047` 取消source待票、移除原对象、原+1出售收入；`7112-7113` 原pool return和sold计数；完整suffix到 `7154` 才completed。普通未修改Lava仅被 `darkcrest_host.gd:184` 显式hold。

本批应基于已验Lava custody及原sale operation做一次真实departure观察和retirement，检查精确board移除、原收入/stock/sold变化及剩余暗潮回合可继续。**不能只删hold**：旧Lava私有board记录必须退休，防止同对象或同UID重插恢复权限；拒绝重放/假context/晚失败不能冒充完整事务回滚。仅未附魔2/5 kept0普通Lava，Mini和永久buff仍保持未桥接。
