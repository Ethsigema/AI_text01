# Ordinary Lava sale: draft test plan

Status: design/script skeleton only; no Godot execution, no acceptance claim. Read reference: previous verified Lava immutable tree at develop_darkcrest_lava_20261112/remote_snapshot_5d98887/restored_snapshot. New candidate is being prepared separately. Do not modify previous frozen tests.

## Scope and fixtures
One authenticated original BG23_009, ordinary 2/5, kept0, no enchantments. Public native sell must remove the original object, add exactly one gold, one stock and one stats.sold, retire only its original play receipt and clear transaction pending state. No golden/multi-Lava/active rebuy/permanent Spellcraft expansion. Funding uses the disclosed original factory/add_hand/public Coin fixture only before owning Darkcrest; not a wholly natural unfunded match. Never write live RNG, stock, hand, UID, tier, health, or tokens to obtain outcomes.

## Two actual four-player cases
1. Seed20261120, reuse successful complete-current-Tier2 three-candidate acquisition (BG23_002/BG23_009/BG31_924, all positive). Native source purchase/play, Tier1 cast, native EOT to2, actual native Tier2 Lava draw. Public Lava play; actual nonempty opponent boards via public buy/play; native combat and next recruit must preserve original 2/5 kept0. Public move then sell. Snapshot and compare exact native deltas: board loses only same original Lava; every other hand/board reference and value stays; gold+1, stats.sold+1, pool[Lava]+1, all other pool entries unchanged, UID/RNG unchanged. Old original reference absent from every player/ghost board/hand/shop. Old helper board authority is rejected, retained old receipt cannot authorize replay, no pending sale/play remains. Same source EOT→4 and complete current-domain native cast4 still succeeds.
2. Seed20261220, original native shop Lava purchase before any Darkcrest, then the bounded original same-shop two-parent search. No post-source Coin. Source1 EOT→2, insert Lava then source2: [source1,Lava,source2]. Sell Lava publicly before next EOT. Board becomes original sources at indices0/1. Actual EOT produces independent upgrades3/2 and each source's own new grant/token. Do not promise the slow shop search is constant time; bounded failure is preserved, not repaired with injected stock.

## Pure and live rejection contracts (pending final API)
- Pure exact transaction-context shape, each field missing/extra/wrong strict type, owner/unit/nonce copied, same detached context fields mutated. Pure shape acceptance must not imply authority.
- FakeHost.actual=true and fake Game dictionaries/RefCounted cannot issue or complete sale.
- Detached wrong source UID, stale/duplicate receipt, changed kept/stats/foreign markers, wrongowner and missing/unissued play record reject without writes.
- In actual Game: copied unit and wrong owner preflight, fabricated begin/complete and replay only call rejection paths and compare full live snapshots. Never modify real pending context/receipt to force a deep branch.
- Retired original board_error rejection and replay rejection must not mutate pool/gold/sold/RNG/UID/hand/board/other parents.
- Exact API, receipt retirement representation and pure helper coverage await implementer; do not invent success fixtures.

## Execution later
New matrix2cases only, not previous3-case or Tier6 eight-case replay. After source freeze/upload/independent fresh restore and explicit authorization, one serial full Game followed by new pure and agreed old contracts. External wrappers/logs/results, isolated HOME/XDG, before-each-test full source hash and final immutable/run double hash. Report actual counts and limitations, no promotion from draft or synthetic checks.
