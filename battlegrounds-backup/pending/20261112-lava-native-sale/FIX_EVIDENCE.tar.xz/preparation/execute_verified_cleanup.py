from pathlib import Path
import json,gzip,hashlib,fcntl,shutil,datetime,sys
ROOT=Path(__file__).resolve().parents[2];P=Path(__file__).parent
sys.path.insert(0,str(ROOT/'develop_darkcrest_lava_20261112/preparation'))
from run_remote_lava import verify_tree
sha=lambda b:hashlib.sha256(b).hexdigest()
report_bytes=(P/'CLEANUP_PREFLIGHT.json').read_bytes();pre=json.loads(report_bytes)
assert pre['status']=='READ_ONLY_PREFLIGHT_PASS_AWAIT_EXPLICIT_DELETE_AUTHORIZATION' and pre['deleted_paths']==[]
allowed=[ROOT/'develop_darkcrest_lava_20261112/remote_snapshot_5d98887/run_tree',ROOT/'develop_darkcrest_tier6_20261112/remote_snapshot_dd428c2/run_tree']
assert [Path(x['deletion_candidate']) for x in pre['targets']]==allowed
assert not (P/'CLEANUP_EXECUTED.json').exists()
with Path(pre['common_lock']).open('r') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert (P/'CLEANUP_PREFLIGHT.json').read_bytes()==report_bytes
 before=shutil.disk_usage(ROOT)._asdict(); checks=[];preserved=[]
 for row in pre['targets']:
  target=Path(row['deletion_candidate']); replacement=Path(row['equivalent_preserved_replacement']);r=target.parent;s=r.parent
  assert target.resolve()==target and replacement.resolve()==replacement and not target.is_symlink()
  manifest_bytes=(r/'package/MANIFEST.json').read_bytes();assert sha(manifest_bytes)==row['source_manifest_sha256'];m=json.loads(manifest_bytes)
  assert sha(Path(row['publication_receipt']).read_bytes())==row['publication_receipt_sha256']
  raw=gzip.decompress((r/'package/SOURCE_MAP.json.gz').read_bytes());assert sha(raw)==row['source_map_sha256'];expected=json.loads(raw)
  a,am=verify_tree(target,expected,m['aggregate_sha256']);b,bm=verify_tree(replacement,expected,m['aggregate_sha256']);assert a==b==row['runtime'] and am==bm
  for x in s.rglob('*'):
   if x.is_dir() and (x.name in {'independent_tests','restored_snapshot','candidate','package'} or 'package' in x.name or 'audit' in x.name) and target not in x.parents and x!=target:preserved.append(x)
  preserved += [replacement,r/'independent_tests',r/'package',s/'candidate',s/'unaccepted_package',s/'restore_receipt_package',s/'final_package']
  checks.append({'path':str(target),'replacement':str(replacement),'rehash':a})
 assert all(x.is_dir() for x in preserved)
 # Both targets are verified before either is removed; only exact allowlisted paths.
 for target in allowed:shutil.rmtree(target)
 assert all(not x.exists() for x in allowed) and all(x.is_dir() for x in preserved)
 after=shutil.disk_usage(ROOT)._asdict()
 result={'status':'AUTHORIZED_TWO_REDUNDANT_RUNTIME_COPIES_REMOVED','executed_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'preflight_sha256':sha(report_bytes),'exclusive_common_lock_held':True,'deleted_paths':[str(x) for x in allowed],'checks':checks,'before_disk':before,'after_disk':after,'available_bytes_change':after['free']-before['free'],'preserved_directories_confirmed':sorted(set(str(x) for x in preserved)),'backups_deleted':False,'source_edits':False}
 with (P/'CLEANUP_EXECUTED.json').open('x') as f:json.dump(result,f,indent=2)
 print(json.dumps({k:v for k,v in result.items() if k not in {'preserved_directories_confirmed','checks'}},indent=2),flush=True)
 # Independent new candidate: never hardlink, never modify restored source.
 source=ROOT/'develop_darkcrest_lava_20261112/remote_snapshot_5d98887/restored_snapshot';candidate=P.parent/'candidate';assert not candidate.exists()
 shutil.copytree(source,candidate)
 raw=gzip.decompress((source.parent/'package/SOURCE_MAP.json.gz').read_bytes());m=json.loads((source.parent/'package/MANIFEST.json').read_text());actual,_=verify_tree(candidate,json.loads(raw),m['aggregate_sha256'])
 result={'status':'NEW_CANDIDATE_EXACT_VERIFIED_LAVA_PREIMAGE_NO_SOURCE_EDITS','created_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source':str(source),'candidate':str(candidate),'source_commit':'5d988875054ad4eea47d6615f8a9fdd65bfe7b4d','final_commit':'527decb1dead1b309faaa0086563ab88780968b8','source_map_sha256':sha(raw),'candidate_verified':actual,'disk':shutil.disk_usage(ROOT)._asdict(),'scope':'ordinary Lava native sell/departure plus later Darkcrest EOT; no permanent Mini interaction or active rebuy'}
 with (P/'CANDIDATE_PREIMAGE_VERIFIED.json').open('x') as f:json.dump(result,f,indent=2)
 print(json.dumps(result,indent=2),flush=True)
