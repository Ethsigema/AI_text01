"""Read-only proof of exact runtime-copy redundancy; no deletion capability."""
from pathlib import Path
import json,gzip,hashlib,fcntl,datetime,sys,os
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'develop_darkcrest_lava_20261112/preparation'))
from run_remote_lava import verify_tree
sha=lambda b:hashlib.sha256(b).hexdigest()
read=lambda p:json.loads(p.read_text())
lockpath=ROOT/'develop_empty_ghost_20261112/.independent_full_game.lock'
with lockpath.open('r') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 rows=[]
 for stage,snap,source,final in [
 ('develop_darkcrest_lava_20261112','remote_snapshot_5d98887','5d988875054ad4eea47d6615f8a9fdd65bfe7b4d','527decb1dead1b309faaa0086563ab88780968b8'),
 ('develop_darkcrest_tier6_20261112','remote_snapshot_dd428c2','dd428c21867d4c15340ff6d4d8868d027d1067e4','15dcc5752827322968ca08d5643fa03ba7cf6934')]:
  s=ROOT/stage;r=s/snap;p=r/'package';m=read(p/'MANIFEST.json');raw=gzip.decompress((p/'SOURCE_MAP.json.gz').read_bytes());assert sha(raw)==m['source_map_sha256'];expected=json.loads(raw)
  pub=read(s/'FINAL_PUBLICATION_VERIFIED.json');assert pub['commit']==final and pub['source_commit']==source and pub['status']=='PASS_FINAL_PUBLICATION_FRESH_BYTES_AND_ALL_GAMEPLAY_EVIDENCE_MEMBERS'
  for name in ['MANIFEST.json','SOURCE_MAP.json.gz','delta.tar.xz']:
   assert sha((p/name).read_bytes())==pub['immutable_source_files_match_fixed_source_commit'][name]
  game=read(r/'INDEPENDENT_GAME_VERIFICATION.json');assert game['source_commit']==source and game['source_map_sha256']==m['source_map_sha256'];assert sha((r/'INDEPENDENT_GAME_VERIFICATION.json').read_bytes())==pub['gameplay_receipt_sha256']
  runtime,runmap=verify_tree(r/'run_tree',expected,m['aggregate_sha256']);replacement,restoremap=verify_tree(r/'restored_snapshot',expected,m['aggregate_sha256']);assert runmap==restoremap and runtime==replacement
  for tree in ['run_tree','restored_snapshot']:assert game['trees'][tree]==runtime
  paths=list((r/'run_tree').rglob('*'));assert all(x.is_file() or x.is_dir() for x in paths)
  allocated=sum(x.stat().st_blocks*512 for x in paths)+(r/'run_tree').stat().st_blocks*512
  rows.append({'deletion_candidate':str(r/'run_tree'),'equivalent_preserved_replacement':str(r/'restored_snapshot'),'source_commit':source,'final_commit':final,'source_map_sha256':m['source_map_sha256'],'runtime':runtime,'replacement':replacement,'unique_files':[],'logical_reclaimable_bytes':runtime['bytes'],'estimated_allocated_bytes_including_directories':allocated,'publication_receipt':str(s/'FINAL_PUBLICATION_VERIFIED.json'),'publication_receipt_sha256':sha((s/'FINAL_PUBLICATION_VERIFIED.json').read_bytes()),'source_manifest_sha256':sha((p/'MANIFEST.json').read_bytes()),'game_results_remain_at':str(r/'independent_tests')})
 report={'status':'READ_ONLY_PREFLIGHT_PASS_AWAIT_EXPLICIT_DELETE_AUTHORIZATION','checked_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'common_lock':str(lockpath),'exclusive_common_lock_acquired_during_all_hashing':True,'cooperating_full_game_runner_not_active_confirmed_by_lock':True,'no_process_list_inference':True,'user_parent_reports_test_sessions_exited':True,'targets':rows,'total_logical_reclaimable_bytes':sum(x['logical_reclaimable_bytes'] for x in rows),'total_estimated_allocated_bytes':sum(x['estimated_allocated_bytes_including_directories'] for x in rows),'deleted_paths':[],'preserved':'All independent_tests/logs, candidates, immutable restored snapshots, source/early/final/audit backup packages and other paths.','fresh_large_downloads':False}
 out=Path(__file__).parent/'CLEANUP_PREFLIGHT.json'
 with out.open('x') as f:json.dump(report,f,indent=2)
 print(json.dumps(report,indent=2))
