"""Archive only completed restore receipts/tools; never touches live Game evidence."""
from pathlib import Path
import json,hashlib,shutil,tarfile,io,datetime
ROOT=Path(__file__).resolve().parent.parent;R=ROOT/'remote_snapshot_73ef3f4';P=ROOT/'restore_receipt_package'
def sha(b):return hashlib.sha256(b).hexdigest()
def enc(j):return (json.dumps(j,indent=2,sort_keys=True)+'\n').encode()
def main():
 import argparse
 ap=argparse.ArgumentParser();ap.add_argument('--execute',action='store_true',required=True);ap.parse_args()
 assert not P.exists();d=json.loads((R/'FRESH_PACKAGE_DOWNLOAD_VERIFIED.json').read_text());assert d['source_commit']=='73ef3f42e2a52b71aacd29fac2d6392731015d9d' and d['files']==17
 for row in d['records']:
  b=(R/'package'/row['filename']).read_bytes();assert len(b)==row['bytes'] and sha(b)==row['sha256']
 restore=json.loads((R/'INDEPENDENT_RESTORE_VERIFIED.json').read_text());assert restore['source_commit']==d['source_commit'] and not restore['game_started'] and not restore['gameplay_acceptance']
 fixed=json.loads((R/'FIX_EVIDENCE_VERIFIED.json').read_text());assert fixed['members']==29 and fixed['every_member_rehashed']
 shutil.copytree(R/'package',P)
 tools={}
 names=['preparation/run_remote_lava_sale.py','preparation/audit_lava_sale_attempt.py','preparation/RUNNER_HELP.txt','preparation/RUNNER_STATIC_NOTES.md','preparation/PREPARATION_DEPENDENCIES_SHA256.json','preparation/prepare_restore_receipt.py','preparation/repin_candidate.py','preparation/synthetic_sale_validator_tests.py','preparation/SYNTHETIC_SALE_VALIDATOR_RESULT.json','fresh_remote/download_fresh.py','fresh_remote/verify_baseline.py','fresh_remote/snapshot_tools/common.py','fresh_remote/snapshot_tools/build_unaccepted.py','fresh_remote/snapshot_tools/add_frozen_evidence.py','fresh_remote/snapshot_tools/restore_fixed_remote.py','fresh_remote/snapshot_tools/verify_remote_evidence.py','fresh_remote/snapshot_tools/PREPARATION_VERIFIED.json','fresh_remote/snapshot_tools/FIXED_REMOTE_73ef3f4_METADATA.json']
 selected={n:sha((ROOT/n).read_bytes()) for n in names}
 assert selected['preparation/run_remote_lava_sale.py']=='f94639381df808f94bf62bd2de0a0c0dd6b46237c781dde9a5ace4fcb3425813'
 assert selected['preparation/audit_lava_sale_attempt.py']=='af70b929e14231f0c6d0f15a4f6358790b2816f922377980f9ea1c402562f0a4'
 (ROOT/'RESTORE_TOOL_SELECTION.json').write_bytes(enc(selected))
 for n in names:
  p=ROOT/n;before=p.stat();b=p.read_bytes();after=p.stat();assert (before.st_size,before.st_mtime_ns)==(after.st_size,after.st_mtime_ns),n;assert sha(b)==selected[n],n;tools[n]=b
 tools['TOOL_SNAPSHOT_NOTE.json']=enc({'captured_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'completed tool source snapshot only; no live test logs or HOME/cache','gameplay_acceptance':False,'some_tools_are_prepared_not_executed':True})
 with tarfile.open(P/'TOOLS_EVIDENCE.tar.xz','w:xz') as t:
  for n,b in sorted(tools.items()):
   x=tarfile.TarInfo(n);x.size=len(b);x.mode=0o644;x.mtime=0;t.addfile(x,io.BytesIO(b))
 members={n:{'bytes':len(b),'sha256':sha(b)} for n,b in tools.items()}
 with tarfile.open(P/'TOOLS_EVIDENCE.tar.xz') as t:assert {x.name:{'bytes':x.size,'sha256':sha(t.extractfile(x).read())} for x in t}==members
 (P/'TOOLS_EVIDENCE_MANIFEST.json').write_bytes(enc({'source_commit':d['source_commit'],'archive_sha256':sha((P/'TOOLS_EVIDENCE.tar.xz').read_bytes()),'members':members}))
 for source,dest in [('INDEPENDENT_RESTORE_VERIFIED.json','REMOTE_SNAPSHOT_RESTORE_VERIFIED.json'),('FIX_EVIDENCE_VERIFIED.json','REMOTE_FIX_EVIDENCE_VERIFIED.json'),('FRESH_PACKAGE_DOWNLOAD_VERIFIED.json','REMOTE_SNAPSHOT_DOWNLOAD_VERIFIED.json'),('CANDIDATE_REMOTE_RESTORE_DOUBLE_REHASH.json','CANDIDATE_REMOTE_RESTORE_DOUBLE_REHASH.json')]:shutil.copyfile(R/source,P/dest)
 (P/'RESTORE_VERIFIED.md').write_text('# Fixed ordinary Lava sale/departure source restoration only, gameplay still unaccepted\n\nSource commit 73ef3f42e2a52b71aacd29fac2d6392731015d9d. All 17 files were actually freshly downloaded and checked by size/Git SHA/SHA256; all 29 source-evidence members were rehashed. Same-stage 55 prerequisites were separately freshly downloaded, then rehashed for restoration.\n\nActual independent restoration and second full read: 27,975 files, 1,550,759,040 bytes; source map 1d03c1d09e8a8387dd1943aae62a8c368bf509a859f4fffd8d8fafd25b8c4084, aggregate c6b2446cac072bb68b8a3cd5937218732bb747fcf08512510a370233ea4fdedd, no differences.\n\nThis receipt proves bytes only. No completed gameplay acceptance is claimed. Tools include prepared but not executed future outcome/publication helpers. No live Game logs, process state, HOME/cache or hypothetical results are archived. Original 17-file source package remains preserved unchanged in its original directory and fixed source commit; only the checksum file of this separate receipt copy is regenerated. No paused empty-slot candidate source is included. Scope is single ordinary Lava sale/departure and later Darkcrest EOT, not permanent Mini or active rebuy. Only batch14 was freshly restored as the preimage base; no extra old Lava tree was restored in this stage.\n')
 (P/'SHA256SUMS.txt').write_text(''.join(sha(p.read_bytes())+'  '+p.name+'\n' for p in sorted(P.iterdir()) if p.is_file() and p.name!='SHA256SUMS.txt'))
 old={x['filename']:x for x in d['records']};records=[];changed=[]
 for p in sorted(P.iterdir()):
  b=p.read_bytes();row={'name':p.name,'bytes':len(b),'sha256':sha(b),'git_sha':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()};records.append(row)
  if p.name not in old or old[p.name]['sha256']!=row['sha256']:changed.append(row)
 assert [x['name'] for x in changed if x['name'] in old]==['SHA256SUMS.txt']
 report={'status':'LOCAL_BYTES_ONLY_RECEIPT_READY_NOT_PUBLISHED','source_commit':d['source_commit'],'folder':'battlegrounds-backup/pending/20261112-lava-native-sale','files':len(records),'bytes':sum(x['bytes'] for x in records),'tool_members':len(members),'records':records,'changed_records':changed}
 (ROOT/'RESTORE_RECEIPT_UPLOAD_METADATA.json').write_bytes(enc(report));print(json.dumps({k:v for k,v in report.items() if k not in ['records','changed_records']},indent=2));print('CHANGED',','.join(x['name'] for x in changed))
if __name__=='__main__':main()
