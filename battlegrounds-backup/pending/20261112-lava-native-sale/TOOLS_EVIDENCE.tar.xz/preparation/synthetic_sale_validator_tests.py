"""Synthetic Python fixtures only, not Godot acceptance."""
from pathlib import Path
import ast,copy,json,re,tempfile
import run_remote_lava_sale as r

def main():
 checks=[]
 assert len(r.TESTS)==8 and [x[3] for x in r.TESTS]==[None,140,211,966,810,68,166,267]
 checks.append('one_game_seven_pure_order')
 retirement={'owner':0,'round':3,'sequence':20}
 def choices(ids):return [{'id':i,'stock':3} for i in ids]
 first={'kind':'generated_lava_combat_move_sale','seed':20261120,'departed_uid':'u2','source_uid':'u1','source_tier':4,'retirement':retirement,'tier2_choices':choices(['BG23_002','BG23_009','BG31_924']),'post_sale_tier4_choices':choices(['BG26_505','BG33_319','BG34_925','BG35_921','BG36_508'])}
 dual={'kind':'two_sources_sale_reindex','seed':20261220,'departed_uid':'u5','source_uids':['u3','u4'],'actual_board_indices':[0,1],'source_tiers':[3,2],'retirement':retirement}
 effects=[dict(uid=uid,index=1,gold_before=4,gold_after=5,stock_before=4,stock_after=5,sold_before=0,sold_after=1,uid_before=20,uid_after=20,rng_before=123,rng_after=123,retirement=retirement) for uid in ['u2','u5']]
 source=Path(r.__file__).read_text();markers=ast.literal_eval(re.search(r'for marker,n in (\[.*?\]):',source).group(1))
 lines=['PASS '+m for m,n in markers for _ in range(n)]
 scenario=dict(scope='ordinary authenticated untouched Lava native sale and retirement only',checks=len(lines)-1,cases=[first,dual],sale_effects=effects,old_lava_three_cases_repeated=False,entirely_natural_game=False,partial_failure_live_injection=False,active_rebuy_opened=False,coin_pre_source_fixture=True,no_live_state_injection=True,combat_damage=[])
 with tempfile.TemporaryDirectory(prefix='sale-validator-') as temp:
  d=Path(temp)
  def validate(s):
   (d/'DARKCREST_LAVA_SALE_MATRIX_RESULT.json').write_text(json.dumps(s))
   log='\n'.join(lines+['DARKCREST_LAVA_SALE_CASE_PASS '+json.dumps(x) for x in s['cases']]+['ACQUIRED '+json.dumps(dict(tier=4,source_uid='u1',id='BG26_505',pool_before=3,pool_after=2)),'DARKCREST_LAVA_SALE_REAL_MATRIX_PASS cases=2 checks='+str(len(lines))])
   r.validate('lava_sale_real_matrix',log,None,d)
  validate(scenario);checks.append('two_case_positive')
  def negative(name,mutate):
   s=copy.deepcopy(scenario);mutate(s)
   try:validate(s)
   except AssertionError:checks.append(name);return
   raise AssertionError('accepted '+name)
  negative('wrong_gold_delta',lambda s:s['sale_effects'][0].update(gold_after=6))
  negative('wrong_stock_delta',lambda s:s['sale_effects'][0].update(stock_after=4))
  negative('wrong_sold_delta',lambda s:s['sale_effects'][0].update(sold_after=0))
  negative('float_gold',lambda s:s['sale_effects'][0].update(gold_after=5.0))
  negative('rng_mutation',lambda s:s['sale_effects'][0].update(rng_after=124))
  negative('uid_mutation',lambda s:s['sale_effects'][0].update(uid_after=21))
  negative('wrong_source_indices',lambda s:s['cases'][1].update(actual_board_indices=[0,2]))
  negative('wrong_seed',lambda s:s['cases'][0].update(seed=1))
  negative('missing_tier4_candidate',lambda s:s['cases'][0]['post_sale_tier4_choices'].pop())
  negative('active_rebuy_claim',lambda s:s.update(active_rebuy_opened=True))
  negative('retirement_owner',lambda s:s['sale_effects'][0]['retirement'].update(owner=1))
  summary=dict(passed=140,failed=0,failures=[],scope='detached sale context and authority rejection observations only',real_game_run=False,live_capacity_tested=False,partial_failure_live_injection=False)
  r.validate('lava_sale_content_contract','\n'.join(['PASS fixture']*140+['DARKCREST_LAVA_SALE_CONTENT_CONTRACT '+json.dumps(summary)]),140,d);checks.append('pure140_summary')
  tree=d/'tree';tree.mkdir();(tree/'a').write_bytes(b'a');expected={'a':{'bytes':1,'sha256':r.sha(b'a')}};aggregate=r.sha(b'a\0' + b'1\0a')
  r.verify_tree(tree,expected,aggregate);checks.append('exact_tree')
  (tree/'a').write_bytes(b'b')
  try:r.verify_tree(tree,expected,aggregate)
  except AssertionError:checks.append('changed_tree_rejected')
  else:raise AssertionError('corruption accepted')
 print(json.dumps(dict(status='PASS_SYNTHETIC_VALIDATOR_ONLY',checks=checks,passed=len(checks),godot_started=False,game_started=False),indent=2))
if __name__=='__main__':main()
