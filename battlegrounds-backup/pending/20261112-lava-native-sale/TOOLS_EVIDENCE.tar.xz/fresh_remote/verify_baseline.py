from pathlib import Path
import json,gzip,sys,tarfile,subprocess
R=Path(__file__).resolve().parent;sys.path.insert(0,str(R/'snapshot_tools'))
from common import verify,sha,dump,write,utc,safe
D=json.loads((R/'FRESH_DOWNLOAD_VERIFIED.json').read_text());assert D['files']==55
for row in D['records']:
 b=(R/row['filename']).read_bytes();assert len(b)==row['bytes'] and sha(b)==row['sha256']
for package in ['base_package','lava_package']:
 checked=set()
 for line in (R/package/'SHA256SUMS.txt').read_text().splitlines():
  h,n=line.split('  ',1);assert safe(n) and '/' not in n and n not in checked;assert sha((R/package/n).read_bytes())==h;checked.add(n)
 assert checked=={p.name for p in (R/package).iterdir() if p.is_file()}-{'SHA256SUMS.txt'}
base_bytes=gzip.decompress((R/'base_package/SOURCE_MAP.json.gz').read_bytes());base=json.loads(base_bytes)
assert sha(base_bytes)=='7fec8d69e82de8bfcb7373549951f9456671b5c3980135d6ec6f983a3daf5ed7'
m=json.loads((R/'lava_package/MANIFEST.json').read_text());target=dict(base)
for n in m['removed']:del target[n]
target.update(m['changed_files']);encoded=dump(target)
assert sha(encoded)=='e84edfaea8bf19ee8650f179cb48d9093915a99ef5d0a54adebb3a01fc9b33c3'
assert gzip.decompress((R/'lava_package/SOURCE_MAP.json.gz').read_bytes())==encoded
prior=json.loads((R.parent/'preparation/CANDIDATE_PREIMAGE_VERIFIED.json').read_text());assert prior['source_map_sha256']==sha(encoded) and prior['candidate_verified']['aggregate_sha256']==m['aggregate_sha256']
with (R/'LAVA_SOURCE_MAP.json').open('xb') as f:f.write(encoded)
counts={}
for prefix,count in [('FIX',23),('TOOLS',19),('GAMEPLAY',50)]:
 meta=json.loads((R/f'lava_package/{prefix}_EVIDENCE_MANIFEST.json').read_text());expected=meta if prefix=='FIX' else meta['members'];seen=set()
 if prefix!='FIX':assert meta['source_commit']=='5d988875054ad4eea47d6615f8a9fdd65bfe7b4d' and sha((R/f'lava_package/{prefix}_EVIDENCE.tar.xz').read_bytes())==meta['archive_sha256']
 with tarfile.open(R/f'lava_package/{prefix}_EVIDENCE.tar.xz') as t:
  for x in t:
   assert x.isfile() and safe(x.name) and x.name not in seen
   b=t.extractfile(x).read();assert {'bytes':len(b),'sha256':sha(b)}==expected[x.name];seen.add(x.name)
 assert seen==set(expected) and len(seen)==count;counts[prefix]=count
assert sha((R/'lava_package/GAMEPLAY_INDEPENDENT_VERIFICATION.json').read_bytes())=='a89342529aa8202dd08ff21b386484c666b43e0590b3bfeb75afc5b0298e18fb'
write(R/'CURRENT_EVIDENCE_VERIFIED.json',{'status':'PASS_FRESH_LAVA_ALL_THREE_EVIDENCE_ARCHIVES','members':counts,'checked_at_utc':utc(),'historical_tests_not_current_execution':True})
write(R/'LAVA_PREIMAGE_METADATA_VERIFIED.json',{'status':'PASS_FRESH_LAVA_MAP_ONLY_NO_NEW_LAVA_TREE_RESTORE','fixed_commit':'527decb1dead1b309faaa0086563ab88780968b8','source_commit':'5d988875054ad4eea47d6615f8a9fdd65bfe7b4d','source_map_sha256':sha(encoded),'aggregate_sha256':m['aggregate_sha256'],'previous_candidate_preedit_report_sha256':sha((R.parent/'preparation/CANDIDATE_PREIMAGE_VERIFIED.json').read_bytes()),'fresh_lava_tree_restored':False,'current_editing_candidate_read_or_changed':False})
with (R/'BASE_RESTORE.log').open('x') as log:
 subprocess.run(['python',str(R/'base_package/restore.py'),'--base-zip',str(R/'original_release.zip'),'--destination',str(R/'restored_base'),'--report',str(R/'BASE_RESTORE_CURRENT.json')],stdout=log,stderr=subprocess.STDOUT,check=True)
tree=verify(R/'restored_base',base,'5ba04ef124fc78cf20e2a942a60589fb92dc76e6808155648226a534a4599e05')
write(R/'CURRENT_RECOVERY_VERIFIED.json',{'status':'PASS_FRESH_DEPENDENCIES_BASE_RESTORE_ONLY_LAVA_PREIMAGE_METADATA','checked_at_utc':utc(),'fixed_commit':'527decb1dead1b309faaa0086563ab88780968b8','source_commit':'5d988875054ad4eea47d6615f8a9fdd65bfe7b4d','fresh_download_files':55,'fresh_download_bytes':D['bytes'],'source_map_sha256':sha(encoded),'trees':{'restored_base':tree},'fresh_lava_tree_restored':False,'game_started':False,'uploads':0,'old_download_bytes_reused':False,'old_files_preserved':True})
print('PASS_55_FRESH_DOWNLOADS_BASE_ONLY_RESTORE_NO_LAVA_RESTORE',tree,flush=True)
