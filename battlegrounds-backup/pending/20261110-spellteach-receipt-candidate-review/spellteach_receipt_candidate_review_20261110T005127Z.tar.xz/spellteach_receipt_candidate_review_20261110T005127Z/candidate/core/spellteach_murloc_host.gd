extends RefCounted
## Actual purchase capability. Neither public events nor generated additions
## can issue this ticket. Quota advances at the real bought-listener stage.
const Sources=preload("res://core/spellteach_murloc_sources.gd")
const Cast=preload("res://core/spellteach_murloc_cast.gd")
const Actual=preload("res://core/duelist_refresh.gd")
const Pure=preload("res://core/recruit_gem_dr_host.gd")
const Delivery=preload("res://core/accepted_card_cursor_projection.gd")
const Owned=preload("res://core/spellteach_trinket_host.gd")
const POLICY: String="actual_bought_spell_uid_round_same_native_child_minion_cast_v1"
static func fail(issue: String) -> Dictionary: return {"ok":false,"error":issue,"active":false}
static func actual(engine,p: Dictionary) -> bool: return Actual._actual_game_host(engine) and engine.state.get("phase")=="recruit" and p.get("alive")==true and engine.state.players.any(func(owner):return is_same(owner,p))
static func sources(p: Dictionary,round_number: int) -> Array:
	return p.get("board",[]).filter(func(unit):return unit.get("card_id") in Sources.PARENTS and Pure.Gains.active(unit) and used(unit,round_number)<int(Sources.PROGRAMS[unit.card_id][0].limit))
static func used(unit: Dictionary,round_number: int) -> int: return int(unit.get(Sources.QUOTA,{}).get("used",0)) if unit.get(Sources.QUOTA,{}).get("round")==round_number else 0
static func snapshot(engine,p: Dictionary) -> Dictionary:
	return {"player":p.duplicate(true),"totals":engine._attack_gain_health_totals.duplicate(true),"next_uid":engine.next_uid,"rng_seed":engine.rng.seed,"rng_state":engine.rng.state,"pool":engine.pool.duplicate(true),"spell_pool":engine.spell_pool.duplicate(true)}
static func projected(state: Dictionary) -> Dictionary:
	return {"player":state.player.duplicate(true),"totals":state.totals.duplicate(true),"next_uid":state.next_uid,"rng_seed":state.rng_seed,"rng_state":state.rng_state,"pool":state.pool.duplicate(true),"spell_pool":state.spell_pool.duplicate(true)}
static func spell_error(engine,spell: Dictionary) -> String:
	var id: String=str(spell.get("card_id",""));var card: Dictionary=engine.catalog.get_card(id)
	if spell.get("kind")!="spell" or not engine.Mechanisms.is_tavern_spell_card(card): return "spellteach_actual_tavern_spell_required"
	var issue: String=Cast.card_error(engine.catalog,id)
	if not issue.is_empty(): return issue
	if not Sources.uid(spell.get("uid")) or spell.get("golden",false) or spell.get("temporary",false) or spell.get("is_spellcraft",false) or not Sources.same(spell.get("effects"),card.get("effects")) or not Sources.same(spell.get("keywords",[]),card.get("keywords",[])): return "spellteach_modified_spell_program_partial"
	for key in ["dynamic_spell_enchantments","attachments"]:
		if not spell.get(key,[]).is_empty(): return "spellteach_enchanted_spell_teaching_partial"
	return ""
static func _observers_error(engine,p: Dictionary) -> String:
	# Hand-add native callbacks have an existing complete cumulative projector.
	# Other purchase/spend generators need an explicit shared-order bridge.
	for unit in p.board:
		if unit.get("card_id") in Sources.PARENTS: continue
		var hand: Dictionary=Delivery.hand_reader(engine,unit)
		if hand.claimed:
			if not str(hand.error).is_empty(): return str(hand.error)
			continue
		for effect in unit.get("effects",[]):
			if engine.DiscardHost._has_read(effect,["buy","purchase","spend"]): return "spellteach_competing_purchase_prefix_partial:"+str(effect.get("type",""))
	for effect in engine.Mechanisms._effects(engine,p)+engine.catalog.get_card(str(p.get("hero_id",""))).get("effects",[]):
		if engine.DiscardHost._has_read(effect,["buy","purchase","spend"]): return "spellteach_owned_purchase_prefix_partial"
	if not p.get("mechanism_reward_queue",[]).is_empty(): return "spellteach_pending_protected_delivery_order_partial"
	return ""
static func prepare_buy(engine,p: Dictionary,spell: Dictionary,quoted: Dictionary,issued: bool=true) -> Dictionary:
	if spell.get("kind")!="spell" or not engine.Mechanisms.is_tavern_spell_card(engine.catalog.get_card(str(spell.get("card_id","")))) or sources(p,int(engine.state.round)).is_empty(): return {"ok":true,"error":"","active":false}
	if not actual(engine,p) or not p.shop.any(func(unit):return is_same(unit,spell)): return fail("spellteach_actual_shop_offer_required")
	if not engine._spellteach_buy_context.is_empty(): return fail("spellteach_nested_buy")
	var issue: String=saved_error(engine.state,engine.catalog,engine.events)
	if issue.is_empty(): issue=Sources.closure_error(engine.catalog)
	if issue.is_empty(): issue=spell_error(engine,spell)
	if issue.is_empty(): issue=_observers_error(engine,p)
	if not issue.is_empty(): return fail(issue)
	if not quoted.get("ok",false) or not Sources.integer(quoted.get("cost")) or ["health_currency","bouncy_health_offer","eye_sargeras_health","tapestry_health_currency","owned_health_currency","bazaar","pilgrimp"].any(func(key):return quoted.get(key,false)): return fail("spellteach_non_gold_quote_partial")
	if p.hand.size()+1+sources(p,int(engine.state.round)).size()>10: return fail("spellteach_overflow_quota_semantics_partial")
	var command: Dictionary=engine._bounty_spend_command
	if issued and (not is_same(command.get("owner"),p) or command.get("action")!="buy" or command.get("round")!=engine.state.round or command.get("sequence")!=engine.state.command_sequence): return fail("spellteach_real_buy_command_required")
	var records: Array=[]
	for source in sources(p,int(engine.state.round)):
		issue=Sources.unit_error(source,engine.catalog)
		if not issue.is_empty(): return fail(issue)
		records.append({"source":source,"uid":source.uid,"id":source.card_id,"before":source.get(Sources.QUOTA,{}).duplicate(true),"used":used(source,int(engine.state.round)),"done":false})
	# Preflight complete accepted purchased-spell plus generated-minion domain.
	var state: Dictionary=Pure._state(engine,p);state.next_uid=engine.next_uid;state.pool=engine.pool.duplicate(true);state.spell_pool=engine.spell_pool.duplicate(true)
	issue=Delivery.project(engine,state,spell.duplicate(true),true)
	if not issue.is_empty(): return fail(issue)
	for record in records:
		var child: Dictionary=engine._preview_native_minion(engine.catalog.get_card(Sources.CHILD),"u"+str(state.next_uid))
		if child.is_empty(): return fail("spellteach_native_child_factory_rejected")
		state.next_uid+=1
		issue=Delivery.project(engine,state,child)
		if not issue.is_empty(): return fail(issue)
	return {"ok":true,"error":"","active":true,"owner":p,"spell":spell,"spell_id":spell.card_id,"spell_uid":spell.uid,"spell_program":spell.effects.duplicate(true),"command":command,"round":engine.state.round,"sequence":engine.state.command_sequence,"cost":quoted.cost,"gold_before":p.gold,"bought_before":p.stats.bought,"paid":false,"records":records}
static func mark_paid(engine,p: Dictionary,spell: Dictionary,cost: int) -> String:
	var ticket: Dictionary=engine._spellteach_buy_context
	if ticket.is_empty(): return ""
	if not actual(engine,p) or not is_same(ticket.owner,p) or not is_same(ticket.spell,spell) or not is_same(ticket.command,engine._bounty_spend_command) or ticket.paid or cost!=ticket.cost or p.gold!=ticket.gold_before-cost: return "spellteach_actual_payment_changed"
	ticket.paid=true;return ""
static func dispatch(engine,p: Dictionary,spell: Dictionary,source: Dictionary) -> String:
	var ticket: Dictionary=engine._spellteach_buy_context
	if ticket.is_empty(): return ""
	var records: Array=ticket.records.filter(func(row):return is_same(row.source,source))
	if records.is_empty(): return ""
	var record: Dictionary=records[0]
	if not actual(engine,p) or not is_same(ticket.owner,p) or not is_same(ticket.spell,spell) or not is_same(ticket.command,engine._bounty_spend_command) or ticket.round!=engine.state.round or ticket.sequence!=engine.state.command_sequence or not ticket.paid or record.done or p.stats.bought!=ticket.bought_before+1 or p.shop.any(func(unit):return is_same(unit,spell)) or not p.hand.any(func(unit):return is_same(unit,spell)): return "spellteach_unissued_successful_purchase"
	if not p.board.any(func(unit):return is_same(unit,source)) or source.uid!=record.uid or source.card_id!=record.id or not Pure.Gains.active(source) or not Sources.same(source.get(Sources.QUOTA,{}),record.before) or spell.uid!=ticket.spell_uid or spell.card_id!=ticket.spell_id or not Sources.same(spell.effects,ticket.spell_program): return "spellteach_original_source_or_spell_changed"
	if p.hand.size()>=10: return "spellteach_unplanned_delivery_capacity_change"
	var state: Dictionary=Pure._state(engine,p);state.next_uid=engine.next_uid;state.pool=engine.pool.duplicate(true);state.spell_pool=engine.spell_pool.duplicate(true)
	var quota: Dictionary={"uid":source.uid,"id":source.card_id,"owner":p.id,"round":engine.state.round,"used":int(record.used)+1}
	Pure.Gains._find(state.player.board,str(source.uid))[Sources.QUOTA]=quota.duplicate(true)
	var child: Dictionary=engine._preview_native_minion(engine.catalog.get_card(Sources.CHILD),"u"+str(state.next_uid))
	if child.is_empty(): return "spellteach_native_child_factory_failed"
	child.pool_count=0;child.pool_id="";child.pool_components=[];state.next_uid+=1
	child[Sources.TAUGHT]={"uid":child.uid,"owner":p.id,"source_id":source.card_id,"source_uid":source.uid,"purchased_uid":spell.uid,"spell_id":spell.card_id,"round":engine.state.round,"sequence":engine.state.command_sequence,"spell_program":spell.effects.duplicate(true)}
	var expected_child: Dictionary=child.duplicate(true)
	var issue: String=Delivery.project(engine,state,child)
	if not issue.is_empty(): return issue
	record.done=true;source[Sources.QUOTA]=quota
	var generated: Dictionary=engine._unit(engine.catalog.get_card(Sources.CHILD))
	generated.pool_count=0;generated.pool_id="";generated.pool_components=[];generated[Sources.TAUGHT]=expected_child[Sources.TAUGHT].duplicate(true)
	if not Sources.same(generated,expected_child): return "spellteach_actual_child_factory_changed"
	engine._add_hand(p,generated)
	if engine.state.phase=="error": return "spellteach_actual_accepted_child_failed"
	if not Sources.same(snapshot(engine,p),projected(state)): return "spellteach_accepted_hand_cursor_changed"
	engine._log("native_spellteach_acquired",{"player":p.id,"source_id":source.card_id,"source_uid":source.uid,"bought_uid":spell.uid,"spell_id":spell.card_id,"child_id":Sources.CHILD,"child_uid":generated.uid,"binding":generated[Sources.TAUGHT].duplicate(true),"used":quota.used,"round":engine.state.round,"sequence":engine.state.command_sequence,"policy":POLICY})
	return ""
static func finish_buy(engine) -> String:
	var ticket: Dictionary=engine._spellteach_buy_context
	if ticket.is_empty(): return ""
	if not ticket.paid or ticket.records.any(func(row):return not row.done): return "spellteach_incomplete_actual_purchase_group"
	engine._spellteach_buy_context={};return ""
static func saved_error(state: Dictionary,catalog,events: Array) -> String:
	var owned: Dictionary=Owned.saved_receipts(state,catalog,events)
	if not str(owned.error).is_empty(): return str(owned.error)
	var receipts: Dictionary=owned.receipts;var quotas: Dictionary={};var purchases: Dictionary={}
	for event in events:
		if event.get("type")!="native_spellteach_acquired": continue
		if event.get("policy")!=POLICY or event.get("source_id") not in Sources.PARENTS or event.get("child_id")!=Sources.CHILD or not Sources.uid(event.get("child_uid")) or receipts.has(event.child_uid) or not Sources.integer(event.get("round"),1,int(state.get("round",0))) or not Sources.integer(event.get("sequence"),1,int(state.get("command_sequence",0))): return "spellteach_invalid_acquisition_receipt"
		var binding: Variant=event.get("binding")
		if not Sources.fields(binding,["uid","owner","source_id","source_uid","purchased_uid","spell_id","round","sequence","spell_program"]) or binding.uid!=event.child_uid or binding.owner!=event.get("player") or binding.source_id not in [event.source_id] or binding.source_uid!=event.get("source_uid") or binding.purchased_uid!=event.get("bought_uid") or binding.spell_id!=event.get("spell_id") or binding.round!=event.round or binding.sequence!=event.sequence or not Sources.uid(binding.source_uid) or not Sources.uid(binding.purchased_uid) or not Sources.same(binding.spell_program,catalog.get_card(str(binding.spell_id)).get("effects")): return "spellteach_changed_acquisition_binding"
		if not state.get("players",[]).any(func(owner):return owner.get("id")==event.get("player")) or not Cast.card_error(catalog,str(binding.spell_id)).is_empty(): return "spellteach_unbound_receipt_owner_or_spell"
		var key: String=str(event.player)+":"+str(event.source_uid)
		var prior: Dictionary=quotas.get(key,{})
		var expected_used: int=int(prior.get("used",0))+1 if prior.get("round")==event.round else 1
		if event.get("used")!=expected_used or expected_used>int(Sources.PROGRAMS[event.source_id][0].limit) or not prior.is_empty() and (prior.id!=event.source_id or int(prior.round)>int(event.round)): return "spellteach_replayed_or_changed_round_quota"
		var purchase_key: String=key+":"+str(event.bought_uid)
		if purchases.has(purchase_key): return "spellteach_same_purchase_replayed"
		purchases[purchase_key]=true
		quotas[key]={"uid":event.source_uid,"id":event.source_id,"owner":event.player,"round":event.round,"used":event.used}
		receipts[event.child_uid]=event
	var cast_uids: Dictionary={};var cast_steps: Dictionary={}
	for event in events:
		if event.get("type")!="native_spellteach_minion_cast": continue
		if event.get("origin")!=Cast.ORIGIN or event.get("caster_kind")!="minion" or event.get("source_id")!=Sources.CHILD or not receipts.has(event.get("source_uid")) or not Sources.uid(event.get("spell_uid")) or cast_uids.has(event.spell_uid) or receipts.has(event.spell_uid) or not Sources.integer(event.get("round"),1,int(state.get("round",0))) or not Sources.integer(event.get("sequence"),1,int(state.get("command_sequence",0))) or not Sources.integer(event.get("repetition"),1): return "spellteach_invalid_minion_cast_receipt"
		var acquisition: Dictionary=receipts[event.source_uid]
		if event.get("player")!=acquisition.player or event.get("spell_id")!=acquisition.spell_id or int(event.round)<int(acquisition.round) or int(event.sequence)<=int(acquisition.sequence) or event.get("target_zone") not in ["board","shop"] or event.get("target_uid")!="" and not Sources.uid(event.get("target_uid")): return "spellteach_changed_minion_cast_lineage"
		var cast_key: String=str(event.source_uid)+":"+str(event.sequence)
		if int(event.repetition)!=int(cast_steps.get(cast_key,0))+1: return "spellteach_replayed_minion_cast_step"
		cast_steps[cast_key]=event.repetition;cast_uids[event.spell_uid]=true
	for player in state.get("players",[]):
		for zone in ["board","hand","shop","mechanism_reward_queue"]:
			for unit in player.get(zone,[]):
				if cast_uids.has(unit.get("uid")): return "spellteach_ephemeral_spell_restored_as_owned_card"
				if not Sources.claimed(unit): continue
				var issue: String=Sources.unit_error(unit,catalog)
				if not issue.is_empty(): return issue
				var quota_key: String=str(player.id)+":"+str(unit.uid)
				if unit.get("card_id") in Sources.PARENTS and (unit.has(Sources.QUOTA) or quotas.has(quota_key)) and not Sources.same(unit.get(Sources.QUOTA),quotas.get(quota_key)): return "spellteach_quota_disagrees_with_actual_purchase_receipts"
				if unit.has(Sources.QUOTA):
					var quota: Dictionary=unit[Sources.QUOTA]
					if quota.owner!=player.id or quota.round>int(state.round): return "spellteach_foreign_or_future_quota"
				if receipts.has(unit.uid) and not unit.has(Sources.TAUGHT): return "spellteach_saved_teaching_binding_removed"
				if not unit.has(Sources.TAUGHT): continue
				var binding: Dictionary=unit[Sources.TAUGHT]
				if binding.owner!=player.id or binding.round>int(state.round) or binding.sequence>int(state.get("command_sequence",0)) or not receipts.has(unit.uid) or not Sources.same(receipts[unit.uid].get("binding"),binding): return "spellteach_unproven_saved_teaching_lineage"
				if not Cast.card_error(catalog,str(binding.spell_id)).is_empty(): return "spellteach_saved_spell_source_changed"
	return ""
