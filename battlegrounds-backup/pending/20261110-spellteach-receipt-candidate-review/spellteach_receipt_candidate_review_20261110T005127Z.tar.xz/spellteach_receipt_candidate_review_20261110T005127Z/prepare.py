from pathlib import Path
import json,hashlib,difflib,resource,re
resource.setrlimit(resource.RLIMIT_AS,(128*1024**2,resource.RLIM_INFINITY))
H=Path(__file__).resolve().parent;W=H.parent;R=W/'historical_tools_batch14_20261109T191857Z/runtime';B=W/'spellteach_type_callchain_review_20261110T003349Z'
def sha(b):return hashlib.sha256(b).hexdigest()
def put(rel,b):
 p=H/rel;p.parent.mkdir(parents=True,exist_ok=True);assert not p.exists(),p;p.write_bytes(b)
pins=[]
def copy(src,rel):
 b=src.read_bytes();put(rel,b);assert src.stat().st_ino!=(H/rel).stat().st_ino;pins.append({'source':str(src.relative_to(W)),'copy':rel,'bytes':len(b),'sha256':sha(b)});return b
for rel in ['core/spellteach_murloc_sources.gd','core/spellteach_murloc_host.gd','core/spellteach_murloc_cast.gd','core/spellteach_trinket_host.gd','core/spellteach_trinket_sources.gd','core/yogg_start_cast_sources.gd']:
 copy(R/rel,'original_inputs/'+rel)
for rel in ['core/phase_undead_army_sources.gd','core/pool_identity.gd','core/spellteach_trinket_sources.gd']:
 copy(R/rel,'gd_minimal/'+rel)
unit=copy(B/'candidate/core/spellteach_murloc_sources.gd','candidate/core/spellteach_murloc_sources.gd');assert sha(unit)=='8cb583cf4c1e9ddaea7579b46b9812abb05d0ac14a43a689f174f3a0a37273b8'
put('gd_minimal/core/spellteach_murloc_sources.gd',unit)
copy(R/'core/spellteach_murloc_sources.gd','gd_minimal/original/spellteach_murloc_sources.gd')
copy(B/'CANDIDATE.patch','PREVIOUS_UNIT_CANDIDATE.patch')
for rel in ['gd_minimal/project.godot','run_bounded.py']:
 copy(B/rel,rel)
for line,prefix in [('const PROOF_SHA256:', 'research/spellteach_murloc_sources/'),('const PROOF:', 'research/spellteach_trinket_native/')]:
 s=(R/('core/spellteach_murloc_sources.gd' if 'SHA256' in line else 'core/spellteach_trinket_sources.gd')).read_text()
 proof=json.loads(next(x.split('=',1)[1] for x in s.splitlines() if x.startswith(line)))
 for path,digest in proof.items():
  rel=path if path.startswith('research/') else prefix+path
  b=copy(R/rel,'gd_minimal/'+rel);assert sha(b)==digest
original=(R/'core/spellteach_murloc_host.gd').read_bytes();assert sha(original)=='fa080e10757bde93b3c7b75332855576dcca08f7b2a4fdc589dc20907fe7cafe'
old=b'binding.source_id!=event.source_id';new=b'binding.source_id not in [event.source_id]';assert original.count(old)==1
candidate=original.replace(old,new);put('candidate/core/spellteach_murloc_host.gd',candidate)
patch=''.join(difflib.unified_diff(original.decode().splitlines(True),candidate.decode().splitlines(True),fromfile='a/core/spellteach_murloc_host.gd',tofile='b/core/spellteach_murloc_host.gd'))
put('RECEIPT_CANDIDATE.patch',patch.encode())
# Four actual saved_error bodies. Dependency fragments are assembled separately.
def func(s,name):
 start=s.index('static func '+name+'(');end=s.find('\nstatic func ',start+1);return s[start:] if end<0 else s[start:end+1]
fragments=[]
def fragment_record(source,name,body,rel):
 fragments.append({'source':source,'function':name,'bytes':len(body.encode()),'sha256':sha(body.encode()),'output':rel})
policy=next(x for x in original.decode().splitlines() if x.startswith('const POLICY:'))
for key,new_host,new_unit in [('OO',False,False),('U',False,True),('R',True,False),('UR',True,True)]:
 body=func(candidate.decode() if new_host else original.decode(),'saved_error')
 rel='gd_minimal/fragments/host_'+key+'.gd'
 text='extends RefCounted\nconst Sources=preload("res://'+('core' if new_unit else 'original')+'/spellteach_murloc_sources.gd")\nconst Owned=preload("res://fragments/owned.gd")\nconst Cast=preload("res://fragments/cast_card.gd")\n'+policy+'\n'+body
 put(rel,text.encode());fragment_record('candidate/core/spellteach_murloc_host.gd' if new_host else 'original_inputs/core/spellteach_murloc_host.gd','saved_error',body,rel)
owned=(R/'core/spellteach_trinket_host.gd').read_text();consts='\n'.join(x for x in owned.splitlines() if any(x.startswith('const '+name+'=') for name in ['STATE','ACQUIRED','EVENT','POLICY']))
owner_body=func(owned,'owner_error');receipt_body=func(owned,'saved_receipts')
text='extends RefCounted\nconst Sources=preload("res://core/spellteach_trinket_sources.gd")\nconst Child=preload("res://core/spellteach_murloc_sources.gd")\nconst Cast=preload("res://fragments/cast_card.gd")\n'+consts+'\n'+owner_body+'\n'+receipt_body
put('gd_minimal/fragments/owned.gd',text.encode())
for n,b in [('owner_error',owner_body),('saved_receipts',receipt_body)]:fragment_record('original_inputs/core/spellteach_trinket_host.gd',n,b,'gd_minimal/fragments/owned.gd')
yogg=(R/'core/yogg_start_cast_sources.gd').read_text();children=next(x for x in yogg.splitlines() if x.startswith('const CHILDREN:'));same=func(yogg,'same');child=func(yogg,'child_error')
# Extension dependencies are never permissive stubs: this path must remain disabled.
text='''extends RefCounted
class ForbiddenExtension:
	static var calls: int=0
	static func accepts_id(_id):
		calls+=1
		push_error("PROBE_FORBIDDEN_EXTENSION_PATH")
		return true
	static func child_error(_catalog,_id):
		calls+=1
		push_error("PROBE_FORBIDDEN_EXTENSION_PATH")
		return "PROBE_FORBIDDEN_EXTENSION_PATH"
'''
for n in ['StatNineSources','OwnerEightSources','TargetThreeSources','RandomThreeSources','StealTwoSources','ResourceQueueSources']:text+='const '+n+'=ForbiddenExtension\n'
text+=children+'\n'+same+'\n'+child
put('gd_minimal/fragments/spell_data.gd',text.encode())
for n,b in [('same',same),('child_error',child),('CHILDREN constant',children)]:fragment_record('original_inputs/core/yogg_start_cast_sources.gd',n,b,'gd_minimal/fragments/spell_data.gd')
cast=(R/'core/spellteach_murloc_cast.gd').read_text();card=func(cast,'card_error');origin=next(x for x in cast.splitlines() if x.startswith('const ORIGIN:'))
put('gd_minimal/fragments/cast_card.gd',('extends RefCounted\nconst SpellData=preload("res://fragments/spell_data.gd")\n'+origin+'\n'+card).encode());fragment_record('original_inputs/core/spellteach_murloc_cast.gd','card_error',card,'gd_minimal/fragments/cast_card.gd')
# Reuse only the representative-value constructor, not old execution logic.
previous=(B/'gd_minimal/type_matrix.gd').read_text();start=previous.index('func _values()');end=previous.index('\nfunc _unit()',start);values=previous[start:end].replace('func _values()','static func values()',1)
put('gd_minimal/values.gd',('extends RefCounted\n'+values+'\n').encode())
put('EXTRACTED_FUNCTIONS.json',(json.dumps(fragments,indent=2)+'\n').encode())
put('INPUT_PINS.json',(json.dumps(pins,indent=2)+'\n').encode())
put('CANDIDATE_MANIFEST.json',(json.dumps({'status':'NEW_LOCAL_RECEIPT_CORRECTION_NOT_ORIGINAL_RESTORATION_NOT_LATEST_NOT_INSTALLED','original_host_sha256':sha(original),'candidate_host_sha256':sha(candidate),'candidate_host_bytes':len(candidate),'receipt_patch_sha256':sha(patch.encode()),'previous_unit_candidate_sha256':sha(unit),'combos':{'OO':'original host + original unit','U':'original host + prior unit candidate','R':'new receipt host + original unit','UR':'new receipt host + prior unit candidate'},'changed_host_lines':[119],'scope':'Only native parent acquisition binding.source_id comparison; no other receipt fields, trinket host or compiler changed.','no_full_host_or_Game_execution':True},indent=2)+'\n').encode())
print(json.dumps({'pins':len(pins),'fragments':len(fragments),'candidate_host_sha256':sha(candidate),'candidate_host_bytes':len(candidate)}))
