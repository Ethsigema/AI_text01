extends SceneTree
const Values=preload("res://values.gd")
const F=preload("res://fixtures.gd")
const OO=preload("res://fragments/host_OO.gd")
const U=preload("res://fragments/host_U.gd")
const R=preload("res://fragments/host_R.gd")
const UR=preload("res://fragments/host_UR.gd")
func _init():call_deferred("_run")
func _run():
	var modules:Dictionary={"OO":OO,"U":U,"R":R,"UR":UR};var c=F.catalog();var results:Array=[];var failures:Array=[]
	assert(not is_same(c,c.source_catalog) and not is_same(c.cards,c.source_catalog.cards))
	for parent in ["BG33_891","BG33_891_G"]:
		for top_type in ["String","StringName"]:
			var top:Variant=parent if top_type=="String" else StringName(parent)
			for entry in Values.values():
				for mode in ["receipt_only","unit_only","both","top_only"]:
					for combo in modules:
						var unit:Dictionary=F.unit(parent);var event:Dictionary=F.event(unit,top)
						if mode in ["receipt_only","both"]:event.binding.source_id=entry[1]
						if mode in ["unit_only","both"]:unit[F.Source.TAUGHT].source_id=entry[1]
						if mode=="top_only":event.source_id=entry[1]
						var state:Dictionary=F.state([unit]);var events:Array=[event];var before:PackedByteArray=var_to_bytes([state,events]);var before_reads:int=c.reads+c.source_catalog.reads
						var label:String=combo+":"+parent+":"+top_type+":"+mode+":"+entry[0]
						print("CALL_BEGIN|",label);var issue:String=modules[combo].saved_error(state,c,events);print("CALL_END|",label)
						if before!=var_to_bytes([state,events]):failures.append({"label":label,"issue":"input_mutated"})
						results.append({"label":label,"version":combo,"parent":parent,"top_type":top_type,"mode":mode,"case":entry[0],"variant_type":type_string(typeof(entry[1])),"returned":issue,"catalog_reads":c.reads+c.source_catalog.reads-before_reads,"synthetic_state_only_no_Game":true,"empty_return_not_pass_if_diagnostic":true})
	if F.SpellData.ForbiddenExtension.calls!=0:failures.append({"issue":"forbidden_extension_was_called"})
	var f=FileAccess.open(OS.get_cmdline_user_args()[0],FileAccess.WRITE);f.store_string(JSON.stringify({"results":results,"failures":failures,"representative_values":Values.values().size(),"forbidden_extension_calls":F.SpellData.ForbiddenExtension.calls,"source_catalog_is_distinct":true,"actual_Owned_and_Cast_functions_extracted":true,"no_permissive_Owned_or_Cast_stubs":true,"full_host_and_Game_not_executed":true},"\t")+"\n");f.close();quit(0 if failures.is_empty() else 1)
