extends RefCounted
const Sources=preload("res://core/spellteach_trinket_sources.gd")
const Child=preload("res://core/spellteach_murloc_sources.gd")
const Cast=preload("res://fragments/cast_card.gd")
const STATE="native_spellteach_trinket_slot"
const ACQUIRED="native_spellteach_trinket_acquired"
const EVENT="native_spellteach_trinket_taught"
const POLICY="actual_owned_slot_purchase_two_per_owner_turn_native_apprentice_v1"
static func owner_error(p: Dictionary,round_number: int,catalog,allow_new: int=-1) -> String:
	var indices: Array=[]
	for index in range(p.get("trinkets",[]).size()):
		if p.trinkets[index]==Sources.ID: indices.append(index)
	if indices.size()>1: return "spellteach_trinket_multiple_slot_order_partial"
	var row: Variant=p.get(STATE,{})
	if not row is Dictionary: return "spellteach_trinket_invalid_slot_ledger"
	if not row.is_empty():
		if not Child.fields(row,["owner","source_id","slot","round","sequence","event_index","quota"]) or row.owner!=p.id or row.source_id!=Sources.ID or not Child.integer(row.slot,0,7) or not Child.integer(row.round,1,round_number) or not Child.integer(row.sequence,1) or not Child.integer(row.event_index) or not row.quota is Dictionary: return "spellteach_trinket_changed_acquisition"
		if not row.quota.is_empty() and (not Child.fields(row.quota,["round","used"]) or not Child.integer(row.quota.round,int(row.round),round_number) or not Child.integer(row.quota.used,1,2)): return "spellteach_trinket_changed_quota"
	if not indices.is_empty() and indices[0]!=allow_new:
		if row.is_empty() or row.slot!=indices[0]: return "spellteach_trinket_missing_original_slot_receipt"
		return Sources.closure_error(catalog)
	return ""

static func saved_receipts(state: Dictionary,catalog,events: Array) -> Dictionary:
	var receipts: Dictionary={};var last: Dictionary={};var purchases: Dictionary={}
	for p in state.get("players",[]):
		var issue: String=owner_error(p,int(state.get("round",0)),catalog)
		if not issue.is_empty(): return {"error":issue}
		if not p.has(STATE): continue
		issue=Sources.closure_error(catalog)
		if not issue.is_empty(): return {"error":issue}
		var row: Dictionary=p[STATE];var index: int=int(row.event_index)
		if index>=events.size() or row.sequence>int(state.get("command_sequence",0)): return {"error":"spellteach_trinket_missing_acquisition_event"}
		var root: Dictionary=row.duplicate(true);root.quota={}
		var event: Dictionary=events[index]
		if event.get("type")!=ACQUIRED or event.get("player")!=p.id or event.get("policy")!=POLICY or not Child.same(event.get("entry"),root): return {"error":"spellteach_trinket_changed_acquisition_receipt"}
	for event_index in range(events.size()):
		var event: Dictionary=events[event_index]
		if event.get("type")==ACQUIRED:
			var owners: Array=state.get("players",[]).filter(func(owner):return owner.get("id")==event.get("player"))
			if owners.size()!=1 or owners[0].get(STATE,{}).get("event_index")!=event_index: return {"error":"spellteach_trinket_orphan_acquisition"}
			continue
		if event.get("type")!=EVENT: continue
		var binding: Variant=event.get("binding")
		var owners: Array=state.get("players",[]).filter(func(owner):return owner.get("id")==event.get("player"))
		if owners.size()!=1 or event.get("policy")!=POLICY or event.get("source_id")!=Sources.ID or event.get("child_id")!=Child.CHILD or not Child.uid(event.get("child_uid")) or receipts.has(event.child_uid) or not Child.integer(event.get("round"),1,int(state.get("round",0))) or not Child.integer(event.get("sequence"),1,int(state.get("command_sequence",0))): return {"error":"spellteach_trinket_invalid_teaching_receipt"}
		var row: Dictionary=owners[0].get(STATE,{})
		if row.is_empty() or event.get("source_slot")!=row.slot or event.get("acquired_event_index")!=row.event_index or event.round<row.round or event.sequence<=row.sequence: return {"error":"spellteach_trinket_foreign_acquisition_lineage"}
		if not Child.fields(binding,["uid","owner","source_id","source_slot","acquired_event_index","purchased_uid","spell_id","round","sequence","spell_program"]) or binding.uid!=event.child_uid or binding.owner!=event.player or binding.source_id!=Sources.ID or binding.source_slot!=row.slot or binding.acquired_event_index!=row.event_index or binding.purchased_uid!=event.get("bought_uid") or binding.spell_id!=event.get("spell_id") or binding.round!=event.round or binding.sequence!=event.sequence or not Child.uid(binding.purchased_uid) or not Child.same(binding.spell_program,catalog.get_card(str(binding.spell_id)).get("effects")) or not Cast.card_error(catalog,str(binding.spell_id)).is_empty(): return {"error":"spellteach_trinket_changed_taught_binding"}
		var key: String=str(event.player);var previous: Dictionary=last.get(key,{})
		var expected: int=int(previous.get("used",0))+1 if previous.get("round")==event.round else 1
		if event.get("used")!=expected or expected>2 or int(previous.get("round",0))>int(event.round): return {"error":"spellteach_trinket_replayed_turn_quota"}
		var purchase: String=key+":"+str(binding.purchased_uid)
		if purchases.has(purchase): return {"error":"spellteach_trinket_replayed_purchase"}
		purchases[purchase]=true;last[key]={"round":event.round,"used":event.used};receipts[event.child_uid]=event
	for p in state.get("players",[]):
		if p.has(STATE) and not Child.same(p[STATE].quota,last.get(str(p.id),{})): return {"error":"spellteach_trinket_saved_quota_not_backed_by_receipts"}
	return {"error":"","receipts":receipts}
