extends RefCounted
const SpellData=preload("res://fragments/spell_data.gd")
const ORIGIN: String="native_apprentice_actual_hand_minion_cast"
static func card_error(catalog,id: String) -> String:
	var issue: String=SpellData.child_error(catalog,id)
	if not issue.is_empty(): return "spellteach_unproved_taught_payload:"+id
	var card: Dictionary=catalog.get_card(id)
	if card.get("kind")!="spell" or card.get("effects",[]).is_empty(): return "spellteach_missing_spell_program"
	for leaf in card.effects:
		if leaf.get("type") not in ["spell_buff","spell_keyword","spell_gold"]: return "spellteach_nonbasic_complete_payload_partial"
		if leaf.get("type")!="spell_gold" and leaf.get("scope") not in ["target","all","all_friendly","leftmost"]: return "spellteach_unproved_spell_target_policy"
	return ""
