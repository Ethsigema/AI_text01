extends RefCounted
const Sources=preload("res://original/spellteach_murloc_sources.gd")
const Owned=preload("res://fragments/owned.gd")
const Cast=preload("res://fragments/cast_card.gd")
const POLICY: String="actual_bought_spell_uid_round_same_native_child_minion_cast_v1"
static func saved_error(state: Dictionary,catalog,events: Array) -> String:
	var owned: Dictionary=Owned.saved_receipts(state,catalog,events)
	if not str(owned.error).is_empty(): return str(owned.error)
	var receipts: Dictionary=owned.receipts;var quotas: Dictionary={};var purchases: Dictionary={}
	for event in events:
		if event.get("type")!="native_spellteach_acquired": continue
		if event.get("policy")!=POLICY or event.get("source_id") not in Sources.PARENTS or event.get("child_id")!=Sources.CHILD or not Sources.uid(event.get("child_uid")) or receipts.has(event.child_uid) or not Sources.integer(event.get("round"),1,int(state.get("round",0))) or not Sources.integer(event.get("sequence"),1,int(state.get("command_sequence",0))): return "spellteach_invalid_acquisition_receipt"
		var binding: Variant=event.get("binding")
		if not Sources.fields(binding,["uid","owner","source_id","source_uid","purchased_uid","spell_id","round","sequence","spell_program"]) or binding.uid!=event.child_uid or binding.owner!=event.get("player") or binding.source_id!=event.source_id or binding.source_uid!=event.get("source_uid") or binding.purchased_uid!=event.get("bought_uid") or binding.spell_id!=event.get("spell_id") or binding.round!=event.round or binding.sequence!=event.sequence or not Sources.uid(binding.source_uid) or not Sources.uid(binding.purchased_uid) or not Sources.same(binding.spell_program,catalog.get_card(str(binding.spell_id)).get("effects")): return "spellteach_changed_acquisition_binding"
		if not state.get("players",[]).any(func(owner):return owner.get("id")==event.get("player")) or not Cast.card_error(catalog,str(binding.spell_id)).is_empty(): return "spellteach_unbound_receipt_owner_or_spell"
		var key: String=str(event.player)+":"+str(event.source_uid)
		var prior: Dictionary=quotas.get(key,{})
		var expected_used: int=int(prior.get("used",0))+1 if prior.get("round")==event.round else 1
		if event.get("used")!=expected_used or expected_used>int(Sources.PROGRAMS[event.source_id][0].limit) or not prior.is_empty() and (prior.id!=event.source_id or int(prior.round)>int(event.round)): return "spellteach_replayed_or_changed_round_quota"
		var purchase_key: String=key+":"+str(event.bought_uid)
		if purchases.has(purchase_key): return "spellteach_same_purchase_replayed"
		purchases[purchase_key]=true
		quotas[key]={"uid":event.source_uid,"id":event.source_id,"owner":event.player,"round":event.round,"used":event.used}
		receipts[event.child_uid]=event
	var cast_uids: Dictionary={};var cast_steps: Dictionary={}
	for event in events:
		if event.get("type")!="native_spellteach_minion_cast": continue
		if event.get("origin")!=Cast.ORIGIN or event.get("caster_kind")!="minion" or event.get("source_id")!=Sources.CHILD or not receipts.has(event.get("source_uid")) or not Sources.uid(event.get("spell_uid")) or cast_uids.has(event.spell_uid) or receipts.has(event.spell_uid) or not Sources.integer(event.get("round"),1,int(state.get("round",0))) or not Sources.integer(event.get("sequence"),1,int(state.get("command_sequence",0))) or not Sources.integer(event.get("repetition"),1): return "spellteach_invalid_minion_cast_receipt"
		var acquisition: Dictionary=receipts[event.source_uid]
		if event.get("player")!=acquisition.player or event.get("spell_id")!=acquisition.spell_id or int(event.round)<int(acquisition.round) or int(event.sequence)<=int(acquisition.sequence) or event.get("target_zone") not in ["board","shop"] or event.get("target_uid")!="" and not Sources.uid(event.get("target_uid")): return "spellteach_changed_minion_cast_lineage"
		var cast_key: String=str(event.source_uid)+":"+str(event.sequence)
		if int(event.repetition)!=int(cast_steps.get(cast_key,0))+1: return "spellteach_replayed_minion_cast_step"
		cast_steps[cast_key]=event.repetition;cast_uids[event.spell_uid]=true
	for player in state.get("players",[]):
		for zone in ["board","hand","shop","mechanism_reward_queue"]:
			for unit in player.get(zone,[]):
				if cast_uids.has(unit.get("uid")): return "spellteach_ephemeral_spell_restored_as_owned_card"
				if not Sources.claimed(unit): continue
				var issue: String=Sources.unit_error(unit,catalog)
				if not issue.is_empty(): return issue
				var quota_key: String=str(player.id)+":"+str(unit.uid)
				if unit.get("card_id") in Sources.PARENTS and (unit.has(Sources.QUOTA) or quotas.has(quota_key)) and not Sources.same(unit.get(Sources.QUOTA),quotas.get(quota_key)): return "spellteach_quota_disagrees_with_actual_purchase_receipts"
				if unit.has(Sources.QUOTA):
					var quota: Dictionary=unit[Sources.QUOTA]
					if quota.owner!=player.id or quota.round>int(state.round): return "spellteach_foreign_or_future_quota"
				if receipts.has(unit.uid) and not unit.has(Sources.TAUGHT): return "spellteach_saved_teaching_binding_removed"
				if not unit.has(Sources.TAUGHT): continue
				var binding: Dictionary=unit[Sources.TAUGHT]
				if binding.owner!=player.id or binding.round>int(state.round) or binding.sequence>int(state.get("command_sequence",0)) or not receipts.has(unit.uid) or not Sources.same(receipts[unit.uid].get("binding"),binding): return "spellteach_unproven_saved_teaching_lineage"
				if not Cast.card_error(catalog,str(binding.spell_id)).is_empty(): return "spellteach_saved_spell_source_changed"
	return ""
