extends RefCounted
const Source=preload("res://core/spellteach_murloc_sources.gd")
const Trinket=preload("res://core/spellteach_trinket_sources.gd")
const Owned=preload("res://fragments/owned.gd")
const SpellData=preload("res://fragments/spell_data.gd")
const Cast=preload("res://fragments/cast_card.gd")
const POLICY="actual_bought_spell_uid_round_same_native_child_minion_cast_v1"
class ProbeCatalog extends RefCounted:
	var cards:Dictionary={}
	var source_catalog=null
	var reads:int=0
	func get_card(id):
		reads+=1
		return cards.get(id,{})
static func catalog():
	var c=ProbeCatalog.new();var raw=ProbeCatalog.new()
	for id in Source.IDS:
		var row:Dictionary=Source.RAW[id].duplicate(true);row.merge(Source.EXPECTED[id],true);c.cards[id]=row
	var trinket:Dictionary=Trinket.RAW[Trinket.ID].duplicate(true);trinket.merge(Trinket.EXPECTED[Trinket.ID],true);c.cards[Trinket.ID]=trinket
	for id in SpellData.CHILDREN:
		var row:Dictionary=SpellData.CHILDREN[id].raw.duplicate(true);row.merge(SpellData.CHILDREN[id].overlay,true);c.cards[id]=row
	raw.cards=c.cards.duplicate(true);c.source_catalog=raw
	return c
static func body(id:String,uid:String)->Dictionary:
	var raw:Dictionary=Source.RAW[id]
	return {"card_id":id,"effects":Source.PROGRAMS[id].duplicate(true),"kind":"minion","name":raw.name,"golden":raw.is_golden,"tribes":raw.tribes.duplicate(true),"tier":raw.tier,"text":raw.text,"uid":uid}
static func unit(source_id:Variant="BG33_891",spell:String="BG28_810",uid:String="u101",purchase:String="u103",round_number:int=1,sequence:int=1)->Dictionary:
	var u:Dictionary=body(Source.CHILD,uid)
	u[Source.TAUGHT]={"uid":uid,"owner":0,"source_id":source_id,"source_uid":"u102","purchased_uid":purchase,"spell_id":spell,"round":round_number,"sequence":sequence,"spell_program":SpellData.CHILDREN[spell].overlay.effects.duplicate(true)}
	return u
static func event(u:Dictionary,event_source:Variant="BG33_891",used:int=1)->Dictionary:
	var b:Dictionary=u[Source.TAUGHT]
	return {"type":"native_spellteach_acquired","policy":POLICY,"player":0,"source_id":event_source,"source_uid":b.source_uid,"bought_uid":b.purchased_uid,"spell_id":b.spell_id,"child_id":Source.CHILD,"child_uid":u.uid,"binding":b.duplicate(true),"used":used,"round":b.round,"sequence":b.sequence}
static func state(units:Array,zone:String="hand",round_number:int=1,sequence:int=1)->Dictionary:
	var p:Dictionary={"id":0,"trinkets":[],"board":[],"hand":[],"shop":[],"mechanism_reward_queue":[]};p[zone]=units
	return {"round":round_number,"command_sequence":sequence,"players":[p]}
static func owned_fixture(catalog)->Dictionary:
	var u:Dictionary=unit();var b:Dictionary=u[Source.TAUGHT];b.erase("source_uid");b.source_id=Trinket.ID;b.source_slot=0;b.acquired_event_index=0;b.sequence=2
	var entry:Dictionary={"owner":0,"source_id":Trinket.ID,"slot":0,"round":1,"sequence":1,"event_index":0,"quota":{}}
	var root:Dictionary={"type":Owned.ACQUIRED,"player":0,"entry":entry.duplicate(true),"policy":Owned.POLICY}
	var taught:Dictionary={"type":Owned.EVENT,"policy":Owned.POLICY,"player":0,"source_id":Trinket.ID,"source_slot":0,"acquired_event_index":0,"bought_uid":b.purchased_uid,"spell_id":b.spell_id,"child_id":Source.CHILD,"child_uid":u.uid,"binding":b.duplicate(true),"used":1,"round":1,"sequence":2}
	entry.quota={"round":1,"used":1}
	var s:Dictionary=state([u],"hand",1,2);s.players[0].trinkets=[Trinket.ID];s.players[0][Owned.STATE]=entry
	return {"state":s,"events":[root,taught]}
