extends SceneTree
const F=preload("res://fixtures.gd")
const OO=preload("res://fragments/host_OO.gd")
const U=preload("res://fragments/host_U.gd")
const R=preload("res://fragments/host_R.gd")
const UR=preload("res://fragments/host_UR.gd")
var modules:Dictionary={"OO":OO,"U":U,"R":R,"UR":UR}
var results:Array=[]
var failures:Array=[]
func _init():call_deferred("_run")
func _check(name:String,state:Dictionary,c,events:Array,expected:String)->void:
	for combo in modules:
		var before:PackedByteArray=var_to_bytes([state,events,c.cards,c.source_catalog.cards]);var label:String=combo+":"+name
		print("CALL_BEGIN|",label);var issue:String=modules[combo].saved_error(state,c,events);print("CALL_END|",label)
		if issue!=expected:failures.append({"label":label,"expected":expected,"actual":issue})
		if before!=var_to_bytes([state,events,c.cards,c.source_catalog.cards]):failures.append({"label":label,"issue":"input_mutated"})
		results.append({"label":label,"version":combo,"case":name,"returned":issue,"expected":expected,"no_real_purchase_or_Game":true})
func _write(path:String,bytes:PackedByteArray)->void:
	var f=FileAccess.open(path,FileAccess.WRITE);assert(f!=null);f.store_buffer(bytes);f.close()
func _run():
	var c=F.catalog()
	assert(F.Source.proof_error().is_empty() and F.Source.closure_error(c).is_empty() and F.Trinket.closure_error(c).is_empty())
	_check("empty_state",{"players":[],"round":1,"command_sequence":1},c,[],"")
	for parent in ["BG33_891","BG33_891_G"]:
		for spell in F.SpellData.CHILDREN:
			var u:Dictionary=F.unit(parent,spell);_check("real_payload:"+parent+":"+spell,F.state([u]),c,[F.event(u,parent)],"")
		for zone in ["board","hand","shop","mechanism_reward_queue"]:
			var u:Dictionary=F.unit(parent);_check("zone:"+parent+":"+zone,F.state([u],zone),c,[F.event(u,parent)],"")
		var child:Dictionary=F.unit(parent);var state:Dictionary=F.state([child]);var teacher:Dictionary=F.body(parent,"u102")
		teacher[F.Source.QUOTA]={"uid":"u102","id":parent,"owner":0,"round":1,"used":1};state.players[0].board=[teacher]
		_check("teacher_quota:"+parent,state,c,[F.event(child,parent)],"")
	for mode in ["golden_two","normal_two","normal_next_round","repeat_purchase","wrong_latest_quota"]:
		var parent:String="BG33_891_G" if mode in ["golden_two","repeat_purchase"] else "BG33_891"
		var second_round:int=2 if mode in ["normal_next_round","wrong_latest_quota"] else 1
		var first:Dictionary=F.unit(parent);var second:Dictionary=F.unit(parent,"BG28_810","u104","u103" if mode=="repeat_purchase" else "u105",second_round,2)
		var last_used:int=1 if second_round==2 else 2
		var state:Dictionary=F.state([first,second],"hand",second_round,2);var teacher:Dictionary=F.body(parent,"u102")
		teacher[F.Source.QUOTA]={"uid":"u102","id":parent,"owner":0,"round":second_round,"used":last_used};state.players[0].board=[teacher]
		var expected:String=""
		if mode=="normal_two":expected="spellteach_replayed_or_changed_round_quota"
		elif mode=="repeat_purchase":expected="spellteach_same_purchase_replayed"
		elif mode=="wrong_latest_quota":teacher[F.Source.QUOTA].round=1;expected="spellteach_quota_disagrees_with_actual_purchase_receipts"
		_check(mode,state,c,[F.event(first,parent),F.event(second,parent,last_used)],expected)
	for mode in ["missing_receipt","binding_removed","duplicate_child","binding_extra","binding_missing_source","binding_not_dict","binding_program_changed","future_round","future_sequence","wrong_owner","changed_policy","wrong_child","wrong_uid","changed_used","changed_source_program","changed_effective_spell","changed_raw_spell","unknown_spell"]:
		var cc=F.catalog();var u:Dictionary=F.unit();var e:Dictionary=F.event(u);var es:Array=[e];var state:Dictionary=F.state([u]);var expected:String="spellteach_invalid_acquisition_receipt"
		match mode:
			"missing_receipt":es=[];expected="spellteach_unproven_saved_teaching_lineage"
			"binding_removed":u.erase(F.Source.TAUGHT);expected="spellteach_saved_teaching_binding_removed"
			"duplicate_child":es.append(e.duplicate(true))
			"binding_extra":e.binding.extra=true;expected="spellteach_changed_acquisition_binding"
			"binding_missing_source":e.binding.erase("source_id");expected="spellteach_changed_acquisition_binding"
			"binding_not_dict":e.binding=[];expected="spellteach_changed_acquisition_binding"
			"binding_program_changed":e.binding.spell_program=[];expected="spellteach_changed_acquisition_binding"
			"future_round":e.round=2
			"future_sequence":e.sequence=2
			"wrong_owner":e.player=1;e.binding.owner=1;expected="spellteach_unbound_receipt_owner_or_spell"
			"changed_policy":e.policy="OTHER"
			"wrong_child":e.child_id="OTHER"
			"wrong_uid":e.child_uid="bad"
			"changed_used":e.used=2;expected="spellteach_replayed_or_changed_round_quota"
			"changed_source_program":u[F.Source.TAUGHT].spell_program=[];expected="spellteach_changed_taught_program"
			"changed_effective_spell":cc.cards.BG28_810.name="changed";expected="spellteach_unbound_receipt_owner_or_spell"
			"changed_raw_spell":cc.source_catalog.cards.BG28_810.name="changed";expected="spellteach_unbound_receipt_owner_or_spell"
			"unknown_spell":
				cc.cards.OTHER={"effects":[]};e.spell_id="OTHER";e.binding.spell_id="OTHER";e.binding.spell_program=[];expected="spellteach_unbound_receipt_owner_or_spell"
		_check(mode,state,cc,es,expected)
	# Valid minion-cast lineage and representative replay/identity rejection.
	for mode in ["valid_cast_receipt","cast_wrong_origin","cast_repetition","cast_early_sequence","cast_duplicate_uid","cast_wrong_spell"]:
		var u:Dictionary=F.unit();var s:Dictionary=F.state([u],"board",1,2)
		var cast:Dictionary={"type":"native_spellteach_minion_cast","origin":F.Cast.ORIGIN,"caster_kind":"minion","player":0,"source_id":F.Source.CHILD,"source_uid":u.uid,"spell_id":"BG28_810","spell_uid":"u201","target_zone":"board","target_uid":"","round":1,"sequence":2,"repetition":1}
		var events:Array=[F.event(u),cast];var expected:String=""
		if mode=="cast_wrong_origin":cast.origin="OTHER";expected="spellteach_invalid_minion_cast_receipt"
		elif mode=="cast_repetition":cast.repetition=2;expected="spellteach_replayed_minion_cast_step"
		elif mode=="cast_early_sequence":cast.sequence=1;expected="spellteach_changed_minion_cast_lineage"
		elif mode=="cast_duplicate_uid":events.append(cast.duplicate(true));expected="spellteach_invalid_minion_cast_receipt"
		elif mode=="cast_wrong_spell":cast.spell_id="OTHER";expected="spellteach_changed_minion_cast_lineage"
		_check(mode,s,c,events,expected)
	for mode in ["owned_valid","owned_ledger_missing","owned_entry_changed","owned_quota_changed","owned_repeated_purchase"]:
		var fix:Dictionary=F.owned_fixture(c);var expected:String=""
		if mode=="owned_ledger_missing":fix.state.players[0].erase(F.Owned.STATE);expected="spellteach_trinket_missing_original_slot_receipt"
		elif mode=="owned_entry_changed":fix.events[0].entry.sequence=2;expected="spellteach_trinket_changed_acquisition_receipt"
		elif mode=="owned_quota_changed":fix.state.players[0][F.Owned.STATE].quota.used=2;expected="spellteach_trinket_saved_quota_not_backed_by_receipts"
		elif mode=="owned_repeated_purchase":
			var second:Dictionary=fix.events[1].duplicate(true);second.child_uid="u104";second.binding.uid="u104";second.sequence=3;second.binding.sequence=3;second.used=2;fix.events.append(second);fix.state.command_sequence=3;expected="spellteach_trinket_replayed_purchase"
		_check(mode,fix.state,c,fix.events,expected)
	# Proof mutation affects only this new isolated project, restores exact bytes.
	var proofs:Dictionary={}
	for name in F.Trinket.PROOF:proofs[F.Trinket.FOLDER+name]="spellteach_trinket_changed_native_evidence:"+name
	for name in F.Source.PROOF_SHA256:proofs["res://"+name]="spellteach_native_proof_changed:"+name
	for path in proofs:
		var bytes:PackedByteArray=FileAccess.get_file_as_bytes(path)
		for mode in ["changed_bytes","missing"]:
			if mode=="changed_bytes":var b:PackedByteArray=bytes.duplicate();b.append(32);_write(path,b)
			else:assert(DirAccess.remove_absolute(ProjectSettings.globalize_path(path))==OK)
			var fix:Dictionary=F.owned_fixture(c);_check("proof:"+path+":"+mode,fix.state,c,fix.events,proofs[path]);_write(path,bytes)
			if FileAccess.get_file_as_bytes(path)!=bytes:failures.append({"issue":"proof_restore_failed","path":path})
	if F.SpellData.ForbiddenExtension.calls!=0:failures.append({"issue":"forbidden_extension_was_called"})
	if not F.Source.closure_error(c).is_empty() or not F.Trinket.closure_error(c).is_empty():failures.append({"issue":"final_closure_failed"})
	var file=FileAccess.open(OS.get_cmdline_user_args()[0],FileAccess.WRITE);file.store_string(JSON.stringify({"results":results,"failures":failures,"forbidden_extension_calls":F.SpellData.ForbiddenExtension.calls,"normal_payloads":F.SpellData.CHILDREN.size(),"proof_variants":proofs.size()*2,"full_host_and_Game_not_run":true},"\t")+"\n");file.close();quit(0 if failures.is_empty() else 1)
