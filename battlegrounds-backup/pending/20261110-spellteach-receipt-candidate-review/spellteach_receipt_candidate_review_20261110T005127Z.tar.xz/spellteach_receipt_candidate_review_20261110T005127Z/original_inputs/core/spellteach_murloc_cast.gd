extends RefCounted
## Native 'This casts' is minion attribution. Reuse exact spell data and pure
## arithmetic, never another caster's ticket or a pretend hand spell command.
const Sources=preload("res://core/spellteach_murloc_sources.gd")
const Pure=preload("res://core/recruit_gem_dr_host.gd")
const Actual=preload("res://core/duelist_refresh.gd")
const SpellData=preload("res://core/yogg_start_cast_sources.gd")
const Delivery=preload("res://core/accepted_card_cursor_projection.gd")
const PlayCompletion=preload("res://core/native_cast_play_completion.gd")
const ORIGIN: String="native_apprentice_actual_hand_minion_cast"
static func fail(issue: String) -> Dictionary: return {"ok":false,"error":issue,"active":false}
static func view(player: Dictionary,totals: Dictionary) -> Dictionary: return {"player":player.duplicate(true),"totals":totals.duplicate(true)}
static func card_error(catalog,id: String) -> String:
	var issue: String=SpellData.child_error(catalog,id)
	if not issue.is_empty(): return "spellteach_unproved_taught_payload:"+id
	var card: Dictionary=catalog.get_card(id)
	if card.get("kind")!="spell" or card.get("effects",[]).is_empty(): return "spellteach_missing_spell_program"
	for leaf in card.effects:
		if leaf.get("type") not in ["spell_buff","spell_keyword","spell_gold"]: return "spellteach_nonbasic_complete_payload_partial"
		if leaf.get("type")!="spell_gold" and leaf.get("scope") not in ["target","all","all_friendly","leftmost"]: return "spellteach_unproved_spell_target_policy"
	return ""
static func _entry_error(engine,p: Dictionary,source: Dictionary) -> String:
	var issue: String=Sources.unit_error(source,engine.catalog)
	if issue.is_empty(): issue=Sources.closure_error(engine.catalog)
	if issue.is_empty(): issue=engine.RecruitEvents.NativeBattlecry.owner_error(engine,p)
	if not issue.is_empty(): return issue
	if not source.has(Sources.TAUGHT): return "spellteach_apprentice_has_no_authenticated_spell"
	var binding: Dictionary=source[Sources.TAUGHT]
	if binding.owner!=p.id: return "spellteach_foreign_taught_owner"
	if binding.get("source_id")=="BG35_MagicItem_750":
		issue=engine.SpellteachTrinket.Sources.closure_error(engine.catalog)
		if not issue.is_empty(): return issue
	issue=card_error(engine.catalog,str(binding.spell_id))
	if not issue.is_empty(): return issue
	var repeated: Dictionary=engine.Kithix.FixedBattlecry.repeat_plan(engine,p,source)
	if not repeated.ok: return str(repeated.error)
	if int(repeated.amount)!=engine._battlecry_multiplier(p,source): return "spellteach_native_battlecry_repeat_changed"
	if source.get("triple_reward",false): return "spellteach_apprentice_cannot_be_tripled"
	if engine.HandLocks.Sources.marked(source) or source.get("attachments",[]) not in [[],{}] or source.get("dark_gift_attachments",[]) not in [[],{}]: return "spellteach_inherited_apprentice_program_partial"
	if engine.SaleSpellGroups.linked(p,source.uid) or engine.Mindflayer.linked(p,source.uid) or engine.Kithix.linked(p,source.uid): return "spellteach_linked_hand_play_partial"
	var amplifier=engine.TavernAmplifierHost.Amplifier
	var sums: Dictionary=amplifier.totals(p)
	if not sums.ok: return str(sums.error)
	if int(sums.attack)!=0 or int(sums.health)!=0 or amplifier.Active.has_active(p) or amplifier.Felburned.has_bonus(p) or p.get("hero_id")==engine.TavernAmplifierHost.PeriodicHero.HERO: return "spellteach_minion_cast_amplifier_attribution_partial"
	for member in p.board+p.hand+p.shop:
		if member.get("uid")==source.uid or member.get("kind")!="minion": continue
		if engine.DarkGift.Sources.marked(member) or engine.DancingHats.Sources.marked(member): return "spellteach_marked_play_observer_partial"
		var reader: Dictionary=Delivery.hand_reader(engine,member)
		if reader.claimed:
			if not str(reader.error).is_empty(): return str(reader.error)
			continue
		for leaf in member.get("effects",[]):
			var type: String=str(leaf.get("type",""))
			if type==Sources.TYPE or type==Sources.CAST or type.begins_with("battlecry_") or type.begins_with("deathrattle_") or type.begins_with("rally") or type.begins_with("avenge") or type.begins_with("start_combat_"): continue
			if engine.DiscardHost._has_read(leaf,["spell","cast","play","summon","battlecry","hand_added"]): return "spellteach_unproved_cast_or_play_observer:"+type
	for leaf in engine.Mechanisms._effects(engine,p)+engine.catalog.get_card(str(p.get("hero_id",""))).get("effects",[]):
		if leaf.get("type")=="owned_tavern_spell_purchase_teach_murloc": continue # Purchase-only source, not a spell-cast observer.
		if engine.DiscardHost._has_read(leaf,["spell","cast","play","summon","battlecry"]): return "spellteach_owned_cast_or_play_observer_partial"
	var quest: Dictionary=p.get("active_quest",{})
	if not quest.is_empty() and not quest.get("complete",false) and quest.get("counter") in ["spells","tavern_spells","played","battlecries_played"]: return "spellteach_quest_cast_or_play_partial"
	return ""
static func options(engine,p: Dictionary,source: Dictionary) -> Array:
	if source.get("card_id")!=Sources.CHILD or not source.has(Sources.TAUGHT): return []
	var id: String=str(source[Sources.TAUGHT].get("spell_id",""))
	if not card_error(engine.catalog,id).is_empty(): return []
	# Target arrow is selected, not random. Future self-target/no-target and
	# retrigger targeting are not silently borrowed from a hand spell.
	return engine.YoggCast._target_options(engine,p,engine.catalog.get_card(id))
static func _resolve(p: Dictionary,selected: Dictionary) -> Dictionary:
	if selected.uid=="": return {"zone":"board","index":-1,"uid":""}
	for index in range(p.get(selected.zone,[]).size()):
		if p[selected.zone][index].get("uid")==selected.uid: return {"zone":selected.zone,"index":index,"uid":selected.uid}
	return {}
static func _cast_plan(engine,state: Dictionary,source_uid: String,next_uid: int,selected: Dictionary) -> Dictionary:
	var source: Dictionary=Pure.Gains._find(state.player.board,source_uid)
	if source.get("card_id")!=Sources.CHILD or not source.has(Sources.TAUGHT): return fail("spellteach_projected_apprentice_missing")
	var target: Dictionary=_resolve(state.player,selected)
	if target.is_empty(): return fail("spellteach_selected_physical_target_lost")
	var id: String=str(source[Sources.TAUGHT].spell_id)
	var spell: Dictionary=engine._preview_native_spell(engine.catalog.get_card(id),"u"+str(next_uid))
	if spell.is_empty(): return fail("spellteach_actual_spell_factory_partial")
	spell.pool_count=0;spell.pool_id="";spell.pool_components=[]
	var before: Dictionary=view(state.player,state.totals);var leaves: Array=[]
	for effect in spell.effects:
		var issue: String=engine.YoggCast._effect(engine,state,spell,effect,target)
		if not issue.is_empty(): return fail(issue)
		leaves.append({"effect":effect.duplicate(true),"after":view(state.player,state.totals)})
	return {"ok":true,"error":"","before":before,"spell":spell,"target":target,"leaves":leaves,"after":view(state.player,state.totals),"next_uid":next_uid+1}
static func prepare(engine,p: Dictionary,source: Dictionary,target: int=-1,zone: String="board",position: int=-1,issued: bool=false) -> Dictionary:
	if source.get("card_id")!=Sources.CHILD: return {"ok":true,"error":"","active":false}
	if not Actual._actual_game_host(engine) or engine.state.phase!="recruit" or p.get("alive")!=true or not engine.state.players.any(func(owner):return is_same(owner,p)): return fail("spellteach_actual_recruit_owner_required")
	if not engine._spellteach_cast_context.is_empty() or not p.hand.any(func(unit):return is_same(unit,source)) or p.board.size()>=7 or not Pure.Gains.active(source): return fail("spellteach_actual_hand_and_capacity_required")
	if issued and (not is_same(engine._bounty_spend_command.get("owner"),p) or engine._bounty_spend_command.get("action")!="play"): return fail("spellteach_real_hand_play_required")
	var issue: String=_entry_error(engine,p,source)
	if issue.is_empty(): issue=engine.Spellteach.saved_error(engine.state,engine.catalog,engine.events)
	if not issue.is_empty(): return fail(issue)
	var selected: Dictionary={}
	var legal: Array=options(engine,p,source)
	if legal.size()==1 and legal[0].uid=="": target=-1;zone="board"
	for option in legal:
		if int(option.index)==target and str(option.zone)==zone: selected=option;break
	if selected.is_empty(): return fail("spellteach_explicit_legal_spell_target_required")
	var prefix: Dictionary=engine.Felhorn.prefix(engine,p,source,position)
	if not prefix.ok: return prefix
	var state: Dictionary=prefix.state;var next_uid: int=engine.next_uid
	var repeated: Dictionary=engine.Kithix.FixedBattlecry.repeat_plan(engine,state.player,Pure.Gains._find(state.player.board,str(source.uid)))
	if not repeated.ok: return repeated
	var rounds: Array=[]
	for repetition in range(int(repeated.amount)):
		var cast: Dictionary=_cast_plan(engine,state,str(source.uid),next_uid,selected)
		if not cast.ok: return cast
		next_uid=cast.next_uid
		issue=engine.BalladistPortrait._completion(engine,state,str(source.uid),true)
		if not issue.is_empty(): return fail(issue)
		rounds.append({"cast":cast,"after":view(state.player,state.totals),"next_uid":next_uid})
	var completion: Dictionary=PlayCompletion.project(engine,state,source,next_uid)
	if not completion.ok: return completion
	return {"ok":true,"error":"","active":true,"owner":p,"source":source,"command":engine._bounty_spend_command,"round":engine.state.round,"sequence":engine.state.command_sequence,"whole":{"rounds":rounds,"repeats":int(repeated.amount)},"next":0,"completion_pending":false,"play_finished":false,"play_completion":completion,"selected":selected,"rng_seed":engine.rng.seed,"rng_state":engine.rng.state,"pool":engine.pool.duplicate(true),"spell_pool":engine.spell_pool.duplicate(true)}
static func commit(engine,p: Dictionary,source: Dictionary,ticket: Dictionary,repetition: int) -> Dictionary:
	if not Actual._actual_game_host(engine) or not is_same(engine._spellteach_cast_context,ticket) or not is_same(ticket.get("owner"),p) or not is_same(ticket.get("source"),source) or not is_same(ticket.get("command"),engine._bounty_spend_command): return fail("spellteach_unissued_actual_battlecry")
	if ticket.get("next")!=repetition or ticket.get("completion_pending",true) or engine._battlecry_multiplier(p,source)!=ticket.whole.repeats or engine.state.phase!="recruit" or engine.state.round!=ticket.round or engine.state.command_sequence!=ticket.sequence or not p.board.any(func(unit):return is_same(unit,source)): return fail("spellteach_actual_battlecry_window_changed")
	var cast: Dictionary=ticket.whole.rounds[repetition].cast
	if not Sources.same(view(p,engine._attack_gain_health_totals),cast.before) or engine.next_uid!=int(cast.next_uid)-1: return fail("spellteach_play_prefix_changed")
	var replay: Dictionary=_cast_plan(engine,Pure._state(engine,p),str(source.uid),engine.next_uid,ticket.selected)
	if not replay.ok or not Sources.same(replay,cast): return fail("spellteach_whole_cast_replay_changed")
	var spell: Dictionary=engine._unit(engine.catalog.get_card(str(source[Sources.TAUGHT].spell_id)))
	spell.pool_count=0;spell.pool_id="";spell.pool_components=[]
	if not Sources.same(spell,cast.spell): return fail("spellteach_ephemeral_native_spell_changed")
	for leaf in cast.leaves:
		engine._apply_recruit_effect(p,spell,leaf.effect,int(cast.target.index),str(cast.target.zone))
		if engine.state.phase=="error" or not Sources.same(view(p,engine._attack_gain_health_totals),leaf.after): return fail("spellteach_actual_payload_shadow_changed")
	if engine.next_uid!=cast.next_uid or engine.rng.seed!=ticket.rng_seed or engine.rng.state!=ticket.rng_state or not Sources.same(engine.pool,ticket.pool) or not Sources.same(engine.spell_pool,ticket.spell_pool): return fail("spellteach_unplanned_cast_resource_change")
	# Deliberately no stats.spells, GlobalCards Tavern count, last-spell history,
	# spell_cast event or hand-play event: the native actor is the apprentice.
	engine._log("native_spellteach_minion_cast",{"player":p.id,"source_id":source.card_id,"source_uid":source.uid,"spell_id":spell.card_id,"spell_uid":spell.uid,"target_uid":cast.target.uid,"target_zone":cast.target.zone,"repetition":repetition+1,"caster_kind":"minion","origin":ORIGIN,"round":engine.state.round,"sequence":engine.state.command_sequence})
	ticket.completion_pending=true
	return {"ok":true,"error":""}
static func completed(engine,p: Dictionary,source: Dictionary,ticket: Dictionary,repetition: int) -> String:
	if not ticket.get("active",false): return ""
	if not is_same(ticket.owner,p) or not is_same(ticket.source,source) or not is_same(ticket.command,engine._bounty_spend_command) or engine.state.phase!="recruit" or engine.state.round!=ticket.round or engine.state.command_sequence!=ticket.sequence or ticket.next!=repetition or not ticket.completion_pending: return "spellteach_unissued_battlecry_completion"
	var step: Dictionary=ticket.whole.rounds[repetition]
	if not Sources.same(view(p,engine._attack_gain_health_totals),step.after) or engine.next_uid!=step.next_uid or engine.rng.seed!=ticket.rng_seed or engine.rng.state!=ticket.rng_state or not Sources.same(engine.pool,ticket.pool) or not Sources.same(engine.spell_pool,ticket.spell_pool): return "spellteach_whole_battlecry_completion_changed"
	ticket.next+=1;ticket.completion_pending=false;return ""
static func finish_play(engine,p: Dictionary,source: Dictionary,ticket: Dictionary) -> String: return PlayCompletion.finish(engine,p,source,ticket)
static func legal_commands(engine,p: Dictionary,source: Dictionary,index: int) -> Array:
	var commands: Array=[]
	for option in options(engine,p,source):
		if prepare(engine,p,source,int(option.index),str(option.zone)).ok: commands.append({"type":"play","index":index,"target":int(option.index),"target_zone":str(option.zone)})
	return commands
