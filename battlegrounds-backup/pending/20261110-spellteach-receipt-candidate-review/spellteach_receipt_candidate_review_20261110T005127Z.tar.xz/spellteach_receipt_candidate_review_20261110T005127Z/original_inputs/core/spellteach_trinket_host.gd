extends RefCounted
## One authentic owned slot; no fabricated minion UID or board-source quota.
const Sources=preload("res://core/spellteach_trinket_sources.gd")
const Child=preload("res://core/spellteach_murloc_sources.gd")
const Cast=preload("res://core/spellteach_murloc_cast.gd")
const Pure=preload("res://core/recruit_gem_dr_host.gd")
const Delivery=preload("res://core/accepted_card_cursor_projection.gd")
const STATE="native_spellteach_trinket_slot"
const ACQUIRED="native_spellteach_trinket_acquired"
const EVENT="native_spellteach_trinket_taught"
const POLICY="actual_owned_slot_purchase_two_per_owner_turn_native_apprentice_v1"
static func fail(issue: String) -> Dictionary: return {"ok":false,"error":issue,"active":false}
static func has_source(p: Dictionary) -> bool: return Sources.ID in p.get("trinkets",[])
static func slot(p: Dictionary) -> int: return p.get("trinkets",[]).find(Sources.ID)
static func used(p: Dictionary,round_number: int) -> int:
	var quota: Dictionary=p.get(STATE,{}).get("quota",{})
	return int(quota.get("used",0)) if quota.get("round")==round_number else 0
static func owner_error(p: Dictionary,round_number: int,catalog,allow_new: int=-1) -> String:
	var indices: Array=[]
	for index in range(p.get("trinkets",[]).size()):
		if p.trinkets[index]==Sources.ID: indices.append(index)
	if indices.size()>1: return "spellteach_trinket_multiple_slot_order_partial"
	var row: Variant=p.get(STATE,{})
	if not row is Dictionary: return "spellteach_trinket_invalid_slot_ledger"
	if not row.is_empty():
		if not Child.fields(row,["owner","source_id","slot","round","sequence","event_index","quota"]) or row.owner!=p.id or row.source_id!=Sources.ID or not Child.integer(row.slot,0,7) or not Child.integer(row.round,1,round_number) or not Child.integer(row.sequence,1) or not Child.integer(row.event_index) or not row.quota is Dictionary: return "spellteach_trinket_changed_acquisition"
		if not row.quota.is_empty() and (not Child.fields(row.quota,["round","used"]) or not Child.integer(row.quota.round,int(row.round),round_number) or not Child.integer(row.quota.used,1,2)): return "spellteach_trinket_changed_quota"
	if not indices.is_empty() and indices[0]!=allow_new:
		if row.is_empty() or row.slot!=indices[0]: return "spellteach_trinket_missing_original_slot_receipt"
		return Sources.closure_error(catalog)
	return ""
static func domain(engine,p: Dictionary) -> String:
	for unit in p.board:
		if unit.get("card_id") in Child.PARENTS: return "spellteach_trinket_native_parent_mixed_order_partial"
		var hand: Dictionary=Delivery.hand_reader(engine,unit)
		if hand.claimed:
			if not str(hand.error).is_empty(): return str(hand.error)
			continue
		for effect in unit.get("effects",[]):
			if engine.DiscardHost._has_read(effect,["buy","purchase","spend"]): return "spellteach_trinket_competing_purchase_prefix_partial"
	for effect in engine.Mechanisms._effects(engine,p)+engine.catalog.get_card(str(p.get("hero_id",""))).get("effects",[]):
		if effect.get("type")==Sources.TYPE: continue
		if engine.DiscardHost._has_read(effect,["buy","purchase","spend"]): return "spellteach_trinket_owned_purchase_order_partial"
	if not p.get("mechanism_reward_queue",[]).is_empty(): return "spellteach_trinket_protected_delivery_partial"
	return ""
static func acquisition_error(engine,p: Dictionary,card: Dictionary) -> String:
	if card.get("id")!=Sources.ID: return ""
	if not engine.Spellteach.actual(engine,p) or card.get("choice_kind")!="trinket" or not p.discover.any(func(choice):return is_same(choice,card)): return "spellteach_trinket_real_offer_required"
	if has_source(p) or p.has(STATE): return "spellteach_trinket_multiple_or_replaced_slot_partial"
	var original: Dictionary=card.duplicate(true);original.erase("choice_kind")
	var issue: String=Sources.source_error(original)
	if issue.is_empty(): issue=Sources.closure_error(engine.catalog)
	return issue
static func acquired(engine,p: Dictionary,context: Dictionary) -> String:
	var ticket: Dictionary=engine._owned_timed_event_context
	if not engine.Spellteach.actual(engine,p) or context.get("source_kind")!="trinket" or context.get("source_id")!=Sources.ID or not is_same(ticket.get("owner"),p) or not is_same(ticket.get("context"),context) or ticket.get("event")!="mechanic_acquired" or ticket.get("round")!=engine.state.round or ticket.get("sequence")!=engine.state.command_sequence or "spellteach_trinket" in ticket.get("used",[]): return "spellteach_trinket_real_acquisition_capability_required"
	var index: int=p.trinkets.size()-1
	if index<0 or p.trinkets[index]!=Sources.ID or p.has(STATE): return "spellteach_trinket_original_new_slot_required"
	var issue: String=owner_error(p,int(engine.state.round),engine.catalog,index)
	if not issue.is_empty(): return issue
	var row: Dictionary={"owner":p.id,"source_id":Sources.ID,"slot":index,"round":engine.state.round,"sequence":engine.state.command_sequence,"event_index":engine.events.size(),"quota":{}}
	p[STATE]=row;ticket.used.append("spellteach_trinket")
	engine._log(ACQUIRED,{"player":p.id,"entry":row.duplicate(true),"policy":POLICY})
	return ""
static func prepare_buy(engine,p: Dictionary,spell: Dictionary,quoted: Dictionary) -> Dictionary:
	if not has_source(p) or spell.get("kind")!="spell" or not engine.Mechanisms.is_tavern_spell_card(engine.catalog.get_card(str(spell.get("card_id","")))): return {"ok":true,"error":"","active":false}
	var issue: String=owner_error(p,int(engine.state.round),engine.catalog)
	if not issue.is_empty(): return fail(issue)
	if used(p,int(engine.state.round))>=2: return {"ok":true,"error":"","active":false}
	if not engine.Spellteach.actual(engine,p) or not engine._spellteach_trinket_buy_context.is_empty() or not p.shop.any(func(unit):return is_same(unit,spell)): return fail("spellteach_trinket_real_shop_buy_required")
	issue=engine.Spellteach.saved_error(engine.state,engine.catalog,engine.events)
	if issue.is_empty(): issue=engine.Spellteach.spell_error(engine,spell)
	if issue.is_empty(): issue=domain(engine,p)
	if not issue.is_empty(): return fail(issue)
	if not quoted.get("ok",false) or not Child.integer(quoted.get("cost")) or ["health_currency","bouncy_health_offer","eye_sargeras_health","tapestry_health_currency","owned_health_currency","bazaar","pilgrimp","hasty_excavation"].any(func(key):return quoted.get(key,false)): return fail("spellteach_trinket_non_gold_purchase_partial")
	if p.hand.size()+2>10: return fail("spellteach_trinket_overflow_quota_semantics_partial")
	var command: Dictionary=engine._bounty_spend_command
	if not is_same(command.get("owner"),p) or command.get("action")!="buy" or command.get("round")!=engine.state.round or command.get("sequence")!=engine.state.command_sequence: return fail("spellteach_trinket_actual_command_required")
	var projected: Dictionary=Pure._state(engine,p);projected.next_uid=engine.next_uid;projected.pool=engine.pool.duplicate(true);projected.spell_pool=engine.spell_pool.duplicate(true)
	issue=Delivery.project(engine,projected,spell.duplicate(true),true)
	if not issue.is_empty(): return fail(issue)
	var child: Dictionary=engine._preview_native_minion(engine.catalog.get_card(Child.CHILD),"u"+str(projected.next_uid))
	if child.is_empty(): return fail("spellteach_trinket_missing_child_factory")
	projected.next_uid+=1
	issue=Delivery.project(engine,projected,child)
	if not issue.is_empty(): return fail(issue)
	return {"ok":true,"error":"","active":true,"owner":p,"spell":spell,"spell_uid":spell.uid,"spell_id":spell.card_id,"program":spell.effects.duplicate(true),"command":command,"round":engine.state.round,"sequence":engine.state.command_sequence,"ledger":p[STATE].duplicate(true),"used":used(p,int(engine.state.round)),"cost":quoted.cost,"gold":p.gold,"bought":p.stats.bought,"paid":false,"done":false}
static func paid(engine,p: Dictionary,spell: Dictionary,cost: int) -> String:
	var ticket: Dictionary=engine._spellteach_trinket_buy_context
	if ticket.is_empty(): return ""
	if not engine.Spellteach.actual(engine,p) or not is_same(ticket.owner,p) or not is_same(ticket.spell,spell) or not is_same(ticket.command,engine._bounty_spend_command) or ticket.paid or ticket.cost!=cost or p.gold!=ticket.gold-cost: return "spellteach_trinket_changed_actual_payment"
	ticket.paid=true;return ""
static func dispatch(engine,p: Dictionary,context: Dictionary) -> String:
	var ticket: Dictionary=engine._spellteach_trinket_buy_context
	if ticket.is_empty(): return ""
	var authority: Dictionary=engine._owned_timed_event_context
	var spell: Dictionary=context.get("unit",{})
	if not engine.Spellteach.actual(engine,p) or not is_same(authority.get("owner"),p) or not is_same(authority.get("context"),context) or authority.get("event")!="buy" or not is_same(ticket.owner,p) or not is_same(ticket.spell,spell) or not is_same(ticket.command,engine._bounty_spend_command) or ticket.round!=engine.state.round or ticket.sequence!=engine.state.command_sequence or not ticket.paid or ticket.done or p.stats.bought!=ticket.bought+1 or p.shop.any(func(unit):return is_same(unit,spell)) or not p.hand.any(func(unit):return is_same(unit,spell)): return "spellteach_trinket_unissued_committed_purchase"
	if slot(p)!=ticket.ledger.slot or not Child.same(p.get(STATE),ticket.ledger) or spell.uid!=ticket.spell_uid or spell.card_id!=ticket.spell_id or not Child.same(spell.effects,ticket.program): return "spellteach_trinket_original_slot_or_spell_changed"
	if p.hand.size()>=10: return "spellteach_trinket_delivery_capacity_changed"
	var state: Dictionary=Pure._state(engine,p);state.next_uid=engine.next_uid;state.pool=engine.pool.duplicate(true);state.spell_pool=engine.spell_pool.duplicate(true)
	var quota: Dictionary={"round":engine.state.round,"used":int(ticket.used)+1}
	state.player[STATE].quota=quota.duplicate(true)
	var child: Dictionary=engine._preview_native_minion(engine.catalog.get_card(Child.CHILD),"u"+str(state.next_uid))
	if child.is_empty(): return "spellteach_trinket_child_factory_failed"
	child.pool_count=0;child.pool_id="";child.pool_components=[];state.next_uid+=1
	child[Child.TAUGHT]={"uid":child.uid,"owner":p.id,"source_id":Sources.ID,"source_slot":ticket.ledger.slot,"acquired_event_index":ticket.ledger.event_index,"purchased_uid":spell.uid,"spell_id":spell.card_id,"round":engine.state.round,"sequence":engine.state.command_sequence,"spell_program":spell.effects.duplicate(true)}
	var expected: Dictionary=child.duplicate(true)
	var issue: String=Delivery.project(engine,state,child)
	if not issue.is_empty(): return issue
	ticket.done=true;p[STATE].quota=quota
	var actual: Dictionary=engine._unit(engine.catalog.get_card(Child.CHILD))
	actual.pool_count=0;actual.pool_id="";actual.pool_components=[];actual[Child.TAUGHT]=expected[Child.TAUGHT].duplicate(true)
	if not Child.same(actual,expected): return "spellteach_trinket_actual_child_changed"
	engine._add_hand(p,actual)
	if engine.state.phase=="error": return "spellteach_trinket_real_hand_delivery_failed"
	if not Child.same(engine.Spellteach.snapshot(engine,p),engine.Spellteach.projected(state)): return "spellteach_trinket_actual_delivery_projection_changed"
	engine._log(EVENT,{"player":p.id,"source_id":Sources.ID,"source_slot":ticket.ledger.slot,"acquired_event_index":ticket.ledger.event_index,"child_id":Child.CHILD,"child_uid":actual.uid,"spell_id":spell.card_id,"bought_uid":spell.uid,"binding":actual[Child.TAUGHT].duplicate(true),"used":quota.used,"round":engine.state.round,"sequence":engine.state.command_sequence,"policy":POLICY})
	return ""
static func finish(engine) -> String:
	var ticket: Dictionary=engine._spellteach_trinket_buy_context
	if ticket.is_empty(): return ""
	if not ticket.paid or not ticket.done: return "spellteach_trinket_unfinished_purchase"
	engine._spellteach_trinket_buy_context={};return ""
static func saved_receipts(state: Dictionary,catalog,events: Array) -> Dictionary:
	var receipts: Dictionary={};var last: Dictionary={};var purchases: Dictionary={}
	for p in state.get("players",[]):
		var issue: String=owner_error(p,int(state.get("round",0)),catalog)
		if not issue.is_empty(): return {"error":issue}
		if not p.has(STATE): continue
		issue=Sources.closure_error(catalog)
		if not issue.is_empty(): return {"error":issue}
		var row: Dictionary=p[STATE];var index: int=int(row.event_index)
		if index>=events.size() or row.sequence>int(state.get("command_sequence",0)): return {"error":"spellteach_trinket_missing_acquisition_event"}
		var root: Dictionary=row.duplicate(true);root.quota={}
		var event: Dictionary=events[index]
		if event.get("type")!=ACQUIRED or event.get("player")!=p.id or event.get("policy")!=POLICY or not Child.same(event.get("entry"),root): return {"error":"spellteach_trinket_changed_acquisition_receipt"}
	for event_index in range(events.size()):
		var event: Dictionary=events[event_index]
		if event.get("type")==ACQUIRED:
			var owners: Array=state.get("players",[]).filter(func(owner):return owner.get("id")==event.get("player"))
			if owners.size()!=1 or owners[0].get(STATE,{}).get("event_index")!=event_index: return {"error":"spellteach_trinket_orphan_acquisition"}
			continue
		if event.get("type")!=EVENT: continue
		var binding: Variant=event.get("binding")
		var owners: Array=state.get("players",[]).filter(func(owner):return owner.get("id")==event.get("player"))
		if owners.size()!=1 or event.get("policy")!=POLICY or event.get("source_id")!=Sources.ID or event.get("child_id")!=Child.CHILD or not Child.uid(event.get("child_uid")) or receipts.has(event.child_uid) or not Child.integer(event.get("round"),1,int(state.get("round",0))) or not Child.integer(event.get("sequence"),1,int(state.get("command_sequence",0))): return {"error":"spellteach_trinket_invalid_teaching_receipt"}
		var row: Dictionary=owners[0].get(STATE,{})
		if row.is_empty() or event.get("source_slot")!=row.slot or event.get("acquired_event_index")!=row.event_index or event.round<row.round or event.sequence<=row.sequence: return {"error":"spellteach_trinket_foreign_acquisition_lineage"}
		if not Child.fields(binding,["uid","owner","source_id","source_slot","acquired_event_index","purchased_uid","spell_id","round","sequence","spell_program"]) or binding.uid!=event.child_uid or binding.owner!=event.player or binding.source_id!=Sources.ID or binding.source_slot!=row.slot or binding.acquired_event_index!=row.event_index or binding.purchased_uid!=event.get("bought_uid") or binding.spell_id!=event.get("spell_id") or binding.round!=event.round or binding.sequence!=event.sequence or not Child.uid(binding.purchased_uid) or not Child.same(binding.spell_program,catalog.get_card(str(binding.spell_id)).get("effects")) or not Cast.card_error(catalog,str(binding.spell_id)).is_empty(): return {"error":"spellteach_trinket_changed_taught_binding"}
		var key: String=str(event.player);var previous: Dictionary=last.get(key,{})
		var expected: int=int(previous.get("used",0))+1 if previous.get("round")==event.round else 1
		if event.get("used")!=expected or expected>2 or int(previous.get("round",0))>int(event.round): return {"error":"spellteach_trinket_replayed_turn_quota"}
		var purchase: String=key+":"+str(binding.purchased_uid)
		if purchases.has(purchase): return {"error":"spellteach_trinket_replayed_purchase"}
		purchases[purchase]=true;last[key]={"round":event.round,"used":event.used};receipts[event.child_uid]=event
	for p in state.get("players",[]):
		if p.has(STATE) and not Child.same(p[STATE].quota,last.get(str(p.id),{})): return {"error":"spellteach_trinket_saved_quota_not_backed_by_receipts"}
	return {"error":"","receipts":receipts}
