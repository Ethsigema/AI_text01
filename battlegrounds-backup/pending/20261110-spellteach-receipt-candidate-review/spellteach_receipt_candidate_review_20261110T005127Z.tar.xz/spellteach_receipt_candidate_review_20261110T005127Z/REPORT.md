# 魔鳍普通取得收据：source_id 新候选与既有 unit 候选交互

## 结论

上一轮剩余的6种坏 receipt 诊断，确实发生在普通取得事件的 binding.source_id 比较中，早于单位校验。因此，已有 unit_error 候选不能单独覆盖它们。本轮保存一项**独立的新 host 单行候选**，与已有 unit 候选组合后，这6种位置/类型组合均正常拒绝，扩展定向测试也没有产生诊断。

这只证明所测函数片段与合成状态的局部行为。没有执行完整 Game、Combat、Catalog、编译器或完整 host，没有真实购买、施放、存档加载，也没有证明真实游戏能产生或到达这些坏状态。**两个候选均不安装，不称原样恢复、最新版、全面修复或游戏验收完成。**

- 原 host：16,204 bytes，SHA-256 `fa080e10757bde93b3c7b75332855576dcca08f7b2a4fdc589dc20907fe7cafe`。
- 新 host 候选：16,212 bytes，SHA-256 `7b265ceb628cd686490d3bb9ebcd753234c5de9d923cc5695b147ef0e797efb9`。
- 新 receipt 补丁 SHA-256：`a8626986816cff147d841bb709fc8b554cc3b5e66a6cb7b89301db411712ce5d`。
- 已有 unit 候选原样复制：SHA-256 `8cb583cf4c1e9ddaea7579b46b9812abb05d0ac14a43a689f174f3a0a37273b8`。旧候选、旧补丁和旧封包均未修改。

## 1. 诊断位置与新改动

原 `core/spellteach_murloc_host.gd` 第117行先要求事件顶层 source_id 属于普通/金色 PARENTS。第119行检查 binding 的精确键集合后，使用：

`binding.source_id!=event.source_id`

顶层身份合法不能保证嵌套字段类型合法。把嵌套 source_id 换为 bool、int、Array，原比较会诊断；函数的空String默认返回不是正常通过。它发生在第144行 unit_error 之前，解释了上一轮单位候选为何还剩6次诊断。

新候选只将该表达式改为：

`binding.source_id not in [event.source_id]`

没有字符串强转，没有增加身份白名单，没有改fields、owner、UID、回合、sequence、program、配额、重放、完整收据一致性或其他错误码。正常不匹配仍返回 spellteach_changed_acquisition_binding。

当前原写入路径把同一受限父体身份写入child和事件；饰品来源使用固定String常量。没有发现正常生产路径主动生成本轮坏类型。完整外部入口还有其他检查，既不能从静态调用边推成故障可达，也不能把后置拒绝误称为前置类型防护。

## 2. 四种组合揭示两处修正的互补关系

- OO：原receipt函数 + 原unit_error。
- U：原receipt函数 + 既有unit候选。
- R：新receipt候选 + 原unit_error。
- UR：新receipt候选 + 既有unit候选。

每轮3712次矩阵调用：58个代表值（39个Variant类型标签）×普通/金色两身份×事件顶层String/StringName两形式×4个污染位置×4种组合。

四种位置为仅receipt binding、仅unit binding、两者同时、仅事件顶层source_id。每种组合928次：

| 组合 | 有诊断调用 | 无诊断允许 | 无诊断拒绝 |
|---|---:|---:|---:|
| OO | 552 | 24 | 352 |
| U | 368 | 24 | 536 |
| R | 184 | 24 | 720 |
| UR | 0 | 24 | 904 |

- 原版376个无诊断结果在UR中逐字保持，包括24允许和352拒绝。
- 原版552个诊断调用在UR中均变为明确拒绝。
- U余下368个诊断来自receipt-only/both；R余下184个诊断来自unit-only。只修其中一处不能消除另一处的目标边界。
- 两轮原始JSON、分类结果及日志分别一致。每次检查输入不变；没有把原版空String或exit=0当成功。

SIX_CASE_CLOSURE.json单列上一轮6种位置/类型组合：普通父体、顶层String、receipt-only/both × bool_true/int_one/array。当前使用完整固定法术数据与更真实的依赖片段重新构造fixture，并非直接复用旧宽松stub。U中6例仍诊断并空返回；UR中6例均无诊断返回 spellteach_changed_acquisition_binding。

这些只是代表值覆盖，不是每个类型所有值、所有其他字段或全部状态空间的穷尽测试。

## 3. StringName兼容与完整收据检查没有弱化

新成员判断保留当前原版的String/StringName身份比较兼容：事件顶层与receipt.binding的身份文本相同，可以继续往下检查。

但后置 Sources.same 对完整receipt.binding与unit.binding仍按typeof严格比较。若二者source_id分别是String和StringName，原来会拒绝的情况仍返回 unproven_saved_teaching_lineage；若二者均为同一StringName，则保留原正常结果。未知文本、错父体、饰品身份和空/null等反例仍按原作用域拒绝。

本候选没有将same改成宽松比较，也没有因新前置判断成功就跳过后置校验。

## 4. 实际执行的最小依赖与未执行部分

本轮不再使用上次的“Owned/Cast无条件允许”stub。新独立工程中：

1. 四份host片段保留相应版本 `saved_error` 的完整函数体，逐字从原件/候选抽取。完整host文件只保存，不加载。
2. Owned使用当前原版 `owner_error`、`saved_receipts` 和原四个常量的逐字片段。当前实际host没有 `_slots`，没有混入其他版本。
3. 加载真实TrinketSources、其7份proof，以及真实Spellteach Sources及8份proof、Exact、PoolIdentity。正常owned控制使用实际host的单数STATE键。Sources中的复数STATE常量原样保留，未借本任务修订二者。
4. Cast.card_error、Yogg.same、Yogg.child_error的函数体和完整21项CHILDREN常量均逐字提取。使用其中完整raw+overlay构造最小Catalog，绑定其完整effects，不执行法术效果。
5. Yogg.child_error的第三参数按原两参调用保持默认false，六种自动扩展均短路。依赖位置由明确push_error、计数并拒绝的sentinel占位；所有运行都断言调用次数为0。没有用静默成功stub代替扩展验证，也不声称未执行扩展已验收。
6. Catalog与source_catalog是两份不同对象、不同数据副本。控制例分别改变两层法术源码，实际child_error都拒绝。

四组合的Owned共享既有unit候选类，但它只调用未改动的fields、integer、same、uid；TrinketSources调用未改动的closure_error，没有经这条共享依赖调用unit_error。直接host单位校验才按四组合分别绑定原/新unit_error。该限定可由逐字diff、preload图和函数调用核对，不隐藏共享依赖。

最小依赖不等于完整工程依赖闭合。真实host capability、对象身份、支付、完整Catalog摄入、事件创建与保存/加载仍未执行。此前真实Game可达性未证实的结论保持。

## 5. 正常路径与拒绝控制

117个控制例在四种组合下各执行，共468次/轮，全部无诊断、返回逐字一致：57个局部允许、60个局部拒绝。

包含：

- 21项固定完整法术程序，分别配普通/金色来源，共42个控制例。这里验证的是原函数允许的绑定数据，不是实际施放。
- board/hand/shop/mechanism_reward_queue四个受检zone及两种父体，和真实形状的父体quota字段。某zone局部允许不表示实际游戏会将该单位放在那里。
- 金色两次配额、普通下一回合重置；普通超额、同一购买重复、最新quota不符等反例。
- 无收据、移除binding、重复child、binding缺/多字段或非Dictionary、程序变化、未来回合/sequence、owner/policy/child/UID/used变化等拒绝。
- 完整合成minion-cast收据及origin、repetition、sequence、重复spell UID、spell身份变化。只调用收据验证，不实际施放。
- 正常owned取得/教授ledger和收据，以及缺ledger、取得entry变更、quota变更、重复购买等控制。
- 15份proof各改字节/缺失，共30个负变体。全部返回对应proof错误；每次仅修改本轮新工程副本，随后恢复并回读固定字节。没有修改runtime原proof。

上次1197例unit/source回归没有在本轮重复计算；旧unit候选字节及其已封存证据保持，本轮针对新增receipt函数及交互执行上述新测试。不把旧结果冒充本轮新运行。

## 6. 验证、便携复跑与资源

verify_results.py具有逐例符号模型，单独计算每个矩阵调用的预期返回与诊断数量，检查四组合、后置类型相等、正常结果保持及6例闭合；也验证全部117控制例预期、原日志begin/end完整配对与结果顺序。每轮源代码fragment中的输入不变断言、sentinel零调用断言均通过。

37文件白名单便携副本重新运行矩阵双轮、控制双轮和结果验证。14份JSON/原始日志与本目录逐字一致；输入及proof恢复后hash一致。复跑不依赖原runtime，不联网或下载：

`python3 replay_to_new.py /一个尚不存在的绝对目录`

矩阵每轮约0.9–1.3秒，含便携复跑峰值约87.1MiB；控制每轮约3秒、峰值约77MiB。受测Godot进程均串行，隔离HOME/XDG，设192MiB RSS停止线、2GiB地址空间、45秒时限和系统可用内存下限。Python来源核验限128MiB地址空间。

独立复核另核对29个输入pin、10个逐字抽取记录、16文件preload图及8,360个主运行调用日志区间，重建四组合模型；并核对37个便携输入、14个输出和6例清单。完整报告见 review_independent/REVIEW.md。它只运行独立Python审查，不算另一次Godot执行；其审查脚本依赖原工作区来源及已完成便携目录，不替代 replay_to_new.py 便携入口。

## 7. 不变边界与后续

41条来源pin记录（31个唯一路径）、15份proof副本和10个旧归档回读一致。原host、原Sources、旧unit候选、Game、Catalog和旧备份未变。345个工具仍缺失，XML36.6.3候选未安装，既有四份全局原证据与两份全局合同缺口未填补。没有改Python编译器或宣称Game/存档通过。

本候选只处理普通取得receipt的source_id这一处比较。其他binding字段直接比较、饰品ledger/事件类型边界及完整host的其他路径没有全面硬化；本轮0诊断只能用于本轮已覆盖的组合。不能为追求“全绿”削弱校验、扩展身份或把真实前置门控换成允许stub。

可安全下一步是保留两处明确新修正及限定证据，待完整版本/依赖闭合后再审集成。当前继续暂缓安装，不升级可达性或验收结论。全程本地，无网络、下载或取消操作重试；封包排除缓存、隔离HOME/XDG、凭据、私聊和存档。
