# 精确源码片段

这些片段仅供只读审阅，未作为完整脚本运行。每个 fragment 为来源指定行的原字节，含原始换行。

## host_parent_selection: core/spellteach_murloc_host.gd:12–15

```gdscript
  12 static func actual(engine,p: Dictionary) -> bool: return Actual._actual_game_host(engine) and engine.state.get("phase")=="recruit" and p.get("alive")==true and engine.state.players.any(func(owner):return is_same(owner,p))
  13 static func sources(p: Dictionary,round_number: int) -> Array:
  14 	return p.get("board",[]).filter(func(unit):return unit.get("card_id") in Sources.PARENTS and Pure.Gains.active(unit) and used(unit,round_number)<int(Sources.PROGRAMS[unit.card_id][0].limit))
  15 static func used(unit: Dictionary,round_number: int) -> int: return int(unit.get(Sources.QUOTA,{}).get("used",0)) if unit.get(Sources.QUOTA,{}).get("round")==round_number else 0
```

## host_purchase_preflight: core/spellteach_murloc_host.gd:44–60

```gdscript
  44 static func prepare_buy(engine,p: Dictionary,spell: Dictionary,quoted: Dictionary,issued: bool=true) -> Dictionary:
  45 	if spell.get("kind")!="spell" or not engine.Mechanisms.is_tavern_spell_card(engine.catalog.get_card(str(spell.get("card_id","")))) or sources(p,int(engine.state.round)).is_empty(): return {"ok":true,"error":"","active":false}
  46 	if not actual(engine,p) or not p.shop.any(func(unit):return is_same(unit,spell)): return fail("spellteach_actual_shop_offer_required")
  47 	if not engine._spellteach_buy_context.is_empty(): return fail("spellteach_nested_buy")
  48 	var issue: String=saved_error(engine.state,engine.catalog,engine.events)
  49 	if issue.is_empty(): issue=Sources.closure_error(engine.catalog)
  50 	if issue.is_empty(): issue=spell_error(engine,spell)
  51 	if issue.is_empty(): issue=_observers_error(engine,p)
  52 	if not issue.is_empty(): return fail(issue)
  53 	if not quoted.get("ok",false) or not Sources.integer(quoted.get("cost")) or ["health_currency","bouncy_health_offer","eye_sargeras_health","tapestry_health_currency","owned_health_currency","bazaar","pilgrimp"].any(func(key):return quoted.get(key,false)): return fail("spellteach_non_gold_quote_partial")
  54 	if p.hand.size()+1+sources(p,int(engine.state.round)).size()>10: return fail("spellteach_overflow_quota_semantics_partial")
  55 	var command: Dictionary=engine._bounty_spend_command
  56 	if issued and (not is_same(command.get("owner"),p) or command.get("action")!="buy" or command.get("round")!=engine.state.round or command.get("sequence")!=engine.state.command_sequence): return fail("spellteach_real_buy_command_required")
  57 	var records: Array=[]
  58 	for source in sources(p,int(engine.state.round)):
  59 		issue=Sources.unit_error(source,engine.catalog)
  60 		if not issue.is_empty(): return fail(issue)
```

## host_write_and_event: core/spellteach_murloc_host.gd:77–105

```gdscript
  77 	ticket.paid=true;return ""
  78 static func dispatch(engine,p: Dictionary,spell: Dictionary,source: Dictionary) -> String:
  79 	var ticket: Dictionary=engine._spellteach_buy_context
  80 	if ticket.is_empty(): return ""
  81 	var records: Array=ticket.records.filter(func(row):return is_same(row.source,source))
  82 	if records.is_empty(): return ""
  83 	var record: Dictionary=records[0]
  84 	if not actual(engine,p) or not is_same(ticket.owner,p) or not is_same(ticket.spell,spell) or not is_same(ticket.command,engine._bounty_spend_command) or ticket.round!=engine.state.round or ticket.sequence!=engine.state.command_sequence or not ticket.paid or record.done or p.stats.bought!=ticket.bought_before+1 or p.shop.any(func(unit):return is_same(unit,spell)) or not p.hand.any(func(unit):return is_same(unit,spell)): return "spellteach_unissued_successful_purchase"
  85 	if not p.board.any(func(unit):return is_same(unit,source)) or source.uid!=record.uid or source.card_id!=record.id or not Pure.Gains.active(source) or not Sources.same(source.get(Sources.QUOTA,{}),record.before) or spell.uid!=ticket.spell_uid or spell.card_id!=ticket.spell_id or not Sources.same(spell.effects,ticket.spell_program): return "spellteach_original_source_or_spell_changed"
  86 	if p.hand.size()>=10: return "spellteach_unplanned_delivery_capacity_change"
  87 	var state: Dictionary=Pure._state(engine,p);state.next_uid=engine.next_uid;state.pool=engine.pool.duplicate(true);state.spell_pool=engine.spell_pool.duplicate(true)
  88 	var quota: Dictionary={"uid":source.uid,"id":source.card_id,"owner":p.id,"round":engine.state.round,"used":int(record.used)+1}
  89 	Pure.Gains._find(state.player.board,str(source.uid))[Sources.QUOTA]=quota.duplicate(true)
  90 	var child: Dictionary=engine._preview_native_minion(engine.catalog.get_card(Sources.CHILD),"u"+str(state.next_uid))
  91 	if child.is_empty(): return "spellteach_native_child_factory_failed"
  92 	child.pool_count=0;child.pool_id="";child.pool_components=[];state.next_uid+=1
  93 	child[Sources.TAUGHT]={"uid":child.uid,"owner":p.id,"source_id":source.card_id,"source_uid":source.uid,"purchased_uid":spell.uid,"spell_id":spell.card_id,"round":engine.state.round,"sequence":engine.state.command_sequence,"spell_program":spell.effects.duplicate(true)}
  94 	var expected_child: Dictionary=child.duplicate(true)
  95 	var issue: String=Delivery.project(engine,state,child)
  96 	if not issue.is_empty(): return issue
  97 	record.done=true;source[Sources.QUOTA]=quota
  98 	var generated: Dictionary=engine._unit(engine.catalog.get_card(Sources.CHILD))
  99 	generated.pool_count=0;generated.pool_id="";generated.pool_components=[];generated[Sources.TAUGHT]=expected_child[Sources.TAUGHT].duplicate(true)
 100 	if not Sources.same(generated,expected_child): return "spellteach_actual_child_factory_changed"
 101 	engine._add_hand(p,generated)
 102 	if engine.state.phase=="error": return "spellteach_actual_accepted_child_failed"
 103 	if not Sources.same(snapshot(engine,p),projected(state)): return "spellteach_accepted_hand_cursor_changed"
 104 	engine._log("native_spellteach_acquired",{"player":p.id,"source_id":source.card_id,"source_uid":source.uid,"bought_uid":spell.uid,"spell_id":spell.card_id,"child_id":Sources.CHILD,"child_uid":generated.uid,"binding":generated[Sources.TAUGHT].duplicate(true),"used":quota.used,"round":engine.state.round,"sequence":engine.state.command_sequence,"policy":POLICY})
 105 	return ""
```

## host_saved_error: core/spellteach_murloc_host.gd:111–156

```gdscript
 111 static func saved_error(state: Dictionary,catalog,events: Array) -> String:
 112 	var owned: Dictionary=Owned.saved_receipts(state,catalog,events)
 113 	if not str(owned.error).is_empty(): return str(owned.error)
 114 	var receipts: Dictionary=owned.receipts;var quotas: Dictionary={};var purchases: Dictionary={}
 115 	for event in events:
 116 		if event.get("type")!="native_spellteach_acquired": continue
 117 		if event.get("policy")!=POLICY or event.get("source_id") not in Sources.PARENTS or event.get("child_id")!=Sources.CHILD or not Sources.uid(event.get("child_uid")) or receipts.has(event.child_uid) or not Sources.integer(event.get("round"),1,int(state.get("round",0))) or not Sources.integer(event.get("sequence"),1,int(state.get("command_sequence",0))): return "spellteach_invalid_acquisition_receipt"
 118 		var binding: Variant=event.get("binding")
 119 		if not Sources.fields(binding,["uid","owner","source_id","source_uid","purchased_uid","spell_id","round","sequence","spell_program"]) or binding.uid!=event.child_uid or binding.owner!=event.get("player") or binding.source_id!=event.source_id or binding.source_uid!=event.get("source_uid") or binding.purchased_uid!=event.get("bought_uid") or binding.spell_id!=event.get("spell_id") or binding.round!=event.round or binding.sequence!=event.sequence or not Sources.uid(binding.source_uid) or not Sources.uid(binding.purchased_uid) or not Sources.same(binding.spell_program,catalog.get_card(str(binding.spell_id)).get("effects")): return "spellteach_changed_acquisition_binding"
 120 		if not state.get("players",[]).any(func(owner):return owner.get("id")==event.get("player")) or not Cast.card_error(catalog,str(binding.spell_id)).is_empty(): return "spellteach_unbound_receipt_owner_or_spell"
 121 		var key: String=str(event.player)+":"+str(event.source_uid)
 122 		var prior: Dictionary=quotas.get(key,{})
 123 		var expected_used: int=int(prior.get("used",0))+1 if prior.get("round")==event.round else 1
 124 		if event.get("used")!=expected_used or expected_used>int(Sources.PROGRAMS[event.source_id][0].limit) or not prior.is_empty() and (prior.id!=event.source_id or int(prior.round)>int(event.round)): return "spellteach_replayed_or_changed_round_quota"
 125 		var purchase_key: String=key+":"+str(event.bought_uid)
 126 		if purchases.has(purchase_key): return "spellteach_same_purchase_replayed"
 127 		purchases[purchase_key]=true
 128 		quotas[key]={"uid":event.source_uid,"id":event.source_id,"owner":event.player,"round":event.round,"used":event.used}
 129 		receipts[event.child_uid]=event
 130 	var cast_uids: Dictionary={};var cast_steps: Dictionary={}
 131 	for event in events:
 132 		if event.get("type")!="native_spellteach_minion_cast": continue
 133 		if event.get("origin")!=Cast.ORIGIN or event.get("caster_kind")!="minion" or event.get("source_id")!=Sources.CHILD or not receipts.has(event.get("source_uid")) or not Sources.uid(event.get("spell_uid")) or cast_uids.has(event.spell_uid) or receipts.has(event.spell_uid) or not Sources.integer(event.get("round"),1,int(state.get("round",0))) or not Sources.integer(event.get("sequence"),1,int(state.get("command_sequence",0))) or not Sources.integer(event.get("repetition"),1): return "spellteach_invalid_minion_cast_receipt"
 134 		var acquisition: Dictionary=receipts[event.source_uid]
 135 		if event.get("player")!=acquisition.player or event.get("spell_id")!=acquisition.spell_id or int(event.round)<int(acquisition.round) or int(event.sequence)<=int(acquisition.sequence) or event.get("target_zone") not in ["board","shop"] or event.get("target_uid")!="" and not Sources.uid(event.get("target_uid")): return "spellteach_changed_minion_cast_lineage"
 136 		var cast_key: String=str(event.source_uid)+":"+str(event.sequence)
 137 		if int(event.repetition)!=int(cast_steps.get(cast_key,0))+1: return "spellteach_replayed_minion_cast_step"
 138 		cast_steps[cast_key]=event.repetition;cast_uids[event.spell_uid]=true
 139 	for player in state.get("players",[]):
 140 		for zone in ["board","hand","shop","mechanism_reward_queue"]:
 141 			for unit in player.get(zone,[]):
 142 				if cast_uids.has(unit.get("uid")): return "spellteach_ephemeral_spell_restored_as_owned_card"
 143 				if not Sources.claimed(unit): continue
 144 				var issue: String=Sources.unit_error(unit,catalog)
 145 				if not issue.is_empty(): return issue
 146 				var quota_key: String=str(player.id)+":"+str(unit.uid)
 147 				if unit.get("card_id") in Sources.PARENTS and (unit.has(Sources.QUOTA) or quotas.has(quota_key)) and not Sources.same(unit.get(Sources.QUOTA),quotas.get(quota_key)): return "spellteach_quota_disagrees_with_actual_purchase_receipts"
 148 				if unit.has(Sources.QUOTA):
 149 					var quota: Dictionary=unit[Sources.QUOTA]
 150 					if quota.owner!=player.id or quota.round>int(state.round): return "spellteach_foreign_or_future_quota"
 151 				if receipts.has(unit.uid) and not unit.has(Sources.TAUGHT): return "spellteach_saved_teaching_binding_removed"
 152 				if not unit.has(Sources.TAUGHT): continue
 153 				var binding: Dictionary=unit[Sources.TAUGHT]
 154 				if binding.owner!=player.id or binding.round>int(state.round) or binding.sequence>int(state.get("command_sequence",0)) or not receipts.has(unit.uid) or not Sources.same(receipts[unit.uid].get("binding"),binding): return "spellteach_unproven_saved_teaching_lineage"
 155 				if not Cast.card_error(catalog,str(binding.spell_id)).is_empty(): return "spellteach_saved_spell_source_changed"
 156 	return ""
```

## sources_identity_constants: core/spellteach_murloc_sources.gd:5–10

```gdscript
   5 const CAST: String="battlecry_taught_tavern_spell"
   6 const CHILD: String="BG33_890t"
   7 const PARENTS: Array=["BG33_891","BG33_891_G"]
   8 const IDS: Array=["BG33_891","BG33_891_G","BG33_890t"]
   9 const QUOTA: String="native_spellteach_purchase_quota"
  10 const TAUGHT: String="native_spellteach_binding"
```

## sources_helpers: core/spellteach_murloc_sources.gd:16–21

```gdscript
  16 static func same(a: Variant,b: Variant) -> bool: return Exact.same(a,b)
  17 static func integer(v: Variant,low: int=0,high: int=2147483647) -> bool: return (v is int or v is float) and not v is bool and is_finite(float(v)) and v==floor(float(v)) and v>=low and v<=high
  18 static func uid(v: Variant) -> bool: return v is String and v.begins_with("u") and v.substr(1).is_valid_int() and int(v.substr(1))>0 and str(int(v.substr(1)))==v.substr(1)
  19 static func fields(v: Variant,keys: Array) -> bool: return v is Dictionary and v.size()==keys.size() and keys.all(func(key):return v.has(key))
  20 static func claimed(card: Dictionary) -> bool:
  21 	return card.get("id",card.get("card_id")) in IDS or card.has(QUOTA) or card.has(TAUGHT) or card.get("effects",[]).any(func(e):return e is Dictionary and e.get("type") in [TYPE,CAST])
```

## sources_unit_error: core/spellteach_murloc_sources.gd:50–73

```gdscript
  50 static func unit_error(unit: Dictionary,catalog=null) -> String:
  51 	if not claimed(unit): return ""
  52 	if unit.has("id") and not unit.has("card_id"): return source_error(unit)
  53 	if unit.get("card_id") not in IDS: return "spellteach_foreign_body"
  54 	var id: String=unit.card_id;var raw: Dictionary=RAW[id]
  55 	if not same(unit.get("effects"),PROGRAMS[id]) or unit.get("kind","minion")!="minion" or unit.get("name")!=raw.name or unit.get("golden")!=raw.is_golden or not same(unit.get("tribes"),raw.tribes) or not integer(unit.get("tier"),1,7): return "spellteach_native_body_changed"
  56 	if catalog!=null and unit.tier!=catalog.get_card(id).get("tier"): return "spellteach_effective_tier_changed"
  57 	if not unit.has("uid"): return "spellteach_private_state_on_template" if unit.has(QUOTA) or unit.has(TAUGHT) else "" # Native base templates carry no private state.
  58 	if not uid(unit.uid): return "spellteach_invalid_physical_uid"
  59 	if unit.get("text")!=raw.text: return "spellteach_native_text_changed"
  60 	if unit.has(QUOTA):
  61 		var row: Variant=unit[QUOTA]
  62 		if id not in PARENTS or not fields(row,["uid","id","owner","round","used"]) or row.uid!=unit.uid or row.id!=id or not integer(row.owner) or not integer(row.round,1) or not integer(row.used,1,int(PROGRAMS[id][0].limit)): return "spellteach_invalid_per_physical_source_quota"
  63 	if unit.has(TAUGHT):
  64 		var row: Variant=unit[TAUGHT]
  65 		if not row is Dictionary: return "spellteach_invalid_actual_purchase_binding"
  66 		if row.get("source_id")=="BG35_MagicItem_750":
  67 			# Owned source is an actual acquired slot, never a fabricated minion UID.
  68 			if id!=CHILD or not fields(row,["uid","owner","source_id","source_slot","acquired_event_index","purchased_uid","spell_id","round","sequence","spell_program"]) or row.uid!=unit.uid or not integer(row.source_slot,0,7) or not integer(row.acquired_event_index) or not uid(row.purchased_uid) or row.uid==row.purchased_uid or not integer(row.owner) or not integer(row.round,1) or not integer(row.sequence,1) or not row.spell_id is String or not row.spell_program is Array: return "spellteach_invalid_owned_purchase_binding"
  69 		else:
  70 			if id!=CHILD or not fields(row,["uid","owner","source_id","source_uid","purchased_uid","spell_id","round","sequence","spell_program"]) or row.uid!=unit.uid or row.source_id not in PARENTS or not uid(row.source_uid) or not uid(row.purchased_uid) or not integer(row.owner) or not integer(row.round,1) or not integer(row.sequence,1) or not row.spell_id is String or not row.spell_program is Array: return "spellteach_invalid_actual_purchase_binding"
  71 			if row.uid in [row.source_uid,row.purchased_uid] or row.source_uid==row.purchased_uid: return "spellteach_aliased_purchase_binding"
  72 		if catalog!=null and not same(row.spell_program,catalog.get_card(row.spell_id).get("effects")): return "spellteach_changed_taught_program"
  73 	return ""
```

## owned_constants: core/spellteach_trinket_host.gd:8–11

```gdscript
   8 const STATE="native_spellteach_trinket_slot"
   9 const ACQUIRED="native_spellteach_trinket_acquired"
  10 const EVENT="native_spellteach_trinket_taught"
  11 const POLICY="actual_owned_slot_purchase_two_per_owner_turn_native_apprentice_v1"
```

## owned_owner_error: core/spellteach_trinket_host.gd:18–31

```gdscript
  18 static func owner_error(p: Dictionary,round_number: int,catalog,allow_new: int=-1) -> String:
  19 	var indices: Array=[]
  20 	for index in range(p.get("trinkets",[]).size()):
  21 		if p.trinkets[index]==Sources.ID: indices.append(index)
  22 	if indices.size()>1: return "spellteach_trinket_multiple_slot_order_partial"
  23 	var row: Variant=p.get(STATE,{})
  24 	if not row is Dictionary: return "spellteach_trinket_invalid_slot_ledger"
  25 	if not row.is_empty():
  26 		if not Child.fields(row,["owner","source_id","slot","round","sequence","event_index","quota"]) or row.owner!=p.id or row.source_id!=Sources.ID or not Child.integer(row.slot,0,7) or not Child.integer(row.round,1,round_number) or not Child.integer(row.sequence,1) or not Child.integer(row.event_index) or not row.quota is Dictionary: return "spellteach_trinket_changed_acquisition"
  27 		if not row.quota.is_empty() and (not Child.fields(row.quota,["round","used"]) or not Child.integer(row.quota.round,int(row.round),round_number) or not Child.integer(row.quota.used,1,2)): return "spellteach_trinket_changed_quota"
  28 	if not indices.is_empty() and indices[0]!=allow_new:
  29 		if row.is_empty() or row.slot!=indices[0]: return "spellteach_trinket_missing_original_slot_receipt"
  30 		return Sources.closure_error(catalog)
  31 	return ""
```

## owned_source_write: core/spellteach_trinket_host.gd:104–118

```gdscript
 104 	var child: Dictionary=engine._preview_native_minion(engine.catalog.get_card(Child.CHILD),"u"+str(state.next_uid))
 105 	if child.is_empty(): return "spellteach_trinket_child_factory_failed"
 106 	child.pool_count=0;child.pool_id="";child.pool_components=[];state.next_uid+=1
 107 	child[Child.TAUGHT]={"uid":child.uid,"owner":p.id,"source_id":Sources.ID,"source_slot":ticket.ledger.slot,"acquired_event_index":ticket.ledger.event_index,"purchased_uid":spell.uid,"spell_id":spell.card_id,"round":engine.state.round,"sequence":engine.state.command_sequence,"spell_program":spell.effects.duplicate(true)}
 108 	var expected: Dictionary=child.duplicate(true)
 109 	var issue: String=Delivery.project(engine,state,child)
 110 	if not issue.is_empty(): return issue
 111 	ticket.done=true;p[STATE].quota=quota
 112 	var actual: Dictionary=engine._unit(engine.catalog.get_card(Child.CHILD))
 113 	actual.pool_count=0;actual.pool_id="";actual.pool_components=[];actual[Child.TAUGHT]=expected[Child.TAUGHT].duplicate(true)
 114 	if not Child.same(actual,expected): return "spellteach_trinket_actual_child_changed"
 115 	engine._add_hand(p,actual)
 116 	if engine.state.phase=="error": return "spellteach_trinket_real_hand_delivery_failed"
 117 	if not Child.same(engine.Spellteach.snapshot(engine,p),engine.Spellteach.projected(state)): return "spellteach_trinket_actual_delivery_projection_changed"
 118 	engine._log(EVENT,{"player":p.id,"source_id":Sources.ID,"source_slot":ticket.ledger.slot,"acquired_event_index":ticket.ledger.event_index,"child_id":Child.CHILD,"child_uid":actual.uid,"spell_id":spell.card_id,"bought_uid":spell.uid,"binding":actual[Child.TAUGHT].duplicate(true),"used":quota.used,"round":engine.state.round,"sequence":engine.state.command_sequence,"policy":POLICY})
```

## owned_saved_receipts: core/spellteach_trinket_host.gd:125–159

```gdscript
 125 static func saved_receipts(state: Dictionary,catalog,events: Array) -> Dictionary:
 126 	var receipts: Dictionary={};var last: Dictionary={};var purchases: Dictionary={}
 127 	for p in state.get("players",[]):
 128 		var issue: String=owner_error(p,int(state.get("round",0)),catalog)
 129 		if not issue.is_empty(): return {"error":issue}
 130 		if not p.has(STATE): continue
 131 		issue=Sources.closure_error(catalog)
 132 		if not issue.is_empty(): return {"error":issue}
 133 		var row: Dictionary=p[STATE];var index: int=int(row.event_index)
 134 		if index>=events.size() or row.sequence>int(state.get("command_sequence",0)): return {"error":"spellteach_trinket_missing_acquisition_event"}
 135 		var root: Dictionary=row.duplicate(true);root.quota={}
 136 		var event: Dictionary=events[index]
 137 		if event.get("type")!=ACQUIRED or event.get("player")!=p.id or event.get("policy")!=POLICY or not Child.same(event.get("entry"),root): return {"error":"spellteach_trinket_changed_acquisition_receipt"}
 138 	for event_index in range(events.size()):
 139 		var event: Dictionary=events[event_index]
 140 		if event.get("type")==ACQUIRED:
 141 			var owners: Array=state.get("players",[]).filter(func(owner):return owner.get("id")==event.get("player"))
 142 			if owners.size()!=1 or owners[0].get(STATE,{}).get("event_index")!=event_index: return {"error":"spellteach_trinket_orphan_acquisition"}
 143 			continue
 144 		if event.get("type")!=EVENT: continue
 145 		var binding: Variant=event.get("binding")
 146 		var owners: Array=state.get("players",[]).filter(func(owner):return owner.get("id")==event.get("player"))
 147 		if owners.size()!=1 or event.get("policy")!=POLICY or event.get("source_id")!=Sources.ID or event.get("child_id")!=Child.CHILD or not Child.uid(event.get("child_uid")) or receipts.has(event.child_uid) or not Child.integer(event.get("round"),1,int(state.get("round",0))) or not Child.integer(event.get("sequence"),1,int(state.get("command_sequence",0))): return {"error":"spellteach_trinket_invalid_teaching_receipt"}
 148 		var row: Dictionary=owners[0].get(STATE,{})
 149 		if row.is_empty() or event.get("source_slot")!=row.slot or event.get("acquired_event_index")!=row.event_index or event.round<row.round or event.sequence<=row.sequence: return {"error":"spellteach_trinket_foreign_acquisition_lineage"}
 150 		if not Child.fields(binding,["uid","owner","source_id","source_slot","acquired_event_index","purchased_uid","spell_id","round","sequence","spell_program"]) or binding.uid!=event.child_uid or binding.owner!=event.player or binding.source_id!=Sources.ID or binding.source_slot!=row.slot or binding.acquired_event_index!=row.event_index or binding.purchased_uid!=event.get("bought_uid") or binding.spell_id!=event.get("spell_id") or binding.round!=event.round or binding.sequence!=event.sequence or not Child.uid(binding.purchased_uid) or not Child.same(binding.spell_program,catalog.get_card(str(binding.spell_id)).get("effects")) or not Cast.card_error(catalog,str(binding.spell_id)).is_empty(): return {"error":"spellteach_trinket_changed_taught_binding"}
 151 		var key: String=str(event.player);var previous: Dictionary=last.get(key,{})
 152 		var expected: int=int(previous.get("used",0))+1 if previous.get("round")==event.round else 1
 153 		if event.get("used")!=expected or expected>2 or int(previous.get("round",0))>int(event.round): return {"error":"spellteach_trinket_replayed_turn_quota"}
 154 		var purchase: String=key+":"+str(binding.purchased_uid)
 155 		if purchases.has(purchase): return {"error":"spellteach_trinket_replayed_purchase"}
 156 		purchases[purchase]=true;last[key]={"round":event.round,"used":event.used};receipts[event.child_uid]=event
 157 	for p in state.get("players",[]):
 158 		if p.has(STATE) and not Child.same(p[STATE].quota,last.get(str(p.id),{})): return {"error":"spellteach_trinket_saved_quota_not_backed_by_receipts"}
 159 	return {"error":"","receipts":receipts}
```

## trinket_sources_constants: core/spellteach_trinket_sources.gd:5–12

```gdscript
   5 const ID: String="BG35_MagicItem_750"
   6 const IDS: Array=[ID]
   7 const TYPE: String="owned_tavern_spell_purchase_teach_murloc"
   8 const STATE: String="native_spellteach_trinket_slots"
   9 const EVENT: String="native_spellteach_trinket_taught"
  10 const ACQUIRED: String="native_spellteach_trinket_acquired"
  11 const CHILD: String="BG33_890t"
  12 const FOLDER: String="res://research/spellteach_trinket_native/"
```

## trinket_sources_closure: core/spellteach_trinket_sources.gd:39–46

```gdscript
  39 static func closure_error(catalog) -> String:
  40 	if catalog==null: return "spellteach_trinket_missing_catalog"
  41 	for name in PROOF:
  42 		if FileAccess.get_sha256(FOLDER+name)!=PROOF[name]: return "spellteach_trinket_changed_native_evidence:"+name
  43 	for current in [catalog.source_catalog if catalog.source_catalog!=null else catalog,catalog]:
  44 		var issue: String=source_error(current.get_card(ID))
  45 		if not issue.is_empty(): return issue
  46 	return Spellteach.closure_error(catalog)
```

## exact_same: core/phase_undead_army_sources.gd:8–21

```gdscript
   8 static func same(a: Variant,b: Variant) -> bool:
   9 	if (a is int or a is float) and (b is int or b is float): return a==b
  10 	if typeof(a)!=typeof(b): return false
  11 	if a is Dictionary:
  12 		if a.size()!=b.size(): return false
  13 		for key in a:
  14 			if not b.has(key) or not same(a[key],b[key]): return false
  15 		return true
  16 	if a is Array:
  17 		if a.size()!=b.size(): return false
  18 		for index in range(a.size()):
  19 			if not same(a[index],b[index]): return false
  20 		return true
  21 	return a==b
```

## cast_card_error: core/spellteach_murloc_cast.gd:10–21

```gdscript
  10 const ORIGIN: String="native_apprentice_actual_hand_minion_cast"
  11 static func fail(issue: String) -> Dictionary: return {"ok":false,"error":issue,"active":false}
  12 static func view(player: Dictionary,totals: Dictionary) -> Dictionary: return {"player":player.duplicate(true),"totals":totals.duplicate(true)}
  13 static func card_error(catalog,id: String) -> String:
  14 	var issue: String=SpellData.child_error(catalog,id)
  15 	if not issue.is_empty(): return "spellteach_unproved_taught_payload:"+id
  16 	var card: Dictionary=catalog.get_card(id)
  17 	if card.get("kind")!="spell" or card.get("effects",[]).is_empty(): return "spellteach_missing_spell_program"
  18 	for leaf in card.effects:
  19 		if leaf.get("type") not in ["spell_buff","spell_keyword","spell_gold"]: return "spellteach_nonbasic_complete_payload_partial"
  20 		if leaf.get("type")!="spell_gold" and leaf.get("scope") not in ["target","all","all_friendly","leftmost"]: return "spellteach_unproved_spell_target_policy"
  21 	return ""
```

## cast_entry_prefix: core/spellteach_murloc_cast.gd:22–34

```gdscript
  22 static func _entry_error(engine,p: Dictionary,source: Dictionary) -> String:
  23 	var issue: String=Sources.unit_error(source,engine.catalog)
  24 	if issue.is_empty(): issue=Sources.closure_error(engine.catalog)
  25 	if issue.is_empty(): issue=engine.RecruitEvents.NativeBattlecry.owner_error(engine,p)
  26 	if not issue.is_empty(): return issue
  27 	if not source.has(Sources.TAUGHT): return "spellteach_apprentice_has_no_authenticated_spell"
  28 	var binding: Dictionary=source[Sources.TAUGHT]
  29 	if binding.owner!=p.id: return "spellteach_foreign_taught_owner"
  30 	if binding.get("source_id")=="BG35_MagicItem_750":
  31 		issue=engine.SpellteachTrinket.Sources.closure_error(engine.catalog)
  32 		if not issue.is_empty(): return issue
  33 	issue=card_error(engine.catalog,str(binding.spell_id))
  34 	if not issue.is_empty(): return issue
```

## yogg_same: core/yogg_start_cast_sources.gd:18–31

```gdscript
  18 static func same(a: Variant,b: Variant) -> bool:
  19 	if b is int: return (a is int or a is float) and not a is bool and is_finite(float(a)) and a==b
  20 	if typeof(a)!=typeof(b): return false
  21 	if b is Dictionary:
  22 		if a.size()!=b.size(): return false
  23 		for key in b:
  24 			if not a.has(key) or not same(a[key],b[key]): return false
  25 		return true
  26 	if b is Array:
  27 		if a.size()!=b.size(): return false
  28 		for index in range(b.size()):
  29 			if not same(a[index],b[index]): return false
  30 		return true
  31 	return a==b
```

## yogg_child_error: core/yogg_start_cast_sources.gd:57–68

```gdscript
  57 static func child_error(catalog,id: String,allow_automatic_extensions: bool=false) -> String:
  58 	if allow_automatic_extensions and StatNineSources.accepts_id(id): return StatNineSources.child_error(catalog,id)
  59 	if allow_automatic_extensions and OwnerEightSources.accepts_id(id): return OwnerEightSources.child_error(catalog,id)
  60 	if allow_automatic_extensions and TargetThreeSources.accepts_id(id): return TargetThreeSources.child_error(catalog,id)
  61 	if allow_automatic_extensions and RandomThreeSources.accepts_id(id): return RandomThreeSources.child_error(catalog,id)
  62 	if allow_automatic_extensions and StealTwoSources.accepts_id(id): return StealTwoSources.child_error(catalog,id)
  63 	if allow_automatic_extensions and ResourceQueueSources.accepts_id(id): return ResourceQueueSources.child_error(catalog,id)
  64 	if not CHILDREN.has(id): return "yogg_start_cast_payload_program_partial:"+id
  65 	var expected: Dictionary=CHILDREN[id].raw.duplicate(true);expected.merge(CHILDREN[id].overlay,true)
  66 	for current in [catalog.source_catalog if catalog.source_catalog!=null else catalog,catalog]:
  67 		if not same(current.get_card(id),expected): return "yogg_start_cast_changed_complete_spell:"+id
  68 	return ""
```
