# Spellteach 普通取得收据 source_id 局部合同审查

## 结论

静态审查支持继续评估只改 host.saved_error 第119行 `binding.source_id!=event.source_id` 为 `binding.source_id not in [event.source_id]` 的独立 host 候选，并与原版/现有 Sources 单行候选构成四组合。它将“收据顶层身份已合法、嵌套 source_id 异型”从直接异类型比较转为拒绝成员判断，不做字符串强转、不增加合法身份、不删除后置检查。

本轮没有执行 Godot、Game、Combat、完整 Catalog、编译器或完整 host；下述新候选结果属于静态预期，不能写成已通过测试。旧包中的 Godot 结果仅用于已有行为证据。完整游戏与真实存档的可达性仍未证明。

关键版本纠正：指定 runtime 的实际 Owned host **没有 `_slots` 函数**。它是单槽版本，host.STATE 为 `native_spellteach_trinket_slot`；同目录 TrinketSources.STATE 为复数 `native_spellteach_trinket_slots`。只记录此版本差异，不在本任务修正或混入另一个版本。当前 host 与旧包固定原件完全同 hash：272e368a784a456ea874874f97dda01169cfe427ea7e40b5b98d0345519acc07。

## 1. 实际写入与前置身份门控

- 普通 sources:13 只选择 card_id 属于 PARENTS 的 board 单位。prepare_buy:56–60 调真实 Sources.unit_error 并记录 source.card_id；dispatch:82 验证原单位与 record 身份/状态没有变化。
- dispatch:93 将同一 `source.card_id` 写入 child binding.source_id；99复制到真实 generated child；104把同一 source.card_id 写入事件顶层，并复制 generated binding。未见此正常生产路径主动构造 bool/int/Array 身份。
- 饰品 dispatch:107/118 使用固定 String 常量 Sources.ID，关联真实 ledger slot/取得事件。它不是普通 PARENTS 事件，不能混入普通候选的成功域。
- saved_error:112先执行 Owned.saved_receipts，116筛普通事件；117要求 event.source_id 在 PARENTS（普通/金色两项）中，118才取 event.binding。119的 fields 只检查 Dictionary 与精确键集合，不约束嵌套 source_id 类型；因此顶层合法不能替代嵌套字段门控。
- “存在这些源码调用边/正常写入不制造坏类型”不等于“完整加载或购买必然/不可能到达异常”。本轮不修改此前可达性边界。

## 2. 候选比较语义与安全边界

对已通过117的事件，singleton 右端只能是既有成员门控接受的普通/金色身份。新条件不改变事件身份白名单；错误仍为 `spellteach_changed_acquisition_binding`。未知 String、另一父体身份、饰品身份仍应不匹配。

既有真实 Sources 类型矩阵说明：Array 成员判断正常拒绝已测异型，并保持 String/StringName 合法身份的局部接受；直接 String 比较对 bool/int/Array 会诊断。但“对这个动态 singleton 的 host 新表达式完全等价”仍须新实验，特别是左右两边 String/StringName 的四种组合与不匹配身份。不要换成 `str(...)`、仅 `is String` 或 `Sources.same(...)`：前者会改变输入解释，后两者会收紧现有 StringName 兼容。

保留的后置区别：Sources.same → Exact.same 第10行在 typeof 不同即false，故 receipt.binding.source_id 与 unit.binding.source_id 的 String/StringName 混用仍在 host:154 拒绝。event顶层与receipt.binding的混用可以过身份比较，不代表receipt.binding与unit.binding也可混用。该差异是现有逻辑，应以组合控制例保留。

范围限制：fields不验证其他键的类型；本候选不处理binding.owner/uid/round等直接比较，也不处理饰品ledger、饰品event或Cast独立比较。不应由“这6个诊断消失”升级为整个saved_error鲁棒、全部字段硬化或完整host安全。

## 3. 四组合的静态预期

- 原host + 原unit：保留既有receipt诊断和unit-only诊断。
- 原host + 新unit：坏receipt单独/与unit同时仍先到host:119，旧探针每轮6次诊断仍在；unit-only异型提前拒绝。
- 新host + 原unit：坏receipt应在119无诊断返回 changed_acquisition_binding，不到单位循环；只有unit坏仍保留原unit诊断，不能称整体完成。
- 新host + 新unit：上述两处目标source_id路径各自提前拒绝，才应使这组目标用例无诊断。

每次需区分“真实返回值”“日志诊断”“调用是否到达下游”，不能将诊断导致的空String、exit=0或sentinel当正常通过。检查state/events输入字节未变，并保留正常父体/金色、缺key、null、未知String、错父体、顶层坏身份、正常owned、重复/配额/后置same负例。不要顺便扩大为所有字段矩阵。

## 4. 最小有证据的依赖闭合

### 无饰品分支

可逐字提取当前 actual Owned.owner_error:18–31、saved_receipts:125–159，以及STATE/ACQUIRED/EVENT/POLICY四个原常量；没有 `_slots` 可提取。每位player明确trinkets=[]且**没有host单数STATE键**（存在空字典不等价于缺键），events不含ACQUIRED/EVENT两种饰品事件。这样owner_error真实执行并返回空，saved_receipts真实跳过ledger/饰品事件/末尾quota，返回真实 `{error:"",receipts:{}}`。比无条件接受Owned stub强，但仍只证明限定无饰品分支。

### 正常owned控制也要执行

父任务提出的方案可接受：加载真实TrinketSources、其7份proof及其真实Child/Sources依赖和8份proof；使用完整RAW+EXPECTED合成Catalog；逐字提取Owned函数而不preload完整Owned host。fixture必须用host单数STATE键建立合法ledger，不能擅自改用Sources复数STATE。明确它是手造状态与真实函数检查，不是真实取得/购买流程。

Cast.card_error:13–21可逐字提取，连同Yogg.same:18–31、child_error:57–68及完整21项CHILDREN常量；两参实际调用默认allow_automatic_extensions=false，六个扩展条件短路。因此六扩展类仅需明确会报错并计数的sentinel，所有调用计数必须为0。不能只用可被剔除的assert或静默return空。不要声称这些未执行扩展已经闭合验收。

Yogg.CHILDREN确含BG28_810金币、BG28_168全友方增益、BG28_507目标圣盾，均在实际card_error允许的基本程序域内。使用其原始完整raw+overlay做Catalog与binding.effects；测试不执行法术。Catalog/source_catalog最好是两份独立对象与独立数据；若source_catalog=null或同对象，应诚实标为同源双读取，不称独立双层核验。可加入单层源卡变异控制，让真实child_error拒绝。

逐字函数体、完整常量、输入原件hash、候选唯一diff、闭合/未闭合依赖列表，以及sentinel零调用结果应一起封存。新host应为新副本，不覆盖原树/旧包/旧unit候选。

## 5. 本次产物与限制

EXCERPTS.md提供带实际行号的关键原文；fragments/每文件为指定连续行的原字节；FRAGMENTS.json给出来源与片段SHA-256；INPUT_PINS.json固定审阅文件；VERIFY.json记录前后hash一致与未运行项目。FILES_SHA256.json覆盖本目录其余产物。

旧封包位置：/workspace/scratch/dd4f12b08ec0/spellteach_type_callchain_review_20261110T003349Z。父任务提供归档SHA为2be4232e82443cd5c285420eecae39d318d18847dc4405ea9a7fc5f92f260237；本次未重新读取归档核验，不将该来源声明冒充本轮计算值。

全程仅对白名单源码与旧报告/诊断结果本地只读，报告写入独立新目录。不联网、不下载、不重试已取消操作、不读缓存/凭据/私聊/旧存档/禁止目录、不运行Godot或完整host，不安装任何候选。
