#!/usr/bin/env python3
"""Read-only evidence audit. Writes only review_independent/audit_results.json.
Does not execute Godot, candidate code, parent verification/preparation scripts,
install anything, access a network, or inspect runtime/user caches.
"""
from pathlib import Path
from collections import Counter, defaultdict
from itertools import product
import hashlib, json, re, difflib

OUT = Path(__file__).resolve().parent
H = OUT.parent
W = H.parent
R = W / 'historical_tools_batch14_20261109T191857Z/runtime'
B = W / 'spellteach_type_callchain_review_20261110T003349Z'
P = W / 'spellteach_receipt_portable_replay_20261110T010100Z'
seen = {}
def sha(b): return hashlib.sha256(b).hexdigest()
def blob(p):
    p = p.resolve()
    assert p.is_relative_to(H) or p.is_relative_to(R) or p.is_relative_to(B) or p.is_relative_to(P), p
    assert '/isolated/' not in str(p) and '/.godot/' not in str(p), p
    b = p.read_bytes()
    seen[str(p.relative_to(W))] = sha(b)
    return b

def j(p): return json.loads(blob(p))
def body(b, name):
    start = re.search(rb'^static func ' + re.escape(name.encode()) + rb'\(', b, re.M)
    assert start, name
    following = re.search(rb'^static func ', b[start.end():], re.M)
    end = start.end() + following.start() if following else len(b)
    return b[start.start():end]

pins = j(H/'INPUT_PINS.json')
for pin in pins:
    src, dst = W/pin['source'], H/pin['copy']
    a, b = blob(src), blob(dst)
    assert a == b and sha(a) == pin['sha256'] and len(a) == pin['bytes'], pin
    assert (src.stat().st_dev, src.stat().st_ino) != (dst.stat().st_dev, dst.stat().st_ino), pin

old_host = blob(R/'core/spellteach_murloc_host.gd')
new_host = blob(H/'candidate/core/spellteach_murloc_host.gd')
old_unit = blob(R/'core/spellteach_murloc_sources.gd')
new_unit = blob(H/'candidate/core/spellteach_murloc_sources.gd')
assert sha(old_host) == 'fa080e10757bde93b3c7b75332855576dcca08f7b2a4fdc589dc20907fe7cafe'
assert sha(new_host) == '7b265ceb628cd686490d3bb9ebcd753234c5de9d923cc5695b147ef0e797efb9'
assert sha(new_unit) == '8cb583cf4c1e9ddaea7579b46b9812abb05d0ac14a43a689f174f3a0a37273b8'
assert old_host.count(b'binding.source_id!=event.source_id') == 1
assert new_host == old_host.replace(b'binding.source_id!=event.source_id', b'binding.source_id not in [event.source_id]')
assert new_unit == old_unit.replace(b'row.get("source_id")=="BG35_MagicItem_750"', b'row.get("source_id") in ["BG35_MagicItem_750"]')
assert blob(H/'gd_minimal/core/spellteach_murloc_sources.gd') == new_unit
assert blob(H/'gd_minimal/original/spellteach_murloc_sources.gd') == old_unit
changed_lines = [i for i, (a,b) in enumerate(zip(old_host.splitlines(),new_host.splitlines()), 1) if a != b]
assert changed_lines == [119] and len(old_host.splitlines()) == len(new_host.splitlines())
patch = ''.join(difflib.unified_diff(old_host.decode().splitlines(True),new_host.decode().splitlines(True),fromfile='a/core/spellteach_murloc_host.gd',tofile='b/core/spellteach_murloc_host.gd')).encode()
assert blob(H/'RECEIPT_CANDIDATE.patch') == patch
manifest = j(H/'CANDIDATE_MANIFEST.json')
assert manifest['original_host_sha256'] == sha(old_host) and manifest['candidate_host_sha256'] == sha(new_host)
assert manifest['candidate_host_bytes'] == len(new_host) and manifest['receipt_patch_sha256'] == sha(patch)
assert manifest['previous_unit_candidate_sha256'] == sha(new_unit) and manifest['changed_host_lines'] == [119]

extracted = j(H/'EXTRACTED_FUNCTIONS.json')
assert len(extracted) == 10
fragment_bodies = defaultdict(list)
for item in extracted:
    source, output = blob(H/item['source']), blob(H/item['output'])
    if item['function'] == 'CHILDREN constant':
        text = re.search(rb'^const CHILDREN:[^\n]*',source,re.M).group(0)
    else:
        text = body(source,item['function'])
    assert len(text) == item['bytes'] and sha(text) == item['sha256'], item
    assert output.count(text) == 1, item
    fragment_bodies[item['output']].append(text)
# No unreported static function implementation in any extracted fragment.
for name, texts in fragment_bodies.items():
    remainder = blob(H/name)
    for text in texts: remainder = remainder.replace(text,b'',1)
    assert not re.search(rb'^static func ',remainder,re.M),name
    if name.endswith('spell_data.gd'):
        assert remainder.count(b'\tstatic func ') == 2
    else:
        assert b'\tstatic func ' not in remainder

children_line = re.search(rb'^const CHILDREN:[^\n]*', blob(H/'gd_minimal/fragments/spell_data.gd'), re.M).group(0)
children = json.loads(children_line.split(b'=',1)[1])
assert len(children) == 21
spell_data = blob(H/'gd_minimal/fragments/spell_data.gd').decode()
assert 'allow_automatic_extensions: bool=false' in spell_data
for name in ['StatNineSources','OwnerEightSources','TargetThreeSources','RandomThreeSources','StealTwoSources','ResourceQueueSources']:
    assert f'const {name}=ForbiddenExtension' in spell_data
    assert f'if allow_automatic_extensions and {name}.accepts_id(id): return {name}.child_error(catalog,id)' in spell_data
assert spell_data.count('calls+=1') == 2 and spell_data.count('push_error("PROBE_FORBIDDEN_EXTENSION_PATH")') == 2
assert 'SpellData.child_error(catalog,id)' in blob(H/'gd_minimal/fragments/cast_card.gd').decode()
exact = body(blob(H/'gd_minimal/core/phase_undead_army_sources.gd'),'same')
assert b'if typeof(a)!=typeof(b): return false' in exact
assert body(new_unit,'same') == body(old_unit,'same')
assert b'Sources.same(receipts[unit.uid].get("binding"),binding)' in body(new_host,'saved_error')

# Reachable script preload graph. No Game, real Catalog, full host or compiler.
queue = ['receipt_matrix.gd','receipt_controls.gd']; graph = {}
while queue:
    path = queue.pop()
    if path in graph: continue
    text = blob(H/'gd_minimal'/path).decode()
    deps = re.findall(r'preload\("res://([^"\n]+)"\)',text)
    assert not re.search(r'(?<![\w_])load\s*\(',text),path
    assert not any(x in text for x in ['OS.execute(', 'OS.create_process(', 'HTTPRequest', 'HTTPClient', 'TCPServer', 'PacketPeer']),path
    graph[path] = deps; queue.extend(deps)
assert len(graph) == 16
for name in graph:
    assert not any(x in name.lower() for x in ['game.gd','catalog.gd','compiler','murloc_host.gd','trinket_host.gd'])
for version in ['OO','U','R','UR']:
    dep = 'original/spellteach_murloc_sources.gd' if version in ['OO','R'] else 'core/spellteach_murloc_sources.gd'
    assert graph['fragments/host_'+version+'.gd'][0] == dep
    src = old_host if version in ['OO','U'] else new_host
    assert body(blob(H/f'gd_minimal/fragments/host_{version}.gd'),'saved_error') == body(src,'saved_error')
# Owned always points to candidate Child, but the sole changed unit_error is not
# called there or in the copied Trinket source's reachable code.
owned = blob(H/'gd_minimal/fragments/owned.gd').decode()
assert 'const Child=preload("res://core/spellteach_murloc_sources.gd")' in owned
owned_calls = sorted(set(re.findall(r'Child\.([a-z_]+)\(',owned)))
assert owned_calls == ['fields','integer','same','uid']
trinket = blob(H/'gd_minimal/core/spellteach_trinket_sources.gd').decode()
trinket_calls = sorted(set(re.findall(r'Spellteach\.([a-z_]+)\(',trinket)))
assert trinket_calls == ['closure_error']
for name in owned_calls + trinket_calls:
    assert body(old_unit,name) == body(new_unit,name),name

# Independently map each report to strict, non-nested log spans; raw report must
# differ from classified report ONLY by its diagnostics list.
summaries = {}; reports = {}
for family, count in [('RECEIPT_MATRIX',3712),('RECEIPT_CONTROLS',468)]:
    for repeat in [1,2]:
        label = f'{family}_{repeat}'
        raw, classified = j(H/(label+'.json')), j(H/(label+'.classified.json'))
        reports[label] = classified
        stripped = json.loads(json.dumps(classified))
        for row in stripped['results']: del row['diagnostics']
        assert stripped == raw
        assert len(raw['results']) == count and not raw['failures'] and raw['forbidden_extension_calls'] == 0
        active = None; spans = {}; order = []; start = None
        for number,line in enumerate(blob(H/(label+'.log')).decode().splitlines(),1):
            if line.startswith('CALL_BEGIN|'):
                assert active is None
                active=line[11:]; assert active not in spans
                spans[active]={'begin':number,'body':[]}; order.append(active)
            elif line.startswith('CALL_END|'):
                assert active == line[9:]
                spans[active]['end']=number; active=None
            elif active is not None:
                spans[active]['body'].append(line)
            else:
                assert not line.strip() or line.startswith('Godot Engine v4.6.3.stable.official.7d41c59c4'), (label,number,line)
        assert active is None and order == [x['label'] for x in raw['results']]
        diagnostics = Counter()
        for row in classified['results']:
            span=spans[row['label']]; errors=[x for x in span['body'] if 'ERROR:' in x]
            assert errors == row['diagnostics'] and len(errors) <= 1
            if not errors: assert not span['body']
            else:
                assert errors[0].startswith('SCRIPT ERROR: Invalid operands ')
                assert all(x.startswith(('SCRIPT ERROR:','          at:','          GDScript backtrace','              [')) for x in span['body'])
                diagnostics[errors[0]] += 1
        resource = j(H/(label+'.resources.json'))
        assert resource['exit'] == 0 and resource['seconds'] < resource['timeout_seconds'] == 45
        assert resource['peak_rss_kib'] < resource['rss_stop_kib'] == 196608
        assert resource['address_space_limit'] == 2147483648
        summaries[label]={'calls':count,'diagnostic_calls':sum(diagnostics.values()),'first_begin_line':spans[order[0]]['begin'],'last_end_line':spans[order[-1]]['end'],'resource':resource}
    assert reports[f'{family}_1'] == reports[f'{family}_2']

matrix = reports['RECEIPT_MATRIX_1']['results']
versions=['OO','U','R','UR']; parents=['BG33_891','BG33_891_G']; top_types=['String','StringName']; modes=['receipt_only','unit_only','both','top_only']
value_text = blob(H/'gd_minimal/values.gd').decode()
cases = re.findall(r'\["([a-z0-9_]+)",',value_text)
assert len(cases) == len(set(cases)) == 58
assert set(x['label'] for x in matrix) == {':'.join(p) for p in product(versions,parents,top_types,modes,cases)}
assert len(set(x['variant_type'] for x in matrix)) == 39
# Model only the source_id branch affected by these two patches, keeping exact
# kind+value equality for the later receipt/unit dictionary comparison.
ids={'parent':'BG33_891','golden':'BG33_891_G','trinket':'BG35_MagicItem_750','child':'BG33_890t','empty':'','unknown':'OTHER'}
def desc(case):
    if case.startswith('stringname_'): return ('StringName',ids[case[11:]])
    if case.startswith('string_'): return ('String',ids[case[7:]])
    return ('Nil',None) if case == 'null' else ('unsupported-comparison',case)
def allowed(v): return v[0] in top_types and v[1] in parents
def semantic_id_equal(a,b): return a[0] in top_types and b[0] in top_types and a[1] == b[1]
def predict(row):
    unit=('String',row['parent']); receipt=unit; event=(row['top_type'],row['parent']); item=desc(row['case'])
    if row['mode'] in ['receipt_only','both']: receipt=item
    if row['mode'] in ['unit_only','both']: unit=item
    if row['mode'] == 'top_only': event=item
    if not allowed(event): return ('spellteach_invalid_acquisition_receipt',None)
    if row['version'] in ['OO','U'] and receipt[0] == 'unsupported-comparison': return ('','!=')
    if not semantic_id_equal(receipt,event): return ('spellteach_changed_acquisition_binding',None)
    if row['version'] in ['OO','R'] and unit[0] == 'unsupported-comparison': return ('spellteach_unproven_saved_teaching_lineage','==')
    if unit[0] in top_types and unit[1] == ids['trinket']: return ('spellteach_invalid_owned_purchase_binding',None)
    if not allowed(unit): return ('spellteach_invalid_actual_purchase_binding',None)
    return ('' if unit == receipt else 'spellteach_unproven_saved_teaching_lineage',None)
counts={}; by = {row['label']:row for row in matrix}
for version in versions:
    rows = [r for r in matrix if r['version']==version]
    for row in rows:
        assert row['label'] == ':'.join(row[k] for k in ['version','parent','top_type','mode','case'])
        result, operator = predict(row)
        assert row['returned'] == result and bool(row['diagnostics']) == (operator is not None),row
        if operator:
            assert f"operator '{operator}'" in row['diagnostics'][0]
    counts[version]={'calls':len(rows),'diagnostic_calls':sum(bool(r['diagnostics']) for r in rows),'clean_accepts':sum(not r['diagnostics'] and r['returned']=='' for r in rows),'diagnostic_modes':dict(Counter(r['mode'] for r in rows if r['diagnostics']))}
assert [counts[v]['diagnostic_calls'] for v in versions] == [552,368,184,0]
assert all(s['calls']==928 and s['clean_accepts']==24 for s in counts.values())
original_clean=0; original_errors=0
for row in matrix:
    if row['version'] != 'OO': continue
    new = by['UR:'+row['label'][3:]]
    assert not new['diagnostics']
    if not row['diagnostics']:
        assert row['returned'] == new['returned']; original_clean += 1
    else:
        assert new['returned']; original_errors += 1
assert (original_clean,original_errors)==(376,552)
# Explicit StringName cases: equal content remains comparable; mismatched kinds
# between the receipt and unit dictionaries still fail the unchanged same().
for version,parent,top in product(versions,parents,top_types):
    case = 'stringname_parent' if parent==parents[0] else 'stringname_golden'
    for mode in modes:
        row=by[':'.join([version,parent,top,mode,case])]
        expected='spellteach_unproven_saved_teaching_lineage' if mode in ['receipt_only','unit_only'] else ''
        assert row['returned']==expected and not row['diagnostics']

control_rows = reports['RECEIPT_CONTROLS_1']['results']; groups=defaultdict(list)
for row in control_rows:
    assert row['returned']==row['expected'] and not row['diagnostics']
    assert row['label']==row['version']+':'+row['case']
    groups[row['case']].append(row)
assert len(groups)==117
for name, group in groups.items():
    assert len(group)==4 and set(r['version'] for r in group)==set(versions)
    assert len(set(r['returned'] for r in group))==1
assert sum(g[0]['returned']=='' for g in groups.values())==57
assert set(x for x in groups if x.startswith('real_payload:')) == {'real_payload:'+p+':'+c for p,c in product(parents,children)}
assert set(x for x in groups if x.startswith('zone:')) == {'zone:'+p+':'+z for p,z in product(parents,['board','hand','shop','mechanism_reward_queue'])}
proofs={}
for mod, prefix, const in [('spellteach_murloc_sources.gd','', 'PROOF_SHA256'),('spellteach_trinket_sources.gd','research/spellteach_trinket_native/','PROOF')]:
    source=blob(H/'gd_minimal/core'/mod)
    proof_line=re.search(rb'^const '+const.encode()+rb':[^\n]*',source,re.M).group(0)
    for name,digest in json.loads(proof_line.split(b'=',1)[1]).items():
        path=prefix+name; assert sha(blob(H/'gd_minimal'/path))==digest
        proofs[path]=digest
assert len(proofs)==15
assert set(n for n in groups if n.startswith('proof:')) == {'proof:res://'+p+':'+kind for p,kind in product(proofs,['changed_bytes','missing'])}
for name in ['owned_valid','owned_ledger_missing','owned_entry_changed','owned_quota_changed','owned_repeated_purchase']:
    assert name in groups

# Portable audit uses only recorded files and comparison, never runs replay.
portable_manifest = j(H/'REPLAY_INPUTS.json')
assert len(portable_manifest)==37
for name,pin in portable_manifest.items():
    original, portable = blob(H/name), blob(P/name)
    assert original==portable and len(original)==pin['bytes'] and sha(original)==pin['sha256']
    assert (H/name).stat().st_ino != (P/name).stat().st_ino
outputs=['VERIFICATION.json','SIX_CASE_CLOSURE.json']+[f'{family}_{repeat}{suffix}' for family in ['RECEIPT_MATRIX','RECEIPT_CONTROLS'] for repeat in [1,2] for suffix in ['.json','.classified.json','.log']]
assert len(outputs)==14
for name in outputs: assert blob(H/name)==blob(P/name)
for family, repeat in product(['RECEIPT_MATRIX','RECEIPT_CONTROLS'],[1,2]):
    name=f'{family}_{repeat}.resources.json'
    resource=j(P/name)
    assert resource==j(H/('PORTABLE_'+name))
    assert resource['exit']==0 and resource['peak_rss_kib']<196608 and resource['seconds']<45
assert j(H/'PORTABLE_REPLAY_RESULT.json')==j(P/'REPLAY_RESULT.json')
six=j(H/'SIX_CASE_CLOSURE.json')
assert len(six)==6
assert set(x['prior_unit_only']['label'] for x in six)=={'U:BG33_891:String:'+mode+':'+case for mode,case in product(['receipt_only','both'],['bool_true','int_one','array'])}
for item in six:
    a,b=item['prior_unit_only'],item['combined']
    assert a==by[a['label']] and b==by[b['label']]
    assert len(a['diagnostics'])==1 and a['returned']==''
    assert b['diagnostics']==[] and b['returned']=='spellteach_changed_acquisition_binding'
portable_result={'input_files_verified':37,'byte_identical_outputs_verified':14,'resources_confirmed':4,'six_case_rows_matched_to_raw_evidence':6,'independent_replay_executed':False}

# Re-read every audited input to ensure it did not change during this audit.
for name,digest in list(seen.items()):
    assert sha((W/name).read_bytes())==digest,name
result={
    'status':'PASS_SCOPED_OFFLINE_EVIDENCE_AUDIT_NOT_FULL_GAME_APPROVAL',
    'input_pins_verified_against_current_sources':len(pins),
    'extraction_records_verified_byte_for_byte':len(extracted),
    'host_changed_lines':changed_lines,
    'host_original_sha256':sha(old_host),'host_candidate_sha256':sha(new_host),
    'unit_candidate_sha256':sha(new_unit),'dependency_graph':graph,
    'shared_owned_candidate_child_methods':owned_calls,
    'shared_trinket_candidate_methods':trinket_calls,
    'shared_candidate_methods_all_unchanged':True,
    'matrix':counts,'original_clean_returns_preserved':original_clean,
    'original_diagnostics_now_clean_rejection':original_errors,
    'control_cases':117,'control_positive_cases':57,'control_negative_cases':60,
    'real_spell_payloads':len(children),'proof_inputs_restored_and_verified':len(proofs),
    'proof_negative_variants':30,'all_reported_rows_reconciled_with_log_spans':True,
    'exact_repeat_results':True,'stringname_compatibility_and_strict_lineage_preserved':True,
    'forbidden_extension_calls_in_all_four_reports':0,
    'runs':summaries,'portable':portable_result,'audit_inputs_sha256':seen,
    'limitations':['No Godot re-run by independent reviewer. Historical logs were independently classified and audited.', 'Only source_id representative cases in synthetic saved_error fragments; not exhaustive Variant values or unrelated receipt fields.', 'No full host/Game/Catalog/compiler/old save executed. No installation or original-file mutation.']
}
(OUT/'audit_results.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['audit_inputs_sha256','dependency_graph','runs']},indent=2,ensure_ascii=False))
