# Independent review: spellteach receipt candidate

Verdict: PASS for the bounded, offline synthetic-fragment evidence. No blocker found in the single-line receipt correction or in its interaction with the previous unit correction. This is not full-host/Game approval, restoration of a historical original, installation, or a claim of complete Variant validation.

## Independently verified

- The current runtime host is SHA-256 `fa080e10757bde93b3c7b75332855576dcca08f7b2a4fdc589dc20907fe7cafe`. The candidate is `7b265ceb628cd686490d3bb9ebcd753234c5de9d923cc5695b147ef0e797efb9`. The complete file differs only at line 119: `binding.source_id!=event.source_id` becomes `binding.source_id not in [event.source_id]`.
- The previous unit candidate remains byte-for-byte `8cb583cf4c1e9ddaea7579b46b9812abb05d0ac14a43a689f174f3a0a37273b8`. Its only difference from the runtime unit source is the already-described membership comparison in `unit_error`.
- All 29 input-pin records match both their current source files and local copies. All 10 extraction records match exact source bytes, including four `saved_error` bodies, real Owned owner/receipt methods, real Cast validation, Yogg `same`/`child_error`, and the full 21-entry CHILDREN constant.
- The 16-file actual preload graph reaches only the isolated fixtures, source modules, and extracted fragments. It does not preload a complete host, real Game/Catalog, compiler, or old save. The complete candidate host is an inert saved artifact in these tests. No permissive Owned/Cast replacement is present.
- Yogg's six automatic extensions are disabled by the unchanged default-false parameter and replaced by explicit error/counter sentinels. Both sentinel methods increment the counter and emit a diagnostic. All four recorded primary reports show zero calls. The raw and effective catalog objects and their card dictionaries are separate.
- The independent Python audit reconciled all 8,360 primary recorded calls with properly paired, ordered, non-nested log intervals, including every diagnostic and backtrace interval. Raw JSON differs from classified JSON only by the added diagnostic list. Both matrix repeats and both control repeats are identical. Resource records show all four original runs exited 0 within their recorded limits.

## Four-combination result

Each combination has 928 matrix calls per run. Diagnostic counts are OO 552, U 368, R 184, UR 0. All four have exactly 24 clean accepts. The independent branch model matches every one of the 3,712 matrix rows per run.

- OO: 184 diagnostics in each of receipt-only, unit-only, and both positions.
- U: receipt-only and both retain 184 diagnostics each; unit-only is fixed.
- R: only unit-only retains 184 diagnostics; the receipt comparison is fixed.
- UR: all 552 formerly diagnostic OO calls become clean nonempty rejection results. All 376 formerly diagnostic-free OO return strings, including all 24 accepts, remain unchanged.
- Top-only contamination produces no diagnostic in any combination because the pre-existing parent-membership gate handles it before the patched expression.

This supports complementary corrections at two distinct comparison sites. An empty string accompanied by a GDScript diagnostic is not counted as acceptance.

## Shared dependency qualification

The four host fragments select old/new Sources exactly as labeled. However, all Owned fragments share the candidate Child class, and the shared Trinket source also refers to that candidate. This distinction is real and must not be hidden.

It does not confound these comparisons: Owned invokes only `fields`, `integer`, `same`, and `uid`; Trinket invokes `closure_error`. All five methods are byte-identical between the original and candidate source and do not call the changed `unit_error`. The direct `Sources.unit_error` call in each host is the one that switches between old and new. Thus OO means original host/original direct unit-validation path, not that every shared loaded file is original.

## StringName and safety boundary

Membership preserves the existing same-text String/StringName compatibility at the receipt-to-top-level event check. It does not stringify arbitrary data. The later unchanged `Sources.same` still rejects receipt/unit source IDs whose Variant kinds differ. A StringName inserted only into the receipt or only into the unit returns `spellteach_unproven_saved_teaching_lineage`; matching StringName values in both, or a same-text StringName only at event top level, remain clean accepts. This was checked for both parent IDs, both top-level kinds, and all four combinations.

The patch does not change proof checks, replay/quota checks, ownership, payload comparison, or other receipt fields. Existing direct comparisons in unrelated fields and owned receipt paths are outside this mutation matrix; zero diagnostics here is not an assertion that arbitrary corrupted state is safe everywhere.

## Controls and portability

All 117 control cases agree across four combinations: 57 positive and 60 negative cases, 468 calls per run, no diagnostics. These include 21 real spell payloads for both parent IDs, all four zones, quota/replay, cast lineage, owned receipt positive/negative cases, and changed/missing variants for all 15 proof files. All proof bytes currently match their original pins.

The six specifically highlighted ordinary-parent receipt/both cases for bool, int, and Array match the raw evidence exactly: U produces an empty return plus `!=` diagnostic; UR returns `spellteach_changed_acquisition_binding` without a diagnostic.

A limited independent portability check verified all 37 replay inputs against their pins and copied bytes, all 14 claimed output files against the primary evidence byte-for-byte, and four successful replay resource records. No replay or Godot process was launched by this reviewer. The broader existing final-source summary (41 records, old archives, missing-tool count, Game/Catalog pins) was read as context, not independently re-audited, because this assignment was limited to the receipt candidate.

## Audit artifact and scope

Run `python review_independent/check_independent.py` from any working directory to repeat the read-only evidence checks; it writes only `review_independent/audit_results.json`. That JSON records audited input hashes and results. The reviewer created only files under `review_independent`; no source, candidate, prior package, or existing test was modified. No network/download, compiler, full host/Game/Catalog execution, credentials, private chat, old save, or runtime cache read was used.
