from pathlib import Path
import json,hashlib,collections
H=Path(__file__).resolve().parent
def read(name):return json.loads((H/name).read_text())
def descriptor(case):
 lookup={'parent':'BG33_891','golden':'BG33_891_G','trinket':'BG35_MagicItem_750','child':'BG33_890t','empty':'','unknown':'OTHER'}
 for prefix,kind in [('stringname_','StringName'),('string_','String')]:
  if case.startswith(prefix):return (kind,lookup[case[len(prefix):]])
 return ('Nil',None) if case=='null' else ('Other',case)
def member(v):return v[0] in ['String','StringName'] and v[1] in ['BG33_891','BG33_891_G']
def eq_id(a,b):return a[0] in ['String','StringName'] and b[0] in ['String','StringName'] and a[1]==b[1]
def expected(row):
 original_unit=row['version'] in ['OO','R'];original_host=row['version'] in ['OO','U'];mode=row['mode'];parent=row['parent'];x=descriptor(row['case'])
 top=(row['top_type'],parent);receipt=('String',parent);unit=('String',parent)
 if mode in ['receipt_only','both']:receipt=x
 if mode in ['unit_only','both']:unit=x
 if mode=='top_only':top=x
 if not member(top):return 'spellteach_invalid_acquisition_receipt',0
 if original_host and receipt[0]=='Other':return '',1
 if not eq_id(receipt,top):return 'spellteach_changed_acquisition_binding',0
 diagnostics=0
 if original_unit and unit[0]=='Other':diagnostics=1
 elif unit[0] in ['String','StringName'] and unit[1]=='BG35_MagicItem_750':return 'spellteach_invalid_owned_purchase_binding',0
 elif not member(unit):return 'spellteach_invalid_actual_purchase_binding',0
 return ('' if receipt==unit else 'spellteach_unproven_saved_teaching_lineage'),diagnostics
matrix=read('RECEIPT_MATRIX_1.classified.json');assert matrix==read('RECEIPT_MATRIX_2.classified.json')
assert not matrix['failures'] and matrix['forbidden_extension_calls']==0 and matrix['representative_values']==58
assert len(matrix['results'])==3712
labels=set();counts={};clean_original=0;fixed=0
for r in matrix['results']:
 assert r['label'] not in labels;labels.add(r['label']);issue,diagnostics=expected(r)
 assert (r['returned'],len(r['diagnostics']))==(issue,diagnostics),(r,issue,diagnostics)
 for line in r['diagnostics']:assert 'Invalid operands' in line and 'operator' in line
 v=r['version'];counts.setdefault(v,{'calls':0,'diagnostic_calls':0,'clean_accepts':0,'clean_rejections':0});s=counts[v];s['calls']+=1;s['diagnostic_calls']+=bool(diagnostics);s['clean_accepts']+=not diagnostics and issue=='';s['clean_rejections']+=not diagnostics and issue!=''
by={r['label']:r for r in matrix['results']}
for r in matrix['results']:
 if r['version']!='OO':continue
 q=by['UR:'+r['label'].split(':',1)[1]];assert not q['diagnostics']
 if not r['diagnostics']:assert r['returned']==q['returned'];clean_original+=1
 else:assert q['returned']!='';fixed+=1
assert clean_original==376 and fixed==552
assert {v:s['diagnostic_calls'] for v,s in counts.items()}=={'OO':552,'U':368,'R':184,'UR':0}
assert all(s['calls']==928 and s['clean_accepts']==24 for s in counts.values())
assert len({r['variant_type'] for r in matrix['results']})==39
controls=read('RECEIPT_CONTROLS_1.classified.json');assert controls==read('RECEIPT_CONTROLS_2.classified.json') and not controls['failures'] and controls['forbidden_extension_calls']==0
assert len(controls['results'])==468 and controls['normal_payloads']==21 and controls['proof_variants']==30
control_groups={}
for r in controls['results']:
 assert not r['diagnostics'] and r['returned']==r['expected'];control_groups.setdefault(r['case'],[]).append(r)
assert len(control_groups)==117
for group in control_groups.values():assert {r['version'] for r in group}=={'OO','U','R','UR'} and len({r['returned'] for r in group})==1
# Verify every logged call is paired, ordered and represented, not just JSON claims.
for family in ['RECEIPT_MATRIX','RECEIPT_CONTROLS']:
 for repeat in [1,2]:
  data=read(f'{family}_{repeat}.classified.json');rows=data['results'];active=None;seen=[];errors={}
  for line in (H/f'{family}_{repeat}.log').read_text().splitlines():
   if line.startswith('CALL_BEGIN|'):
    assert active is None;active=line.split('|',1)[1];assert active not in errors;seen.append(active);errors[active]=[]
   elif line.startswith('CALL_END|'):assert active==line.split('|',1)[1];active=None
   elif 'ERROR:' in line:assert active is not None;errors[active].append(line)
  assert active is None and seen==[r['label'] for r in rows]
  for r in rows:assert errors[r['label']]==r['diagnostics']
six=[]
for mode in ['receipt_only','both']:
 for case in ['bool_true','int_one','array']:
  suffix='BG33_891:String:'+mode+':'+case
  prior=by['U:'+suffix];combined=by['UR:'+suffix]
  assert len(prior['diagnostics'])==1 and prior['returned']==''
  assert not combined['diagnostics'] and combined['returned']=='spellteach_changed_acquisition_binding'
  six.append({'prior_unit_only':prior,'combined':combined})
(H/'SIX_CASE_CLOSURE.json').write_text(json.dumps(six,indent=2)+'\n')
manifest=read('CANDIDATE_MANIFEST.json');assert hashlib.sha256((H/'candidate/core/spellteach_murloc_host.gd').read_bytes()).hexdigest()==manifest['candidate_host_sha256']
assert hashlib.sha256((H/'candidate/core/spellteach_murloc_sources.gd').read_bytes()).hexdigest()==manifest['previous_unit_candidate_sha256']
summary={'status':'PASS_NEW_RECEIPT_AND_PRIOR_UNIT_LOCAL_CANDIDATES_NOT_GAME_APPROVAL','matrix':counts,'total_matrix_calls_per_run':3712,'variant_representative_values':58,'variant_type_categories':39,'original_clean_results_preserved_in_combined':376,'original_diagnostic_calls_changed_to_rejection_in_combined':552,'control_cases':117,'control_calls_per_run':468,'all_control_results_identical_across_four_combos':True,'control_clean_positive_cases':sum(g[0]['returned']=='' for g in control_groups.values()),'control_clean_negative_cases':sum(g[0]['returned']!='' for g in control_groups.values()),'real_spell_payloads':21,'proof_negative_variants':30,'forbidden_extension_calls':0,'no_permissive_owned_or_cast_stubs':True,'source_catalog_separate_object':True,'all_four_reports_repeat_identical':True,'full_Game_or_host_executed':False,'candidate_installed':False}
(H/'VERIFICATION.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
