"""Portable local four-combination receipt validation, never installation or Game."""
from pathlib import Path
import sys,subprocess,json,hashlib,resource
resource.setrlimit(resource.RLIMIT_AS,(128*1024**2,resource.RLIM_INFINITY))
H=Path(__file__).resolve().parent
assert len(sys.argv)==2 and Path(sys.argv[1]).is_absolute();D=Path(sys.argv[1]);assert not D.exists();D.mkdir(parents=True)
manifest=json.loads((H/'REPLAY_INPUTS.json').read_text())
for rel,pin in manifest.items():
 b=(H/rel).read_bytes();assert len(b)==pin['bytes'] and hashlib.sha256(b).hexdigest()==pin['sha256'];p=D/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b);assert p.stat().st_ino!=(H/rel).stat().st_ino
for argv in [['run_bounded.py','receipt_matrix.gd','RECEIPT_MATRIX'],['run_bounded.py','receipt_controls.gd','RECEIPT_CONTROLS'],['verify_results.py']]:subprocess.run([sys.executable,'-B',str(D/argv[0]),*argv[1:]],check=True)
for rel,pin in manifest.items():assert hashlib.sha256((D/rel).read_bytes()).hexdigest()==pin['sha256'],rel
outputs=['VERIFICATION.json','SIX_CASE_CLOSURE.json']+[f'{family}_{repeat}{suffix}' for family in ['RECEIPT_MATRIX','RECEIPT_CONTROLS'] for repeat in [1,2] for suffix in ['.json','.classified.json','.log']]
for rel in outputs:assert (D/rel).read_bytes()==(H/rel).read_bytes(),rel
report={'status':'PASS_PORTABLE_FOUR_COMBO_LOCAL_REPLAY_NOT_GAME_APPROVAL','destination':str(D),'input_files':len(manifest),'byte_identical_output_files':len(outputs),'calls_per_run':4180,'combos':['OO','U','R','UR'],'candidate_host_sha256':json.loads((D/'CANDIDATE_MANIFEST.json').read_text())['candidate_host_sha256'],'source_runtime_not_required':True,'no_download_or_network':True,'full_Game_Catalog_compiler_host_not_executed':True,'candidate_not_installed':True}
(D/'REPLAY_RESULT.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
