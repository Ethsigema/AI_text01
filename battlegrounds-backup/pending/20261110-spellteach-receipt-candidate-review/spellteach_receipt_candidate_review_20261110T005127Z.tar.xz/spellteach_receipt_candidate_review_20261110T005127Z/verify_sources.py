from pathlib import Path
import json,hashlib,resource
resource.setrlimit(resource.RLIMIT_AS,(128*1024**2,resource.RLIM_INFINITY))
H=Path(__file__).resolve().parent;W=H.parent;R=W/'historical_tools_batch14_20261109T191857Z/runtime'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
records=[]
for row in json.loads((H/'INPUT_PINS.json').read_text()):
 p=W/row['source'];q=H/row['copy'];assert p.stat().st_size==row['bytes'] and sha(p)==row['sha256'];assert q.stat().st_size==row['bytes'] and sha(q)==row['sha256'];assert p.stat().st_ino!=q.stat().st_ino;records.append(str(p))
for row in json.loads((H/'static_contract/INPUT_PINS.json').read_text()):
 p=Path(row['path']);assert p.stat().st_size==row['bytes'] and sha(p)==row['sha256'];records.append(str(p))
previous=W/'spellteach_type_callchain_review_20261110T003349Z'
archives=json.loads((previous/'FINAL_SOURCE_VERIFICATION.json').read_text())['old_archives']
archives['spellteach_type_callchain_review_20261110T003349Z.tar.xz']='2be4232e82443cd5c285420eecae39d318d18847dc4405ea9a7fc5f92f260237'
for rel,pin in archives.items():assert sha(W/rel)==pin,rel
scope=json.loads((W/'historical_tools_batch15_20261109T195018Z/REMAINING_SCOPE.json').read_text())['remaining_targets'];assert len(scope)==345 and all(not (R/p).exists() for p in scope)
assert not (R/'evidence/portable_legacy/CardDefs.Bacon_latest.xml').exists()
assert sha(R/'core/game.gd')=='84ea17caff1c22d082badf6118f8fdde02e35616d4d156b28430b02313504410'
assert sha(R/'core/catalog.gd')=='5ba81a78d4924e4596dada5cb8f1a9ad5877d7bed6c7d350ca370d8bff955a72'
assert sha(previous/'candidate/core/spellteach_murloc_sources.gd')=='8cb583cf4c1e9ddaea7579b46b9812abb05d0ac14a43a689f174f3a0a37273b8'
for rel,pin in json.loads((H/'REPLAY_INPUTS.json').read_text()).items():assert sha(H/rel)==pin['sha256']
result={'status':'MATCH_ORIGINAL_SOURCES_PROOFS_AND_OLD_BACKUPS','input_pin_records':len(records),'unique_source_paths':len(set(records)),'old_archives':archives,'old_unit_candidate_unchanged':True,'game_and_catalog_unchanged':True,'tools_still_missing':345,'XML_candidate_not_installed':True,'both_candidates_not_installed':True,'proof_copies_restored':True,'python_peak_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
(H/'FINAL_SOURCE_VERIFICATION.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
