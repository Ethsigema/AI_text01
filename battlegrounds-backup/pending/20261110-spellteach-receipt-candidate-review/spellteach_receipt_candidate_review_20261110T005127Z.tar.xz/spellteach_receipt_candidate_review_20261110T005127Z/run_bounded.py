from pathlib import Path
import subprocess,resource,time,json,os,sys
H=Path(__file__).resolve().parent

def available():return next(int(x.split()[1]) for x in Path('/proc/meminfo').read_text().splitlines() if x.startswith('MemAvailable:'))
def bound():resource.setrlimit(resource.RLIMIT_AS,(2*1024**3,2*1024**3));resource.setrlimit(resource.RLIMIT_CORE,(0,0))
def run(script,label):
 assert available()>=1024*1024
 env=os.environ.copy()
 for key,sub in [('HOME','home'),('XDG_CACHE_HOME','cache'),('XDG_DATA_HOME','data'),('XDG_CONFIG_HOME','config')]:
  p=H/'isolated'/sub;p.mkdir(parents=True,exist_ok=True);env[key]=str(p)
 env['GODOT_SILENCE_ROOT_WARNING']='1'
 out=H/(label+'.json');log=H/(label+'.log');start=time.monotonic();peak=0
 with log.open('w') as f:
  p=subprocess.Popen(['/usr/local/bin/godot','--headless','--path',str(H/'gd_minimal'),'--script','res://'+script,'--',str(out)],stdout=f,stderr=subprocess.STDOUT,env=env,preexec_fn=bound)
  while p.poll() is None:
   try:
    for line in Path(f'/proc/{p.pid}/status').read_text().splitlines():
     if line.startswith('VmRSS:'):peak=max(peak,int(line.split()[1]))
   except FileNotFoundError:pass
   if peak>192*1024 or available()<640*1024 or time.monotonic()-start>45:p.kill();p.wait();raise RuntimeError('resource stop')
   time.sleep(.02)
 stats={'exit':p.returncode,'seconds':round(time.monotonic()-start,3),'peak_rss_kib':peak,'rss_stop_kib':192*1024,'address_space_limit':2*1024**3,'timeout_seconds':45}
 (H/(label+'.resources.json')).write_text(json.dumps(stats,indent=2)+'\n')
 assert p.returncode==0,(stats,log.read_text()[-5000:])
 result=json.loads(out.read_text());assert not result.get('failures'),result.get('failures')
 intervals={};current=None
 for line in log.read_text().splitlines():
  if line.startswith('CALL_BEGIN|'):current=line.split('|',1)[1];assert current not in intervals;intervals[current]=[]
  elif line.startswith('CALL_END|'):assert current==line.split('|',1)[1];current=None
  elif 'ERROR:' in line:
   assert current is not None,('error outside marked call',line)
   intervals[current].append(line)
 for row in result.get('results',[]):row['diagnostics']=intervals.get(row['label'],[])
 (H/(label+'.classified.json')).write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n')
 return result,stats
if __name__=='__main__':
 script=sys.argv[1];label=sys.argv[2]
 a,s=run(script,label+'_1');b,t=run(script,label+'_2');assert a==b
 print(json.dumps({'script':script,'rows':len(a.get('results',[])),'runs':[s,t],'diagnostic_calls':sum(bool(x['diagnostics']) for x in a.get('results',[]))}))
