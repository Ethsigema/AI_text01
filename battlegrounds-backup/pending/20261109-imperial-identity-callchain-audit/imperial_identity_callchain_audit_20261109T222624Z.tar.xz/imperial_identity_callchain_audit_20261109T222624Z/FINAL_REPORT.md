# 皇家守护者映射身份：实际入口只读追踪

## 结论

三项合成映射反例证明了单行/闭包校验器不绑定外部映射键，但不能据此认定正常加载流程会产生这些映射，也不能仅凭它们认定新修正稿在真实入口不兼容。

在本轮检查的当前Catalog构造、112个直接改写入口和CustomShop转换中，没有找到把皇家守护者普通/金色完整行互换、或把同一版本放到两个键下的路径。当前磁盘输入也与GD来源常量精确一致。

完整编译调用链仍不能闭合：当前tools/build_effect_catalog.py缺失，历史版本不能替代当前发布pin，大量先行模块原件缺失且可变引用没有全图证明。维持候选安装暂缓，不修改或削弱任何校验。345条原参考缺口不变。

## 当前Catalog如何建立身份

core/catalog.gd：

- 11635行规范化输入；11640–11644逐行取出并深复制。
- 11648行令id=str(card.get("id",""))；皇家守护者的两个实际id均为固定字符串。
- 11810–11811从cards.get(id,{})深复制旧行，再用当前行覆盖，包括行内id。
- 11822行存回cards[id]。

因此，对这两种合法字符串身份，插入键由该行自身id生成。交换JSON数组的行顺序不会交换映射键；重复普通行只会覆盖普通键，不能凭空把它写入金色键。传入行的id不能在这段代码中与插入键独立选择。

_normalize_numbers（18797–18803）递归转换整数浮点值，不改字符串id。CustomShop（103–148）先深复制cards，之后只改费用、等级、店铺和派生元数据，不改行内id或重分配两者的键。从正确映射出发，这些转换保持身份绑定；它们并不承诺修复预先构造的坏映射。

## 实际磁盘输入

按Catalog列出的20份输入JSON逐行流式解析，并逐文件匹配已有源码树SHA256。皇家守护者只出现四行：

- data/catalog_raw.json的第1955、1956个零基索引行，普通/金色分别与当前GD RAW精确相同。
- data/catalog.json的第3396、3397个零基索引行，普通/金色分别与当前GD EXPECTED精确相同。
- 其余18份加载输入没有这两个id。

这里只读取了数据，没有执行完整Catalog加载。流式解析峰值约34 MiB，没有一次加载整个30.9 MB raw JSON文档。

## 112个直接改写入口已经进一步收束

108个apply_overlay调用及4个前置mutator均已解析到实际preload文件并检查直接函数体、目标常量及写入方式。直接写入域全部限定于固定ID/IDS或经过成员检查的row.id，且与皇家守护者两个id不相交。

- 没有直接遍历整个传入Catalog map的函数，也没有将整个map继续传给其他函数。
- Pressure、RoundUp、QuestIdentity会改任务卡id，但同时迁移对应键，且不涉及皇家守护者。
- 若干函数进行通用merge，但仅作用于限定目标行；FinalSource/HeroValues还限定字段，不允许id。
- 部分函数把一个已选定的行交给辅助函数。未展开任意全局或别名递归图，这与“直接入口可任意改写整个map”不同。
- Catalog另有12137–12138的通用数值覆盖写入。当前catalog_value_overrides.json只有16项attack/health覆盖，不含皇家守护者；不能把未来任意修改的数据视为当前输入。

所以，不能再仅以“存在108个overlay”作为它们可能生成这些皇家守护者错配的依据。完整直接实现、常量、调用行及112个文件哈希已保存。

## 历史编译器的调用路径

只进行AST解析，不导入或执行历史Python模块。每版读取一份代表整本并复核哈希，共98个不同版本，其中69个版本含皇家守护者hook；现存索引将这69版对应到133份保存副本，本轮没有重读全部133份副本。69版全部使用同一结构：

1. cards={c['id']:c for c in raw}，先按行内id建表。
2. 在家族循环中使用c=cards.get(identity)。
3. 调用compile_imperial_defender(c,cards)。

代表性的imperial_defender_native_recovery驱动在532行构造cards，7356–7362行执行该hook。直接第一层cards[...]赋值在构造之后、hook之前未检出，但这不涵盖别名修改、方法调用或其他模块的副作用。

每个相关版本在hook之前有824–841处语法上直接将cards作为位置参数的调用点，涉及702–719个当前tools目录缺失的导入模块。这是静态源位置计数，不是证明每处都会执行，也不是全传递依赖数量。

构造后紧接着调用的Python前置模块中：

- recruit_quest_identity.py和hero_value_overrides.py在当前tools及保存整本路径清单中均未找到。
- final_source_overrides.py存在，来源哈希和其数据manifest pin匹配；固定目标集合不含皇家守护者，字段白名单不允许id。

此外raw=list(cards.values())保留行对象引用，许多后续编译函数也接收cards或其中的行。没有这些原件及当前驱动身份，不能把起点的建表不变量直接扩展为到达任意后续调用时的不变量。GD同名用途的实现不能冒充缺失Python模块的实际行为。

## 三项合成反例应如何理解

- 当前Imperial raw_source_error按行内id验证，该行属于哪个映射键不是它的参数。
- source_error及closure_error没有显式比较请求键与返回行的id。Catalog get_card（14841）也直接返回保存的Dictionary。
- 旧Python原件已经要求cards[identity]等于该identity的RAW；新修正稿保留这个更强的键身份要求。三项结构分歧不是新修正稿引入的退化。
- 合法输入的已查构造路径会自行建立键/id绑定，因此这些合成坏映射不能仅通过改行顺序在该入口复现。
- cards公开可变，get_card和list_cards暴露行引用。任意外部别名改写尚未作全图证明。对current core/ui的直接.cards赋值文本筛查发现8处候选，除CustomShop外为派生上下文/结果结构；这不是别名或动态调用的完整证明，也没有据此认定实际故障可达。

最准确的区分是：已证实校验契约对任意合成map有差别；未找到所查正常当前入口生成三项错配的路径；尚未证明整个运行或编译系统绝对不可达。

## 保持的边界与下一步

没有运行Godot、Game、完整Catalog或任何历史编译器，没有网络、下载、安装或源码修正。历史原件、候选、旧备份、XML状态及旧存档验收边界均保持不变。

候选仍暂缓。最有价值的下一步是取得与当前core/data一致的权威驱动整本和缺失的关键前置模块，再围绕其真实调用顺序证明或限定键/id不变量。不能用历史版本的共同结构替代当前版本来源，也不应放松候选的键校验来追求孤立校验器的形式一致。

## 证据导航

- CURRENT_INPUT_ROWS.json：20份当前数据输入的哈希、计数及四条精确来源记录。
- HISTORICAL_DRIVER_SUMMARY.json、HISTORICAL_DRIVER_TRACE.json：98版来源与69版hook静态记录。
- PYTHON_PREPROCESSOR_BOUNDARIES.json：三项前置Python模块的实际可用性与边界。
- mutator_supplement_report.md、mutator_direct_implementations.md、mutator_inventory.json、mutator_source_sha256.json：112个直接改写入口。
- catalog_identity_excerpts.txt：当前构造、读取、CustomShop及来源校验的逐行原文。
- EXTERNAL_CARDS_WRITE_CANDIDATES.json：有限的直接.cards赋值文本筛查。
- selected_inputs/、SELECTED_INPUT_PINS.json：代表性完整输入独立副本。
- FINAL_RECHECK.json：末尾字节复核及未安装状态。

所有证据是本地有限范围结论，不把未执行的流程记为通过。
