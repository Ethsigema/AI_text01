# 补充：108 个 overlay 与 4 个前置 mutator 的直接实现

## 结论
本次已将 Catalog 的 preload 名称逐一解析到 112 个直接函数实现，而不是仅统计调用数量。108 个 apply_overlay（92 个 Patch3702、16 个其他来源）及 DamageRegistry / QuestIdentity / FinalSource / HeroValues 的直接写入域全部被固定 ID、IDS，或先验证为 IDS 成员的输入 row.id 限制；核对常量后均与 Imperial 的 BG22_HERO_007_Buddy / BG22_HERO_007_Buddy_G 不相交。

112 个直接函数中：没有遍历整个传入 Catalog cards 的函数，没有将整个传入 cards 参数转交其他函数的调用，没有显式 Imperial ID。部分函数将单个指定行传给 source_error / import_error / same / source_from_baseline 等辅助函数；这不同于开放整个 map。未展开任意全局/别名递归图，结论限于直接实现和显式目标域。

因此，上份报告把这些调用列为“尚未审查的证明义务”现已得到更精确收束：不能继续以“有 108 个 overlay”作为它们可能任意改写 Imperial 键的依据。没有发现这些直接实现产生那三种 Imperial 合法整行交换/复制 map 的路径。

## 写入方式
- 92 个 Patch3702：固定 ID/IDS 下替换整行，通常先对旧行做完整基线检查、深复制，再合并 EFFECTIVE_FIELDS 或 packet 字段，或提交 staged 行。新增时空卡也仅写各自固定 ID。Ashen:40–59 只改副本的 attack/health/text/effects 后在 IDS 下提交。MiniatureShip/两种 Phrasebook 和 Azerite/Twilight/Tidecaller 含 packet effective_fields 的通用 merge，但目标域仍是固定不相交卡。
- Fairmount:22–36：遍历其两个固定 Buddy ID，改副本效果/支持元数据并替换该行；不是 Imperial Buddy。
- Pressure:12–23：读取 ALIAS="104661"，17 行设置 canonical.id=ID="BG27_Quest_801"，22 行删除旧键并写新键。身份转换与键迁移一致。
- RoundUp:11–27：OLD_ID="104660" 到 ID="BG27_Quest_802"；18 行改 id，24–25 行同步迁移键。
- SortItAllOut、WitnessProtection、ExhumeBones、DustPrints、MurderWeapon、AssembleLineup：通过 cards.get(ID) 得到固定任务行的别名，原地改 supported/effects/implementation 元数据，不改 id、不迁移键。
- Eonar:37–45 和 WinnerBread:30–38：固定 ID 行深复制后 merge(CARD/ROW,true)，再写回固定键。
- Elise:35–48、ParasiticFleshling:23–33、MutatedLasher:31–47、DeterminedDefender:26–41、UpbeatUpstart:12–25：遍历磁盘 overlay 的 cards 数组（不是 Catalog 全表），写入前检查 row.id ∈ IDS；深复制对应 map 行，通用 merge(row,true)，以同一 row.id 写回或用 IDS 提交 staged rows。输入行包含其自身 id，所以这些 merge 本身不将另一未绑定身份放入该键。

## 四个前置函数
- damage_listener_registry.gd:972–990：仅 SOURCE_IDS + TOKEN_IDS；985–988 原地添加 damage_listener_source、client_card_id、client_dbf_id，不写 id。常量 6–7 行不含 Imperial。
- quest_identity_overrides.gd:24–34：固定 FROM_ID → TO_ID；31 行显式验证 canonical_card.id == TO_ID，32–33 行删除旧键并用 TO_ID 写入深复制行。其目标是 BG27_Quest_800。
- final_source_overrides.gd:7–36：16 行固定 IDS 成员检查；24–25 行字段白名单（text/category/categories；特定 ID 的 tier/name/tribes），明确不允许 id；33–35 行对计划指定行写元数据并 merge 受限字段。不是泛型任意 ID/字段入口。
- hero_value_overrides.gd:4–30：12 行固定三个英雄 ID 且 kind==hero；15–17 行要求 fields 大小 4 且包含 health/armor/armor_by_mode/text，因此不能混入 id；24–29 行合并这些字段与元数据。

## 剩余边界
直接入口已经按目标域区分。部分实现有通用字段 merge 和单行 helper 调用，其完整副作用/所有新行 id 的全局证明需要更深展开，但对本次“是否直接触及 Imperial 两键”的问题，不能忽略已验证的不相交域。任意预先构造的共享字典别名、外部对公开 cards/get_card 返回值的修改仍不在本次证明内。Catalog 自身 12137–12138 的 catalog_value_overrides 泛型字段写入也不属于上述 112 个函数；当前文件只含 attack/health、没有 Imperial 行，结论保持原有界限。

## 证据
- mutator_direct_implementations.md：112 个函数逐项文件、行号、调用行、目标常量、完整直接函数体、SHA256。
- mutator_inventory.json：机器可读的初始解析记录。
- mutator_source_sha256.json：112 个直接源文件哈希。

未执行 Godot、Game、编译器或网络请求；仅新增本目录补充证据，既有报告与项目文件保持不变。
