## Patch3702CrimsonVindicator.apply_overlay
File: core/patch_3702_crimson_vindicator_sources.gd:92-103
SHA256: a16f78a7504617e240eebb95fc6e504ecea1e16c665e9e8ee792b7d9de875e2b
Catalog call lines: 11823
Scope: fixed target IDs disjoint from Imperial. Whole-map iteration: none. Whole-map forwarding: none. Explicit Imperial literal in direct file: False
Target constants:
4: const IDS: Array=["BG36_241","BG36_241_G"]
Direct function (all writes, merges and helper calls preserved):
92: static func apply_overlay(cards: Dictionary) -> String:
93: 	var rows: Dictionary=packet()
94: 	if rows.size()!=IDS.size(): return "partial_3702_crimson_vindicator_missing_or_changed_packet"
95: 	var staged: Dictionary={}
96: 	# Verify both full old preimages before publishing either new source.
97: 	for identity in IDS:
98: 		if not cards.get(identity) is Dictionary or not same(cards[identity],rows[identity].expected_baseline): return "partial_3702_crimson_vindicator_changed_baseline:"+identity
99: 		var current: Dictionary=_expected(identity,rows)
100: 		if current.is_empty(): return "partial_3702_crimson_vindicator_changed_text_digest:"+identity
101: 		staged[identity]=current
102: 	for identity in IDS: cards[identity]=staged[identity]
103: 	return ""

## Patch3702Eudora.apply_overlay
File: core/patch_3702_eudora_sources.gd:96-107
SHA256: a176c545c64ed8ac76ef0a2ef18eae84a391ce10e88e45c41cc7ff3008a76315
Catalog call lines: 11826
Scope: fixed target IDs disjoint from Imperial. Whole-map iteration: none. Whole-map forwarding: none. Explicit Imperial literal in direct file: False
Target constants:
4: const IDS: Array=["BG33_828","BG33_828_G"]
5: const FOUR_IDS: Array=["BG32_202","BG32_202_G","BG33_828","BG33_828_G"]
Direct function (all writes, merges and helper calls preserved):
96: static func apply_overlay(cards: Dictionary) -> String:
97: 	var rows: Dictionary=packet()
98: 	if rows.size()!=FOUR_IDS.size(): return "partial_3702_eudora_missing_or_changed_packet"
99: 	var staged: Dictionary={}
100: 	# Authenticate all four complete preimages before publishing either changed source.
101: 	for identity in FOUR_IDS:
102: 		if not cards.get(identity) is Dictionary or not same(cards[identity],rows[identity].expected_baseline): return "partial_3702_eudora_changed_baseline:"+identity
103: 		var current: Dictionary=_expected(identity,rows)
104: 		if current.is_empty(): return "partial_3702_eudora_changed_text_digest:"+identity
105: 		if accepts_id(identity): staged[identity]=current
106: 	for identity in IDS: cards[identity]=staged[identity]
107: 	return ""

## Patch3702UnboundTempest.apply_overlay
File: core/patch_3702_unbound_tempest_sources.gd:66-77
SHA256: 09dd1ed96c5b2fb16687221d0a60456a7fccb56613623f254f6123e9629b8a6a
Catalog call lines: 11829
Scope: fixed target IDs disjoint from Imperial. Whole-map iteration: none. Whole-map forwarding: none. Explicit Imperial literal in direct file: False
Target constants:
4: const IDS: Array=["BG36_352","BG36_352_G"]
Direct function (all writes, merges and helper calls preserved):
66: static func apply_overlay(cards: Dictionary) -> String:
67: 	var rows: Dictionary=packet()
68: 	if rows.size()!=IDS.size(): return "partial_3702_unbound_tempest_missing_or_changed_packet"
69: 	var staged: Dictionary={}
70: 	# Authenticate the complete two-row preimage before publishing either variant.
71: 	for identity in IDS:
72: 		if not cards.get(identity) is Dictionary: return "partial_3702_unbound_tempest_missing_baseline:"+identity
73: 		var current: Dictionary=source_from_baseline(cards[identity],rows)
74: 		if current.is_empty(): return "partial_3702_unbound_tempest_changed_baseline:"+identity
75: 		staged[identity]=current
76: 	for identity in IDS: cards[identity]=staged[identity]
77: 	return ""

## Patch3702SanguineRefiner.apply_overlay
File: core/patch_3702_sanguine_refiner_sources.gd:67-78
SHA256: 3bdceb24640428a0e691bcf65adc1ff7b4fec5cef53cbe04f76e369432345397
Catalog call lines: 11832
Scope: fixed target IDs disjoint from Imperial. Whole-map iteration: none. Whole-map forwarding: none. Explicit Imperial literal in direct file: False
Target constants:
5: const IDS: Array=["BG33_885","BG33_885_G"]
Direct function (all writes, merges and helper calls preserved):
67: static func apply_overlay(cards: Dictionary) -> String:
68: 	var rows: Dictionary=packet()
69: 	if rows.size()!=IDS.size(): return "partial_3702_sanguine_refiner_missing_or_changed_packet"
70: 	var staged: Dictionary={}
71: 	# No partial pair application, even when the second complete preimage fails.
72: 	for identity in IDS:
73: 		if not cards.get(identity) is Dictionary: return "partial_3702_sanguine_refiner_missing_baseline:"+identity
74: 		var current: Dictionary=source_from_baseline(cards[identity],rows)
75: 		if current.is_empty(): return "partial_3702_sanguine_refiner_changed_baseline:"+identity
76: 		staged[identity]=current
77: 	for identity in IDS: cards[identity]=staged[identity]
78: 	return ""

## Patch3702MamaBear.apply_overlay
File: core/patch_3702_mama_bear_sources.gd:64-74
SHA256: c76d01191d0e5acc276ecdf782701301306c57d4f7739285d59a50a8573908f1
Catalog call lines: 11835
Scope: fixed target IDs disjoint from Imperial. Whole-map iteration: none. Whole-map forwarding: none. Explicit Imperial literal in direct file: False
Target constants:
4: const IDS: Array=["BG35_MagicItem_871"]
Direct function (all writes, merges and helper calls preserved):
64: static func apply_overlay(cards: Dictionary) -> String:
65: 	# Preflight identity before writing; no normalization or disk reads here.
66: 	var staged: Dictionary={}
67: 	for id in IDS:
68: 		if not cards.has(id) or not same(cards[id],EXPECTED_BASELINE[id]): return "partial_3702_mama_bear_changed_whole_baseline:"+id
69: 		var merged: Dictionary=cards[id].duplicate(true);merged.merge(EFFECTIVE_FIELDS[id],true)
70: 		if not same(merged,EXPECTED_CURRENT[id]): return "partial_3702_mama_bear_changed_effective_derivation:"+id
71: 		staged[id]=merged
72: 	for id in IDS: cards[id]=staged[id]
73: 	return ""
74: 

## Patch3702Glambot.apply_overlay
File: core/patch_3702_glambot_sources.gd:65-75
SHA256: fd2db7aca918ba890aecafd99b25968effa1464fd6ed5f240373aa007830a176
Catalog call lines: 11838
Scope: fixed target IDs disjoint from Imperial. Whole-map iteration: none. Whole-map forwarding: none. Explicit Imperial literal in direct file: False
Target constants:
4: const IDS: Array=["BG36_853","BG36_853_G"]
Direct function (all writes, merges and helper calls preserved):
65: static func apply_overlay(cards: Dictionary) -> String:
66: 	# Preflight both identities before writing either; no normalization or disk reads here.
67: 	var staged: Dictionary={}
68: 	for id in IDS:
69: 		if not cards.has(id) or not same(cards[id],EXPECTED_BASELINE[id]): return "partial_3702_glambot_changed_whole_baseline:"+id
70: 		var merged: Dictionary=cards[id].duplicate(true);merged.merge(EFFECTIVE_FIELDS[id],true)
71: 		if not same(merged,EXPECTED_CURRENT[id]): return "partial_3702_glambot_changed_effective_derivation:"+id
72: 		staged[id]=merged
73: 	for id in IDS: cards[id]=staged[id]
74: 	return ""
75: 

## Patch3702Bobblehead.apply_overlay
File: core/patch_3702_bobblehead_sources.gd:61-68
SHA256: 84563029e3662fb28f9359fc5e63f35ce80bb0f050c9ec4bee178004f3e6363b
Catalog call lines: 11841
Scope: fixed target IDs disjoint from Imperial. Whole-map iteration: none. Whole-map forwarding: none. Explicit Imperial literal in direct file: False
Target constants:
4: const ID: String="BG30_MagicItem_998"
Direct function (all writes, merges and helper calls preserved):
61: static func apply_overlay(cards: Dictionary) -> String:
62: 	# Startup already proved immutable files. No disk reads or normalization here.
63: 	if not cards.has(ID) or not same(cards[ID],EXPECTED_BASELINE): return "partial_3702_bobblehead_changed_whole_baseline"
64: 	var merged: Dictionary=cards[ID].duplicate(true);merged.merge(EFFECTIVE_FIELDS,true)
65: 	if not same(merged,EXPECTED_CURRENT): return "partial_3702_bobblehead_changed_effective_derivation"
66: 	cards[ID]=merged
67: 	return ""
68: 

## Patch3702PackedWallet.apply_overlay
File: core/patch_3702_packed_wallet_sources.gd:61-68
SHA256: 59d73bb5cd3233dc2b4e917200312d7d5ce30350c7b2f8f973641bab4416695d
Catalog call lines: 11844
Scope: fixed target IDs disjoint from Imperial. Whole-map iteration: none. Whole-map forwarding: none. Explicit Imperial literal in direct file: False
Target constants:
4: const ID: String="BG35_MagicItem_814"
Direct function (all writes, merges and helper calls preserved):
61: static func apply_overlay(cards: Dictionary) -> String:
62: 	# Startup already proved immutable files. No disk reads or normalization here.
63: 	if not cards.has(ID) or not same(cards[ID],EXPECTED_BASELINE): return "partial_3702_packed_wallet_changed_whole_baseline"
64: 	var merged: Dictionary=cards[ID].duplicate(true);merged.merge(EFFECTIVE_FIELDS,true)
65: 	if not same(merged,EXPECTED_CURRENT): return "partial_3702_packed_wallet_changed_effective_derivation"
66: 	cards[ID]=merged
67: 	return ""
68: 

## Patch3702GreaterBootyBrew.apply_overlay
File: core/patch_3702_greater_booty_brew_sources.gd:61-68
SHA256: 0fa1317d7166a513c0bef7a789e2298ac34bc9ab839a53478637b1bf3cfe3a59
Catalog call lines: 11847
Scope: fixed target IDs disjoint from Imperial. Whole-map iteration: none. Whole-map forwarding: none. Explicit Imperial literal in direct file: False
Target constants:
4: const ID: String="BG30_MagicItem_924t"
Direct function (all writes, merges and helper calls preserved):
61: static func apply_overlay(cards: Dictionary) -> String:
62: 	# Startup already proved immutable files. No disk reads or normalization here.
63: 	if not cards.has(ID) or not same(cards[ID],EXPECTED_BASELINE): return "partial_3702_greater_booty_brew_changed_whole_baseline"
64: 	var merged: Dictionary=cards[ID].duplicate(true);merged.merge(EFFECTIVE_FIELDS,true)
65: 	if not same(merged,EXPECTED_CURRENT): return "partial_3702_greater_booty_brew_changed_effective_derivation"
66: 	cards[ID]=merged
67: 	return ""
68: 

## Patch3702Crowbar.apply_overlay
File: core/patch_3702_crowbar_sources.gd:61-68
SHA256: 1f117bfd8dc60163293331f5847ac98af252c0d7472880a24849fe88b17a32f0
Catalog call lines: 11850
Scope: fixed target IDs disjoint from Imperial. Whole-map iteration: none. Whole-map forwarding: none. Explicit Imperial literal in direct file: False
Target constants:
4: const ID: String="BG35_MagicItem_713"
Direct function (all writes, merges and helper calls preserved):
61: static func apply_overlay(cards: Dictionary) -> String:
62: 	# Startup already proved immutable files. No disk reads or normalization here.
63: 	if not cards.has(ID) or not same(cards[ID],EXPECTED_BASELINE): return "partial_3702_crowbar_changed_whole_baseline"
64: 	var merged: Dictionary=cards[ID].duplicate(true);merged.merge(EFFECTIVE_FIELDS,true)
65: 	if not same(merged,EXPECTED_CURRENT): return "partial_3702_crowbar_changed_effective_derivation"
66: 	cards[ID]=merged
67: 	return ""
68: 

## Patch3702MawPortrait.apply_overlay
File: core/patch_3702_maw_portrait_sources.gd:61-68
SHA256: 05558b4ecf34b3f5dfafde5e3b0723cab15c2c746d74d5667eeb580801ef0cbc
Catalog call lines: 11853
Scope: fixed target IDs disjoint from Imperial. Whole-map iteration: none. Whole-map forwarding: none. Explicit Imperial literal in direct file: False
Target constants:
4: const ID: String="BG32_MagicItem_205"
Direct function (all writes, merges and helper calls preserved):
61: static func apply_overlay(cards: Dictionary) -> String:
62: 	# Startup already proved immutable files. No disk reads or normalization here.
63: 	if not cards.has(ID) or not same(cards[ID],EXPECTED_BASELINE): return "partial_3702_maw_portrait_changed_whole_baseline"
64: 	var merged: Dictionary=cards[ID].duplicate(true);merged.merge(EFFECTIVE_FIELDS,true)
65: 	if not same(merged,EXPECTED_CURRENT): return "partial_3702_maw_portrait_changed_effective_derivation"
66: 	cards[ID]=merged
67: 	return ""
68: 

## Patch3702ForestHeart.apply_overlay
File: core/patch_3702_forest_heart_sources.gd:61-68
SHA256: 4566d48af411c0423f80df6edf384b023efb4b1bf59c4d261ad02f16374f9ccf
Catalog call lines: 11856
Scope: fixed target IDs disjoint from Imperial. Whole-map iteration: none. Whole-map forwarding: none. Explicit Imperial literal in direct file: False
Target constants:
4: const ID: String="BG32_MagicItem_801t"
Direct function (all writes, merges and helper calls preserved):
61: static func apply_overlay(cards: Dictionary) -> String:
62: 	# Startup already proved immutable files. No disk reads or normalization here.
63: 	if not cards.has(ID) or not same(cards[ID],EXPECTED_BASELINE): return "partial_3702_forest_heart_changed_whole_baseline"
64: 	var merged: Dictionary=cards[ID].duplicate(true);merged.merge(EFFECTIVE_FIELDS,true)
65: 	if not same(merged,EXPECTED_CURRENT): return "partial_3702_forest_heart_changed_effective_derivation"
66: 	cards[ID]=merged
67: 	return ""
68: 

## Patch3702SecretSchematic.apply_overlay
File: core/patch_3702_secret_schematic_sources.gd:61-68
SHA256: 0ecac4b54c19aa157772a10b290188955c9952a2300bc8914894abdbc51c63e2
Catalog call lines: 11859
Scope: fixed target IDs disjoint from Imperial. Whole-map iteration: none. Whole-map forwarding: none. Explicit Imperial literal in direct file: False
Target constants:
4: const ID: String="BG36_MagicItem_840"
Direct function (all writes, merges and helper calls preserved):
61: static func apply_overlay(cards: Dictionary) -> String:
62: 	# Startup already proved immutable files. No disk reads or normalization here.
63: 	if not cards.has(ID) or not same(cards[ID],EXPECTED_BASELINE): return "partial_3702_secret_schematic_changed_whole_baseline"
64: 	var merged: Dictionary=cards[ID].duplicate(true);merged.merge(EFFECTIVE_FIELDS,true)
65: 	if not same(merged,EXPECTED_CURRENT): return "partial_3702_secret_schematic_changed_effective_derivation"
66: 	cards[ID]=merged
67: 	return ""
68: 

## Patch3702LesserBootyBrew.apply_overlay
File: core/patch_3702_lesser_booty_brew_sources.gd:61-68
SHA256: 2bca3bb9079d5780c75ef024410ee656833306c64b110d16896b95207b16e2fe
Catalog call lines: 11862
Scope: fixed target IDs disjoint from Imperial. Whole-map iteration: none. Whole-map forwarding: none. Explicit Imperial literal in direct file: False
Target constants:
4: const ID: String="BG30_MagicItem_924"
Direct function (all writes, merges and helper calls preserved):
61: static func apply_overlay(cards: Dictionary) -> String:
62: 	# Startup already proved immutable files. No disk reads or normalization here.
63: 	if not cards.has(ID) or not same(cards[ID],EXPECTED_BASELINE): return "partial_3702_lesser_booty_brew_changed_whole_baseline"
64: 	var merged: Dictionary=cards[ID].duplicate(true);merged.merge(EFFECTIVE_FIELDS,true)
65: 	if not same(merged,EXPECTED_CURRENT): return "partial_3702_lesser_booty_brew_changed_effective_derivation"
66: 	cards[ID]=merged
67: 	return ""
68: 

## Patch3702WeightedGauntlet.apply_overlay
File: core/patch_3702_weighted_gauntlet_sources.gd:61-68
SHA256: 8246b843ba3e50c46524038bbfa15e738eac2d1b3f4826dcc8c2d443e4ac38f1
Catalog call lines: 11865
Scope: fixed target IDs disjoint from Imperial. Whole-map iteration: none. Whole-map forwarding: none. Explicit Imperial literal in direct file: False
Target constants:
4: const ID: String="BG36_MagicItem_414"
Direct function (all writes, merges and helper calls preserved):
61: static func apply_overlay(cards: Dictionary) -> String:
62: 	# Startup already proved immutable files. No disk reads or normalization here.
63: 	if not cards.has(ID) or not same(cards[ID],EXPECTED_BASELINE): return "partial_3702_weighted_gauntlet_changed_whole_baseline"
64: 	var merged: Dictionary=cards[ID].duplicate(true);merged.merge(EFFECTIVE_FIELDS,true)
65: 	if not same(merged,EXPECTED_CURRENT): return "partial_3702_weighted_gauntlet_changed_effective_derivation"
66: 	cards[ID]=merged
67: 	return ""
68: 

## Patch3702WandDivination.apply_overlay
File: core/patch_3702_wand_divination_sources.gd:61-68
SHA256: 9208e09837bb647b92e6abdea6c13db6c3e7c2f693c45c34a79a1f146e185f82
Catalog call lines: 11868
Scope: fixed target IDs disjoint from Imperial. Whole-map iteration: none. Whole-map forwarding: none. Explicit Imperial literal in direct file: False
Target constants:
4: const ID: String="BG36_MagicItem_307"
Direct function (all writes, merges and helper calls preserved):
61: static func apply_overlay(cards: Dictionary) -> String:
62: 	# Startup already proved immutable files. No disk reads or normalization here.
63: 	if not cards.has(ID) or not same(cards[ID],EXPECTED_BASELINE): return "partial_3702_wand_divination_changed_whole_baseline"
64: 	var merged: Dictionary=cards[ID].duplicate(true);merged.merge(EFFECTIVE_FIELDS,true)
65: 	if not same(merged,EXPECTED_CURRENT): return "partial_3702_wand_divination_changed_effective_derivation"
66: 	cards[ID]=merged
67: 	return ""
68: 

## Patch3702StormcoilSticker.apply_overlay
File: core/patch_3702_stormcoil_sticker_sources.gd:61-68
SHA256: 9fdfa2dd673f84c68bf437b7cd5c108f222584e303975fea4bf269a6f8bbccfb
Catalog call lines: 11871
Scope: fixed target IDs disjoint from Imperial. Whole-map iteration: none. Whole-map forwarding: none. Explicit Imperial literal in direct file: False
Target constants:
4: const ID: String="BG35_MagicItem_302"
Direct function (all writes, merges and helper calls preserved):
61: static func apply_overlay(cards: Dictionary) -> String:
62: 	# Startup already proved immutable files. No disk reads or normalization here.
63: 	if not cards.has(ID) or not same(cards[ID],EXPECTED_BASELINE): return "partial_3702_stormcoil_sticker_changed_whole_baseline"
64: 	var merged: Dictionary=cards[ID].duplicate(true);merged.merge(EFFECTIVE_FIELDS,true)
65: 	if not same(merged,EXPECTED_CURRENT): return "partial_3702_stormcoil_sticker_changed_effective_derivation"
66: 	cards[ID]=merged
67: 	return ""
68: 

## Patch3702LuckyTabby.apply_overlay
File: core/patch_3702_lucky_tabby_sources.gd:61-68
SHA256: ee22fb968235eee68c1279581d84a1f963c2b1676592f0a4c350343c2720ffdd
Catalog call lines: 11874
Scope: fixed target IDs disjoint from Imperial. Whole-map iteration: none. Whole-map forwarding: none. Explicit Imperial literal in direct file: False
Target constants:
4: const ID: String="BG30_MagicItem_931"
Direct function (all writes, merges and helper calls preserved):
61: static func apply_overlay(cards: Dictionary) -> String:
62: 	# Startup already proved immutable files. No disk reads or normalization here.
63: 	if not cards.has(ID) or not same(cards[ID],EXPECTED_BASELINE): return "partial_3702_lucky_tabby_changed_whole_baseline"
64: 	var merged: Dictionary=cards[ID].duplicate(true);merged.merge(EFFECTIVE_FIELDS,true)
65: 	if not same(merged,EXPECTED_CURRENT): return "partial_3702_lucky_tabby_changed_effective_derivation"
66: 	cards[ID]=merged
67: 	return ""
68: 

## Patch3702PortableFactory.apply_overlay
File: core/patch_3702_portable_factory_sources.gd:61-68
SHA256: b224e43d598712904bd28a52ff152990a2c76218bcd7e34c82ad598681964518
Catalog call lines: 11877
Scope: fixed target IDs disjoint from Imperial. Whole-map iteration: none. Whole-map forwarding: none. Explicit Imperial literal in direct file: False
Target constants:
4: const ID: String="BG32_MagicItem_361t"
Direct function (all writes, merges and helper calls preserved):
61: static func apply_overlay(cards: Dictionary) -> String:
62: 	# Startup already proved immutable files. No disk reads or normalization here.
63: 	if not cards.has(ID) or not same(cards[ID],EXPECTED_BASELINE): return "partial_3702_portable_factory_changed_whole_baseline"
64: 	var merged: Dictionary=cards[ID].duplicate(true);merged.merge(EFFECTIVE_FIELDS,true)
65: 	if not same(merged,EXPECTED_CURRENT): return "partial_3702_portable_factory_changed_effective_derivation"
66: 	cards[ID]=merged
67: 	return ""
68: 

## Patch3702SkyGolemPortrait.apply_overlay
File: core/patch_3702_sky_golem_portrait_sources.gd:61-68
SHA256: 57fb105a3fde11ce9511e1aeb35901a0e24af786e3a07b85664421371d1556c9
Catalog call lines: 11880
Scope: fixed target IDs disjoint from Imperial. Whole-map iteration: none. Whole-map forwarding: none. Explicit Imperial literal in direct file: False
Target constants:
4: const ID: String="BG35_MagicItem_740"
Direct function (all writes, merges and helper calls preserved):
61: static func apply_overlay(cards: Dictionary) -> String:
62: 	# Startup already proved immutable files. No disk reads or normalization here.
63: 	if not cards.has(ID) or not same(cards[ID],EXPECTED_BASELINE): return "partial_3702_sky_golem_portrait_changed_whole_baseline"
64: 	var merged: Dictionary=cards[ID].duplicate(true);merged.merge(EFFECTIVE_FIELDS,true)
65: 	if not same(merged,EXPECTED_CURRENT): return "partial_3702_sky_golem_portrait_changed_effective_derivation"
66: 	cards[ID]=merged
67: 	return ""
68: 

## Patch3702RockinMusicBox.apply_overlay
File: core/patch_3702_rockin_music_box_sources.gd:61-68
SHA256: 37de846c977e39d7d34a1886bfd133a321680e422606596eb0c3e2381ba54632
Catalog call lines: 11883
Scope: fixed target IDs disjoint from Imperial. Whole-map iteration: none. Whole-map forwarding: none. Explicit Imperial literal in direct file: False
Target constants:
4: const ID: String="BG30_MagicItem_430"
Direct function (all writes, merges and helper calls preserved):
61: static func apply_overlay(cards: Dictionary) -> String:
62: 	# Startup already proved immutable files. No disk reads or normalization here.
63: 	if not cards.has(ID) or not same(cards[ID],EXPECTED_BASELINE): return "partial_3702_rockin_music_box_changed_whole_baseline"
64: 	var merged: Dictionary=cards[ID].duplicate(true);merged.merge(EFFECTIVE_FIELDS,true)
65: 	if not same(merged,EXPECTED_CURRENT): return "partial_3702_rockin_music_box_changed_effective_derivation"
66: 	cards[ID]=merged
67: 	return ""
68: 

## Patch3702PowderCourier.apply_overlay
File: core/patch_3702_powder_courier_sources.gd:61-68
SHA256: ef844fac2477d138459cd66963bd5b06921a20768fb8d4e60daae041a1e30115
Catalog call lines: 11886
Scope: fixed target IDs disjoint from Imperial. Whole-map iteration: none. Whole-map forwarding: none. Explicit Imperial literal in direct file: False
Target constants:
4: const ID: String="BG26_810"
Direct function (all writes, merges and helper calls preserved):
61: static func apply_overlay(cards: Dictionary) -> String:
62: 	# Startup already proved immutable files. No disk reads or normalization here.
63: 	if not cards.has(ID) or not same(cards[ID],EXPECTED_BASELINE): return "partial_3702_powder_courier_changed_whole_baseline"
64: 	var merged: Dictionary=cards[ID].duplicate(true);merged.merge(EFFECTIVE_FIELDS,true)
65: 	if not same(merged,EXPECTED_CURRENT): return "partial_3702_powder_courier_changed_effective_derivation"
66: 	cards[ID]=merged
67: 	return ""
68: 

## Patch3702PowderCourierGolden.apply_overlay
File: core/patch_3702_powder_courier_golden_sources.gd:61-68
SHA256: 73753c51a64f4bb958decf9ef6465eab4c1d65269a0f50632d3b4ce2d5a38bc9
Catalog call lines: 11889
Scope: fixed target IDs disjoint from Imperial. Whole-map iteration: none. Whole-map forwarding: none. Explicit Imperial literal in direct file: False
Target constants:
4: const ID: String="BG26_810_G"
Direct function (all writes, merges and helper calls preserved):
61: static func apply_overlay(cards: Dictionary) -> String:
62: 	# Startup already proved immutable files. No disk reads or normalization here.
63: 	if not cards.has(ID) or not same(cards[ID],EXPECTED_BASELINE): return "partial_3702_powder_courier_golden_changed_whole_baseline"
64: 	var merged: Dictionary=cards[ID].duplicate(true);merged.merge(EFFECTIVE_FIELDS,true)
65: 	if not same(merged,EXPECTED_CURRENT): return "partial_3702_powder_courier_golden_changed_effective_derivation"
66: 	cards[ID]=merged
67: 	return ""
68: 

## Patch3702FandralFortune.apply_overlay
File: core/patch_3702_fandral_fortune_sources.gd:61-68
SHA256: 3f4201283a95b8881a317c4fa176dea38b4c0c029a3f460916c12a229f400eae
Catalog call lines: 11892
Scope: fixed target IDs disjoint from Imperial. Whole-map iteration: none. Whole-map forwarding: none. Explicit Imperial literal in direct file: False
Target constants:
4: const ID: String="BG31_892"
Direct function (all writes, merges and helper calls preserved):
61: static func apply_overlay(cards: Dictionary) -> String:
62: 	# Startup already proved immutable files. No disk reads or normalization here.
63: 	if not cards.has(ID) or not same(cards[ID],EXPECTED_BASELINE): return "partial_3702_fandral_fortune_changed_whole_baseline"
64: 	var merged: Dictionary=cards[ID].duplicate(true);merged.merge(EFFECTIVE_FIELDS,true)
65: 	if not same(merged,EXPECTED_CURRENT): return "partial_3702_fandral_fortune_changed_effective_derivation"
66: 	cards[ID]=merged
67: 	return ""
68: 

## Patch3702JailbirdJuggernaut.apply_overlay
File: core/patch_3702_jailbird_juggernaut_sources.gd:61-68
SHA256: 786c2300ec5b345e61839ccf0f364c0c1dc90465d567b29cb3d2b1ee5bbeeeab
Catalog call lines: 11895
Scope: fixed target IDs disjoint from Imperial. Whole-map iteration: none. Whole-map forwarding: none. Explicit Imperial literal in direct file: False
Target constants:
4: const ID: String="BG36_333"
Direct function (all writes, merges and helper calls preserved):
61: static func apply_overlay(cards: Dictionary) -> String:
62: 	# Startup already proved immutable files. No disk reads or normalization here.
63: 	if not cards.has(ID) or not same(cards[ID],EXPECTED_BASELINE): return "partial_3702_jailbird_juggernaut_changed_whole_baseline"
64: 	var merged: Dictionary=cards[ID].duplicate(true);merged.merge(EFFECTIVE_FIELDS,true)
65: 	if not same(merged,EXPECTED_CURRENT): return "partial_3702_jailbird_juggernaut_changed_effective_derivation"
66: 	cards[ID]=merged
67: 	return ""
68: 

## Patch3702JailbirdJuggernautGolden.apply_overlay
File: core/patch_3702_jailbird_juggernaut_golden_sources.gd:61-68
SHA256: 54dcc2cdcde4cddd10b63c49826f8a3aaecc24b99319c07b8dc36cad1cbd6971
Catalog call lines: 11898
Scope: fixed target IDs disjoint from Imperial. Whole-map iteration: none. Whole-map forwarding: none. Explicit Imperial literal in direct file: False
Target constants:
4: const ID: String="BG36_333_G"
Direct function (all writes, merges and helper calls preserved):
61: static func apply_overlay(cards: Dictionary) -> String:
62: 	# Startup already proved immutable files. No disk reads or normalization here.
63: 	if not cards.has(ID) or not same(cards[ID],EXPECTED_BASELINE): return "partial_3702_jailbird_juggernaut_golden_changed_whole_baseline"
64: 	var merged: Dictionary=cards[ID].duplicate(true);merged.merge(EFFECTIVE_FIELDS,true)
65: 	if not same(merged,EXPECTED_CURRENT): return "partial_3702_jailbird_juggernaut_golden_changed_effective_derivation"
66: 	cards[ID]=merged
67: 	return ""
68: 

## Patch3702Hopebringer.apply_overlay
File: core/patch_3702_hopebringer_sources.gd:61-68
SHA256: 318d48b6e6af701be9e290bedbbed33ab30f870e4aa7b71247da2f8e98b21d3e
Catalog call lines: 11901
Scope: fixed target IDs disjoint from Imperial. Whole-map iteration: none. Whole-map forwarding: none. Explicit Imperial literal in direct file: False
Target constants:
4: const ID: String="BG36_364"
Direct function (all writes, merges and helper calls preserved):
61: static func apply_overlay(cards: Dictionary) -> String:
62: 	# Startup already proved immutable files. No disk reads or normalization here.
63: 	if not cards.has(ID) or not same(cards[ID],EXPECTED_BASELINE): return "partial_3702_hopebringer_changed_whole_baseline"
64: 	var merged: Dictionary=cards[ID].duplicate(true);merged.merge(EFFECTIVE_FIELDS,true)
65: 	if not same(merged,EXPECTED_CURRENT): return "partial_3702_hopebringer_changed_effective_derivation"
66: 	cards[ID]=merged
67: 	return ""
68: 

## Patch3702HopebringerGolden.apply_overlay
File: core/patch_3702_hopebringer_golden_sources.gd:61-68
SHA256: d9da7affce20fd1498205a635f888c8be4f072b628078579cfc77ac29f348a41
Catalog call lines: 11904
Scope: fixed target IDs disjoint from Imperial. Whole-map iteration: none. Whole-map forwarding: none. Explicit Imperial literal in direct file: False
Target constants:
4: const ID: String="BG36_364_G"
Direct function (all writes, merges and helper calls preserved):
61: static func apply_overlay(cards: Dictionary) -> String:
62: 	# Startup already proved immutable files. No disk reads or normalization here.
63: 	if not cards.has(ID) or not same(cards[ID],EXPECTED_BASELINE): return "partial_3702_hopebringer_golden_changed_whole_baseline"
64: 	var merged: Dictionary=cards[ID].duplicate(true);merged.merge(EFFECTIVE_FIELDS,true)
65: 	if not same(merged,EXPECTED_CURRENT): return "partial_3702_hopebringer_golden_changed_effective_derivation"
66: 	cards[ID]=merged
67: 	return ""
68: 

## Patch3702Leviathan.apply_overlay
File: core/patch_3702_leviathan_sources.gd:61-68
SHA256: 9b426773cbdc1e7a9cfaf8b99b89e72872cb130efcf997cf2792feeb6d1cd842
Catalog call lines: 11907
Scope: fixed target IDs disjoint from Imperial. Whole-map iteration: none. Whole-map forwarding: none. Explicit Imperial literal in direct file: False
Target constants:
4: const ID: String="BG35_602"
Direct function (all writes, merges and helper calls preserved):
61: static func apply_overlay(cards: Dictionary) -> String:
62: 	# Startup already proved immutable files. No disk reads or normalization here.
63: 	if not cards.has(ID) or not same(cards[ID],EXPECTED_BASELINE): return "partial_3702_leviathan_changed_whole_baseline"
64: 	var merged: Dictionary=cards[ID].duplicate(true);merged.merge(EFFECTIVE_FIELDS,true)
65: 	if not same(merged,EXPECTED_CURRENT): return "partial_3702_leviathan_changed_effective_derivation"
66: 	cards[ID]=merged
67: 	return ""
68: 

## Patch3702LeviathanGolden.apply_overlay
File: core/patch_3702_leviathan_golden_sources.gd:61-68
SHA256: 4346a85ce34360f36c20b8e565a674f060bafebe8c1b5d9c2b2e6e8c1f2b03f7
Catalog call lines: 11910
Scope: fixed target IDs disjoint from Imperial. Whole-map iteration: none. Whole-map forwarding: none. Explicit Imperial literal in direct file: False
Target constants:
4: const ID: String="BG35_602_G"
Direct function (all writes, merges and helper calls preserved):
61: static func apply_overlay(cards: Dictionary) -> String:
62: 	# Startup already proved immutable files. No disk reads or normalization here.
63: 	if not cards.has(ID) or not same(cards[ID],EXPECTED_BASELINE): return "partial_3702_leviathan_golden_changed_whole_baseline"
64: 	var merged: Dictionary=cards[ID].duplicate(true);merged.merge(EFFECTIVE_FIELDS,true)
65: 	if not same(merged,EXPECTED_CURRENT): return "partial_3702_leviathan_golden_changed_effective_derivation"
66: 	cards[ID]=merged
67: 	return ""
68: 

## Patch3702Lobster.apply_overlay
File: core/patch_3702_lobster_sources.gd:61-68
SHA256: 3bf0d86713c5add8613eb20dd7c4af57e83122a60c4344ec4e21c7e7d41ba68a
Catalog call lines: 11913
Scope: fixed target IDs disjoint from Imperial. Whole-map iteration: none. Whole-map forwarding: none. Explicit Imperial literal in direct file: False
Target constants:
4: const ID: String="BG36_202"
Direct function (all writes, merges and helper calls preserved):
61: static func apply_overlay(cards: Dictionary) -> String:
62: 	# Startup already proved immutable files. No disk reads or normalization here.
63: 	if not cards.has(ID) or not same(cards[ID],EXPECTED_BASELINE): return "partial_3702_lobster_changed_whole_baseline"
64: 	var merged: Dictionary=cards[ID].duplicate(true);merged.merge(EFFECTIVE_FIELDS,true)
65: 	if not same(merged,EXPECTED_CURRENT): return "partial_3702_lobster_changed_effective_derivation"
66: 	cards[ID]=merged
67: 	return ""
68: 

## Patch3702LobsterGolden.apply_overlay
File: core/patch_3702_lobster_golden_sources.gd:61-68
SHA256: 299c27aadc9b72e5f944fd0ba56fc0e3514e097330c18209b90f6af021b8347d
Catalog call lines: 11916
Scope: fixed target IDs disjoint from Imperial. Whole-map iteration: none. Whole-map forwarding: none. Explicit Imperial literal in direct file: False
Target constants:
4: const ID: String="BG36_202_G"
Direct function (all writes, merges and helper calls preserved):
61: static func apply_overlay(cards: Dictionary) -> String:
62: 	# Startup already proved immutable files. No disk reads or normalization here.
63: 	if not cards.has(ID) or not same(cards[ID],EXPECTED_BASELINE): return "partial_3702_lobster_golden_changed_whole_baseline"
64: 	var merged: Dictionary=cards[ID].duplicate(true);merged.merge(EFFECTIVE_FIELDS,true)
65: 	if not same(merged,EXPECTED_CURRENT): return "partial_3702_lobster_golden_changed_effective_derivation"
66: 	cards[ID]=merged
67: 	return ""
68: 

## Patch3702Hyena.apply_overlay
File: core/patch_3702_hyena_sources.gd:61-68
SHA256: fc32ec21413ffc0e2689f82b15a19390e2b75268f273f69f4098914c579286ea
Catalog call lines: 11919
Scope: fixed target IDs disjoint from Imperial. Whole-map iteration: none. Whole-map forwarding: none. Explicit Imperial literal in direct file: False
Target constants:
4: const ID: String="BG36_210"
Direct function (all writes, merges and helper calls preserved):
61: static func apply_overlay(cards: Dictionary) -> String:
62: 	# Startup already proved immutable files. No disk reads or normalization here.
63: 	if not cards.has(ID) or not same(cards[ID],EXPECTED_BASELINE): return "partial_3702_hyena_changed_whole_baseline"
64: 	var merged: Dictionary=cards[ID].duplicate(true);merged.merge(EFFECTIVE_FIELDS,true)
65: 	if not same(merged,EXPECTED_CURRENT): return "partial_3702_hyena_changed_effective_derivation"
66: 	cards[ID]=merged
67: 	return ""
68: 

## Patch3702HyenaGolden.apply_overlay
File: core/patch_3702_hyena_golden_sources.gd:61-68
SHA256: 4cc797508da69be86e6d9afd3c30735b135bb6ae1af6ba8b336b39def3bcde11
Catalog call lines: 11922
Scope: fixed target IDs disjoint from Imperial. Whole-map iteration: none. Whole-map forwarding: none. Explicit Imperial literal in direct file: False
Target constants:
4: const ID: String="BG36_210_G"
Direct function (all writes, merges and helper calls preserved):
61: static func apply_overlay(cards: Dictionary) -> String:
62: 	# Startup already proved immutable files. No disk reads or normalization here.
63: 	if not cards.has(ID) or not same(cards[ID],EXPECTED_BASELINE): return "partial_3702_hyena_golden_changed_whole_baseline"
64: 	var merged: Dictionary=cards[ID].duplicate(true);merged.merge(EFFECTIVE_FIELDS,true)
65: 	if not same(merged,EXPECTED_CURRENT): return "partial_3702_hyena_golden_changed_effective_derivation"
66: 	cards[ID]=merged
67: 	return ""
68: 

## Patch3702Thaumaturgist.apply_overlay
File: core/patch_3702_thaumaturgist_sources.gd:61-68
SHA256: 2a610f5b8b623cd1c2ba0efc0616a9f3b452a7f6e1d6bcc30b3b32446acdbad1
Catalog call lines: 11925
Scope: fixed target IDs disjoint from Imperial. Whole-map iteration: none. Whole-map forwarding: none. Explicit Imperial literal in direct file: False
Target constants:
4: const ID: String="BG31_924"
Direct function (all writes, merges and helper calls preserved):
61: static func apply_overlay(cards: Dictionary) -> String:
62: 	# Startup already proved immutable files. No disk reads or normalization here.
63: 	if not cards.has(ID) or not same(cards[ID],EXPECTED_BASELINE): return "partial_3702_thaumaturgist_changed_whole_baseline"
64: 	var merged: Dictionary=cards[ID].duplicate(true);merged.merge(EFFECTIVE_FIELDS,true)
65: 	if not same(merged,EXPECTED_CURRENT): return "partial_3702_thaumaturgist_changed_effective_derivation"
66: 	cards[ID]=merged
67: 	return ""
68: 

## Patch3702ThaumaturgistGolden.apply_overlay
File: core/patch_3702_thaumaturgist_golden_sources.gd:61-68
SHA256: 2138f3eebfe98789e4b3b335bd5e2fe5c296ff84cbf306e8fb421e8671f67160
Catalog call lines: 11928
Scope: fixed target IDs disjoint from Imperial. Whole-map iteration: none. Whole-map forwarding: none. Explicit Imperial literal in direct file: False
Target constants:
4: const ID: String="BG31_924_G"
Direct function (all writes, merges and helper calls preserved):
61: static func apply_overlay(cards: Dictionary) -> String:
62: 	# Startup already proved immutable files. No disk reads or normalization here.
63: 	if not cards.has(ID) or not same(cards[ID],EXPECTED_BASELINE): return "partial_3702_thaumaturgist_golden_changed_whole_baseline"
64: 	var merged: Dictionary=cards[ID].duplicate(true);merged.merge(EFFECTIVE_FIELDS,true)
65: 	if not same(merged,EXPECTED_CURRENT): return "partial_3702_thaumaturgist_golden_changed_effective_derivation"
66: 	cards[ID]=merged
67: 	return ""
68: 

## Patch3702Thaumaturgy.apply_overlay
File: core/patch_3702_thaumaturgy_sources.gd:61-68
SHA256: 514cf562c7c49ff2593a5bb02b3e5e26941db5d1cf1ad88861b0c98772010dbc
Catalog call lines: 11931
Scope: fixed target IDs disjoint from Imperial. Whole-map iteration: none. Whole-map forwarding: none. Explicit Imperial literal in direct file: False
Target constants:
4: const ID: String="BG31_924t"
Direct function (all writes, merges and helper calls preserved):
61: static func apply_overlay(cards: Dictionary) -> String:
62: 	# Startup already proved immutable files. No disk reads or normalization here.
63: 	if not cards.has(ID) or not same(cards[ID],EXPECTED_BASELINE): return "partial_3702_thaumaturgy_changed_whole_baseline"
64: 	var merged: Dictionary=cards[ID].duplicate(true);merged.merge(EFFECTIVE_FIELDS,true)
65: 	if not same(merged,EXPECTED_CURRENT): return "partial_3702_thaumaturgy_changed_effective_derivation"
66: 	cards[ID]=merged
67: 	return ""
68: 

## Patch3702ThaumaturgyGolden.apply_overlay
File: core/patch_3702_thaumaturgy_golden_sources.gd:61-68
SHA256: 22b928340cda453cb7bf254081af5b279f9b31b9606d48eb0f846302611852a9
Catalog call lines: 11934
Scope: fixed target IDs disjoint from Imperial. Whole-map iteration: none. Whole-map forwarding: none. Explicit Imperial literal in direct file: False
Target constants:
4: const ID: String="BG31_924_Gt"
Direct function (all writes, merges and helper calls preserved):
61: static func apply_overlay(cards: Dictionary) -> String:
62: 	# Startup already proved immutable files. No disk reads or normalization here.
63: 	if not cards.has(ID) or not same(cards[ID],EXPECTED_BASELINE): return "partial_3702_thaumaturgy_golden_changed_whole_baseline"
64: 	var merged: Dictionary=cards[ID].duplicate(true);merged.merge(EFFECTIVE_FIELDS,true)
65: 	if not same(merged,EXPECTED_CURRENT): return "partial_3702_thaumaturgy_golden_changed_effective_derivation"
66: 	cards[ID]=merged
67: 	return ""
68: 

## Patch3702BeetleBand.apply_overlay
File: core/patch_3702_beetle_band_sources.gd:61-68
SHA256: cdcad2c5c749bf24dd0ba3f0cdb0b03fd5cd5f1b3973d0e0dc946b8168a328c9
Catalog call lines: 11937
Scope: fixed target IDs disjoint from Imperial. Whole-map iteration: none. Whole-map forwarding: none. Explicit Imperial literal in direct file: False
Target constants:
4: const ID: String="BG32_MagicItem_860t"
Direct function (all writes, merges and helper calls preserved):
61: static func apply_overlay(cards: Dictionary) -> String:
62: 	# Startup already proved immutable files. No disk reads or normalization here.
63: 	if not cards.has(ID) or not same(cards[ID],EXPECTED_BASELINE): return "partial_3702_beetle_band_changed_whole_baseline"
64: 	var merged: Dictionary=cards[ID].duplicate(true);merged.merge(EFFECTIVE_FIELDS,true)
65: 	if not same(merged,EXPECTED_CURRENT): return "partial_3702_beetle_band_changed_effective_derivation"
66: 	cards[ID]=merged
67: 	return ""
68: 

## Patch3702BloodboundEarrings.apply_overlay
File: core/patch_3702_bloodbound_earrings_sources.gd:61-68
SHA256: 9b0c5addc006180a0c0182dac621f163bf471307690085b96b0c12830a3b703a
Catalog call lines: 11940
Scope: fixed target IDs disjoint from Imperial. Whole-map iteration: none. Whole-map forwarding: none. Explicit Imperial literal in direct file: False
Target constants:
4: const ID: String="BG32_MagicItem_808"
Direct function (all writes, merges and helper calls preserved):
61: static func apply_overlay(cards: Dictionary) -> String:
62: 	# Startup already proved immutable files. No disk reads or normalization here.
63: 	if not cards.has(ID) or not same(cards[ID],EXPECTED_BASELINE): return "partial_3702_bloodbound_earrings_changed_whole_baseline"
64: 	var merged: Dictionary=cards[ID].duplicate(true);merged.merge(EFFECTIVE_FIELDS,true)
65: 	if not same(merged,EXPECTED_CURRENT): return "partial_3702_bloodbound_earrings_changed_effective_derivation"
66: 	cards[ID]=merged
67: 	return ""
68: 

## Patch3702BazaarSticker.apply_overlay
File: core/patch_3702_bazaar_sticker_sources.gd:61-68
SHA256: cf2ed2dc6de20402f66473ab199646a92223dd9b1f02ab081c65818bd0991038
Catalog call lines: 11943
Scope: fixed target IDs disjoint from Imperial. Whole-map iteration: none. Whole-map forwarding: none. Explicit Imperial literal in direct file: False
Target constants:
4: const ID: String="BG32_MagicItem_822"
Direct function (all writes, merges and helper calls preserved):
61: static func apply_overlay(cards: Dictionary) -> String:
62: 	# Startup already proved immutable files. No disk reads or normalization here.
63: 	if not cards.has(ID) or not same(cards[ID],EXPECTED_BASELINE): return "partial_3702_bazaar_sticker_changed_whole_baseline"
64: 	var merged: Dictionary=cards[ID].duplicate(true);merged.merge(EFFECTIVE_FIELDS,true)
65: 	if not same(merged,EXPECTED_CURRENT): return "partial_3702_bazaar_sticker_changed_effective_derivation"
66: 	cards[ID]=merged
67: 	return ""
68: 

## Patch3702Kibble.apply_overlay
File: core/patch_3702_kibble_sources.gd:61-68
SHA256: e920f7ab7f7b802efc69f9f9a2d22f50768c25ac00a4e32f01abf4cd6078b6c9
Catalog call lines: 11946
Scope: fixed target IDs disjoint from Imperial. Whole-map iteration: none. Whole-map forwarding: none. Explicit Imperial literal in direct file: False
Target constants:
4: const ID: String="BG32_MagicItem_200"
Direct function (all writes, merges and helper calls preserved):
61: static func apply_overlay(cards: Dictionary) -> String:
62: 	# Startup already proved immutable files. No disk reads or normalization here.
63: 	if not cards.has(ID) or not same(cards[ID],EXPECTED_BASELINE): return "partial_3702_kibble_changed_whole_baseline"
64: 	var merged: Dictionary=cards[ID].duplicate(true);merged.merge(EFFECTIVE_FIELDS,true)
65: 	if not same(merged,EXPECTED_CURRENT): return "partial_3702_kibble_changed_effective_derivation"
66: 	cards[ID]=merged
67: 	return ""
68: 

## Patch3702SushiRoll.apply_overlay
File: core/patch_3702_sushi_roll_sources.gd:61-68
SHA256: e90e09b1846e736fb7a9ae61e0714f28c514aa235a041bfdba83a9fc0c1257d4
Catalog call lines: 11949
Scope: fixed target IDs disjoint from Imperial. Whole-map iteration: none. Whole-map forwarding: none. Explicit Imperial literal in direct file: False
Target constants:
4: const ID: String="BG30_MagicItem_920"
Direct function (all writes, merges and helper calls preserved):
61: static func apply_overlay(cards: Dictionary) -> String:
62: 	# Startup already proved immutable files. No disk reads or normalization here.
63: 	if not cards.has(ID) or not same(cards[ID],EXPECTED_BASELINE): return "partial_3702_sushi_roll_changed_whole_baseline"
64: 	var merged: Dictionary=cards[ID].duplicate(true);merged.merge(EFFECTIVE_FIELDS,true)
65: 	if not same(merged,EXPECTED_CURRENT): return "partial_3702_sushi_roll_changed_effective_derivation"
66: 	cards[ID]=merged
67: 	return ""
68: 

## Patch3702VibrantBubble.apply_overlay
File: core/patch_3702_vibrant_bubble_sources.gd:61-68
SHA256: 2ceed94d9af3419f46b24407dd9c72f59b29ead2a13f320ed9a2771e51c513e7
Catalog call lines: 11952
Scope: fixed target IDs disjoint from Imperial. Whole-map iteration: none. Whole-map forwarding: none. Explicit Imperial literal in direct file: False
Target constants:
4: const ID: String="BG32_MagicItem_892"
Direct function (all writes, merges and helper calls preserved):
61: static func apply_overlay(cards: Dictionary) -> String:
62: 	# Startup already proved immutable files. No disk reads or normalization here.
63: 	if not cards.has(ID) or not same(cards[ID],EXPECTED_BASELINE): return "partial_3702_vibrant_bubble_changed_whole_baseline"
64: 	var merged: Dictionary=cards[ID].duplicate(true);merged.merge(EFFECTIVE_FIELDS,true)
65: 	if not same(merged,EXPECTED_CURRENT): return "partial_3702_vibrant_bubble_changed_effective_derivation"
66: 	cards[ID]=merged
67: 	return ""
68: 

## Patch3702VibrantBubbleSpell.apply_overlay
File: core/patch_3702_vibrant_bubble_spell_sources.gd:61-68
SHA256: 275ffadd2a82fc3bc989e70869a764a3a697b5a08f5f8b6c1e184a19224be68e
Catalog call lines: 11955
Scope: fixed target IDs disjoint from Imperial. Whole-map iteration: none. Whole-map forwarding: none. Explicit Imperial literal in direct file: False
Target constants:
4: const ID: String="BG32_MagicItem_892t"
Direct function (all writes, merges and helper calls preserved):
61: static func apply_overlay(cards: Dictionary) -> String:
62: 	# Startup already proved immutable files. No disk reads or normalization here.
63: 	if cards.has(ID): return "partial_3702_vibrant_bubble_spell_changed_whole_baseline"
64: 	var merged: Dictionary={};merged.merge(EFFECTIVE_FIELDS,true)
65: 	if not same(merged,EXPECTED_CURRENT): return "partial_3702_vibrant_bubble_spell_changed_effective_derivation"
66: 	cards[ID]=merged
67: 	return ""
68: 

## Patch3702ThaumaturgistPortrait.apply_overlay
File: core/patch_3702_thaumaturgist_portrait_sources.gd:61-68
SHA256: 51ff869327b0ba57f10ded9af5c030ae3aa4f6e9cdb09ec236a82eeac699b53f
Catalog call lines: 11958
Scope: fixed target IDs disjoint from Imperial. Whole-map iteration: none. Whole-map forwarding: none. Explicit Imperial literal in direct file: False
Target constants:
4: const ID: String="BG32_MagicItem_920"
Direct function (all writes, merges and helper calls preserved):
61: static func apply_overlay(cards: Dictionary) -> String:
62: 	# Startup already proved immutable files. No disk reads or normalization here.
63: 	if not cards.has(ID) or not same(cards[ID],EXPECTED_BASELINE): return "partial_3702_thaumaturgist_portrait_changed_whole_baseline"
64: 	var merged: Dictionary=cards[ID].duplicate(true);merged.merge(EFFECTIVE_FIELDS,true)
65: 	if not same(merged,EXPECTED_CURRENT): return "partial_3702_thaumaturgist_portrait_changed_effective_derivation"
66: 	cards[ID]=merged
67: 	return ""
68: 

## Patch3702Wrathguard.apply_overlay
File: core/patch_3702_wrathguard_sources.gd:61-68
SHA256: 3f83d0d18584d144ea120b0b34e33e1dc53510cc5f65595154aa83a5a1bd38a8
Catalog call lines: 11961
Scope: fixed target IDs disjoint from Imperial. Whole-map iteration: none. Whole-map forwarding: none. Explicit Imperial literal in direct file: False
Target constants:
4: const ID: String="BG36_362"
Direct function (all writes, merges and helper calls preserved):
61: static func apply_overlay(cards: Dictionary) -> String:
62: 	# Startup already proved immutable files. No disk reads or normalization here.
63: 	if not cards.has(ID) or not same(cards[ID],EXPECTED_BASELINE): return "partial_3702_wrathguard_changed_whole_baseline"
64: 	var merged: Dictionary=cards[ID].duplicate(true);merged.merge(EFFECTIVE_FIELDS,true)
65: 	if not same(merged,EXPECTED_CURRENT): return "partial_3702_wrathguard_changed_effective_derivation"
66: 	cards[ID]=merged
67: 	return ""
68: 

## Patch3702WrathguardGolden.apply_overlay
File: core/patch_3702_wrathguard_golden_sources.gd:61-68
SHA256: 4ba0e586b89eaf264a517c31e4c4073b475e98023846feb445746c55fde9097a
Catalog call lines: 11964
Scope: fixed target IDs disjoint from Imperial. Whole-map iteration: none. Whole-map forwarding: none. Explicit Imperial literal in direct file: False
Target constants:
4: const ID: String="BG36_362_G"
Direct function (all writes, merges and helper calls preserved):
61: static func apply_overlay(cards: Dictionary) -> String:
62: 	# Startup already proved immutable files. No disk reads or normalization here.
63: 	if not cards.has(ID) or not same(cards[ID],EXPECTED_BASELINE): return "partial_3702_wrathguard_golden_changed_whole_baseline"
64: 	var merged: Dictionary=cards[ID].duplicate(true);merged.merge(EFFECTIVE_FIELDS,true)
65: 	if not same(merged,EXPECTED_CURRENT): return "partial_3702_wrathguard_golden_changed_effective_derivation"
66: 	cards[ID]=merged
67: 	return ""
68: 

## Patch3702TimewarpTheotar.apply_overlay
File: core/patch_3702_timewarp_theotar_sources.gd:61-65
SHA256: d00a0dcfce96f31c2f61cefdc11d90b9263c1a0acf735486d3731d5ac70ee863
Catalog call lines: 11967
Scope: fixed target IDs disjoint from Imperial. Whole-map iteration: none. Whole-map forwarding: none. Explicit Imperial literal in direct file: False
Target constants:
4: const ID: String="BG34_Giant_335"
Direct function (all writes, merges and helper calls preserved):
61: static func apply_overlay(cards: Dictionary) -> String:
62: 	if cards.has(ID): return "timewarp_theotar_unexpected_existing_source"
63: 	cards[ID]=EXPECTED_CURRENT.duplicate(true)
64: 	return ""
65: 

## Patch3702TimewarpTheotarGolden.apply_overlay
File: core/patch_3702_timewarp_theotar_golden_sources.gd:61-65
SHA256: 456567c0f4294748eb87bf754b2de54be72ba8f255e51a1788b9ec7f1698ba7a
Catalog call lines: 11970
Scope: fixed target IDs disjoint from Imperial. Whole-map iteration: none. Whole-map forwarding: none. Explicit Imperial literal in direct file: False
Target constants:
4: const ID: String="BG34_Giant_335_G"
Direct function (all writes, merges and helper calls preserved):
61: static func apply_overlay(cards: Dictionary) -> String:
62: 	if cards.has(ID): return "timewarp_theotar_golden_unexpected_existing_source"
63: 	cards[ID]=EXPECTED_CURRENT.duplicate(true)
64: 	return ""
65: 

## Patch3702TimewarpElectron.apply_overlay
File: core/patch_3702_timewarp_electron_sources.gd:61-68
SHA256: b0187b4952ed7ac3948db6d60949e7c1fe7c99abf3b55b2577581beb4022a5d2
Catalog call lines: 11973
Scope: fixed target IDs disjoint from Imperial. Whole-map iteration: none. Whole-map forwarding: none. Explicit Imperial literal in direct file: False
Target constants:
4: const ID: String="BG34_Giant_610"
Direct function (all writes, merges and helper calls preserved):
61: static func apply_overlay(cards: Dictionary) -> String:
62: 	# Startup already proved immutable files. No disk reads or normalization here.
63: 	if not cards.has(ID) or not same(cards[ID],EXPECTED_BASELINE): return "partial_3702_timewarp_electron_changed_whole_baseline"
64: 	var merged: Dictionary=cards[ID].duplicate(true);merged.merge(EFFECTIVE_FIELDS,true)
65: 	if not same(merged,EXPECTED_CURRENT): return "partial_3702_timewarp_electron_changed_effective_derivation"
66: 	cards[ID]=merged
67: 	return ""
68: 

## Patch3702TimewarpElectronGolden.apply_overlay
File: core/patch_3702_timewarp_electron_golden_sources.gd:61-68
SHA256: a4b5bcdb049f530265d91afd215b2e589e3bb586ca705533747858d1cd6706e2
Catalog call lines: 11976
Scope: fixed target IDs disjoint from Imperial. Whole-map iteration: none. Whole-map forwarding: none. Explicit Imperial literal in direct file: False
Target constants:
4: const ID: String="BG34_Giant_610_G"
Direct function (all writes, merges and helper calls preserved):
61: static func apply_overlay(cards: Dictionary) -> String:
62: 	# Startup already proved immutable files. No disk reads or normalization here.
63: 	if not cards.has(ID) or not same(cards[ID],EXPECTED_BASELINE): return "partial_3702_timewarp_electron_golden_changed_whole_baseline"
64: 	var merged: Dictionary=cards[ID].duplicate(true);merged.merge(EFFECTIVE_FIELDS,true)
65: 	if not same(merged,EXPECTED_CURRENT): return "partial_3702_timewarp_electron_golden_changed_effective_derivation"
66: 	cards[ID]=merged
67: 	return ""
68: 

## Patch3702TimewarpAmalgam.apply_overlay
File: core/patch_3702_timewarp_amalgam_sources.gd:61-65
SHA256: e5858e6094af3774d3accc2f9e81c5facc6a878d676bd6160225f31fb0d7f3bd
Catalog call lines: 11979
Scope: fixed target IDs disjoint from Imperial. Whole-map iteration: none. Whole-map forwarding: none. Explicit Imperial literal in direct file: False
Target constants:
4: const ID: String="BG34_Giant_336"
Direct function (all writes, merges and helper calls preserved):
61: static func apply_overlay(cards: Dictionary) -> String:
62: 	if cards.has(ID): return "timewarp_amalgam_unexpected_existing_source"
63: 	cards[ID]=EXPECTED_CURRENT.duplicate(true)
64: 	return ""
65: 

## Patch3702TimewarpAmalgamGolden.apply_overlay
File: core/patch_3702_timewarp_amalgam_golden_sources.gd:61-65
SHA256: 006b4ee140ac03dc07bf78d929221619bd9b051f983547227750b94bc78b689f
Catalog call lines: 11982
Scope: fixed target IDs disjoint from Imperial. Whole-map iteration: none. Whole-map forwarding: none. Explicit Imperial literal in direct file: False
Target constants:
4: const ID: String="BG34_Giant_336_G"
Direct function (all writes, merges and helper calls preserved):
61: static func apply_overlay(cards: Dictionary) -> String:
62: 	if cards.has(ID): return "timewarp_amalgam_golden_unexpected_existing_source"
63: 	cards[ID]=EXPECTED_CURRENT.duplicate(true)
64: 	return ""
65: 

## Patch3702TimewarpMythrax.apply_overlay
File: core/patch_3702_timewarp_mythrax_sources.gd:61-65
SHA256: 7ae855289d67f4a61704a37334b630d6f3850e3af2b712c4de57d413c4d2538b
Catalog call lines: 11985
Scope: fixed target IDs disjoint from Imperial. Whole-map iteration: none. Whole-map forwarding: none. Explicit Imperial literal in direct file: False
Target constants:
4: const ID: String="BG34_Giant_684"
Direct function (all writes, merges and helper calls preserved):
61: static func apply_overlay(cards: Dictionary) -> String:
62: 	if cards.has(ID): return "timewarp_mythrax_unexpected_existing_source"
63: 	cards[ID]=EXPECTED_CURRENT.duplicate(true)
64: 	return ""
65: 

## Patch3702TimewarpMythraxGolden.apply_overlay
File: core/patch_3702_timewarp_mythrax_golden_sources.gd:61-65
SHA256: 2c23004014492a72dac54e9bdd26dd982c1f2b209b7881d4c1abe700889ea89e
Catalog call lines: 11988
Scope: fixed target IDs disjoint from Imperial. Whole-map iteration: none. Whole-map forwarding: none. Explicit Imperial literal in direct file: False
Target constants:
4: const ID: String="BG34_Giant_684_G"
Direct function (all writes, merges and helper calls preserved):
61: static func apply_overlay(cards: Dictionary) -> String:
62: 	if cards.has(ID): return "timewarp_mythrax_golden_unexpected_existing_source"
63: 	cards[ID]=EXPECTED_CURRENT.duplicate(true)
64: 	return ""
65: 

## Patch3702TimewarpChimera.apply_overlay
File: core/patch_3702_timewarp_chimera_sources.gd:61-65
SHA256: 6274a2543bb1cebcf3ebf36cebbdc0d532553f52bd68a6e21019ee9ca0073e59
Catalog call lines: 11991
Scope: fixed target IDs disjoint from Imperial. Whole-map iteration: none. Whole-map forwarding: none. Explicit Imperial literal in direct file: False
Target constants:
4: const ID: String="BG34_Giant_679"
Direct function (all writes, merges and helper calls preserved):
61: static func apply_overlay(cards: Dictionary) -> String:
62: 	if cards.has(ID): return "timewarp_chimera_unexpected_existing_source"
63: 	cards[ID]=EXPECTED_CURRENT.duplicate(true)
64: 	return ""
65: 

## Patch3702TimewarpChimeraGolden.apply_overlay
File: core/patch_3702_timewarp_chimera_golden_sources.gd:61-65
SHA256: c61d857de65931f580ab9fdd8092017657c5f01203950195ff421b7a2e794906
Catalog call lines: 11994
Scope: fixed target IDs disjoint from Imperial. Whole-map iteration: none. Whole-map forwarding: none. Explicit Imperial literal in direct file: False
Target constants:
4: const ID: String="BG34_Giant_679_G"
Direct function (all writes, merges and helper calls preserved):
61: static func apply_overlay(cards: Dictionary) -> String:
62: 	if cards.has(ID): return "timewarp_chimera_golden_unexpected_existing_source"
63: 	cards[ID]=EXPECTED_CURRENT.duplicate(true)
64: 	return ""
65: 

## Patch3702TimewarpRodeo.apply_overlay
File: core/patch_3702_timewarp_rodeo_sources.gd:61-65
SHA256: 1c8518f4dff4ed14ea1dbe5ddd90095f7835476d6e8f0b5d4b032c378e6d1cb6
Catalog call lines: 11997
Scope: fixed target IDs disjoint from Imperial. Whole-map iteration: none. Whole-map forwarding: none. Explicit Imperial literal in direct file: False
Target constants:
4: const ID: String="BG34_Giant_670"
Direct function (all writes, merges and helper calls preserved):
61: static func apply_overlay(cards: Dictionary) -> String:
62: 	if cards.has(ID): return "timewarp_rodeo_unexpected_existing_source"
63: 	cards[ID]=EXPECTED_CURRENT.duplicate(true)
64: 	return ""
65: 

## Patch3702TimewarpRodeoGolden.apply_overlay
File: core/patch_3702_timewarp_rodeo_golden_sources.gd:61-65
SHA256: 270a90ad75efda91797bb015a2d7f5c95e3f4ecb3301807a4994d7f2495883af
Catalog call lines: 12000
Scope: fixed target IDs disjoint from Imperial. Whole-map iteration: none. Whole-map forwarding: none. Explicit Imperial literal in direct file: False
Target constants:
4: const ID: String="BG34_Giant_670_G"
Direct function (all writes, merges and helper calls preserved):
61: static func apply_overlay(cards: Dictionary) -> String:
62: 	if cards.has(ID): return "timewarp_rodeo_golden_unexpected_existing_source"
63: 	cards[ID]=EXPECTED_CURRENT.duplicate(true)
64: 	return ""
65: 

## Patch3702Ultraviolet.apply_overlay
File: core/patch_3702_ultraviolet_sources.gd:61-68
SHA256: 2731c706b44eb30c7f821df6ea920d7ea805fa4e05f1b6c30e8620c3cb8f8210
Catalog call lines: 12003
Scope: fixed target IDs disjoint from Imperial. Whole-map iteration: none. Whole-map forwarding: none. Explicit Imperial literal in direct file: False
Target constants:
4: const ID: String="BG31_810"
Direct function (all writes, merges and helper calls preserved):
61: static func apply_overlay(cards: Dictionary) -> String:
62: 	# Startup already proved immutable files. No disk reads or normalization here.
63: 	if not cards.has(ID) or not same(cards[ID],EXPECTED_BASELINE): return "partial_3702_ultraviolet_changed_whole_baseline"
64: 	var merged: Dictionary=cards[ID].duplicate(true);merged.merge(EFFECTIVE_FIELDS,true)
65: 	if not same(merged,EXPECTED_CURRENT): return "partial_3702_ultraviolet_changed_effective_derivation"
66: 	cards[ID]=merged
67: 	return ""
68: 

## Patch3702UltravioletGolden.apply_overlay
File: core/patch_3702_ultraviolet_golden_sources.gd:61-68
SHA256: 2d6d5ecedce96512af215fe5892fdc856276f43fcbf8a9cec43bfdcbe6f4cf7f
Catalog call lines: 12006
Scope: fixed target IDs disjoint from Imperial. Whole-map iteration: none. Whole-map forwarding: none. Explicit Imperial literal in direct file: False
Target constants:
4: const ID: String="BG31_810_G"
Direct function (all writes, merges and helper calls preserved):
61: static func apply_overlay(cards: Dictionary) -> String:
62: 	# Startup already proved immutable files. No disk reads or normalization here.
63: 	if not cards.has(ID) or not same(cards[ID],EXPECTED_BASELINE): return "partial_3702_ultraviolet_golden_changed_whole_baseline"
64: 	var merged: Dictionary=cards[ID].duplicate(true);merged.merge(EFFECTIVE_FIELDS,true)
65: 	if not same(merged,EXPECTED_CURRENT): return "partial_3702_ultraviolet_golden_changed_effective_derivation"
66: 	cards[ID]=merged
67: 	return ""
68: 

## Patch3702Hooktusk.apply_overlay
File: core/patch_3702_hooktusk_sources.gd:61-68
SHA256: 64009c2dda5325a548bc1962ac876ace358c08f5b3c9b93d72e3e317129156d0
Catalog call lines: 12009
Scope: fixed target IDs disjoint from Imperial. Whole-map iteration: none. Whole-map forwarding: none. Explicit Imperial literal in direct file: False
Target constants:
4: const ID: String="BG36_344"
Direct function (all writes, merges and helper calls preserved):
61: static func apply_overlay(cards: Dictionary) -> String:
62: 	# Startup already proved immutable files. No disk reads or normalization here.
63: 	if not cards.has(ID) or not same(cards[ID],EXPECTED_BASELINE): return "partial_3702_hooktusk_changed_whole_baseline"
64: 	var merged: Dictionary=cards[ID].duplicate(true);merged.merge(EFFECTIVE_FIELDS,true)
65: 	if not same(merged,EXPECTED_CURRENT): return "partial_3702_hooktusk_changed_effective_derivation"
66: 	cards[ID]=merged
67: 	return ""
68: 

## Patch3702HooktuskGolden.apply_overlay
File: core/patch_3702_hooktusk_golden_sources.gd:61-68
SHA256: 160369fcf4af353af3426e5acb1d29f83ddf1dcf96670a0e92a6935ff611f9fc
Catalog call lines: 12012
Scope: fixed target IDs disjoint from Imperial. Whole-map iteration: none. Whole-map forwarding: none. Explicit Imperial literal in direct file: False
Target constants:
4: const ID: String="BG36_344_G"
Direct function (all writes, merges and helper calls preserved):
61: static func apply_overlay(cards: Dictionary) -> String:
62: 	# Startup already proved immutable files. No disk reads or normalization here.
63: 	if not cards.has(ID) or not same(cards[ID],EXPECTED_BASELINE): return "partial_3702_hooktusk_golden_changed_whole_baseline"
64: 	var merged: Dictionary=cards[ID].duplicate(true);merged.merge(EFFECTIVE_FIELDS,true)
65: 	if not same(merged,EXPECTED_CURRENT): return "partial_3702_hooktusk_golden_changed_effective_derivation"
66: 	cards[ID]=merged
67: 	return ""
68: 

## Patch3702FireBaller.apply_overlay
File: core/patch_3702_fire_baller_sources.gd:61-68
SHA256: 96f80161b87718ff06eb1d23c3489f5387bd0da7acd59e322e7346084879a0ff
Catalog call lines: 12015
Scope: fixed target IDs disjoint from Imperial. Whole-map iteration: none. Whole-map forwarding: none. Explicit Imperial literal in direct file: False
Target constants:
4: const ID: String="BG31_816"
Direct function (all writes, merges and helper calls preserved):
61: static func apply_overlay(cards: Dictionary) -> String:
62: 	# Startup already proved immutable files. No disk reads or normalization here.
63: 	if not cards.has(ID) or not same(cards[ID],EXPECTED_BASELINE): return "partial_3702_fire_baller_changed_whole_baseline"
64: 	var merged: Dictionary=cards[ID].duplicate(true);merged.merge(EFFECTIVE_FIELDS,true)
65: 	if not same(merged,EXPECTED_CURRENT): return "partial_3702_fire_baller_changed_effective_derivation"
66: 	cards[ID]=merged
67: 	return ""
68: 

## Patch3702FireBallerGolden.apply_overlay
File: core/patch_3702_fire_baller_golden_sources.gd:61-68
SHA256: afc91888aad5ea8d1cfa1aee7b52b12543ae521f60a190c2590ff8a423204275
Catalog call lines: 12018
Scope: fixed target IDs disjoint from Imperial. Whole-map iteration: none. Whole-map forwarding: none. Explicit Imperial literal in direct file: False
Target constants:
4: const ID: String="BG31_816_G"
Direct function (all writes, merges and helper calls preserved):
61: static func apply_overlay(cards: Dictionary) -> String:
62: 	# Startup already proved immutable files. No disk reads or normalization here.
63: 	if not cards.has(ID) or not same(cards[ID],EXPECTED_BASELINE): return "partial_3702_fire_baller_golden_changed_whole_baseline"
64: 	var merged: Dictionary=cards[ID].duplicate(true);merged.merge(EFFECTIVE_FIELDS,true)
65: 	if not same(merged,EXPECTED_CURRENT): return "partial_3702_fire_baller_golden_changed_effective_derivation"
66: 	cards[ID]=merged
67: 	return ""
68: 

## Patch3702SnowBaller.apply_overlay
File: core/patch_3702_snow_baller_sources.gd:61-68
SHA256: c991f24b3bca6dab79f11849d134fff450ce8813fcf03909b112e66ed8485eab
Catalog call lines: 12021
Scope: fixed target IDs disjoint from Imperial. Whole-map iteration: none. Whole-map forwarding: none. Explicit Imperial literal in direct file: False
Target constants:
4: const ID: String="BG31_818"
Direct function (all writes, merges and helper calls preserved):
61: static func apply_overlay(cards: Dictionary) -> String:
62: 	# Startup already proved immutable files. No disk reads or normalization here.
63: 	if not cards.has(ID) or not same(cards[ID],EXPECTED_BASELINE): return "partial_3702_snow_baller_changed_whole_baseline"
64: 	var merged: Dictionary=cards[ID].duplicate(true);merged.merge(EFFECTIVE_FIELDS,true)
65: 	if not same(merged,EXPECTED_CURRENT): return "partial_3702_snow_baller_changed_effective_derivation"
66: 	cards[ID]=merged
67: 	return ""
68: 

## Patch3702SnowBallerGolden.apply_overlay
File: core/patch_3702_snow_baller_golden_sources.gd:61-68
SHA256: 613deab49037eb194fd35a6e43f3067ef5690aa3adc58b1ae0ccfd7302000457
Catalog call lines: 12024
Scope: fixed target IDs disjoint from Imperial. Whole-map iteration: none. Whole-map forwarding: none. Explicit Imperial literal in direct file: False
Target constants:
4: const ID: String="BG31_818_G"
Direct function (all writes, merges and helper calls preserved):
61: static func apply_overlay(cards: Dictionary) -> String:
62: 	# Startup already proved immutable files. No disk reads or normalization here.
63: 	if not cards.has(ID) or not same(cards[ID],EXPECTED_BASELINE): return "partial_3702_snow_baller_golden_changed_whole_baseline"
64: 	var merged: Dictionary=cards[ID].duplicate(true);merged.merge(EFFECTIVE_FIELDS,true)
65: 	if not same(merged,EXPECTED_CURRENT): return "partial_3702_snow_baller_golden_changed_effective_derivation"
66: 	cards[ID]=merged
67: 	return ""
68: 

## Patch3702TemperatureShift.apply_overlay
File: core/patch_3702_temperature_shift_sources.gd:61-68
SHA256: ebb5fe05338b3244e858314cdd23510a0d538ff23a68bc81f17794379b24d660
Catalog call lines: 12027
Scope: fixed target IDs disjoint from Imperial. Whole-map iteration: none. Whole-map forwarding: none. Explicit Imperial literal in direct file: False
Target constants:
4: const ID: String="BG31_819"
Direct function (all writes, merges and helper calls preserved):
61: static func apply_overlay(cards: Dictionary) -> String:
62: 	# Startup already proved immutable files. No disk reads or normalization here.
63: 	if not cards.has(ID) or not same(cards[ID],EXPECTED_BASELINE): return "partial_3702_temperature_shift_changed_whole_baseline"
64: 	var merged: Dictionary=cards[ID].duplicate(true);merged.merge(EFFECTIVE_FIELDS,true)
65: 	if not same(merged,EXPECTED_CURRENT): return "partial_3702_temperature_shift_changed_effective_derivation"
66: 	cards[ID]=merged
67: 	return ""
68: 

## Patch3702AirBaller.apply_overlay
File: core/patch_3702_air_baller_sources.gd:61-68
SHA256: eed5984c9446ad40f8794397cffcad78af7e68efa519c673fe5df1056983e788
Catalog call lines: 12030
Scope: fixed target IDs disjoint from Imperial. Whole-map iteration: none. Whole-map forwarding: none. Explicit Imperial literal in direct file: False
Target constants:
4: const ID: String="BG36_181"
Direct function (all writes, merges and helper calls preserved):
61: static func apply_overlay(cards: Dictionary) -> String:
62: 	# Startup already proved immutable files. No disk reads or normalization here.
63: 	if not cards.has(ID) or not same(cards[ID],EXPECTED_BASELINE): return "partial_3702_air_baller_changed_whole_baseline"
64: 	var merged: Dictionary=cards[ID].duplicate(true);merged.merge(EFFECTIVE_FIELDS,true)
65: 	if not same(merged,EXPECTED_CURRENT): return "partial_3702_air_baller_changed_effective_derivation"
66: 	cards[ID]=merged
67: 	return ""
68: 

## Patch3702AirBallerGolden.apply_overlay
File: core/patch_3702_air_baller_golden_sources.gd:61-68
SHA256: 5f1e6a7deb4612a85166e36ddfd4dab926727af3b794a847dad43fc42add5a57
Catalog call lines: 12033
Scope: fixed target IDs disjoint from Imperial. Whole-map iteration: none. Whole-map forwarding: none. Explicit Imperial literal in direct file: False
Target constants:
4: const ID: String="BG36_181_G"
Direct function (all writes, merges and helper calls preserved):
61: static func apply_overlay(cards: Dictionary) -> String:
62: 	# Startup already proved immutable files. No disk reads or normalization here.
63: 	if not cards.has(ID) or not same(cards[ID],EXPECTED_BASELINE): return "partial_3702_air_baller_golden_changed_whole_baseline"
64: 	var merged: Dictionary=cards[ID].duplicate(true);merged.merge(EFFECTIVE_FIELDS,true)
65: 	if not same(merged,EXPECTED_CURRENT): return "partial_3702_air_baller_golden_changed_effective_derivation"
66: 	cards[ID]=merged
67: 	return ""
68: 

## Patch3702TimewarpPainter.apply_overlay
File: core/patch_3702_timewarp_painter_sources.gd:61-68
SHA256: 60e1c7f8e03a65757e731cf9f6a471caf1d3308cc37b45a45cd19131bd4ca882
Catalog call lines: 12036
Scope: fixed target IDs disjoint from Imperial. Whole-map iteration: none. Whole-map forwarding: none. Explicit Imperial literal in direct file: False
Target constants:
4: const ID: String="BG34_Giant_319"
Direct function (all writes, merges and helper calls preserved):
61: static func apply_overlay(cards: Dictionary) -> String:
62: 	# Startup already proved immutable files. No disk reads or normalization here.
63: 	if not cards.has(ID) or not same(cards[ID],EXPECTED_BASELINE): return "partial_3702_timewarp_painter_changed_whole_baseline"
64: 	var merged: Dictionary=cards[ID].duplicate(true);merged.merge(EFFECTIVE_FIELDS,true)
65: 	if not same(merged,EXPECTED_CURRENT): return "partial_3702_timewarp_painter_changed_effective_derivation"
66: 	cards[ID]=merged
67: 	return ""
68: 

## Patch3702TimewarpPainterGolden.apply_overlay
File: core/patch_3702_timewarp_painter_golden_sources.gd:61-68
SHA256: b9abf785d3dd476493c46247f3e9a06e97f1f2bc0e020ba80c28083b8b70924e
Catalog call lines: 12039
Scope: fixed target IDs disjoint from Imperial. Whole-map iteration: none. Whole-map forwarding: none. Explicit Imperial literal in direct file: False
Target constants:
4: const ID: String="BG34_Giant_319_G"
Direct function (all writes, merges and helper calls preserved):
61: static func apply_overlay(cards: Dictionary) -> String:
62: 	# Startup already proved immutable files. No disk reads or normalization here.
63: 	if not cards.has(ID) or not same(cards[ID],EXPECTED_BASELINE): return "partial_3702_timewarp_painter_golden_changed_whole_baseline"
64: 	var merged: Dictionary=cards[ID].duplicate(true);merged.merge(EFFECTIVE_FIELDS,true)
65: 	if not same(merged,EXPECTED_CURRENT): return "partial_3702_timewarp_painter_golden_changed_effective_derivation"
66: 	cards[ID]=merged
67: 	return ""
68: 

## Patch3702TimewarpMurky.apply_overlay
File: core/patch_3702_timewarp_murky_sources.gd:61-68
SHA256: 9674099e6f6a305c724fa720c33ac4712060c8a04b9ca698ab622fe6897e9aa8
Catalog call lines: 12042
Scope: fixed target IDs disjoint from Imperial. Whole-map iteration: none. Whole-map forwarding: none. Explicit Imperial literal in direct file: False
Target constants:
4: const ID: String="BG34_Giant_206"
Direct function (all writes, merges and helper calls preserved):
61: static func apply_overlay(cards: Dictionary) -> String:
62: 	# Startup already proved immutable files. No disk reads or normalization here.
63: 	if not cards.has(ID) or not same(cards[ID],EXPECTED_BASELINE): return "partial_3702_timewarp_murky_changed_whole_baseline"
64: 	var merged: Dictionary=cards[ID].duplicate(true);merged.merge(EFFECTIVE_FIELDS,true)
65: 	if not same(merged,EXPECTED_CURRENT): return "partial_3702_timewarp_murky_changed_effective_derivation"
66: 	cards[ID]=merged
67: 	return ""
68: 

## Patch3702TimewarpMurkyGolden.apply_overlay
File: core/patch_3702_timewarp_murky_golden_sources.gd:61-68
SHA256: c124314239668aa94a81177fd48a77ebcdad166e2e42c24fb6b589e1dd6dcca0
Catalog call lines: 12045
Scope: fixed target IDs disjoint from Imperial. Whole-map iteration: none. Whole-map forwarding: none. Explicit Imperial literal in direct file: False
Target constants:
4: const ID: String="BG34_Giant_206_G"
Direct function (all writes, merges and helper calls preserved):
61: static func apply_overlay(cards: Dictionary) -> String:
62: 	# Startup already proved immutable files. No disk reads or normalization here.
63: 	if not cards.has(ID) or not same(cards[ID],EXPECTED_BASELINE): return "partial_3702_timewarp_murky_golden_changed_whole_baseline"
64: 	var merged: Dictionary=cards[ID].duplicate(true);merged.merge(EFFECTIVE_FIELDS,true)
65: 	if not same(merged,EXPECTED_CURRENT): return "partial_3702_timewarp_murky_golden_changed_effective_derivation"
66: 	cards[ID]=merged
67: 	return ""
68: 

## Patch3702TimewarpMolten.apply_overlay
File: core/patch_3702_timewarp_molten_sources.gd:61-68
SHA256: 9a91545b6be55af3acaf539a97dc75e4877c9b6288af31b85e5a3d7a2e99bd22
Catalog call lines: 12048
Scope: fixed target IDs disjoint from Imperial. Whole-map iteration: none. Whole-map forwarding: none. Explicit Imperial literal in direct file: False
Target constants:
4: const ID: String="BG34_Giant_006"
Direct function (all writes, merges and helper calls preserved):
61: static func apply_overlay(cards: Dictionary) -> String:
62: 	# Startup already proved immutable files. No disk reads or normalization here.
63: 	if not cards.has(ID) or not same(cards[ID],EXPECTED_BASELINE): return "partial_3702_timewarp_molten_changed_whole_baseline"
64: 	var merged: Dictionary=cards[ID].duplicate(true);merged.merge(EFFECTIVE_FIELDS,true)
65: 	if not same(merged,EXPECTED_CURRENT): return "partial_3702_timewarp_molten_changed_effective_derivation"
66: 	cards[ID]=merged
67: 	return ""
68: 

## Patch3702TimewarpMoltenGolden.apply_overlay
File: core/patch_3702_timewarp_molten_golden_sources.gd:61-68
SHA256: 7c4ef7cd554a82bf7c4d9c4e9c77df82bfbb501d07066181d62341cd42fdda92
Catalog call lines: 12051
Scope: fixed target IDs disjoint from Imperial. Whole-map iteration: none. Whole-map forwarding: none. Explicit Imperial literal in direct file: False
Target constants:
4: const ID: String="BG34_Giant_006_G"
Direct function (all writes, merges and helper calls preserved):
61: static func apply_overlay(cards: Dictionary) -> String:
62: 	# Startup already proved immutable files. No disk reads or normalization here.
63: 	if not cards.has(ID) or not same(cards[ID],EXPECTED_BASELINE): return "partial_3702_timewarp_molten_golden_changed_whole_baseline"
64: 	var merged: Dictionary=cards[ID].duplicate(true);merged.merge(EFFECTIVE_FIELDS,true)
65: 	if not same(merged,EXPECTED_CURRENT): return "partial_3702_timewarp_molten_golden_changed_effective_derivation"
66: 	cards[ID]=merged
67: 	return ""
68: 

## Patch3702SparkSnapper.apply_overlay
File: core/patch_3702_spark_snapper_sources.gd:61-68
SHA256: 5dd0b83fdb06ffde8f1a0c59744272701b093bf00cafeaf39e52cd10bb6dc646
Catalog call lines: 12054
Scope: fixed target IDs disjoint from Imperial. Whole-map iteration: none. Whole-map forwarding: none. Explicit Imperial literal in direct file: False
Target constants:
4: const ID: String="BG36_851"
Direct function (all writes, merges and helper calls preserved):
61: static func apply_overlay(cards: Dictionary) -> String:
62: 	# Startup already proved immutable files. No disk reads or normalization here.
63: 	if not cards.has(ID) or not same(cards[ID],EXPECTED_BASELINE): return "partial_3702_spark_snapper_changed_whole_baseline"
64: 	var merged: Dictionary=cards[ID].duplicate(true);merged.merge(EFFECTIVE_FIELDS,true)
65: 	if not same(merged,EXPECTED_CURRENT): return "partial_3702_spark_snapper_changed_effective_derivation"
66: 	cards[ID]=merged
67: 	return ""
68: 

## Patch3702SparkSnapperGolden.apply_overlay
File: core/patch_3702_spark_snapper_golden_sources.gd:61-68
SHA256: c370d8facce27a6a4d5c5ade45a469802fdb3450e52f1c40177819d146277732
Catalog call lines: 12057
Scope: fixed target IDs disjoint from Imperial. Whole-map iteration: none. Whole-map forwarding: none. Explicit Imperial literal in direct file: False
Target constants:
4: const ID: String="BG36_851_G"
Direct function (all writes, merges and helper calls preserved):
61: static func apply_overlay(cards: Dictionary) -> String:
62: 	# Startup already proved immutable files. No disk reads or normalization here.
63: 	if not cards.has(ID) or not same(cards[ID],EXPECTED_BASELINE): return "partial_3702_spark_snapper_golden_changed_whole_baseline"
64: 	var merged: Dictionary=cards[ID].duplicate(true);merged.merge(EFFECTIVE_FIELDS,true)
65: 	if not same(merged,EXPECTED_CURRENT): return "partial_3702_spark_snapper_golden_changed_effective_derivation"
66: 	cards[ID]=merged
67: 	return ""
68: 

## Patch3702TimewarpRedWhelp.apply_overlay
File: core/patch_3702_timewarp_red_whelp_sources.gd:61-68
SHA256: 0545f49bf6ed1d16e1506bd95f4afd56b2ba695c32e3eaa40d90750db3597918
Catalog call lines: 12060
Scope: fixed target IDs disjoint from Imperial. Whole-map iteration: none. Whole-map forwarding: none. Explicit Imperial literal in direct file: False
Target constants:
4: const ID: String="BG34_Giant_091"
Direct function (all writes, merges and helper calls preserved):
61: static func apply_overlay(cards: Dictionary) -> String:
62: 	# Startup already proved immutable files. No disk reads or normalization here.
63: 	if not cards.has(ID) or not same(cards[ID],EXPECTED_BASELINE): return "partial_3702_timewarp_red_whelp_changed_whole_baseline"
64: 	var merged: Dictionary=cards[ID].duplicate(true);merged.merge(EFFECTIVE_FIELDS,true)
65: 	if not same(merged,EXPECTED_CURRENT): return "partial_3702_timewarp_red_whelp_changed_effective_derivation"
66: 	cards[ID]=merged
67: 	return ""
68: 

## Patch3702TimewarpScout.apply_overlay
File: core/patch_3702_timewarp_scout_sources.gd:61-68
SHA256: e6d7beacdee9c21e54badbd4138302bb04ffebe36d21ebeda400819da176c142
Catalog call lines: 12063
Scope: fixed target IDs disjoint from Imperial. Whole-map iteration: none. Whole-map forwarding: none. Explicit Imperial literal in direct file: False
Target constants:
4: const ID: String="BG34_Giant_333"
Direct function (all writes, merges and helper calls preserved):
61: static func apply_overlay(cards: Dictionary) -> String:
62: 	# Startup already proved immutable files. No disk reads or normalization here.
63: 	if not cards.has(ID) or not same(cards[ID],EXPECTED_BASELINE): return "partial_3702_timewarp_scout_changed_whole_baseline"
64: 	var merged: Dictionary=cards[ID].duplicate(true);merged.merge(EFFECTIVE_FIELDS,true)
65: 	if not same(merged,EXPECTED_CURRENT): return "partial_3702_timewarp_scout_changed_effective_derivation"
66: 	cards[ID]=merged
67: 	return ""
68: 

## Patch3702TimewarpScoutGolden.apply_overlay
File: core/patch_3702_timewarp_scout_golden_sources.gd:61-68
SHA256: 3dd00f69180232cac349de5a9a23c78d812b494b40002e1a022afbeb7108a781
Catalog call lines: 12066
Scope: fixed target IDs disjoint from Imperial. Whole-map iteration: none. Whole-map forwarding: none. Explicit Imperial literal in direct file: False
Target constants:
4: const ID: String="BG34_Giant_333_G"
Direct function (all writes, merges and helper calls preserved):
61: static func apply_overlay(cards: Dictionary) -> String:
62: 	# Startup already proved immutable files. No disk reads or normalization here.
63: 	if not cards.has(ID) or not same(cards[ID],EXPECTED_BASELINE): return "partial_3702_timewarp_scout_golden_changed_whole_baseline"
64: 	var merged: Dictionary=cards[ID].duplicate(true);merged.merge(EFFECTIVE_FIELDS,true)
65: 	if not same(merged,EXPECTED_CURRENT): return "partial_3702_timewarp_scout_golden_changed_effective_derivation"
66: 	cards[ID]=merged
67: 	return ""
68: 

## Patch3702TimewarpSwirler.apply_overlay
File: core/patch_3702_timewarp_swirler_sources.gd:61-68
SHA256: edd5bd7d422ad78e2cd3ced58fcf44a364de8147e3739540c0adc90358eeed6b
Catalog call lines: 12069
Scope: fixed target IDs disjoint from Imperial. Whole-map iteration: none. Whole-map forwarding: none. Explicit Imperial literal in direct file: False
Target constants:
4: const ID: String="BG34_Giant_686"
Direct function (all writes, merges and helper calls preserved):
61: static func apply_overlay(cards: Dictionary) -> String:
62: 	# Startup already proved immutable files. No disk reads or normalization here.
63: 	if not cards.has(ID) or not same(cards[ID],EXPECTED_BASELINE): return "partial_3702_timewarp_swirler_changed_whole_baseline"
64: 	var merged: Dictionary=cards[ID].duplicate(true);merged.merge(EFFECTIVE_FIELDS,true)
65: 	if not same(merged,EXPECTED_CURRENT): return "partial_3702_timewarp_swirler_changed_effective_derivation"
66: 	cards[ID]=merged
67: 	return ""
68: 

## Patch3702TimewarpSwirlerGolden.apply_overlay
File: core/patch_3702_timewarp_swirler_golden_sources.gd:61-68
SHA256: c80a66778caab971b4ffed38324eebbfc6e9a18987bf0c34ba4c490013b50b65
Catalog call lines: 12072
Scope: fixed target IDs disjoint from Imperial. Whole-map iteration: none. Whole-map forwarding: none. Explicit Imperial literal in direct file: False
Target constants:
4: const ID: String="BG34_Giant_686_G"
Direct function (all writes, merges and helper calls preserved):
61: static func apply_overlay(cards: Dictionary) -> String:
62: 	# Startup already proved immutable files. No disk reads or normalization here.
63: 	if not cards.has(ID) or not same(cards[ID],EXPECTED_BASELINE): return "partial_3702_timewarp_swirler_golden_changed_whole_baseline"
64: 	var merged: Dictionary=cards[ID].duplicate(true);merged.merge(EFFECTIVE_FIELDS,true)
65: 	if not same(merged,EXPECTED_CURRENT): return "partial_3702_timewarp_swirler_golden_changed_effective_derivation"
66: 	cards[ID]=merged
67: 	return ""
68: 

## Patch3702CursedCrystal.apply_overlay
File: core/patch_3702_cursed_crystal_sources.gd:61-68
SHA256: 2dd6bb9fe6c883562f360e4ba99b1555df8fc27c865696d375263457c0493ff7
Catalog call lines: 12075
Scope: fixed target IDs disjoint from Imperial. Whole-map iteration: none. Whole-map forwarding: none. Explicit Imperial literal in direct file: False
Target constants:
4: const ID: String="BG35_MagicItem_150"
Direct function (all writes, merges and helper calls preserved):
61: static func apply_overlay(cards: Dictionary) -> String:
62: 	# Startup already proved immutable files. No disk reads or normalization here.
63: 	if not cards.has(ID) or not same(cards[ID],EXPECTED_BASELINE): return "partial_3702_cursed_crystal_changed_whole_baseline"
64: 	var merged: Dictionary=cards[ID].duplicate(true);merged.merge(EFFECTIVE_FIELDS,true)
65: 	if not same(merged,EXPECTED_CURRENT): return "partial_3702_cursed_crystal_changed_effective_derivation"
66: 	cards[ID]=merged
67: 	return ""
68: 

## Patch3702MiniatureShip.apply_overlay
File: core/patch_3702_miniature_ship_sources.gd:84-95
SHA256: 2f03e48da138628f64568369a74087d76b418042f42111e088129b803eef03fa
Catalog call lines: 12078
Scope: fixed target IDs disjoint from Imperial. Whole-map iteration: none. Whole-map forwarding: none. Explicit Imperial literal in direct file: False
Target constants:
4: const ID: String="BG35_MagicItem_710"
Direct function (all writes, merges and helper calls preserved):
84: static func apply_overlay(miniature_ship_cards: Dictionary) -> String:
85: 	var startup_issue: String=proof_error()
86: 	if not startup_issue.is_empty(): return startup_issue
87: 	var miniature_ship_row: Dictionary=packet()
88: 	if miniature_ship_row.is_empty(): return "partial_3702_miniature_ship_missing_or_changed_packet"
89: 	if not miniature_ship_cards.has(ID) or not same(miniature_ship_cards[ID],miniature_ship_row.expected_baseline): return "partial_3702_miniature_ship_changed_whole_baseline"
90: 	var miniature_ship_merged: Dictionary=miniature_ship_cards[ID].duplicate(true)
91: 	miniature_ship_merged.merge(miniature_ship_row.effective_fields,true)
92: 	if str(miniature_ship_merged.text).sha256_text()!=miniature_ship_merged.coverage_text_sha256: return "partial_3702_miniature_ship_changed_text_digest"
93: 	miniature_ship_cards[ID]=miniature_ship_merged
94: 	return ""
95: 

## Patch3702GreaterPhrasebook.apply_overlay
File: core/patch_3702_greater_phrasebook_sources.gd:73-82
SHA256: 2898042a569368b6b811137afe7394edc17dee899e2e70dd64d87a6ad11ed035
Catalog call lines: 12081
Scope: fixed target IDs disjoint from Imperial. Whole-map iteration: none. Whole-map forwarding: none. Explicit Imperial literal in direct file: False
Target constants:
4: const ID: String="BG30_MagicItem_914t"
Direct function (all writes, merges and helper calls preserved):
73: static func apply_overlay(greater_phrasebook_cards: Dictionary) -> String:
74: 	var greater_phrasebook_row: Dictionary=packet()
75: 	if greater_phrasebook_row.is_empty(): return "partial_3702_greater_phrasebook_missing_or_changed_packet"
76: 	if not greater_phrasebook_cards.has(ID) or not same(greater_phrasebook_cards[ID],greater_phrasebook_row.expected_baseline): return "partial_3702_greater_phrasebook_changed_whole_baseline"
77: 	var greater_phrasebook_merged: Dictionary=greater_phrasebook_cards[ID].duplicate(true)
78: 	greater_phrasebook_merged.merge(greater_phrasebook_row.effective_fields,true)
79: 	if str(greater_phrasebook_merged.text).sha256_text()!=greater_phrasebook_merged.coverage_text_sha256: return "partial_3702_greater_phrasebook_changed_text_digest"
80: 	greater_phrasebook_cards[ID]=greater_phrasebook_merged
81: 	return ""
82: 

## Patch3702MurlocPhrasebook.apply_overlay
File: core/patch_3702_murloc_phrasebook_sources.gd:73-82
SHA256: 995db21c175cc7316219c28c737c3e48954ff9ffb07a71766f997f229304b5b0
Catalog call lines: 12084
Scope: fixed target IDs disjoint from Imperial. Whole-map iteration: none. Whole-map forwarding: none. Explicit Imperial literal in direct file: False
Target constants:
4: const ID: String="BG30_MagicItem_914"
Direct function (all writes, merges and helper calls preserved):
73: static func apply_overlay(phrasebook_cards: Dictionary) -> String:
74: 	var phrasebook_row: Dictionary=packet()
75: 	if phrasebook_row.is_empty(): return "partial_3702_murloc_phrasebook_missing_or_changed_packet"
76: 	if not phrasebook_cards.has(ID) or not same(phrasebook_cards[ID],phrasebook_row.expected_baseline): return "partial_3702_murloc_phrasebook_changed_whole_baseline"
77: 	var phrasebook_merged: Dictionary=phrasebook_cards[ID].duplicate(true)
78: 	phrasebook_merged.merge(phrasebook_row.effective_fields,true)
79: 	if str(phrasebook_merged.text).sha256_text()!=phrasebook_merged.coverage_text_sha256: return "partial_3702_murloc_phrasebook_changed_text_digest"
80: 	phrasebook_cards[ID]=phrasebook_merged
81: 	return ""
82: 

## Patch3702Azerite.apply_overlay
File: core/patch_3702_azerite_sources.gd:69-81
SHA256: 23fc98988dc1cdb46e1eb4ea3345eed58ffb8783234c1e87ff924c241ca92fd3
Catalog call lines: 12087
Scope: fixed target IDs disjoint from Imperial. Whole-map iteration: none. Whole-map forwarding: none. Explicit Imperial literal in direct file: False
Target constants:
9: const IDS: Array=["BG28_707","BG28_707_G"]
Direct function (all writes, merges and helper calls preserved):
69: static func apply_overlay(cards: Dictionary) -> String:
70: 	var rows: Dictionary=packet()
71: 	if rows.size()!=IDS.size(): return "partial_3702_azerite_missing_or_changed_packet"
72: 	var staged: Dictionary={}
73: 	for id in IDS:
74: 		# Authenticate both complete historical rows before changing either.
75: 		if not cards.has(id) or not same(cards[id],rows[id].expected_baseline): return "partial_3702_azerite_changed_baseline:"+id
76: 		var merged: Dictionary=cards[id].duplicate(true)
77: 		merged.merge(rows[id].effective_fields,true)
78: 		if str(merged.text).sha256_text()!=merged.coverage_text_sha256: return "partial_3702_azerite_changed_text_digest:"+id
79: 		staged[id]=merged
80: 	for id in IDS: cards[id]=staged[id]
81: 	return ""

## Patch3702Twilight.apply_overlay
File: core/patch_3702_twilight_sources.gd:54-66
SHA256: 519c4dbd5ff2f07cdfe09c8f674ed0c1dd27737b7619bcdcb4bf0bbdd9e5baf1
Catalog call lines: 12090
Scope: fixed target IDs disjoint from Imperial. Whole-map iteration: none. Whole-map forwarding: none. Explicit Imperial literal in direct file: False
Target constants:
4: const IDS: Array=["BG36_703","BG36_703_G"]
Direct function (all writes, merges and helper calls preserved):
54: static func apply_overlay(cards: Dictionary) -> String:
55: 	var rows: Dictionary=packet()
56: 	if rows.size()!=IDS.size(): return "partial_3702_twilight_missing_or_changed_packet"
57: 	var staged: Dictionary={}
58: 	for id in IDS:
59: 		# Authenticate both complete historical rows before changing either.
60: 		if not cards.has(id) or not same(cards[id],rows[id].expected_baseline): return "partial_3702_twilight_changed_baseline:"+id
61: 		var merged: Dictionary=cards[id].duplicate(true)
62: 		merged.merge(rows[id].effective_fields,true)
63: 		if str(merged.text).sha256_text()!=merged.coverage_text_sha256: return "partial_3702_twilight_changed_text_digest:"+id
64: 		staged[id]=merged
65: 	for id in IDS: cards[id]=staged[id]
66: 	return ""

## Patch3702Tidecaller.apply_overlay
File: core/patch_3702_tidecaller_sources.gd:54-66
SHA256: 6dd0a3a99eb342a4232befa11bb890c37fcbedc6007a46a261c3b8aa2bb9c5a7
Catalog call lines: 12093
Scope: fixed target IDs disjoint from Imperial. Whole-map iteration: none. Whole-map forwarding: none. Explicit Imperial literal in direct file: False
Target constants:
4: const IDS: Array=["BG36_704","BG36_704_G"]
Direct function (all writes, merges and helper calls preserved):
54: static func apply_overlay(cards: Dictionary) -> String:
55: 	var rows: Dictionary=packet()
56: 	if rows.size()!=IDS.size(): return "partial_3702_tidecaller_missing_or_changed_packet"
57: 	var staged: Dictionary={}
58: 	for id in IDS:
59: 		# Authenticate both complete historical rows before changing either.
60: 		if not cards.has(id) or not same(cards[id],rows[id].expected_baseline): return "partial_3702_tidecaller_changed_baseline:"+id
61: 		var merged: Dictionary=cards[id].duplicate(true)
62: 		merged.merge(rows[id].effective_fields,true)
63: 		if str(merged.text).sha256_text()!=merged.coverage_text_sha256: return "partial_3702_tidecaller_changed_text_digest:"+id
64: 		staged[id]=merged
65: 	for id in IDS: cards[id]=staged[id]
66: 	return ""

## Patch3702Ashen.apply_overlay
File: core/patch_3702_ashen_sources.gd:40-59
SHA256: ac284bd5bc8d5cc6ce46d7301ab01fa4f8f266f668c37aa42f2d4e421861ea5d
Catalog call lines: 12096
Scope: fixed target IDs disjoint from Imperial. Whole-map iteration: none. Whole-map forwarding: none. Explicit Imperial literal in direct file: False
Target constants:
3: const IDS: Array=["BG32_873","BG32_873_G"]
Direct function (all writes, merges and helper calls preserved):
40: static func apply_overlay(cards: Dictionary) -> String:
41: 	var issue: String=proof_error()
42: 	if not issue.is_empty(): return issue
43: 	var data: Dictionary=_packet()
44: 	if data.is_empty(): return "partial_3702_ashen_packet_changed"
45: 	# Authenticate both complete preimages before creating or committing a write.
46: 	for id in IDS:
47: 		if not cards.get(id) is Dictionary or not same(cards[id],data.expected_merged[id]): return "partial_3702_ashen_exact_old_record_changed:"+id
48: 	var prepared: Dictionary={}
49: 	for id in IDS:
50: 		var card: Dictionary=cards[id].duplicate(true)
51: 		var revised: Dictionary=data.effective_fields[id]
52: 		card.attack=int(revised.attack);card.health=int(revised.health)
53: 		card.text=revised.text;card.coverage_text_sha256=revised.coverage_text_sha256
54: 		card.effects=revised.effects.duplicate(true)
55: 		for effect in card.effects:
56: 			effect.attack=int(effect.attack);effect.health=int(effect.health)
57: 		prepared[id]=card
58: 	for id in IDS: cards[id]=prepared[id]
59: 	return ""

## FairmountSources.apply_overlay
File: core/fairmount_eot_sources.gd:22-36
SHA256: 59714f5e3966d471b83fb195cc570d1b619db5198092f284e266dce873fcd364
Catalog call lines: 12099
Scope: fixed target IDs disjoint from Imperial. Whole-map iteration: none. Whole-map forwarding: none. Explicit Imperial literal in direct file: False
Target constants:
3: const IDS=["BG21_HERO_000_Buddy","BG21_HERO_000_Buddy_G"]
Direct function (all writes, merges and helper calls preserved):
22: static func apply_overlay(cards: Dictionary) -> String:
23: 	for id in IDS:
24: 		var card: Dictionary=cards.get(id,{})
25: 		if card.get("card_code")!=id or card.get("effects")!=[] or card.get("supported")!=false: return "fairmount_unexpected_raw_source:"+id
26: 		var next: Dictionary=card.duplicate(true)
27: 		next.effects=program(id);next.supported=true
28: 		next.default_pool=false;next.pool_supported=false
29: 		next.implementation_status="written_unverified"
30: 		next.coverage_rule="fairmount_complete_eot_three_axis_v1"
31: 		next.coverage_text_sha256=str(next.text).sha256_text()
32: 		next.conditional_support={"rule":"fairmount_complete_eot_three_axis_v1","reason":"Complete original-owner EOT normal/golden improvement, all three axes; original complete scheduler and durable receipt. Unknown mixed EOT/lineage and seven-recipient frontier held before mutation. No combat-choice ticket reuse; not validated."}
33: 		var issue: String=source_error(next)
34: 		if not issue.is_empty(): return issue
35: 		cards[id]=next
36: 	return ""

## PressureSources.apply_overlay
File: core/pressure_authorities_sources.gd:12-23
SHA256: 67d8ee319a40c79e5a479b07ff1387d3b050ef7171121de9bd72fa4a5f322333
Catalog call lines: 12101
Scope: fixed target IDs disjoint from Imperial. Whole-map iteration: none. Whole-map forwarding: none. Explicit Imperial literal in direct file: False
Target constants:
3: const ID="BG27_Quest_801"
4: const ALIAS="104661"
Direct function (all writes, merges and helper calls preserved):
12: static func apply_overlay(cards:Dictionary)->String:
13:  if cards.has(ID):return "pressure_unexpected_preexisting_canonical_source"
14:  var card:Dictionary=cards.get(ALIAS,{})
15:  if card.get("id")!=ALIAS or card.get("card_code")!=ALIAS or card.get("name")!="反抗威权" or card.get("text")!=TEXT or card.get("kind")!="quest" or card.get("supported")!=false or card.get("effects")!=[] or card.get("source_conflicts",[])!=[]:return "pressure_changed_original_alias"
16:  var canonical:Dictionary=card.duplicate(true)
17:  canonical.id=ID;canonical.card_code=ID;canonical.dbf_id="104661";canonical.resolved_from_id=ALIAS
18:  canonical.supported=true;canonical.effects=EFFECTS.duplicate(true);canonical.default_pool=false
19:  canonical.implementation_status="written_unverified"
20:  canonical.implementation_evidence="res://research/pressure_authorities_gauge_20261029/IMPLEMENTATION.md"
21:  canonical.conditional_support={"reason":"Actual recruit warband Attack gauge, custom threshold1..100; initial already-met and unbound multi-slot held. Combat admitted only for no-growth original entity domain."}
22:  cards.erase(ALIAS);cards[ID]=canonical
23:  return ""

## SortItAllOut.apply_overlay
File: core/sort_it_all_out_sources.gd:11-20
SHA256: 84b03649048358b4503e633faed5ced42d68454a43681b9e6128098a3593c232
Catalog call lines: 12103
Scope: fixed target IDs disjoint from Imperial. Whole-map iteration: none. Whole-map forwarding: none. Explicit Imperial literal in direct file: False
Target constants:
3: const ID: String="BG24_Quest_125"
Direct function (all writes, merges and helper calls preserved):
11: static func apply_overlay(cards: Dictionary) -> String:
12: 	var card: Dictionary=cards.get(ID,{})
13: 	var issue: String=source_error(card)
14: 	if not issue.is_empty(): return issue
15: 	if card.get("supported")!=false or card.get("effects")!=[] or card.get("source_conflicts",[])!=[] or card.get("latest_validation",{}).get("data_gate",false): return "sort_it_all_out_changed_raw_program"
16: 	card.supported=true;card.effects=EFFECTS.duplicate(true)
17: 	card["implementation_status"]="written_unverified"
18: 	card["implementation_evidence"]="res://research/sort_it_all_out_20261029/IMPLEMENTATION.md"
19: 	card["conditional_support"]={"reason":"Actual pre-start-effects combat formation, at least two distinct Attack values. Equal-Attack/empty/single formations held; no official difficulty inferred."}
20: 	return ""

## WitnessProtection.apply_overlay
File: core/witness_protection_sources.gd:11-19
SHA256: d8cafe0523897ef0855ac758e8d8c1691d9628dab552ba3685006be8699c5d78
Catalog call lines: 12105
Scope: fixed target IDs disjoint from Imperial. Whole-map iteration: none. Whole-map forwarding: none. Explicit Imperial literal in direct file: False
Target constants:
3: const ID: String="BG24_Quest_318"
Direct function (all writes, merges and helper calls preserved):
11: static func apply_overlay(cards: Dictionary) -> String:
12: 	var card: Dictionary=cards.get(ID,{})
13: 	var issue: String=source_error(card)
14: 	if not issue.is_empty(): return issue
15: 	if card.get("supported")!=false or card.get("effects")!=[] or card.get("source_conflicts",[])!=[] or card.get("latest_validation",{}).get("data_gate",false): return "witness_protection_raw_program_changed"
16: 	card.supported=true;card.effects=EFFECTS.duplicate(true)
17: 	card["implementation_status"]="written_unverified"
18: 	card["implementation_evidence"]="res://research/witness_protection_20261029/IMPLEMENTATION.md"
19: 	return ""

## ExhumeBones.apply_overlay
File: core/exhume_bones_sources.gd:12-20
SHA256: d6429823495efd6da85bb512bfdcef4ecad9971eb0a2874037d463554a6c865a
Catalog call lines: 12107
Scope: fixed target IDs disjoint from Imperial. Whole-map iteration: none. Whole-map forwarding: none. Explicit Imperial literal in direct file: False
Target constants:
2: const ID="BG24_Quest_320"
Direct function (all writes, merges and helper calls preserved):
12: static func apply_overlay(cards: Dictionary) -> String:
13: 	var card: Dictionary=cards.get(ID,{})
14: 	var issue: String=source_error(card)
15: 	if not issue.is_empty(): return issue
16: 	if card.get("supported")!=false or card.get("effects")!=[] or card.get("source_conflicts",[])!=[] or card.get("latest_validation",{}).get("data_gate",false): return "exhume_bones_raw_program_changed"
17: 	card.supported=true;card.effects=EFFECTS.duplicate(true)
18: 	card["implementation_status"]="written_unverified"
19: 	card["implementation_evidence"]="res://research/exhume_bones_20261029/IMPLEMENTATION.md"
20: 	return ""

## DustPrints.apply_overlay
File: core/dust_prints_sources.gd:9-17
SHA256: 84fcd65c00faa3836d4f57d52dfe4c0e008bba48aa2c5d51a01a8f686eb42773
Catalog call lines: 12109
Scope: fixed target IDs disjoint from Imperial. Whole-map iteration: none. Whole-map forwarding: none. Explicit Imperial literal in direct file: False
Target constants:
2: const ID="BG24_Quest_314"
Direct function (all writes, merges and helper calls preserved):
9: static func apply_overlay(cards: Dictionary) -> String:
10: 	var card: Dictionary=cards.get(ID,{})
11: 	var issue: String=source_error(card)
12: 	if not issue.is_empty(): return issue
13: 	if card.get("supported")!=false or card.get("effects")!=[] or card.get("source_conflicts",[])!=[] or card.get("latest_validation",{}).get("data_gate",false): return "dust_prints_raw_program_changed"
14: 	card.supported=true;card.effects=EFFECTS.duplicate(true)
15: 	card["implementation_status"]="written_unverified"
16: 	card["implementation_evidence"]="res://research/dust_prints_20261029/IMPLEMENTATION.md"
17: 	return ""

## MurderWeaponSources.apply_overlay
File: core/murder_weapon_sources.gd:17-24
SHA256: 0968456825a16968cfef2cb254114413c0b45c6eec263461d0a8fa2502164bc3
Catalog call lines: 12111
Scope: fixed target IDs disjoint from Imperial. Whole-map iteration: none. Whole-map forwarding: none. Explicit Imperial literal in direct file: False
Target constants:
4: const ID: String="BG24_Quest_123"
Direct function (all writes, merges and helper calls preserved):
17: static func apply_overlay(cards: Dictionary) -> String:
18: 	var card: Dictionary=cards.get(ID,{})
19: 	var issue: String=source_error(card)
20: 	if not issue.is_empty(): return issue
21: 	if card.get("supported")!=false or card.get("effects")!=[] or card.get("source_conflicts",[])!=[] or card.get("latest_validation",{}).get("data_gate",false): return "murder_weapon_raw_program_changed"
22: 	card.supported=true;card.effects=EFFECTS.duplicate(true);card.implementation_status="written_unverified"
23: 	card.implementation_evidence="res://research/murder_weapon_20261029/IMPLEMENTATION.md"
24: 	return ""

## AssembleLineup.apply_overlay
File: core/assemble_lineup_sources.gd:11-19
SHA256: 8c548b8645e2034e5cbe0cc9768b9e2921b605f7b9331c085e59b8aaa4dd590f
Catalog call lines: 12113
Scope: fixed target IDs disjoint from Imperial. Whole-map iteration: none. Whole-map forwarding: none. Explicit Imperial literal in direct file: False
Target constants:
4: const ID="BG24_Quest_114"
Direct function (all writes, merges and helper calls preserved):
11: static func apply_overlay(cards: Dictionary) -> String:
12: 	var card: Dictionary=cards.get(ID,{})
13: 	var issue: String=source_error(card)
14: 	if not issue.is_empty(): return issue
15: 	if card.get("supported")!=false or card.get("effects")!=[] or card.get("source_conflicts",[])!=[] or card.get("latest_validation",{}).get("data_gate",false): return "assemble_lineup_raw_program_changed"
16: 	card.supported=true;card.effects=EFFECTS.duplicate(true)
17: 	card["implementation_status"]="written_unverified"
18: 	card["implementation_evidence"]="res://research/assemble_lineup_20261029/IMPLEMENTATION.md"
19: 	return ""

## RoundUpQuest.apply_overlay
File: core/round_up_quest_sources.gd:11-27
SHA256: 509cd1ec11ff5328dc7baa5a66fb90f29acc3d49293dbbdd268880bebf3abf09
Catalog call lines: 12115
Scope: fixed target IDs disjoint from Imperial. Whole-map iteration: none. Whole-map forwarding: none. Explicit Imperial literal in direct file: False
Target constants:
4: const ID="BG27_Quest_802"
5: const OLD_ID="104660"
Direct function (all writes, merges and helper calls preserved):
11: static func apply_overlay(cards: Dictionary) -> String:
12: 	if cards.has(ID): return "round_up_quest_duplicate_canonical_identity"
13: 	var raw: Dictionary=cards.get(OLD_ID,{})
14: 	if raw.get("id")!=OLD_ID or raw.get("card_code")!=OLD_ID or raw.get("kind")!="quest" or raw.get("name")!="围捕嫌犯" or raw.get("text")!=TEXT or raw.get("supported")!=false or raw.get("effects")!=[]:
15: 		return "round_up_quest_raw_identity_or_program_changed"
16: 	if raw.get("source_conflicts",[])!=[] or raw.get("latest_validation",{}).get("data_gate",false): return "round_up_quest_source_held"
17: 	var card: Dictionary=raw.duplicate(true)
18: 	card.id=ID;card.card_code=ID;card.dbf_id=DBF;card.resolved_from_id=OLD_ID
19: 	card.supported=true;card.effects=EFFECTS.duplicate(true)
20: 	card["conditional_support"]={"reason":"Entire original combat must pass closed plain attack preflight; unknown owner/source domains held before combat."}
21: 	card["implementation_status"]="written_unverified"
22: 	card["native_source_build"]=255790
23: 	card["implementation_evidence"]="res://research/round_up_plain_attack_20261029/IMPLEMENTATION.md"
24: 	cards.erase(OLD_ID)
25: 	cards[ID]=card
26: 	return ""
27: 

## EonarSources.apply_overlay
File: core/eonar_favor_sources.gd:37-45
SHA256: 0146dbda725b6bf329f03c3fd0854f50edd510b55da4fb72e9b90a896fd31652
Catalog call lines: 12117
Scope: fixed target IDs disjoint from Imperial. Whole-map iteration: none. Whole-map forwarding: none. Explicit Imperial literal in direct file: False
Target constants:
3: const ID: String="BG35_912"
Direct function (all writes, merges and helper calls preserved):
37: static func apply_overlay(cards: Dictionary) -> String:
38: 	if not cards.has(ID): return "BG35_912_native_import_missing"
39: 	if not cards[ID] is Dictionary: return "BG35_912_native_import_invalid_row"
40: 	var issue: String=import_error(cards[ID])
41: 	if not issue.is_empty(): return issue
42: 	var merged: Dictionary=cards[ID].duplicate(true)
43: 	merged.merge(CARD,true)
44: 	cards[ID]=merged
45: 	return ""

## WinnerBreadSources.apply_overlay
File: core/winner_bread_sources.gd:30-38
SHA256: d85cb984050f1b14eb18f3ab34cabb0b736e686a00960c1558401c429b595617
Catalog call lines: 12119
Scope: fixed target IDs disjoint from Imperial. Whole-map iteration: none. Whole-map forwarding: none. Explicit Imperial literal in direct file: False
Target constants:
2: const ID: String="BG36_883"
Direct function (all writes, merges and helper calls preserved):
30: static func apply_overlay(cards: Dictionary) -> String:
31: 	if not cards.has(ID): return "BG36_883_native_import_missing"
32: 	if not cards[ID] is Dictionary: return "BG36_883_native_import_invalid_row"
33: 	var issue: String=import_error(cards[ID])
34: 	if not issue.is_empty(): return issue
35: 	var merged: Dictionary=cards[ID].duplicate(true)
36: 	merged.merge(ROW,true)
37: 	cards[ID]=merged
38: 	return ""

## EliseRefreshSources.apply_overlay
File: core/elise_refresh_sources.gd:35-48
SHA256: 530f72a10aa04f9c5f7d9c795cbdeb76c380109d8841fcdc9b26011aae738985
Catalog call lines: 12121
Scope: fixed target IDs disjoint from Imperial. Whole-map iteration: none. Whole-map forwarding: none. Explicit Imperial literal in direct file: False
Target constants:
6: const NORMAL: String = "BG23_353"
7: const GOLDEN: String = "BG23_353_G"
9: const IDS: Array = [NORMAL, GOLDEN]
Direct function (all writes, merges and helper calls preserved):
35: static func apply_overlay(cards: Dictionary) -> String:
36: 	var parsed: Variant = JSON.parse_string(FileAccess.get_file_as_string("res://data/elise_refresh_native_overlay.json"))
37: 	if not parsed is Dictionary or not parsed.get("cards") is Array:
38: 		return "elise_refresh_missing_overlay"
39: 	for overlay in parsed.cards:
40: 		if not overlay is Dictionary or overlay.get("id") not in IDS or not cards.has(overlay.id):
41: 			return "elise_refresh_missing_native_parent"
42: 		var merged: Dictionary = cards[overlay.id].duplicate(true)
43: 		merged.merge(overlay, true)
44: 		var issue: String = program_error(merged)
45: 		if not issue.is_empty(): return issue
46: 		cards[overlay.id] = merged
47: 	return ""
48: 

## ParasiticFleshlingSources.apply_overlay
File: core/parasitic_fleshling_sources.gd:23-33
SHA256: 760b1ce82383c96047854dbd68d7f98d6062144ab673c1c85ed01be0058771bf
Catalog call lines: 12123
Scope: fixed target IDs disjoint from Imperial. Whole-map iteration: none. Whole-map forwarding: none. Explicit Imperial literal in direct file: False
Target constants:
6: const IDS: Array = ["BG36_114", "BG36_114_G"]
Direct function (all writes, merges and helper calls preserved):
23: static func apply_overlay(cards: Dictionary) -> String:
24: 	var data: Variant=JSON.parse_string(FileAccess.get_file_as_string("res://data/parasitic_fleshling_overlay.json"))
25: 	if not data is Dictionary or not data.get("cards") is Array: return "parasitic_fleshling_missing_overlay"
26: 	for row in data.cards:
27: 		if not row is Dictionary or row.get("id") not in IDS or not cards.has(row.id): return "parasitic_fleshling_missing_native_identity"
28: 		var merged: Dictionary=cards[row.id].duplicate(true)
29: 		merged.merge(row,true)
30: 		var issue: String=program_error(merged)
31: 		if not issue.is_empty(): return issue
32: 		cards[row.id]=merged
33: 	return ""

## MutatedLasherSources.apply_overlay
File: core/mutated_lasher_sources.gd:31-47
SHA256: d35425629ddba1cc65ea157b483bd3fd67ae1a31af21f7d1f59e175361df2278
Catalog call lines: 12125
Scope: fixed target IDs disjoint from Imperial. Whole-map iteration: none. Whole-map forwarding: none. Explicit Imperial literal in direct file: False
Target constants:
5: const IDS: Array = ["BG31_852", "BG31_852_G"]
Direct function (all writes, merges and helper calls preserved):
31: static func apply_overlay(cards: Dictionary) -> String:
32: 	var data: Variant = JSON.parse_string(FileAccess.get_file_as_string("res://data/mutated_lasher_overlay.json"))
33: 	if not data is Dictionary or not data.get("cards") is Array or data.cards.size() != IDS.size(): return "mutated_lasher_missing_overlay"
34: 	var merged_rows: Dictionary = {}
35: 	for row in data.cards:
36: 		if not row is Dictionary or row.get("id") not in IDS or not cards.has(row.id) or merged_rows.has(row.id): return "mutated_lasher_missing_native_identity"
37: 		var native: Dictionary = cards[row.id]
38: 		if native.get("text") != NATIVE_TEXT[row.id] or native.get("attack") != NATIVE_BODY[row.id][0] or native.get("health") != NATIVE_BODY[row.id][1]: return "mutated_lasher_changed_independent_source"
39: 		var merged: Dictionary = native.duplicate(true)
40: 		merged.merge(row, true)
41: 		var issue: String = program_error(merged)
42: 		if not issue.is_empty(): return issue
43: 		merged.quality_flags = merged.get("quality_flags", []).duplicate()
44: 		merged.quality_flags.erase("effect_not_implemented")
45: 		merged_rows[row.id] = merged
46: 	for id in IDS: cards[id] = merged_rows[id]
47: 	return ""

## DeterminedDefenderSources.apply_overlay
File: core/determined_defender_sources.gd:26-41
SHA256: afa1f27d46618e66584cd001223593f3bc17aeec30379c6262c9ca025629aac3
Catalog call lines: 12127
Scope: fixed target IDs disjoint from Imperial. Whole-map iteration: none. Whole-map forwarding: none. Explicit Imperial literal in direct file: False
Target constants:
6: const IDS: Array = ["BG35_122", "BG35_122_G"]
Direct function (all writes, merges and helper calls preserved):
26: static func apply_overlay(cards: Dictionary) -> String:
27: 	var data: Variant = JSON.parse_string(FileAccess.get_file_as_string("res://data/determined_defender_overlay.json"))
28: 	if not data is Dictionary or not data.get("cards") is Array: return "determined_defender_missing_overlay"
29: 	for row in data.cards:
30: 		if not row is Dictionary or row.get("id") not in IDS or not cards.has(row.id):
31: 			return "determined_defender_missing_native_identity"
32: 		var merged: Dictionary = cards[row.id].duplicate(true)
33: 		merged.merge(row, true)
34: 		var issue: String = program_error(merged)
35: 		if not issue.is_empty(): return issue
36: 		# Preserve raw values, historical pool identity, normal/golden links and
37: 		# independent native proof. This only removes the superseded missing-DSL flag.
38: 		merged.quality_flags = merged.get("quality_flags", []).duplicate()
39: 		merged.quality_flags.erase("effect_not_implemented")
40: 		cards[row.id] = merged
41: 	return ""

## UpbeatUpstartSources.apply_overlay
File: core/upbeat_upstart_sources.gd:12-25
SHA256: 48e6473fc6b8f8cfeb8bb841c33ef3a980d15146fefa75e62fa722ae69bbdb92
Catalog call lines: 12129
Scope: fixed target IDs disjoint from Imperial. Whole-map iteration: none. Whole-map forwarding: none. Explicit Imperial literal in direct file: False
Target constants:
5: const IDS: Array = ["BG26_120", "BG26_120_G"]
Direct function (all writes, merges and helper calls preserved):
12: static func apply_overlay(cards: Dictionary) -> String:
13: 	var data: Variant = JSON.parse_string(FileAccess.get_file_as_string("res://data/upbeat_upstart_overlay.json"))
14: 	if not data is Dictionary or not data.get("cards") is Array:
15: 		return "upbeat_upstart_missing_overlay"
16: 	for row in data.cards:
17: 		if not row is Dictionary or row.get("id") not in IDS or not cards.has(row.id):
18: 			return "upbeat_upstart_missing_native_identity"
19: 		if not Exact.same(row.get("effects"),PROGRAMS[row.id]): return "upbeat_upstart_changed_overlay_program"
20: 		var merged: Dictionary = cards[row.id].duplicate(true)
21: 		merged.merge(row, true)
22: 		merged.quality_flags = merged.get("quality_flags", []).duplicate()
23: 		merged.quality_flags.erase("effect_not_implemented")
24: 		cards[row.id] = merged
25: 	return ""

## DamageRegistry.apply_source_metadata
File: core/damage_listener_registry.gd:972-990
SHA256: 162ad1d2ad74e0a0a65632bf6b2e6a2789ff1424cf3c9e00865e74d8b8ed8764
Catalog call lines: 2191
Scope: fixed target IDs disjoint from Imperial. Whole-map iteration: none. Whole-map forwarding: none. Explicit Imperial literal in direct file: False
Target constants:
6: const SOURCE_IDS: Array = ["BG_BOT_218", "TB_BaconUps_041", "BG29_801", "BG29_801_G", "BG29_800", "BG29_800_G", "BG_BRM_006", "TB_BaconUps_030", "BG34_312", "BG34_312_G"]
7: const TOKEN_IDS: Array = ["BG_BOT_218t", "TB_BaconUps_041t", "BG29_801t", "BG29_801_Gt", "BG_BRM_006t", "TB_BaconUps_030t"]
Direct function (all writes, merges and helper calls preserved):
972: static func apply_source_metadata(cards: Dictionary) -> String:
973: 	if not FileAccess.file_exists(PATH) or FileAccess.get_file_as_string(PATH).sha256_text() != REGISTRATION_SHA256:
974: 		return "Damage-received source registration changed; independent review required"
975: 	if not FileAccess.file_exists("res://data/damage_listener_registry.json") or FileAccess.get_file_as_string("res://data/damage_listener_registry.json").sha256_text() != Sources.REGISTRY_SHA256:
976: 		return "Damage-received pure source registry changed"
977: 	var registration: Variant = JSON.parse_string(FileAccess.get_file_as_string(PATH))
978: 	if not registration is Dictionary or not same(registration.get("catalog_fields"), SOURCE_SPECS): return "Damage-received compiled source literals differ"
979: 	var registry: Variant = JSON.parse_string(FileAccess.get_file_as_string("res://data/damage_listener_registry.json"))
980: 	if not registry is Dictionary or not same(registry.get("records"),Sources.RECORDS): return "Damage-received independent source literals differ"
981: 	for identity in SOURCE_IDS + TOKEN_IDS:
982: 		if not cards.get(identity) is Dictionary: return "Missing exact damage-received source: " + str(identity)
983: 		var issue: String = _definition_error(cards[identity],identity)
984: 		if not issue.is_empty(): return issue
985: 	for identity in SOURCE_IDS + TOKEN_IDS:
986: 		cards[identity].damage_listener_source = Sources.RECORDS[identity].duplicate(true)
987: 		cards[identity].client_card_id = Sources.RECORDS[identity].client_card_id
988: 		cards[identity].client_dbf_id = Sources.RECORDS[identity].dbf_id
989: 	return ""
990: 

## QuestIdentity.apply
File: core/quest_identity_overrides.gd:24-34
SHA256: 89bbd65ed6a0247a950084b4747f4dc47163f3c5b3fb5143174dea601f5c7839
Catalog call lines: 2193
Scope: fixed target IDs disjoint from Imperial. Whole-map iteration: none. Whole-map forwarding: none. Explicit Imperial literal in direct file: False
Target constants:
5: const FROM_ID: String = "unverified_07cd694f33ade4fb64ae"
6: const TO_ID: String = "BG27_Quest_800"
Direct function (all writes, merges and helper calls preserved):
24: static func apply(cards: Dictionary, manifest_text: String) -> String:
25: 	if manifest_text.sha256_text() != MANIFEST_SHA256: return "任务身份核验清单已变化，须重新审核。"
26: 	var row: Variant = JSON.parse_string(manifest_text)
27: 	if not row is Dictionary or not _same(row.get("schema_version"),1) or not _same(row.get("from_id"),FROM_ID) or not _same(row.get("to_id"),TO_ID): return "任务身份清单格式无效。"
28: 	if not cards.has(FROM_ID) or cards.has(TO_ID): return "任务暂存身份缺失或已经归一。"
29: 	if not _same(cards[FROM_ID],row.get("original_card")): return "任务原始暂存记录已变化，不能应用旧身份依据。"
30: 	var card: Variant = row.get("canonical_card")
31: 	if not card is Dictionary or not _same(card.get("id"),TO_ID) or not _same(card.get("card_code"),TO_ID) or not _same(card.get("kind"),"quest") or not _same(card.get("supported"),false) or not _same(card.get("dbf_id"),"104658") or not _same(card.get("resolved_from_id"),FROM_ID): return "任务独立卡码绑定不完整。"
32: 	cards.erase(FROM_ID)
33: 	cards[TO_ID] = card.duplicate(true)
34: 	return ""

## FinalSource.apply
File: core/final_source_overrides.gd:7-36
SHA256: 38d7555a9e91993b08e08b6382c2afc877e8ac69eb1fded7ff5204b42d021a81
Catalog call lines: 2196
Scope: fixed target IDs disjoint from Imperial. Whole-map iteration: none. Whole-map forwarding: none. Explicit Imperial literal in direct file: False
Target constants:
5: const IDS: Array = ["BG23_007", "BG23_007_G", "BG23_007t", "BG23_007_Gt", "BG31_880", "BG31_880t", "BG31_880t2", "BG25_032_G", "BG33_827_G","BG31_881t","BG31_886t","BG31_886t2","BG27_009_G","BG34_521_G","BG34_PreMadeChamp_065_G","BG32_893","BG32_893_G","BG_CFM_063","BG_CFM_063_G"]
Direct function (all writes, merges and helper calls preserved):
7: static func apply(cards: Dictionary, manifest_text: String) -> String:
8: 	if manifest_text.sha256_text() != MANIFEST_SHA256: return "最终战棋源修正清单已变化，须重新核验。"
9: 	var payload: Variant = JSON.parse_string(manifest_text)
10: 	if not payload is Dictionary or payload.get("schema_version") != 1 or not payload.get("overrides") is Array: return "最终战棋源修正清单格式无效。"
11: 	var plans: Array = []
12: 	var seen: Dictionary = {}
13: 	for row in payload.overrides:
14: 		if not row is Dictionary or not row.get("id") is String: return "最终战棋源修正身份无效。"
15: 		var id: String = row.id
16: 		if id not in IDS or seen.has(id) or not cards.has(id): return "最终战棋源修正身份缺失或重复。"
17: 		seen[id] = true
18: 		var card: Dictionary = cards[id]
19: 		if card.get("kind") != row.get("kind"): return "最终战棋源修正种类不匹配。"
20: 		if not row.get("verification") is Dictionary or row.verification.get("status") != "confirmed": return "最终战棋源修正尚未核实。"
21: 		var original: Variant = row.get("original_fields")
22: 		var fields: Variant = row.get("fields")
23: 		if not original is Dictionary or not fields is Dictionary or original.size()!=fields.size() or not original.has("text") or not fields.has("text"): return "最终战棋源修正字段不完整。"
24: 		for key in fields:
25: 			if (key not in ["text","category","categories"] and not (key=="tier" and id in ["BG32_893","BG32_893_G"]) and not (key in ["name","tribes"] and id in ["BG_CFM_063","BG_CFM_063_G"])) or not original.has(key) or card.get(key) != original[key]: return "原始字段已变化，须重新核验："+id
26: 		if id in ["BG_CFM_063","BG_CFM_063_G"] and (fields.size()!=3 or fields.get("name")!="化学怪人" or fields.get("tribes")!=[] or original.get("name")!="格斗陪练师" or original.get("tribes")!=["亡灵"] or fields.text!=original.text): return "化学怪人完整原生名称与无种族修正不匹配。"
27: 		if fields.has("tier") and (fields.tier!=(5 if id=="BG32_893" else 4) or original.tier!=5): return "跳跳魔犬最终原生星级修正不匹配。"
28: 		if fields.has("category") and (not fields.category is String or fields.get("categories") != [fields.category]): return "最终战棋分类字段无效。"
29: 		if not fields.text is String or fields.text.is_empty(): return "最终战棋卡文无效。"
30: 		plans.append({"id":id,"original":original,"fields":fields,"verification":row.verification})
31: 	if seen.size()!=IDS.size(): return "最终战棋源修正清单不完整。"
32: 	for plan in plans:
33: 		cards[plan.id].original_final_bg_fields = plan.original.duplicate(true)
34: 		cards[plan.id].merge(plan.fields.duplicate(true),true)
35: 		cards[plan.id].final_bg_source_verification = plan.verification.duplicate(true)
36: 	return ""

## HeroValues.apply
File: core/hero_value_overrides.gd:4-30
SHA256: c88ad3541ef6fe40914561c93ec5d4849f66fc9f885644a63761258962141052
Catalog call lines: 2201
Scope: fixed target IDs disjoint from Imperial. Whole-map iteration: none. Whole-map forwarding: none. Explicit Imperial literal in direct file: False
Target constants:
3: const IDS: Array = ["TB_BaconShop_HERO_31","TB_BaconShop_HERO_20","TB_BaconShop_HERO_47"]
Direct function (all writes, merges and helper calls preserved):
4: static func apply(cards: Dictionary, payload: Variant) -> String:
5: 	if not payload is Dictionary or payload.get("schema_version") != 1 or not payload.get("overrides") is Array: return "历史英雄终值覆盖格式无效。"
6: 	var plans: Array = []
7: 	var seen: Dictionary = {}
8: 	for row in payload.overrides:
9: 		if not row is Dictionary: return "历史英雄终值条目无效。"
10: 		if not row.get("verification") is Dictionary or row.verification.get("status","") != "confirmed": return "历史英雄终值尚未核实。"
11: 		var id: String = str(row.get("id",""))
12: 		if id not in IDS or seen.has(id) or not cards.has(id) or row.get("kind") != "hero" or cards[id].get("kind") != "hero": return "历史英雄身份不匹配。"
13: 		seen[id] = true
14: 		var fields: Variant = row.get("fields")
15: 		if not fields is Dictionary or fields.size()!=4: return "历史英雄字段不完整。"
16: 		for key in ["health","armor","armor_by_mode","text"]:
17: 			if not fields.has(key): return "历史英雄缺少字段："+key
18: 		if not str(row.get("original_text_sha256","")).is_valid_hex_number(false) or str(cards[id].get("text","")).sha256_text()!=row.original_text_sha256: return "历史英雄原文已变化，须重新核实："+id
19: 		if not fields.health is int or fields.health<1 or not fields.armor is int or fields.armor<0: return "历史英雄生命/护甲须为有效整数。"
20: 		if fields.armor_by_mode != {"solo":fields.armor} or not fields.text is String or fields.text.is_empty(): return "历史英雄模式或卡文无效。"
21: 		plans.append({"id":id,"row":row,"fields":fields})
22: 	if seen.size() != IDS.size(): return "历史英雄终值覆盖不完整。"
23: 	for plan in plans:
24: 		var card: Dictionary = cards[plan.id]
25: 		card.original_terminal_hero_fields=plan.row.get("original_fields",{}).duplicate(true)
26: 		card.merge(plan.fields.duplicate(true),true)
27: 		for key in ["health","armor"]:
28: 			card.field_status[key]={"status":"known","value":plan.fields[key],"verification":"confirmed_final_BG_hero_definition"}
29: 		card.terminal_hero_verification=plan.row.verification.duplicate(true)
30: 	return ""
