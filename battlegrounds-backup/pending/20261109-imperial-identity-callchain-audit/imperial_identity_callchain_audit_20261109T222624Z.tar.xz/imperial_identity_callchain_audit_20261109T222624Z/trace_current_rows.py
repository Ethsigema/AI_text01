"""Stream technical catalog arrays as data; no project module execution."""
from pathlib import Path
import hashlib, json, re, resource

resource.setrlimit(resource.RLIMIT_AS,(128*1024*1024,128*1024*1024))
H=Path(__file__).resolve().parent;R=H.parent/'historical_tools_batch14_20261109T191857Z/runtime'
base=json.loads((R.parent/'SOURCE_MAP.json').read_text())
catalog=(R/'core/catalog.gd').read_text()
match=re.search(r'^\s*for path in (\["res://data/catalog_raw.json".*\]):$',catalog,re.M)
paths=[x.removeprefix('res://')for x in json.loads(match[1])]
source=(R/'core/imperial_defender_sources.gd').read_text();const={}
for line in source.splitlines():
 m=re.match(r'^const (RAW|EXPECTED): Dictionary=(.*)$',line)
 if m:const[m[1]]=json.loads(m[2])
ids=set(const['RAW']);selected=[];files=[]
def digest(path):
 h=hashlib.sha256()
 with path.open('rb')as f:
  for b in iter(lambda:f.read(262144),b''):h.update(b)
 return h.hexdigest()
def cards(path):
 decoder=json.JSONDecoder()
 with path.open(encoding='utf-8')as f:
  buf=f.read(65536);m=re.search(r'"cards"\s*:\s*\[',buf)
  assert m,'No cards array found in bounded top-level prefix'
  prefix=buf[:m.end()-1];header=json.loads(prefix+'[]}');assert isinstance(header,dict)and header['cards']==[]
  pos=m.end()
  while True:
   while pos<len(buf)and buf[pos]in ' \r\t\n,':pos+=1
   if pos>=len(buf):buf=f.read(65536);pos=0;assert buf,'Unexpected EOF';continue
   if buf[pos]==']':
    tail=buf[pos+1:]+f.read();json.loads(prefix+'[]'+tail);break
   try:row,end=decoder.raw_decode(buf,pos)
   except json.JSONDecodeError:
    more=f.read(65536);assert more,'Incomplete row'
    buf=buf[pos:]+more;pos=0;assert len(buf)<8*1024*1024,'Oversized single row';continue
   assert isinstance(row,dict);yield row;pos=end
   if pos>65536:buf=buf[pos:];pos=0
def exact(a,b):return json.dumps(a,sort_keys=True,separators=(',',':'))==json.dumps(b,sort_keys=True,separators=(',',':'))
for rel in paths:
 p=R/rel
 if not p.is_file():files.append({'path':rel,'exists':False});continue
 pin=digest(p);assert pin==base[rel]['sha256'];count=0;seen=set();duplicates=[];nonstring=0;hits=[]
 for count,row in enumerate(cards(p),1):
  identity=row.get('id')
  if not isinstance(identity,str):nonstring+=1;continue
  if identity in seen:duplicates.append(identity)
  seen.add(identity)
  if identity in ids:
   record={'path':rel,'row_index_zero_based':count-1,'id':identity,
    'exact_current_gd_RAW':exact(row,const['RAW'][identity]),
    'exact_current_gd_EXPECTED':exact(row,const['EXPECTED'][identity]),'row':row}
   selected.append(record);hits.append(identity)
 files.append({'path':rel,'exists':True,'bytes':p.stat().st_size,'sha256':pin,'cards_count':count,
               'nonstring_or_missing_ids':nonstring,'duplicate_ids':duplicates,'imperial_ids':hits})
result={'scope':'Current loader input JSON rows only. Construction/mutation helpers not executed. Rows read one at a time.',
 'files':files,'selected_rows':selected,'source_gd_sha256':digest(R/'core/imperial_defender_sources.gd'),
 'all_files_match_baseline':True,'max_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
(H/'CURRENT_INPUT_ROWS.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'files':len(files),'selected_rows':[ {k:v for k,v in x.items()if k!='row'}for x in selected],
 'max_rss_kib':result['max_rss_kib']},ensure_ascii=False,indent=2))
