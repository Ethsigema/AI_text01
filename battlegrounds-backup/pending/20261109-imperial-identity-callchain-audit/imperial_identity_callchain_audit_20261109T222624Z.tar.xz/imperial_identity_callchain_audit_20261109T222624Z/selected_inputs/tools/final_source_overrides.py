"""Reviewed final-BG source corrections. Does not admit executable effects.

The small reviewed manifest is anchored verbatim. Original Library/raw records
remain unchanged; any different raw field or partial/malformed manifest fails
before the first source record is changed.
"""
from copy import deepcopy
from pathlib import Path
import hashlib
import json

MANIFEST = 'data/final_bg_source_overrides.json'
MANIFEST_SHA256 = '1f61cc86718d6e0fcba3091b9213823c8c25804cb6a2849e66946a7cafb63c27'
IDS = frozenset(('BG23_007', 'BG23_007_G', 'BG23_007t', 'BG23_007_Gt', 'BG31_880', 'BG31_880t', 'BG31_880t2', 'BG25_032_G', 'BG33_827_G', 'BG31_881t', 'BG31_886t', 'BG31_886t2', 'BG27_009_G', 'BG34_521_G', 'BG34_PreMadeChamp_065_G', 'BG32_893', 'BG32_893_G', 'BG_CFM_063', 'BG_CFM_063_G'))

def apply(cards, root):
    content = (Path(root) / MANIFEST).read_bytes()
    assert hashlib.sha256(content).hexdigest() == MANIFEST_SHA256, 'Final BG source manifest changed; review required'
    payload = json.loads(content)
    assert payload.get('schema_version') == 1 and isinstance(payload.get('overrides'), list)
    plans, seen = [], set()
    for row in payload['overrides']:
        assert isinstance(row, dict)
        ident = row.get('id')
        assert ident in IDS and ident in cards and ident not in seen
        seen.add(ident)
        card = cards[ident]
        assert card.get('kind') == row.get('kind')
        assert row.get('verification', {}).get('status') == 'confirmed'
        original, fields = row.get('original_fields'), row.get('fields')
        assert isinstance(original, dict) and isinstance(fields, dict)
        assert set(original) == set(fields) and 'text' in fields and set(fields) <= ({'text', 'category', 'categories', 'tier'} if ident in ('BG32_893', 'BG32_893_G') else {'text', 'name', 'tribes'} if ident in ('BG_CFM_063', 'BG_CFM_063_G') else {'text', 'category', 'categories'})
        assert all(card.get(key) == value for key, value in original.items()), ident + ' original source drift'
        assert isinstance(fields['text'], str) and fields['text']
        if ident in ('BG_CFM_063', 'BG_CFM_063_G'):
            assert fields == {'text': original['text'], 'name': '化学怪人', 'tribes': []}
            assert original['name'] == '格斗陪练师' and original['tribes'] == ['亡灵']
        if 'tier' in fields:
            assert original['tier'] == 5 and fields['tier'] == (5 if ident == 'BG32_893' else 4)
        if 'category' in fields:
            assert isinstance(fields['category'], str) and fields['categories'] == [fields['category']]
        plans.append((card, row))
    assert seen == IDS, 'Incomplete final BG source correction manifest'
    for card, row in plans:
        card['original_final_bg_fields'] = deepcopy(row['original_fields'])
        card.update(deepcopy(row['fields']))
        card['final_bg_source_verification'] = deepcopy(row['verification'])
    return len(plans)

if __name__ == '__main__':
    root = Path(__file__).resolve().parents[1]
    cards = {c['id']: c for c in json.loads((root / 'data/catalog_raw.json').read_text())['cards']}
    old = deepcopy(cards)
    assert apply(cards, root) == 19
    for ident in IDS:
        assert cards[ident]['supported'] == old[ident]['supported'] == False
        assert cards[ident]['effects'] == old[ident]['effects']
        if ident.startswith('BG23_007'): assert '如果该随从是纳迦' in cards[ident]['text']
        assert cards[ident]['original_final_bg_fields']['text'] == old[ident]['text']
    bad = deepcopy(old)
    bad['BG23_007_Gt']['text'] += '未审核新效果'
    before = deepcopy(bad)
    try:
        apply(bad, root)
    except AssertionError:
        pass
    else:
        raise AssertionError('Changed original source accepted')
    assert bad == before, 'Source correction partially committed'
    print('FINAL BG SOURCE CORRECTIONS: 19 complete source-only overrides; original drift rejected atomically; no effect admission')
