extends RefCounted
const Gadrin = preload("res://core/gadrin_recipient_health_sources.gd")
const Ragnaros = preload("res://core/timewarped_ragnaros_sources.gd")
const Crystal = preload("res://core/crystal_infuser_sources.gd")
const MirageChoice = preload("res://core/mirage_choice_leaves_sources.gd")
const SelfChoice = preload("res://core/self_choice_leaves_sources.gd")
const OutbackSources = preload("res://core/outback_sources.gd")
const DamageRoom = preload("res://core/damage_listener_room.gd")
const AttackGainOrder = preload("res://core/attack_gain_order.gd")
const ShopRefreshOrder = preload("res://core/shop_refresh_category_order.gd")
const EotCategoryOrder = preload("res://core/end_turn_category_order.gd")
const RecruitQuests = preload("res://core/recruit_quest_predicates.gd")
const NativePrizes = preload("res://core/native_prizes.gd")
const MinionPriceOrder = preload("res://core/minion_price_order.gd")
## Explicit local sandbox parameters. Source records/categories/effects remain immutable.
const FIELDS:Array=["tier","cost","copies"]
static func _integer(value:Variant)->bool:
	return value is int or (value is float and is_finite(value) and value==floor(value))
static func entry_error(value:Variant)->String:
	if not value is Dictionary or value.size()!=3:return "自定义入店参数必须包含星级、价格和库存三项。"
	for key in FIELDS:
		if not _integer(value.get(key)):return "自定义入店参数必须为整数："+key
	if value.tier<1 or value.tier>6:return "自定义商店星级只支持1至6。"
	if value.cost<0 or value.cost>99:return "自定义购买价格必须为0至99枚铸币。"
	if value.copies<1 or value.copies>99:return "自定义共享库存必须为1至99份。"
	return ""
static func source_error(catalog,id:String)->String:
	if Gadrin.accepts_id(id):return "gadrin_recipient_health_native_buddy_acquisition_unimplemented"
	if Ragnaros.accepts_id(id):return "timewarped_ragnaros_custom_gold_acquisition_unimplemented"
	if Crystal.leaf_id(id):return "晶能灌注抉择选项只能通过真实父随从执行，不能加入商店。"
	if MirageChoice.leaf_id(id):return "幻象抉择选项只能通过真实父随从执行，不能加入商店。"
	if SelfChoice.leaf_id(id):return "自身抉择叶只能在真实父随从上下文中执行，不能加入商店。"
	if id in ["BG31_884t","BG31_884t2"]:return "罕迹之路抉择叶仅支持特殊来源手牌，不能直接加入商店。"
	var card:Dictionary=catalog.get_card(id)
	if card.is_empty() or card.get("kind","") not in ["minion","spell"]:return "自定义入店只支持随从或法术。"
	if not card.get("supported",false) or card.get("excluded",false) or not card.get("solo_eligible",true):return "自定义参数不能跳过效果、数值或单打禁用检查。"
	if card.kind=="minion":
		if card.get("is_golden",false):return "金色随从仍通过三连获得，不能直接加入商店。"
		var golden:Dictionary=catalog.get_card(str(card.get("golden_id","")))
		if not golden.get("supported",false) or not golden.get("is_golden",false):return "缺少独立已实现的金色随从，不能准确结算三连。"
	return ""
static func validate(config:Dictionary,catalog)->Array[String]:
	if catalog.source_catalog != null: catalog = catalog.source_catalog
	var errors:Array[String]=[]
	if not OutbackSources.schema_error(config).is_empty(): return [OutbackSources.schema_error(config)]
	if not DamageRoom.schema_error(config).is_empty(): return [DamageRoom.schema_error(config)]
	if config.has("beetle_growth") and not config.beetle_growth is bool: return ["beetle_growth 必须为布尔值。"]
	if not EotCategoryOrder.schema_error(config).is_empty(): return ["回合结束整组顺序配置无效。"]
	if not ShopRefreshOrder.schema_error(config).is_empty(): return ["刷新后整组顺序配置无效。"]
	if not AttackGainOrder.schema_error(config).is_empty(): return ["攻击增益顺序配置无效。"]
	var parameters:Variant=config.get("quest_parameters",{})
	if not parameters is Dictionary: return ["招募任务参数必须为对象。"]
	for identity in parameters:
		var parameter_issue:String = RecruitQuests.parameters_error(identity,parameters[identity])
		if not parameter_issue.is_empty(): return ["招募任务参数："+parameter_issue]
	var entries:Variant=config.get("shop_overrides",{})
	if not entries is Dictionary:return ["自定义商店配置必须为对象。"]
	var golden_tiers:Dictionary={}
	for id in entries:
		if not id is String or id.is_empty():errors.append("自定义入店卡牌ID无效。");continue
		var issue:String=entry_error(entries[id])
		if issue.is_empty():issue=source_error(catalog,id)
		if not issue.is_empty():errors.append(id+"："+issue);continue
		var card:Dictionary=catalog.get_card(id)
		if card.kind=="minion":
			var golden_id:String=card.golden_id
			if golden_tiers.has(golden_id) and golden_tiers[golden_id]!=int(entries[id].tier):errors.append("同一金色身份不能同时使用不同的自定义星级："+golden_id)
			golden_tiers[golden_id]=int(entries[id].tier)
	return errors
static func _canonical(entries:Dictionary)->Dictionary:
	var output:Dictionary={};var ids:Array=entries.keys();ids.sort()
	for id in ids:
		output[id]={"tier":int(entries[id].tier),"cost":int(entries[id].cost),"copies":int(entries[id].copies)}
	return output
static func _canonical_quest_parameters(entries:Dictionary)->Dictionary:
	var output:Dictionary = {}
	var ids:Array = entries.keys(); ids.sort()
	for id in ids: output[id] = RecruitQuests.normalize_parameters(id,entries[id])
	return output
static func _prize_config(config:Dictionary)->Dictionary:
	if not NativePrizes.enabled(config): return {}
	var ids:Array=config.get("enabled_prizes",[]).duplicate();ids.sort()
	var disabled:Array=config.get("disabled_ids",[]).filter(func(id):return id in ids);disabled.sort()
	return {"source":NativePrizes.SOURCE if NativePrizes.global_enabled(config) else NativePrizes.Tickatus.SOURCE,"enabled_ids":ids,"disabled_ids":disabled,"choice_order":config.get("prize_choice_order",""),"delivery_order":config.get("prize_delivery_order",""),"policy":"explicit-local-prize-order-v1"}
static func fingerprint(catalog,config:Dictionary)->String:
	var base:String=catalog.base_execution_fingerprint if not str(catalog.base_execution_fingerprint).is_empty() else catalog.execution_fingerprint
	var entries:Dictionary=config.get("shop_overrides",{})
	var prize:Dictionary=_prize_config(config)
	var specification:String=base
	if config.get(OutbackSources.FIELD,false) == true: specification+="\n"+OutbackSources.POLICY
	if config.get(DamageRoom.FIELD,false) == true: specification+="\n"+DamageRoom.fingerprint_fragment(config)
	if config.get("beetle_growth",false) == true: specification+="\nbeetle-growth-closed-room-v1\nM+I;frozen-elimination-1"
	if not str(config.get(AttackGainOrder.FIELD,"")).is_empty(): specification+="\n"+AttackGainOrder.fingerprint_fragment(config)
	if not str(config.get(ShopRefreshOrder.FIELD,"")).is_empty(): specification+="\n"+ShopRefreshOrder.fingerprint_fragment(config)
	if not str(config.get(EotCategoryOrder.FIELD,"")).is_empty(): specification+="\n"+EotCategoryOrder.fingerprint_fragment(config)
	if not config.get("quest_parameters",{}).is_empty(): specification+="\nlocal-quest-parameters-v1\n"+JSON.stringify(_canonical_quest_parameters(config.quest_parameters))
	if not str(config.get(MinionPriceOrder.FIELD,"")).is_empty(): specification+="\n"+MinionPriceOrder.fingerprint_fragment(config)
	if not entries.is_empty():specification+="\ncustom-shop-v1\n"+JSON.stringify(_canonical(entries))
	if not str(config.get("delayed_income_order","")).is_empty():specification+="\nlocal-delayed-income-v1\n"+str(config.delayed_income_order)
	if not str(config.get("coin_end_turn_order","")).is_empty():specification+="\nlocal-eot-order-v1\n"+str(config.coin_end_turn_order)
	if not prize.is_empty():specification+="\nnative-prize-room-v1\n"+JSON.stringify(prize)
	return specification.sha256_text() if specification!=base else base
static func effective_catalog(catalog,config:Dictionary):
	if catalog.source_catalog != null: catalog = catalog.source_catalog
	if not validate(config,catalog).is_empty():return null
	var entries:Dictionary=config.get("shop_overrides",{})
	if config.get(OutbackSources.FIELD,false) != true and config.get(DamageRoom.FIELD,false) != true and config.get("beetle_growth",false) != true and str(config.get(AttackGainOrder.FIELD,"")).is_empty() and str(config.get(ShopRefreshOrder.FIELD,"")).is_empty() and str(config.get(EotCategoryOrder.FIELD,"")).is_empty() and entries.is_empty() and config.get("quest_parameters",{}).is_empty() and not NativePrizes.enabled(config) and str(config.get("coin_end_turn_order","")).is_empty() and str(config.get("delayed_income_order","")).is_empty() and str(config.get(MinionPriceOrder.FIELD,"")).is_empty():return catalog
	var result=catalog.get_script().new()
	result.source_catalog=catalog
	result.cards=catalog.cards.duplicate(true)
	result.seasons=catalog.seasons.duplicate(true)
	result.tribe_requirements=catalog.tribe_requirements
	result.buddy_bindings=catalog.buddy_bindings
	result.native_prize_registry=catalog.native_prize_registry
	result.native_prize_defaults=catalog.native_prize_defaults
	result.load_errors=catalog.load_errors.duplicate()
	result.rules_version=catalog.rules_version
	result.base_execution_fingerprint=catalog.base_execution_fingerprint if not str(catalog.base_execution_fingerprint).is_empty() else catalog.execution_fingerprint
	result.execution_fingerprint=fingerprint(catalog,config)
	result.hand_card_templates=catalog.hand_card_templates.duplicate(true)
	result.hand_card_kinds=catalog.hand_card_kinds.duplicate(true)
	var tier_by_identity:Dictionary={}
	for id in entries:
		var entry:Dictionary=_canonical({id:entries[id]})[id]
		var card:Dictionary=result.cards[id]
		card.source_shop_fields={"tier":card.get("tier"),"cost":card.get("cost"),"pool_supported":card.get("pool_supported",false)}
		card.custom_shop_override=entry.duplicate(true)
		card.tier=entry.tier;card.cost=entry.cost;card.pool_supported=true
		if result.hand_card_templates.has(id) and card.kind=="minion":result.hand_card_templates[id].tier=entry.tier
		if card.kind=="minion":
			tier_by_identity[id]=entry.tier
			tier_by_identity[card.golden_id]=entry.tier
			var golden:Dictionary=result.cards[card.golden_id]
			golden.source_shop_fields={"tier":golden.get("tier"),"cost":golden.get("cost"),"pool_supported":false}
			golden.tier=entry.tier;golden.custom_shop_derived_from=id
			if result.hand_card_templates.has(golden.id):result.hand_card_templates[golden.id].tier=entry.tier
	# The explicit room tier belongs to this identity in every acquisition path.
	# Patch embedded summon/base templates as well as catalog-created instances.
	for card in result.cards.values(): _synchronize_embedded_tiers(card.get("effects",[]),tier_by_identity)
	for template in result.hand_card_templates.values(): _synchronize_embedded_tiers(template,tier_by_identity)
	return result
static func _synchronize_embedded_tiers(value:Variant,tiers:Dictionary)->void:
	if value is Dictionary:
		var id:String=str(value.get("card_id",""))
		if tiers.has(id) and value.has("attack") and value.has("health"):
			value.tier=int(tiers[id])
		for nested in value.values(): _synchronize_embedded_tiers(nested,tiers)
	elif value is Array:
		for nested in value: _synchronize_embedded_tiers(nested,tiers)
static func copy_count(card:Dictionary,ordinary:int)->int:
	return int(card.get("custom_shop_override",{}).get("copies",ordinary))
static func configured(card:Dictionary)->bool:
	return card.get("custom_shop_override") is Dictionary and entry_error(card.custom_shop_override).is_empty()
