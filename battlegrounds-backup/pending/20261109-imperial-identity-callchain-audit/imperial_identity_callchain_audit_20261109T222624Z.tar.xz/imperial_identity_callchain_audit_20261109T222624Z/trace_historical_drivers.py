"""Parse pinned historical Python sources only. Never import or execute them."""
from pathlib import Path
import ast, collections, gc, hashlib, json, resource

resource.setrlimit(resource.RLIMIT_AS,(128*1024*1024,128*1024*1024))
H=Path(__file__).resolve().parent;R=H.parent/'historical_tools_batch14_20261109T191857Z/runtime'
IP=H.parent/'historical_tools_batch16_driver_closeout_20261109T205039Z/compiler/CURRENT_VERSIONS.json'
versions=json.loads(IP.read_text());records=[]
for version in versions:
 rel=version['paths'][0]['path'];b=(R/rel).read_bytes();assert hashlib.sha256(b).hexdigest()==version['sha256']
 source=b.decode();lines=source.splitlines();tree=ast.parse(source);nodes=list(ast.walk(tree))
 imports={}
 for n in nodes:
  if isinstance(n,ast.ImportFrom):
   for a in n.names:imports[a.asname or a.name]={'module':n.module,'name':a.name,'line':n.lineno}
 calls=[n for n in nodes if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=='compile_imperial_defender']
 record={'sha256':version['sha256'],'bytes':len(b),'representative_path':rel,
         'saved_copy_count':len(version['paths']),'imperial_calls':len(calls)}
 if not calls:records.append(record);del tree,nodes;gc.collect();continue
 assert len(calls)==1
 call=calls[0];before=call.lineno
 def snippet(a,z):return [{'line':i,'text':lines[i-1]}for i in range(a,z+1)]
 constructors=[];direct_writes=[];card_calls=[]
 for n in nodes:
  if getattr(n,'lineno',10**9)>=before:continue
  if isinstance(n,ast.Assign):
   for target in n.targets:
    if isinstance(target,ast.Name) and target.id=='cards':constructors.append({'line':n.lineno,'expression':ast.unparse(n.value),'statement':lines[n.lineno-1]})
    if isinstance(target,ast.Subscript) and isinstance(target.value,ast.Name) and target.value.id=='cards':direct_writes.append({'line':n.lineno,'statement':lines[n.lineno-1]})
  if isinstance(n,ast.Call) and any(isinstance(x,ast.Name) and x.id=='cards' for x in n.args):
   name=ast.unparse(n.func);im=imports.get(name);exists=None
   if im and im['module']:exists=(R/'tools'/(im['module'].replace('.','/')+'.py')).is_file()
   card_calls.append({'line':n.lineno,'callee':name,'import':im,'module_present_in_current_tools':exists})
 constructor_ok=len(constructors)==1 and constructors[0]['expression']=="{c['id']: c for c in raw}"
 start=max(1,call.lineno-3);end=min(len(lines),call.lineno+5)
 record.update({'cards_constructors':constructors,'own_id_comprehension':constructor_ok,
  'direct_cards_item_assignments_before_hook':direct_writes,
  'hook':snippet(start,end),'hook_arguments':[ast.unparse(x)for x in call.args],
  'lookup_immediately_before_hook':lines[call.lineno-2].strip(),
  'calls_receiving_cards_before_hook_count':len(card_calls),
  'distinct_imported_modules_receiving_cards_before_hook':len({x['import']['module']for x in card_calls if x['import']}),
  'missing_imported_modules_receiving_cards_before_hook':sorted({x['import']['module']for x in card_calls if x['module_present_in_current_tools']is False}),
  'first_mutator_boundary_calls':[x for x in card_calls if x['callee'] in ('apply_recruit_quest_identity','apply_hero_value_overrides','apply_final_source_overrides')]})
 records.append(record);del tree,nodes;gc.collect()
relevant=[x for x in records if x['imperial_calls']]
summary={'status':'HISTORICAL_AST_CONSTRUCTION_AND_CALLSITE_TRACE_ONLY','versions_checked':len(records),
 'versions_with_imperial_hook':len(relevant),'saved_copies_with_hook':sum(x['saved_copy_count']for x in relevant),
 'all_relevant_construct_cards_from_row_id':all(x['own_id_comprehension']for x in relevant),
 'all_relevant_immediate_lookup_is_cards_get_identity':all(x['lookup_immediately_before_hook']=='c=cards.get(identity)'for x in relevant),
 'all_relevant_hook_arguments_c_cards':all(x['hook_arguments']==['c','cards']for x in relevant),
 'direct_cards_item_assignments_before_hook_total':sum(len(x['direct_cards_item_assignments_before_hook'])for x in relevant),
 'cards_argument_callsite_count_range':[min(x['calls_receiving_cards_before_hook_count']for x in relevant),max(x['calls_receiving_cards_before_hook_count']for x in relevant)],
 'missing_cards_argument_module_count_range':[min(len(x['missing_imported_modules_receiving_cards_before_hook'])for x in relevant),max(len(x['missing_imported_modules_receiving_cards_before_hook'])for x in relevant)],
 'current_driver_exists':(R/'tools/build_effect_catalog.py').exists(),'current_driver_version_proven':False,
 'historical_modules_executed':False,'transitive_alias_mutation_audited':False,
 'source_inventory_sha256':hashlib.sha256(IP.read_bytes()).hexdigest(),
 'max_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
(H/'HISTORICAL_DRIVER_SUMMARY.json').write_text(json.dumps(summary,indent=2)+'\n')
with (H/'HISTORICAL_DRIVER_TRACE.json').open('w') as f:
 json.dump({'summary':summary,'records':records},f,indent=2);f.write('\n')
print(json.dumps(summary,indent=2))
