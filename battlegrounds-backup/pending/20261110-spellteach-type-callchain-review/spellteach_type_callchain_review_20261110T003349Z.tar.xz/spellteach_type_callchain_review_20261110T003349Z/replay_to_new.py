"""Replay standalone validators and explicitly stubbed function excerpts only."""
from pathlib import Path
import sys,subprocess,resource,hashlib,json
resource.setrlimit(resource.RLIMIT_AS,(128*1024**2,resource.RLIM_INFINITY))
H=Path(__file__).resolve().parent
assert len(sys.argv)==2 and Path(sys.argv[1]).is_absolute()
D=Path(sys.argv[1]);assert not D.exists();D.mkdir(parents=True)
manifest=json.loads((H/'REPLAY_INPUTS.json').read_text())
for rel,pin in manifest.items():
 b=(H/rel).read_bytes();assert len(b)==pin['bytes'] and hashlib.sha256(b).hexdigest()==pin['sha256'],rel
 p=D/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b);assert p.stat().st_ino!=(H/rel).stat().st_ino
for argv in [['run_godot.py'],['run_bounded.py','type_matrix.gd','TYPE_MATRIX'],['run_bounded.py','caller_probe.gd','CALLER_PROBE'],['verify_results.py']]:subprocess.run([sys.executable,'-B',str(D/argv[0]),*argv[1:]],check=True)
for rel,pin in manifest.items():assert hashlib.sha256((D/rel).read_bytes()).hexdigest()==pin['sha256'],rel
for rel in ['GODOT_first.json','GODOT_repeat.json','TYPE_MATRIX_1.classified.json','TYPE_MATRIX_2.classified.json','CALLER_PROBE_1.classified.json','CALLER_PROBE_2.classified.json','VERIFICATION.json']:
 assert (D/rel).read_bytes()==(H/rel).read_bytes(),rel
report={'status':'PASS_PORTABLE_LOCAL_CANDIDATE_VALIDATION_NOT_INSTALLATION','copied_files':len(manifest),'output':str(D),'selected_reports_byte_identical':True,'original_runtime_not_needed':True,'network_or_download_used':False,'full_Game_Catalog_compiler_host_old_save_not_run':True,'candidate_not_installed':True}
(D/'REPLAY_RESULT.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
