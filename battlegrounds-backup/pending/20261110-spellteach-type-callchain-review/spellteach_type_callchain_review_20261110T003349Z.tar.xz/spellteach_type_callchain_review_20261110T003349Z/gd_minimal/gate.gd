extends SceneTree
const Source=preload("res://core/spellteach_murloc_sources.gd")
const Historical=preload("res://historical/spellteach_murloc_sources.gd")
const Pool=preload("res://core/pool_identity.gd")
class ProbeCatalog extends RefCounted:
	var cards: Dictionary={}
	var source_catalog=null
	var reads: int=0
	func get_card(identity):
		reads+=1
		return cards.get(identity,{})
func _init(): call_deferred("_run")

func _key(container: Variant,key: Variant)->Variant:
	return int(key) if container is Array else key

func _all_floats(value: Variant)->Variant:
	if value is int: return float(value)
	if value is Dictionary:
		var result: Dictionary={}
		for key in value: result[key]=_all_floats(value[key])
		return result
	if value is Array:
		var result: Array=[]
		for item in value: result.append(_all_floats(item))
		return result
	return value

func _mutate(value: Variant,entry: Dictionary)->Variant:
	var op: String=entry.op
	var path: Array=entry.path
	if op=="canonical": return value
	if op=="swap_parents":
		var saved: Variant=value[Source.IDS[0]]
		value[Source.IDS[0]]=value[Source.IDS[1]]
		value[Source.IDS[1]]=saved
		return value
	if op=="rotate_all": return {Source.IDS[0]:value[Source.IDS[1]],Source.IDS[1]:value[Source.IDS[2]],Source.IDS[2]:value[Source.IDS[0]]}
	if op=="duplicate_row":
		var result: Dictionary={}
		for identity in Source.IDS: result[identity]=value[entry.target_id].duplicate(true)
		return result
	if op=="all_numbers_float": return _all_floats(value)
	if op=="merged_card":
		value.merge(Source.EXPECTED[value.id].duplicate(true),true)
		return value
	if op=="custom_card":
		value.merge(Source.EXPECTED[value.id].duplicate(true),true)
		value.source_shop_fields={"tier":3,"cost":null,"pool_supported":false}
		value.tier=4
		return value
	if op=="swap_rows": return {Source.IDS[0]:value[Source.IDS[1]],Source.IDS[1]:value[Source.IDS[0]]}
	if op=="duplicate_normal": return {Source.IDS[0]:value[Source.IDS[0]],Source.IDS[1]:value[Source.IDS[0]].duplicate(true)}
	if op=="duplicate_golden": return {Source.IDS[0]:value[Source.IDS[1]],Source.IDS[1]:value[Source.IDS[1]].duplicate(true)}
	if op=="invalid_root": return entry.value.duplicate(true) if entry.value is Array or entry.value is Dictionary else entry.value
	if op=="id_only": return {"id":value.id}
	if op=="extra_unrelated":
		value["not-a-source"]={"id":"not-a-source"}
		return value
	if op=="invalid_member":
		value[path[0]]=null
		return value
	var parent: Variant=value
	for at in range(path.size()-1): parent=parent[_key(parent,path[at])]
	var key: Variant=_key(parent,path[-1]) if not path.is_empty() else null
	var prior: Variant=parent[key] if not path.is_empty() else value
	if op=="delete":
		if parent is Array: parent.remove_at(int(key))
		else: parent.erase(key)
		return value
	var changed: Variant=null
	match op:
		"replace_value": changed=entry.value.duplicate(true) if entry.value is Dictionary or entry.value is Array else entry.value
		"id_swap": changed=Source.IDS[1] if prior==Source.IDS[0] else Source.IDS[0]
		"replace_null": changed=null
		"replace_array": changed=[]
		"replace_dict": changed={}
		"null_to_zero": changed=0
		"reverse_dict":
			changed={}
			var keys: Array=prior.keys()
			keys.reverse()
			for entry_key in keys: changed[entry_key]=prior[entry_key]
		"bool_to_int": changed=int(prior)
		"bool_to_float": changed=float(prior)
		"toggle_bool": changed=not prior
		"numeric_float": changed=float(prior)
		"numeric_int": changed=int(prior)
		"number_delta": changed=prior+1
		"number_string": changed=str(prior)
		"number_bool": changed=bool(prior)
		"change_string": changed=prior+"__changed__"
		"null_to_false": changed=false
		"extra_key":
			changed=prior.duplicate(true)
			changed["__extra__"]=true
		"append_item":
			changed=prior.duplicate(true)
			changed.append("__extra__")
		"reverse_list":
			changed=prior.duplicate(true)
			changed.reverse()
		"nan": changed=NAN
		"pos_inf": changed=INF
		"neg_inf": changed=-INF
		_: assert(false,"Unknown mutation: "+op)
	if not path.is_empty(): parent[key]=changed
	else: value=changed
	return value

func _strict_ingress(card: Variant,cards: Variant)->bool:
	# Diagnostic composition of the actual raw gate and local compiler key/id contract.
	# Actual closure_error does not itself enforce key=id; probe it separately.
	if not card is Dictionary or not cards is Dictionary or not Source.proof_error().is_empty(): return false
	if not Source.raw_error(card).is_empty(): return false
	for identity in Source.IDS:
		var row: Variant=cards.get(identity)
		if not row is Dictionary or not Source.raw_error(row).is_empty() or row.get("id")!=identity: return false
	return true

func _compiled(cards: Dictionary,outputs: Dictionary)->ProbeCatalog:
	var c=ProbeCatalog.new()
	c.cards=cards.duplicate(true)
	for identity in Source.IDS: c.cards[identity].merge(outputs[identity],true)
	return c

func _custom(row: Dictionary,tier: Variant=4,cost: Variant=3,copies: Variant=2)->void:
	row.source_shop_fields={"tier":Source.RAW[row.id].tier,"cost":Source.RAW[row.id].cost,"pool_supported":false}
	row.custom_shop_override={"tier":tier,"cost":cost,"copies":copies}
	row.tier=tier;row.cost=cost;row.pool_supported=true
func _derived(row: Dictionary,tier: Variant=4)->void:
	row.source_shop_fields={"tier":Source.RAW[row.id].tier,"cost":Source.RAW[row.id].cost,"pool_supported":false}
	row.custom_shop_derived_from=Source.IDS[0];row.tier=tier
func _unit(identity: String)->Dictionary:
	var raw: Dictionary=Source.RAW[identity]
	return {"card_id":identity,"effects":Source.PROGRAMS[identity].duplicate(true),"kind":"minion","name":raw.name,"golden":raw.is_golden,"tribes":raw.tribes.duplicate(true),"tier":raw.tier,"text":raw.text,"uid":"u101"}
func _parent_binding()->Dictionary:
	return {"uid":"u101","owner":0,"source_id":Source.IDS[0],"source_uid":"u102","purchased_uid":"u103","spell_id":"PROBE_SPELL_NOT_EXECUTED","round":1,"sequence":1,"spell_program":[{"probe_only":true}]}
func _owned_binding()->Dictionary:
	var b: Dictionary=_parent_binding();b.erase("source_uid");b.source_id="BG35_MagicItem_750";b.source_slot=0;b.acquired_event_index=0;return b
func _write_bytes(path: String,bytes: PackedByteArray)->void:
	var f=FileAccess.open(path,FileAccess.WRITE);assert(f!=null);f.store_buffer(bytes);f.close()
func _run():
	var folder: String=ProjectSettings.globalize_path("res://").path_join("..").simplify_path()
	var cases: Array=JSON.parse_string(FileAccess.get_file_as_string(folder.path_join("CASES.json")))
	var py: Dictionary=JSON.parse_string(FileAccess.get_file_as_string(folder.path_join("PYTHON_REPORT.json")))
	var outputs: Dictionary=JSON.parse_string(FileAccess.get_file_as_string(folder.path_join("ORIGINAL_OUTPUTS.json")))
	var failures: Array=[];var results: Array=[];var counts: Dictionary={}
	if not Source.proof_error().is_empty() or not Historical.proof_error().is_empty(): failures.append({"kind":"initial_proof_error"})
	for identity in Source.IDS:
		if not Source.same(outputs[identity],Source.EXPECTED[identity]): failures.append({"kind":"output_constant_mismatch","id":identity})
	for index in range(cases.size()):
		var entry: Dictionary=cases[index];var identity: String=entry.identity
		var cards: Variant=Source.RAW.duplicate(true);var card: Variant=Source.RAW[identity].duplicate(true)
		if entry.regime=="detached": card=_mutate(card,entry)
		elif entry.regime in ["coupled","companion"]:
			cards[entry.target_id]=_mutate(cards[entry.target_id],entry);card=cards[identity]
		else: cards=_mutate(cards,entry)
		var before: PackedByteArray=var_to_bytes([card,cards]);var accepted: bool=_strict_ingress(card,cards)
		var raw_accept: bool=card is Dictionary and Source.raw_error(card).is_empty()
		var historical_raw: bool=card is Dictionary and Historical.raw_error(card).is_empty()
		if raw_accept!=historical_raw: failures.append({"kind":"unexpected_historical_raw_drift","label":entry.label})
		var prior: Dictionary=py.results[index]
		if entry.label!=prior.label: failures.append({"kind":"case_alignment"})
		if accepted and not prior.original_accept: failures.append({"kind":"original_rejects_strict_positive","label":entry.label})
		var compiled_issue=null
		if prior.original_accept:
			var adjusted: Dictionary=cards.duplicate(true)
			if entry.regime=="detached": adjusted[identity]=card.duplicate(true)
			compiled_issue=Source.closure_error(_compiled(adjusted,outputs))
			if accepted and not compiled_issue.is_empty(): failures.append({"kind":"strict_positive_closure_reject","label":entry.label})
		if before!=var_to_bytes([card,cards]): failures.append({"kind":"input_mutation","label":entry.label})
		if not counts.has(entry.regime): counts[entry.regime]={"cases":0,"original_accept":0,"strict_accept":0,"original_accept_GD_reject":0,"original_exception":0,"original_accept_compiled_closure_reject":0}
		counts[entry.regime].cases+=1
		if prior.original_accept: counts[entry.regime].original_accept+=1
		if accepted: counts[entry.regime].strict_accept+=1
		if prior.original_accept and not accepted: counts[entry.regime].original_accept_GD_reject+=1
		if prior.original_error!=null: counts[entry.regime].original_exception+=1
		if compiled_issue!=null and not compiled_issue.is_empty(): counts[entry.regime].original_accept_compiled_closure_reject+=1
		results.append({"label":entry.label,"regime":entry.regime,"original_accept":prior.original_accept,"strict_accept":accepted,"actual_raw_accept":raw_accept,"historical_raw_accept":historical_raw,"compiled_closure_error":compiled_issue,"compiled_projection":"hypothetical_detached_replacement_not_actual_hook" if entry.regime=="detached" else "actual_mapping_plus_fixed_outputs","actual_hook_emitted_ids":prior.actual_hook_emitted_ids})
	var structural: Array=[]
	for op in ["canonical","swap_parents","rotate_all","duplicate_normal","missing_normal","missing_golden","missing_child","all_pool_blockers","bad_pool_blocker","custom_normal_only","custom_golden_only","custom_pair","custom_pair_mismatched_tier","custom_float_values","custom_child","custom_bool_tier","custom_extra_key"]:
		var canonical: ProbeCatalog=_compiled(Source.RAW,outputs);var c: ProbeCatalog=canonical
		if op=="swap_parents" or op=="rotate_all": c.cards=_mutate(c.cards,{"op":op,"path":[]})
		elif op=="duplicate_normal": c.cards=_mutate(c.cards,{"op":"duplicate_row","target_id":Source.IDS[0],"path":[]})
		elif op=="missing_normal": c.cards.erase(Source.IDS[0])
		elif op=="missing_golden": c.cards.erase(Source.IDS[1])
		elif op=="missing_child": c.cards.erase(Source.IDS[2])
		elif op=="all_pool_blockers":
			for identity in Source.IDS: c.cards[identity].pool_blocker=Pool.MINION_REASON
		elif op=="bad_pool_blocker": c.cards[Source.IDS[0]].pool_blocker="not-the-required-reason"
		elif op=="custom_normal_only": _custom(c.cards[Source.IDS[0]])
		elif op=="custom_golden_only": _derived(c.cards[Source.IDS[1]])
		elif op in ["custom_pair","custom_pair_mismatched_tier"]:
			c=ProbeCatalog.new();c.cards=canonical.cards.duplicate(true);c.source_catalog=canonical
			_custom(c.cards[Source.IDS[0]]);_derived(c.cards[Source.IDS[1]],5 if op=="custom_pair_mismatched_tier" else 4)
		elif op=="custom_float_values": _custom(c.cards[Source.IDS[0]],4.0,3.0,2.0)
		elif op=="custom_child": _custom(c.cards[Source.IDS[2]])
		elif op=="custom_bool_tier": _custom(c.cards[Source.IDS[0]],true)
		elif op=="custom_extra_key":
			_custom(c.cards[Source.IDS[0]]);c.cards[Source.IDS[0]].custom_shop_override.extra=true
		var issue: String=Source.closure_error(c);var old_issue: String=Historical.closure_error(c)
		if issue!=old_issue: failures.append({"kind":"unexpected_source_closure_version_drift","case":op})
		var expected: bool=op not in ["missing_normal","missing_golden","missing_child","bad_pool_blocker","custom_bool_tier","custom_extra_key"]
		if issue.is_empty()!=expected: failures.append({"kind":"structure_expectation","case":op,"issue":issue})
		structural.append({"case":op,"accepted":issue.is_empty(),"current_error":issue,"historical_error":old_issue,"arbitrary_probe_mapping_not_actual_pipeline_reachability":true})
	var effects: Array=[]
	for identity in Source.IDS:
		var ops: Array=["canonical","float_equal","bool_limit","wrong_limit","extra","nonfinite"] if identity!=Source.CHILD else ["canonical","bool_to_number","false_cannot_triple","wrong_caster","extra"]
		for op in ops:
			var e: Dictionary=Source.PROGRAMS[identity][0].duplicate(true)
			if op=="float_equal": e.limit=float(e.limit)
			elif op=="bool_limit": e.limit=true
			elif op=="wrong_limit": e.limit=99
			elif op=="extra": e.extra=true
			elif op=="nonfinite": e.limit=INF
			elif op=="bool_to_number": e.cannot_triple=1
			elif op=="false_cannot_triple": e.cannot_triple=false
			elif op=="wrong_caster": e.caster="player"
			var issue: String=Source.effect_error(e)
			if issue.is_empty()!=(op in ["canonical","float_equal"]): failures.append({"kind":"effect_expectation","id":identity,"case":op})
			effects.append({"id":identity,"case":op,"accepted":issue.is_empty(),"error":issue})
	var proof_tests: Array=[]
	for path in Source.PROOF_SHA256:
		var absolute: String=ProjectSettings.globalize_path("res://"+path);var bytes: PackedByteArray=FileAccess.get_file_as_bytes(absolute)
		for mode in ["changed_bytes","missing"]:
			if mode=="changed_bytes":
				var changed: PackedByteArray=bytes.duplicate();changed.append(32);_write_bytes(absolute,changed)
			else: assert(DirAccess.remove_absolute(absolute)==OK)
			var c: ProbeCatalog=_compiled(Source.RAW,outputs)
			var issue: String=Source.proof_error();var closure: String=Source.closure_error(c);var old_issue: String=Historical.proof_error()
			var raw_ok: bool=Source.raw_error(Source.RAW[Source.IDS[0]]).is_empty()
			_write_bytes(absolute,bytes)
			if issue!="spellteach_native_proof_changed:"+path or closure!=issue or old_issue!=issue or c.reads!=0 or not raw_ok: failures.append({"kind":"proof_expectation","path":path,"mode":mode})
			if not Source.proof_error().is_empty(): failures.append({"kind":"proof_restore_failed","path":path})
			proof_tests.append({"path":path,"mode":mode,"current_error":issue,"historical_error":old_issue,"closure_error":closure,"catalog_reads_before_reject":c.reads,"raw_gate_remains_independent":raw_ok,"isolated_copy_restored":true})
	var units: Array=[]
	var catalog: ProbeCatalog=_compiled(Source.RAW,outputs);catalog.cards["PROBE_SPELL_NOT_EXECUTED"]={"effects":[{"probe_only":true}]}
	for op in ["parent_binding","parent_alias_uid","parent_changed_program","owned_binding","owned_float_slot","owned_bool_slot","owned_slot_out_of_range","owned_negative_event","owned_alias_purchase","owned_bad_purchase_uid","owned_wrong_source","owned_extra","owned_missing_slot","owned_parent_body","binding_not_dictionary","normal_quota_1","normal_quota_2","golden_quota_2","golden_quota_3","bool_quota"]:
		var unit: Dictionary=_unit(Source.CHILD);var b: Variant=_owned_binding() if op.begins_with("owned") else _parent_binding()
		unit[Source.TAUGHT]=b
		if op=="parent_alias_uid": b.source_uid=unit.uid
		elif op=="parent_changed_program": b.spell_program=[]
		elif op=="owned_float_slot": b.source_slot=1.0;b.acquired_event_index=0.0
		elif op=="owned_bool_slot": b.source_slot=true
		elif op=="owned_slot_out_of_range": b.source_slot=8
		elif op=="owned_negative_event": b.acquired_event_index=-1
		elif op=="owned_alias_purchase": b.purchased_uid=unit.uid
		elif op=="owned_bad_purchase_uid": b.purchased_uid="u01"
		elif op=="owned_wrong_source": b.source_id="not-a-source"
		elif op=="owned_extra": b.extra=true
		elif op=="owned_missing_slot": b.erase("source_slot")
		elif op=="owned_parent_body":
			unit=_unit(Source.IDS[0]);unit[Source.TAUGHT]=b
		elif op=="binding_not_dictionary": unit[Source.TAUGHT]=[]
		elif "quota" in op:
			unit=_unit(Source.IDS[1] if op.begins_with("golden") else Source.IDS[0])
			var used: Variant=true if op=="bool_quota" else (int(op[-1]))
			unit[Source.QUOTA]={"uid":unit.uid,"id":unit.card_id,"owner":0,"round":1,"used":used}
		var current: String=Source.unit_error(unit,catalog);var historical: String=Historical.unit_error(unit,catalog)
		var expected_current: bool=op in ["parent_binding","owned_binding","owned_float_slot","normal_quota_1","golden_quota_2"]
		var expected_historical: bool=op in ["parent_binding","normal_quota_1","golden_quota_2"]
		if current.is_empty()!=expected_current or historical.is_empty()!=expected_historical: failures.append({"kind":"unit_binding_expectation","case":op,"current":current,"historical":historical})
		units.append({"case":op,"current_accept":current.is_empty(),"historical_accept":historical.is_empty(),"current_error":current,"historical_error":historical,"synthetic_validation_only_not_actual_purchase_or_cast":true})
	var report: Dictionary={"case_count":cases.size(),"counts":counts,"results":results,"structural_probes":structural,"effect_probes":effects,"proof_tests":proof_tests,"historical_current_unit_probes":units,"failures":failures,"godot_version":Engine.get_version_info(),"diagnostic_ingress_is_composition_not_single_project_entry":true,"actual_source_functions_used":true,"new_correction_created":true,"installed":false,"full_driver_Catalog_Game_hosts_or_saves_run":false}
	var output: String=OS.get_cmdline_user_args()[0];var file=FileAccess.open(output,FileAccess.WRITE);file.store_string(JSON.stringify(report,"\t")+"\n");file.close()
	print("Cases ",cases.size()," failures ",failures.size()," counts ",counts)
	quit(0 if failures.is_empty() else 1)
