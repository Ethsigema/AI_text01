extends SceneTree
const Source=preload("res://core/spellteach_murloc_sources.gd")
const Original=preload("res://fragments/caller_original.gd")
const Candidate=preload("res://fragments/caller_candidate.gd")
const POLICY="actual_bought_spell_uid_round_same_native_child_minion_cast_v1"
class ProbeCatalog extends RefCounted:
	var source_catalog=null
	func get_card(id):
		if id=="PROBE_NOT_EXECUTED":return {"effects":[]}
		var c: Dictionary=Source.RAW.get(id,{}).duplicate(true)
		if Source.EXPECTED.has(id):c.merge(Source.EXPECTED[id],true)
		return c
class NativeOwner:
	static func owner_error(_engine,_p):return ""
class Trinket:
	static func closure_error(_catalog):return ""
func _init():call_deferred("_run")
func _unit()->Dictionary:
	var raw: Dictionary=Source.RAW[Source.CHILD]
	var u: Dictionary={"card_id":Source.CHILD,"effects":Source.PROGRAMS[Source.CHILD].duplicate(true),"kind":"minion","name":raw.name,"golden":raw.is_golden,"tribes":raw.tribes.duplicate(true),"tier":raw.tier,"text":raw.text,"uid":"u101"}
	u[Source.TAUGHT]={"uid":"u101","owner":0,"source_id":"BG33_891","source_uid":"u102","purchased_uid":"u103","spell_id":"PROBE_NOT_EXECUTED","round":1,"sequence":1,"spell_program":[]}
	return u
func _event(unit:Dictionary)->Dictionary:
	return {"type":"native_spellteach_acquired","policy":POLICY,"player":0,"source_id":"BG33_891","source_uid":"u102","bought_uid":"u103","spell_id":"PROBE_NOT_EXECUTED","child_id":Source.CHILD,"child_uid":"u101","binding":unit[Source.TAUGHT].duplicate(true),"used":1,"round":1,"sequence":1}
func _run():
	var results:Array=[];var failures:Array=[];var catalog=ProbeCatalog.new()
	var engine={"catalog":catalog,"RecruitEvents":{"NativeBattlecry":NativeOwner},"SpellteachTrinket":{"Sources":Trinket}}
	for value in [["canonical","BG33_891"],["bool",true],["int",1],["array",[]],["null",null],["unknown","OTHER"]]:
		for mode in ["good_receipt_bad_unit","no_receipt_bad_unit","bad_receipt_good_unit","same_bad_both","bad_event_source","cast_entry_prefix"]:
			for version in ["original","candidate"]:
				var unit:Dictionary=_unit();var event:Dictionary=_event(unit)
				if mode in ["good_receipt_bad_unit","no_receipt_bad_unit","same_bad_both","cast_entry_prefix"]:unit[Source.TAUGHT].source_id=value[1]
				if mode in ["bad_receipt_good_unit","same_bad_both"]:event.binding.source_id=value[1]
				if mode=="bad_event_source":event.source_id=value[1]
				var player:Dictionary={"id":0,"hand":[unit]};var state:Dictionary={"round":1,"command_sequence":1,"players":[player]}
				var events:Array=[] if mode=="no_receipt_bad_unit" else [event]
				var before:PackedByteArray=var_to_bytes([state,events]);var module=Original if version=="original" else Candidate
				var label:String=version+":"+mode+":"+value[0];print("CALL_BEGIN|",label)
				var issue:String=module._entry_error(engine,player,unit) if mode=="cast_entry_prefix" else module.saved_error(state,catalog,events)
				print("CALL_END|",label)
				if var_to_bytes([state,events])!=before:failures.append({"label":label,"error":"input_mutated"})
				results.append({"label":label,"version":version,"case":value[0],"mode":mode,"returned":issue,"stubbed_dependencies_and_synthetic_state":true,"empty_return_not_acceptance_if_diagnostic":true})
	var file=FileAccess.open(OS.get_cmdline_user_args()[0],FileAccess.WRITE);file.store_string(JSON.stringify({"results":results,"failures":failures,"actual_full_saved_error_body_extracted":true,"actual_entry_prefix_only":true,"full_host_not_executed":true,"actual_game_reachability_not_proven":true},"\t")+"\n");file.close();quit(0 if failures.is_empty() else 1)
