extends SceneTree
const Candidate=preload("res://core/spellteach_murloc_sources.gd")
const Original=preload("res://original/spellteach_murloc_sources.gd")
const Historical=preload("res://historical/spellteach_murloc_sources.gd")
class ProbeCatalog extends RefCounted:
	func get_card(id):
		if id=="PROBE_NOT_EXECUTED": return {"effects":[]}
		return Candidate.RAW.get(id,{})
func _init(): call_deferred("_run")
func _values()->Array:
	return [["null",null],["bool_true",true],["bool_false",false],["int_one",1],["int_zero",0],["float_one",1.0],["float_zero",0.0],["nan",NAN],["inf",INF],["negative_inf",-INF],
	["string_parent","BG33_891"],["string_golden","BG33_891_G"],["string_trinket","BG35_MagicItem_750"],["string_child","BG33_890t"],["string_empty",""],["string_unknown","OTHER"],
	["stringname_parent",StringName("BG33_891")],["stringname_golden",StringName("BG33_891_G")],["stringname_trinket",StringName("BG35_MagicItem_750")],["stringname_empty",StringName("")],["stringname_unknown",StringName("OTHER")],
	["nodepath_parent",NodePath("BG33_891")],["nodepath_trinket",NodePath("BG35_MagicItem_750")],["nodepath_empty",NodePath("")],
	["vector2",Vector2.ZERO],["vector2i",Vector2i.ZERO],["rect2",Rect2()],["rect2i",Rect2i()],["vector3",Vector3.ZERO],["vector3i",Vector3i.ZERO],["transform2d",Transform2D.IDENTITY],["vector4",Vector4.ZERO],["vector4i",Vector4i.ZERO],["plane",Plane()],["quaternion",Quaternion.IDENTITY],["aabb",AABB()],["basis",Basis.IDENTITY],["transform3d",Transform3D.IDENTITY],["projection",Projection.IDENTITY],["color",Color.BLACK],["rid",RID()],["object",RefCounted.new()],["callable",Callable()],["signal",Signal()],
	["dictionary",{}],["array",[]],["array_parent",["BG33_891"]],["array_trinket",["BG35_MagicItem_750"]],["packed_byte",PackedByteArray()],["packed_int32",PackedInt32Array()],["packed_int64",PackedInt64Array()],["packed_float32",PackedFloat32Array()],["packed_float64",PackedFloat64Array()],["packed_string",PackedStringArray()],["packed_vector2",PackedVector2Array()],["packed_vector3",PackedVector3Array()],["packed_color",PackedColorArray()],["packed_vector4",PackedVector4Array()]]
func _unit()->Dictionary:
	var raw: Dictionary=Candidate.RAW[Candidate.CHILD]
	return {"card_id":Candidate.CHILD,"effects":Candidate.PROGRAMS[Candidate.CHILD].duplicate(true),"kind":"minion","name":raw.name,"golden":raw.is_golden,"tribes":raw.tribes.duplicate(true),"tier":raw.tier,"text":raw.text,"uid":"u101"}
func _run():
	var results: Array=[];var failure: Array=[];var catalog=ProbeCatalog.new()
	var versions: Dictionary={"candidate":Candidate,"original":Original,"historical":Historical}
	for value in _values():
		for shape in ["parent","owned"]:
			for with_catalog in [false,true]:
				var u: Dictionary=_unit();var b: Dictionary={"uid":"u101","owner":0,"source_id":value[1],"source_uid":"u102","purchased_uid":"u103","spell_id":"PROBE_NOT_EXECUTED","round":1,"sequence":1,"spell_program":[]}
				if shape=="owned": b.erase("source_uid");b.source_slot=0;b.acquired_event_index=0
				u[Candidate.TAUGHT]=b
				var should_accept: bool=(shape=="parent" and value[0] in ["string_parent","string_golden","stringname_parent","stringname_golden"]) or (shape=="owned" and value[0] in ["string_trinket","stringname_trinket"])
				for version in versions:
					var label: String=version+":"+value[0]+":"+shape+":"+str(with_catalog)
					var before: PackedByteArray=var_to_bytes(u)
					print("CALL_BEGIN|",label)
					var issue: String=versions[version].unit_error(u,catalog if with_catalog else null)
					print("CALL_END|",label)
					if before!=var_to_bytes(u) or not is_same(b.source_id,value[1]):failure.append({"label":label,"issue":"input_mutated"})
					if version=="candidate" and issue.is_empty()!=should_accept:failure.append({"label":label,"issue":"unexpected_acceptance","returned":issue})
					results.append({"label":label,"version":version,"case":value[0],"variant_type":type_string(typeof(value[1])),"shape":shape,"with_catalog":with_catalog,"returned":issue,"candidate_expected_accept":should_accept,"empty_return_not_success_if_diagnostic":true})
	# Missing source_id must reject before any direct field access in both versions.
	for version in versions:
		var u: Dictionary=_unit();u[Candidate.TAUGHT]={}
		var label: String=version+":missing_key"
		print("CALL_BEGIN|",label);var issue: String=versions[version].unit_error(u);print("CALL_END|",label)
		results.append({"label":label,"version":version,"case":"missing_key","returned":issue,"candidate_expected_accept":false})
		if issue.is_empty():failure.append({"label":label,"issue":"missing_key_accepted"})
	var out=FileAccess.open(OS.get_cmdline_user_args()[0],FileAccess.WRITE);out.store_string(JSON.stringify({"results":results,"failures":failure,"synthetic_only":true,"variant_representatives":_values().size()},"\t")+"\n");out.close()
	quit(0 if failure.is_empty() else 1)
