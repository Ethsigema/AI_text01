from pathlib import Path
import hashlib,json,re
H=Path(__file__).resolve().parent
host=(H/'original_inputs/core/spellteach_murloc_host.gd').read_text();cast=(H/'original_inputs/core/spellteach_murloc_cast.gd').read_text()
saved=host[host.index('static func saved_error('):];assert saved.count('static func ')==1
prefix=cast[cast.index('static func _entry_error('):cast.index('\tissue=card_error(engine.catalog,str(binding.spell_id))')]
policy=next(x for x in host.splitlines() if x.startswith('const POLICY:'))
records=[]
for version,path in [('original','original'),('candidate','core')]:
 s='extends RefCounted\nconst Sources=preload("res://'+path+'/spellteach_murloc_sources.gd")\n'+policy+'\n'+'''# Explicit test stubs, not real host dependencies or proof of full reachability.
class Owned:
	static func saved_receipts(_state,_catalog,_events): return {"error":"","receipts":{}}
class Cast:
	const ORIGIN="native_apprentice_actual_hand_minion_cast"
	static func card_error(_catalog,id): return "" if id=="PROBE_NOT_EXECUTED" else "PROBE_STUB_UNKNOWN_SPELL"
'''+saved+'\n'+prefix+'\treturn "PROBE_PREFIX_REACHED_END_NOT_ACCEPTANCE"\n'
 p=H/'gd_minimal/fragments'/f'caller_{version}.gd';p.parent.mkdir(exist_ok=True);p.write_text(s)
 records.append({'output':str(p.relative_to(H)),'sha256':hashlib.sha256(s.encode()).hexdigest(),'saved_error_exact_original_function_sha256':hashlib.sha256(saved.encode()).hexdigest(),'cast_entry_prefix_exact_original_sha256':hashlib.sha256(prefix.encode()).hexdigest(),'scope':'Full saved_error function body with explicit Owned/Cast stubs, plus exact _entry_error prefix through trinket-closure guard then diagnostic sentinel. No complete host loaded.'})
(H/'EXTRACTED_FUNCTIONS.json').write_text(json.dumps(records,indent=2)+'\n')
