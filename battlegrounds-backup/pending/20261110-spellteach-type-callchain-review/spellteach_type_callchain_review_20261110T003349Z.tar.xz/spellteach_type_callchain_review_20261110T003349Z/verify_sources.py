from pathlib import Path
import json,hashlib,resource
resource.setrlimit(resource.RLIMIT_AS,(128*1024**2,resource.RLIM_INFINITY))
H=Path(__file__).resolve().parent;W=H.parent;R=W/'historical_tools_batch14_20261109T191857Z/runtime'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
checked=[]
for row in json.loads((H/'INPUT_PINS.json').read_text()):
 p=W/row['source'];assert p.stat().st_size==row['bytes'] and sha(p)==row['sha256'],p
 assert sha(H/row['copy'])==row['final_copy_sha256'];checked.append(str(p))
for row in json.loads((H/'static_callchain/SOURCE_PINS.json').read_text()):
 p=Path(row['path']);assert p.stat().st_size==row['bytes'] and sha(p)==row['sha256'],p;checked.append(str(p))
text=(R/'core/spellteach_murloc_sources.gd').read_text();proof=json.loads(next(s.split('=',1)[1] for s in text.splitlines() if s.startswith('const PROOF_SHA256:')))
for rel,pin in proof.items():assert sha(R/rel)==pin;assert sha(H/'gd_minimal'/rel)==pin;checked.append(str(R/rel))
archives={
 'remaining_tools_readonly_audit_20261109T215306Z.tar.xz':'9eb4be705ee386167956350de3212845a70b664148f8dddeb3aed540da5c12ba',
 'imperial_defender_candidate_review_20261109T220940Z.tar.xz':'19750c8aa7ad3117befab977d8dd338fbb934d5ed5c958cf373a52e71e54bde0',
 'imperial_identity_callchain_audit_20261109T222624Z.tar.xz':'f77e2a104017e743ee7c529feeef9bd4137367cacfcee65e2c34252139e9f846',
 'old_murkeye_candidate_review_20261109T224622Z.tar.xz':'d88441dae609ab923b743b15fc4d32f37b25996012b7217888e5a99c4babb9ef',
 'compiler_pin_contract_audit_20261109T230342Z.tar.xz':'c92e371e0dbb447093d9348f558dc7bfd2b75056eba36a38e99d3a738901be87',
 'historical_tools_batch16_dependency_audit_20261109/historical_tools_batch16_xml_original_candidate_20261109.tar.xz':'3d37a9d1a0ee2d61939e88f8ced995622ca22fd84ba7f9dabe8c4f2df6bafa7d',
 'titanic_guardian_readonly_probe_20261109T232356Z.tar.xz':'b7ea490684bb5b9ef1db93f4ad0c8c5d0c46c8da431ac4e8007fe5c28ecc75ca',
 'titanic_guardian_correction_review_20261109T234448Z.tar.xz':'005f831d5c3a1f6833a935014e182bfe14adbec017da0a26a472f21190ff0c19',
 'spellteach_murloc_readonly_probe_20261110T000457Z.tar.xz':'2ccad346879d2b1fe0cd4f020b338d5a7d403bcff92f9312a1df4a4fbf046414'}
for rel,pin in archives.items():assert sha(W/rel)==pin,rel
scope=json.loads((W/'historical_tools_batch15_20261109T195018Z/REMAINING_SCOPE.json').read_text())['remaining_targets']
assert len(scope)==345
missing=[p for p in scope if not (R/p).exists()];assert len(missing)==345
assert not (R/'evidence/portable_legacy/CardDefs.Bacon_latest.xml').exists()
assert sha(R/'core/game.gd')=='84ea17caff1c22d082badf6118f8fdde02e35616d4d156b28430b02313504410'
assert sha(R/'core/catalog.gd')=='5ba81a78d4924e4596dada5cb8f1a9ad5877d7bed6c7d350ca370d8bff955a72'
report={'status':'SOURCE_AND_OLD_ARCHIVE_READBACK_MATCH','source_pin_records_checked':len(checked),'unique_source_paths':len(set(checked)),'old_archives':archives,'remaining_tools_missing':345,'XML_candidate_not_installed':True,'original_game_and_catalog_sha_unchanged':True,'original_source_and_candidate_are_separate':True,'rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
(H/'FINAL_SOURCE_VERIFICATION.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
