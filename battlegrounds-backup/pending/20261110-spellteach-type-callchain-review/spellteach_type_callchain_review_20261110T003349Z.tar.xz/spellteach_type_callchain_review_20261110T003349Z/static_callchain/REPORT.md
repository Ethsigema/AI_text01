# Spellteach source_id 异类型诊断的静态调用与返回值审查

## 核心结论

1. 当前 `Sources.unit_error` 在第 65 行只检查 TAUGHT 是 Dictionary，第 66 行立即将 `row.get("source_id")` 与 String 作 `==`。这之前没有针对这个嵌套字段的 String/成员类型门控；第 68/70 行的具体分支字段校验发生在比较之后。既有隔离 Godot 证据已记录 bool/int/Array 各两次诊断并使调用者收到空 String；本轮没有重跑 Godot，空返回不算正常通过。
2. 调用侧大多仅用 `not issue.is_empty()` 决定是否拒绝。其确有真实 owner、对象身份、商店/手牌、购买完成、事件、原槽和完整收据等保护，但这些保护不能统一描述成“source_id 的前置类型门控”。有的在 `unit_error` 之后才检查。
3. `Spellteach.saved_error` 的单位循环先调用 `unit_error`（144），后比较整份 binding 和收据（154）。如果仅单位的 source_id 被合成污染、收据缺失或仍正常，后置的缺收据/`Sources.same` 条件可以拒绝；这是**诊断后的后置拒绝**，不等于没有诊断。若污染的是事件 binding，119 行会在单位循环之前直接比较 source_id；饰品收据还有独立的直接比较点。它们是单独待测的异常边界。
4. 加载链确实静态连接到 `unit_error`。本轮可见外层门控只要求单位是 Dictionary、uid/card_id 为 String，没有显式约束 TAUGHT.source_id。加载使用私有候选引擎，返回 OK 后才发布到 live 引擎。但大量其他家族检查未执行或穷尽审计，因此**不能由未见此字段门控推成完整加载或真实游戏故障可达**。
5. 正常购买写入 binding 的源码使用已限定的父体 card_id 或固定饰品 String 常量，未发现这两条本地写入路径会主动制造 bool/int/Array source_id。既有当前 Catalog 目标数据一致性证据不是存档/实际手牌证据。本轮不读取玩家旧存档，不声称真实数据污染、交易绕过或游戏事故。

所有引用来自固定的本地源树，完整 SHA-256 见 SOURCE_PINS.json；精确行号片段见 EXCERPTS.md。仅在本目录新增报告与只读切片，没有改源树或旧证据包。

## 1. 证据等级与范围

- **既有动态证据**：旧包 `type_boundary_probe/RESULT.json` 与 `TYPE_BOUNDARY.stdout.log`。bool/int/Array 六次记录均有一条真实 script error，当前返回空 String；null 两次是正常拒绝。此次只是阅读并固定这些证据的哈希，不将其算作新执行。
- **本轮静态证据**：下面的真实调用点、返回值使用、字段写入和顺序。没有实例化或加载任何 Game、host、完整 Catalog、完整 compiler，也没有运行历史作者脚本。
- **合成输入**：仅假设原探针那样“其余必要字段合法，只将 TAUGHT.source_id 换为异类型”。讨论这种输入在一个函数内部会走到哪条语句，不证明某真实入口能产生或接受它。
- **真实游戏可达**：未证明。没有真实购买、取得饰品、教授、手牌打出、施放、战斗、保存/加载操作。不得将“有静态调用边”和“局部空返回”合并成已复现游戏绕过。
- **既有数据**：旧包 static_contract/CURRENT_TARGET_DATA.json 记录 raw/compiled 共六条目标行与 RAW/EXPECTED 严格匹配。该项此次没有重扫约 30 MB 的 Catalog 数据，也不代表实际私有 binding 或事件状态。

## 2. Sources.unit_error 本身的顺序

`core/spellteach_murloc_sources.gd:50–75`：

- claimed/body 身份、完整程序、kind/name/golden/tribes/tier、可选 catalog tier、物理 uid、text 和可选 QUOTA 先行。
- TAUGHT 分支第 65 行只拒绝非 Dictionary；第 66 行即比较其 source_id。
- 饰品分支随后才要求 CHILD、11 个精确字段、slot、取得事件序号、各 UID/owner/round/sequence 和法术类型。
- 普通分支随后才要求 CHILD、10 个精确字段、source_id 属于 PARENTS、各 UID/owner/round/sequence 和法术类型。
- 第 73 行比较绑定 spell_program 与 catalog 中该法术程序；本函数本身不读取实际购买收据。

`Sources.same` 委托 `phase_undead_army_sources.gd:8–21`：数值 int/float 可以相等，非数值先按 typeof 拒绝，Dictionary/Array 递归比较。因此正常 String 收据与 bool/int/Array 单位字段不相等，不需要执行异类型 String `==`。

## 3. 保存、加载与统一命令预检

### 保存

`Game.save_to` 在 13840 拒绝未结束的 Spellteach contexts，13842 调 `Spellteach.saved_error`，非空返回 ERR_INVALID_DATA；正常继续后 14131 JSON.stringify，14132 AtomicSaveFile.write_text。未执行此路径。

### 加载

精确静态链：

- `load_from:14134–14145`：JSON.parse_string；envelope 与 room 必须 Dictionary；CurrentScope.room_errors；进入 `_load_scoped_game`。
- `_load_scoped_game:14147…14349`：大量 live busy gates，包括 14273 的三个 Spellteach contexts；14341 新建私有 candidate，14342 调 candidate._read_scoped_game。非 OK 14343 返回。只有成功才 14346–14348 发布脚本变量。
- `_read_scoped_game:14351…`：版本、其他家族 serialized/saved 检查；14487 `_normalize_numbers`；room 验证与 effective catalog/fingerprint；14496 设置候选 catalog；14497 `_valid_save`。
- `_valid_save:15302–15308`：对 hand/board/shop/mechanism_reward_queue 单位，15303 要求 Dictionary 且 uid/card_id String；另外三项家族检查后调 `_valid_unit_state`。
- `_valid_unit_state:16223`：`if not Spellteach.Sources.unit_error(unit,catalog).is_empty(): return false`。前面是其他家族校验，没有本函数内显式 TAUGHT.source_id 类型检查。
- `_valid_save:15323` 对 minion 还会调 `Combat.new()._validate_unit`，其 `combat.gd:2142–2143` 再调用 unit_error，仍只按非空拒绝。
- 最后 `_valid_save:15537` 才调 Spellteach.saved_error，非空返回 false。这个最终收据校验不是前两次 unit_error 的前置门控。

`_normalize_numbers:14722–14728` 递归将整值 float 改为 int；bool、Array 和 Dictionary 结构保留，不会把 source_id 改成 String。JSON 可表达 bool、数值、Array 只说明可构造文档形状，不说明该文档可通过其他入口检查。

以上函数内找不到显式该私有字段 guard，只能陈述为“本轮可见门控没有”；未执行或逐个解析所有其他家族校验，不声称已穷尽其间的隐式拒绝条件。

### 统一命令预检和展示操作

一般命令在 `apply_command:2057` 落到 `_apply_azshara_triple_body`（有若干专门路由，不能说所有命令都必经同一条链）。普通体 2477 拒绝嵌套 Spellteach context；2784–2785 调 saved_error 后按非空 `_fail`；2946–2947 调 `_prize_zone_source_error`，后者 5888 调 `_prize_source_error`。

`_prize_source_error:5844` 对 claimed 直接转交 unit_error；该函数还用于 play 4391、_prize_play_error 5935、legal action 扫描 13017。`_prize_zone_source_error` 有 12889 的 legal-action 前置使用。空 String 在这些条件中不会触发其显式错误分支，但这不等于后续完整操作成功。

Ghost 特殊边界：`_valid_ghost:15740` 直接拒绝含 QUOTA 或 TAUGHT 的 ghost，属于这一独立路径的明示私有状态拒绝，不能推广到 hand/board 的正常单位加载。

## 4. 购买、交付与施放

### 普通/金色父体购买

- `Game:3555–3558` 调普通与饰品 prepare_buy，`ok=false` 时 `_fail`。
- 普通 `host.prepare_buy:44–72` 要求真实招募 owner/原 shop 对象/无嵌套；48 saved_error，49 closure，再核法术与观察者；限定支付、容量和真实 command。
- `sources:13–14` 只选择 card_id 在 PARENTS 内的 active board source。59 unit_error，60 只按非空拒绝。
- `mark_paid:73–77` 核真实对象身份和扣款；`dispatch:78–104` 核完成购买、仍是原 board source、配额/法术未变、交付容量、preview 与 actual。
- 93 的 binding.source_id 来自该原父体 source.card_id，99 复制同一 binding 到真实 child；102 观察 engine error；103 检验整个投影；104 写收据。
- Game 3625–3628 处理 paid，3707–3708 处理 dispatch，3720–3723 处理两种 finish，均非空拒绝。

这些门控对正常写入来源有实质意义；它们不是“任意坏 binding 字段先被类型检查”的证明。

### 饰品购买

- `Sources.ID` 是 `spellteach_trinket_sources.gd:5` 的固定 String `BG35_MagicItem_750`。
- `owner_error:18–30` 检查单一实际槽及 ledger；`acquired:54–64` 绑定实际事件 ticket，61 写固定 source_id 与实际 slot/event index。
- `prepare_buy:65–87` 检查 ledger、每轮最多两次、实际 shop 与 owner/command、saved_error、法术/观察者、支付与容量。
- `paid:88–92` 和 `dispatch:93–118` 检查实际购买完成、原 ledger 和法术不变；107 写固定 String source_id；113 复制给真实 child；115 调 _add_hand，116–117 检验错误与整个投影，118 写完整收据。
- `mechanism_effects.on_event:234–239` 接线真实取得/buy，非空走 _eot_fail；Game 8532–8533 接线 acquisition_error。

### 入手交付

`Game._add_hand:9947–9955` 包装前后 Gladiator 规则；`_add_hand_before_gladiator:9978–9980` 调 unit_error，非空时 `_return_unit`、`_native_result(ok=false)` 并返回。`_native_result:16947–16951` 在失败时将 phase 设 error 并记 coverage_error。现有空 String 诊断返回不会自行触发这一非空分支；其他前后条件未执行，不据此断言坏单位实际被加入。

### 手动打出与 minion-cast

- Game 4391 先经 _prize_source_error，再在 4454–4455 调 `Cast.prepare`。
- `Cast.prepare:89–96` 先核实际 Game（Actual._actual_game_host 检查脚本链）、owner、recruit、实际 hand 对象、容量、active、可选 play command，再 `_entry_error`。
- `_entry_error:23` 第一项就是 unit_error，24 closure，25 owner 校验；26 非空拒绝。28 取 binding，29 owner 比较，30 再直接比较 binding.source_id 与饰品 String，33 起核真实法术和 repeat 等条件。
- prepare 95 在 `_entry_error` 空时再调用 saved_error，96 非空拒绝。30 的第二次直接 String 比较是独立潜在诊断点；本轮不猜测其发生后的具体 Godot 返回传播，建议下述片段实测。
- commit 119 起要求真实 ticket、owner/source/command、board 对象、repeat、phase/round/sequence 和投影等相符；Game 5114–5118、5196–5197、5254–5255 分别检查 commit/completed/finish。没有执行这些链。

## 5. saved_error 的前后拒绝与不同污染位置

`host.saved_error:111–156` 的顺序很重要：

1. 112 先 `Owned.saved_receipts`，113 读其 error。
2. 普通取得事件循环：117 的 event.source_id 必须在 PARENTS；118 取 event.binding；119 精确键检查之后直接 `binding.source_id != event.source_id`，没有单独的 String 类型 guard。一个源字段正确的事件、配一个异型 binding 字段，可能在这里诊断，早于 unit_error。
3. 取得次数、重复购买与施放事件账本检查。
4. 139–145 才逐单位调用 unit_error；145 仅非空拒绝。
5. 147–151 核父体 quota 与不能移除 binding；153 取单位 binding；154 检查 owner/round/sequence、receipt 存在，并用 Sources.same 比较完整 receipt.binding。该行没有第二次直接读 unit.binding.source_id 比较。

限定结论：若其余字段合法、仅单位的 source_id 异型，而收据不存在或来自正常路径，则静态上 154 可后置拒绝。相反，若事件 binding 也被异型污染，119 的独立诊断会更早触发，不能套用“154 总会兜住”的说法。实际默认返回传播应通过逐字函数片段单独测量，而不是假定异常自动等于失败。

饰品 `saved_receipts:125–159` 也有独立边界：先 owner_error；`owner_error:26` 直接比较 ledger.source_id；147 直接比较 event.source_id；150 直接比较 event.binding.source_id。这里只列静态比较点，未将它们宣称为已复现的新问题。

## 6. 可安全继续的最小实际片段

本包 `fragments/*.gd.txt` 是**原字节函数切片**，未运行。FRAGMENT_INDEX.json 给出原行范围和切片 SHA-256。它们不是整个 host 的运行证明，也不是修正版本。

建议按风险从低到高：

1. 已有最小 Sources 三文件方式继续测 `unit_error`，保留全部真实诊断，合法 binding 对照与 bool/int/Array/null 对照，分开记录 return 与日志。
2. 精确 `saved_error:111–156` 函数，绑定真实 Sources、ProbeCatalog，显式 `Owned.saved_receipts` stub 返回 `{error:"", receipts:{}}`，显式 `Cast.card_error` stub。先测空事件/无收据的坏单位；再测真实形状的普通取得事件与正确 binding + 坏单位；再将事件 binding 单独污染。标注所有 fixture、stub、跳过的 closure/owned/法术证明，绝不能叫真实存档验证。
3. 精确 `owner_error` + `saved_receipts`，必要时以固定 Sources.ID/closure stub 和 Cast stub 运行。分别污染 ledger、event.source_id、event.binding.source_id，观察先后与 Dictionary 默认返回；不要把未知返回擅自当作 `{error:""}`。
4. 精确 `_entry_error` 片段若要测，依赖较多。只追到 30 行的诊断需显式允许前面 closure/owner stub；继续时要带可计数 sentinel stub，并证明未调用后续实际 effects。优先不扩大测试范围。
5. `_normalize_numbers` 是独立递归小函数，可用 bool/int/Array 值说明加载归一化不会提供 source_id String 类型门控；它不能代替 `_valid_save`。

不得加载整份 host 去获得这些函数，因为其 preload 会牵入大量执行依赖。不得调用 Game、Combat、真实 Catalog 或全编译器；也不应为证明这一个字段边界而放宽实际 host/capability 检查。

仅修改 Sources 第 66 行的独立候选，若能干净拒绝坏 binding，将使经过 unit_error 的后续路径提前停止；但它不自动覆盖事件 binding/slot ledger 自己的直接比较，也不闭合整体集成验收。本轮没有制作、应用或认可任何修正。

## 7. 文件与复核

- SOURCE_PINS.json：11 份当前源码与 5 份旧证据的完整 SHA-256。
- EXCERPTS.md：关键入口、前后拒绝、发布边界和比较位置的带行号原文。
- FRAGMENT_INDEX.json 和 fragments：7 个逐字函数切片，仅供独立测试设计。
- RECHECK.json：这些源/旧证据从采集到末次回读未变，包含低资源 Python 的峰值 RSS。
- FILES_SHA256.json：本目录封包文件白名单及 SHA-256。

无联网、下载、凭据/缓存/私聊/旧存档访问；没有访问禁止目录，没有重试已取消操作，没有修改旧包或源树。RECHECK 的不变性时间范围是本轮采集到回读，不虚称整个工程所有文件都已扫描。
