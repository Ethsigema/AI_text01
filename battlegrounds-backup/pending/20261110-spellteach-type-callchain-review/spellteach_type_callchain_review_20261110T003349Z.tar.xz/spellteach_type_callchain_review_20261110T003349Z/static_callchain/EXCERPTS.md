# Pinned read-only source excerpts

Line numbers refer to source originals; omitted ranges are not claimed to be audited.

## core/spellteach_murloc_sources.gd:16-21

```text
16: static func same(a: Variant,b: Variant) -> bool: return Exact.same(a,b)
17: static func integer(v: Variant,low: int=0,high: int=2147483647) -> bool: return (v is int or v is float) and not v is bool and is_finite(float(v)) and v==floor(float(v)) and v>=low and v<=high
18: static func uid(v: Variant) -> bool: return v is String and v.begins_with("u") and v.substr(1).is_valid_int() and int(v.substr(1))>0 and str(int(v.substr(1)))==v.substr(1)
19: static func fields(v: Variant,keys: Array) -> bool: return v is Dictionary and v.size()==keys.size() and keys.all(func(key):return v.has(key))
20: static func claimed(card: Dictionary) -> bool:
21: 	return card.get("id",card.get("card_id")) in IDS or card.has(QUOTA) or card.has(TAUGHT) or card.get("effects",[]).any(func(e):return e is Dictionary and e.get("type") in [TYPE,CAST])
```

## core/spellteach_murloc_sources.gd:43-78

```text
43: 	if not issue.is_empty(): return issue
44: 	for current in [catalog.source_catalog if catalog.source_catalog!=null else catalog,catalog]:
45: 		for id in IDS:
46: 			issue=source_error(current.get_card(id))
47: 			if not issue.is_empty(): return issue
48: 	return ""
49: static func effect_error(effect: Dictionary) -> String: return "" if effect.get("source_id") in IDS and same([effect],PROGRAMS[effect.source_id]) else "spellteach_changed_whole_program"
50: static func unit_error(unit: Dictionary,catalog=null) -> String:
51: 	if not claimed(unit): return ""
52: 	if unit.has("id") and not unit.has("card_id"): return source_error(unit)
53: 	if unit.get("card_id") not in IDS: return "spellteach_foreign_body"
54: 	var id: String=unit.card_id;var raw: Dictionary=RAW[id]
55: 	if not same(unit.get("effects"),PROGRAMS[id]) or unit.get("kind","minion")!="minion" or unit.get("name")!=raw.name or unit.get("golden")!=raw.is_golden or not same(unit.get("tribes"),raw.tribes) or not integer(unit.get("tier"),1,7): return "spellteach_native_body_changed"
56: 	if catalog!=null and unit.tier!=catalog.get_card(id).get("tier"): return "spellteach_effective_tier_changed"
57: 	if not unit.has("uid"): return "spellteach_private_state_on_template" if unit.has(QUOTA) or unit.has(TAUGHT) else "" # Native base templates carry no private state.
58: 	if not uid(unit.uid): return "spellteach_invalid_physical_uid"
59: 	if unit.get("text")!=raw.text: return "spellteach_native_text_changed"
60: 	if unit.has(QUOTA):
61: 		var row: Variant=unit[QUOTA]
62: 		if id not in PARENTS or not fields(row,["uid","id","owner","round","used"]) or row.uid!=unit.uid or row.id!=id or not integer(row.owner) or not integer(row.round,1) or not integer(row.used,1,int(PROGRAMS[id][0].limit)): return "spellteach_invalid_per_physical_source_quota"
63: 	if unit.has(TAUGHT):
64: 		var row: Variant=unit[TAUGHT]
65: 		if not row is Dictionary: return "spellteach_invalid_actual_purchase_binding"
66: 		if row.get("source_id")=="BG35_MagicItem_750":
67: 			# Owned source is an actual acquired slot, never a fabricated minion UID.
68: 			if id!=CHILD or not fields(row,["uid","owner","source_id","source_slot","acquired_event_index","purchased_uid","spell_id","round","sequence","spell_program"]) or row.uid!=unit.uid or not integer(row.source_slot,0,7) or not integer(row.acquired_event_index) or not uid(row.purchased_uid) or row.uid==row.purchased_uid or not integer(row.owner) or not integer(row.round,1) or not integer(row.sequence,1) or not row.spell_id is String or not row.spell_program is Array: return "spellteach_invalid_owned_purchase_binding"
69: 		else:
70: 			if id!=CHILD or not fields(row,["uid","owner","source_id","source_uid","purchased_uid","spell_id","round","sequence","spell_program"]) or row.uid!=unit.uid or row.source_id not in PARENTS or not uid(row.source_uid) or not uid(row.purchased_uid) or not integer(row.owner) or not integer(row.round,1) or not integer(row.sequence,1) or not row.spell_id is String or not row.spell_program is Array: return "spellteach_invalid_actual_purchase_binding"
71: 			if row.uid in [row.source_uid,row.purchased_uid] or row.source_uid==row.purchased_uid: return "spellteach_aliased_purchase_binding"
72: 		if catalog!=null and not same(row.spell_program,catalog.get_card(row.spell_id).get("effects")): return "spellteach_changed_taught_program"
73: 	return ""
74: static func inheritance_error(originals: Array) -> String:
75: 	return "spellteach_private_quota_or_teaching_migration_partial" if originals.any(func(unit):return unit.has(QUOTA) or unit.has(TAUGHT)) else ""
```

## core/spellteach_murloc_host.gd:10-15

```text
10: const POLICY: String="actual_bought_spell_uid_round_same_native_child_minion_cast_v1"
11: static func fail(issue: String) -> Dictionary: return {"ok":false,"error":issue,"active":false}
12: static func actual(engine,p: Dictionary) -> bool: return Actual._actual_game_host(engine) and engine.state.get("phase")=="recruit" and p.get("alive")==true and engine.state.players.any(func(owner):return is_same(owner,p))
13: static func sources(p: Dictionary,round_number: int) -> Array:
14: 	return p.get("board",[]).filter(func(unit):return unit.get("card_id") in Sources.PARENTS and Pure.Gains.active(unit) and used(unit,round_number)<int(Sources.PROGRAMS[unit.card_id][0].limit))
15: static func used(unit: Dictionary,round_number: int) -> int: return int(unit.get(Sources.QUOTA,{}).get("used",0)) if unit.get(Sources.QUOTA,{}).get("round")==round_number else 0
```

## core/spellteach_murloc_host.gd:44-156

```text
44: static func prepare_buy(engine,p: Dictionary,spell: Dictionary,quoted: Dictionary,issued: bool=true) -> Dictionary:
45: 	if spell.get("kind")!="spell" or not engine.Mechanisms.is_tavern_spell_card(engine.catalog.get_card(str(spell.get("card_id","")))) or sources(p,int(engine.state.round)).is_empty(): return {"ok":true,"error":"","active":false}
46: 	if not actual(engine,p) or not p.shop.any(func(unit):return is_same(unit,spell)): return fail("spellteach_actual_shop_offer_required")
47: 	if not engine._spellteach_buy_context.is_empty(): return fail("spellteach_nested_buy")
48: 	var issue: String=saved_error(engine.state,engine.catalog,engine.events)
49: 	if issue.is_empty(): issue=Sources.closure_error(engine.catalog)
50: 	if issue.is_empty(): issue=spell_error(engine,spell)
51: 	if issue.is_empty(): issue=_observers_error(engine,p)
52: 	if not issue.is_empty(): return fail(issue)
53: 	if not quoted.get("ok",false) or not Sources.integer(quoted.get("cost")) or ["health_currency","bouncy_health_offer","eye_sargeras_health","tapestry_health_currency","owned_health_currency","bazaar","pilgrimp"].any(func(key):return quoted.get(key,false)): return fail("spellteach_non_gold_quote_partial")
54: 	if p.hand.size()+1+sources(p,int(engine.state.round)).size()>10: return fail("spellteach_overflow_quota_semantics_partial")
55: 	var command: Dictionary=engine._bounty_spend_command
56: 	if issued and (not is_same(command.get("owner"),p) or command.get("action")!="buy" or command.get("round")!=engine.state.round or command.get("sequence")!=engine.state.command_sequence): return fail("spellteach_real_buy_command_required")
57: 	var records: Array=[]
58: 	for source in sources(p,int(engine.state.round)):
59: 		issue=Sources.unit_error(source,engine.catalog)
60: 		if not issue.is_empty(): return fail(issue)
61: 		records.append({"source":source,"uid":source.uid,"id":source.card_id,"before":source.get(Sources.QUOTA,{}).duplicate(true),"used":used(source,int(engine.state.round)),"done":false})
62: 	# Preflight complete accepted purchased-spell plus generated-minion domain.
63: 	var state: Dictionary=Pure._state(engine,p);state.next_uid=engine.next_uid;state.pool=engine.pool.duplicate(true);state.spell_pool=engine.spell_pool.duplicate(true)
64: 	issue=Delivery.project(engine,state,spell.duplicate(true),true)
65: 	if not issue.is_empty(): return fail(issue)
66: 	for record in records:
67: 		var child: Dictionary=engine._preview_native_minion(engine.catalog.get_card(Sources.CHILD),"u"+str(state.next_uid))
68: 		if child.is_empty(): return fail("spellteach_native_child_factory_rejected")
69: 		state.next_uid+=1
70: 		issue=Delivery.project(engine,state,child)
71: 		if not issue.is_empty(): return fail(issue)
72: 	return {"ok":true,"error":"","active":true,"owner":p,"spell":spell,"spell_id":spell.card_id,"spell_uid":spell.uid,"spell_program":spell.effects.duplicate(true),"command":command,"round":engine.state.round,"sequence":engine.state.command_sequence,"cost":quoted.cost,"gold_before":p.gold,"bought_before":p.stats.bought,"paid":false,"records":records}
73: static func mark_paid(engine,p: Dictionary,spell: Dictionary,cost: int) -> String:
74: 	var ticket: Dictionary=engine._spellteach_buy_context
75: 	if ticket.is_empty(): return ""
76: 	if not actual(engine,p) or not is_same(ticket.owner,p) or not is_same(ticket.spell,spell) or not is_same(ticket.command,engine._bounty_spend_command) or ticket.paid or cost!=ticket.cost or p.gold!=ticket.gold_before-cost: return "spellteach_actual_payment_changed"
77: 	ticket.paid=true;return ""
78: static func dispatch(engine,p: Dictionary,spell: Dictionary,source: Dictionary) -> String:
79: 	var ticket: Dictionary=engine._spellteach_buy_context
80: 	if ticket.is_empty(): return ""
81: 	var records: Array=ticket.records.filter(func(row):return is_same(row.source,source))
82: 	if records.is_empty(): return ""
83: 	var record: Dictionary=records[0]
84: 	if not actual(engine,p) or not is_same(ticket.owner,p) or not is_same(ticket.spell,spell) or not is_same(ticket.command,engine._bounty_spend_command) or ticket.round!=engine.state.round or ticket.sequence!=engine.state.command_sequence or not ticket.paid or record.done or p.stats.bought!=ticket.bought_before+1 or p.shop.any(func(unit):return is_same(unit,spell)) or not p.hand.any(func(unit):return is_same(unit,spell)): return "spellteach_unissued_successful_purchase"
85: 	if not p.board.any(func(unit):return is_same(unit,source)) or source.uid!=record.uid or source.card_id!=record.id or not Pure.Gains.active(source) or not Sources.same(source.get(Sources.QUOTA,{}),record.before) or spell.uid!=ticket.spell_uid or spell.card_id!=ticket.spell_id or not Sources.same(spell.effects,ticket.spell_program): return "spellteach_original_source_or_spell_changed"
86: 	if p.hand.size()>=10: return "spellteach_unplanned_delivery_capacity_change"
87: 	var state: Dictionary=Pure._state(engine,p);state.next_uid=engine.next_uid;state.pool=engine.pool.duplicate(true);state.spell_pool=engine.spell_pool.duplicate(true)
88: 	var quota: Dictionary={"uid":source.uid,"id":source.card_id,"owner":p.id,"round":engine.state.round,"used":int(record.used)+1}
89: 	Pure.Gains._find(state.player.board,str(source.uid))[Sources.QUOTA]=quota.duplicate(true)
90: 	var child: Dictionary=engine._preview_native_minion(engine.catalog.get_card(Sources.CHILD),"u"+str(state.next_uid))
91: 	if child.is_empty(): return "spellteach_native_child_factory_failed"
92: 	child.pool_count=0;child.pool_id="";child.pool_components=[];state.next_uid+=1
93: 	child[Sources.TAUGHT]={"uid":child.uid,"owner":p.id,"source_id":source.card_id,"source_uid":source.uid,"purchased_uid":spell.uid,"spell_id":spell.card_id,"round":engine.state.round,"sequence":engine.state.command_sequence,"spell_program":spell.effects.duplicate(true)}
94: 	var expected_child: Dictionary=child.duplicate(true)
95: 	var issue: String=Delivery.project(engine,state,child)
96: 	if not issue.is_empty(): return issue
97: 	record.done=true;source[Sources.QUOTA]=quota
98: 	var generated: Dictionary=engine._unit(engine.catalog.get_card(Sources.CHILD))
99: 	generated.pool_count=0;generated.pool_id="";generated.pool_components=[];generated[Sources.TAUGHT]=expected_child[Sources.TAUGHT].duplicate(true)
100: 	if not Sources.same(generated,expected_child): return "spellteach_actual_child_factory_changed"
101: 	engine._add_hand(p,generated)
102: 	if engine.state.phase=="error": return "spellteach_actual_accepted_child_failed"
103: 	if not Sources.same(snapshot(engine,p),projected(state)): return "spellteach_accepted_hand_cursor_changed"
104: 	engine._log("native_spellteach_acquired",{"player":p.id,"source_id":source.card_id,"source_uid":source.uid,"bought_uid":spell.uid,"spell_id":spell.card_id,"child_id":Sources.CHILD,"child_uid":generated.uid,"binding":generated[Sources.TAUGHT].duplicate(true),"used":quota.used,"round":engine.state.round,"sequence":engine.state.command_sequence,"policy":POLICY})
105: 	return ""
106: static func finish_buy(engine) -> String:
107: 	var ticket: Dictionary=engine._spellteach_buy_context
108: 	if ticket.is_empty(): return ""
109: 	if not ticket.paid or ticket.records.any(func(row):return not row.done): return "spellteach_incomplete_actual_purchase_group"
110: 	engine._spellteach_buy_context={};return ""
111: static func saved_error(state: Dictionary,catalog,events: Array) -> String:
112: 	var owned: Dictionary=Owned.saved_receipts(state,catalog,events)
113: 	if not str(owned.error).is_empty(): return str(owned.error)
114: 	var receipts: Dictionary=owned.receipts;var quotas: Dictionary={};var purchases: Dictionary={}
115: 	for event in events:
116: 		if event.get("type")!="native_spellteach_acquired": continue
117: 		if event.get("policy")!=POLICY or event.get("source_id") not in Sources.PARENTS or event.get("child_id")!=Sources.CHILD or not Sources.uid(event.get("child_uid")) or receipts.has(event.child_uid) or not Sources.integer(event.get("round"),1,int(state.get("round",0))) or not Sources.integer(event.get("sequence"),1,int(state.get("command_sequence",0))): return "spellteach_invalid_acquisition_receipt"
118: 		var binding: Variant=event.get("binding")
119: 		if not Sources.fields(binding,["uid","owner","source_id","source_uid","purchased_uid","spell_id","round","sequence","spell_program"]) or binding.uid!=event.child_uid or binding.owner!=event.get("player") or binding.source_id!=event.source_id or binding.source_uid!=event.get("source_uid") or binding.purchased_uid!=event.get("bought_uid") or binding.spell_id!=event.get("spell_id") or binding.round!=event.round or binding.sequence!=event.sequence or not Sources.uid(binding.source_uid) or not Sources.uid(binding.purchased_uid) or not Sources.same(binding.spell_program,catalog.get_card(str(binding.spell_id)).get("effects")): return "spellteach_changed_acquisition_binding"
120: 		if not state.get("players",[]).any(func(owner):return owner.get("id")==event.get("player")) or not Cast.card_error(catalog,str(binding.spell_id)).is_empty(): return "spellteach_unbound_receipt_owner_or_spell"
121: 		var key: String=str(event.player)+":"+str(event.source_uid)
122: 		var prior: Dictionary=quotas.get(key,{})
123: 		var expected_used: int=int(prior.get("used",0))+1 if prior.get("round")==event.round else 1
124: 		if event.get("used")!=expected_used or expected_used>int(Sources.PROGRAMS[event.source_id][0].limit) or not prior.is_empty() and (prior.id!=event.source_id or int(prior.round)>int(event.round)): return "spellteach_replayed_or_changed_round_quota"
125: 		var purchase_key: String=key+":"+str(event.bought_uid)
126: 		if purchases.has(purchase_key): return "spellteach_same_purchase_replayed"
127: 		purchases[purchase_key]=true
128: 		quotas[key]={"uid":event.source_uid,"id":event.source_id,"owner":event.player,"round":event.round,"used":event.used}
129: 		receipts[event.child_uid]=event
130: 	var cast_uids: Dictionary={};var cast_steps: Dictionary={}
131: 	for event in events:
132: 		if event.get("type")!="native_spellteach_minion_cast": continue
133: 		if event.get("origin")!=Cast.ORIGIN or event.get("caster_kind")!="minion" or event.get("source_id")!=Sources.CHILD or not receipts.has(event.get("source_uid")) or not Sources.uid(event.get("spell_uid")) or cast_uids.has(event.spell_uid) or receipts.has(event.spell_uid) or not Sources.integer(event.get("round"),1,int(state.get("round",0))) or not Sources.integer(event.get("sequence"),1,int(state.get("command_sequence",0))) or not Sources.integer(event.get("repetition"),1): return "spellteach_invalid_minion_cast_receipt"
134: 		var acquisition: Dictionary=receipts[event.source_uid]
135: 		if event.get("player")!=acquisition.player or event.get("spell_id")!=acquisition.spell_id or int(event.round)<int(acquisition.round) or int(event.sequence)<=int(acquisition.sequence) or event.get("target_zone") not in ["board","shop"] or event.get("target_uid")!="" and not Sources.uid(event.get("target_uid")): return "spellteach_changed_minion_cast_lineage"
136: 		var cast_key: String=str(event.source_uid)+":"+str(event.sequence)
137: 		if int(event.repetition)!=int(cast_steps.get(cast_key,0))+1: return "spellteach_replayed_minion_cast_step"
138: 		cast_steps[cast_key]=event.repetition;cast_uids[event.spell_uid]=true
139: 	for player in state.get("players",[]):
140: 		for zone in ["board","hand","shop","mechanism_reward_queue"]:
141: 			for unit in player.get(zone,[]):
142: 				if cast_uids.has(unit.get("uid")): return "spellteach_ephemeral_spell_restored_as_owned_card"
143: 				if not Sources.claimed(unit): continue
144: 				var issue: String=Sources.unit_error(unit,catalog)
145: 				if not issue.is_empty(): return issue
146: 				var quota_key: String=str(player.id)+":"+str(unit.uid)
147: 				if unit.get("card_id") in Sources.PARENTS and (unit.has(Sources.QUOTA) or quotas.has(quota_key)) and not Sources.same(unit.get(Sources.QUOTA),quotas.get(quota_key)): return "spellteach_quota_disagrees_with_actual_purchase_receipts"
148: 				if unit.has(Sources.QUOTA):
149: 					var quota: Dictionary=unit[Sources.QUOTA]
150: 					if quota.owner!=player.id or quota.round>int(state.round): return "spellteach_foreign_or_future_quota"
151: 				if receipts.has(unit.uid) and not unit.has(Sources.TAUGHT): return "spellteach_saved_teaching_binding_removed"
152: 				if not unit.has(Sources.TAUGHT): continue
153: 				var binding: Dictionary=unit[Sources.TAUGHT]
154: 				if binding.owner!=player.id or binding.round>int(state.round) or binding.sequence>int(state.get("command_sequence",0)) or not receipts.has(unit.uid) or not Sources.same(receipts[unit.uid].get("binding"),binding): return "spellteach_unproven_saved_teaching_lineage"
155: 				if not Cast.card_error(catalog,str(binding.spell_id)).is_empty(): return "spellteach_saved_spell_source_changed"
156: 	return ""
```

## core/spellteach_murloc_cast.gd:13-40

```text
13: static func card_error(catalog,id: String) -> String:
14: 	var issue: String=SpellData.child_error(catalog,id)
15: 	if not issue.is_empty(): return "spellteach_unproved_taught_payload:"+id
16: 	var card: Dictionary=catalog.get_card(id)
17: 	if card.get("kind")!="spell" or card.get("effects",[]).is_empty(): return "spellteach_missing_spell_program"
18: 	for leaf in card.effects:
19: 		if leaf.get("type") not in ["spell_buff","spell_keyword","spell_gold"]: return "spellteach_nonbasic_complete_payload_partial"
20: 		if leaf.get("type")!="spell_gold" and leaf.get("scope") not in ["target","all","all_friendly","leftmost"]: return "spellteach_unproved_spell_target_policy"
21: 	return ""
22: static func _entry_error(engine,p: Dictionary,source: Dictionary) -> String:
23: 	var issue: String=Sources.unit_error(source,engine.catalog)
24: 	if issue.is_empty(): issue=Sources.closure_error(engine.catalog)
25: 	if issue.is_empty(): issue=engine.RecruitEvents.NativeBattlecry.owner_error(engine,p)
26: 	if not issue.is_empty(): return issue
27: 	if not source.has(Sources.TAUGHT): return "spellteach_apprentice_has_no_authenticated_spell"
28: 	var binding: Dictionary=source[Sources.TAUGHT]
29: 	if binding.owner!=p.id: return "spellteach_foreign_taught_owner"
30: 	if binding.get("source_id")=="BG35_MagicItem_750":
31: 		issue=engine.SpellteachTrinket.Sources.closure_error(engine.catalog)
32: 		if not issue.is_empty(): return issue
33: 	issue=card_error(engine.catalog,str(binding.spell_id))
34: 	if not issue.is_empty(): return issue
35: 	var repeated: Dictionary=engine.Kithix.FixedBattlecry.repeat_plan(engine,p,source)
36: 	if not repeated.ok: return str(repeated.error)
37: 	if int(repeated.amount)!=engine._battlecry_multiplier(p,source): return "spellteach_native_battlecry_repeat_changed"
38: 	if source.get("triple_reward",false): return "spellteach_apprentice_cannot_be_tripled"
39: 	if engine.HandLocks.Sources.marked(source) or source.get("attachments",[]) not in [[],{}] or source.get("dark_gift_attachments",[]) not in [[],{}]: return "spellteach_inherited_apprentice_program_partial"
40: 	if engine.SaleSpellGroups.linked(p,source.uid) or engine.Mindflayer.linked(p,source.uid) or engine.Kithix.linked(p,source.uid): return "spellteach_linked_hand_play_partial"
```

## core/spellteach_murloc_cast.gd:89-118

```text
89: static func prepare(engine,p: Dictionary,source: Dictionary,target: int=-1,zone: String="board",position: int=-1,issued: bool=false) -> Dictionary:
90: 	if source.get("card_id")!=Sources.CHILD: return {"ok":true,"error":"","active":false}
91: 	if not Actual._actual_game_host(engine) or engine.state.phase!="recruit" or p.get("alive")!=true or not engine.state.players.any(func(owner):return is_same(owner,p)): return fail("spellteach_actual_recruit_owner_required")
92: 	if not engine._spellteach_cast_context.is_empty() or not p.hand.any(func(unit):return is_same(unit,source)) or p.board.size()>=7 or not Pure.Gains.active(source): return fail("spellteach_actual_hand_and_capacity_required")
93: 	if issued and (not is_same(engine._bounty_spend_command.get("owner"),p) or engine._bounty_spend_command.get("action")!="play"): return fail("spellteach_real_hand_play_required")
94: 	var issue: String=_entry_error(engine,p,source)
95: 	if issue.is_empty(): issue=engine.Spellteach.saved_error(engine.state,engine.catalog,engine.events)
96: 	if not issue.is_empty(): return fail(issue)
97: 	var selected: Dictionary={}
98: 	var legal: Array=options(engine,p,source)
99: 	if legal.size()==1 and legal[0].uid=="": target=-1;zone="board"
100: 	for option in legal:
101: 		if int(option.index)==target and str(option.zone)==zone: selected=option;break
102: 	if selected.is_empty(): return fail("spellteach_explicit_legal_spell_target_required")
103: 	var prefix: Dictionary=engine.Felhorn.prefix(engine,p,source,position)
104: 	if not prefix.ok: return prefix
105: 	var state: Dictionary=prefix.state;var next_uid: int=engine.next_uid
106: 	var repeated: Dictionary=engine.Kithix.FixedBattlecry.repeat_plan(engine,state.player,Pure.Gains._find(state.player.board,str(source.uid)))
107: 	if not repeated.ok: return repeated
108: 	var rounds: Array=[]
109: 	for repetition in range(int(repeated.amount)):
110: 		var cast: Dictionary=_cast_plan(engine,state,str(source.uid),next_uid,selected)
111: 		if not cast.ok: return cast
112: 		next_uid=cast.next_uid
113: 		issue=engine.BalladistPortrait._completion(engine,state,str(source.uid),true)
114: 		if not issue.is_empty(): return fail(issue)
115: 		rounds.append({"cast":cast,"after":view(state.player,state.totals),"next_uid":next_uid})
116: 	var completion: Dictionary=PlayCompletion.project(engine,state,source,next_uid)
117: 	if not completion.ok: return completion
118: 	return {"ok":true,"error":"","active":true,"owner":p,"source":source,"command":engine._bounty_spend_command,"round":engine.state.round,"sequence":engine.state.command_sequence,"whole":{"rounds":rounds,"repeats":int(repeated.amount)},"next":0,"completion_pending":false,"play_finished":false,"play_completion":completion,"selected":selected,"rng_seed":engine.rng.seed,"rng_state":engine.rng.state,"pool":engine.pool.duplicate(true),"spell_pool":engine.spell_pool.duplicate(true)}
```

## core/spellteach_murloc_cast.gd:119-149

```text
119: static func commit(engine,p: Dictionary,source: Dictionary,ticket: Dictionary,repetition: int) -> Dictionary:
120: 	if not Actual._actual_game_host(engine) or not is_same(engine._spellteach_cast_context,ticket) or not is_same(ticket.get("owner"),p) or not is_same(ticket.get("source"),source) or not is_same(ticket.get("command"),engine._bounty_spend_command): return fail("spellteach_unissued_actual_battlecry")
121: 	if ticket.get("next")!=repetition or ticket.get("completion_pending",true) or engine._battlecry_multiplier(p,source)!=ticket.whole.repeats or engine.state.phase!="recruit" or engine.state.round!=ticket.round or engine.state.command_sequence!=ticket.sequence or not p.board.any(func(unit):return is_same(unit,source)): return fail("spellteach_actual_battlecry_window_changed")
122: 	var cast: Dictionary=ticket.whole.rounds[repetition].cast
123: 	if not Sources.same(view(p,engine._attack_gain_health_totals),cast.before) or engine.next_uid!=int(cast.next_uid)-1: return fail("spellteach_play_prefix_changed")
124: 	var replay: Dictionary=_cast_plan(engine,Pure._state(engine,p),str(source.uid),engine.next_uid,ticket.selected)
125: 	if not replay.ok or not Sources.same(replay,cast): return fail("spellteach_whole_cast_replay_changed")
126: 	var spell: Dictionary=engine._unit(engine.catalog.get_card(str(source[Sources.TAUGHT].spell_id)))
127: 	spell.pool_count=0;spell.pool_id="";spell.pool_components=[]
128: 	if not Sources.same(spell,cast.spell): return fail("spellteach_ephemeral_native_spell_changed")
129: 	for leaf in cast.leaves:
130: 		engine._apply_recruit_effect(p,spell,leaf.effect,int(cast.target.index),str(cast.target.zone))
131: 		if engine.state.phase=="error" or not Sources.same(view(p,engine._attack_gain_health_totals),leaf.after): return fail("spellteach_actual_payload_shadow_changed")
132: 	if engine.next_uid!=cast.next_uid or engine.rng.seed!=ticket.rng_seed or engine.rng.state!=ticket.rng_state or not Sources.same(engine.pool,ticket.pool) or not Sources.same(engine.spell_pool,ticket.spell_pool): return fail("spellteach_unplanned_cast_resource_change")
133: 	# Deliberately no stats.spells, GlobalCards Tavern count, last-spell history,
134: 	# spell_cast event or hand-play event: the native actor is the apprentice.
135: 	engine._log("native_spellteach_minion_cast",{"player":p.id,"source_id":source.card_id,"source_uid":source.uid,"spell_id":spell.card_id,"spell_uid":spell.uid,"target_uid":cast.target.uid,"target_zone":cast.target.zone,"repetition":repetition+1,"caster_kind":"minion","origin":ORIGIN,"round":engine.state.round,"sequence":engine.state.command_sequence})
136: 	ticket.completion_pending=true
137: 	return {"ok":true,"error":""}
138: static func completed(engine,p: Dictionary,source: Dictionary,ticket: Dictionary,repetition: int) -> String:
139: 	if not ticket.get("active",false): return ""
140: 	if not is_same(ticket.owner,p) or not is_same(ticket.source,source) or not is_same(ticket.command,engine._bounty_spend_command) or engine.state.phase!="recruit" or engine.state.round!=ticket.round or engine.state.command_sequence!=ticket.sequence or ticket.next!=repetition or not ticket.completion_pending: return "spellteach_unissued_battlecry_completion"
141: 	var step: Dictionary=ticket.whole.rounds[repetition]
142: 	if not Sources.same(view(p,engine._attack_gain_health_totals),step.after) or engine.next_uid!=step.next_uid or engine.rng.seed!=ticket.rng_seed or engine.rng.state!=ticket.rng_state or not Sources.same(engine.pool,ticket.pool) or not Sources.same(engine.spell_pool,ticket.spell_pool): return "spellteach_whole_battlecry_completion_changed"
143: 	ticket.next+=1;ticket.completion_pending=false;return ""
144: static func finish_play(engine,p: Dictionary,source: Dictionary,ticket: Dictionary) -> String: return PlayCompletion.finish(engine,p,source,ticket)
145: static func legal_commands(engine,p: Dictionary,source: Dictionary,index: int) -> Array:
146: 	var commands: Array=[]
147: 	for option in options(engine,p,source):
148: 		if prepare(engine,p,source,int(option.index),str(option.zone)).ok: commands.append({"type":"play","index":index,"target":int(option.index),"target_zone":str(option.zone)})
149: 	return commands
```

## core/spellteach_trinket_host.gd:8-30

```text
8: const STATE="native_spellteach_trinket_slot"
9: const ACQUIRED="native_spellteach_trinket_acquired"
10: const EVENT="native_spellteach_trinket_taught"
11: const POLICY="actual_owned_slot_purchase_two_per_owner_turn_native_apprentice_v1"
12: static func fail(issue: String) -> Dictionary: return {"ok":false,"error":issue,"active":false}
13: static func has_source(p: Dictionary) -> bool: return Sources.ID in p.get("trinkets",[])
14: static func slot(p: Dictionary) -> int: return p.get("trinkets",[]).find(Sources.ID)
15: static func used(p: Dictionary,round_number: int) -> int:
16: 	var quota: Dictionary=p.get(STATE,{}).get("quota",{})
17: 	return int(quota.get("used",0)) if quota.get("round")==round_number else 0
18: static func owner_error(p: Dictionary,round_number: int,catalog,allow_new: int=-1) -> String:
19: 	var indices: Array=[]
20: 	for index in range(p.get("trinkets",[]).size()):
21: 		if p.trinkets[index]==Sources.ID: indices.append(index)
22: 	if indices.size()>1: return "spellteach_trinket_multiple_slot_order_partial"
23: 	var row: Variant=p.get(STATE,{})
24: 	if not row is Dictionary: return "spellteach_trinket_invalid_slot_ledger"
25: 	if not row.is_empty():
26: 		if not Child.fields(row,["owner","source_id","slot","round","sequence","event_index","quota"]) or row.owner!=p.id or row.source_id!=Sources.ID or not Child.integer(row.slot,0,7) or not Child.integer(row.round,1,round_number) or not Child.integer(row.sequence,1) or not Child.integer(row.event_index) or not row.quota is Dictionary: return "spellteach_trinket_changed_acquisition"
27: 		if not row.quota.is_empty() and (not Child.fields(row.quota,["round","used"]) or not Child.integer(row.quota.round,int(row.round),round_number) or not Child.integer(row.quota.used,1,2)): return "spellteach_trinket_changed_quota"
28: 	if not indices.is_empty() and indices[0]!=allow_new:
29: 		if row.is_empty() or row.slot!=indices[0]: return "spellteach_trinket_missing_original_slot_receipt"
30: 		return Sources.closure_error(catalog)
```

## core/spellteach_trinket_host.gd:46-159

```text
46: static func acquisition_error(engine,p: Dictionary,card: Dictionary) -> String:
47: 	if card.get("id")!=Sources.ID: return ""
48: 	if not engine.Spellteach.actual(engine,p) or card.get("choice_kind")!="trinket" or not p.discover.any(func(choice):return is_same(choice,card)): return "spellteach_trinket_real_offer_required"
49: 	if has_source(p) or p.has(STATE): return "spellteach_trinket_multiple_or_replaced_slot_partial"
50: 	var original: Dictionary=card.duplicate(true);original.erase("choice_kind")
51: 	var issue: String=Sources.source_error(original)
52: 	if issue.is_empty(): issue=Sources.closure_error(engine.catalog)
53: 	return issue
54: static func acquired(engine,p: Dictionary,context: Dictionary) -> String:
55: 	var ticket: Dictionary=engine._owned_timed_event_context
56: 	if not engine.Spellteach.actual(engine,p) or context.get("source_kind")!="trinket" or context.get("source_id")!=Sources.ID or not is_same(ticket.get("owner"),p) or not is_same(ticket.get("context"),context) or ticket.get("event")!="mechanic_acquired" or ticket.get("round")!=engine.state.round or ticket.get("sequence")!=engine.state.command_sequence or "spellteach_trinket" in ticket.get("used",[]): return "spellteach_trinket_real_acquisition_capability_required"
57: 	var index: int=p.trinkets.size()-1
58: 	if index<0 or p.trinkets[index]!=Sources.ID or p.has(STATE): return "spellteach_trinket_original_new_slot_required"
59: 	var issue: String=owner_error(p,int(engine.state.round),engine.catalog,index)
60: 	if not issue.is_empty(): return issue
61: 	var row: Dictionary={"owner":p.id,"source_id":Sources.ID,"slot":index,"round":engine.state.round,"sequence":engine.state.command_sequence,"event_index":engine.events.size(),"quota":{}}
62: 	p[STATE]=row;ticket.used.append("spellteach_trinket")
63: 	engine._log(ACQUIRED,{"player":p.id,"entry":row.duplicate(true),"policy":POLICY})
64: 	return ""
65: static func prepare_buy(engine,p: Dictionary,spell: Dictionary,quoted: Dictionary) -> Dictionary:
66: 	if not has_source(p) or spell.get("kind")!="spell" or not engine.Mechanisms.is_tavern_spell_card(engine.catalog.get_card(str(spell.get("card_id","")))): return {"ok":true,"error":"","active":false}
67: 	var issue: String=owner_error(p,int(engine.state.round),engine.catalog)
68: 	if not issue.is_empty(): return fail(issue)
69: 	if used(p,int(engine.state.round))>=2: return {"ok":true,"error":"","active":false}
70: 	if not engine.Spellteach.actual(engine,p) or not engine._spellteach_trinket_buy_context.is_empty() or not p.shop.any(func(unit):return is_same(unit,spell)): return fail("spellteach_trinket_real_shop_buy_required")
71: 	issue=engine.Spellteach.saved_error(engine.state,engine.catalog,engine.events)
72: 	if issue.is_empty(): issue=engine.Spellteach.spell_error(engine,spell)
73: 	if issue.is_empty(): issue=domain(engine,p)
74: 	if not issue.is_empty(): return fail(issue)
75: 	if not quoted.get("ok",false) or not Child.integer(quoted.get("cost")) or ["health_currency","bouncy_health_offer","eye_sargeras_health","tapestry_health_currency","owned_health_currency","bazaar","pilgrimp","hasty_excavation"].any(func(key):return quoted.get(key,false)): return fail("spellteach_trinket_non_gold_purchase_partial")
76: 	if p.hand.size()+2>10: return fail("spellteach_trinket_overflow_quota_semantics_partial")
77: 	var command: Dictionary=engine._bounty_spend_command
78: 	if not is_same(command.get("owner"),p) or command.get("action")!="buy" or command.get("round")!=engine.state.round or command.get("sequence")!=engine.state.command_sequence: return fail("spellteach_trinket_actual_command_required")
79: 	var projected: Dictionary=Pure._state(engine,p);projected.next_uid=engine.next_uid;projected.pool=engine.pool.duplicate(true);projected.spell_pool=engine.spell_pool.duplicate(true)
80: 	issue=Delivery.project(engine,projected,spell.duplicate(true),true)
81: 	if not issue.is_empty(): return fail(issue)
82: 	var child: Dictionary=engine._preview_native_minion(engine.catalog.get_card(Child.CHILD),"u"+str(projected.next_uid))
83: 	if child.is_empty(): return fail("spellteach_trinket_missing_child_factory")
84: 	projected.next_uid+=1
85: 	issue=Delivery.project(engine,projected,child)
86: 	if not issue.is_empty(): return fail(issue)
87: 	return {"ok":true,"error":"","active":true,"owner":p,"spell":spell,"spell_uid":spell.uid,"spell_id":spell.card_id,"program":spell.effects.duplicate(true),"command":command,"round":engine.state.round,"sequence":engine.state.command_sequence,"ledger":p[STATE].duplicate(true),"used":used(p,int(engine.state.round)),"cost":quoted.cost,"gold":p.gold,"bought":p.stats.bought,"paid":false,"done":false}
88: static func paid(engine,p: Dictionary,spell: Dictionary,cost: int) -> String:
89: 	var ticket: Dictionary=engine._spellteach_trinket_buy_context
90: 	if ticket.is_empty(): return ""
91: 	if not engine.Spellteach.actual(engine,p) or not is_same(ticket.owner,p) or not is_same(ticket.spell,spell) or not is_same(ticket.command,engine._bounty_spend_command) or ticket.paid or ticket.cost!=cost or p.gold!=ticket.gold-cost: return "spellteach_trinket_changed_actual_payment"
92: 	ticket.paid=true;return ""
93: static func dispatch(engine,p: Dictionary,context: Dictionary) -> String:
94: 	var ticket: Dictionary=engine._spellteach_trinket_buy_context
95: 	if ticket.is_empty(): return ""
96: 	var authority: Dictionary=engine._owned_timed_event_context
97: 	var spell: Dictionary=context.get("unit",{})
98: 	if not engine.Spellteach.actual(engine,p) or not is_same(authority.get("owner"),p) or not is_same(authority.get("context"),context) or authority.get("event")!="buy" or not is_same(ticket.owner,p) or not is_same(ticket.spell,spell) or not is_same(ticket.command,engine._bounty_spend_command) or ticket.round!=engine.state.round or ticket.sequence!=engine.state.command_sequence or not ticket.paid or ticket.done or p.stats.bought!=ticket.bought+1 or p.shop.any(func(unit):return is_same(unit,spell)) or not p.hand.any(func(unit):return is_same(unit,spell)): return "spellteach_trinket_unissued_committed_purchase"
99: 	if slot(p)!=ticket.ledger.slot or not Child.same(p.get(STATE),ticket.ledger) or spell.uid!=ticket.spell_uid or spell.card_id!=ticket.spell_id or not Child.same(spell.effects,ticket.program): return "spellteach_trinket_original_slot_or_spell_changed"
100: 	if p.hand.size()>=10: return "spellteach_trinket_delivery_capacity_changed"
101: 	var state: Dictionary=Pure._state(engine,p);state.next_uid=engine.next_uid;state.pool=engine.pool.duplicate(true);state.spell_pool=engine.spell_pool.duplicate(true)
102: 	var quota: Dictionary={"round":engine.state.round,"used":int(ticket.used)+1}
103: 	state.player[STATE].quota=quota.duplicate(true)
104: 	var child: Dictionary=engine._preview_native_minion(engine.catalog.get_card(Child.CHILD),"u"+str(state.next_uid))
105: 	if child.is_empty(): return "spellteach_trinket_child_factory_failed"
106: 	child.pool_count=0;child.pool_id="";child.pool_components=[];state.next_uid+=1
107: 	child[Child.TAUGHT]={"uid":child.uid,"owner":p.id,"source_id":Sources.ID,"source_slot":ticket.ledger.slot,"acquired_event_index":ticket.ledger.event_index,"purchased_uid":spell.uid,"spell_id":spell.card_id,"round":engine.state.round,"sequence":engine.state.command_sequence,"spell_program":spell.effects.duplicate(true)}
108: 	var expected: Dictionary=child.duplicate(true)
109: 	var issue: String=Delivery.project(engine,state,child)
110: 	if not issue.is_empty(): return issue
111: 	ticket.done=true;p[STATE].quota=quota
112: 	var actual: Dictionary=engine._unit(engine.catalog.get_card(Child.CHILD))
113: 	actual.pool_count=0;actual.pool_id="";actual.pool_components=[];actual[Child.TAUGHT]=expected[Child.TAUGHT].duplicate(true)
114: 	if not Child.same(actual,expected): return "spellteach_trinket_actual_child_changed"
115: 	engine._add_hand(p,actual)
116: 	if engine.state.phase=="error": return "spellteach_trinket_real_hand_delivery_failed"
117: 	if not Child.same(engine.Spellteach.snapshot(engine,p),engine.Spellteach.projected(state)): return "spellteach_trinket_actual_delivery_projection_changed"
118: 	engine._log(EVENT,{"player":p.id,"source_id":Sources.ID,"source_slot":ticket.ledger.slot,"acquired_event_index":ticket.ledger.event_index,"child_id":Child.CHILD,"child_uid":actual.uid,"spell_id":spell.card_id,"bought_uid":spell.uid,"binding":actual[Child.TAUGHT].duplicate(true),"used":quota.used,"round":engine.state.round,"sequence":engine.state.command_sequence,"policy":POLICY})
119: 	return ""
120: static func finish(engine) -> String:
121: 	var ticket: Dictionary=engine._spellteach_trinket_buy_context
122: 	if ticket.is_empty(): return ""
123: 	if not ticket.paid or not ticket.done: return "spellteach_trinket_unfinished_purchase"
124: 	engine._spellteach_trinket_buy_context={};return ""
125: static func saved_receipts(state: Dictionary,catalog,events: Array) -> Dictionary:
126: 	var receipts: Dictionary={};var last: Dictionary={};var purchases: Dictionary={}
127: 	for p in state.get("players",[]):
128: 		var issue: String=owner_error(p,int(state.get("round",0)),catalog)
129: 		if not issue.is_empty(): return {"error":issue}
130: 		if not p.has(STATE): continue
131: 		issue=Sources.closure_error(catalog)
132: 		if not issue.is_empty(): return {"error":issue}
133: 		var row: Dictionary=p[STATE];var index: int=int(row.event_index)
134: 		if index>=events.size() or row.sequence>int(state.get("command_sequence",0)): return {"error":"spellteach_trinket_missing_acquisition_event"}
135: 		var root: Dictionary=row.duplicate(true);root.quota={}
136: 		var event: Dictionary=events[index]
137: 		if event.get("type")!=ACQUIRED or event.get("player")!=p.id or event.get("policy")!=POLICY or not Child.same(event.get("entry"),root): return {"error":"spellteach_trinket_changed_acquisition_receipt"}
138: 	for event_index in range(events.size()):
139: 		var event: Dictionary=events[event_index]
140: 		if event.get("type")==ACQUIRED:
141: 			var owners: Array=state.get("players",[]).filter(func(owner):return owner.get("id")==event.get("player"))
142: 			if owners.size()!=1 or owners[0].get(STATE,{}).get("event_index")!=event_index: return {"error":"spellteach_trinket_orphan_acquisition"}
143: 			continue
144: 		if event.get("type")!=EVENT: continue
145: 		var binding: Variant=event.get("binding")
146: 		var owners: Array=state.get("players",[]).filter(func(owner):return owner.get("id")==event.get("player"))
147: 		if owners.size()!=1 or event.get("policy")!=POLICY or event.get("source_id")!=Sources.ID or event.get("child_id")!=Child.CHILD or not Child.uid(event.get("child_uid")) or receipts.has(event.child_uid) or not Child.integer(event.get("round"),1,int(state.get("round",0))) or not Child.integer(event.get("sequence"),1,int(state.get("command_sequence",0))): return {"error":"spellteach_trinket_invalid_teaching_receipt"}
148: 		var row: Dictionary=owners[0].get(STATE,{})
149: 		if row.is_empty() or event.get("source_slot")!=row.slot or event.get("acquired_event_index")!=row.event_index or event.round<row.round or event.sequence<=row.sequence: return {"error":"spellteach_trinket_foreign_acquisition_lineage"}
150: 		if not Child.fields(binding,["uid","owner","source_id","source_slot","acquired_event_index","purchased_uid","spell_id","round","sequence","spell_program"]) or binding.uid!=event.child_uid or binding.owner!=event.player or binding.source_id!=Sources.ID or binding.source_slot!=row.slot or binding.acquired_event_index!=row.event_index or binding.purchased_uid!=event.get("bought_uid") or binding.spell_id!=event.get("spell_id") or binding.round!=event.round or binding.sequence!=event.sequence or not Child.uid(binding.purchased_uid) or not Child.same(binding.spell_program,catalog.get_card(str(binding.spell_id)).get("effects")) or not Cast.card_error(catalog,str(binding.spell_id)).is_empty(): return {"error":"spellteach_trinket_changed_taught_binding"}
151: 		var key: String=str(event.player);var previous: Dictionary=last.get(key,{})
152: 		var expected: int=int(previous.get("used",0))+1 if previous.get("round")==event.round else 1
153: 		if event.get("used")!=expected or expected>2 or int(previous.get("round",0))>int(event.round): return {"error":"spellteach_trinket_replayed_turn_quota"}
154: 		var purchase: String=key+":"+str(binding.purchased_uid)
155: 		if purchases.has(purchase): return {"error":"spellteach_trinket_replayed_purchase"}
156: 		purchases[purchase]=true;last[key]={"round":event.round,"used":event.used};receipts[event.child_uid]=event
157: 	for p in state.get("players",[]):
158: 		if p.has(STATE) and not Child.same(p[STATE].quota,last.get(str(p.id),{})): return {"error":"spellteach_trinket_saved_quota_not_backed_by_receipts"}
159: 	return {"error":"","receipts":receipts}
```

## core/spellteach_trinket_sources.gd:2-10

```text
2: ## Independent owned source; never fabricates a board teacher or its quota.
3: const Exact=preload("res://core/phase_undead_army_sources.gd")
4: const Spellteach=preload("res://core/spellteach_murloc_sources.gd")
5: const ID: String="BG35_MagicItem_750"
6: const IDS: Array=[ID]
7: const TYPE: String="owned_tavern_spell_purchase_teach_murloc"
8: const STATE: String="native_spellteach_trinket_slots"
9: const EVENT: String="native_spellteach_trinket_taught"
10: const ACQUIRED: String="native_spellteach_trinket_acquired"
```

## core/phase_undead_army_sources.gd:8-21

```text
8: static func same(a: Variant,b: Variant) -> bool:
9: 	if (a is int or a is float) and (b is int or b is float): return a==b
10: 	if typeof(a)!=typeof(b): return false
11: 	if a is Dictionary:
12: 		if a.size()!=b.size(): return false
13: 		for key in a:
14: 			if not b.has(key) or not same(a[key],b[key]): return false
15: 		return true
16: 	if a is Array:
17: 		if a.size()!=b.size(): return false
18: 		for index in range(a.size()):
19: 			if not same(a[index],b[index]): return false
20: 		return true
21: 	return a==b
```

## core/duelist_refresh.gd:174-182

```text
174: static func _actual_game_host(engine) -> bool:
175: 	if not engine is RefCounted: return false
176: 	var current_script: Script = engine.get_script()
177: 	for _depth in range(16):
178: 		if current_script == null: return false
179: 		if current_script.resource_path == "res://core/game.gd": return true
180: 		current_script = current_script.get_base_script()
181: 	return false
182: 
```

## core/game.gd:2055-2063

```text
2055: 	if not _azshara_triple_scope.is_empty(): return _fail("azshara_triple_reentrant_command")
2056: 	if AzsharaOrdinaryBridge.eligible(self,player_id,command): return AzsharaOrdinaryBridge.apply(self,player_id,command)
2057: 	return _apply_azshara_triple_body(player_id,command)
2058: func _apply_azshara_triple_body(player_id: int, command: Dictionary) -> Dictionary:
2059: 	if not _ritual_dagger_acquisition_context.is_empty(): return _fail("ritual_dagger_reentrant_command")
2060: 	var ritual_saved_issue: String=RitualDagger.saved_error(state,catalog,events)
2061: 	if not ritual_saved_issue.is_empty(): return _fail(ritual_saved_issue)
2062: 	var fairmount_command_issue: String=Fairmount.command_preflight(self,command)
2063: 	if not fairmount_command_issue.is_empty(): return _fail(fairmount_command_issue)
```

## core/game.gd:2474-2479

```text
2474: 	if not _faelin_start_context.is_empty() or not _faelin_choice_context.is_empty() or not _faelin_completion_context.is_empty(): return _fail("faelin_deferred_reentrant_command")
2475: 	if not _jandice_swap_context.is_empty(): return _fail("jandice_swap_reentrant_command")
2476: 	if not _malygos_replace_context.is_empty(): return _fail("malygos_replace_reentrant_command")
2477: 	if not _spellteach_buy_context.is_empty() or not _spellteach_cast_context.is_empty() or not _spellteach_trinket_buy_context.is_empty(): return _fail("spellteach_nested_command")
2478: 	if not _bought_armor_context.is_empty(): return _fail("bought_armor_nested_command")
2479: 	if not _galakrond_replace_power_context.is_empty() or not _galakrond_replace_choice_context.is_empty(): return _fail("galakrond_replace_reentrant_command")
```

## core/game.gd:2780-2787

```text
2780: 	if not prize_chain_saved_issue.is_empty(): return _fail(prize_chain_saved_issue)
2781: 	var prize_resource_saved_issue: String=PrizeResources.saved_error(state,room,catalog)
2782: 	if not prize_resource_saved_issue.is_empty(): return _fail(prize_resource_saved_issue)
2783: 	if not _locked_timewarp_delivery_context.is_empty(): return _fail("locked_timewarp_reentrant_delivery")
2784: 	var spellteach_saved_issue: String=Spellteach.saved_error(state,catalog,events)
2785: 	if not spellteach_saved_issue.is_empty(): return _fail(spellteach_saved_issue)
2786: 	var bought_armor_saved_issue: String=BoughtArmor.saved_error(state,catalog)
2787: 	if not bought_armor_saved_issue.is_empty(): return _fail(bought_armor_saved_issue)
```

## core/game.gd:2942-2949

```text
2942: 	var afk_start_command_issue: String=AfkStart.command_error(self,p,command)
2943: 	if not afk_start_command_issue.is_empty(): return _fail(afk_start_command_issue)
2944: 	var start_fixed_issue: String = StartFixedGrants.saved_error(state,catalog)
2945: 	if not start_fixed_issue.is_empty(): return _fail(start_fixed_issue)
2946: 	var prize_zone_issue: String = _prize_zone_source_error(p)
2947: 	if not prize_zone_issue.is_empty(): return _fail(prize_zone_issue)
2948: 	var received_issue: String = DamageListenerHost.recruit_error(self,p,command)
2949: 	if not received_issue.is_empty(): return _fail(received_issue)
```

## core/game.gd:3553-3559

```text
3553: 	if not bought_armor_ticket.ok: return _fail(str(bought_armor_ticket.error))
3554: 	if p.gold < cost: return _fail("铸币不足。")
3555: 	var spellteach_buy_ticket: Dictionary=Spellteach.prepare_buy(self,p,u,quoted)
3556: 	if not spellteach_buy_ticket.ok: return _fail(str(spellteach_buy_ticket.error))
3557: 	var spellteach_trinket_ticket: Dictionary=SpellteachTrinket.prepare_buy(self,p,u,quoted)
3558: 	if not spellteach_trinket_ticket.ok: return _fail(str(spellteach_trinket_ticket.error))
3559: 	var clunker_kurtrus_ticket: Dictionary=ClunkerKurtrusTriples.prepare(self,p,u,quoted,plain_copy_plan)
```

## core/game.gd:3612-3629

```text
3612: 	if owned_purchase_plan.get("active",false): _owned_purchase_context=owned_purchase_plan
3613: 	if eye_clock_ticket.get("active",false): _eye_purchase_context=eye_clock_ticket
3614: 	if spellteach_buy_ticket.get("active",false): _spellteach_buy_context=spellteach_buy_ticket
3615: 	if spellteach_trinket_ticket.get("active",false): _spellteach_trinket_buy_context=spellteach_trinket_ticket
3616: 	if bought_armor_ticket.get("active",false): _bought_armor_context=bought_armor_ticket
3617: 	if health_buy_ticket.active:
3618: 		_health_buy_context=health_buy_ticket
3619: 		var health_buy_paid_issue: String=health_buy_host.pay(self,p,health_buy_ticket)
3620: 		if not _native_result({"ok":health_buy_paid_issue.is_empty(),"error":health_buy_paid_issue}): return _fail(health_buy_paid_issue)
3621: 	else:
3622: 		p.gold -= cost
3623: 		if not _mark_bounty_payment(p,cost): return _fail("真实付款扣款票据验证失败。")
3624: 	ClunkerPatchesTriples.observe_buy_paid(self,p,u,cost,health_buy_ticket.active)
3625: 	var spellteach_paid_issue: String=Spellteach.mark_paid(self,p,u,cost)
3626: 	if not spellteach_paid_issue.is_empty(): return _fail(spellteach_paid_issue)
3627: 	var spellteach_trinket_paid_issue: String=SpellteachTrinket.paid(self,p,u,cost)
3628: 	if not spellteach_trinket_paid_issue.is_empty(): return _fail(spellteach_trinket_paid_issue)
3629: 	var bought_armor_paid_issue: String=BoughtArmor.mark_paid(self,p,u)
```

## core/game.gd:3704-3724

```text
3704: 		if not purchase_stat_dispatch_issue.is_empty(): return _fail(purchase_stat_dispatch_issue)
3705: 		var native_quota_issue: String=TradeQuotas.dispatch_buy(self,p,native_quota_purchase,listener)
3706: 		if not native_quota_issue.is_empty(): return _fail(native_quota_issue)
3707: 		var spellteach_dispatch_issue: String=Spellteach.dispatch(self,p,u,listener)
3708: 		if not spellteach_dispatch_issue.is_empty(): return _fail(spellteach_dispatch_issue)
3709: 		PurchaseSpellCopy.dispatch_source(self,p,copy_plan,listener)
3710: 		if not trade_ticket.is_empty(): TradeStat.on_event(self,p,"trade_listener",{"ticket":trade_ticket,"source":listener})
3711: 		if state.phase == "error": return _fail("购买监听结算失败，已停止。")
3712: 		if not listener in p.board: continue
3713: 		var bulk_trade_issue: String = TradeTriggers.on_event(self,p,listener,"buy",u)
3714: 		if not bulk_trade_issue.is_empty():
3715: 			_native_result({"ok":false,"error":bulk_trade_issue})
3716: 			return _fail(bulk_trade_issue)
3717: 		for e in listener.get("effects", []):
3718: 			if e.type == "on_buy_gold" and u.get("kind","minion") == "minion" and _tribe_match(u,e.get("tribe","")):
3719: 				if not _grant_actual_gold(p,int(e.amount),"on_buy_gold",{"source_id":listener.card_id,"source_uid":listener.uid,"bought_uid":u.uid}): return _fail("实际购买奖励收入监听失败。")
3720: 	var spellteach_trinket_finish_issue: String=SpellteachTrinket.finish(self)
3721: 	if not spellteach_trinket_finish_issue.is_empty(): return _fail(spellteach_trinket_finish_issue)
3722: 	var spellteach_buy_finish_issue: String=Spellteach.finish_buy(self)
3723: 	if not spellteach_buy_finish_issue.is_empty(): return _fail(spellteach_buy_finish_issue)
3724: 	var purchase_stat_finish_issue: String=PurchaseStats.finish(self)
```

## core/game.gd:4387-4393

```text
4387: 	var native_recruit_issue: String = NativeRecruit.play_error(self,p,u)
4388: 	if not native_recruit_issue.is_empty(): return _fail(native_recruit_issue)
4389: 	var tier_reward_issue: String = RecruitExtensions.validate_tier_reward_program(u)
4390: 	if not tier_reward_issue.is_empty(): return _fail(tier_reward_issue)
4391: 	var prize_source_issue: String = _prize_source_error(u)
4392: 	if not prize_source_issue.is_empty(): return _fail(prize_source_issue)
4393: 	var nether_child_issue: String=NetherConstruct.child_play_error(u)
```

## core/game.gd:4451-4457

```text
4451: 	if not reverber_drake_ticket.ok: return _fail(str(reverber_drake_ticket.error))
4452: 	var efficient_engineer_ticket: Dictionary=EfficientEngineer.prepare(self,p,u,target,target_zone,position,true)
4453: 	if not efficient_engineer_ticket.ok: return _fail(str(efficient_engineer_ticket.error))
4454: 	var spellteach_cast_ticket: Dictionary=Spellteach.Cast.prepare(self,p,u,target,target_zone,position,true)
4455: 	if not spellteach_cast_ticket.ok: return _fail(str(spellteach_cast_ticket.error))
4456: 	var queensguard_ticket: Dictionary=Queensguard.prepare(self,p,u,position,true)
4457: 	if not queensguard_ticket.ok: return _fail(str(queensguard_ticket.error))
```

## core/game.gd:5112-5120

```text
5112: 						_efficient_engineer_context={}
5113: 						if not _native_result(efficient_engineer_result): return _fail("Efficient Engineer actual artificial EOT failed")
5114: 					elif effect.type==Spellteach.Sources.CAST:
5115: 						_spellteach_cast_context=spellteach_cast_ticket
5116: 						var spellteach_cast_result: Dictionary=Spellteach.Cast.commit(self,p,u,spellteach_cast_ticket,_repeat)
5117: 						_spellteach_cast_context={}
5118: 						if not _native_result(spellteach_cast_result): return _fail(str(spellteach_cast_result.error))
5119: 					elif effect.type==Queensguard.Sources.BATTLECRY:
5120: 						_queensguard_context=queensguard_ticket
```

## core/game.gd:5193-5199

```text
5193: 			if not reverber_drake_completion_issue.is_empty(): return _fail(reverber_drake_completion_issue)
5194: 			var efficient_engineer_completion_issue: String=EfficientEngineer.completed(self,p,u,efficient_engineer_ticket,_repeat)
5195: 			if not efficient_engineer_completion_issue.is_empty(): return _fail(efficient_engineer_completion_issue)
5196: 			var spellteach_completion_issue: String=Spellteach.Cast.completed(self,p,u,spellteach_cast_ticket,_repeat)
5197: 			if not spellteach_completion_issue.is_empty(): return _fail(spellteach_completion_issue)
5198: 			var queensguard_completion_issue: String=Queensguard.completed(self,p,u,queensguard_ticket,_repeat)
5199: 			if not queensguard_completion_issue.is_empty(): return _fail(queensguard_completion_issue)
```

## core/game.gd:5252-5257

```text
5252: 		var felhorn_finish_issue: String=Felhorn.finish_play(self,p,u,felhorn_ticket)
5253: 		if not felhorn_finish_issue.is_empty(): return _fail(felhorn_finish_issue)
5254: 		var spellteach_play_finish_issue: String=Spellteach.Cast.finish_play(self,p,u,spellteach_cast_ticket)
5255: 		if not spellteach_play_finish_issue.is_empty(): return _fail(spellteach_play_finish_issue)
5256: 		var queensguard_finish_issue: String=Queensguard.finish_play(self,p,u,queensguard_ticket)
5257: 		if not queensguard_finish_issue.is_empty(): return _fail(queensguard_finish_issue)
```

## core/game.gd:5814-5845

```text
5814: func _prize_source_error(source: Dictionary) -> String:
5815: 	if DevourerSoulsSources.claimed(source): return DevourerSoulsSources.unit_error(source,catalog)
5816: 	if Amalgadon.Sources.claimed(source): return Amalgadon.unit_error(source)
5817: 	if Megasaur.Sources.claimed(source): return Megasaur.Sources.unit_error(source)
5818: 	if Clunker.Sources.claimed(source) or Clunker.Sources.marked(source): return Clunker.Sources.unit_error(source,catalog.hand_card_templates)
5819: 	if Aureate.Sources.claimed(source): return Aureate.Sources.unit_error(source)
5820: 	if Brigand.Sources.claimed(source): return Brigand.Sources.unit_error(source)
5821: 	if Disco.Sources.claimed(source): return Disco.Sources.unit_error(source)
5822: 	if Beatboxer.Sources.claimed(source): return Beatboxer.Sources.unit_error(source)
5823: 	if WindsSpend.Sources.claimed(source): return WindsSpend.Sources.unit_error(source)
5824: 	if TerrorguardCast.Sources.claimed(source): return TerrorguardCast.Sources.unit_error(source)
5825: 	if Gatekeeper.Sources.claimed(source): return Gatekeeper.Sources.unit_error(source)
5826: 	if Slither.Sources.claimed(source): return Slither.unit_error(source)
5827: 	if Deadscale.claimed(source): return Deadscale.unit_error(source)
5828: 	if JandiceApprentice.Sources.claimed(source): return JandiceApprentice.Sources.unit_error(source)
5829: 	if Underling.Sources.claimed(source): return Underling.Sources.unit_error(source)
5830: 	if Waxadred.Sources.claimed(source): return Waxadred.Sources.unit_error(source)
5831: 	if MiniZerek.Sources.claimed(source): return MiniZerek.Sources.unit_error(source)
5832: 	if Faceless.Sources.claimed(source): return Faceless.Sources.unit_error(source)
5833: 	if Taverngoer.Sources.claimed(source): return Taverngoer.Sources.unit_error(source)
5834: 	if LuckyEgg.Sources.claimed(source): return LuckyEgg.Sources.unit_error(source)
5835: 	if Evolution.Sources.claimed(source): return Evolution.Sources.unit_error(source)
5836: 	if Trench.Sources.claimed(source): return Trench.Sources.unit_error(source)
5837: 	if Lasso.Sources.claimed(source): return Lasso.Sources.unit_error(source)
5838: 	if FandralFortune.Sources.claimed(source): return FandralFortune.Sources.unit_error(source)
5839: 	if Trailblazer.Sources.claimed(source): return Trailblazer.Sources.unit_error(source)
5840: 	if ReverberDrake.Sources.claimed(source): return ReverberDrake.Sources.unit_error(source)
5841: 	if EfficientEngineer.Sources.claimed(source): return EfficientEngineer.Sources.unit_error(source)
5842: 	if FaunaEot.Sources.claimed(source): return FaunaEot.Sources.unit_error(source)
5843: 	if StaffEot.Sources.claimed(source): return StaffEot.Sources.unit_error(source)
5844: 	if Spellteach.Sources.claimed(source): return Spellteach.Sources.unit_error(source,catalog)
5845: 	if Queensguard.Sources.claimed(source): return Queensguard.Sources.unit_error(source)
```

## core/game.gd:5875-5892

```text
5875: 	if PrizeStats.DoubleStat.claimed(source): return PrizeStats.DoubleStat.live_error(source,catalog)
5876: 	var id: Variant = source.get("card_id")
5877: 	if not id is String or id.is_empty(): return "手牌实体需要有效字符串身份。"
5878: 	var closed: bool = PrizeGolden.SOURCE_FIELDS.has(id) or PrizeStats.SOURCES.has(id) or PrizeBuffs.SOURCES.has(id) or PrizePassives.SOURCES.has(id) or id in [PrizeReturn.SOURCE_ID,PrizeSteal.SOURCE_ID,PrizeCoin.SOURCE_ID,PrizePrice.SOURCE_ID,PrizeDiscount.SOURCE_ID,PrizeBattlecry.SOURCE_ID]
5879: 	if closed and not BoardAura.same(source.get("effects"),catalog.get_card(str(id)).get("effects")):
5880: 		return "奖品实例的完整效果程序与已核来源不符。"
5881: 	return ""
5882: 
5883: func _prize_zone_source_error(player: Dictionary) -> String:
5884: 	# Close known Prize programs before unrelated preflight scanners inspect the
5885: 	# same zones. This does not synthesize missing effects or repair bad state.
5886: 	for zone in ["board","hand","shop"]:
5887: 		for unit in player[zone]:
5888: 			var issue: String = _prize_source_error(unit)
5889: 			if not issue.is_empty(): return issue
5890: 			issue = PrizeGoldenSave.unit_error(unit,player,catalog,state.round,next_uid,zone)
5891: 			if not issue.is_empty(): return issue
5892: 	return ""
```

## core/game.gd:6035-6040

```text
6035: 		if EfficientEngineer.NativeCasts.resolve(self,p,source,effect): return
6036: 		_native_result({"ok":false,"error":"staff_eot_complete_actual_scheduler_required"});return
6037: 	if effect.get("type") in [Spellteach.Sources.CAST,Spellteach.Sources.TYPE]:
6038: 		_native_result({"ok":false,"error":"spellteach_requires_actual_purchase_or_hand_battlecry"});return
6039: 	if effect.get("type")==Queensguard.Sources.BATTLECRY:
6040: 		_native_result({"ok":false,"error":"queensguard_original_hand_battlecry_capability_required"});return
```

## core/game.gd:9947-9981

```text
9947: func _add_hand(p: Dictionary, u: Dictionary) -> void:
9948: 	if _gladiator_projecting:
9949: 		_add_hand_before_gladiator(p,u);return
9950: 	var gladiator_before: String=Gladiator.before_hand(self,p,u)
9951: 	if not _native_result({"ok":gladiator_before.is_empty(),"error":gladiator_before}): return
9952: 	_add_hand_before_gladiator(p,u)
9953: 	if state.phase=="error": return
9954: 	var gladiator_after: String=Gladiator.after_hand(self,p,u)
9955: 	if not _native_result({"ok":gladiator_after.is_empty(),"error":gladiator_after}): return
9956: 
9957: func _add_hand_before_gladiator(p: Dictionary, u: Dictionary) -> void:
9958: 	var fandral_fortune_delivery_issue: String=FandralFortune.triple_error(self,p,u)
9959: 	if not fandral_fortune_delivery_issue.is_empty():
9960: 		_return_unit(u);_native_result({"ok":false,"error":fandral_fortune_delivery_issue});return
9961: 	if Devilish.claimed(u) and u.get("card_id")==Devilish.Acquisition.ID:
9962: 		var devilish_delivery_issue: String=Devilish.Acquisition.delivery_error(u,int(p.id))
9963: 		if not devilish_delivery_issue.is_empty():
9964: 			_return_unit(u);_native_result({"ok":false,"error":devilish_delivery_issue});return
9965: 	var dust_admission: String=DustPrintsDelivery.admission(self,p,u)
9966: 	if not _native_result({"ok":dust_admission.is_empty(),"error":dust_admission}): return
9967: 	var amalgadon_delivery_issue: String=Amalgadon.complete_error(u)
9968: 	if not amalgadon_delivery_issue.is_empty():
9969: 		_return_unit(u);_native_result({"ok":false,"error":amalgadon_delivery_issue});return
9970: 	var old_soul_delivery_issue: String=OldSoul.Sources.unit_error(u)
9971: 	if not old_soul_delivery_issue.is_empty():
9972: 		_return_unit(u);_native_result({"ok":false,"error":old_soul_delivery_issue});return
9973: 	var bloodbinder_delivery_issue: String=Bloodbinder.delivery_error(self,p,u)
9974: 	if not bloodbinder_delivery_issue.is_empty():
9975: 		_return_unit(u);_native_result({"ok":false,"error":bloodbinder_delivery_issue});return
9976: 	var megasaur_grant_issue: String=Megasaur.Grants.owner_error(u,int(p.id),int(state.round))
9977: 	if not _native_result({"ok":megasaur_grant_issue.is_empty(),"error":megasaur_grant_issue}): return
9978: 	var spellteach_delivery_issue: String=Spellteach.Sources.unit_error(u,catalog)
9979: 	if not spellteach_delivery_issue.is_empty():
9980: 		_return_unit(u);_native_result({"ok":false,"error":spellteach_delivery_issue});return
9981: 	if state.get("phase")=="recruit" and (p.get("hero_id")==Clocksworth.Sources.HERO or FalseIdols.Sources.enabled(room) or (PilferedLamps.Sources.enabled(room) and PilferedLamps.Sources.has_source(p))):
```

## core/game.gd:13015-13020

```text
13015: 		if not Ekkron.play_error(self,p,card).is_empty(): continue
13016: 		if not RecruitExtensions.validate_tier_reward_program(card).is_empty(): continue
13017: 		if not _prize_source_error(card).is_empty(): continue
13018: 		if not _turn_repeat_cast_error(p,card).is_empty(): continue
13019: 		if not BattlecruiserBallistics.prepare_play(self,p,card).ok: continue
13020: 		if not BattlecruiserMissile.prepare_play(self,p,card).ok: continue
```

## core/game.gd:13117-13122

```text
13117: 			actions.append_array(EfficientEngineer.legal_commands(self,p,card,i))
13118: 			continue
13119: 		if card.get("card_id")==Spellteach.Sources.CHILD:
13120: 			actions.append_array(Spellteach.Cast.legal_commands(self,p,card,i))
13121: 			continue
13122: 		if Queensguard.Sources.claimed(card):
```

## core/game.gd:13452-13456

```text
13452: 	actions=actions.filter(func(command):return command.get("type")!="play" or TerrorguardCast.play_error(self,p,p.hand[int(command.index)],int(command.get("target",-1)),str(command.get("target_zone","board")),int(command.get("choice",-1))).is_empty())
13453: 	actions=actions.filter(func(command):return command.get("type")!="play" or NetherConstruct.child_play_error(p.hand[int(command.index)]).is_empty())
13454: 	actions=actions.filter(func(command):return command.type!="buy" or Spellteach.prepare_buy(self,p,p.shop[int(command.index)],_buy_cost_quote(p,p.shop[int(command.index)]),false).ok)
13455: 	return actions.filter(func(command): return (command.type!="play" or FandralFortune.prepare_cast(self,p,p.hand[int(command.index)]).ok) and (command.type!="play" or TimewarpedApples.play_error(self,p,p.hand[int(command.index)]).is_empty()) and (command.type!="roll" or TimewarpedApples.fill_error(self,p,false,"paid_refresh").is_empty()) and Slither.command_error(self,player_id,command).is_empty() and (command.type!="play" or Slither.play_error(self,p,p.hand[int(command.index)],int(command.get("target",-1)),str(command.get("target_zone","board"))).is_empty()) and Megasaur.Grants.command_error(p,command).is_empty() and Tapestry.command_error(self,p,command).is_empty() and (command.type not in ["play","magnetize"] or Clocksworth.play_error(self,p,p.hand[int(command.index)],str(command.type)).is_empty()) and (command.type!="end_turn" or DefilerPortrait.preflight(self,p).is_empty()) and FodderSale.command_error(self,p,command).is_empty() and SaleSpellGroups.command_error(self,p,command).is_empty() and Mindflayer.command_error(self,p,command).is_empty() and Kithix.command_error(self,p,command).is_empty() and (command.type!="magnetize" or DancingHats.magnetic_error(p,int(command.index),int(command.target)).is_empty()) and HandLocks.command_error(p,command).is_empty() and (command.type!="play" or HandLocks.play_error(self,p,p.hand[int(command.index)]).is_empty()) and (command.type!="play" or p.hand[int(command.index)].get("card_id")!=Lockboxes.Sources.CHILD) and (command.type!="magnetize" or not TempDeath.marked(p.hand[int(command.index)])) and (command.type!="play" or TempDeath.play_error(self,p,p.hand[int(command.index)],int(command.get("target",-1)),str(command.get("target_zone","board"))).is_empty()) and (command.type!="play" or HighDiscover.play_error(self,p,p.hand[int(command.index)]).is_empty()) and (command.type!="play" or LockedTimewarp.play_error(self,p,p.hand[int(command.index)]).is_empty()) and (command.type!="play" or WarpDiscover.play_error(self,p,p.hand[int(command.index)]).is_empty()) and (command.type!="play" or RandomSpellcraft.play_error(self,p,p.hand[int(command.index)]).is_empty()) and (command.type!="play" or BulkDiscover.Majority.play_error(self,p,p.hand[int(command.index)]).is_empty()) and (command.type!="play" or StatSpellResources.play_error(self,p,p.hand[int(command.index)]).is_empty()) and (command.type!="play" or PreviousPlain.play_error(self,p,p.hand[int(command.index)],int(command.get("target",-1))).is_empty()) and (command.type!="play" or BulkResourceHost.Chromatic.play_error(self,p,p.hand[int(command.index)]).is_empty()) and (command.type!="play" or HandGemRepeat.play_error(self,p,p.hand[int(command.index)],int(command.get("target",-1)),str(command.get("target_zone","board"))).is_empty()) and (command.type!="play" or PrivateerCast.play_error(self,p,p.hand[int(command.index)]).is_empty()) and (command.type!="play" or BulkResourceHost.Bounty.play_error(self,p,p.hand[int(command.index)]).is_empty()) and (command.type!="play" or BulkResourceHost.Special.play_error(self,p,p.hand[int(command.index)]).is_empty()) and (command.type!="play" or PrizeExtraOffer.play_error(self,p,p.hand[int(command.index)]).is_empty()) and (command.type!="play" or SpellcraftRefresh.play_error(self,p,p.hand[int(command.index)]).is_empty()) and (command.type!="roll" or RefreshOffers.fill_error(self,p,false,false,"paid_refresh").is_empty()) and (command.type!="end_turn" or RefreshOffers.fill_error(self,p,bool(p.frozen),true,"").is_empty()) and (command.type != "play" or DiscardHost.play_error(self,p,p.hand[int(command.index)]).is_empty()) and (command.type != "roll" or FodderRefresh.fill_error(self,p,false,false,"paid_refresh").is_empty()) and (command.type != "play" or Lockboxes.play_error(p,p.hand[int(command.index)]).is_empty()) and (command.type != "play" or FodderRefresh.play_error(self,p,p.hand[int(command.index)]).is_empty()) and (command.type != "roll" or RefreshOwnerBuffs.fill_error(self,p,false,"paid_refresh").is_empty()) and (command.type != "play" or RefreshOwnerBuffs.play_error(self,p,p.hand[int(command.index)]).is_empty()) and RefreshGemBarrage.command_error(self,p,command).is_empty() and (command.type != "play" or FixedResourceSpells.play_error(self,p,p.hand[int(command.index)],int(command.get("target",-1)),str(command.get("target_zone","board"))).is_empty()) and (command.type != "sell" or HeroPowerRefresh.sale_error(self,p,p.board[int(command.index)]).is_empty()) and (command.type != "hero_power" or (_hero_triple_error(p,hero.get("effects",[]),int(command.get("target",-1))).is_empty() and HeroPowerRefresh.power_error(self,p).is_empty())) and (command.type != "hero_power" or _hero_listener_preflight(p,int(command.get("target",-1)),str(command.get("target_zone","board"))).is_empty()) and _waiting_command_error(p,command).is_empty() and NativeBuddy.command_preflight(self,p,command).is_empty() and TypeCountHost.command_error(self,p,command).is_empty() and BeetleHost.recruit_error(self,p,command).is_empty() and Constellation.command_error(self,p,command).is_empty() and ThreeTribe.command_error(self,p,command).is_empty() and BonusKeyword.command_error(self,p,command).is_empty() and PreviousCombat.command_error(self,p,command).is_empty() and PersistentShop.command_error(self,p,command).is_empty() and CorpseSale.command_error(self,p,command).is_empty() and HiredRitualist.command_error(self,p,command).is_empty())
13456: 
```

## core/game.gd:13838-13844

```text
13838: 	if not _jandice_swap_context.is_empty(): return ERR_BUSY
13839: 	if not _malygos_replace_context.is_empty(): return ERR_BUSY
13840: 	if not _spellteach_buy_context.is_empty() or not _spellteach_cast_context.is_empty() or not _spellteach_trinket_buy_context.is_empty(): return ERR_BUSY
13841: 	if not _bought_armor_context.is_empty(): return ERR_BUSY
13842: 	if not state.is_empty() and not Spellteach.saved_error(state,catalog,events).is_empty(): return ERR_INVALID_DATA
13843: 	if not state.is_empty() and not BoughtArmor.saved_error(state,catalog).is_empty(): return ERR_INVALID_DATA
13844: 	if not _galakrond_replace_power_context.is_empty() or not _galakrond_replace_choice_context.is_empty(): return ERR_BUSY
```

## core/game.gd:14130-14149

```text
14130: 	if BeetleHost.enabled(room) and not BeetleHost.serialized_error({"state":state,"last_combats":last_combats,"events":events}).is_empty(): return ERR_INVALID_DATA
14131: 	var contents: String=JSON.stringify({"schema_version":SAVE_VERSION,"rules_version":RULES_VERSION,"execution_fingerprint":catalog.execution_fingerprint,"room":room,"state":state,"pool":pool,"spell_pool":spell_pool,"rng_state":str(rng.state),"rng_seed":str(rng.seed),"next_uid":next_uid,"command_log":command_log,"events":events,"last_combats":last_combats}, "\t")
14132: 	return AtomicSaveFile.write_text(path,contents)
14133: 
14134: func load_from(path: String, cat: RefCounted) -> Error:
14135: 	if not _lobster_combat_authority.is_empty(): return ERR_BUSY
14136: 	if not _leviathan_combat_authority.is_empty() or not _leviathan_entry_context.is_empty() or not _leviathan_recruit_tickets.is_empty(): return ERR_BUSY
14137: 	if HarbingerEot.busy(self): return ERR_BUSY
14138: 	if not _current_spell_stock_purchase.is_empty(): return ERR_BUSY
14139: 	# Refuse a different scope before mutating the live engine; never migrate
14140: 	# old player entities, receipts, stock or generated dependencies silently.
14141: 	if not FileAccess.file_exists(path): return ERR_FILE_NOT_FOUND
14142: 	var envelope: Variant=JSON.parse_string(FileAccess.get_file_as_string(path))
14143: 	if not envelope is Dictionary or not envelope.get("room") is Dictionary: return ERR_INVALID_DATA
14144: 	if not CurrentScope.room_errors(envelope.room,cat).is_empty(): return ERR_INVALID_DATA
14145: 	return _load_scoped_game(envelope,cat)
14146: 
14147: func _load_scoped_game(envelope: Dictionary, cat: RefCounted) -> Error:
14148: 	if HarbingerEot.busy(self): return ERR_BUSY
14149: 	if not _gladiator_round_scope.is_empty() or not _gladiator_result_scope.is_empty() or not _gladiator_choice_scope.is_empty(): return ERR_BUSY
```

## core/game.gd:14270-14275

```text
14270: 	if not _faelin_start_context.is_empty() or not _faelin_choice_context.is_empty() or not _faelin_completion_context.is_empty(): return ERR_BUSY
14271: 	if not _jandice_swap_context.is_empty(): return ERR_BUSY
14272: 	if not _malygos_replace_context.is_empty(): return ERR_BUSY
14273: 	if not _spellteach_buy_context.is_empty() or not _spellteach_cast_context.is_empty() or not _spellteach_trinket_buy_context.is_empty(): return ERR_BUSY
14274: 	if not _bought_armor_context.is_empty(): return ERR_BUSY
14275: 	if not _galakrond_replace_power_context.is_empty() or not _galakrond_replace_choice_context.is_empty(): return ERR_BUSY
```

## core/game.gd:14338-14363

```text
14338: 	# All original live-command busy gates above run against this engine.
14339: 	# Recovery callbacks below execute only on a private candidate. Failure must
14340: 	# not publish a partly restored room, stock, RNG, receipts or pending choice.
14341: 	var candidate: RefCounted=get_script().new()
14342: 	var load_error: Error=candidate._read_scoped_game(envelope,cat)
14343: 	if load_error!=OK: return load_error
14344: 	# Transfer script-owned state as one synchronous publication, including
14345: 	# source-private restored contexts. Constants/native Object properties stay.
14346: 	for entry in get_property_list():
14347: 		if (int(entry.usage) & PROPERTY_USAGE_SCRIPT_VARIABLE)!=0:
14348: 			set(str(entry.name),candidate.get(str(entry.name)))
14349: 	return OK
14350: 
14351: func _read_scoped_game(obj: Dictionary, cat: RefCounted) -> Error:
14352: 	if not obj.get("state") is Dictionary or not Lobster.History.saved_error(obj.state,cat).is_empty(): return ERR_INVALID_DATA
14353: 	if not obj.get("state") is Dictionary or not Leviathan.History.saved_error(obj.state,cat).is_empty(): return ERR_INVALID_DATA
14354: 	if not obj.get("state") is Dictionary or not Hopebringer.History.saved_error(obj.state,cat).is_empty(): return ERR_INVALID_DATA
14355: 	# Use exactly the envelope admitted by the current-scope gate, rather than
14356: 	# reopening a path that may now contain a different room or rules revision.
14357: 	_weaver_command_context = {}
14358: 	_weaver_cast_context = {}
14359: 	if not _is_number(obj.get("schema_version")) or int(obj.schema_version) != SAVE_VERSION or obj.get("rules_version","") != RULES_VERSION: return ERR_INVALID_DATA
14360: 	# Reject only claimed Siphon structural/owner-boundary faults before unrelated hosts.
14361: 	# Existing root, room, fingerprint and every later validator retain their order.
14362: 	if not SpellSiphon.Layer.saved_boundary_error(obj).is_empty(): return ERR_INVALID_DATA
14363: 	if obj.get("room") is Dictionary and BeetleHost.enabled(obj.room) and not BeetleHost.serialized_error(obj).is_empty(): return ERR_INVALID_DATA
```

## core/game.gd:14485-14509

```text
14485: 	if not StartFriendlyConsume.saved_error(obj.state,cat,obj.events).is_empty(): return ERR_INVALID_DATA
14486: 	if not DeityOwner.saved_error(obj.state,obj.room,cat,obj.events).is_empty(): return ERR_INVALID_DATA
14487: 	obj = _normalize_numbers(obj)
14488: 	if not obj.get("room") is Dictionary: return ERR_INVALID_DATA
14489: 	var check: RefCounted = RoomConfig.new()
14490: 	check.data = obj.room
14491: 	if not check.validate(cat).is_empty(): return ERR_INVALID_DATA
14492: 	cat = CustomShop.effective_catalog(cat,obj.room)
14493: 	if obj.get("execution_fingerprint","") != cat.execution_fingerprint: return ERR_INVALID_DATA
14494: 	# This is the private load candidate, not the live engine. Unit validators
14495: 	# use its catalog before publication; failed loads still leave the caller intact.
14496: 	catalog = cat
14497: 	if not _valid_save(obj, cat): return ERR_INVALID_DATA
14498: 	if not PreviousCombat.saved_error(obj.state,obj.last_combats,obj.events,obj.room,cat).is_empty(): return ERR_INVALID_DATA
14499: 	if not Constellation.saved_error(obj.state,obj.room,cat,int(obj.next_uid)).is_empty(): return ERR_INVALID_DATA
14500: 	if not ThreeTribe.saved_error(obj.state,obj.room,cat,int(obj.next_uid)).is_empty(): return ERR_INVALID_DATA
14501: 	if not FriendlyAttackRoom.saved_error(obj.state,cat,obj.room).is_empty(): return ERR_INVALID_DATA
14502: 	if not TypeCountHost.saved_error(obj.state,obj.room,cat).is_empty(): return ERR_INVALID_DATA
14503: 	if not DamageListenerHost.saved_error(obj.state,obj.room,cat).is_empty(): return ERR_INVALID_DATA
14504: 	if DamageListenerHost.enabled(obj.room) and not _damage_listener_history_valid(obj.state,obj.last_combats): return ERR_INVALID_DATA
14505: 	if not BeetleHost.saved_error(obj.state,obj.room,cat).is_empty(): return ERR_INVALID_DATA
14506: 	var loaded_deathwing_context: Dictionary = DeathwingHost.load_context(obj.room,cat)
14507: 	if not str(loaded_deathwing_context.error).is_empty(): return ERR_INVALID_DATA
14508: 	if not obj.get("state") is Dictionary or not obj.state.get("players") is Array: return ERR_INVALID_DATA
14509: 	_timewarped_start_context = {}
```

## core/game.gd:14713-14729

```text
14713: 	_timewarped_start_context = {}
14714: 	_barov_coin_context = {}
14715: 	return {"ok":false,"error":message}
14716: 
14717: func _pool_ids() -> Array:
14718: 	var ids: Array = pool.keys()
14719: 	ids.sort()
14720: 	return ids
14721: 
14722: func _normalize_numbers(value: Variant) -> Variant:
14723: 	if value is float and value == floor(value): return int(value)
14724: 	if value is Dictionary:
14725: 		for key in value: value[key] = _normalize_numbers(value[key])
14726: 	elif value is Array:
14727: 		for index in range(value.size()): value[index] = _normalize_numbers(value[index])
14728: 	return value
14729: 
```

## core/game.gd:14945-14950

```text
14945: func _valid_save(obj: Dictionary, cat: RefCounted) -> bool:
14946: 	for key in ["state","room","pool","spell_pool"]:
14947: 		if not obj.get(key) is Dictionary: return false
14948: 	if not obj.get("events") is Array or not Gladiator.saved_error(obj.state,cat,obj.events).is_empty(): return false
14949: 	if not Gladiator.Sources.enabled(obj.room) and obj.state.get("players",[]).any(func(p):return p.has(Gladiator.Sources.STATE)): return false
14950: 	if not obj.get("events") is Array or not DeityOwner.saved_error(obj.state,obj.room,cat,obj.events).is_empty(): return false
```

## core/game.gd:15283-15324

```text
15283: 		for key in ["hand","board","shop","discover","trinkets","reward_active"]:
15284: 			if not player.get(key) is Array: return false
15285: 		for pair in [["trinkets","trinket"],["reward_active","reward"]]:
15286: 			for id in player[pair[0]]:
15287: 				if not id is String or cat.get_card(id).get("kind","") != pair[1] or not cat.get_card(id).get("supported",false): return false
15288: 		if player.board.size() > 7 or player.hand.size() > 10 or player.shop.size() > 7: return false
15289: 		for board_unit in player.board:
15290: 			if not board_unit is Dictionary or cat.get_card(str(board_unit.get("card_id",""))).get("kind","") != "minion": return false
15291: 		if TavernTier.exact_tier_enabled(obj.room,cat) and player.shop.filter(func(u):return u is Dictionary and u.get("kind","")=="spell").size() > 1: return false
15292: 		for shop_unit in player.shop:
15293: 			if not shop_unit is Dictionary: return false
15294: 			var shop_card: Dictionary = cat.get_card(str(shop_unit.get("card_id","")))
15295: 			if shop_card.get("kind","") == "minion":
15296: 				if shop_card.get("is_golden",false):
15297: 					if not PrizeGoldenSave.shop_error(shop_unit,player,cat,enabled_pools.minions,saved.round,obj.next_uid).is_empty(): return false
15298: 				elif not enabled_pools.minions.has(shop_card.get("id","")) or not shop_card.get("pool_supported",false): return false
15299: 			elif shop_card.get("kind","") == "spell":
15300: 				if not enabled_pools.spells.has(shop_card.get("id","")) or not shop_card.get("pool_supported",false) or (not Mechanisms.is_tavern_spell_card(shop_card) and not CustomShop.configured(shop_card)): return false
15301: 				if shop_unit.get("pool_id","") != shop_card.id or shop_unit.get("pool_kind","") != "spell" or shop_unit.get("pool_count",0) != 1: return false
15302: 		for unit in player.hand + player.board + player.shop + player.get("mechanism_reward_queue",[]):
15303: 			if not unit is Dictionary or not unit.get("uid") is String or not unit.get("card_id") is String: return false
15304: 			if not Megasaur.Grants.owner_error(unit,int(player.id),int(saved.round)).is_empty(): return false
15305: 			if not MinionActivate.validate_unit(unit,cat,saved.round).is_empty(): return false
15306: 			if not GeneratedDiscover.held_error(unit,cat).is_empty(): return false
15307: 			if not BulkDiscover.held_error(unit,cat).is_empty(): return false
15308: 			if not _valid_unit_state(unit,saved.round) or not DynamicSpells.validate_unit(unit,cat): return false
15309: 			for temp_grant in unit.get(TempDeath.KEY,[]):
15310: 				if temp_grant.owner!=player.id or int(temp_grant.round)>int(saved.round) or int(temp_grant.expires_round)<=int(saved.round): return false
15311: 			var internal_reward: bool = unit.card_id in ["__triple_reward","__triple_gold_pouch"]
15312: 			if internal_reward and (not unit in player.hand or unit.get("kind","") != "spell" or unit.get("cost") != 0): return false
15313: 			if not internal_reward and not cat.get_card(unit.card_id).get("supported",false): return false
15314: 			if not PrizeGoldenSave.unit_error(unit,player,cat,saved.round,obj.next_uid).is_empty(): return false
15315: 			if not internal_reward and unit.get("kind","minion") != cat.get_card(unit.card_id).get("kind",""): return false
15316: 			if not unit.get("effects") is Array: return false
15317: 			for effect in unit.effects:
15318: 				if not effect is Dictionary or not effect.get("type") is String: return false
15319: 			if seen_uids.has(unit.uid): return false
15320: 			seen_uids[unit.uid] = true
15321: 			if unit.get("kind","minion") == "minion":
15322: 				if not Magnetic.validate_unit(cat,unit): return false
15323: 				if not Combat.new()._validate_unit(unit,0,false,cat.hand_card_templates).is_empty(): return false
15324: 				for attachment_uid in Magnetic.attachment_uids(unit):
```

## core/game.gd:15534-15540

```text
15534: 	if not PeriodicEvolve.saved_error(saved,cat).is_empty(): return false
15535: 	if not PrizeChain.saved_error(saved,obj.room,cat).is_empty(): return false
15536: 	if not PrizeResources.saved_error(saved,obj.room,cat).is_empty(): return false
15537: 	if not Spellteach.saved_error(saved,cat,obj.events).is_empty(): return false
15538: 	if not BoughtArmor.saved_error(saved,cat).is_empty(): return false
15539: 	if not LockedTimewarp.saved_error(saved,obj.room,cat).is_empty(): return false
15540: 	if not WarpDiscover.saved_error(saved,obj.room,cat).is_empty(): return false
```

## core/game.gd:15737-15743

```text
15737: 	if value.has(HeroTrinkets.Sources.STATE): return false
15738: 	if value.has(OwnedLockedDiscover.Sources.KEY): return false
15739: 	if value.has(LockedTimewarp.KEY): return false
15740: 	if value.has(Spellteach.Sources.QUOTA) or value.has(Spellteach.Sources.TAUGHT): return false
15741: 	if value.has(BoughtArmor.Sources.KEY): return false
15742: 	if value.has(HandLocks.Sources.STATE) or value.has(HandLocks.Sources.HISTORY): return false
15743: 	if value.has(Stimulant.Sources.KEY): return false
```

## core/game.gd:16067-16072

```text
16067: func _valid_unit_state(unit: Dictionary, saved_round: int = -1) -> bool:
16068: 	if not TimewarpSwirler.unit_error(unit).is_empty(): return false
16069: 	if not TimewarpScout.unit_error(unit).is_empty(): return false
16070: 	if not TimewarpRedWhelp.unit_error(unit).is_empty(): return false
16071: 	if not SparkSnapper.unit_error(unit).is_empty(): return false
16072: 	if not TimewarpMolten.unit_error(unit).is_empty(): return false
```

## core/game.gd:16219-16226

```text
16219: 	if not Deadscale.unit_error(unit).is_empty(): return false
16220: 	if not TerrorguardCast.Sources.unit_error(unit).is_empty(): return false
16221: 	if not WindsSpend.Sources.unit_error(unit).is_empty(): return false
16222: 	if not Gatekeeper.Sources.unit_error(unit).is_empty(): return false
16223: 	if not Spellteach.Sources.unit_error(unit,catalog).is_empty(): return false
16224: 	if not Queensguard.Sources.unit_error(unit).is_empty(): return false
16225: 	if not FacelessDisciple.Sources.unit_error(unit).is_empty(): return false
16226: 	if not DitchGuardian.Sources.unit_error(unit).is_empty(): return false
```

## core/game.gd:16947-16951

```text
16947: func _native_result(result: Dictionary) -> bool:
16948: 	if result.ok: return true
16949: 	state.phase = "error"
16950: 	_log("coverage_error",{"message":str(result.error)})
16951: 	return false
```

## core/combat.gd:1887-1893

```text
1887: func _validate_unit(unit: Dictionary, depth: int, is_base_unit: bool = false, source_templates: Dictionary = {}) -> String:
1888: 	if not TimewarpSwirler.unit_error(unit).is_empty(): return TimewarpSwirler.unit_error(unit)
1889: 	var timewarp_scout_issue: String=TimewarpScout.unit_error(unit)
1890: 	if not timewarp_scout_issue.is_empty(): return timewarp_scout_issue
1891: 	var timewarp_red_whelp_issue: String=TimewarpRedWhelp.unit_error(unit)
1892: 	if not timewarp_red_whelp_issue.is_empty(): return timewarp_red_whelp_issue
1893: 	var spark_snapper_unit_issue: String=SparkSnapper.unit_error(unit)
```

## core/combat.gd:2138-2147

```text
2138: 	var trailblazer_unit_issue: String=TrailblazerSources.unit_error(unit)
2139: 	if not trailblazer_unit_issue.is_empty(): return trailblazer_unit_issue
2140: 	var centurion_unit_issue: String=CenturionSources.unit_error(unit)
2141: 	if not centurion_unit_issue.is_empty(): return centurion_unit_issue
2142: 	var spellteach_unit_issue: String=SpellteachSources.unit_error(unit)
2143: 	if not spellteach_unit_issue.is_empty(): return spellteach_unit_issue
2144: 	var bouncy_unit_issue: String=BouncySources.unit_error(unit)
2145: 	if not bouncy_unit_issue.is_empty(): return bouncy_unit_issue
2146: 	var health_refresh_unit_issue: String=HealthRefreshSources.unit_error(unit)
2147: 	if not health_refresh_unit_issue.is_empty(): return health_refresh_unit_issue
```

## core/mechanism_effects.gd:230-239

```text
230: static func on_event(engine, p: Dictionary, event: String, context: Dictionary = {}) -> void:
231: 	if event=="mechanic_acquired":
232: 		var forest_issue: String=Forest.acquired(engine,p,context)
233: 		if not forest_issue.is_empty(): _eot_fail(engine,forest_issue);return
234: 	if event=="mechanic_acquired" and context.get("source_id")==engine.SpellteachTrinket.Sources.ID:
235: 		var owned_teach_issue: String=engine.SpellteachTrinket.acquired(engine,p,context)
236: 		if not owned_teach_issue.is_empty(): _eot_fail(engine,owned_teach_issue);return
237: 	if event=="buy":
238: 		var owned_teach_buy_issue: String=engine.SpellteachTrinket.dispatch(engine,p,context)
239: 		if not owned_teach_buy_issue.is_empty(): _eot_fail(engine,owned_teach_buy_issue);return
```

## core/golden_rebase_state.gd:43-49

```text
43: 	if OldSoulSources.claimed(unit) and not OldSoulSources.inheritance_error([unit]).is_empty(): return false
44: 	if unit.has("taverngoer_original_stock"): return false # Native stock-lineage inheritance has no triple/rebase bridge.
45: 	if not BoogieSources.inheritance_error([unit]).is_empty(): return false
46: 	if unit.has("owner_magnetic_repeat_receipts"): return false # Receipt-holder Golden migration is not certified.
47: 	if unit.has("native_spellteach_purchase_quota") or unit.has("native_spellteach_binding"): return false
48: 	if unit.has(AutoReveilleSources.KEY) or unit.has(AutoReveilleSources.STATE): return false
49: 	if unit.has(ResourcefulSources.KEY): return false
```
