from pathlib import Path
import json,hashlib,difflib,resource
resource.setrlimit(resource.RLIMIT_AS,(128*1024**2,resource.RLIM_INFINITY))
H=Path(__file__).resolve().parent;W=H.parent;R=W/'historical_tools_batch14_20261109T191857Z/runtime';B=W/'spellteach_murloc_readonly_probe_20261110T000457Z'
def sha(b):return hashlib.sha256(b).hexdigest()
def put(rel,b):
 p=H/rel;p.parent.mkdir(parents=True,exist_ok=True);assert not p.exists();p.write_bytes(b)
pins=[]
def copy(src,rel):
 b=src.read_bytes();put(rel,b);assert src.stat().st_ino!=(H/rel).stat().st_ino;pins.append({'source':str(src.relative_to(W)),'copy':rel,'bytes':len(b),'sha256':sha(b)});return b
for rel in json.loads((B/'REPLAY_INPUTS.json').read_text()):
 if rel.startswith('gd_minimal/') and not rel.endswith('type_boundary_probe.gd'):
  copy(B/rel,rel)
for rel in ['CASES.json','PYTHON_REPORT.json','ORIGINAL_OUTPUTS.json','run_godot.py']:
 copy(B/rel,rel)
copy(B/'GODOT_first.json','baseline/GODOT_original.json')
for rel in ['core/spellteach_murloc_sources.gd','core/spellteach_murloc_host.gd','core/spellteach_murloc_cast.gd','core/spellteach_trinket_host.gd','core/spellteach_trinket_sources.gd','research/spellteach_trinket_runtime/patches/core__spellteach_murloc_sources.gd.patch','research/spellteach_murloc_native_recovery/candidates/core/spellteach_murloc_sources.gd','research/spellteach_murloc_native_recovery/candidates/tools/spellteach_murloc_native_patterns.py','research/spellteach_murloc_native_recovery/manifest.json']:
 copy(R/rel,'original_inputs/'+rel)
original=(R/'core/spellteach_murloc_sources.gd').read_bytes();assert sha(original)=='11f8b3b06cc65b484ae379fbeaf825843df0f22d55c1887d23eba152d3b41ca5'
old=b'if row.get("source_id")=="BG35_MagicItem_750":';new=b'if row.get("source_id") in ["BG35_MagicItem_750"]:'
assert original.count(old)==1
candidate=original.replace(old,new)
(H/'gd_minimal/core/spellteach_murloc_sources.gd').write_bytes(candidate)
put('candidate/core/spellteach_murloc_sources.gd',candidate)
put('gd_minimal/original/spellteach_murloc_sources.gd',original)
patch=''.join(difflib.unified_diff(original.decode().splitlines(True),candidate.decode().splitlines(True),fromfile='a/core/spellteach_murloc_sources.gd',tofile='b/core/spellteach_murloc_sources.gd'))
put('CANDIDATE.patch',patch.encode())
gate=H/'gd_minimal/gate.gd';gate_text=gate.read_text();assert gate_text.count('\"new_correction_created\":false')==1
gate.write_text(gate_text.replace('\"new_correction_created\":false','\"new_correction_created\":true'))
for pin in pins:
 pin['final_copy_sha256']=sha((H/pin['copy']).read_bytes())
 pin['copy_changed_only_for_candidate_or_test_metadata']=pin['final_copy_sha256']!=pin['sha256']
put('INPUT_PINS.json',(json.dumps(pins,indent=2)+'\n').encode())
put('CANDIDATE_MANIFEST.json',(json.dumps({'status':'NEW_LOCAL_CORRECTION_CANDIDATE_NOT_ORIGINAL_RESTORATION_NOT_LATEST_NOT_INSTALLED','original_sha256':sha(original),'candidate_sha256':sha(candidate),'bytes':len(candidate),'patch_sha256':sha(patch.encode()),'scope':'Only unit_error source_id trinket dispatch: heterogeneous Variant equality becomes singleton Array membership; existing parent membership and rejection errors retained.','original_python_compiler_not_corrected':True,'dependencies_unchanged':True,'full_pipeline_not_executed':True},indent=2)+'\n').encode())
print(json.dumps({'inputs':len(pins),'candidate_sha256':sha(candidate)}))
