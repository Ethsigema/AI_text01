# 单行 source_id 候选：独立审查

## 结论与适用范围

**通过这一个固定版本、本地单行候选的有限证据审查。没有发现候选弱化本次覆盖到的原正常允许或拒绝。不能据此批准安装、全链路集成、旧存档加载，也不能称其为历史原样恢复或最新版。**

独立审查只读取已有代码、原始日志和结果，运行了自写的纯 Python 证据核对脚本，没有重跑 Godot，没有运行原编译器、完整 host、Game、Catalog 或旧存档，没有网络请求或下载。只有本目录 `review_independent/` 中的审查文件是本审查新增的。

`verify_independent.py` 共通过 **6,273** 项断言。它未调用或导入任务作者的 `verify_results.py`，也未把 `VERIFICATION.json` 用作判断依据。结论来自候选与原件字节比较、pin 重新散列、原日志区间重建、独立期望值及 baseline 比较。此次审查仍属于对已有 Godot 实验的独立证据核对，而不是独立重现实验。

## 1. 补丁、原件与依赖

- 原文件 SHA-256：`11f8b3b06cc65b484ae379fbeaf825843df0f22d55c1887d23eba152d3b41ca5`。
- 候选 SHA-256：`8cb583cf4c1e9ddaea7579b46b9812abb05d0ac14a43a689f174f3a0a37273b8`，29,155 字节。
- 只有 `core/spellteach_murloc_sources.gd:66` 改变：`row.get("source_id")=="BG35_MagicItem_750"` 改为 `row.get("source_id") in ["BG35_MagicItem_750"]`。独立逐字替换正好生成候选；重新生成的 unified diff 与 `CANDIDATE.patch` 完全一致。
- 源树中的原文件、`original_inputs` 原件和实际测试用 `gd_minimal/original` 原件字节一致。候选交付副本与 `gd_minimal/core` 测试副本字节一致。
- `INPUT_PINS.json` 的 28 个来源全部匹配原 pin；所有来源与复制件 inode 不同。两个运行依赖 `phase_undead_army_sources.gd`、`pool_identity.gd` 还直接与 runtime 源树副本复核一致。
- 八个 `PROOF_SHA256` 文件全部按候选常量重新散列通过，说明当前所见的隔离 proof 文件已恢复到预期字节。
- `INPUT_PINS.json` 是**准备时的输入 pin 清单，不是最终目录 manifest**。最终补充的 `final_copy_sha256` 与 `copy_changed_only_for_candidate_or_test_metadata` 已逐项独立核对通过。两项变化均显式记录，其中两个 copy 预期不再匹配输入散列：测试用 Sources 已改为候选；`gate.gd` 只把 `new_correction_created:false` 改为 `true`，散列从 `34eae7d9…` 变为 `118a8b02…`。没有第三项未解释的 copy 变化。
- 原 Python 编译器与其他保存的历史证据仅核对 pin，没有修改或执行。历史 GD 版本 SHA-256 仍为 `465267b111c12f3cba4a18eef1285ed0544340207139953ea57a548dc7072f6e`。

最终发行/可移植包宜另列当前文件 manifest，不能让使用者把准备输入清单误作最终目录完整性清单。审查快照 `reviewed_file_hashes.json` 记录了此次实际读取的 158 个文件，不替代最终包装清单。

## 2. 为什么该行没有删除既有绑定条件

修改只影响选择 owned 分支的判断方式。该分支原有 `fields` 精确键集合、child 身份、物理 UID、slot 0..7、acquired event index、purchase UID 非别名、owner/round/sequence、spell_id 和 spell_program 类型检查均逐字未变。父体分支的精确字段、`source_id not in PARENTS`、UID 以及别名检查同样未变。最后的 catalog 程序一致性检查也未变。

在本次观测的 Godot 4.6.3 环境中，异型值与 String 直接 `==` 会在 184 次原调用中产生诊断并返回空字符串；singleton Array 成员判断没有产生这些诊断，并使这些值进入已有父体拒绝路径。不能把原空字符串当作校验成功，也不能用它论证新增候选收紧了原先正常允许的业务输入。

**StringName 的兼容性有意保留。** 原版会正常允许的 StringName 父体/金色/饰品身份，候选仍允许。这个补丁不是“只有 String 类型才允许”，也不应被介绍成会拒绝全部非 String 值。

## 3. 类型矩阵：覆盖与独立结果

`gd_minimal/type_matrix.gd` 使用 **58 个代表值，覆盖 39 个报告出的 Variant 类型标签**，而不是 58 种 Variant 类型。每个代表值具有 parent/owned 两种绑定形状、有/无 catalog、candidate/original/historical 三个版本，共 `58 × 2 × 2 × 3 = 696` 次，加三个空绑定字典的缺字段用例，合计 **699 次/轮**。

| 版本 | 调用 | 有诊断调用 | 无诊断允许 | 无诊断拒绝 |
|---|---:|---:|---:|---:|
| candidate | 233 | 0 | 12 | 221 |
| original | 233 | 184 | 12 | 37 |
| historical | 233 | 0 | 8 | 225 |

独立断言逐项确认：

1. 测试源码中的 58 个代表名不重复，结果的 699 个标签与完整预期笛卡尔积吻合。
2. 所有 49 个原版无诊断调用，候选返回字符串逐字相同，包含 12 个允许和 37 个拒绝。
3. 所有 184 个原版有诊断调用，诊断都定位在原 `unit_error:66`，原返回为空。候选对应调用全部无诊断并返回 `spellteach_invalid_actual_purchase_binding`。
4. candidate 允许集合仅为 parent 形状的普通/金色 String 或 StringName，以及 owned 形状的饰品 String 或 StringName，并各自覆盖有/无 catalog。
5. 历史版本的 8 次允许只包含父体形状；其不接受 owned 功能，不能因该差别把候选称为对历史原样恢复。
6. 两轮分类后 JSON 完全一致。原 GD 探针对输入序列化和 source_id identity 检查的 `failures` 均为空。

限制：58 个代表值并不是所有可能值。Object 仅用一个 RefCounted，RID/Callable/Signal 主要是空代表；packed arrays 多为空，未覆盖所有有内容或 typed 容器、释放对象、资源对象等变体。这里也没有把每一个其他绑定字段同时改成所有类型。

缺字段用例采用 `{}`，不是“其他字段完整、只删除 source_id”的单独运行用例。源码中的 `get`、`fields` 与短路顺序支持后者应拒绝，但本审查不把静态推断改写成已跑过的测试。

## 4. 主 gate：未出现结果漂移

两轮 `GODOT_first.json` / `GODOT_repeat.json` 完全一致，所有 `failures` 为空。与 `baseline/GODOT_original.json` 逐字段比较，**唯一差别是 `new_correction_created` 从 false 变 true**。

- 原主案例：1,197。
- 结构探针：17。
- effect 探针：17。
- proof 负例：8 个文件各 changed_bytes/missing，共 16。每次都报告在 catalog 读取前拒绝；当前文件散列亦确认恢复。
- unit 探针：20。正常父体、owned、owned 整数值 float slot、普通 quota 1、金色 quota 2 仍接受；别名、变更程序、bool slot、slot 越界、负 event、坏 UID、错 source、额外/缺字段、错误 body、非 Dictionary binding、quota 超限/bool 等仍拒绝。

这证明候选没有改变本组已存在结果，不代表所有既有结果本身都已安全或完整。例如原 gate 中交换/旋转映射、duplicate_normal、部分自定义商店结构仍被 closure 允许，现结果按原样保留。它是已有诊断组合入口的比较，不是完整编译器、真实 hook 或 Game 调用链验收。

`PYTHON_REPORT.json` 和 `ORIGINAL_OUTPUTS.json` 是此前结果的 pin 副本。本次主 gate 使用这些保存结果，没有重新运行 Python 编译器，更没有修复其已知边界。

## 5. 调用方抽取与 72 次探针

### 字节来源

- 完整 `saved_error` 来自 `original_inputs/core/spellteach_murloc_host.gd:111–156`，其后没有其他函数。完整字节 SHA-256 为 `b69047baef5bcec89eb87b5afabc7a6dd99497c68b3d0302d663861fe9c3fa24`。
- `_entry_error` 只抽取 `original_inputs/core/spellteach_murloc_cast.gd:22–32`，在首次 `card_error(...)` 前截止。前缀 SHA-256 为 `a76b4bdc5a2ddc44ce4ba3a1a6a6fa58d8d755ea0b69df6bcf075cc6e4b8682d`。
- 两个 fragment 的已抽取源码都逐字匹配原文件。两个 fragment 之间也只有 Sources preload 路径差别。
- fragment `saved_error:18` 诊断逐字映射原 host 的第 **119** 行；fragment `_entry_error:65` 映射原 cast 的第 **30** 行。

### 不能隐藏的 stubs

Owned.saved_receipts 固定返回空 receipts 和空 error；Cast.card_error 只认可 `PROBE_NOT_EXECUTED`；owner_error/trinket closure_error 固定返回空；catalog 是本地 ProbeCatalog。它们足够展示所测局部控制流，但没有验证真实 Owned 票据规则、真实法术允许列表、真实 owner/trinket closure 或完整 cast。

`_entry_error` 最后的 `PROBE_PREFIX_REACHED_END_NOT_ACCEPTANCE` 是到达抽取边界的哨兵，**不是施放通过或成功**。

### 结果

72 次/轮来自 6 个值 × 6 种模式 × 2 个版本。

| 版本 | 调用 | 有诊断调用 | 诊断消息 | 无诊断空返回 | 到达前缀末尾 |
|---|---:|---:|---:|---:|---:|
| original | 36 | 15 | 18 | 4 | 1 |
| candidate | 36 | 6 | 6 | 4 | 1 |

- 原版 21 个无诊断调用的返回均在候选逐字保留。
- bool/int/array 位于 unit binding 的三种模式 `good_receipt_bad_unit`、`no_receipt_bad_unit`、`cast_entry_prefix`，共 9 次候选调用改为明确拒绝且无诊断。前缀的原调用每次有两条诊断，候选提前拒绝后两条均不出现。
- bool/int/array 位于 acquisition receipt binding 的 `bad_receipt_good_unit`、`same_bad_both`，共 **6 次/版本**仍在原 host 第 119 行对应的 `binding.source_id != event.source_id` 产生诊断、返回空。该阶段发生在 unit_error 之前，单行候选没有也不能修复它。
- bad_event_source 的样本由已有 `not in PARENTS` 拒绝，没有新增候选差异。
- 两轮完全一致，输入变异检查均无失败。

这支持“局部 unit_error 提前拒绝坏 source_id 可以屏蔽后续同类分派诊断”的窄结论，不支持“所有坏存档/receipt 都 fail-closed”或“实际 Game 可达性已证明”。特别是那 6 次仍有诊断的空返回必须标成 **diagnostic failure**，不能算允许或正常返回。

## 6. 日志区间、断言与资源记录

独立脚本重新解析四份原始合流日志，而非只信任 `.classified.json`：要求无嵌套/重复调用开始、开始与结束标签严格相同、最后没有未闭合区间、区间顺序与 JSON 行完全一致、无区间外错误或其他未知文本、错误头都被归类。独立重建结果与已保存分类文件完全相同。两轮主 gate stderr 均为空，stdout 未发现错误或 warning 标记。

原 `run_bounded.py` 只是附加 diagnostics，并不会单靠有诊断就失败；其区间解析本身也不检查全部 begin/end 标签集合与记录的一一对应。`caller_probe.gd` 自己最初只有输入变异断言。这些事实不使当前日志失效，但说明“exit 0 / failures=[]”不足以证明业务成功。

作者后补的 `verify_results.py` 已审读，它现在对全部 caller 返回/诊断数量、矩阵原结果保持及 184 次转拒绝、baseline 一致性作显式断言。**这解决了本次语义预期缺少自动核对的问题。** 本独立脚本还额外验证原日志区间完整性、字节和 pin；可移植重放应始终执行语义验证，而不应仅运行 `run_bounded.py` 后以退出码宣告通过。

所有保存的资源记录报告 exit 0，峰值 RSS 约 66–79 MiB（包括后补 portable 记录），低于 192 MiB stop；类型/调用探针报告低于 45 秒超时。此处是核对已保存记录，不是独立监控或重新测量峰值。静态 preload 图未引入完整 host/cast、Game 或 Catalog，最小工程只使用 Sources、其两个既有依赖和抽取 fragment。

### 后补的 portable 与源回读材料

独立读取 `REPLAY_INPUTS.json`、`replay_to_new.py` 以及已完成的 portable 目录：26 个输入在主目录/重放目录逐字相同、散列及字节数吻合且 inode 不同；7 个所选报告逐字相同；类型/caller 的4份原始日志及4份原始JSON也逐字相同；复制的资源记录与重放目录一致。两轮主 gate stderr 为空，stdout 与主目录一致。`replay_to_new.py` 确实在三组双轮运行后调用 `verify_results.py`，并回读输入 pin 与输出。未重新执行 portable/Godot。

主 `REPORT.md` 中与本单行候选、类型矩阵、抽取函数及 portable 有关的描述与核对结果相符。其更广的静态调用图、52条源pin/9个旧封包以及全局缺口结论不是本次独立审查范围；`verify_sources.py` 与 `FINAL_SOURCE_VERIFICATION.json` 只作补充材料审读，不在此另行声称已独立重做全部广域检查。主报告会再合入审查摘要，因此不纳入独立输入hash快照，避免报告互相引用形成循环。

最终总 `FILES_SHA256` 应由封包方在所有报告定稿后生成，排除 `isolated*`、`.godot` 和不相关文件。本审查子目录的确定白名单及散列另见 `FILES.sha256`；总包及最终总清单在本审查完成时尚未生成，不声称已验包。

## 7. 尚未覆盖与发布建议

1. **保留未解决 receipt 诊断作为明确限制。** 不需要为了让本候选“全绿”改变 receipt、host 或 stubs；那是另一个修正范围。
2. **不要提升完整安全性或 reachability 结论。** 没有真实 host 依赖、真实 Owned 票据、实际购入/施放、全保存恢复、历史存档、真实 Catalog 或全编译器运行。
3. **不能推广成 unit_error 的全面类型硬化。** 例如 row.uid/body 字段等仍有原有直接比较，候选未改；当前矩阵只针对 source_id 变量，其余字段基本有效。
4. **调用探针样本较小。** 只含 canonical/bool/int/array/null/unknown，未测 caller 层 StringName/golden/owned 三方组合、cast 票据、多个 players/events、四个 zone 的所有差别、时间/配额/重放交互或真正的施放后续代码。
5. **保持版本限定。** 日志对应 Godot `4.6.3.stable.official.7d41c59c4`；无其他 Godot 版本、release/export 或平台兼容性结论。
6. **最终包另做当前 hash 清单。** 两个 INPUT_PINS copy 差异已经明确，portable 已执行语义 verifier并完成独立字节核验；复核后若修改测试或候选，需重验相关证据。本报告仅对上述固定候选 SHA 生效。

本审查没有要求额外候选改动，没有发现阻碍本单行候选被作为“有限验证的新本地修正候选”保存的缺陷；上述边界阻止将其升级成完整集成/安装批准。

## 审查产物

- `verify_independent.py`：独立、只读输入核对脚本。
- `independent_checks.json`：汇总和 6,273 项检查结果。
- `verify_stdout.json`：此次脚本标准输出。
- `reviewed_file_hashes.json`：158 个已读取证据文件的字节长度与散列。
- `REVIEW.md`：本报告。

运行方式：在本次原工作区保留证据目录、被 pin 的同级原来源目录及 `PORTABLE_REPLAY_RESULT.json` 所指的已完成重放目录，然后运行 `python review_independent/verify_independent.py`。这是本地独立审计脚本，并非无需原来源的便携入口。独立包的可移植重放使用主目录的 `replay_to_new.py` 和 `verify_results.py`。审计脚本只在 `review_independent/` 写结果文件，并要求被审原证据在该次检查期间未变化。
