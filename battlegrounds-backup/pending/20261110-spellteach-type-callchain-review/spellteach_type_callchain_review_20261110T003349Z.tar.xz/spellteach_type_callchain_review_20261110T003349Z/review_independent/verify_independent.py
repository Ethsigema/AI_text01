#!/usr/bin/env python3
"""Read-only audit of supplied evidence. Never imports/runs tested code or Godot.

Writes only independent_checks.json and reviewed_file_hashes.json beside this file.
No network, compiler, full host, Game, Catalog, or old-save execution.
"""
from pathlib import Path
from collections import Counter
import difflib
import hashlib
import itertools
import json
import re

OUT = Path(__file__).resolve().parent
H = OUT.parent
W = H.parent
R = W / 'historical_tools_batch14_20261109T191857Z/runtime'
observed = {}
checks = 0

def need(condition, message):
    global checks
    checks += 1
    if not condition:
        raise AssertionError(message)

def sha(data):
    return hashlib.sha256(data).hexdigest()

def read(path):
    path = Path(path)
    data = path.read_bytes()
    observed[str(path.relative_to(W))] = {'bytes': len(data), 'sha256': sha(data)}
    return data

def document(name):
    return json.loads(read(H / name))

manifest = document('CANDIDATE_MANIFEST.json')
original = read(H / 'original_inputs/core/spellteach_murloc_sources.gd')
candidate = read(H / 'candidate/core/spellteach_murloc_sources.gd')
old = b'if row.get("source_id")=="BG35_MagicItem_750":'
new = b'if row.get("source_id") in ["BG35_MagicItem_750"]:'
need(sha(original) == '11f8b3b06cc65b484ae379fbeaf825843df0f22d55c1887d23eba152d3b41ca5', 'original hash')
need(sha(candidate) == '8cb583cf4c1e9ddaea7579b46b9812abb05d0ac14a43a689f174f3a0a37273b8', 'candidate hash')
need(original.count(old) == 1 and candidate == original.replace(old, new), 'only the requested byte replacement')
need(read(R / 'core/spellteach_murloc_sources.gd') == original, 'runtime original unchanged')
need(read(H / 'gd_minimal/core/spellteach_murloc_sources.gd') == candidate, 'executed candidate copy')
need(read(H / 'gd_minimal/original/spellteach_murloc_sources.gd') == original, 'executed original copy')
changed_lines = [i for i, (a, b) in enumerate(zip(original.splitlines(), candidate.splitlines()), 1) if a != b]
need(changed_lines == [66] and len(original.splitlines()) == len(candidate.splitlines()), 'single changed line 66')
patch = ''.join(difflib.unified_diff(original.decode().splitlines(True), candidate.decode().splitlines(True), fromfile='a/core/spellteach_murloc_sources.gd', tofile='b/core/spellteach_murloc_sources.gd')).encode()
need(read(H / 'CANDIDATE.patch') == patch and sha(patch) == manifest['patch_sha256'], 'exact patch regeneration')
need(manifest['bytes'] == len(candidate) and manifest['candidate_sha256'] == sha(candidate) and manifest['original_sha256'] == sha(original), 'manifest identities')

pins = document('INPUT_PINS.json')
pin_exceptions = []
for pin in pins:
    source = read(W / pin['source'])
    copied = read(H / pin['copy'])
    need(sha(source) == pin['sha256'] and len(source) == pin['bytes'], 'pinned source ' + pin['source'])
    need(sha(copied) == pin['final_copy_sha256'], 'explicit final copy hash ' + pin['copy'])
    need(pin['copy_changed_only_for_candidate_or_test_metadata'] == (copied != source), 'explicit copy change marker ' + pin['copy'])
    need((W / pin['source']).stat().st_ino != (H / pin['copy']).stat().st_ino, 'independent copied inode ' + pin['copy'])
    if copied != source:
        if pin['copy'] == 'gd_minimal/core/spellteach_murloc_sources.gd':
            need(copied == candidate and source == original, 'candidate is intentional pin departure')
        elif pin['copy'] == 'gd_minimal/gate.gd':
            before = b'"new_correction_created":false'
            after = b'"new_correction_created":true'
            need(source.count(before) == 1 and copied == source.replace(before, after), 'only gate metadata change')
        else:
            raise AssertionError('unexpected changed copy ' + pin['copy'])
        pin_exceptions.append({'path': pin['copy'], 'input_sha256': pin['sha256'], 'current_sha256': sha(copied)})
need(len(pins) == 28 and len(pin_exceptions) == 2, '28 inputs and two disclosed transformed copies')
for dependency in ['phase_undead_army_sources.gd', 'pool_identity.gd']:
    need(read(R / 'core' / dependency) == read(H / 'gd_minimal/core' / dependency), 'runtime dependency matches ' + dependency)
proof_line = next(line for line in candidate.decode().splitlines() if line.startswith('const PROOF_SHA256:'))
proof = json.loads(proof_line.split('=', 1)[1])
need(len(proof) == 8, 'proof file count')
for path, digest in proof.items():
    need(sha(read(H / 'gd_minimal' / path)) == digest, 'proof bytes restored and pinned ' + path)

# Independently locate exact function extents from top-level declarations, not
# by importing or rerunning the author's extraction script.
host = read(H / 'original_inputs/core/spellteach_murloc_host.gd')
cast = read(H / 'original_inputs/core/spellteach_murloc_cast.gd')
saved_start = host.index(b'static func saved_error(')
need(host.find(b'\nstatic func ', saved_start) == -1, 'saved_error is complete final function')
saved = host[saved_start:]
entry_start = cast.index(b'static func _entry_error(')
entry_stop = cast.index(b'\tissue=card_error(engine.catalog,str(binding.spell_id))', entry_start)
prefix = cast[entry_start:entry_stop]
records = document('EXTRACTED_FUNCTIONS.json')
need(len(records) == 2, 'two fragment records')
for record in records:
    fragment = read(H / record['output'])
    need(sha(fragment) == record['sha256'], 'fragment hash')
    need(fragment.count(saved) == 1 and fragment.count(prefix) == 1, 'exact extracted function bytes')
    need(sha(saved) == record['saved_error_exact_original_function_sha256'], 'saved_error hash')
    need(sha(prefix) == record['cast_entry_prefix_exact_original_sha256'], 'entry prefix hash')
    need(fragment.endswith(prefix + b'\treturn "PROBE_PREFIX_REACHED_END_NOT_ACCEPTANCE"\n'), 'prefix ends with nonacceptance sentinel')
    need(b'static func saved_receipts(_state,_catalog,_events): return {"error":"","receipts":{}}' in fragment, 'Owned is explicit empty-receipt stub')
    need(b'static func card_error(_catalog,id): return "" if id=="PROBE_NOT_EXECUTED" else "PROBE_STUB_UNKNOWN_SPELL"' in fragment, 'Cast is explicit spell stub')
f0 = read(H / records[0]['output'])
f1 = read(H / records[1]['output'])
need(f1 == f0.replace(b'res://original/spellteach_murloc_sources.gd', b'res://core/spellteach_murloc_sources.gd'), 'fragments differ only in Sources preload')
need(saved.splitlines()[8] == host.splitlines()[118], 'fragment diagnostic line 18 maps to host line 119')
need(prefix.splitlines()[8] == cast.splitlines()[29], 'entry diagnostic maps to cast line 30')

def classify_again(stem):
    raw = document(stem + '.json')
    recorded = document(stem + '.classified.json')
    lines = read(H / (stem + '.log')).decode().splitlines()
    active = None
    order = []
    intervals = {}
    outside = []
    for line in lines:
        if line.startswith('CALL_BEGIN|'):
            label = line.partition('|')[2]
            need(active is None and label not in intervals, 'no nested/duplicate call ' + label)
            active = label
            order.append(label)
            intervals[label] = []
        elif line.startswith('CALL_END|'):
            need(active == line.partition('|')[2], 'balanced end marker')
            active = None
        elif active is None:
            outside.append(line)
        else:
            intervals[active].append(line)
    need(active is None, 'all calls closed')
    need(order == [row['label'] for row in raw['results']], 'complete log/report label bijection and ordering')
    need(all(line == '' or line.startswith('Godot Engine v4.6.3.stable.official.7d41c59c4 - ') for line in outside), 'no outside diagnostics or unexpected log text')
    for row in raw['results']:
        contents = intervals[row['label']]
        diagnostics = [line for line in contents if line.startswith('SCRIPT ERROR:')]
        need(all(not re.search(r'ERROR|WARNING|CRASH|FATAL', line) or line in diagnostics for line in contents), 'no unclassified diagnostic header ' + row['label'])
        row['diagnostics'] = diagnostics
    need(raw == recorded, 'independent interval classification matches stored JSON ' + stem)
    need(not raw['failures'], 'probe did not report input mutation/embedded assertion failure')
    return raw, intervals

matrix1, matrix_log = classify_again('TYPE_MATRIX_1')
matrix2, _ = classify_again('TYPE_MATRIX_2')
caller1, caller_log = classify_again('CALLER_PROBE_1')
caller2, _ = classify_again('CALLER_PROBE_2')
need(matrix1 == matrix2 and caller1 == caller2, 'both repeated classified probes identical')
matrix = matrix1['results']
need(len(matrix) == 699 and matrix1['variant_representatives'] == 58, '58 x 2 x 2 x 3 plus 3')
matrix_source = read(H / 'gd_minimal/type_matrix.gd').decode()
values_block = matrix_source.split('func _values()->Array:', 1)[1].split('func _unit()', 1)[0]
cases = re.findall(r'\["([a-z0-9_]+)",', values_block)
need(len(cases) == 58 and len(set(cases)) == 58, '58 distinct representative names from test source')
versions = ['candidate', 'original', 'historical']
labels = {f'{v}:{case}:{shape}:{with_catalog}' for v, case, shape, with_catalog in itertools.product(versions, cases, ['parent', 'owned'], ['false', 'true'])}
labels |= {v + ':missing_key' for v in versions}
need(set(r['label'] for r in matrix) == labels, 'full intended matrix cartesian product')
need(len({r['variant_type'] for r in matrix if 'variant_type' in r}) == 39, '39 distinct reported Variant type tags')
indexed = {r['label']: r for r in matrix}
stats = {}
preserved = fixed = 0
parent_good = {'string_parent', 'string_golden', 'stringname_parent', 'stringname_golden'}
owned_good = {'string_trinket', 'stringname_trinket'}
for row in matrix:
    if row['version'] == 'candidate':
        accepted = row['case'] != 'missing_key' and ((row['shape'] == 'parent' and row['case'] in parent_good) or (row['shape'] == 'owned' and row['case'] in owned_good))
        need(not row['diagnostics'] and (row['returned'] == '') == accepted, 'independent candidate allowlist ' + row['label'])
    elif row['version'] == 'original':
        c = indexed[row['label'].replace('original:', 'candidate:', 1)]
        if row['diagnostics']:
            need(len(row['diagnostics']) == 1 and "operator '=='" in row['diagnostics'][0], 'one original equality diagnostic')
            need(any('at: unit_error (res://original/spellteach_murloc_sources.gd:66)' in line for line in matrix_log[row['label']]), 'original diagnostic exact location')
            need(row['returned'] == '' and c['returned'] == 'spellteach_invalid_actual_purchase_binding', 'diagnostic empty return becomes explicit rejection')
            fixed += 1
        else:
            need(row['returned'] == c['returned'], 'exact original clean result preserved ' + row['label'])
            preserved += 1
    else:
        accepted = row['case'] != 'missing_key' and row['shape'] == 'parent' and row['case'] in parent_good
        need(not row['diagnostics'] and (row['returned'] == '') == accepted, 'historical independent allowlist')
for version in versions:
    subset = [r for r in matrix if r['version'] == version]
    stats[version] = {'calls': len(subset), 'diagnostic_calls': sum(bool(r['diagnostics']) for r in subset), 'clean_accept': sum(not r['diagnostics'] and r['returned'] == '' for r in subset), 'clean_reject': sum(not r['diagnostics'] and r['returned'] != '' for r in subset)}
need((preserved, fixed) == (49, 184), 'preservation/fix totals')

caller = caller1['results']
modes = ['good_receipt_bad_unit', 'no_receipt_bad_unit', 'bad_receipt_good_unit', 'same_bad_both', 'bad_event_source', 'cast_entry_prefix']
kinds = ['canonical', 'bool', 'int', 'array', 'null', 'unknown']
need(len(caller) == 72 and {r['label'] for r in caller} == {f'{v}:{m}:{k}' for v, m, k in itertools.product(['original', 'candidate'], modes, kinds)}, '72 caller combinations')
caller_index = {r['label']: r for r in caller}
caller_stats = {}
caller_preserved = 0
for row in caller:
    version, mode, kind = row['label'].split(':')
    malformed = kind in ['bool', 'int', 'array']
    diagnostic_count = 0
    if kind == 'canonical':
        expected = {'no_receipt_bad_unit': 'spellteach_unproven_saved_teaching_lineage', 'cast_entry_prefix': 'PROBE_PREFIX_REACHED_END_NOT_ACCEPTANCE'}.get(mode, '')
    elif mode == 'bad_event_source':
        expected = 'spellteach_invalid_acquisition_receipt'
    elif mode in ['bad_receipt_good_unit', 'same_bad_both']:
        expected = '' if malformed else 'spellteach_changed_acquisition_binding'
        diagnostic_count = int(malformed)
        if malformed:
            need(any(f'at: saved_error (res://fragments/caller_{version}.gd:18)' in line for line in caller_log[row['label']]), 'receipt error maps to host119')
            need(all("operator '!='" in message for message in row['diagnostics']), 'receipt inequality diagnostic')
    elif version == 'original' and malformed:
        expected = '' if mode == 'cast_entry_prefix' else 'spellteach_unproven_saved_teaching_lineage'
        diagnostic_count = 2 if mode == 'cast_entry_prefix' else 1
    else:
        expected = 'spellteach_invalid_actual_purchase_binding'
    need(row['returned'] == expected and len(row['diagnostics']) == diagnostic_count, 'independent caller return/diagnostic oracle ' + row['label'])
    if version == 'original' and not row['diagnostics']:
        c = caller_index[row['label'].replace('original:', 'candidate:', 1)]
        need(not c['diagnostics'] and c['returned'] == row['returned'], 'caller originally clean behavior preserved')
        caller_preserved += 1
for version in ['original', 'candidate']:
    subset = [r for r in caller if r['version'] == version]
    caller_stats[version] = {'calls': len(subset), 'diagnostic_calls': sum(bool(r['diagnostics']) for r in subset), 'diagnostic_messages': sum(len(r['diagnostics']) for r in subset), 'clean_empty': sum(not r['diagnostics'] and r['returned'] == '' for r in subset), 'prefix_sentinels': sum(r['returned'] == 'PROBE_PREFIX_REACHED_END_NOT_ACCEPTANCE' for r in subset)}
need(caller_preserved == 21 and caller_stats['candidate']['diagnostic_calls'] == 6, 'caller preservation and unresolved receipt count')

gate = document('GODOT_first.json')
repeat = document('GODOT_repeat.json')
baseline = document('baseline/GODOT_original.json')
need(gate == repeat and not gate['failures'], 'repeated main gate identical/no recorded failures')
need({k for k in gate.keys() | baseline.keys() if gate.get(k) != baseline.get(k)} == {'new_correction_created'}, 'only metadata differs from baseline')
need(gate['new_correction_created'] is True and baseline['new_correction_created'] is False, 'metadata accurately records candidate')
need(gate['case_count'] == len(gate['results']) == len(document('CASES.json')) == 1197, 'main case sizes')
need(len(gate['structural_probes']) == 17 and len(gate['effect_probes']) == 17 and len(gate['proof_tests']) == 16 and len(gate['historical_current_unit_probes']) == 20, 'subprobe sizes')
need({(r['path'], r['mode']) for r in gate['proof_tests']} == set(itertools.product(proof, ['changed_bytes', 'missing'])), 'all proof file negative variants')
need(all(r['isolated_copy_restored'] and r['catalog_reads_before_reject'] == 0 for r in gate['proof_tests']), 'proof rejection before catalog reads')
for label in ['first', 'repeat']:
    need(read(H / f'GODOT_{label}.stderr.log') == b'', 'main gate empty stderr ' + label)
    stdout = read(H / f'GODOT_{label}.stdout.log').decode()
    need(not re.search(r'ERROR|WARNING|CRASH|FATAL', stdout), 'main gate no stdout diagnostics ' + label)
for stats_file in ['TYPE_MATRIX_1.resources.json', 'TYPE_MATRIX_2.resources.json', 'CALLER_PROBE_1.resources.json', 'CALLER_PROBE_2.resources.json']:
    resources = document(stats_file)
    need(resources['exit'] == 0 and resources['peak_rss_kib'] < resources['rss_stop_kib'] and resources['seconds'] < resources['timeout_seconds'], 'bounded runtime record ' + stats_file)
for resources in document('GODOT_RUNS.json'):
    need(resources['exit_code'] == 0 and resources['stopped'] is None and resources['peak_rss_kib'] < resources['rss_stop_kib'], 'main bounded runtime record')

# Inventory all reachable static loads in the minimal project. This does not
# claim an executable trace, just verifies there is no complete-host preload.
loads = {}
for path in sorted((H / 'gd_minimal').rglob('*.gd')):
    body = read(path).decode()
    targets = re.findall(r'(?:preload|load)\("res://([^"\n]+)"\)', body)
    loads[str(path.relative_to(H))] = targets
    need(all((H / 'gd_minimal' / target).is_file() for target in targets), 'all local preloads resolved')
    need(all(not target.endswith(('_host.gd', '_cast.gd')) and not re.search(r'(^|/)(game|catalog)\.gd$', target, re.I) for target in targets), 'no full host/Game/Catalog preload')

# Read the author's later verifier as evidence only; do not use its computed
# VERIFICATION.json as an oracle or invoke the original compiler.
read(H / 'verify_results.py')
read(H / 'VERIFICATION.json')
read(H / 'run_bounded.py')
read(H / 'run_godot.py')
read(H / 'prepare.py')
read(H / 'extract_callers.py')
# The author's top-level narrative incorporates this review after completion;
# it was read separately, not pinned here to avoid a circular report snapshot.
read(H / 'verify_sources.py')
read(H / 'FINAL_SOURCE_VERIFICATION.json')

# Review the author's already-completed portable execution by direct bytes.
# Do not execute its replay script or any additional Godot call.
portable = document('PORTABLE_REPLAY_RESULT.json')
portable_dir = Path(portable['output'])
need(portable_dir.parent == W and portable_dir != H, 'separate sibling portable evidence directory')
replay_inputs = document('REPLAY_INPUTS.json')
need(len(replay_inputs) == portable['copied_files'] == 26, 'portable input count')
for name, pin in replay_inputs.items():
    local = read(H / name)
    remote = read(portable_dir / name)
    need(local == remote and len(local) == pin['bytes'] and sha(local) == pin['sha256'], 'portable input exact pin ' + name)
    need((H / name).stat().st_ino != (portable_dir / name).stat().st_ino, 'portable input independent inode ' + name)
selected = ['GODOT_first.json', 'GODOT_repeat.json', 'TYPE_MATRIX_1.classified.json', 'TYPE_MATRIX_2.classified.json', 'CALLER_PROBE_1.classified.json', 'CALLER_PROBE_2.classified.json', 'VERIFICATION.json']
for name in selected:
    need(read(H / name) == read(portable_dir / name), 'portable selected report exact bytes ' + name)
for prefix in ['TYPE_MATRIX', 'CALLER_PROBE']:
    for run in [1, 2]:
        for suffix in ['json', 'log']:
            name = f'{prefix}_{run}.{suffix}'
            need(read(H / name) == read(portable_dir / name), 'portable raw output/log exact bytes ' + name)
        name = f'{prefix}_{run}.resources.json'
        need(read(H / ('PORTABLE_' + name)) == read(portable_dir / name), 'portable copied resource report ' + name)
        resources = json.loads(read(portable_dir / name))
        need(resources['exit'] == 0 and resources['seconds'] < 45 and resources['peak_rss_kib'] < 192 * 1024, 'portable bounded probe runtime')
need(read(H / 'PORTABLE_GODOT_RUNS.json') == read(portable_dir / 'GODOT_RUNS.json'), 'portable main resource report copy')
need(read(H / 'PORTABLE_REPLAY_RESULT.json') == read(portable_dir / 'REPLAY_RESULT.json'), 'portable replay result copy')
for resources in document('PORTABLE_GODOT_RUNS.json'):
    need(resources['exit_code'] == 0 and resources['stopped'] is None and resources['seconds'] < 45 and resources['peak_rss_kib'] < 192 * 1024, 'portable main bounded runtime')
for run in ['first', 'repeat']:
    need(read(portable_dir / f'GODOT_{run}.stderr.log') == b'', 'portable main empty stderr')
    need(read(portable_dir / f'GODOT_{run}.stdout.log') == read(H / f'GODOT_{run}.stdout.log'), 'portable main stdout identical')
replay_script = read(H / 'replay_to_new.py')
need(b"['verify_results.py']" in replay_script, 'portable replay invokes semantic verifier')
read(H / 'PORTABLE_REPLAY.stdout.log')
for relative, snapshot in observed.items():
    data = (W / relative).read_bytes()
    need(len(data) == snapshot['bytes'] and sha(data) == snapshot['sha256'], 'reviewed input unchanged during review ' + relative)

summary = {'status': 'PASS_FOR_PINNED_SINGLE_LINE_LOCAL_CANDIDATE_ONLY', 'method': 'Independent Python evidence audit; no Godot rerun or compiler/full pipeline execution', 'assertions_passed': checks, 'candidate_sha256': sha(candidate), 'original_sha256': sha(original), 'patch_changed_lines': changed_lines, 'pin_entries': len(pins), 'pin_copy_intentional_departures': pin_exceptions, 'matrix': stats, 'representative_values': 58, 'variant_type_tags': 39, 'matrix_original_clean_results_preserved': preserved, 'matrix_diagnostics_replaced_by_explicit_rejection': fixed, 'caller': caller_stats, 'caller_original_clean_results_preserved': caller_preserved, 'caller_candidate_unresolved_receipt_diagnostics': 6, 'gate': {'cases': 1197, 'structural': 17, 'effect': 17, 'proof': 16, 'unit': 20, 'baseline_only_changed_key': 'new_correction_created'}, 'extracted_source_lines': {'saved_error_full': [111, 156], 'entry_prefix': [22, 32], 'remaining_receipt_diagnostic': 119, 'original_entry_dispatch_diagnostic': 30}, 'static_loads': loads, 'portable': {'input_files': 26, 'selected_reports_byte_identical': len(selected), 'raw_type_and_caller_logs_byte_identical': True, 'inputs_remain_pinned': True, 'semantic_verifier_in_replay': True}, 'reviewed_files': len(observed), 'read_only_inputs_unchanged_at_end': True, 'limits': ['No independent Godot execution', 'Not complete integration/reachability validation', 'No universal proof across all values or non-source_id malformed fields', 'Receipt source_id diagnostics still exist', 'StringName acceptance retained by design; this is not strict String-only validation', 'Input pin list now explicitly contains final copy hashes; it is not a complete final package manifest', 'Broader static callchain and legacy archive claims remain outside this focused independent review']}
(OUT / 'independent_checks.json').write_text(json.dumps(summary, indent=2, ensure_ascii=False) + '\n')
(OUT / 'reviewed_file_hashes.json').write_text(json.dumps(observed, indent=2, sort_keys=True) + '\n')
print(json.dumps(summary, indent=2, ensure_ascii=False))
