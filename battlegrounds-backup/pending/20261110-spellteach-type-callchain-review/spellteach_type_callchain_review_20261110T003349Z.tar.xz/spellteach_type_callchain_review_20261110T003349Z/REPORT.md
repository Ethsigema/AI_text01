# 魔鳍 source_id 类型诊断：调用链与独立局部修正候选

## 结论

有真实源码调用边连接到该诊断点，但没有证明完整游戏、真实存档或正常购买流程能产生并通过全部检查到达坏输入。本轮没有运行 Game、Combat、完整 Catalog、编译器或完整 host，也没有读取旧存档。

可以保留一项有局部证据的新修正候选：仅把 Sources.unit_error 第66行的饰品分支判断由异类型 `==` 改为单元素 Array 成员判断。它让已测异型 source_id 正常返回原有拒绝错误，保留原版正常成功及拒绝行为，不把 bool/数字转换成字符串，也不放宽字段、收据、UID或配额校验。

候选不安装。它不是历史原样恢复、已确认最新版或整体修复。普通取得事件 binding 中还存在另一处已在显式 stub 片段中复现的诊断，候选不覆盖该路径；饰品 ledger/事件还有静态待核边界。完整集成、Game和旧存档仍未验收。

- 当前原 GD：29,151 bytes，SHA-256 `11f8b3b06cc65b484ae379fbeaf825843df0f22d55c1887d23eba152d3b41ca5`。
- 独立候选：29,155 bytes，SHA-256 `8cb583cf4c1e9ddaea7579b46b9812abb05d0ac14a43a689f174f3a0a37273b8`。
- 新补丁 SHA-256：`19c9793ac1b632f181e4bba3983ed4312ecb1ded40f33e14f7ee06a81e7c061e`。
- 历史 GD、当前原件、历史工具、家族 manifest 和饰品历史补丁分别保留。没有覆盖原树或旧备份，未修复旧 Python 工具的 bool/数值相等差异。

## 1. 实际调用顺序与可达性边界

详见 static_callchain/REPORT.md 和带精确行号的 EXCERPTS.md。静态审阅固定11份当前源码及5份旧证据，另保存7个原字节函数片段。

### 正常生成来源

普通父体 prepare/dispatch 仅选择 PARENTS 中的实际 board source，经真实 owner、shop 对象、支付、购买完成、原对象身份、quota与完整投影检查后，使用 source.card_id 写入 binding。饰品路径使用固定 String 常量 BG35_MagicItem_750，绑定实际 slot 和取得事件。

未发现这两条正常写入路径主动生成 bool/int/Array source_id。当前目标卡牌的历史数据核验也不能替代真实手牌、事件或存档证据；本轮不声称真实数据污染。

### 保存与加载

Game.save_to:13842 调 Spellteach.saved_error，非空则拒绝保存。加载链为 load_from → _load_scoped_game 新建私有 candidate → candidate._read_scoped_game → _normalize_numbers → _valid_save。只有私有 candidate 成功返回 OK 后才发布到 live 引擎。

_valid_save:15303 的可见单位门控要求 Dictionary、uid/card_id 为 String，随后 _valid_unit_state:16223 调 unit_error；minion 的 Combat._validate_unit:2142 再调一次；_valid_save:15537 最后才调用 Spellteach.saved_error 核收据。所查看的这些外层函数没有先约束嵌套 TAUGHT.source_id；_normalize_numbers 只把整值 float 转 int，不把 bool/int/Array 转 String。

不能把“未见这个字段的直接前置 guard”升级为“完整加载可达”。大量其他家族检查没有执行或穷尽审计，真实存档未读取。私有 candidate 的发布边界也限制失败加载向 live state 传播。

### 单位与收据检查先后

Sources.unit_error:65 仅先检查 binding 是 Dictionary，66 即直接与 String 比较；具体字段成员校验在68/70之后。

Spellteach.saved_error:144 先调 unit_error，145仅按非空拒绝；154才比较完整 unit binding 与已验证 receipt binding。若只是单位字段污染而收据正常或缺失，局部流程可以先诊断，再被154拒绝。这是后置拒绝，不是该诊断点不可达。

如果污染的是 event.binding.source_id，saved_error:119 会在单位循环之前做直接 `!=` 比较。不能笼统说154一定兜住。饰品 saved_receipts 的 ledger、event和binding也有独立比较位置，此次只有静态记录，没有运行完整饰品 host。

### 施放与其他调用点

Cast.prepare 先检查真实 Game、招募 owner、原 hand 对象、容量、active及真实 play command，后调用 _entry_error；其23先 unit_error，30再比较 binding.source_id，95才回到 saved_error。候选可让经过 unit_error 的坏单位提前拒绝，但不代表绕过其前面的真实 host/对象门控。

另外 _add_hand、_prize_source_error、单位统一校验、普通命令预检均有真实引用。静态链接与单独返回值行为不是实际购买、施放、加载成功的证明。

## 2. 新候选的范围与版本身份

唯一工程代码变化：

`if row.get("source_id")=="BG35_MagicItem_750":`

改为：

`if row.get("source_id") in ["BG35_MagicItem_750"]:`

现有普通父体分支本来使用 `row.source_id not in PARENTS`。新写法避免不兼容 Variant 的字符串相等比较；不做强制 str 转换，不更改 branch 内条件、错误码、RAW、EXPECTED、PROGRAMS、PROOF_SHA256、继承限制、默认关闭或 partial 标记。

测试保留当前原版对合法 StringName 身份的局部接受行为，没有擅自加一个只接受 String 的新约束。StringName 是否能来自真实 JSON存档不是本候选声称的内容。

依赖仍仅为当前 Sources、Exact、PoolIdentity；历史 Sources 只用于版本对照。八份 proof 原文件保持固定 pin。新增候选身份仅由本包 manifest/hash 表示，没有改历史 manifest 或把旧 proof pin 宣称为新代码认证。

## 3. 实际 GD 的类型正反例

type_matrix.gd 在最小独立工程中调用原版、历史版、候选版真实 unit_error。58个代表值覆盖本机 Godot 4.6.3 的39个 Variant 类型类别，含 bool、int、float、NaN/±Inf、String、StringName、NodePath、Array、Dictionary和各内建值类型。

每个值覆盖父体/饰品两种 binding 形状、无catalog/最小ProbeCatalog两种方式，另有空binding缺字段控制例。共699调用，逐次用 CALL_BEGIN/CALL_END 将诊断归到调用，重复两轮结果一致。

| 版本 | 调用 | 诊断调用 | 无诊断空返回 | 无诊断拒绝 |
|---|---:|---:|---:|---:|
| 当前原版 | 233 | 184 | 12 | 37 |
| 独立候选 | 233 | 0 | 12 | 221 |
| 历史版本 | 233 | 0 | 8 | 225 |

当前原版49个无诊断结果在候选中逐字保持；184个诊断调用均变为 spellteach_invalid_actual_purchase_binding。原版诊断后的空String不算正常接受，exit=0也不算通过。历史版少4个正常允许调用源于尚未加入饰品分支，不是候选回退功能。

所有fixture输入未变异。此矩阵是代表性值覆盖，不声称穷尽某一类型所有值、悬空对象、所有其他字段组合或整个验证器的鲁棒性。

## 4. 真实函数片段的限定验证

extract_callers.py 从保留原件逐字截取：

- host.saved_error 的完整函数体（111–156），但依赖 Owned.saved_receipts 和 Cast.card_error 是明确标识的测试 stub。
- Cast._entry_error 从函数头到饰品 closure guard 的原始前缀（22–32），随后返回 PROBE_PREFIX_REACHED_END_NOT_ACCEPTANCE。真实 Sources.closure_error 使用八份proof和最小合成Catalog；owner与trinket closure是明确stub。没有运行 prepare的真实host/hand门控或后续cast逻辑。

72次调用，每版36次，重复两轮：规范对照、bool/int/Array/null/未知String，分别放在坏单位、坏receipt、二者同时、event顶层source，以及施放入口前缀。

- 只有单位坏且有正常收据/无收据：原版bool/int/Array先各产生一条unit_error诊断，再返回 unproven_saved_teaching_lineage；候选无诊断、提前返回 invalid_actual_purchase_binding。
- 施放前缀：原版bool/int/Array分别在 unit_error 和第二次分支比较产生两条诊断；候选在第一次unit_error正常拒绝，未到第二次比较。规范对照只到达sentinel，不算完成施放。
- 只有event.binding坏或与单位同时坏：两个版本都在原host第119行的直接比较诊断，早于unit_error，随后返回空String。候选每轮仍有6个这样的调用，不把空返回称为通过，也没有修改它们。
- event顶层source_id异型被既有PARENTS成员门控正常拒绝，两版一致。

每轮原版36调用中15次含18条诊断；候选36调用中6次含6条诊断。此测试只证明抽取代码在明确stub/fixture条件下的顺序和传播。它既不是完整host测试，也不证明某真实玩家状态能通过其余检查。测试脚本先记录结果，verify_results.py逐例断言期望返回及诊断数量，独立复核另从日志重建区间。

## 5. 回归、复跑与资源

既有1197例真实GD raw/proof/closure诊断组合、17结构例、17效果例、16个proof负变体及20个unit例均在候选最小工程重新执行两轮。结果仅 new_correction_created 元数据由false改为true，其余与已固定pin的此前原版结果完全相同。原Python结果作为已核pin的既有对照输入使用；本轮没有重跑完整编译器或声称旧Python差异已修复。

所有proof负变体只修改新测试副本，并恢复回读；runtime原proof未修改。26文件便携副本从本包白名单生成，重复主GD双轮、类型矩阵双轮、caller片段双轮与逐例断言。所选结果JSON逐字一致，不依赖原runtime，不下载或安装Godot。

便携入口：`python3 replay_to_new.py /一个尚不存在的绝对目录`。

主GD每轮约2.3–2.6秒，含便携复跑峰值约78.6MiB；类型/片段每轮约0.3–0.6秒、峰值约68MiB。Godot保持192MiB RSS停止线、2GiB地址空间、45秒时限及系统可用内存检查，串行运行、HOME/XDG隔离。源回读Python约12.5MiB，限128MiB地址空间。

独立审查另以自写Python通过6,273项断言：重建四份原始合流日志的完整区间，核对标签、顺序、逐例返回、诊断位置、原件pin、单行diff和最小preload图；未重跑Godot。它确认49个原版无诊断矩阵结果及21个原版无诊断caller结果保持，仍明确保留6个receipt诊断限制。详情见 review_independent/REVIEW.md。独立核对脚本需要本轮原工作区来源及已完成的便携目录，不是另一个便携入口；可移植复跑使用 replay_to_new.py。

## 6. 保留边界与下一步

52条来源pin记录（47个唯一路径）及9个旧封包回读未变；Game和Catalog原哈希未变。345个缺失工具仍缺失，XML36.6.3候选未安装。四份全局原证据与两份全局合同缺口未填补；不得把家族contract当作替代。

本候选可作为局部类型拒绝修正继续审查，不能安装成“全部恢复”。若继续调查，应独立确认event.binding和饰品ledger比较的安全拒绝域，保留其真实返回及诊断，不以宽松stub结果代替实际调用授权或集成验收。完整driver及依赖未闭合、Game和旧存档未验收边界维持。

全程本地，不访问网络、不下载、不重试取消的第14批操作。封包只含白名单源原件、候选、补丁、脚本、报告和必要诊断，排除隔离HOME/XDG、缓存、凭据、私聊和存档。
