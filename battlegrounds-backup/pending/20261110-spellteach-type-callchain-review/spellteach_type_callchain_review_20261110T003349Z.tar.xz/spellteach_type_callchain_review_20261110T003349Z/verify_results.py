from pathlib import Path
import json,collections,hashlib
H=Path(__file__).resolve().parent
def read(n):return json.loads((H/n).read_text())
a=read('GODOT_first.json');b=read('GODOT_repeat.json');baseline=read('baseline/GODOT_original.json')
assert a==b and not a['failures'] and a['case_count']==1197
assert a.pop('new_correction_created') is True and baseline.pop('new_correction_created') is False
assert a==baseline
matrix=read('TYPE_MATRIX_1.classified.json');assert matrix==read('TYPE_MATRIX_2.classified.json') and not matrix['failures']
assert len(matrix['results'])==699 and matrix['variant_representatives']==58
rows={r['label']:r for r in matrix['results']};assert len(rows)==699
stats={};equivalent=0;diagnostic_fixed=0
for version in ['candidate','original','historical']:
 subset=[r for r in rows.values() if r['version']==version]
 stats[version]={'calls':len(subset),'diagnostic_calls':sum(bool(r['diagnostics']) for r in subset),'clean_empty_returns':sum(not r['diagnostics'] and r['returned']=='' for r in subset),'clean_rejections':sum(not r['diagnostics'] and r['returned']!='' for r in subset)}
for r in rows.values():
 if r['version']!='original':continue
 c=rows[r['label'].replace('original:','candidate:',1)]
 assert not c['diagnostics']
 if not r['diagnostics']:assert r['returned']==c['returned'];equivalent+=1
 else:
  assert len(r['diagnostics'])==1 and 'Invalid operands' in r['diagnostics'][0] and "operator '=='" in r['diagnostics'][0]
  assert r['returned']=='' and c['returned']=='spellteach_invalid_actual_purchase_binding';diagnostic_fixed+=1
assert equivalent==49 and diagnostic_fixed==184
assert len({r['variant_type'] for r in rows.values() if 'variant_type'in r})==39
caller=read('CALLER_PROBE_1.classified.json');assert caller==read('CALLER_PROBE_2.classified.json') and not caller['failures'] and len(caller['results'])==72
caller_counts=collections.Counter()
for r in caller['results']:
 kind=r['case'];mode=r['mode'];version=r['version'];bad=kind in ['bool','int','array'];canonical=kind=='canonical'
 if mode in ['good_receipt_bad_unit','no_receipt_bad_unit']:
  expected_errors=1 if bad and version=='original' else 0
  expected=('' if mode=='good_receipt_bad_unit' else 'spellteach_unproven_saved_teaching_lineage') if canonical else ('spellteach_unproven_saved_teaching_lineage' if bad and version=='original' else 'spellteach_invalid_actual_purchase_binding')
 elif mode in ['bad_receipt_good_unit','same_bad_both']:
  expected_errors=1 if bad else 0
  expected='' if bad or canonical else 'spellteach_changed_acquisition_binding'
 elif mode=='bad_event_source':expected_errors=0;expected='' if canonical else 'spellteach_invalid_acquisition_receipt'
 else:
  assert mode=='cast_entry_prefix'
  expected_errors=2 if bad and version=='original' else 0
  expected='PROBE_PREFIX_REACHED_END_NOT_ACCEPTANCE' if canonical else ('' if expected_errors else 'spellteach_invalid_actual_purchase_binding')
 assert len(r['diagnostics'])==expected_errors,(r,expected_errors)
 assert r['returned']==expected,(r,expected)
 caller_counts[(version,'calls')]+=1;caller_counts[(version,'diagnostic_calls')]+=bool(r['diagnostics']);caller_counts[(version,'diagnostic_messages')]+=len(r['diagnostics'])
summary={'status':'PASS_BOUNDED_LOCAL_CANDIDATE_EVIDENCE_NOT_INTEGRATION_APPROVAL','matrix':stats,'source_variant_type_categories':39,'source_representative_values':58,'original_defined_results_preserved':equivalent,'original_diagnostic_calls_changed_to_explicit_rejection':diagnostic_fixed,'main_gate_cases':1197,'main_gate_semantically_identical_to_baseline':True,'proof_negative_variants':16,'structure_cases':17,'effects_cases':17,'unit_cases':20,'caller_probe_calls':72,'caller_summary':{v:{k:caller_counts[(v,k)] for k in ['calls','diagnostic_calls','diagnostic_messages']} for v in ['original','candidate']},'remaining_receipt_diagnostic_cases_per_version':6,'new_receipt_fix_attempted':False,'full_load_Game_compiler_Catalog_host_or_old_save_run':False,'candidate_installed':False}
(H/'VERIFICATION.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
