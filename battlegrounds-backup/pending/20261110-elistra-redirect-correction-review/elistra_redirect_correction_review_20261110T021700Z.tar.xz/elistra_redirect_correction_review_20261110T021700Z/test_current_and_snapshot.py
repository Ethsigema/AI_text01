from pathlib import Path
from copy import deepcopy
import ast,hashlib,json,resource,sys,types,collections
resource.setrlimit(resource.RLIMIT_AS,(128*1024**2,128*1024**2));sys.dont_write_bytecode=True
H=Path(__file__).resolve().parent;R=H/'fixture_root';F='research/elistra_redirect_native_recovery/'
p=H/'candidate/tools/elistra_redirect_patterns.py';m=types.ModuleType('candidate_controls');m.__file__=str(p);exec(compile(p.read_text(),str(p),'exec'),m.__dict__)
raw=json.loads((H/'current_data_inputs/CURRENT_RAW_ROWS.json').read_text());compiled=json.loads((H/'current_data_inputs/CURRENT_COMPILED_ROWS.json').read_text());records=[]
for identity in m.SOURCE_IDS:
 result=m.compile_card(raw[identity],raw,root=R);expected={k:v for k,v in compiled[identity].items() if k not in ('id','supported','coverage_text_sha256')};assert result==expected
 records.append({'identity':identity,'current_raw_accepted':True,'result_exact_current_compiled_overlay':True})
code=compile((H/'DRIVER_EXACT_FRAGMENTS.py').read_text(),'exact_historical_elistra_fragments','exec')
ns={'cards':deepcopy(raw),'out':{i:{'stale':True} for i in m.SOURCE_IDS}|{'unrelated':{'keep':True}},'ordered_ids':['unrelated',*reversed(m.SOURCE_IDS)],'ELISTRA_REDIRECT_IDS':m.SOURCE_IDS,'compile_elistra_redirect':m.compile_card,'hashlib':hashlib,'R':R}
exec(code,ns);assert {i:ns['out'][i] for i in m.SOURCE_IDS}==compiled;assert ns['out']['unrelated']=={'keep':True};assert ns['ordered_ids']==['unrelated',*m.SOURCE_IDS]
# Confirm the existing hook removes old target outputs when compile refuses both rows.
bad=deepcopy(raw);bad[m.SOURCE_IDS[0]]['is_golden']=int(bad[m.SOURCE_IDS[0]]['is_golden']);ns2={'cards':bad,'out':{i:{'stale':True} for i in m.SOURCE_IDS}|{'unrelated':{'keep':True}},'ordered_ids':['unrelated',*m.SOURCE_IDS],'ELISTRA_REDIRECT_IDS':m.SOURCE_IDS,'compile_elistra_redirect':m.compile_card,'hashlib':hashlib,'R':R};exec(code,ns2);assert ns2['out']=={'unrelated':{'keep':True}} and ns2['ordered_ids']==['unrelated']
# Controlled post-read file replacement, in our own fixture only, proves parsing uses
# the verified snapshot. It is not a claim of atomic coherence among all proof files.
raw_path=R/F/'raw_rows.json';original_bytes=raw_path.read_bytes();real_read_bytes=Path.read_bytes;read_counts=collections.Counter();replaced=[]
def observed_read(path):
 data=real_read_bytes(path);read_counts[str(path.relative_to(R))]+=1
 if path==raw_path:
  path.write_bytes(b'{"controlled_post_read_replacement":true}\n');replaced.append(True)
 return data
try:
 Path.read_bytes=observed_read
 result=m.compile_card(deepcopy(raw[m.SOURCE_IDS[0]]),deepcopy(raw),root=R)
finally:
 Path.read_bytes=real_read_bytes
 raw_path.write_bytes(original_bytes)
assert replaced==[True] and result is not None
assert dict(read_counts)=={p:1 for p in m.PROOF_SHA256}
assert hashlib.sha256(raw_path.read_bytes()).hexdigest()==m.PROOF_SHA256[F+'raw_rows.json']
# Intentionally invalid JSON-domain card roots/IDs are rejected without file reads.
invalid=[None,[],True,1,'bad',{}, {'id':None},{'id':False},{'id':1},{'id':[]},{'id':{}},{'id':'unknown'}]
invalid_results=[]
for card in invalid:
 value=m.compile_card(card,deepcopy(raw),root=H/'nonexistent_control_root');assert value is None;invalid_results.append({'card_type':type(card).__name__,'id_type':type(card.get('id')).__name__ if isinstance(card,dict) else None,'rejected':True})
report={'current_data_cases':records,'actual_hook_outputs_exact_current_compiled':True,'stale_target_outputs_removed_on_rejection':True,'unrelated_output_preserved':True,'current_hook_order_exact':True,'controlled_snapshot_test':{'all_four_files_read_once':True,'reads':dict(read_counts),'raw_parsed_from_verified_bytes_despite_post_read_path_change':True,'fixture_reset_to_exact_historical_pin':True,'not_a_global_atomic_snapshot':True},'invalid_root_id_cases':invalid_results,'no_game_or_full_driver_run':True,'max_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
(H/'CURRENT_AND_SNAPSHOT_RESULT.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps(report,ensure_ascii=False,indent=2))
