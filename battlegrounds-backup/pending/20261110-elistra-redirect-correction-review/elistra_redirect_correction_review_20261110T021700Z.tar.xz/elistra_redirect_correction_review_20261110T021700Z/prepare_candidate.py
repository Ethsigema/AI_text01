from pathlib import Path
import ast,hashlib,json,difflib,resource
resource.setrlimit(resource.RLIMIT_AS,(128*1024**2,128*1024**2))
H=Path(__file__).resolve().parent;W=H.parent;O=W/'elistra_redirect_readonly_probe_20261110T015700Z';F='research/elistra_redirect_native_recovery/'
pins=json.loads((O/'REPLAY_INPUTS.json').read_text())
for rel,pin in pins.items():
 b=(O/rel).read_bytes();assert len(b)==pin['bytes'] and hashlib.sha256(b).hexdigest()==pin['sha256'];d=H/'prior_snapshot'/rel;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(b)
for rel,pin in pins.items():
 if rel.startswith(('gd_minimal/core/','fixture_root/')) or rel in ['gd_minimal/project.godot','GD_CONSTANTS.json','INPUT_PINS.json']:
  d=H/rel;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes((O/rel).read_bytes())
original=(O/'original_inputs'/F/'candidates/tools/elistra_redirect_patterns.py').read_bytes();assert hashlib.sha256(original).hexdigest()=='94f4398484c99accb054bc125f896317aa2b3e611d702119ca14d3e5a37ecefa'
source=original.decode();lines=source.splitlines(keepends=True)
proof=ast.literal_eval(next(n.value for n in ast.parse(source).body if isinstance(n,ast.Assign) and n.targets[0].id=='PROOF_SHA256'))
proof[F+'raw_rows.json']='e94544aeae79ae363083b3cee4d9cb84ccb89811a56e60edda869d755a0dea5a'
lines[7]='PROOF_SHA256='+repr(proof)+'\n'
helper='''def same(a,b):
    """Match the current GD Exact.same on the JSON-shaped source domain."""
    if type(a) in (int,float) and type(b) in (int,float): return a==b
    if type(a) is not type(b): return False
    if isinstance(a,dict):
        return len(a)==len(b) and all(key in b and same(value,b[key]) for key,value in a.items())
    if isinstance(a,list):
        return len(a)==len(b) and all(same(x,y) for x,y in zip(a,b))
    return a==b

def compile_card(card,cards,root=ROOT):
    if not isinstance(card,dict) or not isinstance(cards,dict) or type(card.get('id')) is not str or card['id'] not in SOURCE_IDS: return None
    try:
        root=Path(root)
        raw_bytes=None
        for path,digest in PROOF_SHA256.items():
            proof=root/path
            if not proof.is_file(): return None
            data=proof.read_bytes()
            if hashlib.sha256(data).hexdigest()!=digest: return None
            if path=='research/elistra_redirect_native_recovery/raw_rows.json': raw_bytes=data
        rows=json.loads(raw_bytes.decode('utf-8'))
    except (OSError,TypeError,ValueError,UnicodeError):
        return None
    if not same(card,rows[card['id']]): return None
    if any(not same(cards.get(identity),rows[identity]) for identity in SOURCE_IDS): return None
    return {k:deepcopy(v) for k,v in EXPECTED[card['id']].items() if k not in ('id','supported','coverage_text_sha256')}
'''
# Preserve the historical docstring/constants and return payload; explicit new provenance lives outside the tool.
candidate=''.join(lines[:8])+helper
D=H/'candidate/tools/elistra_redirect_patterns.py';D.parent.mkdir(parents=True,exist_ok=True);D.write_text(candidate)
patch=''.join(difflib.unified_diff(source.splitlines(keepends=True),candidate.splitlines(keepends=True),fromfile='a/tools/elistra_redirect_patterns.py',tofile='b/tools/elistra_redirect_patterns.py'))
(H/'NEW_CORRECTION.patch').write_text(patch)
manifest={'kind':'NEW_LOCAL_CORRECTION_NOT_HISTORICAL_RESTORATION_OR_LATEST','target':'tools/elistra_redirect_patterns.py','original_sha256':hashlib.sha256(original).hexdigest(),'original_bytes':len(original),'candidate_sha256':hashlib.sha256(candidate.encode()).hexdigest(),'candidate_bytes':len(candidate.encode()),'patch_sha256':hashlib.sha256(patch.encode()).hexdigest(),'raw_rows_historical_pin':proof[F+'raw_rows.json'],'current_gd_sha256':'1ba1f47dcf21e814476fd634bf143a0e36eede3956399fb78ee377e86ca4199d','historical_full_patch_preserved_unfixed':True,'installed':False,'proof_snapshot_note':'The exact raw bytes that pass SHA are decoded; no second read of raw_rows after verification. Not a global atomic filesystem snapshot.'}
(H/'CANDIDATE_MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
# Retain the 262 old case labels in order, then broaden finite JSON-type/source coverage.
cases=json.loads((O/'CASES.json').read_text());gd=json.loads((H/'GD_CONSTANTS.json').read_text());seen={(c['regime'],c['identity'],tuple(c['path']),c['op']) for c in cases}
def walk(v,p=[]):
 yield p,v
 if type(v) is dict:
  for k,x in v.items():yield from walk(x,p+[k])
 elif type(v) is list:
  for k,x in enumerate(v):yield from walk(x,p+[k])
def add(regime,identity,path,op,**kwargs):
 key=(regime,identity,tuple(path),op)
 if key in seen:return
 seen.add(key);cases.append({'label':f'{len(cases):04d}:{regime}:{identity}:{op}:'+'.'.join(map(str,path)),'regime':regime,'identity':identity,'path':path,'op':op,**kwargs})
for identity in gd['IDS']:
 for regime in ['detached','coupled','companion']:
  target=identity if regime!='companion' else next(i for i in gd['IDS'] if i!=identity)
  for path,v in walk(gd['RAW'][target]):
   if type(v) in [int,float]:
    for op in ['numeric_float','number_delta','number_bool']:add(regime,identity,path,op)
   elif v is None:add(regime,identity,path,'null_to_false')
  for path in [['name'],['fields','race'],['source_url'],['images',0,'sha256'],['provenance','library_file_id'],['fields','text']]:add(regime,identity,path,'change_string')
 for op in ['raw_whitespace','raw_json_equivalent','raw_directory']:add('bad_raw_file',identity,[],op)
(H/'CASES.json').write_text(json.dumps(cases,ensure_ascii=False,indent=2)+'\n')
report={'prior_snapshot_files':len(pins),'legacy_cases_retained':262,'expanded_case_count':len(cases),'new_candidate':manifest,'max_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
(H/'PREPARATION.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
