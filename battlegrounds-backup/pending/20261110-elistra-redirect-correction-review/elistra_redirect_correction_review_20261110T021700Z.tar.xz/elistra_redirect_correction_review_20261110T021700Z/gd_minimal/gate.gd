extends SceneTree
const Source=preload("res://core/elistra_redirect_sources.gd")
const Pool=preload("res://core/pool_identity.gd")
class ProbeCatalog extends RefCounted:
	var cards: Dictionary={}
	var source_catalog=null
	func get_card(identity): return cards.get(identity,{})
func _init(): call_deferred("_run")

func _key(container: Variant,key: Variant)->Variant:
	return int(key) if container is Array else key

func _mutate(value: Variant,entry: Dictionary)->Variant:
	var op: String=entry.op
	var path: Array=entry.path
	if op=="canonical": return value
	if op=="swap_rows": return {Source.IDS[0]:value[Source.IDS[1]],Source.IDS[1]:value[Source.IDS[0]]}
	if op=="duplicate_normal": return {Source.IDS[0]:value[Source.IDS[0]],Source.IDS[1]:value[Source.IDS[0]].duplicate(true)}
	if op=="duplicate_golden": return {Source.IDS[0]:value[Source.IDS[1]],Source.IDS[1]:value[Source.IDS[1]].duplicate(true)}
	if op=="invalid_root": return entry.value.duplicate(true) if entry.value is Array or entry.value is Dictionary else entry.value
	if op=="id_only": return {"id":value.id}
	if op=="extra_unrelated":
		value["not-a-source"]={"id":"not-a-source"}
		return value
	if op=="invalid_member":
		value[path[0]]=null
		return value
	var parent: Variant=value
	for at in range(path.size()-1): parent=parent[_key(parent,path[at])]
	var key: Variant=_key(parent,path[-1]) if not path.is_empty() else null
	var prior: Variant=parent[key] if not path.is_empty() else value
	if op=="delete":
		if parent is Array: parent.remove_at(int(key))
		else: parent.erase(key)
		return value
	var changed: Variant=null
	match op:
		"bool_to_int": changed=int(prior)
		"bool_to_float": changed=float(prior)
		"toggle_bool": changed=not prior
		"numeric_float": changed=float(prior)
		"numeric_int": changed=int(prior)
		"number_delta": changed=prior+1
		"number_string": changed=str(prior)
		"number_bool": changed=bool(prior)
		"change_string": changed=prior+"__changed__"
		"null_to_false": changed=false
		"extra_key":
			changed=prior.duplicate(true)
			changed["__extra__"]=true
		"append_item":
			changed=prior.duplicate(true)
			changed.append("__extra__")
		"reverse_list":
			changed=prior.duplicate(true)
			changed.reverse()
		"nan": changed=NAN
		"pos_inf": changed=INF
		"neg_inf": changed=-INF
		_: assert(false,"Unknown mutation: "+op)
	if not path.is_empty(): parent[key]=changed
	else: value=changed
	return value

func _strict_ingress(card: Variant,cards: Variant)->bool:
	# Diagnostic composition: actual GD per-row gate plus Python's expected keyed map contract.
	# This is not a single project entry and is not an invariant enforced by closure_error.
	if not card is Dictionary or not cards is Dictionary: return false
	if not Source.raw_source_error(card).is_empty(): return false
	for identity in Source.IDS:
		var row: Variant=cards.get(identity)
		if not row is Dictionary or row.get("id")!=identity or not Source.raw_source_error(row).is_empty(): return false
	return true
func _compiled(cards: Dictionary,outputs: Dictionary)->ProbeCatalog:
	var c=ProbeCatalog.new()
	c.cards=cards.duplicate(true)
	for identity in outputs:
		if c.cards.get(identity) is Dictionary: c.cards[identity].merge(outputs[identity],true)
	return c
func _unit(identity: String)->Dictionary:
	var row: Dictionary=Source.RAW[identity]
	return {"card_id":identity,"name":row.name,"kind":"minion","tier":row.tier,"attack":row.attack,"health":row.health,"max_health":row.health,"tribes":row.tribes.duplicate(true),"golden":row.is_golden,"keywords":Source.EXPECTED[identity].keywords.duplicate(true),"effects":Source.program_for(identity)}
func _run():
	var folder: String=ProjectSettings.globalize_path("res://").path_join("..").simplify_path()
	var cases: Array=JSON.parse_string(FileAccess.get_file_as_string(folder.path_join("CASES.json")))
	var py: Dictionary=JSON.parse_string(FileAccess.get_file_as_string(folder.path_join("PYTHON_REPORT.json")))
	var outputs: Dictionary=JSON.parse_string(FileAccess.get_file_as_string(folder.path_join("ORIGINAL_OUTPUTS.json")))
	var failures: Array=[]
	var results: Array=[]
	var counts: Dictionary={}
	for identity in Source.IDS:
		if not Source.same(outputs[identity],Source.EXPECTED[identity]): failures.append({"kind":"output_constant_mismatch","identity":identity})
	for index in range(cases.size()):
		var entry: Dictionary=cases[index]
		var identity: String=entry.identity
		var cards: Variant=Source.RAW.duplicate(true)
		var card: Variant=Source.RAW[identity].duplicate(true)
		if entry.regime=="detached": card=_mutate(card,entry)
		elif entry.regime in ["coupled","coherent_raw_file"]:
			cards[identity]=_mutate(cards[identity],entry)
			card=cards[identity]
		elif entry.regime=="companion":
			var target: String=Source.IDS[1] if identity==Source.IDS[0] else Source.IDS[0]
			cards[target]=_mutate(cards[target],entry)
			card=cards[identity]
		elif entry.regime=="mapping_root": cards=_mutate(cards,entry)
		var before: PackedByteArray=var_to_bytes([card,cards])
		var raw_accept: bool=card is Dictionary and Source.raw_source_error(card).is_empty()
		var strict: bool=_strict_ingress(card,cards)
		var prior: Dictionary=py.results[index]
		if prior.label!=entry.label: failures.append({"kind":"case_alignment","label":entry.label})
		var expected_accept: bool=strict and prior.all_four_pins_valid
		var candidate: Dictionary=prior.versions.candidate
		var original: Dictionary=prior.versions.original
		if candidate.accepted!=expected_accept or candidate.error!=null: failures.append({"kind":"candidate_gate_mismatch","label":entry.label,"expected":expected_accept})
		var versions: Dictionary={}
		for version in ["original","candidate"]:
			var result: Dictionary=prior.versions[version]
			var compiled_issue=null
			if cards is Dictionary and result.hook_accepted_ids.size()==Source.IDS.size() and result.hook_error==null:
				compiled_issue=Source.closure_error(_compiled(cards,py.hook_output_pool[int(result.hook_outputs_index)]))
				if version=="candidate" and not compiled_issue.is_empty(): failures.append({"kind":"candidate_hook_output_failed_closure","label":entry.label,"issue":compiled_issue})
			versions[version]={"accepted":result.accepted,"actual_hook_output_closure_error":compiled_issue,"hook_error":result.hook_error}
		if before!=var_to_bytes([card,cards]): failures.append({"kind":"input_mutation","label":entry.label})
		if not counts.has(entry.regime): counts[entry.regime]={"cases":0,"original_accept":0,"candidate_accept":0,"strict_memory_accept":0,"candidate_accept_diagnostic_difference":0,"original_to_candidate_tightened":0,"candidate_hook_closure_checks":0}
		counts[entry.regime].cases+=1
		if original.accepted: counts[entry.regime].original_accept+=1
		if candidate.accepted: counts[entry.regime].candidate_accept+=1
		if strict: counts[entry.regime].strict_memory_accept+=1
		if candidate.accepted!=expected_accept: counts[entry.regime].candidate_accept_diagnostic_difference+=1
		if original.accepted and not candidate.accepted: counts[entry.regime].original_to_candidate_tightened+=1
		if versions.candidate.actual_hook_output_closure_error!=null: counts[entry.regime].candidate_hook_closure_checks+=1
		results.append({"label":entry.label,"regime":entry.regime,"actual_supplied_card_raw_gate_accept":raw_accept,"strict_memory_ingress_accept":strict,"four_pin_condition_from_isolated_python_fixture":prior.all_four_pins_valid,"expected_candidate_accept":expected_accept,"versions":versions})
	var structure: Array=[]
	for op in ["canonical","swap_rows","duplicate_normal","duplicate_golden","missing_normal","missing_golden","both_pool_blockers","invalid_pool_blocker","extra_unrelated","projection_fields","unsupported","extra_field"]:
		var current: ProbeCatalog=_compiled(Source.RAW,outputs)
		if op in ["swap_rows","duplicate_normal","duplicate_golden","extra_unrelated"]: current.cards=_mutate(current.cards,{"op":op,"path":[]})
		elif op=="missing_normal": current.cards.erase(Source.IDS[0])
		elif op=="missing_golden": current.cards.erase(Source.IDS[1])
		elif op=="both_pool_blockers":
			for identity in Source.IDS: current.cards[identity].pool_blocker=Pool.MINION_REASON
		elif op=="invalid_pool_blocker": current.cards[Source.IDS[0]].pool_blocker="wrong"
		elif op=="projection_fields": current.cards[Source.IDS[0]].source_shop_fields={"tier":7,"cost":null,"pool_supported":false}
		elif op=="unsupported": current.cards[Source.IDS[0]].supported=false
		elif op=="extra_field": current.cards[Source.IDS[0]].extra=true
		var issue: String=Source.closure_error(current)
		var accepted: bool=issue.is_empty()
		if accepted!=(op in ["canonical","swap_rows","duplicate_normal","duplicate_golden","both_pool_blockers","extra_unrelated"]): failures.append({"kind":"structural_probe","op":op,"issue":issue})
		structure.append({"case":op,"accepted":accepted,"closure_error":issue})
	var effects: Array=[]
	var units: Array=[]
	for identity in Source.IDS:
		for op in ["canonical","wrong_type","wrong_source","extra_field","missing_source","null"]:
			var effect: Variant=Source.LEAVES[identity].duplicate(true)
			if op=="wrong_type": effect.type="wrong"
			elif op=="wrong_source": effect.source_id="unknown"
			elif op=="extra_field": effect.extra=true
			elif op=="missing_source": effect.erase("source_id")
			elif op=="null": effect=null
			var issue: String=Source.effect_error(effect)
			if issue.is_empty()!=(op=="canonical"): failures.append({"kind":"effect_probe","identity":identity,"op":op})
			effects.append({"identity":identity,"op":op,"accepted":issue.is_empty(),"error":issue})
		for op in ["canonical","float_tier","wrong_tier","wrong_program","extra_effect","buff_no_base","buff_with_clean_base","buff_with_mutated_base","tainted_nested_base","invalid_base_identity"]:
			var unit: Dictionary=_unit(identity)
			if op=="float_tier": unit.tier=float(unit.tier)
			elif op=="wrong_tier": unit.tier=4
			elif op=="wrong_program": unit.effects=[]
			elif op=="extra_effect": unit.effects.append({"type":"extra"})
			elif op.begins_with("buff_"):
				if op!="buff_no_base": unit.base_unit=_unit(identity)
				unit.attack+=3
				if op=="buff_with_mutated_base": unit.base_unit.attack+=3
			elif op=="tainted_nested_base":
				unit.base_unit=_unit(identity)
				unit.base_unit._base={}
			elif op=="invalid_base_identity":
				unit.base_unit=_unit(identity)
				unit.base_unit.card_id="wrong"
			var issue: String=Source.unit_error(unit)
			if issue.is_empty()!=(op in ["canonical","float_tier","buff_with_clean_base"]): failures.append({"kind":"unit_probe","identity":identity,"op":op,"issue":issue})
			units.append({"identity":identity,"op":op,"accepted":issue.is_empty(),"error":issue})
	var report: Dictionary={"case_count":cases.size(),"counts":counts,"results":results,"structural_probes":structure,"effect_probes":effects,"unit_probes":units,"failures":failures,"godot_version":Engine.get_version_info(),"strict_ingress_is_composed_diagnostic_not_single_project_entry":true,"four_proof_hashes_evaluated_in_python_not_in_GD":true,"closure_does_not_enforce_key_equals_inline_id":true,"actual_source_raw_effect_unit_closure_functions_used":true,"catalog_interface_is_minimal_probe_not_full_catalog":true,"game_catalog_host_or_save_run":false,"new_correction_created":true}
	var writer=FileAccess.open(OS.get_cmdline_user_args()[0],FileAccess.WRITE)
	writer.store_string(JSON.stringify(report,"\t")+"\n")
	writer.close()
	print("Cases ",cases.size(),"; failures ",failures.size(),"; differences ",counts)
	quit(0 if failures.is_empty() else 1)
