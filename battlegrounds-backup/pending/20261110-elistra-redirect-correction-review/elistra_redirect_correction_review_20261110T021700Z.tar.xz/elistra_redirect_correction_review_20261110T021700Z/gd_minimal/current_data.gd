extends SceneTree
const Source=preload("res://core/elistra_redirect_sources.gd")
class ProbeCatalog extends RefCounted:
	var cards: Dictionary={}
	func get_card(identity): return cards.get(identity,{})
func _init():
	var folder: String=ProjectSettings.globalize_path("res://").path_join("..").simplify_path()
	var raw: Dictionary=JSON.parse_string(FileAccess.get_file_as_string(folder.path_join("current_data_inputs/CURRENT_RAW_ROWS.json")))
	var outputs: Dictionary=JSON.parse_string(FileAccess.get_file_as_string(folder.path_join("current_data_inputs/CURRENT_COMPILED_ROWS.json")))
	var c=ProbeCatalog.new()
	var rows: Array=[]
	var failures: Array=[]
	for identity in Source.IDS:
		var raw_issue: String=Source.raw_source_error(raw[identity])
		var row: Dictionary=raw[identity].duplicate(true)
		row.merge(outputs[identity],true)
		var compiled_issue: String=Source.source_error(row)
		if not raw_issue.is_empty() or not compiled_issue.is_empty(): failures.append(identity)
		c.cards[identity]=row
		rows.append({"identity":identity,"raw_error":raw_issue,"compiled_error":compiled_issue})
	var issue: String=Source.closure_error(c)
	if not issue.is_empty(): failures.append(issue)
	var report={"rows":rows,"closure_error":issue,"failures":failures,"actual_current_data_only":true,"minimal_get_card_interface_not_production_catalog":true,"game_not_run":true}
	var writer=FileAccess.open(OS.get_cmdline_user_args()[0],FileAccess.WRITE)
	writer.store_string(JSON.stringify(report,"\t")+"\n")
	writer.close()
	print("Current raw rows ",rows.size(),"; failures ",failures.size())
	quit(0 if failures.is_empty() else 1)
