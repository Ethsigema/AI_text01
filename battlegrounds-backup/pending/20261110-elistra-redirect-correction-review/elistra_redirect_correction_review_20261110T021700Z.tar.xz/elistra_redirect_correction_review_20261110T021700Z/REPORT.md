# 艾丽斯特拉独立新修正候选

## 结果与决定

已制作可独立审查的新修正候选，有限测试通过，继续暂缓安装。它不是历史原件、原样恢复、官方最新版或已整合版本。

当前完整编译驱动及其依赖未闭合；真实 Game 可达性、攻击重定向、存档兼容没有验证。没有更改当前原树、历史工具、历史补丁、GD校验或旧备份。

## 明确的前像、候选与来源

- 历史工具5771 bytes，SHA256：94f4398484c99accb054bc125f896317aa2b3e611d702119ca14d3e5a37ecefa。
- 新候选6698 bytes，SHA256：5117ad6bf7e755be6063d3538aa541e6633ca1091e163e247a5427a06c74e2ab。
- NEW_CORRECTION.patch SHA256：215d0ee3f8f839b749a8ec8a1b73e98d553cb497c34f0ad19630d9414004ed28。
- raw_rows历史固定pin：e94544aeae79ae363083b3cee4d9cb84ccb89811a56e60edda869d755a0dea5a。
- 评估对应当前GD：1ba1f47dcf21e814476fd634bf143a0e36eede3956399fb78ee377e86ca4199d。

新补丁描述“保存的历史整本→新候选”，不是当前缺失目标可直接套用的安装补丁。当前 tools/elistra_redirect_patterns.py 仍不存在。未知前像、GD版本变化或proof变化都需要另行审查，不能fuzzy套用、改pin适配或称为最新版。

历史 manifest、工具和原 candidate.patch 全部保留。原整包补丁第605/686行XML尾部与下一文件头粘连的缺陷未修复。历史选定工具/GD/driver片段能精确重建，不代表该整包可直接安装。

## 修正的具体内容

1. 保留原三份proof的哈希，新增已封存raw_rows的固定哈希。四份文件各读取一次，raw_rows由实际通过哈希验证的同一份字节解码，不在验证后另读文件。
2. 增加与当前GD Exact.same对应的JSON来源比较：bool不等于整数/浮点数；int/float可在数值相等时相等；列表和字典递归比较，不能增删字段。
3. 验证传入card的完整本体，以及映射中的两个完整来源行。仅有合法id不再足够。
4. 对测试覆盖的坏根、缺失/错误文件等情形返回None。函数签名、默认ROOT布局、SOURCE_IDS、EXPECTED、deepcopy输出、pool=false和partial状态保留。

范围是当前固定来源及JSON形态输入，不声称任意自定义Python对象都对应GD类型。文件pin是字节精确约束：仅空白或重新序列化的变化也会拒绝，这是来源固定策略，不是说GD内存校验会拒绝语义等值JSON文件。

受控快照测试在独立fixture里，于raw字节读出后立即替换路径内容，候选仍只解析已验证原字节，随后恢复fixture并核对pin。这验证没有第二次raw读取，不代表四个文件或整个文件系统是全局原子快照。

## 886项有限矩阵

保留原262项编号及原工具结果，新增深层数字等值float、数值变化/布尔替换、null变化、若干来源文本及raw文件格式/目录反例。当前GD源文件未改，直接调用实际raw/source/closure/effect/unit函数。

- 原工具直接接受452项、20项抛异常；新候选接受178项、直接调用0异常，收紧274项。
- 候选与“实际GD逐行raw规则＋指定映射key/id条件＋四项文件pin”的有界诊断，886项无差异。此组合不是项目内单一入口；文件pin由Python对独立fixture核验，不能说GD读取了这些proof。
- detached组收紧204项，但真实hook从cards.get(identity)取同一行。不能把这些手工detached差异称为真实hook缺陷可达。
- coupled/companion各24个bool/数值差异case均被候选拒绝，共48case对应24个唯一坏映射。每case真实hook调用两个来源，不能把case数和hook调用数混用。
- 同步修改raw_rows与cards的14项全部拒绝；仅修改raw文件的原先4项数值别名接受也被拒绝；raw空白/等值序列化不再绕过来源pin。
- 候选实际hook产生完整双行输出的392次评估，合并后全部通过未修改的GD来源闭包。
- 仍有8项非法cards根在历史hook自己的 cards.get、调用候选之前抛AttributeError。新候选直接调用已拒绝，但没有改驱动，不宣称这些hook异常已解决。

执行的驱动片段只有历史emit、Elistra循环及两步ordered_ids，共四个精确AST节点；没有执行完整驱动。输出池只是报告去重，不替代实际函数或emit。原262项原工具接受/异常/完整hook输出逐项与旧封存结果相同。886是唯一编号的样例数，包含等值float正例，不等于886个互异运行状态，更不是穷尽输入空间。

另保留12项结构、12项effect、20项unit回归。闭包按行内id校验而未绑定查询key的交换/重复行现象原样保留；没有通过放宽或修改GD掩盖差异。这里未证明真实Catalog能够构建这些手造映射。

## 当前合法数据验证

独立只读审查流式读取当前11份历史驱动输入，仅catalog_raw含这两个来源，各出现一次；精确索引、行号、字节段及完整文件hash保存在static_current_inputs。当前raw双行与历史raw_rows、GD RAW一致，当前catalog双overlay与历史/GD/Python EXPECTED一致。

新候选对实际摘取的两条当前raw均接受，真实emit/hook输出逐字段等于当前compiled双行。原始ROOT路径布局的独立测试副本也通过；Path和字符串root结果一致，嵌套输出deepcopy互不影响，partial/pool标记未变。

另以实际当前数据执行最小GD正例，两条raw/source检查及双来源closure均通过，重复一致。没有用全Catalog加载来冒充两条正例，也没有执行工厂、真实战斗或存档。

验证了拒绝时原hook删掉两个旧target out，保留无关输出并更新顺序。没有修改这些驱动副作用。

## 依赖和版本边界

新候选不增加第三方依赖：标准库pathlib/copy/hashlib/json，加显式root、四份固定文件、所选card与双行mapping。相比历史工具，raw_rows从“必读但不固定”变为“必读且固定”。static_current_inputs的依赖图描述历史工具的三pin状态，新候选的四pin以CANDIDATE_MANIFEST和代码为准。

最小GD依赖为ElistraSources、phase_undead_army_sources、pool_identity三个原始项目文件，另有自写测试harness。当前正式driver缺失；历史driver直接本地模块检查789项缺失，包括前置QuestIdentity/HeroValues。789的历史驱动检查口径不同于当前345项恢复范围，不是新增任务清单。完整前处理/后处理与执行可达性仍不明。

Catalog把该工具及关联文件字节纳入execution_fingerprint，Game/有效房间Catalog也存在存档身份比较。因此不能保证新增工具后旧存档兼容；没有读取存档、计算缺依赖下的完整fingerprint或绕过检查。四份全局原核验证据、两份全局合同和未安装XML候选的边界不变。

## 重放、资源与封存

主测试两轮矩阵及两轮当前数据GD均成功、无脚本诊断、对应结果逐字相同。另用56个显式白名单输入建立新的便携目录，重新运行Python测试、当前数据/快照测试、四次受限GD和验证脚本：14个输出逐字相同，3份报告仅排除实测RSS峰值后相同。

全部测试串行。Python测试/核验限制128MiB；GD限制2GiB地址空间，RSS超过192MiB或45秒停止，启动MemAvailable至少1GiB、运行时低于640MiB停止。矩阵GD约79–80MiB、约1.1–1.5秒；当前数据GD约61–62MiB、约0.3秒。隔离HOME/XDG，不运行原项目。

白名单只含候选、原件/旧缺陷快照、精确diff、报告、定向测试、合法双行小摘取和哈希证据；不包含缓存、凭据、私聊、旧存档或完整原始大catalog。没有网络操作或重试此前取消的下载。

独立评审逐项核对886矩阵、原patch→历史原件→新patch→候选、当前数据/快照及便携重放，未发现新的阻断缺陷；它只运行自身静态/数据断言，没有再次执行目标或Godot。168个独立审查输入已固定并复核。

末尾检查选定原件、33项来源记录、168项独立审查输入、56重放输入和13份旧归档保持原值，当前345项缺口仍缺失。不是完整源码树重新验收。

## 交付与后续

- candidate/tools/elistra_redirect_patterns.py：新修正候选，未安装。
- NEW_CORRECTION.patch、CANDIDATE_MANIFEST.json：精确前后hash与来源限制。
- VERIFIED_RESULTS.json、PYTHON_REPORT.json、GODOT_first.json：有界矩阵结果。
- CURRENT_AND_SNAPSHOT_RESULT.json、CURRENT_GODOT_first.json：当前合法输入及快照检查。
- static_current_inputs/：来源摘取、版本/依赖与fingerprint静态证据。
- review_independent/：独立复核，非新增Godot执行。
- replay_to_new.py、REPLAY_INPUTS.json：只向新目录重放，勿在已封存目录直接运行会覆盖结果的脚本。

本轮可封存为待审候选。后续需要与当前core/data同一可信版本的完整driver及关键前处理依赖，才能继续整合评估；在此之前保持暂缓安装，不将有限通过扩大成完整游戏或旧档通过。
