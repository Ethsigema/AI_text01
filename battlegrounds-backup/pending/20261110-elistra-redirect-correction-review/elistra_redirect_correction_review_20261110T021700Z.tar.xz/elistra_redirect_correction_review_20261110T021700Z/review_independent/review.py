"""Independent static/data review. Never imports, compiles or executes target code.

Read access is restricted to the explicit allowlist below. Writes only this folder.
AST is parsed as data, constants use literal_eval, and the oracle is independent.
"""
from pathlib import Path
from copy import deepcopy
import ast, collections, hashlib, json, math, re, resource, xml.etree.ElementTree as ET

resource.setrlimit(resource.RLIMIT_AS, (128*1024**2, 128*1024**2))
HERE = Path(__file__).resolve().parent
SOURCE = HERE.parent / 'elistra_redirect_correction_review_20261110T021700Z'
F = 'research/elistra_redirect_native_recovery/'
ORIG = 'prior_snapshot/original_inputs/'
FIXED = [
 'CANDIDATE_MANIFEST.json','INPUT_PINS.json','LEGACY_BASELINE_PIN.json','PREPARATION.json',
 'NEW_CORRECTION.patch','candidate/tools/elistra_redirect_patterns.py','CASES.json',
 'GD_CONSTANTS.json','PYTHON_REPORT.json','ORIGINAL_OUTPUTS.json','GODOT_first.json',
 'GODOT_repeat.json','GODOT_RUNS.json','GODOT_first.stderr.log','GODOT_repeat.stderr.log',
 'GODOT_first.stdout.log','GODOT_repeat.stdout.log','test_candidate.py','mutations.py',
 'prepare_candidate.py','DRIVER_EXACT_FRAGMENTS.py','gd_minimal/gate.gd',
 'gd_minimal/core/elistra_redirect_sources.gd','gd_minimal/core/phase_undead_army_sources.gd',
 'gd_minimal/core/pool_identity.gd','run_godot.py','prior_snapshot/CASES.json',
 'prior_snapshot/LEGACY_PYTHON_REPORT.json','prior_snapshot/test_original.py',
 'prior_snapshot/verify_results.py',
]
INPUT_PATHS = [F+'manifest.json',F+'candidate.patch',F+'native_source_manifest.json',
 F+'native/BGS_205.xml',F+'native/TB_BaconUps_306.xml',F+'raw_rows.json',F+'programs.json',
 F+'expected_compiled.json',F+'candidates/tools/elistra_redirect_patterns.py',
 F+'candidates/tools/build_effect_catalog.py',F+'candidates/core/elistra_redirect_sources.gd',
 'core/elistra_redirect_sources.gd','core/phase_undead_army_sources.gd','core/pool_identity.gd']
PROOF_PATHS = [F+'native_source_manifest.json',F+'native/BGS_205.xml',F+'native/TB_BaconUps_306.xml',F+'raw_rows.json']
ALLOW = FIXED + [ORIG+p for p in INPUT_PATHS] + ['fixture_root/'+p for p in PROOF_PATHS]
assert len(ALLOW)==len(set(ALLOW))
data = {p:(SOURCE/p).read_bytes() for p in ALLOW}
sha = lambda b: hashlib.sha256(b).hexdigest()
pins = {p:{'bytes':len(b),'sha256':sha(b)} for p,b in data.items()}
readjson = lambda p: json.loads(data[p])
assert len(data['GODOT_first.stderr.log'])==len(data['GODOT_repeat.stderr.log'])==0
manifest = readjson('CANDIDATE_MANIFEST.json')
original = data[ORIG+F+'candidates/tools/elistra_redirect_patterns.py']
candidate = data['candidate/tools/elistra_redirect_patterns.py']
patch = data['NEW_CORRECTION.patch']
assert len(original)==5771 and sha(original)==manifest['original_sha256']=='94f4398484c99accb054bc125f896317aa2b3e611d702119ca14d3e5a37ecefa'
assert len(candidate)==6698 and sha(candidate)==manifest['candidate_sha256']=='5117ad6bf7e755be6063d3538aa541e6633ca1091e163e247a5427a06c74e2ab'
assert sha(patch)==manifest['patch_sha256']=='215d0ee3f8f839b749a8ec8a1b73e98d553cb497c34f0ad19630d9414004ed28'
assert manifest['installed'] is False
for p,pin in readjson('INPUT_PINS.json').items():
 assert p in INPUT_PATHS and pins[ORIG+p]==pin

# Strict unified-diff application in memory. No filesystem patch/install operation.
def apply_diff(before, unified):
 old=before.decode().splitlines(keepends=True); lines=unified.decode().splitlines(keepends=True)
 assert lines[0].startswith('--- ') and lines[1].startswith('+++ ')
 out=[]; cursor=0; i=2
 while i<len(lines):
  match=re.fullmatch(r'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@.*\n',lines[i]); assert match,lines[i]
  first,nold,nfirst,nnew=match.groups(); start=int(first)-1 if int(first) else 0
  old_count=int(nold) if nold is not None else 1; new_count=int(nnew) if nnew is not None else 1
  assert start>=cursor; out.extend(old[cursor:start]); cursor=start; i+=1; oc=nc=0
  while i<len(lines) and not lines[i].startswith('@@ '):
   line=lines[i]; assert line[0] in ' +-'
   if line[0] in ' -': assert cursor<len(old) and old[cursor]==line[1:]; cursor+=1; oc+=1
   if line[0] in ' +': out.append(line[1:]); nc+=1
   i+=1
  assert (oc,nc)==(old_count,new_count)
 out.extend(old[cursor:]); return ''.join(out).encode()
assert apply_diff(original,patch)==candidate
historical=data[ORIG+F+'candidate.patch']
start=historical.index(b'--- /dev/null\n+++ b/tools/elistra_redirect_patterns.py\n')
end=historical.index(b'--- a/ui/combat_replay.gd\n',start)
assert apply_diff(b'',historical[start:end])==original
sealed=readjson(ORIG+F+'manifest.json')
sealed_entry=next(x for x in sealed['files'] if x['path']=='tools/elistra_redirect_patterns.py')
assert sealed_entry['after_sha256']==sha(original) and sealed['patch_sha256']==sha(historical)

def literals(blob):
 tree=ast.parse(blob)
 result={}
 for n in tree.body:
  if isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Name) and n.targets[0].id in ('SOURCE_IDS','EXPECTED','PROOF_SHA256'):
   result[n.targets[0].id]=ast.literal_eval(n.value)
 return tree,result
ot,oc=literals(original); ct,cc=literals(candidate)
assert cc['SOURCE_IDS']==oc['SOURCE_IDS']; IDS=list(cc['SOURCE_IDS'])
assert cc['EXPECTED']==oc['EXPECTED']
assert len(oc['PROOF_SHA256'])==3 and len(cc['PROOF_SHA256'])==4
assert {p:h for p,h in cc['PROOF_SHA256'].items() if p!=F+'raw_rows.json'}==oc['PROOF_SHA256']
assert cc['PROOF_SHA256'][F+'raw_rows.json']==sha(data[ORIG+F+'raw_rows.json'])==manifest['raw_rows_historical_pin']
for p,h in cc['PROOF_SHA256'].items():
 assert sha(data[ORIG+p])==h and data['fixture_root/'+p]==data[ORIG+p]
assert [n.name for n in ct.body if isinstance(n,ast.FunctionDef)]==['same','compile_card']
func=next(n for n in ct.body if isinstance(n,ast.FunctionDef) and n.name=='compile_card')
calls=[n for n in ast.walk(func) if isinstance(n,ast.Call)]
reads=[n for n in calls if isinstance(n.func,ast.Attribute) and n.func.attr in ('read_bytes','read_text')]
assert len(reads)==1 and ast.unparse(reads[0])=='proof.read_bytes()'
assert any(ast.unparse(n)=="json.loads(raw_bytes.decode('utf-8'))" for n in calls)
try_node=next(n for n in func.body if isinstance(n,ast.Try))
assert ast.unparse(try_node.handlers[0].type)=='(OSError, TypeError, ValueError, UnicodeError)'
assert ast.dump(func.body[-1],include_attributes=False)==ast.dump(next(n for n in ot.body if isinstance(n,ast.FunctionDef)).body[-1],include_attributes=False)

gd=readjson('GD_CONSTANTS.json'); raw=readjson(ORIG+F+'raw_rows.json')
assert gd['RAW']==raw and gd['EXPECTED']==cc['EXPECTED']==readjson('ORIGINAL_OUTPUTS.json')==readjson(ORIG+F+'expected_compiled.json')
source_gd=data['gd_minimal/core/elistra_redirect_sources.gd'].decode()
for name in ('RAW','EXPECTED','PROGRAMS','IDS','RUNTIME_PATHS'):
 line=next(x for x in source_gd.splitlines() if x.startswith('const '+name+':'))
 assert json.loads(line.split('=',1)[1])==gd[name]
assert gd['PROGRAMS']==readjson(ORIG+F+'programs.json')
assert data['gd_minimal/core/elistra_redirect_sources.gd']==data[ORIG+'core/elistra_redirect_sources.gd']==data[ORIG+F+'candidates/core/elistra_redirect_sources.gd']
assert sha(data['gd_minimal/core/elistra_redirect_sources.gd'])==manifest['current_gd_sha256']
for dep in ('phase_undead_army_sources.gd','pool_identity.gd'):
 assert data['gd_minimal/core/'+dep]==data[ORIG+'core/'+dep]
assert set(gd['RUNTIME_PATHS']) >= {'tools/elistra_redirect_patterns.py',*PROOF_PATHS}

# Independent comparator: canonical typed trees, numeric exact rational forms.
# This is not copied/executed target code and only models the pinned JSON source rows.
def typed(v):
 t=type(v)
 if t is dict: return ('object',tuple(sorted((k,typed(x)) for k,x in v.items())))
 if t is list: return ('array',tuple(map(typed,v)))
 if t is bool: return ('boolean',v)
 if t is int: return ('number',v,1)
 if t is float:
  if not math.isfinite(v): return ('nonfinite',repr(v))
  n,d=v.as_integer_ratio(); return ('number',n,d)
 if v is None:return ('null',)
 if t is str:return ('string',v)
 raise AssertionError(t)
def eq(a,b):return typed(a)==typed(b)
def raw_ok(card):
 return type(card) is dict and type(card.get('id')) is str and card['id'] in IDS and eq(card,raw[card['id']])
def strict(card,cards):
 return raw_ok(card) and type(cards) is dict and all(eq(cards.get(k),raw[k]) for k in IDS)
def edit(value,case):
 v=deepcopy(value); op=case['op']; path=case['path']
 if op=='canonical':return v
 if op=='invalid_root':return deepcopy(case['value'])
 if op=='id_only':return {'id':v['id']}
 if op=='extra_unrelated':v['not-a-source']={'id':'not-a-source'};return v
 if op=='swap_rows':return dict(zip(IDS,[v[IDS[1]],v[IDS[0]]]))
 if op in ('duplicate_normal','duplicate_golden'):
  row=v[IDS[op=='duplicate_golden']];return {k:deepcopy(row) for k in IDS}
 if op=='invalid_member':v[path[0]]=None;return v
 p=v
 for key in path[:-1]:p=p[key]
 if op=='delete':del p[path[-1]];return v
 old=p[path[-1]] if path else v
 if op in ('bool_to_int','numeric_int'):new=int(old)
 elif op in ('bool_to_float','numeric_float'):new=float(old)
 elif op in ('number_bool','toggle_bool'):new=bool(old) if op=='number_bool' else not old
 elif op=='number_delta':new=old+1
 elif op=='number_string':new=str(old)
 elif op=='change_string':new=old+'__changed__'
 elif op=='null_to_false':new=False
 elif op=='extra_key':new={**old,'__extra__':True}
 elif op=='append_item':new=old+['__extra__']
 elif op=='reverse_list':new=old[::-1]
 elif op in ('nan','pos_inf','neg_inf'):new=float({'nan':'nan','pos_inf':'inf','neg_inf':'-inf'}[op])
 else:raise AssertionError(op)
 if path:p[path[-1]]=new
 else:v=new
 return v

cases=readjson('CASES.json'); py=readjson('PYTHON_REPORT.json'); g=readjson('GODOT_first.json'); g2=readjson('GODOT_repeat.json')
assert len(cases)==py['case_count']==g['case_count']==886
assert data['GODOT_first.json']==data['GODOT_repeat.json'] and g==g2 and not g['failures']
assert cases[:262]==readjson('prior_snapshot/CASES.json')
legacy=readjson('prior_snapshot/LEGACY_PYTHON_REPORT.json')
assert pins['prior_snapshot/LEGACY_PYTHON_REPORT.json']=={k:v for k,v in readjson('LEGACY_BASELINE_PIN.json').items() if k!='path'}
assert len(py['hook_output_pool'])==py['outputs_interned_count']==4
assert len({json.dumps(x,sort_keys=True) for x in py['hook_output_pool']})==4
counts=collections.defaultdict(collections.Counter); labels=collections.Counter(); hook_errors=[]
for index,(c,r,gr) in enumerate(zip(cases,py['results'],g['results'],strict=True)):
 labels[c['label']]+=1
 assert c['label']==r['label']==gr['label']
 identity=c['identity']; regime=c['regime']; card=deepcopy(raw[identity]); cards=deepcopy(raw)
 if regime=='detached':card=edit(card,c)
 elif regime in ('coupled','coherent_raw_file'):cards[identity]=edit(cards[identity],c);card=cards[identity]
 elif regime=='companion':other=next(k for k in IDS if k!=identity);cards[other]=edit(cards[other],c)
 elif regime=='mapping_root':cards=edit(cards,c)
 elif regime not in ('raw_file_only','bad_raw_file','bad_proof'):raise AssertionError(regime)
 four=regime not in ('coherent_raw_file','raw_file_only','bad_raw_file','bad_proof')
 # All four regimes rewrite/delete a pinned byte stream; GD has no filesystem proof gate.
 assert r['all_four_pins_valid']==four==gr['four_pin_condition_from_isolated_python_fixture']
 s=strict(card,cards); expect=s and four
 assert gr['actual_supplied_card_raw_gate_accept']==raw_ok(card)
 assert gr['strict_memory_ingress_accept']==s
 assert gr['expected_candidate_accept']==expect
 cr=r['versions']['candidate']; orig=r['versions']['original']
 assert cr['accepted']==expect and cr['error'] is None
 pred_hook_error='AttributeError' if type(cards) is not dict else None
 expected_hook=[] if pred_hook_error else [k for k in IDS if strict(cards.get(k),cards) and four]
 assert cr['hook_error']==pred_hook_error and cr['hook_accepted_ids']==sorted(expected_hook)
 actual=py['hook_output_pool'][cr['hook_outputs_index']]
 assert eq(actual,{k:cc['EXPECTED'][k] for k in expected_hook})
 if pred_hook_error:
  assert not cr['hook_calls'];hook_errors.append(c['label'])
 else:
  assert len(cr['hook_calls'])==2 and all(x['same_mapping_value'] for x in cr['hook_calls'])
 for v in ('original','candidate'):
  vr=r['versions'][v]
  assert all(x['same_mapping_value'] for x in vr['hook_calls'])
  assert gr['versions'][v]['accepted']==vr['accepted'] and gr['versions'][v]['hook_error']==vr['hook_error']
  if v=='candidate' and expected_hook:assert gr['versions'][v]['actual_hook_output_closure_error']==''
 if index<262:
  old=legacy['results'][index]
  assert old['label']==c['label']
  assert (orig['accepted'],orig['error'],orig['hook_error'],orig['hook_accepted_ids'])==(old['original_accept'],old['original_error'],old['exact_hook_error'],old['exact_hook_accepted_ids'])
  assert eq(py['hook_output_pool'][orig['hook_outputs_index']],old['exact_hook_outputs'])
 count=counts[regime];count['cases']+=1;count['candidate_accept']+=expect;count['strict_memory_accept']+=s
 count['original_accept']+=orig['accepted'];count['original_exception']+=orig['error'] is not None
 count['candidate_hook_exception']+=pred_hook_error is not None;count['candidate_hook_closure_checks']+=bool(expected_hook)
 count['tightened']+=orig['accepted'] and not expect
for regime,count in counts.items():
 assert all(g['counts'][regime][k]==count[k] for k in ('cases','candidate_accept','strict_memory_accept','original_accept','candidate_hook_closure_checks'))
 assert g['counts'][regime]['original_to_candidate_tightened']==count['tightened']
 assert py['by_regime'][regime]['candidate']=={'accepts':count['candidate_accept'],'exceptions':0,'hook_exceptions':count['candidate_hook_exception']}
 assert py['by_regime'][regime]['original']['exceptions']==count['original_exception']
assert len(hook_errors)==8
assert len(g['effect_probes'])==12 and sum(x['accepted'] for x in g['effect_probes'])==2
assert len(g['unit_probes'])==20 and sum(x['accepted'] for x in g['unit_probes'])==6
assert {x['case'] for x in g['structural_probes'] if x['accepted']}=={'canonical','swap_rows','duplicate_normal','duplicate_golden','both_pool_blockers','extra_unrelated'}
assert g['four_proof_hashes_evaluated_in_python_not_in_GD'] and g['strict_ingress_is_composed_diagnostic_not_single_project_entry']
assert g['closure_does_not_enforce_key_equals_inline_id'] and g['game_catalog_host_or_save_run'] is False

# Exact four AST nodes are parsed/compared, never compiled or executed here.
driver=data[ORIG+F+'candidates/tools/build_effect_catalog.py'].decode(); tree=ast.parse(driver)
emit=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='emit')
hook=next(n for n in tree.body if isinstance(n,ast.For) and ast.unparse(n.iter)=='ELISTRA_REDIRECT_IDS')
ix=tree.body.index(hook); nodes=[emit,hook,*tree.body[ix+1:ix+3]]
assert '\n\n'.join(ast.get_source_segment(driver,n) for n in nodes)+'\n'==data['DRIVER_EXACT_FRAGMENTS.py'].decode()
node_list=[{'kind':type(n).__name__,'first':n.lineno,'last':n.end_lineno} for n in nodes]
assert node_list==py['executed_driver_nodes']
assert [x['kind'] for x in node_list]==['FunctionDef','For','Assign','Expr']
assert 'c=cards.get(identity)' in ast.get_source_segment(driver,hook)
assert 'compile_elistra_redirect(c,cards,root=R)' in ast.get_source_segment(driver,hook)
runner_ast=ast.parse(data['test_candidate.py']); execute_calls=[n for n in ast.walk(runner_ast) if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=='exec']
assert len(execute_calls)==3
assert sorted(ast.unparse(n.args[0]) for n in execute_calls)==sorted(['code',"compile(tree, str(path), 'exec')", "compile((D / 'tools/elistra_redirect_patterns.py').read_text(), m.__file__, 'exec')"])
assert all(x['exit_code']==0 and x['stopped'] is None for x in readjson('GODOT_RUNS.json'))

# Validate pinned native evidence and all finite numeric/bool source boundaries.
native=readjson(ORIG+F+'native_source_manifest.json'); native_summary=[]
for identity in IDS:
 entity=native['entities'][identity]; xml=ET.fromstring(data[ORIG+F+'native/'+identity+'.xml'])
 tags={x.get('name'):x for x in xml.findall('Tag')}
 assert xml.get('CardID')==identity and xml.get('ID')==entity['dbf_id']
 assert sha(data[ORIG+F+'native/'+identity+'.xml'])==entity['native_sha256']
 for key,value in {**entity['native_tags'],**entity['pair_tag']}.items():assert (tags[key].get('value') if key in tags else None)==value
 assert all(key not in tags for key in ('COST','CARDRACE','TAUNT'))
 assert any(x.get('name')=='TAUNT' for x in xml.findall('ReferencedTag'))
 for lang in ('enUS','zhCN'):assert tags['CARDTEXT'].find(lang).text==entity[lang]
 native_summary.append({'id':identity,'dbf_id':entity['dbf_id'],'native_tags_text_pair_verified':True})
def walk(v):
 yield v
 if type(v) is dict:
  for x in v.values():yield from walk(x)
 elif type(v) is list:
  for x in v:yield from walk(x)
numbers=[v for v in walk(raw) if type(v) in (int,float)]
assert all(math.isfinite(v) and abs(v)<2**53 for v in numbers)
assert eq(7,7.0) and not eq(True,1) and not eq(False,0.0) and not eq(None,False)
assert not eq({'x':False},{'x':0}) and not eq([False],[0.0])
assert not eq([1,2],[2,1]) and not eq({}, {'extra':None})

result={
 'status':'BOUNDED_CANDIDATE_REVIEW_NO_NEW_BLOCKING_DEFECT_FOUND',
 'candidate_sha256':sha(candidate),'original_sha256':sha(original),'patch_sha256':sha(patch),
 'historical_patch_to_original_exact':True,'new_patch_to_candidate_exact':True,
 'static_candidate_only':True,'target_code_executed_by_reviewer':False,'godot_executed_by_reviewer':False,
 'observed_reports_not_independent_runtime_rerun':True,'all_four_pins_validated':True,
 'same_hashed_raw_bytes_parsed_without_second_read':True,
 'case_entries':len(cases),'unique_case_labels':len(labels),'case_labels_unique_and_index_alignment_verified':len(labels)==len(cases),
 'candidate_direct_accepts':sum(x['candidate_accept'] for x in counts.values()),
 'candidate_direct_errors_in_recorded_matrix':0,'candidate_hook_errors_in_recorded_matrix':len(hook_errors),
 'candidate_hook_error_cause':'Historical cards.get executes before the candidate function for non-dict mappings.',
 'candidate_hook_full_output_closure_checks':sum(x['candidate_hook_closure_checks'] for x in counts.values()),
 'original_direct_accepts':sum(x['original_accept'] for x in counts.values()),
 'original_direct_exceptions':sum(x['original_exception'] for x in counts.values()),
 'proof_not_gd_memory_gate':True,'gd_reports_byte_equal':True,'gd_recorded_failures':len(g['failures']),
 'legacy_262_original_results_exact':True,'hook_pool_is_recording_only_deduplication':True,
 'executed_driver_nodes_in_supplied_test':node_list,'by_regime':dict(counts),
 'source_numeric_values_count':len(numbers),'source_numeric_abs_max':max(map(abs,numbers)),
 'native_input_checks':native_summary,
 'limits':['Only pinned JSON-source comparison domain; no custom Python subclasses, adversarial objects, arbitrary numeric equivalence, or global atomic filesystem snapshot claim.',
  'No complete compiler driver, current Game/catalog/host/save integration, reachability proof, runtime install, download, or network operation.',
  'GD closure accepts swapped/duplicated lookup values; composed keyed-map diagnostic is stricter and is not one existing GD entry.',
  'The 886 entries have unique indexed labels but include type-equivalent float controls; this is not 886 distinct runtime states or exhaustive input coverage.',
  'Existing test report records ordinary root failures as None; reviewer does not independently execute the target.'],
 'max_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
}
for p,b in data.items():assert (SOURCE/p).read_bytes()==b, 'Input changed during review: '+p
(HERE/'INPUT_PINS.json').write_text(json.dumps(pins,indent=2)+'\n')
(HERE/'RESULT.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
artifacts=['review.py','INPUT_PINS.json','RESULT.json']
out={p:{'bytes':len((HERE/p).read_bytes()),'sha256':sha((HERE/p).read_bytes())} for p in artifacts}
(HERE/'WHITELIST_MANIFEST.json').write_text(json.dumps({'read_only_source':str(SOURCE),'input_allowlist':ALLOW,'output_allowlist':artifacts+['WHITELIST_MANIFEST.json','REVIEW.md'],'artifacts':out,'target_execution':False,'network':False,'installation':False},indent=2)+'\n')
print(json.dumps(result,ensure_ascii=False,indent=2))
