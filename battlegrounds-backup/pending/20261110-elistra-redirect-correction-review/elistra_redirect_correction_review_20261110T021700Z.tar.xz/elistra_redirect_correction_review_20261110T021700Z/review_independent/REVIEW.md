# Elistra 新候选独立审查

结论：在本次明确限定的历史来源、JSON 行结构、函数级及四节点 hook 探针范围内，未发现新的阻断缺陷。可保留为新的独立修正候选；不能安装、不能宣称完整 driver 或真实 Game 可达性已闭合。

## 证据链与改动

- 原历史完整 patch 中的新增工具段可在内存中精确重建 5771 字节原件，SHA256 `94f4398484c99accb054bc125f896317aa2b3e611d702119ca14d3e5a37ecefa`。
- `NEW_CORRECTION.patch` 可从该原件精确生成 6698 字节候选，SHA256 `5117ad6bf7e755be6063d3538aa541e6633ca1091e163e247a5427a06c74e2ab`；patch SHA256 为 `215d0ee3f8f839b749a8ec8a1b73e98d553cb497c34f0ad19630d9414004ed28`。
- 三个旧 proof 未变，新增 raw_rows 历史 pin `e94544aeae79ae363083b3cee4d9cb84ccb89811a56e60edda869d755a0dea5a`。候选在同一次 `read_bytes` 得到的字节上验 hash 并解析，不再次读取 raw 路径；不等于四文件全局原子快照。
- EXPECTED 常量、返回字段过滤、逐值 deepcopy、partial 状态、default_pool/pool_supported=false 均保留。没有改动历史完整 patch；其中原先的 XML 接头粘连问题仍属历史材料，不能称整份 patch 已修好。

## 类型与错误边界

候选的递归比较与当前 `elistra_redirect_sources.gd` 委托的 `phase_undead_army_sources.gd::same` 在固定来源行域一致：同值 int/float 可互通，bool 不等于 0/1，null 不等于 false，字典要求键集合一致，数组要求长度及顺序一致。来源的 56 个数字值最大绝对值为 7500，均位于精确整数表示范围内。本结论不推广到任意大整数比较、任意 Python 子类、自定义对象或所有可能输入。

`compile_card` 同时检查传入 card 本体及 cards 中两个固定键的完整行，因此 detached 参数篡改、布尔数字混淆及两行交换/复制不再借由 Python 普通相等获准。新增四 pin 是 Python 文件来源条件，不是 GD 内存 gate。GD `closure_error` 本身仍能接受交换/重复的 lookup 行；组合诊断中的固定键契约不是某个原有 GD 单入口。

文件内容或空白改变也使新增 raw pin 拒绝。普通坏 root、缺失/目录/坏编码/坏 JSON 等输入的记录结果为 None；parse 之前有精确原始字节 pin，所以固定 pin 下解析后缺键/非字典的路径不可由这些坏文件触发。没有声称吞掉任意异常。

## 886 条矩阵与真实 hook

独立审查脚本只执行自身静态/数据断言，以类型标记树实现独立语义 oracle。没有 import、compile 或 exec 目标工具、目标测试、driver、GD、Game；未新运行 Godot，未联网。

- 886 个编号唯一的条目逐项与 Python/GD 报告对齐；原件直接接受 452 次、异常 20 次，新候选接受 178 次、直接异常 0 次，收紧 274 次。
- 候选报告中的完整 hook 输出有 392 次 closure 检查且全通过。两轮矩阵 GD 输出逐字一致，记录失败 0。
- 仍有 8 次非字典 mapping 的 `cards.get` 前置 AttributeError，发生在进入候选函数之前。不能宣称所有 hook 异常已修复。
- 输出池为四种记录的去重。实际测试仍逐例执行历史 driver 的恰好四个 AST 节点：emit 函数 559 行、Elistra For 3275–3281 行、Assign 3282 行、Expr 3283 行。不是完整 driver，去重没有代替真实 hook 调用。
- 最初 262 条原件结果及完整输出逐条保留。矩阵包含同值 float 控制，886 不表示 886 个不同运行状态或穷尽输入覆盖。

## 当前合法输入与快照控制

提供的当前 raw 双行序列化字节等于历史 raw pin，当前 compiled 双行字节等于 EXPECTED。四份精确片段的 bytes/hash/JSON 与位置记录对得上；本审查没有重新扫描完整当前 catalog，原源文件扫描归属另一只读当前输入审查。

已核对新增脚本及记录：候选与原 hook 输出等于当前 compiled，拒绝时清除陈旧目标 out、保留无关项；受控读后替换测试确实先保存原字节、再替换副本路径、返回原字节，并用 finally 还原读函数和 fixture。四 proof 各读一次。12 个非法 card 根/id 控制拒绝。当前双行的两轮实际 GD 记录逐字一致，raw/source/closure 均通过；接口仍是最小 get_card 探针，不是生产 Catalog。

## 便携重放与交付

独立只读对账实际新重放目录：56 个输入在源/重放两边都符合 pin，14 个输出逐字一致，3 份报告只排除 max_rss_kib 后一致。没有由本审查重启重放或 Godot。

审查自身 Python 进程均设置 128 MiB RLIMIT_AS，峰值见各 RESULT。输入 pin、审查脚本及输出白名单收于同目录。完整 driver 的 imports/preprocessors/上游 cards 变换仍未闭合；不从原始双行接受推断真实 hook 到达时未被修改，更不推断 Game、存档或战斗验收。
