"""Read-only supplementary review. Does not import/execute target/test/runner code."""
from pathlib import Path
import ast, hashlib, json, resource
resource.setrlimit(resource.RLIMIT_AS,(128*1024**2,128*1024**2))
H=Path(__file__).resolve().parent
S=H.parent/'elistra_redirect_correction_review_20261110T021700Z'
allow=['current_data_inputs/CURRENT_RAW_ROWS.json','current_data_inputs/CURRENT_COMPILED_ROWS.json',
 'current_data_inputs/CURRENT_INPUT_LOCATIONS.json','CURRENT_AND_SNAPSHOT_RESULT.json',
 'CURRENT_GODOT_first.json','CURRENT_GODOT_repeat.json','CURRENT_GODOT_RUNS.json',
 'CURRENT_GODOT_first.stderr.log','CURRENT_GODOT_repeat.stderr.log','test_current_and_snapshot.py',
 'gd_minimal/current_data.gd','run_current_godot.py','replay_to_new.py','verify_results.py',
 'REPLAY_INPUTS.json','VERIFIED_RESULTS.json','static_current_inputs/DEPENDENCY_GRAPH.json',
 'static_current_inputs/STATIC_RESULTS.json','static_current_inputs/EXACT_SLICE_VERIFICATION.json',
 'static_current_inputs/SOURCE_PINS.json','static_current_inputs/FINAL_INPUT_RECHECK.json']
for kind in ('raw','compiled'):
 for identity in ('BGS_205','TB_BaconUps_306'):
  allow.append('static_current_inputs/evidence/'+kind+'.'+identity+'.exact.json')
B={p:(S/p).read_bytes() for p in allow}; J=lambda p:json.loads(B[p]); sha=lambda b:hashlib.sha256(b).hexdigest()
main=json.loads((H/'RESULT.json').read_bytes()); main_pins=json.loads((H/'INPUT_PINS.json').read_bytes())
current_raw=J('current_data_inputs/CURRENT_RAW_ROWS.json'); current_out=J('current_data_inputs/CURRENT_COMPILED_ROWS.json')
assert sha(B['current_data_inputs/CURRENT_RAW_ROWS.json'])=='e94544aeae79ae363083b3cee4d9cb84ccb89811a56e60edda869d755a0dea5a'
assert sha(B['current_data_inputs/CURRENT_COMPILED_ROWS.json'])==main_pins['ORIGINAL_OUTPUTS.json']['sha256']
loc=J('current_data_inputs/CURRENT_INPUT_LOCATIONS.json'); source_pins=J('static_current_inputs/SOURCE_PINS.json')
for kind,source in [('raw',loc['driver_raw_inputs'][0]),('compiled',loc['compiled_catalog'])]:
 rows=current_raw if kind=='raw' else current_out
 for m in source['matches']:
  p='static_current_inputs/'+m['exact_excerpt_path']
  assert sha(B[p])==m['exact_excerpt_sha256']
  assert len(B[p])==m['byte_end_exclusive']-m['byte_start_zero_based']
  assert json.loads(B[p])==rows[m['id']]
assert all(not x['matches'] for x in loc['driver_raw_inputs'][1:])
snap=J('CURRENT_AND_SNAPSHOT_RESULT.json')
assert all(x['current_raw_accepted'] and x['result_exact_current_compiled_overlay'] for x in snap['current_data_cases'])
assert snap['actual_hook_outputs_exact_current_compiled'] and snap['stale_target_outputs_removed_on_rejection'] and snap['unrelated_output_preserved'] and snap['current_hook_order_exact']
assert set(snap['controlled_snapshot_test']['reads'].values())=={1} and len(snap['controlled_snapshot_test']['reads'])==4
assert snap['controlled_snapshot_test']['raw_parsed_from_verified_bytes_despite_post_read_path_change']
assert snap['controlled_snapshot_test']['fixture_reset_to_exact_historical_pin'] and snap['controlled_snapshot_test']['not_a_global_atomic_snapshot']
assert len(snap['invalid_root_id_cases'])==12 and all(x['rejected'] for x in snap['invalid_root_id_cases'])
script=ast.parse(B['test_current_and_snapshot.py'])
observer=next(n for n in script.body if isinstance(n,ast.FunctionDef) and n.name=='observed_read')
assert isinstance(observer.body[0],ast.Assign) and ast.unparse(observer.body[0].value)=='real_read_bytes(path)'
assert any(isinstance(n,ast.Call) and ast.unparse(n.func)=='path.write_bytes' for n in ast.walk(observer))
assert ast.unparse(observer.body[-1])=='return data'
assert any(isinstance(n,ast.Try) and any(isinstance(x,ast.Assign) and ast.unparse(x)=='Path.read_bytes = real_read_bytes' for x in n.finalbody) for n in script.body)
cg=J('CURRENT_GODOT_first.json')
assert B['CURRENT_GODOT_first.json']==B['CURRENT_GODOT_repeat.json']
assert not cg['failures'] and cg['closure_error']=='' and all(x['raw_error']==x['compiled_error']=='' for x in cg['rows'])
assert cg['minimal_get_card_interface_not_production_catalog'] and cg['game_not_run']
assert not B['CURRENT_GODOT_first.stderr.log'] and not B['CURRENT_GODOT_repeat.stderr.log']
assert all(x['exit_code']==0 and x['stopped'] is None for x in J('CURRENT_GODOT_RUNS.json'))
deps=J('static_current_inputs/DEPENDENCY_GRAPH.json'); static=J('static_current_inputs/STATIC_RESULTS.json')
assert len(deps['python']['proof_pinned_files'])==3 # report explicitly describes historical original, not new candidate
assert deps['python']['raw_rows_pin_not_consumed_by_original_tool']==sha(B['current_data_inputs/CURRENT_RAW_ROWS.json'])
assert deps['full_driver']['current_driver_exists'] is False and deps['full_driver']['current_tool_exists'] is False
assert len(deps['gd_preload_closure'])==3 and deps['full_driver']['missing_local_py_entries']==789
assert static['original_patch']['glued_xml_header_lines']==[605,686] and static['original_patch']['untouched']
verified=J('VERIFIED_RESULTS.json')
assert verified['candidate_sha256']==main['candidate_sha256'] and verified['installed'] is False
assert verified['case_count']==886 and verified['candidate_accepts']==178 and verified['unchanged_hook_pre_call_exceptions']==8
replay_pins=J('REPLAY_INPUTS.json'); unknown=[]
for p,pin in replay_pins.items():
 assert not Path(p).is_absolute() and '..' not in Path(p).parts
 if p in B:observed={'bytes':len(B[p]),'sha256':sha(B[p])}
 elif p in main_pins:observed=main_pins[p]
 else:unknown.append(p);continue
 assert observed==pin,p
result={'status':'SUPPLIED_CURRENT_ROWS_AND_RECORDED_PROBES_CONSISTENT',
 'current_raw_serialized_bytes_equal_historical_pin':True,'current_compiled_serialized_bytes_equal_original_expected':True,
 'exact_excerpt_bytes_match_location_pins_and_normalized_rows':True,
 'full_current_raw_catalog_not_independently_reopened_by_this_reviewer':True,
 'source_of_current_rows':'Copied static_current_inputs extraction evidence and CURRENT_INPUT_LOCATIONS.json; source file scan belongs to separate current-input reviewer.',
 'recorded_current_python_and_hook_pass':True,'recorded_current_godot_reports_byte_equal':True,
 'snapshot_test_design_valid_for_same_verified_raw_bytes_not_global_atomic_snapshot':True,
 'invalid_card_root_id_cases_recorded':12,
 'historical_dependency_report_describes_original_three_pin_module_not_new_candidate':True,
 'full_driver_closure_not_proven':True,'historical_full_patch_xml_header_glue_preserved':True,
 'replay_script_inspected_not_executed':True,'replay_input_entries':len(replay_pins),
 'replay_pins_cross_checked_in_reviewed_inputs':len(replay_pins)-len(unknown),
 'replay_extra_prior_files_not_reopened':unknown,
 'target_or_godot_executed_by_reviewer':False,'max_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
for p,b in B.items():assert (S/p).read_bytes()==b,'Changed during supplementary review: '+p
(H/'CURRENT_INPUT_PINS.json').write_text(json.dumps({p:{'bytes':len(b),'sha256':sha(b)} for p,b in B.items()},indent=2)+'\n')
(H/'CURRENT_RESULT.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(result,ensure_ascii=False,indent=2))
