"""Compare existing portable replay bytes only. Does not launch replay/targets/Godot."""
from pathlib import Path
import hashlib,json,resource
resource.setrlimit(resource.RLIMIT_AS,(128*1024**2,128*1024**2))
H=Path(__file__).resolve().parent
S=H.parent/'elistra_redirect_correction_review_20261110T021700Z'
R=H.parent/'elistra_correction_portable_replay_20261110T022700Z'
sha=lambda b:hashlib.sha256(b).hexdigest()
inputs={}
def read(root,name):
 assert not Path(name).is_absolute() and '..' not in Path(name).parts
 b=(root/name).read_bytes();inputs[str(root/name)]={'bytes':len(b),'sha256':sha(b)};return b
pins=json.loads(read(S,'REPLAY_INPUTS.json'))
assert len(pins)==56
assert read(S,'PORTABLE_REPLAY_RESULT.json')==read(R,'REPLAY_RESULT.json')
report=json.loads(read(R,'REPLAY_RESULT.json'))
assert report['input_files']==56 and report['source_inputs_unchanged'] and Path(report['replay_directory'])==R
for rel,pin in pins.items():
 for root in (S,R):
  b=read(root,rel);assert {'bytes':len(b),'sha256':sha(b)}==pin
outputs=['DRIVER_EXACT_FRAGMENTS.py','ORIGINAL_OUTPUTS.json']+[f'{prefix}_{run}.{suffix}' for prefix in ('GODOT','CURRENT_GODOT') for run in ('first','repeat') for suffix in ('json','stdout.log','stderr.log')]
assert outputs==report['byte_equal_outputs'] and len(outputs)==14
for rel in outputs:assert read(S,rel)==read(R,rel),rel
for rel in ('PYTHON_REPORT.json','CURRENT_AND_SNAPSHOT_RESULT.json','VERIFIED_RESULTS.json'):
 a=json.loads(read(S,rel));b=json.loads(read(R,rel));a.pop('max_rss_kib',None);b.pop('max_rss_kib',None);assert a==b,rel
for src,dst in [('GODOT_RUNS.json','PORTABLE_GODOT_RUNS.json'),('CURRENT_GODOT_RUNS.json','PORTABLE_CURRENT_GODOT_RUNS.json'),('VERIFIED_RESULTS.json','PORTABLE_VERIFIED_RESULTS.json')]:
 assert read(R,src)==read(S,dst)
 if src.endswith('RUNS.json'):
  assert all(x['exit_code']==0 and x['stopped'] is None for x in json.loads(read(R,src)))
result={'status':'PORTABLE_REPLAY_BYTES_INDEPENDENTLY_RECONCILED','input_files_verified_in_both_directories':56,
 'byte_equal_outputs_independently_compared':14,'reports_equal_except_max_rss':3,
 'replay_launched_by_reviewer':False,'target_or_godot_executed_by_reviewer':False,
 'no_integration_or_installation_claim':True,'max_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
for p,pin in inputs.items():
 b=Path(p).read_bytes();assert {'bytes':len(b),'sha256':sha(b)}==pin
(H/'REPLAY_INPUT_PINS.json').write_text(json.dumps(inputs,indent=2)+'\n')
(H/'REPLAY_RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
