from pathlib import Path
import hashlib,json,resource
resource.setrlimit(resource.RLIMIT_AS,(128*1024**2,128*1024**2))
H=Path(__file__).resolve().parent
S=H.parent/'elistra_redirect_correction_review_20261110T021700Z'
sha=lambda b:hashlib.sha256(b).hexdigest()
merged={}
for file in ('INPUT_PINS.json','CURRENT_INPUT_PINS.json','REPLAY_INPUT_PINS.json'):
 for name,pin in json.loads((H/file).read_bytes()).items():
  p=Path(name) if Path(name).is_absolute() else S/name
  key=str(p)
  if key in merged:assert merged[key]==pin
  merged[key]=pin
for path,pin in merged.items():
 b=Path(path).read_bytes();assert {'bytes':len(b),'sha256':sha(b)}==pin,path
recheck={'input_files':len(merged),'all_unchanged':True,'target_execution':False,'network':False,'godot_launched':False,'installation':False}
(H/'FINAL_INPUT_RECHECK.json').write_text(json.dumps(recheck,indent=2)+'\n')
artifacts=['review.py','review_current.py','review_replay.py','seal.py','INPUT_PINS.json','CURRENT_INPUT_PINS.json','REPLAY_INPUT_PINS.json','RESULT.json','CURRENT_RESULT.json','REPLAY_RESULT.json','FINAL_INPUT_RECHECK.json','REVIEW.md']
assert {p.name for p in H.iterdir()}==set(artifacts+['WHITELIST_MANIFEST.json'])
manifest={'kind':'INDEPENDENT_STATIC_AND_STORED_REPORT_REVIEW','input_allowlist':merged,
 'output_allowlist':artifacts+['WHITELIST_MANIFEST.json'],
 'artifacts':{p:{'bytes':len((H/p).read_bytes()),'sha256':sha((H/p).read_bytes())} for p in artifacts},
 'target_execution':False,'godot_execution':False,'network':False,'installation':False,
 'source_trees_modified':False,'memory_limit_bytes_per_auditor':128*1024**2}
(H/'WHITELIST_MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(recheck))
print('WHITELIST_MANIFEST.json sha256 '+sha((H/'WHITELIST_MANIFEST.json').read_bytes()))
