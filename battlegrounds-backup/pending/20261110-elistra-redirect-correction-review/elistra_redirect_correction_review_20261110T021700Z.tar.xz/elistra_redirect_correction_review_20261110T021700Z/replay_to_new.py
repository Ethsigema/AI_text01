from pathlib import Path
import hashlib,json,subprocess,sys
H=Path(__file__).resolve().parent
if len(sys.argv)!=2:raise SystemExit('Usage: python replay_to_new.py /absolute/new/directory')
D=Path(sys.argv[1]).resolve();assert not D.exists();D.mkdir(parents=True)
pins=json.loads((H/'REPLAY_INPUTS.json').read_text())
for rel,pin in pins.items():
 p=Path(rel);assert not p.is_absolute() and '..' not in p.parts
 b=(H/p).read_bytes();assert len(b)==pin['bytes'] and hashlib.sha256(b).hexdigest()==pin['sha256'];d=D/p;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(b)
for script in ['test_candidate.py','test_current_and_snapshot.py','run_godot.py','run_current_godot.py','verify_results.py']:
 # Tests/verifiers self-limit Python to128MiB; each Godot child has its separate monitored bounds.
 r=subprocess.run([sys.executable,str(D/script)],capture_output=True,text=True);(D/(script+'.stdout.log')).write_text(r.stdout);(D/(script+'.stderr.log')).write_text(r.stderr);assert r.returncode==0,(script,r.returncode,r.stderr)
for rel,pin in pins.items():assert hashlib.sha256((D/rel).read_bytes()).hexdigest()==pin['sha256']
def normalized(file):
 r=json.loads(file.read_text());r.pop('max_rss_kib',None);return r
for rel in ['PYTHON_REPORT.json','CURRENT_AND_SNAPSHOT_RESULT.json','VERIFIED_RESULTS.json']:assert normalized(D/rel)==normalized(H/rel),rel
outputs=['DRIVER_EXACT_FRAGMENTS.py','ORIGINAL_OUTPUTS.json']+[f'{prefix}_{run}.{suffix}' for prefix in ['GODOT','CURRENT_GODOT'] for run in ['first','repeat'] for suffix in ['json','stdout.log','stderr.log']]
for rel in outputs:assert (D/rel).read_bytes()==(H/rel).read_bytes(),rel
report={'input_files':len(pins),'byte_equal_outputs':outputs,'reports_equal_except_peak_rss':['PYTHON_REPORT.json','CURRENT_AND_SNAPSHOT_RESULT.json','VERIFIED_RESULTS.json'],'source_inputs_unchanged':True,'replay_directory':str(D)}
(D/'REPLAY_RESULT.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
