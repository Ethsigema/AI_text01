from pathlib import Path
import json,hashlib,difflib,resource,collections
resource.setrlimit(resource.RLIMIT_AS,(128*1024**2,128*1024**2))
H=Path(__file__).resolve().parent;F='research/elistra_redirect_native_recovery/'
p=json.loads((H/'PYTHON_REPORT.json').read_text());g=json.loads((H/'GODOT_first.json').read_text());cases=json.loads((H/'CASES.json').read_text());assert len(cases)==len(p['results'])==len(g['results'])==886 and not g['failures']
assert (H/'GODOT_first.json').read_bytes()==(H/'GODOT_repeat.json').read_bytes()
assert (H/'CURRENT_GODOT_first.json').read_bytes()==(H/'CURRENT_GODOT_repeat.json').read_bytes()
assert all(a['label']==b['label']==c['label'] for a,b,c in zip(cases,p['results'],g['results']))
for a,b in zip(p['results'],g['results']):
 c=a['versions']['candidate'];expected=b['strict_memory_ingress_accept'] and a['all_four_pins_valid'];assert c['accepted']==expected and c['error'] is None
 assert not c['accepted'] or a['versions']['original']['accepted']
 if b['versions']['candidate']['actual_hook_output_closure_error'] is not None:assert b['versions']['candidate']['actual_hook_output_closure_error']==''
 for v in ['original','candidate']:assert all(call['same_mapping_value'] for call in a['versions'][v]['hook_calls'])
assert sum(x['versions']['candidate']['accepted'] for x in p['results'])==178
assert sum(x['versions']['original']['accepted'] for x in p['results'])==452
assert sum(x['versions']['original']['error'] is not None for x in p['results'])==20
assert sum(x['versions']['candidate']['hook_error'] is not None for x in p['results'])==8
assert all(x['regime']=='mapping_root' and x['versions']['candidate']['hook_error']=='AttributeError' for x in p['results'] if x['versions']['candidate']['hook_error'])
assert sum(x['versions']['candidate']['actual_hook_output_closure_error'] is not None for x in g['results'])==392
assert len(g['structural_probes'])==12 and len(g['effect_probes'])==12 and len(g['unit_probes'])==20
for name in ['GODOT','CURRENT_GODOT']:
 for run in ['first','repeat']:assert not (H/f'{name}_{run}.stderr.log').read_bytes()
c=json.loads((H/'CURRENT_AND_SNAPSHOT_RESULT.json').read_text());assert c['actual_hook_outputs_exact_current_compiled'] and c['controlled_snapshot_test']['all_four_files_read_once'] and c['controlled_snapshot_test']['fixture_reset_to_exact_historical_pin'];assert not json.loads((H/'CURRENT_GODOT_first.json').read_text())['failures']
manifest=json.loads((H/'CANDIDATE_MANIFEST.json').read_text());original=(H/'prior_snapshot/original_inputs'/F/'candidates/tools/elistra_redirect_patterns.py').read_bytes();candidate=(H/'candidate/tools/elistra_redirect_patterns.py').read_bytes();patch=(H/'NEW_CORRECTION.patch').read_bytes()
for key,data in [('original',original),('candidate',candidate),('patch',patch)]:assert hashlib.sha256(data).hexdigest()==manifest[key+'_sha256']
assert patch.decode()==''.join(difflib.unified_diff(original.decode().splitlines(keepends=True),candidate.decode().splitlines(keepends=True),fromfile='a/tools/elistra_redirect_patterns.py',tofile='b/tools/elistra_redirect_patterns.py'))
for rel,pin in json.loads((H/'INPUT_PINS.json').read_text()).items():assert hashlib.sha256((H/'prior_snapshot/original_inputs'/rel).read_bytes()).hexdigest()==pin['sha256']
for rel in [F+'native_source_manifest.json',F+'native/BGS_205.xml',F+'native/TB_BaconUps_306.xml',F+'raw_rows.json']:
 assert (H/'fixture_root'/rel).read_bytes()==(H/'prior_snapshot/original_inputs'/rel).read_bytes()
assert hashlib.sha256((H/'current_data_inputs/CURRENT_RAW_ROWS.json').read_bytes()).hexdigest()==manifest['raw_rows_historical_pin']
report={'status':'INDEPENDENT_NEW_CORRECTION_PASSES_BOUNDED_TESTS_DEFER_INSTALL','case_count':886,'original_accepts':452,'candidate_accepts':178,'tightened_cases':274,'candidate_direct_exceptions':0,'original_direct_exceptions':20,'unchanged_hook_pre_call_exceptions':8,'candidate_vs_composed_GD_and_four_pin_mismatches':0,'accepted_hook_mapping_closure_checks':392,'accepted_hook_mapping_closure_rejects':0,'legacy262_original_unchanged':p['legacy262_original_results_exact'],'structure_cases':12,'effect_cases':12,'unit_cases':20,'current_raw_rows':2,'current_compiled_rows':2,'current_data_actual_GD_passed':True,'controlled_read_once_snapshot_passed':True,'proof_is_byte_exact_including_whitespace':True,'candidate_sha256':manifest['candidate_sha256'],'historical_patch_unfixed':True,'installed':False,'game_or_save_acceptance':False,'max_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
(H/'VERIFIED_RESULTS.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
