# Small dependency map

Python isolated call
  candidate elistra_redirect_patterns.py
    stdlib: pathlib, copy, hashlib, json
    explicit root
      native_source_manifest.json [tool SHA256 pinned]
      native/BGS_205.xml [tool SHA256 pinned]
      native/TB_BaconUps_306.xml [tool SHA256 pinned]
      raw_rows.json [read, not pinned by original tool]
    selected card + mapping of both canonical raw rows

GD isolated gate
  minimal harness + compatible existing Godot engine
    elistra_redirect_sources.gd
      phase_undead_army_sources.gd
        pool_identity.gd
      pool_identity.gd

Broader unexecuted integration boundary
  historical full driver [current formal path missing]
    11 source inputs -> ID overwrite map
    QuestIdentity [missing] -> HeroValues [missing] -> FinalSource [present]
    confirmed value overrides -> numerous compiler hooks
    actual Elistra hook -> emit -> later hooks -> output file writes
  full Catalog
    Sources.RUNTIME_PATHS bytes -> overall execution fingerprint
    raw/overlay/source/program/closure validation
  Game
    factory validation
    save fingerprint / effective room catalog fingerprint comparison
    full save/unit validation
  Combat
    not included in minimal Python/GD gate validation
