#!/usr/bin/env python3
"""Independent static/read-only extraction; never imports or executes project code."""
import resource
resource.setrlimit(resource.RLIMIT_AS, (128*1024*1024,128*1024*1024))
import ast, gc, hashlib, json, pathlib, re, sys, xml.etree.ElementTree as ET
BASE=pathlib.Path('/workspace/scratch/dd4f12b08ec0')
R=BASE/'historical_tools_batch14_20261109T191857Z/runtime'
OUT=pathlib.Path(__file__).resolve().parent
REC='research/elistra_redirect_native_recovery/'
IDS=('BGS_205','TB_BaconUps_306')
PINS={}
def digest(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(65536),b''):h.update(b)
 return h.hexdigest()
def pin(rel):
 p=R/rel if not pathlib.Path(rel).is_absolute() else pathlib.Path(rel)
 k=str(p.relative_to(R)) if p.is_relative_to(R) else str(p)
 PINS[k]={'path':str(p),'bytes':p.stat().st_size,'sha256':digest(p)}
 return p

def read(rel):return pin(rel).read_text(encoding='utf-8')
def jd(name,obj):
 (OUT/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def same(a,b):
 if type(a) in (int,float) and type(b) in (int,float):return a==b
 if type(a) is not type(b):return False
 if isinstance(a,dict):return a.keys()==b.keys() and all(same(v,b[k]) for k,v in a.items())
 if isinstance(a,list):return len(a)==len(b) and all(same(x,y) for x,y in zip(a,b))
 return a==b

def scan_cards(rel,tag):
 p=pin(rel); hits=[]; rows={}; n=0; idx_byte=0; idx_line=1
 with p.open('r',encoding='utf-8',newline='') as f:
  buf=f.read(65536)
  m=re.search(r'"cards"\s*:\s*\[',buf); assert m,rel
  prefix=buf[:m.end()-1]
  taken=buf[:m.end()]; idx_byte+=len(taken.encode());idx_line+=taken.count('\n');buf=buf[m.end():]
  dec=json.JSONDecoder(); need_value=True; end=False
  while not end:
   ws=len(buf)-len(buf.lstrip()); taken=buf[:ws];idx_byte+=len(taken.encode());idx_line+=taken.count('\n');buf=buf[ws:]
   if not buf:
    extra=f.read(65536);assert extra,'Unexpected EOF';buf+=extra;continue
   if buf[0]==']':
    assert need_value or n>0
    buf=buf[1:]; suffix=buf+f.read(); json.loads(prefix+'[]'+suffix);end=True;break
   if not need_value:
    assert buf[0]==',',(rel,n,buf[:50]);buf=buf[1:];idx_byte+=1;need_value=True;continue
   while True:
    try:row,e=dec.raw_decode(buf);break
    except json.JSONDecodeError:
     extra=f.read(65536);assert extra,'Invalid object or EOF';buf+=extra
   assert isinstance(row,dict),rel
   exact=buf[:e]; ident=row.get('id')
   if ident in IDS:
    assert ident not in rows,(rel,ident,'duplicate')
    exact_path=f'evidence/{tag}.{ident}.exact.json'
    (OUT/exact_path).write_bytes(exact.encode('utf-8'))
    hits.append({'id':ident,'array_index_zero_based':n,'array_index_one_based':n+1,'line_start_one_based':idx_line,'line_end_one_based':idx_line+exact.count('\n'),'byte_start_zero_based':idx_byte,'byte_end_exclusive':idx_byte+len(exact.encode()),'exact_excerpt_path':exact_path,'exact_excerpt_sha256':hashlib.sha256(exact.encode()).hexdigest()})
    rows[ident]=row
   idx_byte+=len(exact.encode());idx_line+=exact.count('\n');buf=buf[e:];need_value=False;n+=1
 return {'path':rel,'bytes':PINS[rel]['bytes'],'sha256':PINS[rel]['sha256'],'card_count':n,'matches':hits},rows

files=['data/catalog_raw.json','data/supplemental_missing_catalog.json','data/native_prize_catalog.json','data/native_brukan_catalog.json','data/native_threshadon_tokens.json','data/native_ironhide_tokens.json','data/native_giantfin_token.json','data/native_protoss_tokens.json','data/native_caduceus_auxiliary.json','data/native_kerrigan_zerg_auxiliary.json','data/native_megasaur_adapt_token.json']
source_scans=[]; raw={}
for i,rel in enumerate(files):
 info,rs=scan_cards(rel,'raw');info['historical_driver_input_order_zero_based']=i;source_scans.append(info)
 for ident,row in rs.items():assert ident not in raw;raw[ident]=row
catinfo,compiled=scan_cards('data/catalog.json','compiled')
assert set(raw)==set(compiled)==set(IDS)
jd('CURRENT_RAW_ROWS.json',raw);jd('CURRENT_COMPILED_ROWS.json',compiled)
jd('CURRENT_INPUT_LOCATIONS.json',{'driver_raw_inputs':source_scans,'compiled_catalog':catinfo,'scope':'Original input file rows before preprocessing. Not the runtime hook state.'})

historic_raw=json.loads(read(REC+'raw_rows.json'))
historic_expected=json.loads(read(REC+'expected_compiled.json'))
historic_programs=json.loads(read(REC+'programs.json'))
manifest=json.loads(read(REC+'manifest.json'))
gdtext=read('core/elistra_redirect_sources.gd');gd={}
for name in ['RAW','EXPECTED','PROGRAMS','RUNTIME_PATHS']:
 line=next(l for l in gdtext.splitlines() if l.startswith('const '+name+':'))
 gd[name]=json.loads(line.split('=',1)[1])
jd('CURRENT_GD_CONSTANTS.json',gd)
pytext=read(REC+'candidates/tools/elistra_redirect_patterns.py');pt=ast.parse(pytext)
pyconst={}
for n in pt.body:
 if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name) and n.targets[0].id in ('SOURCE_IDS','EXPECTED','PROOF_SHA256'):
  pyconst[n.targets[0].id]=ast.literal_eval(n.value)
proof_checks=[]
for rel,want in pyconst['PROOF_SHA256'].items():
 p=pin(rel);proof_checks.append({'path':rel,'expected':want,'actual':PINS[rel]['sha256'],'matches':PINS[rel]['sha256']==want})
source_manifest=json.loads((R/(REC+'native_source_manifest.json')).read_text())
native={}
for ident in IDS:
 root=ET.fromstring((R/(REC+'native/'+ident+'.xml')).read_bytes())
 entity=root if root.tag=='Entity' else root.find('Entity')
 assert entity is not None
 native[ident]={'entity_attributes':entity.attrib,'direct_tags':{t.get('name'):t.get('value') for t in entity.findall('Tag') if t.get('name') in ('ATK','HEALTH','TECH_LEVEL','DIVINE_SHIELD','REBORN','TAUNT','COST','CARDRACE','BACON_TRIPLE_UPGRADE_MINION_ID','BACON_TRIPLED_BASE_MINION_ID','PREMIUM')},'referenced_tags':[t.attrib for t in entity.findall('ReferencedTag')]}
 for t in entity.findall('Tag'):
  if t.get('name')=='CARDTEXT':
   native[ident]['zhCN']=t.findtext('zhCN');native[ident]['enUS']=t.findtext('enUS')
 text=native[ident].get('zhCN','')
 native[ident]['markup_stripped_text_matches_raw']=re.sub(r'<[^>]*>|\s','',text)==raw[ident]['text']
 native[ident]['stats_match_raw']=all(int(native[ident]['direct_tags'][tag])==raw[ident][key] for tag,key in [('ATK','attack'),('HEALTH','health'),('TECH_LEVEL','tier')])
 native[ident]['manifest_native_hash_matches']=source_manifest['entities'][ident]['native_sha256']==PINS[REC+'native/'+ident+'.xml']['sha256']

checks={
 'historical_raw_pin_matches':PINS[REC+'raw_rows.json']['sha256']=='e94544aeae79ae363083b3cee4d9cb84ccb89811a56e60edda869d755a0dea5a',
 'python_candidate_pin_matches':PINS[REC+'candidates/tools/elistra_redirect_patterns.py']['sha256']=='94f4398484c99accb054bc125f896317aa2b3e611d702119ca14d3e5a37ecefa',
 'current_gd_pin_matches':PINS['core/elistra_redirect_sources.gd']['sha256']=='1ba1f47dcf21e814476fd634bf143a0e36eede3956399fb78ee377e86ca4199d',
 'current_raw_equals_historic_raw':same(raw,historic_raw),
 'current_raw_equals_gd_RAW':same(raw,gd['RAW']),
 'current_compiled_equals_historic_expected':same(compiled,historic_expected),
 'current_compiled_equals_gd_EXPECTED':same(compiled,gd['EXPECTED']),
 'gd_EXPECTED_equals_python_EXPECTED':same(gd['EXPECTED'],pyconst['EXPECTED']),
 'gd_PROGRAMS_equals_historic_programs':same(gd['PROGRAMS'],historic_programs),
 'python_proof_checks':proof_checks,
 'native':native,
}
# Read the historical driver as source only. AST operations never compile/exec it.
driver_rel=REC+'candidates/tools/build_effect_catalog.py';driver=read(driver_rel);dt=ast.parse(driver)
imports=[];missing=[]
for n in ast.walk(dt):
 if isinstance(n,ast.ImportFrom):mods=[n.module] if n.module else []
 elif isinstance(n,ast.Import):mods=[a.name for a in n.names]
 else:continue
 for mod in mods:
  if mod.split('.')[0] in sys.stdlib_module_names:continue
  candidate=R/'tools'/f'{mod}.py'; item={'module':mod,'line':n.lineno,'current_local_py_exists':candidate.is_file()};imports.append(item)
  if not candidate.is_file():missing.append(item)
calls=[n for n in ast.walk(dt) if isinstance(n,ast.Call) and any(isinstance(a,ast.Name) and a.id=='cards' for a in n.args)]
checks['historical_driver']={'path':driver_rel,'sha256':PINS[driver_rel]['sha256'],'current_driver_exists':(R/'tools/build_effect_catalog.py').exists(),'current_tool_exists':(R/'tools/elistra_redirect_patterns.py').exists(),'nonstdlib_direct_module_entries':len(imports),'missing_local_py_entries':len(missing),'whole_cards_call_sites_total':len(calls),'whole_cards_call_sites_before_hook':sum(n.lineno<3278 for n in calls),'module_presence_scope':'Static local runtime/tools/*.py existence only; not sys.path resolution or transitive import closure.','preprocessors':[{'module':m,'line':line,'exists':(R/'tools'/f'{m}.py').is_file()} for m,line in [('recruit_quest_identity',532),('hero_value_overrides',534),('final_source_overrides',535)]]}
del dt;gc.collect()
# Pin and independently inspect the one currently present explicit preprocessor.
final_src=read('tools/final_source_overrides.py');ft=ast.parse(final_src)
ids_node=next(n.value for n in ft.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='IDS' for t in n.targets))
final_ids=ast.literal_eval(ids_node.args[0]);final_manifest=json.loads(read('data/final_bg_source_overrides.json'))
value_overrides=json.loads(read('data/catalog_value_overrides.json'))
checks['current_explicit_override_scope']={'final_source_module_ids_exclude_elistra':not(set(IDS)&set(final_ids)),'final_source_manifest_matches_module_pin':PINS['data/final_bg_source_overrides.json']['sha256']=='1f61cc86718d6e0fcba3091b9213823c8c25804cb6a2849e66946a7cafb63c27','final_source_manifest_elistra_rows':[x for x in final_manifest['overrides'] if x.get('id') in IDS],'catalog_value_overrides_elistra_rows':[x for x in value_overrides['overrides'] if x.get('id') in IDS],'does_not_establish_missing_preprocessors_or_all_hooks_are_identity_preserving':True}
# GD minimal parse/preload closure: no target GD execution.
graph={};pending=['core/elistra_redirect_sources.gd']
while pending:
 rel=pending.pop()
 if rel in graph:continue
 s=gdtext if rel=='core/elistra_redirect_sources.gd' else read(rel)
 refs=re.findall(r'\bpreload\("res://([^"\n]+)"\)',s);graph[rel]=refs;pending.extend(refs)
checks['gd_preload_closure']=graph
checks['gd_runtime_paths_presence']=[{'path':p,'exists':(R/p).is_file()} for p in gd['RUNTIME_PATHS']]
# Minimal exact evidence excerpts, preserving source line numbers.
def excerpt(rel,ranges,dest,source=None):
 s=source if source is not None else read(rel);lines=s.splitlines()
 chunks=[]
 for first,last in ranges:chunks.append('\n'.join(f'{i}: {lines[i-1]}' for i in range(first,last+1)))
 (OUT/'evidence'/dest).write_text(f'Source: {rel}\nSHA256: {PINS[rel]["sha256"]}\n\n'+'\n\n'.join(chunks)+'\n',encoding='utf-8')
excerpt(driver_rel,[(134,134),(433,433),(468,468),(474,474),(518,551),(559,559),(3274,3283),(len(driver.splitlines())-7,len(driver.splitlines()))],'HISTORICAL_DRIVER.txt',driver)
excerpt('core/elistra_redirect_sources.gd',[(8,31),(57,64)],'CURRENT_GD_GATES.txt',gdtext)
excerpt('core/phase_undead_army_sources.gd',[(7,21)],'EXACT_COMPARATOR.txt')
excerpt('core/catalog.gd',[(857,858),(1387,1388),(2100,2101),(2103,2105),(3231,3240),(13566,13576),(16666,16670)],'CATALOG_BOUNDARY.txt')
excerpt('core/game.gd',[(9284,9286),(14131,14145),(14487,14497),(16326,16326)],'SAVE_FACTORY_BOUNDARY.txt')
excerpt('core/custom_shop.gd',[(84,90),(112,120)],'CUSTOM_SHOP_FINGERPRINT.txt')
patch=read(REC+'candidate.patch');glued=[i for i,l in enumerate(patch.splitlines(),1) if l=='+\t--- /dev/null']
checks['original_patch']={'sha256':PINS[REC+'candidate.patch']['sha256'],'glued_xml_header_lines':glued,'untouched':True}
excerpt(REC+'candidate.patch',[(602,608),(683,689)],'UNMODIFIED_XML_GLUE.txt',patch)
# Historic provenance pins and preserved bundle, hash only, no unpacking/execution.
pin(REC+'before/tools/build_effect_catalog.py')
archive=str(BASE/'elistra_redirect_readonly_probe_20261110T015700Z.tar.xz');pin(archive)
checks['sealed_review_archive']={'path':archive,'sha256':PINS[archive]['sha256'],'matches_expected':PINS[archive]['sha256']=='bf2e9bf9747469d66c7caad93ef3af87512d02d3622914633189af6436833ef8','read_mode':'streaming SHA256 only; not unpacked'}
checks['manifest_anchored_pins']=[dict(x,observed=PINS.get(x['candidate'],PINS.get(x['path']))) for x in manifest['files'] if x['path'] in ('tools/elistra_redirect_patterns.py','tools/build_effect_catalog.py','core/elistra_redirect_sources.gd',REC+'raw_rows.json')]
checks['resource_limits']={'rlimit_as_bytes':128*1024*1024,'peak_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'execution':'own static auditor only; no import/exec of target Python/GD/driver/Game/Catalog/Combat'}
jd('STATIC_RESULTS.json',checks)
jd('SOURCE_PINS.json',PINS)
jd('DEPENDENCY_GRAPH.json',{'python':{'module':REC+'candidates/tools/elistra_redirect_patterns.py','stdlib_imports':['pathlib.Path','copy.deepcopy','hashlib','json'],'explicit_root_required_for_isolation':True,'runtime_read_files':list(pyconst['PROOF_SHA256'])+[REC+'raw_rows.json'],'proof_pinned_files':pyconst['PROOF_SHA256'],'raw_rows_pin_not_consumed_by_original_tool':PINS[REC+'raw_rows.json']['sha256'],'test_input_objects':['selected card','mapping containing both exact canonical raw rows'],'not_required':['historical full driver','Game','Catalog','Combat','Godot','network']},'gd_preload_closure':graph,'gd_runtime_paths_are_fingerprint_metadata_not_preload_dependencies':gd['RUNTIME_PATHS'],'full_driver':checks['historical_driver']})
recheck=[]
for name,item in PINS.items():
 p=pathlib.Path(item['path']);now=digest(p);recheck.append({'path':name,'sha256':now,'matches':now==item['sha256'],'bytes':p.stat().st_size})
assert all(x['matches'] for x in recheck)
jd('FINAL_INPUT_RECHECK.json',{'all_unchanged':True,'inputs':recheck})
print(json.dumps({'rows_ready':str(OUT/'CURRENT_RAW_ROWS.json'),'checks':{k:v for k,v in checks.items() if isinstance(v,bool)},'peak_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'current_raw_locations':source_scans[0]['matches'],'compiled_locations':catinfo['matches'],'driver':checks['historical_driver']},ensure_ascii=False,indent=2))
