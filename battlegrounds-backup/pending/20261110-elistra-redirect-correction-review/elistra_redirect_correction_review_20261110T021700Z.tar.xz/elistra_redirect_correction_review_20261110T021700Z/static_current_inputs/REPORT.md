# Elistra 当前输入、最小依赖和历史 hook 独立复核

## 可直接交给隔离测试的结果

- `CURRENT_RAW_ROWS.json`：从当前 11 份历史 driver 原始输入重新流式摘取的两个完整 raw 对象，按 ID 索引。SHA256 `e94544aeae79ae363083b3cee4d9cb84ccb89811a56e60edda869d755a0dea5a`，与历史 raw_rows 的完整文件 pin 相同。未从旧测试用例反向构造。
- `CURRENT_COMPILED_ROWS.json`：当前 data/catalog.json 的两个编译 overlay。SHA256 `006ebf505dc4e0fccd0e6640954d1ab88456b5a4b7d0ccad2653bc03564c3231`。
- `CURRENT_CANONICAL_MERGED_ROWS.json`：以上 raw 与各自 overlay 的纯数据合并，可作当前 GD source_error 的标准正例。不是调用 Catalog 得到的运行结果。
- `CURRENT_INPUT_LOCATIONS.json`：11 份原始输入和当前 catalog 的完整 SHA256、字节数、card 数、ID 命中、数组索引、原文件行号及精确字节段。
- `evidence/raw.*.exact.json` 和 `evidence/compiled.*.exact.json`：原文件中对象从 `{` 到 `}` 的原字节摘取，不含对象外缩进、逗号或换行；可按记录的字节位置独立复核。

两行只在当前 catalog_raw.json 各出现一次，其余 10 个输入均没有这两个 ID，故这 11 个当前输入在初始 `{c['id']: c for c in raw}` 构造中不会覆盖这两行。此结论只到前处理之前。

位置（数组索引为零基，文件行号为一基，字节区间左闭右开）：

- raw BGS_205：index 2363，行 516748–516947，字节 18823851–18831096。
- raw TB_BaconUps_306：index 2364，行 516948–517147，字节 18831102–18838438。
- compiled BGS_205：index 3386，行 79485–79507，字节 4599927–4602310。
- compiled TB_BaconUps_306：index 3387，行 79508–79530，字节 4602316–4604715。

来源完整文件：

- data/catalog_raw.json：30,883,879 bytes，3879 cards，SHA256 `bf7cabaa5d8e6df51f25ddaef3f3edba5fdb9102d22b6a9ce2228516158a5c27`。
- data/catalog.json：4,861,565 bytes，3505 cards，SHA256 `caae174bb5ecbfdaa7ff78065c38d473908d651fd1bdb2c94c5abf83193a87b8`。

## 当前数据一致性

使用仅属于本次审计的递归比较器，区分 bool 与 number，仅允许 int/float 数值等价，得到：

1. 当前 raw 双行 = 历史 research/raw_rows = 当前 GD RAW。
2. 当前 catalog 编译双行 = 历史 expected_compiled = 当前 GD EXPECTED = 历史 Python 工具 EXPECTED。
3. 当前 GD PROGRAMS = 历史 programs.json。
4. Python 声明的三份 proof 文件全部逐字节匹配其 SHA256。raw_rows 历史 pin 也匹配，但原工具的 PROOF_SHA256 没有包含它。
5. 本地两份原生 XML 的 ID/DBF、T7、8/8 与16/16、互指普通/金色、直接圣盾/复生均匹配。TAUNT 仅 ReferencedTag，无直接 COST/CARDRACE；中文文本去标签与空白后与 raw.text 完全相同。

这些是当前文件静态事实，不是完整 driver/游戏执行或官方当前轮换证明。原生 manifest 继续限定 build225000，未联网验证整个上游响应或新的源版本。

## 最小 Python 运行依赖

历史候选工具：`research/elistra_redirect_native_recovery/candidates/tools/elistra_redirect_patterns.py`，5771 bytes，SHA256 `94f4398484c99accb054bc125f896317aa2b3e611d702119ca14d3e5a37ecefa`。当前正式 `tools/elistra_redirect_patterns.py` 仍不存在。

最小独立调用只需要：

- 工具整本及标准库 pathlib.Path、copy.deepcopy、hashlib、json。
- 一个显式 root；root 下精确三份 proof（native_source_manifest.json、两份 XML）及 raw_rows.json。
- card 参数及含两个合法 raw 对象的 cards mapping。

工具不会加载 driver、GD、Catalog、Game、Combat、programs.json 或 expected_compiled.json，也不解析 XML。ROOT 默认来自工具文件的 `__file__.parents[1]`；在 recovery candidates 原位置直接导入时，它不是当前 runtime 根。测试应显式 root，且不要把修正文件安装到正式 runtime。

原 compile_card 按 card.id 筛选，校验三份 proof，再读取 raw_rows，并逐一普通 Python `!=` 比较 cards.get(identity)。card 本身除 id 外没有独立整行绑定。返回 EXPECTED 的 deepcopy overlay，排除 id/supported/coverage_text_sha256。原实现没有异常统一转 None，也没有执行 raw_rows 的历史 hash 校验。

## 最小 GD 依赖

静态递归 preload 闭包正好是三个脚本：

- core/elistra_redirect_sources.gd → core/phase_undead_army_sources.gd。
- core/elistra_redirect_sources.gd → core/pool_identity.gd。
- core/phase_undead_army_sources.gd → core/pool_identity.gd。
- core/pool_identity.gd 没有 preload。

三个脚本都继承引擎 RefCounted。实际独立运行还需要已存在的兼容 Godot 引擎、最小 project 与测试入口，但本任务没有查找、安装或启动引擎。

GD Sources 里的 RUNTIME_PATHS 是供 Catalog 消费的执行 fingerprint 元数据，不是本脚本的 preload 清单。只测试 raw_source_error/source_error 不需要运行整套 Catalog/Game/Combat；closure_error(catalog) 另需有 get_card 的对象。Exact.same 区分 bool/number，允许 int/float 等值。source_error 要求完整 RAW+EXPECTED，唯一 pool_blocker 容许值是 PoolIdentity.MINION_REASON；compiled overlay 自身不能充当完整 source card。

当前 GD SHA256 `1ba1f47dcf21e814476fd634bf143a0e36eede3956399fb78ee377e86ca4199d`。依赖图和完整 pins 见 DEPENDENCY_GRAPH.json / SOURCE_PINS.json。

## 真实历史 hook 与完整 driver 边界

历史 after driver SHA256 `260f3d719d16e0ccc5c3c8527427a0b3e44e0ca69c61b9a6efad2f393c511ebc`；before SHA256 `f73a4864eaa5d129508c082eb1126bb7cf7a7d600f3fa6698e3e5b0e46cec8ef`。当前正式 tools/build_effect_catalog.py 不存在。关键源码逐行摘录见 evidence/HISTORICAL_DRIVER.txt。

- 134：导入 compile_card 和 SOURCE_IDS。
- 518–530：顺序加载11份 raw 输入；当前 catalog.json 仅提供 prior_catalog_ids 顺序，不作为 raw 源行输入。supplemental_missing 和 native_prize 条件存在才读取，其余输入是直接读取。
- 531：按 ID 后行整行覆盖，不是字段 merge。
- 532–535：QuestIdentity → `raw=list(cards.values())` → HeroValues → FinalSource。新 raw list 仍共享行对象，不是深拷贝。
- 545–552：confirmed catalog_value_overrides 可改写映射行。当前该文件没有 Elistra 条目。
- 当前 FinalSource 模块及其已 pin manifest 均排除 Elistra。这个局部事实不能替缺失的 QuestIdentity/HeroValues 证明，也不能推出所有其他 hook 都不改行。
- 3275–3283：清除既有 out → `c=cards.get(identity)` → `compile_elistra_redirect(c,cards,root=R)` → 非 None 时拆 metadata 并 emit → 将成功 ID 放回 ordered_ids。故真实 hook 的 card 与 cards[identity] 有调用点关联；任意 detached-card 手工调用的失败/成功不能直接冒充这个 hook 的可达输入。
- 559 emit：外部 out key/内部 id 取当时 c.id，supported=True，coverage_text_sha256 取当时 c.text。工具返回刻意不带 id/supported/coverage_text_sha256，metadata 也不重复 effects/keywords/coverage_rule。
- driver 最后会覆写 data/catalog.json 和 data/effect_coverage.json；本次没有导入或执行 driver。

AST 静态统计795个非标准库直接模块条目，当前 runtime/tools 中789个相应 .py 不存在；这只是直接本地文件存在性，并非完整 sys.path/传递依赖分析。846个把整个 cards 作为直接位置参数的 Call 站点中339个在 Elistra hook 之前；这些数不是执行次数或修改次数。前处理、hook 实际可达、之后其他 hook 改写、最终写出均未运行和验收。

## Catalog 与 save fingerprint 边界

当前 Catalog 的 Elistra RUNTIME_PATHS 参与 fingerprint，清单包含 Sources、Host、正式 Python 工具、raw_rows、programs、expected_compiled、native manifest 与两份 XML。Catalog 第1387–1388行读取路径内容并加上路径拼接 hash；2100/2104行形成整体 fingerprint，2105行保存 base_execution_fingerprint。

因此即使修正工具的合法输出与旧 overlay 相同，把新字节正式安装到被消费的工具路径仍会影响执行身份。只在本独立目录生成/测试候选，不等于改动正式路径，也不构成统一版本或存档迁移。

这是参与 fingerprint 的静态代码事实，不是原 compile_card 已校验 raw_rows pin。当前清单中正式 Python 工具缺失；未测试 Godot 对缺文件的读取/报错行为，不声称该路径必然被阻断或必然产生某值，也未计算完整游戏 fingerprint。

Game 第14131行保存 catalog.execution_fingerprint；加载先检查 room scope，14492行经 CustomShop.effective_catalog，14493行再比对存档与有效 catalog fingerprint，随后做完整 save 校验。CustomShop 可在 base fingerprint 上加房间设置。因此独立工具/GD正例通过，既不能证明旧存档兼容，也不能证明完整 Catalog 能加载、工厂能构建或战斗可运行。未读取任何存档内容，未测试旧档拒绝/迁移。

当前 Catalog 有 raw_source_error、合并 overlay 后 source_error、闭包及程序 guard；Game factory 有 source_error/closure_error。它们是静态存在的守卫，不是端到端执行证明。

## 保留原候选缺陷与封存证据

原 candidate.patch SHA256 `dda35c4a77318f8b8d7260b133d68747cd00ddd93524e974e890668ec2f2d246`。XML 尾部粘连的两个 `+\t--- /dev/null` 仍在605与686行。未修复、应用或改写 patch。

旧审查 tar.xz 只流式计算 SHA256，未解包或执行，结果 `bf2e9bf9747469d66c7caad93ef3af87512d02d3622914633189af6436833ef8`。历史 manifest 状态仍是 static_only_candidate_not_runtime_validated；EXPECTED 仍为 partial_implementation_pending_unified_validation，ordinary pool/default_pool false。

## 执行与可交付边界

仅执行新建的独立静态审计脚本，128MiB RLIMIT_AS，峰值 RSS 65,684KiB。大 raw JSON 流式解码，一次只保存一个对象。目标 Python/GD、driver、Game、Catalog、Combat 零执行；不联网、不安装、不重试任何下载。不读取私聊、凭据、缓存或旧存档，不修改正式工程或旧成果。

SOURCE_PINS.json 是本次审计实际数据/源码读入白名单；FINAL_INPUT_RECHECK.json 再次核验所有输入无变更。WHITELIST_MANIFEST.json 只列本新目录的可交付文件，不包含整源树、整输入、旧归档或任何存档。原文件精确 byte slice 已通过另一个只读小程序按记录 seek 复核。
