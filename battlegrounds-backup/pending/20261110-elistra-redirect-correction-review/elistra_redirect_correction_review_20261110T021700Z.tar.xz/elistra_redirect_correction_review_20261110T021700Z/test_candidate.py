from pathlib import Path
from copy import deepcopy
import ast,hashlib,json,resource,sys,types,shutil,collections
resource.setrlimit(resource.RLIMIT_AS,(128*1024**2,128*1024**2));sys.dont_write_bytecode=True
H=Path(__file__).resolve().parent;F='research/elistra_redirect_native_recovery/';ROOT=H/'fixture_root'
from mutations import mutate,frozen
rawdata=json.loads((H/'GD_CONSTANTS.json').read_text());RAW=rawdata['RAW'];IDS=rawdata['IDS']
paths={'original':H/'prior_snapshot/original_inputs'/F/'candidates/tools/elistra_redirect_patterns.py','candidate':H/'candidate/tools/elistra_redirect_patterns.py'}
modules={}
for name,path in paths.items():
 tree=ast.parse(path.read_text());assert all(isinstance(n,(ast.Expr,ast.Assign,ast.Import,ast.ImportFrom,ast.FunctionDef)) for n in tree.body)
 assert [n.name for n in tree.body if isinstance(n,ast.FunctionDef)]==(['compile_card'] if name=='original' else ['same','compile_card'])
 module=types.ModuleType(name);module.__file__=str(path);exec(compile(tree,str(path),'exec'),module.__dict__);modules[name]=module
 assert frozen(module.EXPECTED)==frozen(rawdata['EXPECTED'])
assert set(modules['candidate'].PROOF_SHA256)==set(modules['original'].PROOF_SHA256)|{F+'raw_rows.json'}
fixtures={p:(H/'prior_snapshot/original_inputs'/p).read_bytes() for p in modules['candidate'].PROOF_SHA256}
def reset():
 for p,b in fixtures.items():
  d=ROOT/p
  if d.is_dir():d.rmdir()
  d.write_bytes(b)
def proof_ok():
 return all((ROOT/p).is_file() and hashlib.sha256((ROOT/p).read_bytes()).hexdigest()==digest for p,digest in modules['candidate'].PROOF_SHA256.items())
driver_path=H/'prior_snapshot/original_inputs'/F/'candidates/tools/build_effect_catalog.py';driver_source=driver_path.read_text();driver=ast.parse(driver_source)
emit=next(n for n in driver.body if isinstance(n,ast.FunctionDef) and n.name=='emit')
hook=next(n for n in driver.body if isinstance(n,ast.For) and isinstance(n.iter,ast.Name) and n.iter.id=='ELISTRA_REDIRECT_IDS');pos=driver.body.index(hook);fragments=[emit,hook,*driver.body[pos+1:pos+3]]
(H/'DRIVER_EXACT_FRAGMENTS.py').write_text('\n\n'.join(ast.get_source_segment(driver_source,n) for n in fragments)+'\n');code=compile(ast.Module(body=fragments,type_ignores=[]),'exact_elistra_hook','exec')
output_pool=[];output_index={}
def intern(value):
 key=frozen(value)
 if key not in output_index:output_index[key]=len(output_pool);output_pool.append(deepcopy(value))
 return output_index[key]
results=[]
for case in json.loads((H/'CASES.json').read_text()):
 reset();identity=case['identity'];cards=deepcopy(RAW);card=deepcopy(RAW[identity]);regime=case['regime'];rows=deepcopy(RAW)
 if regime=='detached':card=mutate(card,case)
 elif regime=='coupled':cards[identity]=mutate(cards[identity],case);card=cards[identity]
 elif regime=='companion':
  target=next(i for i in IDS if i!=identity);cards[target]=mutate(cards[target],case);card=cards[identity]
 elif regime=='mapping_root':cards=mutate(cards,case)
 elif regime in ['coherent_raw_file','raw_file_only']:
  rows[identity]=mutate(rows[identity],case);(ROOT/F/'raw_rows.json').write_text(json.dumps(rows,ensure_ascii=False))
  if regime=='coherent_raw_file':cards=deepcopy(rows);card=cards[identity]
 elif regime=='bad_raw_file':
  op=case['op'];p=ROOT/F/'raw_rows.json'
  if op=='missing_raw':p.unlink()
  elif op=='malformed_json':p.write_text('{')
  elif op=='null_json':p.write_text('null')
  elif op=='list_json':p.write_text('[]')
  elif op=='raw_whitespace':p.write_bytes(p.read_bytes()+b'\n')
  elif op=='raw_json_equivalent':p.write_text(json.dumps(rows,ensure_ascii=False,separators=(',',':')))
  elif op=='raw_directory':p.unlink();p.mkdir()
  else:
   if op=='missing_identity':del rows[identity]
   elif op=='nonrow_identity':rows[identity]=None
   elif op=='array_member':rows[identity]=[]
   p.write_text(json.dumps(rows))
 elif regime=='bad_proof':
  p=ROOT/case['proof_path']
  if case['op']=='proof_changed':p.write_bytes(p.read_bytes()+b'\n')
  else:p.unlink()
 else:raise AssertionError(regime)
 before=frozen([card,cards]);record={'label':case['label'],'regime':regime,'op':case['op'],'all_four_pins_valid':proof_ok(),'versions':{}}
 for name,module in modules.items():
  error=None
  try:output=module.compile_card(card,cards,root=ROOT)
  except Exception as e:output=None;error=type(e).__name__
  assert frozen([card,cards])==before
  if output is not None:assert frozen(output)==frozen({k:v for k,v in module.EXPECTED[card['id']].items() if k not in ('id','supported','coverage_text_sha256')})
  calls=[]
  def instrument(c,all_cards,root):
   calls.append({'row_id':c.get('id') if isinstance(c,dict) else None,'loop_key':ns.get('identity'),'same_mapping_value':isinstance(all_cards,dict) and c is all_cards.get(ns.get('identity'))})
   return module.compile_card(c,all_cards,root=root)
  ns={'cards':cards,'out':{},'ordered_ids':['unrelated']+list(reversed(IDS)),'ELISTRA_REDIRECT_IDS':IDS,'compile_elistra_redirect':instrument,'hashlib':hashlib,'R':ROOT}
  hook_error=None
  try:exec(code,ns)
  except Exception as e:hook_error=type(e).__name__
  assert frozen([card,cards])==before
  record['versions'][name]={'accepted':output is not None,'error':error,'hook_accepted_ids':sorted(ns['out']),'hook_outputs_index':intern(ns['out']),'hook_error':hook_error,'hook_calls':calls}
 results.append(record)
reset()
controls=[]
for identity in IDS:
 for name,module in modules.items():
  a=module.compile_card(deepcopy(RAW[identity]),deepcopy(RAW),root=ROOT);b=module.compile_card(deepcopy(RAW[identity]),deepcopy(RAW),root=str(ROOT))
  assert frozen(a)==frozen(b);a['effects'][0]['test_extra']=True;a['conditional_support']['reason']='changed'
  assert 'test_extra' not in b['effects'][0] and b['conditional_support']==module.EXPECTED[identity]['conditional_support']
  assert b['default_pool'] is False and b['pool_supported'] is False and b['implementation_status']=='partial_implementation_pending_unified_validation'
  controls.append({'version':name,'identity':identity,'path_and_str_root_equal':True,'deepcopy_nested_independent':True,'partial_flags_preserved':True})
# Bounded default-root layout in an independent test fixture, never the current runtime.
D=H/'default_root_probe';(D/'tools').mkdir(parents=True,exist_ok=True);shutil.copyfile(paths['candidate'],D/'tools/elistra_redirect_patterns.py')
for rel,b in fixtures.items():
 p=D/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
m=types.ModuleType('default_root_probe');m.__file__=str(D/'tools/elistra_redirect_patterns.py');exec(compile((D/'tools/elistra_redirect_patterns.py').read_text(),m.__file__,'exec'),m.__dict__)
assert m.ROOT==D
for identity in IDS:assert frozen(m.compile_card(deepcopy(RAW[identity]),deepcopy(RAW)))==frozen(modules['candidate'].compile_card(deepcopy(RAW[identity]),deepcopy(RAW),root=ROOT))
# Root-type errors are newly explicit rejection behavior, not claims about GD file access.
root_controls=[]
for root in [None,0,False,[],{},H/'intentionally_missing_root']:
 try:result=modules['candidate'].compile_card(deepcopy(RAW[IDS[0]]),deepcopy(RAW),root=root);error=None
 except Exception as exc:result=None;error=type(exc).__name__
 assert result is None and error is None;root_controls.append({'root_type':type(root).__name__,'rejected_without_exception':True})
for rel,b in fixtures.items():assert (ROOT/rel).read_bytes()==b
# Preserve exact prior 262 original results, allowing only the compact output representation to differ.
prior=json.loads((H/'prior_snapshot/LEGACY_PYTHON_REPORT.json').read_text())
for new,old in zip(results[:262],prior['results']):
 r=new['versions']['original'];assert new['label']==old['label'];assert (r['accepted'],r['error'],r['hook_error'],r['hook_accepted_ids'])==(old['original_accept'],old['original_error'],old['exact_hook_error'],old['exact_hook_accepted_ids']);assert frozen(output_pool[r['hook_outputs_index']])==frozen(old['exact_hook_outputs'])
summary={'case_count':len(results),'outputs_interned_count':len(output_pool),'results':results,'hook_output_pool':output_pool,'controls':controls,'default_root_two_positives':True,'root_controls':root_controls,'legacy262_original_results_exact':True,'fixtures_reset':True,'executed_driver_nodes':[{'kind':type(n).__name__,'first':n.lineno,'last':n.end_lineno} for n in fragments],'by_regime':{},'max_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
for regime in sorted({r['regime'] for r in results}):
 group=[r for r in results if r['regime']==regime];summary['by_regime'][regime]={'cases':len(group),**{name:{'accepts':sum(r['versions'][name]['accepted'] for r in group),'exceptions':sum(r['versions'][name]['error'] is not None for r in group),'hook_exceptions':sum(r['versions'][name]['hook_error'] is not None for r in group)} for name in modules}}
(H/'PYTHON_REPORT.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n');(H/'ORIGINAL_OUTPUTS.json').write_text(json.dumps(rawdata['EXPECTED'],ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:v for k,v in summary.items() if k not in ['results','hook_output_pool']},indent=2))
