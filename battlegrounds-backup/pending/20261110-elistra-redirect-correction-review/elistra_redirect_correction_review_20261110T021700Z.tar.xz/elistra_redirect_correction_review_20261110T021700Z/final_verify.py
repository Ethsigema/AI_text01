from pathlib import Path
import hashlib,json,resource
resource.setrlimit(resource.RLIMIT_AS,(128*1024**2,128*1024**2))
H=Path(__file__).resolve().parent;W=H.parent;R=W/'historical_tools_batch14_20261109T191857Z/runtime';O=W/'elistra_redirect_readonly_probe_20261110T015700Z'
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def check(p,rec):
 p=p.resolve();assert p.is_relative_to(W.resolve());assert p.stat().st_size==rec['bytes'] and sha(p)==rec['sha256'],str(p)
pins=json.loads((H/'INPUT_PINS.json').read_text())
for rel,pin in pins.items():check(R/rel,pin);check(H/'prior_snapshot/original_inputs'/rel,pin)
for rel,pin in json.loads((O/'REPLAY_INPUTS.json').read_text()).items():check(O/rel,pin);check(H/'prior_snapshot'/rel,pin)
base=json.loads((H/'LEGACY_BASELINE_PIN.json').read_text());check(W/base['path'],base);check(H/'prior_snapshot/LEGACY_PYTHON_REPORT.json',base)
static=json.loads((H/'static_current_inputs/SOURCE_PINS.json').read_text())
for pin in static.values():check(Path(pin['path']),pin)
review_path=H/'review_independent/WHITELIST_MANIFEST.json';assert review_path.exists()
review=json.loads(review_path.read_text())['input_allowlist']
for rel,pin in review.items():check(Path(rel),pin)
old=json.loads((O/'FINAL_VERIFICATION.json').read_text())['old_archives'];old[O.name+'.tar.xz']='bf2e9bf9747469d66c7caad93ef3af87512d02d3622914633189af6436833ef8'
for rel,digest in old.items():assert sha(W/rel)==digest
replay=json.loads((H/'REPLAY_INPUTS.json').read_text())
for rel,pin in replay.items():check(H/rel,pin)
assert sha(R.parent/'SOURCE_MAP.json')=='7fec8d69e82de8bfcb7373549951f9456671b5c3980135d6ec6f983a3daf5ed7'
scope=json.loads((W/'historical_tools_batch15_20261109T195018Z/REMAINING_SCOPE.json').read_text())['remaining_targets'];assert len(scope)==345 and 'tools/elistra_redirect_patterns.py' in scope;assert all(not (R/p).exists() for p in scope)
assert not (R/'evidence/portable_legacy/CardDefs.Bacon_latest.xml').exists()
manifest=json.loads((H/'CANDIDATE_MANIFEST.json').read_text());assert sha(H/'candidate/tools/elistra_redirect_patterns.py')==manifest['candidate_sha256'];assert sha(R/'core/elistra_redirect_sources.gd')==manifest['current_gd_sha256']
r={'status':'SELECTED_SOURCES_PRIOR_SNAPSHOTS_AND_OLD_ARCHIVES_UNCHANGED','runtime_input_records':len(pins),'static_source_records':len(static),'independent_review_input_records':len(review),'replay_inputs':len(replay),'old_archives':old,'remaining_tools_missing':345,'xml_candidate_not_installed':True,'new_candidate_installed':False,'full_tree_rehash_claim':False,'no_game_full_driver_combat_or_save_run':True,'network_attempted':False,'max_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
(H/'FINAL_VERIFICATION.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
