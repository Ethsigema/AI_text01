"""Preparation only until explicitly invoked after parent freeze. No Game/upload."""
from common import *
import argparse,tarfile,io,shutil,subprocess

def main():
 assert STATUS != "UNSET_PENDING_STAGE_DECISION" and REMOTE_FOLDER != "UNSET_PENDING_STAGE_DECISION", "Stage scope/folder/status not approved; do not build or restore a new candidate"
 ap=argparse.ArgumentParser(description=__doc__)
 ap.add_argument('--freeze-confirmed',action='store_true',required=True)
 ap.add_argument('--reconstruction-note',type=Path,required=True)
 ap.add_argument('--output',type=Path,required=True)
 args=ap.parse_args();out=args.output.resolve();source=ROOT.parent/'candidate'
 assert not out.exists() and not out.is_relative_to(source)
 assert args.reconstruction_note.is_file()
 recovery=json.loads((ROOT/'CURRENT_INPUTS_VERIFIED.json').read_text())
 assert recovery['status']=='PASS_FRESH_DEPENDENCIES_METADATA_ONLY_NO_BASE_OR_ACCEPTED_MINI_RESTORE'
 base_bytes=gzip.decompress((ROOT/'base_package/SOURCE_MAP.json.gz').read_bytes());base=json.loads(base_bytes)
 assert sha(base_bytes)=='7fec8d69e82de8bfcb7373549951f9456671b5c3980135d6ec6f983a3daf5ed7'
 old=json.loads((ROOT/'ACCEPTED_MINI_SOURCE_MAP.json').read_text())
 assert sha(dump(old))=='378619e4219a4f394b972d79c79e9e173c86abd562e3e4cba00f453bcc07bb9e'
 target,aggregate=scan(source);assert target
 # Do not silently omit caches or files from a claimed complete frozen source tree.
 assert not any(n.startswith('.godot/') for n in target),'Freeze a cache-free source tree first'
 changed={n:v for n,v in target.items() if base.get(n)!=v};removed=sorted(set(base)-set(target))
 out.mkdir(parents=True)
 with tarfile.open(out/'delta.tar.xz','w:xz') as t:
  for n,v in sorted(changed.items()):
   b=(source/n).read_bytes();assert {'bytes':len(b),'sha256':sha(b)}==v,n
   member=tarfile.TarInfo(n);member.size=len(b);member.mode=0o644;member.mtime=0;t.addfile(member,io.BytesIO(b))
 delta=(out/'delta.tar.xz').read_bytes()
 with (out/'SOURCE_MAP.json.gz').open('xb') as f:f.write(gzip.compress(dump(target),mtime=0))
 write(out/'CHANGES_FROM_ACCEPTED_MINI.json',{'previous_commit':PREVIOUS_COMMIT,'added':{n:v for n,v in target.items() if n not in old},'modified':{n:{'before':old[n],'after':v} for n,v in target.items() if n in old and old[n]!=v},'removed':{n:old[n] for n in sorted(set(old)-set(target))}})
 for n in ['CURRENT_INPUTS_VERIFIED.json','CURRENT_EVIDENCE_VERIFIED.json','FRESH_DOWNLOAD_VERIFIED.json','ACCEPTED_MINI_PREIMAGE_METADATA_VERIFIED.json']:
  shutil.copyfile(ROOT/n,out/n)
 shutil.copyfile(args.reconstruction_note,out/'RECONSTRUCTION_NOTE.md')
 shutil.copyfile(ROOT/'accepted_mini_package/restore_increment.py',out/'restore_increment.py')
 shutil.copyfile(ROOT/'snapshot_tools/restore_low_disk.py',out/'restore_low_disk.py')
 manifest={'format_version':1,'status':STATUS,'created_at_utc':utc(),'remote_folder':REMOTE_FOLDER,'base_content_commit':BASE_COMMIT,'base_folder':'battlegrounds-backup/consolidated/20261111-batch14-restored','base_map_sha256':sha(base_bytes),'source_map_sha256':sha(dump(target)),'aggregate_sha256':aggregate,'source_files':len(target),'source_bytes':sum(v['bytes'] for v in target.values()),'archive':'delta.tar.xz','archive_bytes':len(delta),'archive_sha256':sha(delta),'changed_files':changed,'removed':removed,'previous_candidate_commit':PREVIOUS_COMMIT,'previous_source_commit':'610cad09b7d19fe2615201f054a68c6e1a31d79d','previous_gameplay_accepted':True,'scope':'Finite native sale of one ordinary Lava after its first native Mini permanent buff in the same turn; retired buffed history denies further Lava buy/play for that owner; live Mini continues Waiting next turn. Existing native permanence/sale algorithms are not new.','original_worktree_recovered':False,'unknown_unuploaded_tier5_recovered':False,'full_scope_acceptance':False,'gameplay_tests_run_for_this_snapshot':False,'historical_discovery_is_acceptance':False,'old_backups_preserved':True,'note':'Unaccepted buffed ordinary Lava native-sale candidate from accepted limited source610cad0/final838043a. Cumulative over batch14, not layered over predecessor. Prior gameplay does not accept this candidate.'}
 write(out/'MANIFEST.json',manifest)
 verify(source,target,aggregate) # Source must still equal freeze after package assembly.
 with tarfile.open(out/'delta.tar.xz','r:xz') as t:
  members={}
  for x in t:
   assert x.isfile() and safe(x.name) and x.name not in members
   b=t.extractfile(x).read();members[x.name]={'bytes':len(b),'sha256':sha(b)}
  assert members==changed
 write(out/'BUILD_VERIFIED.json',{'status':'PASS_FROZEN_BYTES_AND_ARCHIVE_ONLY_NOT_GAME_ACCEPTANCE','created_at_utc':utc(),'source_map_sha256':manifest['source_map_sha256'],'aggregate_sha256':aggregate,'source_files':len(target),'source_bytes':manifest['source_bytes'],'game_started':False,'uploads':0})
 (out/'RECOVERY.md').write_text(f"""# 普通Lava首次永久增益后原生出售 未验收累积候选恢复

状态：{STATUS}。固定前像source610cad09b7d19fe2615201f054a68c6e1a31d79d、有限回执838043a91d995a93bf916846e960465ee05966e7。新范围仅单个普通原Lava在同回合获原Mini首次永久buff后原生sell；该owner的buffed退休历史继续拒绝Lava buy/play，Mini活源下轮继续Waiting。不新增原生永久或出售算法，不开放额外Mini/Lava/金色或任意token，不带入失败空位链，不代表全scope验收。全部旧备份、输入、最终恢复树、失败证据与日志保留；仅明确授权且全SHA证明冗余的工作/中间依赖树已清理，记录另存。

## 输入准备
需要 Python 3.12+。低盘工具使用fcntl，仅支持Linux/macOS；传统双树路线需额外空间。以下命令从一个新工作目录执行。运行恢复所必需的依赖仅原Release、固定batch14全部24项和本候选包；本阶段下载的已接受有限Mini证据最终30项用于前像/历史证据核验，并非运行恢复的依赖。

1. 下载原始Release为 `original_release.zip`：
https://github.com/Ethsigema/AI_text01/releases/download/battlegrounds-handoff-20261101/battlegrounds_new_scope_handoff_20261101.zip
大小324,041,102字节；SHA256 `33b3a1a12185cf9035cec33da4fff7008c7680194eb045b37234fbb934803d65`。

2. 下载固定batch14目录全部24文件到 `base_package/`，保持文件名：
https://github.com/Ethsigema/AI_text01/tree/{BASE_COMMIT}/battlegrounds-backup/consolidated/20261111-batch14-restored
必须有restore.py、MANIFEST.json、SOURCE_MAP.json.gz、BASE_MEMBERS.json.gz及13片payload.tar.xz.part0000至part0012。

3. 从同一固定提交下载本候选目录全部文件到 `mini_package/`。目录为 `{REMOTE_FOLDER}`，首次源码提交号以发布回执为准。不要混用不同提交的MANIFEST、delta或校验清单。证据包不是源码，不要解进工程。

## 推荐低空间完整恢复（新单树路线）
本批新工具restore_low_disk.py与传统restore_increment.py并存，不改旧恢复器。
低盘路线从不存在的新工作目录开始，在其中先实际恢复完整batch14并逐文件核验checkpoint，再在同一新树应用已完整验证的累积增量并两次全量核验。不会修改任何旧base/restored_snapshot/candidate。
```sh
touch common.lock
python3 mini_package/restore_low_disk.py --execute --base-package base_package --release original_release.zip --candidate-package mini_package --new-workspace fresh_single_restore --lock-file common.lock
```
首次独立恢复可按上例创建新工作目录内的common.lock；同一工作流所有恢复和Game进程必须复用此共同锁，不可用不同锁绕过互斥。fresh_single_restore必须不存在，其父目录必须已存在；失败保留FAILED_RESTORE.json和当前状态，不自动删除/重试。成功报告SINGLE_TREE_RESTORE_VERIFIED.json，工程在fresh_single_restore/restored_snapshot/project.godot。外置HOME/缓存/日志直接测试此树并测试前后全SHA，不另复制runtime树；只能称一棵独立远端恢复/测试树，不能称双恢复树。保留本批实际55项下载的证据；实际恢复最低依赖仍是原Release+batch14全部24项+本候选，不需已接受有限Mini证据最终30项。

### 本批远端工具布局与runner参数
固定提交下载协调器将新恢复工作目录置于remote_snapshot_<commit>/single_tree_restore，因此源码在remote_snapshot_<commit>/single_tree_restore/restored_snapshot，不在package旁边。下载包仍在remote_snapshot_<commit>/package，独立恢复总回执在remote_snapshot_<commit>/INDEPENDENT_RESTORE_VERIFIED.json。
后续runner必须显式传入 `--package remote_snapshot_<commit>/package --restore-report remote_snapshot_<commit>/INDEPENDENT_RESTORE_VERIFIED.json --output remote_snapshot_<commit>`，并用其对应源码参数指定 `remote_snapshot_<commit>/single_tree_restore/restored_snapshot`；不能依赖默认siblings推断。此为路径约束，不是声称runner已执行或默认参数已适配。

## 传统双树完整恢复（额外空间）
```sh
printf '%s\\n' '33b3a1a12185cf9035cec33da4fff7008c7680194eb045b37234fbb934803d65  original_release.zip' | sha256sum -c -
(cd base_package && sha256sum -c SHA256SUMS.txt)
(cd mini_package && sha256sum -c SHA256SUMS.txt)
python3 base_package/restore.py --base-zip original_release.zip --destination restored_batch14 --report BASE_RESTORE.json
python3 mini_package/restore_increment.py --base-tree restored_batch14 --base-map base_package/SOURCE_MAP.json.gz --destination restored_mini --report MINI_RESTORE.json
```
两个输出目录和两个报告必须不存在。**本包是相对batch14的累积增量，直接叠batch14，不能叠前像610cad0、首次失败517、旧Lava、Tier6或空位候选。** 不需要逐层叠历史包，也不能只解增量当完整工程。

两个恢复器实际重新读取每个文件，验证完整路径集、长度和SHA256；输入SHA256SUMS只校验包文件，不能替代源码恢复核验。基线应报告PASS_ACTUAL_DISK_RESTORE_EVERY_FILE_REHASHED（27,920文件、1,549,340,406字节）。候选应报告PASS_INCREMENT_RESTORED_AND_EVERY_FILE_REHASHED，{len(target):,}文件、{manifest['source_bytes']:,}字节；missing/extra/mismatched均为空。

完整每文件SHA/大小见解压后的SOURCE_MAP.json.gz。解压地图内容SHA256：`{manifest['source_map_sha256']}`。
聚合SHA256：`{aggregate}`；MINI_RESTORE.json的aggregate_sha256必须一致。

工程入口 `restored_mini/project.godot`，对应Godot 4.6.3。本批实际采用一棵独立fresh restore/runtime树，外置HOME/缓存/日志并测试前后逐文件全SHA，不另复制运行树；传统双树命令仅提供额外空间下的可选恢复方式。恢复成功仅证明字节可重建；真实玩法验收必须另有固定来源的实际测试回执。若包内附带证据归档，按相邻成员清单逐项验证，不把历史成绩算作本候选通过。
""")
 (out/'SHA256SUMS.txt').write_text(''.join(sha(p.read_bytes())+'  '+p.name+'\n' for p in sorted(out.iterdir()) if p.is_file()))
 print(json.dumps({'status':STATUS,'output':str(out),'files':len(target),'source_map_sha256':manifest['source_map_sha256'],'aggregate_sha256':aggregate}))
if __name__=='__main__':main()
