# Count correction only

The frozen pure source cc17 has44 static checks, not43: eight singleton checks, six fake-game calls, and30 range/variant checks. Earlier README/V1/V2 metadata contain the counting mistake and remain byte-for-byte unchanged. Use V3_COUNT_CORRECTION for the corrected static expectation; actual count awaits execution. No test assertion or code was changed to fit a count. All frozen source/test files and archives remain untouched.

Real multiplicity: trident3 and original_mini_token3 (initial, cast helper, replacement); one next_round and each opponent-ready once. This addendum is static review, not a gameplay receipt.
