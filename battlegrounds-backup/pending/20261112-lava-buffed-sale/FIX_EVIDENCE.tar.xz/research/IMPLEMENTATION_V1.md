# Buffed Lava native sale, unaccepted V1

Base source610cad09b7d19fe2615201f054a68c6e1a31d79d. Two overlay files only; immutable trees untouched. No full copy, Game, repin or upload.

New finite window: same round as first native Mini cast, certified Lava mini_steps=1, kept=1, current mini_round. Original live Mini and unique original consumed token must pass existing consumed_sale_error (issued registry, original owner/source/token, completed earlier cast sequence, absence in all zones). Token targetUID must match this Lava. No pending Mini/host issue/cast/reset/expiry/EOT windows or waiting tickets. Existing full owner/body/stock and original sale operation checks remain.

Native Game._return_unit iterates Magnetic.pool_returns and increments pool by pool_id/count; it does not insert a buffed entity into a pool. This overlay never changes the native gold/pool or permanent-buff arithmetic. Full pool/spell_pool strict integer receipts remain, only Lava base ID +1, gold/sold +1, UID/RNG unchanged. Buffed branch additionally checks strict full remaining board/hand, unchanged departed source values and original token registry refs/facts. Success does not reset the detached body's stats or manufacture a fresh card.

On actual captured departure, original Lava authority is erased and retired UID marked mini_buffed=true even after partial native failure. This is revocation, not success certification. Existing original failure is preserved; no refund or replay. Owner-bound history blocks future Lava play AND purchase, including after Mini later departs. Untouched Lava retirements lack marker and retain old finite rebuy behavior.

Next recruit Mini grant is already source-bound, not target-bound: Mini remains authenticated and Waiting may create original new Trident; casting without an actual certified Lava is still rejected. Need one actual nonempty combat/next-recruit test to verify this path. No claim of tested behavior yet. Do not replace actual history with fixture dictionaries as authorization.

API: buffed_sale_error(host,game,p,u)->String; buffed_sale_history(p)->bool inspects local issued retirement history and only denies. Existing sale_preflight/begin_sale/finish_sale unchanged signatures. Helper check-only exited0 in isolated HOME/all XDG; integrated Host parse remains parent step. No pure/Game run here.
