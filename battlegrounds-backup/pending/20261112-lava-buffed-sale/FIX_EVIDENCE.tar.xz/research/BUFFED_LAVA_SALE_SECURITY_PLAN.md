# 单次永久+2 Lava出售：独立只读边界

基线610cad09固定恢复树。未改源码、未运行Game、未复制工程。新分支仅实际普通Lava本轮接受唯一原Mini原票第一次+2后4/5 kept1出售；不扩大多buff、第二Mini、golden、其它目标或新购买。

## 最小真实授权

保留现Lava.sale_preflight的actual ownedGame/helper、recruit/无活动窗、retired上限、owner_error、board_error、严格会计/stock条件。仅将mini_steps存在即held改成一个完整认证分支：原Lava私有record同对象/owner/engine，mini_steps严格1、mini_round本轮、snapshot严格4/5 kept1；对应Mini稳定_board原source仍alive认证、未退休、同owner；唯一该source本轮原_tokens记录已ready+used未expired，原token/snapshot/registry键一致、cast_target_uid为该Lava，cast_sequence早于当前公开sale，原token全zones消失。原cast完成凭据必须来自已有complete，不准复制字段或浅shape发证。

## 退休与会计

仍用原native sale operation8字段/plan原引用及值，完整原body后无条件finish。实际离场先撤销Lava _board许可并退休UID；失败不rollback、不返还或重新写buff。成功仍唯一stock+1/gold+1/sold+1、原hand及其它board对象/值不变、UID/RNG不变。新增分支须保存并核Mini source/issued记录原引用和事实不变，不能售中清used或再发票。只在完整成功后记录成功结果，部分失败不能授予后续能力。

pool本身只存数量，不存已buff实体；原_return_unit加库存不应把u/base_unit塞回池。证明“无永久buff泄入pool”应以原数值库存/原body无新实体与旧UID退休为基础，不假装已实际验证新的rebuy。

## owner与后续票

当前Host.owner_error逐项认证现board，Mini.board_error不要求Lava常驻，因此售后Mini仍可保持原custody。下一轮原Waiting可从alive Mini发新token；无Lava board对象时cast_preflight应因真实目标不存在而held，不删除合法issued票或伪造新目标。reset只遍历现zones、Lava记录已退休，应不尝试对售出对象续写reset。

## rebuy隐藏交互

只依赖“Mini仍在board”阻止Lava购买不足以维持边界：下一轮新readytoken入手后，Mini可走已有持票sale分支离场，随后board仅parents会再次满足旧Lava buy门槛。因此若本批明确不放buffed出售后的rebuy，应保存该owner的真实buffed退休历史，并在live购买投影前拒绝该历史；不得通过删Mini或换新UID绕过。旧untouched售出/重购不应被全局一刀切held。退休历史只作限制，不能成为影子/新实体权限。

## 只需有限证据

实战仅原Mini/Lava/暗潮→真实首cast→public sell Lava→一次非空combat/下一招募Mini实际再发新token、无目标cast消费前拒，记录源/票未被sale改写。纯负例cover copied/wrongowner/未完成cast/旧轮/多步buff/kept0/未用票/source退休/partial sale/rebuy历史绕过。不要为证明pool数值另外扩成实际buffed rebuy流程。

目前为设计审查，尚无新实现冻结通过结论。
