# First permanent buff then original Lava departure

Draft only, no Game/source edits. Baseline610cad0 is read-only; old files remain unchanged. Canonical new tests/darkcrest_lava_buffed_sale_20261112.

One new actual room, original seed20261120 and unchanged public acquisition fixture. Original Mini real Waiting→original Trident publicfirstcast→same ordinary Lava4/5 kept1→publicsellLava. Native deltas gold/pool/sold+1 only; source object leaves every zone, original Lava registry retires, UID/RNG/spellpool unchanged, Mini original board receipt not retired and token refs/history retained. Inventory remains strict scalar counts, not objects carrying buffs. SameGame native factory preview after sale must2/5kept0 without allocating UID; this is shape/no-leak evidence, NOT an actual rebuy or fresh shop offer.

One real nonempty combat/recruit: Mini present, Lava absent, Darkcrest2. Still-live Mini genuinely issues a fresh distinct token. With no Lava target, public cast on original Mini rejects without consuming token or mutating full live state. SecondMini/golden/additionalbuff/other targets/buffedLava rebuy remain outside scope. Native partial-failure injection not exercised. Coin factory/add_hand/publiccast remains explicit pre-source fixture.

Important inherited test conflict: old permanent cast_first ends by asserting buffed Lava sale held. This new test overrides that helper and preserves all other old cast verification, removing only the obsolete public sell negative so it cannot sell Lava prematurely. Old test source remains unchanged. No old full matrix initializer runs.

Producer final API and rebuy-history fence pending. Pure content checks will target finite first-buff departure and consumed-token/Lava receipt correspondence, but will not forge native successful receipts. Real retirement and provenance remain public-flow evidence only.
