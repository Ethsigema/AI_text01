# Buffed ordinary Lava sale draft

One new Game only, inherits latest helpers but overrides initializer and cast_first to avoid the obsolete buffed-sale-held command. All original positive cast and negative token/target checks remain. Old test files untouched. Source610cad0 baseline only, not new acceptance.

True public Mini Waiting issuance, first permanent cast2/5→4/5, public Lava sale, strict native accounting and original Lava retirement; original Mini stays alive and issues another real token after one actual nonempty combat/recruit. New token cannot be cast with no Lava; a public wrong-target command must reject without state mutation. Source Darkcrest reaches2 independently.

The local originalfactory preview2/5 after sale proves no buffed factory content and does not allocate UID, but is not actual rebuy evidence. BuffedLava rebuy, golden, secondMini, multiple buffs, other targets and default/fullgame acceptance remain held/unverified. No native failure injection. All funding is disclosed pre-source Coin fixture. No old fullGame repeated.

Producer pure API/finite rebuy fence still pending; this is an unfinished test draft, not a pass or final frozen artifact. No Game or full-tree copy performed by this task.

## API-aligned finite history guard

Production actual buffed_sale_error authenticates first-current buff via original Mini consumed history and original Lava receipt. New pure static43 checks cover owner-bound _retired mini_buffed denial-content and fake/unbound authority refusal; fake records are deliberately isolated and cannot prove a native sale. Deep malformed mini_steps/currentround/kept/casttarget actual branches are not reached by fake early rejection and are not claimed as live fault coverage.

Real sale creates original owner-bound mini_buffed history, observed directly. SameGame buy/play gates return exact buffed_rebuy/reentry held before any actual shop/hand transaction; check preserves full state and persists after next recruit. This is a real recorded-history gate observation, NOT an actual shop buy attempt or proof of the longer Mini-also-sold chain. No actual buffedLava rebuy performed. The invariant remains production guard/static-review responsibility beyond this finite trajectory.
