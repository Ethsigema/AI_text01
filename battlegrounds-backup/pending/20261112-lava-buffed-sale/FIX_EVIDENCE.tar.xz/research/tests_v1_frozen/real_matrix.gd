extends "res://tests/darkcrest_mini_after_cast_20261112/real_matrix.gd"
# One new buffed-Lava sale scenario; no old initializer or obsolete sale-held assertion.
var buffed_sale={}
func cast_first(mini: Dictionary,lava: Dictionary,parent: Dictionary,expected_attack: int) -> bool:
 var p=game.state.players[0];var spell=trident()
 if spell.is_empty():return false
 if not original_mini_token(spell,mini) or not token_negative_checks(spell,mini,lava):return false
 if not must(spell.is_spellcraft and spell.temporary and spell.expires_at_end_turn and lava.spellcraft_kept==0,"real_temporary_spell_and_reset_lava_before_cast"):return false
 # Real wrong-target request is held before hand consumption; no target is forged.
 if not rejected_public({"type":"play","index":p.hand.find(spell),"target":p.board.find(parent),"target_zone":"board","position":-1},"other_original_board_target_held_no_consumption"):return false
 var uid=game.next_uid;var rng=game.rng.state;var pool=game.pool.duplicate(true);var spell_pool=game.spell_pool.duplicate(true);var stats=p.stats.spells
 var old= lava.attack;var parent_values=parent.duplicate(true);var mini_values=mini.duplicate(true)
 var parent_record=game._darkcrest_host._parents[parent.uid];var parent_record_values=parent_record.duplicate(true)
 if not must(command(0,{"type":"play","index":p.hand.find(spell),"target":p.board.find(lava),"target_zone":"board","position":-1}).get("ok",false),"public_native_first_trident_cast"):return false
 if not must(p.board.any(func(u):return is_same(u,lava)) and lava.attack==expected_attack and lava.attack==old+2 and lava.health==5 and lava.max_health==5 and lava.spellcraft_kept==1 and lava.temporary_buffs.is_empty(),"first_trident_permanent_exact_plus2_kept1_no_temporary_layer"):return false
 if not must(not p.hand.any(func(u):return is_same(u,spell) or u.uid==spell.uid) and p.stats.spells==stats+1 and game.next_uid==uid and game.rng.state==rng and game.Darkcrest.Sources.same(pool,game.pool) and game.Darkcrest.Sources.same(spell_pool,game.spell_pool),"cast_consumes_original_token_only_no_factory_rng_stock"):return false
 if not must(game.Darkcrest.Sources.same(parent_values,parent) and game.Darkcrest.Sources.same(mini_values,mini) and is_same(game._darkcrest_host._parents[parent.uid],parent_record) and game.Darkcrest.Sources.same(parent_record_values,parent_record),"mini_cast_does_not_consume_darkcrest_growth_or_source_state"):return false
 var helper=game._darkcrest_host._mini
 if not must(helper._tokens[spell.uid].used==true and helper._cast.is_empty() and helper._poison.is_empty() and game._darkcrest_host._lava_play._board[lava.uid].mini_steps==mini_casts.size()+1,"actual_completed_cast_updates_only_observer_receipt"):return false
 var after=live_snapshot()
 if not must(not helper.token_error(game._darkcrest_host,game,p,spell).is_empty() and game.Darkcrest.Sources.same(after,live_snapshot()),"used_original_token_replay_rejected_without_mutation"):return false
 mini_casts.append({"round":game.state.round,"source_uid":mini.uid,"token_uid":spell.uid,"target_uid":lava.uid,"attack_before":old,"attack_after":lava.attack,"health":lava.health,"kept":lava.spellcraft_kept});return true
func sell_buffed_lava(lava: Dictionary,mini: Dictionary) -> bool:
 var p=game.state.players[0];var h=game._darkcrest_host;var helper=h._lava_play
 var before=live_snapshot()
 if not must(helper.sale_preflight(h,game,p,lava).is_empty(),"original_buffed_lava_sale_preflight"):return false
 if not must(not helper.sale_preflight(h,game,p,lava.duplicate(true)).is_empty() and not helper.sale_preflight(h,game,game.state.players[1],lava).is_empty(),"copied_wrongowner_buffed_lava_sale_refused"):return false
 if not must(not helper.begin_sale(h,game,p,p.board.find(lava),{}).is_empty() and h.Sources.same(before,live_snapshot()),"unbound_buffed_lava_sale_preserves_state"):return false
 var board=p.board.duplicate();var values=p.board.duplicate(true);var hand=p.hand.duplicate();var hand_values=p.hand.duplicate(true)
 var gold=p.gold;var sold=p.stats.sold;var pool=game.pool.duplicate(true);var spell_pool=game.spell_pool.duplicate(true);var uid=game.next_uid;var rng=game.rng.state;var seed=game.rng.seed
 var mini_record=h._mini._board;var mini_values=mini.duplicate(true);var token_refs=h._mini._tokens.duplicate(false);var token_facts={}
 for key in token_refs:token_facts[key]=h.Mini.token_facts(token_refs[key])
 var index=p.board.find(lava);var sale_round=game.state.round;var sale_sequence=game.state.command_sequence;var old_stats={"attack":lava.attack,"health":lava.health,"kept":lava.spellcraft_kept}
 if not must(command(0,{"type":"sell","index":index}).get("ok",false),"public_native_buffed_lava_sell"):return false
 board.remove_at(index);values.remove_at(index);pool[LAVA]+=1
 if not must(h.Generation._same_objects(board,p.board) and h.purchase_value_same(values,p.board) and h.Generation._same_objects(hand,p.hand) and h.purchase_value_same(hand_values,p.hand),"buffed_sale_only_original_board_departure"):return false
 if not must(p.gold==gold+1 and p.stats.sold==sold+1 and h.LavaPlay._sale_inventory_matches(game.pool,pool) and h.LavaPlay._sale_inventory_matches(game.spell_pool,spell_pool),"buffed_sale_exact_native_accounting"):return false
 if not must(game.next_uid==uid and game.rng.state==rng and game.rng.seed==seed and absent_from_all_zones(lava),"buffed_sale_no_uid_rng_and_original_absent"):return false
 var expected_retired={"owner":p.id,"round":sale_round,"sequence":sale_sequence};expected_retired.mini_buffed=true
 if not must(not helper._board.has(lava.uid) and helper._retired.has(lava.uid) and h.purchase_value_same(helper._retired[lava.uid],expected_retired) and helper._sale_pending.is_empty(),"buffed_lava_authority_retired"):return false
 if not must(is_same(h._mini._board,mini_record) and not mini_record.get("retired",false) and h.purchase_value_same(mini_values,mini) and h._mini.board_error(h,game,p,mini).is_empty(),"live_mini_not_retired_by_lava_sale"):return false
 for key in token_refs:
  if not must(is_same(h._mini._tokens.get(key),token_refs[key]) and h.purchase_value_same(h.Mini.token_facts(h._mini._tokens[key]),token_facts[key]),"mini_token_record_reference_survives_lava_sale"):return false
 var before_preview=live_snapshot()
 var native_preview=game._preview_native_minion(cat.get_card(LAVA),"u"+str(game.next_uid))
 if not must(native_preview.attack==2 and native_preview.health==5 and native_preview.spellcraft_kept==0 and game.next_uid==uid and game.rng.state==rng and h.LavaPlay._sale_inventory_matches(game.pool,pool) and h.Sources.same(before_preview,live_snapshot()),"buffed_stats_do_not_leak_to_native_factory_preview"):return false
 var gate_before=live_snapshot()
 if not must(helper.buffed_sale_history(p) and not helper.buffed_sale_history(game.state.players[1]),"actual_buffed_retirement_history_owner_bound"):return false
 if not must(h.lava_purchase_error(game,p,native_preview)=="darkcrest_lava_buffed_rebuy_held" and helper.preflight(h,game,p,native_preview)=="darkcrest_lava_buffed_reentry_held","actual_retirement_history_blocks_buy_and_play_gate"):return false
 if not must(h.Sources.same(gate_before,live_snapshot()),"history_gate_checks_do_not_change_live_state"):return false
 var after=live_snapshot()
 if not must(not helper.sale_preflight(h,game,p,lava).is_empty() and not helper.board_error(h,game,p,lava).is_empty() and h.Sources.same(after,live_snapshot()),"retired_buffed_lava_replay_refused_no_mutation"):return false
 buffed_sale={"lava_uid":lava.uid,"mini_uid":mini.uid,"index":index,"retirement":helper._retired[lava.uid].duplicate(true),"departed_stats":old_stats,"gold_before":gold,"gold_after":p.gold,"sold_before":sold,"sold_after":p.stats.sold,"stock_before":pool[LAVA]-1,"stock_after":game.pool[LAVA],"uid_before":uid,"uid_after":game.next_uid,"rng_before":rng,"rng_after":game.rng.state,"native_preview_attack":native_preview.attack,"native_preview_health":native_preview.health,"preview_not_actual_rebuy":true,"owner_bound_history_gate_observed":true,"actual_shop_buy_attempted":false}
 return true
func buffed_lava_case() -> bool:
 var setup=prepare_room()
 if setup.is_empty():return false
 var mini=setup.mini;var lava=setup.lava;var parent=setup.parent;var p=game.state.players[0]
 if not public_lava_play(lava,0):return false
 if not must(command(0,{"type":"play","index":p.hand.find(mini),"target":-1,"position":1}).get("ok",false),"original_mini_publicplay_real_waiting_grant"):return false
 var token=trident()
 if token.is_empty() or not original_mini_token(token,mini):return false
 if not cast_first(mini,lava,parent,4) or not sell_buffed_lava(lava,mini) or not prepare_real_opponents():return false
 if not next_round(parent,2):return false
 var matches=game.last_combats.filter(func(c):return c.get("left_player")==0 or c.get("right_player")==0)
 if not must(matches.size()==1 and matches[0].get("error","")=="","one_nonempty_post_lava_sale_combat"):return false
 var combat=matches[0];var side="left" if combat.left_player==0 else "right";var enemy="right" if side=="left" else "left"
 var starts=combat.log.filter(func(e):return e.get("event")=="combat_start")
 if not must(starts.size()==1 and not starts[0][enemy].is_empty() and starts[0][side].any(func(u):return u.uid==mini.uid) and not starts[0][side].any(func(u):return u.uid==lava.uid),"actual_combat_mini_present_lava_absent"):return false
 var history_before=live_snapshot()
 if not must(game._darkcrest_host._lava_play.buffed_sale_history(p) and game._darkcrest_host.lava_purchase_error(game,p,lava)=="darkcrest_lava_buffed_rebuy_held" and game.Darkcrest.Sources.same(history_before,live_snapshot()),"buffed_history_buy_gate_persists_next_round"):return false
 var replacement=trident()
 if replacement.is_empty() or not original_mini_token(replacement,mini):return false
 if not must(replacement.uid!=token.uid and not is_same(replacement,token) and absent_from_all_zones(lava),"live_mini_native_regrant_without_lava"):return false
 if not rejected_public({"type":"play","index":p.hand.find(replacement),"target":p.board.find(mini),"target_zone":"board","position":-1},"no_lava_new_token_cast_held_without_consumption"):return false
 var result={"scope":"one ordinary Lava first Mini permanent buff then native sale with live Mini regrant","seed":20261120,"checks":checks,"sale":buffed_sale,"casts":mini_casts,"darkcrest_uid":parent.uid,"darkcrest_final_tier":2,"mini_uid":mini.uid,"old_token_uid":token.uid,"new_token_uid":replacement.uid,"combat_start":starts[0],"native_preview_diagnostic":native_preview_diagnostic,"acquisitions":acquisition,"coin_pre_source_fixture":true,"entirely_natural_game":false,"actual_lava_rebuy_tested":false,"old_full_matrix_repeated":false}
 var file=FileAccess.open(get_script().resource_path.get_base_dir()+"/DARKCREST_LAVA_BUFFED_SALE_MATRIX_RESULT.json",FileAccess.WRITE)
 if not must(file!=null,"matrix_result_file"):return false
 file.store_string(JSON.stringify(result,"  ")+"\n");file.close();return true
func _initialize():
 print("DARKCREST_LAVA_BUFFED_SALE_MATRIX_LOAD_BEGIN")
 var Game=load("res://core/game.gd")
 if not must(Game!=null and Game.can_instantiate(),"complete_game_script"):return
 cat=load("res://core/catalog.gd").new();cat.load_catalog()
 if not must(cat.load_errors.is_empty(),"complete_catalog"):return
 if not buffed_lava_case():return
 print("DARKCREST_LAVA_BUFFED_SALE_REAL_MATRIX_PASS cases=1 casts=1 combats=1 checks=",checks)
 quit(0)
