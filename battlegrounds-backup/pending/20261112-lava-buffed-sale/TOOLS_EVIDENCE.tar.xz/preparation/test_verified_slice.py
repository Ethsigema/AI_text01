"""Synthetic renderer assertions. No Game, files copied to runtime, or publication."""
from copy import deepcopy
import json
from render_verified_slice import render_slice,runner
from test_lava_buffed_sale_schema_synthetic import fixture
labels=[x[0] for x in runner.TESTS];commit='a'*40;row,_,n=fixture();checks=[]
s={'source_commit':commit,'runtime_mode':runner.RUNTIME_MODE,'two_runtime_copies':False,'status':'TESTS_VALIDATED_SOURCE_INTEGRITY_PASS','error':None,'validated_tests':labels}
a={'source_commit':commit,'runtime_mode':runner.RUNTIME_MODE,'two_runtime_copies':False,'runner_suite_accepted':True,'status':'PASS_POST_ATTEMPT_SOURCE_AND_EVIDENCE_AUDIT','tests':{k:{'classification':'executed_validated','process_started':True,'revalidated_checks':v if v else n} for k,_,_,v in runner.TESTS}}
f={'source_commit':commit,'status':runner.FINAL_STATUS,'tests':{k:{'passed_checks':v} for k,_,_,v in runner.TESTS},'full_game_processes':1,'full_game_acceptance':False,'default_pool_promoted':False,'old_full_matrices_repeated':False};f['tests'][labels[0]]={'passed_checks':n,'verified_scenario_fields':row}
text=render_slice(s,a,f,row,commit)
for label,condition in [('dynamic_Game_plus44_plus3248',str(n+44+3248) in text),('acquisition_level_not_minion_tier','暗潮的获取牌等级推进至2（不是随从星级变化）' in text and '暗潮成长至2级' not in text),('active_not_global','active 暗潮路径' in text and '不是 inactive/off-Darkcrest' in text),('history_gate_not_shop_or_reverse_live_chain','不是实际商店重买挑战' in text and '未实测Mini后来离场' in text),('old43_not_actual_failed_run','43只是静态误计' in text and '不是实际测试失败' in text),('lost_initial_package_honestly_disclosed','db9a67c' in text and '原封装字节丢失' in text and '不能声称所有unique产物都保留' in text),('V2_guard_not_confirmed_V1_vulnerability','callee既有检查已存在' in text),('same_round_not_hard_round1','不是代码硬限制为round 1' in text),('no_unused_expiry_claim','售后未用token到期' in text)]:
 assert condition,label;checks.append(label)
for label,mutate in [('wrong_new_pure',lambda x:x[2]['tests'][labels[1]].update(passed_checks=43)),('wrong_commit',lambda x:x[0].update(source_commit='b'*40)),('old_full_repeated',lambda x:x[2].update(old_full_matrices_repeated=True)),('actual_rebuy_claim',lambda x:x[3].update(actual_lava_rebuy_tested=True)),('shop_attempt_claim',lambda x:x[3]['sale'].update(actual_shop_buy_attempted=True)),('missing_history_gate',lambda x:x[3]['sale'].update(owner_bound_history_gate_observed=False)),('buffed_factory_pollution',lambda x:x[3]['sale'].update(native_preview_attack=4)),('second_cast',lambda x:x[3]['casts'].append(deepcopy(x[3]['casts'][0]))),('wrong_retirement_owner',lambda x:x[3]['sale']['retirement'].update(owner=1))]:
 x=deepcopy([s,a,f,row]);mutate(x)
 try:render_slice(*x,commit)
 except (AssertionError,ValueError):checks.append(label)
 else:raise AssertionError('accepted '+label)
fs={**s,'status':'FAILED_OR_INCOMPLETE_ATTEMPT','error':'synthetic failure','validated_tests':[]};fa={**a,'runner_suite_accepted':False,'status':'FAIL_POST_ATTEMPT_AUDIT','tests':{k:{'classification':'omitted','process_started':False} for k in labels}};fa['tests'][labels[0]]={'classification':'process_failed','process_started':True}
text=render_slice(fs,fa,None,None,commit);assert '12 份纯合同全部未运行' in text;checks.append('first_full_failure_twelve_not_run')
x=deepcopy(fa);x['tests'][labels[0]]={'classification':'executed_validated','process_started':True,'revalidated_checks':n};x['tests'][labels[1]]={'classification':'process_failed','process_started':True}
text=render_slice(fs,x,None,None,commit);assert '明确未启动 11 项' in text and '12 份纯合同全部未运行' not in text;checks.append('new_pure_failure_eleven_not_run')
x=deepcopy(fa);x['tests'][labels[0]]={'classification':'launch_or_execution_without_completion_receipt','process_started':None};text=render_slice(fs,x,None,None,commit);assert '待确认 1 项' in text and '确认启动 0 项' in text;checks.append('uncertain_not_claimed_started')
print(json.dumps({'status':'PASS_SYNTHETIC_RENDERER_ONLY','passed':len(checks),'checks':checks,'game_started':False,'package_created':False,'actual_Game_count_not_inferred':True},indent=2))
