"""Only test fail-closed unknown success and honest failure classifications."""
import copy,json
from render_verified_slice import render_slice,ACQUISITION_LEVEL_WORDING,runner
labels=[x[0] for x in runner.TESTS];commit='a'*40;checks=[]
s={'source_commit':commit,'runtime_mode':runner.RUNTIME_MODE,'two_runtime_copies':False,'status':'FAILED_OR_INCOMPLETE_ATTEMPT','error':'synthetic failure','validated_tests':[]}
a={'source_commit':commit,'runtime_mode':runner.RUNTIME_MODE,'two_runtime_copies':False,'runner_suite_accepted':False,'status':'FAIL_POST_ATTEMPT_AUDIT','tests':{k:{'classification':'omitted','process_started':False} for k in labels}}
a['tests'][labels[0]]={'classification':'process_failed','process_started':True}
text=render_slice(s,a,None,None,commit);assert '12 份纯合同全部未运行' in text and '既有11份纯合同3248项' in text;checks.append('first_full_failure_exactly_twelve_pure_not_run')
x=copy.deepcopy(a);x['tests'][labels[0]]={'classification':'executed_validated','process_started':True,'revalidated_checks':100};x['tests'][labels[1]]={'classification':'process_failed','process_started':True}
text=render_slice(s,x,None,None,commit);assert '明确未启动 11 项' in text and '12 份纯合同全部未运行' not in text;checks.append('new_pure_failure_eleven_old_pure_not_run')
x=copy.deepcopy(a);x['tests'][labels[0]]={'classification':'launch_or_execution_without_completion_receipt','process_started':None}
text=render_slice(s,x,None,None,commit);assert '待确认 1 项' in text and '确认启动 0 项' in text;checks.append('uncertain_not_claimed_executed')
ss={**s,'status':'TESTS_VALIDATED_SOURCE_INTEGRITY_PASS','error':None,'validated_tests':labels};aa={**a,'runner_suite_accepted':True,'status':'PASS_POST_ATTEMPT_SOURCE_AND_EVIDENCE_AUDIT','tests':{k:{'classification':'executed_validated'} for k in labels}};f={'source_commit':commit,'status':runner.FINAL_STATUS,'tests':{k:{} for k in labels},'full_game_processes':1,'full_game_acceptance':False,'default_pool_promoted':False,'old_full_matrices_repeated':False}
try:render_slice(ss,aa,f,{},commit)
except ValueError:checks.append('unknown_success_schema_refuses_acceptance')
else:raise AssertionError('unknown success accepted')
assert '获取牌等级推进' in ACQUISITION_LEVEL_WORDING and '不是随从星级变化' in ACQUISITION_LEVEL_WORDING;checks.append('corrected_acquisition_level_semantics_retained')
print(json.dumps({'status':'PASS_SYNTHETIC_PENDING_RENDERER_ONLY','passed':len(checks),'checks':checks,'game_started':False,'package_created':False},indent=2))
