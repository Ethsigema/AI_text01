"""One explicitly requested new pure contract only, no Game. Never overwrite an attempt.

Full candidate bytes are scanned before and after any process attempt, including
failure/timeout. HOME/XDG/logs live in a unique external evidence directory.
"""
from pathlib import Path
import argparse,fcntl,os,re,subprocess,time
import pre_freeze_buffed_sale_support_v2 as r

PURE_SOURCE='tests/darkcrest_lava_buffed_sale_20261112/content_contract.gd'
PURE_SHA='cc17f6c1210165e314dce1ce1a7bf427c0c037c864b1ce2c81cce4f45d40d0fe'
EXPECTED_CHECKS=44

def main():
 ap=argparse.ArgumentParser(description=__doc__)
 ap.add_argument('--execute',action='store_true',required=True)
 ap.add_argument('--attempt-id',required=True,help='Fresh lower-case identifier; existing evidence is never replaced')
 a=ap.parse_args();r.require(re.fullmatch(r'[a-z0-9][a-z0-9_]{0,63}',a.attempt_id) is not None,'Safe fresh attempt identifier required')
 stage=Path(__file__).resolve().parent.parent;candidate=stage/'candidate';root=stage/'evidence';root.mkdir(exist_ok=True)
 attempt=root/('pre_freeze_pure_'+a.attempt_id)
 lock_path=stage.parent/'develop_empty_ghost_20261112/.independent_full_game.lock'
 with lock_path.open('a') as guard:
  fcntl.flock(guard,fcntl.LOCK_EX|fcntl.LOCK_NB)
  r.require(not attempt.exists(),'Attempt already exists; choose a new --attempt-id without altering evidence')
  attempt.mkdir();before={};before_info={};after={};after_info={};process=None;error=None;validated=None
  reason='not_started';started=r.utc();t=time.monotonic();peak=0;limit=0;command=[]
  log_path=attempt/'pure.log'
  try:
   before_info,before=r.scan_tree(candidate,{},'BASELINE_DISCOVERY_ONLY')
   before_info={key:value for key,value in before_info.items() if key not in ['matches','missing','extra','mismatched']}
   before_info['scan_mode']='complete_pre_process_baseline_without_prior_expected_map'
   r.write_new(attempt/'BEFORE_SOURCE_MAP.json',before)
   r.require(before.get(PURE_SOURCE,{}).get('sha256')==PURE_SHA,'Frozen new pure script is missing or changed')
   env=os.environ.copy()
   for key,name in [('HOME','home'),('XDG_CACHE_HOME','cache'),('XDG_CONFIG_HOME','config'),('XDG_DATA_HOME','data')]:
    destination=attempt/name;destination.mkdir();env[key]=str(destination)
   available=int(next(line.split()[1] for line in Path('/proc/meminfo').read_text().splitlines() if line.startswith('MemAvailable:')))*1024
   limit=min(4*1024**3,available//2);r.require(limit>=512*1024**2,'Insufficient memory for guarded pure contract')
   command=['godot','--headless','--path',str(candidate),'--script','res://'+PURE_SOURCE]
   r.write_new(attempt/'LAUNCH_INTENT.json',{'command':command,'source':PURE_SOURCE,'source_sha256':PURE_SHA,
    'source_files':len(before),'source_bytes':before_info['bytes'],'source_map_sha256':r.sha((attempt/'BEFORE_SOURCE_MAP.json').read_bytes()),
    'aggregate_sha256':before_info['aggregate_sha256'],'static_expected_checks':EXPECTED_CHECKS,'timeout_seconds':180,'rss_soft_limit':limit,'game_started':False})
   with log_path.open('x') as log:
    process=subprocess.Popen(command,stdout=log,stderr=subprocess.STDOUT,env=env,start_new_session=True);reason='exited'
    r.write_new(attempt/'STARTED.json',{'pid':process.pid,'command':command,'started_at_utc':r.utc(),'godot_started':True,'game_started':False})
    while process.poll() is None:
     rss=r.rss_for_group(process.pid);peak=max(peak,rss)
     if rss>limit or time.monotonic()-t>180:
      reason='rss_soft_limit' if rss>limit else 'timeout';r.stop(process);break
     time.sleep(.1)
   r.require(process.wait()==0 and reason=='exited','Pure process did not exit successfully')
   previous=r.NEW_TEST_METADATA['pure_checks']
   try:
    # This local expected-count check cannot modify formal runner configuration.
    r.NEW_TEST_METADATA['pure_checks']=EXPECTED_CHECKS
    count,_=r.validate('lava_buffed_sale_content_contract',log_path.read_text(),EXPECTED_CHECKS,attempt)
    validated={'passed':count,'failed':0,'scope':r.BUFFED_SALE_PURE_SCOPE,'real_game_run':False,'actual_provenance_proven':False}
   finally:r.NEW_TEST_METADATA['pure_checks']=previous
  except BaseException as exc:
   error=repr(exc)
   if process is not None and reason=='exited' and process.poll() is None:reason='runner_interrupted'
  finally:
   if process is not None:r.stop(process)
   try:
    after_info,after=r.scan_tree(candidate,before,before_info.get('aggregate_sha256','UNKNOWN'))
    r.write_new(attempt/'AFTER_SOURCE_MAP.json',after)
   except Exception as exc:
    after_info={'matches':False,'error':repr(exc)}
    if error is None:error='Post-pure source scan: '+repr(exc)
   unchanged=bool(before) and after==before and after_info.get('aggregate_sha256')==before_info.get('aggregate_sha256')
   if not unchanged and error is None:error='Candidate source changed or could not be fully rehashed'
   success=error is None and validated is not None and unchanged
   report={'status':'PASS_PURE_ONLY_NO_GAME' if success else 'FAIL_PURE_OR_SOURCE_INTEGRITY','attempt_id':a.attempt_id,
    'started':started,'elapsed':time.monotonic()-t,'command':command,'process_started':process is not None,
    'godot_started':process is not None,'game_started':False,'exit':process.returncode if process is not None else None,
    'reason':reason,'error':error,'log_sha256':r.sha(log_path.read_bytes()) if log_path.exists() else None,
    'source_files':len(before),'source_bytes':before_info.get('bytes'),'source_map_sha256':r.sha((attempt/'BEFORE_SOURCE_MAP.json').read_bytes()) if before else None,
    'aggregate_sha256':before_info.get('aggregate_sha256'),'before_after_identical':unchanged,'summary':[validated] if validated else [],
    'before_tree':before_info,'after_tree':after_info,'static_expected_checks':EXPECTED_CHECKS,'sampled_peak_rss':peak,'rss_soft_limit':limit,
    'memory_enforcement':'sampled process-group soft limit, not a cgroup hard cap','timeout_seconds':180,'formal_Game_acceptance':False}
   r.write_new(attempt/'PURE_VERIFIED.json',report)
   print(r.dump(report).decode(),end='')
  if not success:raise SystemExit(1)

if __name__=='__main__':main()
