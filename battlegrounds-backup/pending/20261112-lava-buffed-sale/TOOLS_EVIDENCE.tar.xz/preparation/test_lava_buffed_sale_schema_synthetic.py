"""Detached synthetic JSON/log validators only, not Game or fabricated live entities."""
from pathlib import Path
from copy import deepcopy
import json,tempfile
import run_remote_lava_buffed_sale as r

def rejected(fn,label):
 try:fn()
 except (ValueError,AssertionError,KeyError,TypeError,FileNotFoundError,StopIteration):return label
 raise AssertionError('Accepted synthetic negative '+label)

def fixture(round_number=1):
 diagnostic={'native_factory_preview':True,'actual_token_issuance':False,'uid_allocated':False,'zone_inserted':False,'shape_error':'','key_types':[{'key':k,'key_type':v[0],'value_type':v[1]} for k,v in r.NATIVE_PREVIEW_TOP_TYPES.items()],'base_key_types':[{'key':k,'key_type':v[0],'value_type':v[1]} for k,v in r.NATIVE_PREVIEW_BASE_TYPES.items()]}
 passes=['PASS '+k for k,n in r.BUFFED_SALE_FULL_MARKERS.items() for _ in range(n)]+['PASS public_darkcrest_play_u30','PASS native_eot_combat_next_recruit_'+str(round_number),'PASS native_growth_exact_once_'+str(round_number),'PASS synthetic_dynamic_funding_observation']
 ordered=['PASS '+k for k in r.buffed_sale_ordered_markers(round_number)]+['PASS matrix_result_file'];passes=[k for k in passes if k not in ordered]+ordered;n=len(passes)
 unit=lambda uid,card:{'uid':uid,'card_id':card,'kind':'minion','golden':False,'attack':2,'health':5,'max_health':5}
 row={'scope':r.BUFFED_SALE_SCOPE,'seed':20261120,'checks':n-1,'native_preview_diagnostic':diagnostic,'acquisitions':[{'id':'BG23_000','uid':'u10','rolls':80,'source_owned':False},{'id':'BG23_009','uid':'u20','rolls':100,'source_owned':False}],
 'sale':{'lava_uid':'u20','mini_uid':'u10','index':0,'retirement':{'owner':0,'round':round_number,'sequence':20,'mini_buffed':True},'departed_stats':{'attack':4,'health':5,'kept':1},'gold_before':5,'gold_after':6,'sold_before':0,'sold_after':1,'stock_before':14,'stock_after':15,'uid_before':50,'uid_after':50,'rng_before':-1234,'rng_after':-1234,'native_preview_attack':2,'native_preview_health':5,'preview_not_actual_rebuy':True,'owner_bound_history_gate_observed':True,'actual_shop_buy_attempted':False},
 'casts':[{'round':round_number,'source_uid':'u10','token_uid':'u40','target_uid':'u20','attack_before':2,'attack_after':4,'health':5,'kept':1}],
 'darkcrest_uid':'u30','darkcrest_final_tier':2,'mini_uid':'u10','old_token_uid':'u40','new_token_uid':'u80','combat_start':{'event':'combat_start','sequence':0,'seed':-123,'rules':'sandbox-1','sort_formation_contract':'actual_combat_start_before_start_effects_v1','round_up_plain_contract':'','left':[unit('u10','BG23_000'),unit('u30','BG31_920')],'right':[unit('u60','BG23_000')],'left_hand_count':1,'right_hand_count':0,'left_hand_summon_locks':[],'right_hand_summon_locks':[]},'coin_pre_source_fixture':True,'entirely_natural_game':False,'actual_lava_rebuy_tested':False,'old_full_matrix_repeated':False}
 log='DARKCREST_LAVA_BUFFED_SALE_MATRIX_LOAD_BEGIN\nMINI_NATIVE_PREVIEW_KEY_TYPES '+json.dumps(diagnostic)+'\n'+'\n'.join(passes)+'\nDARKCREST_LAVA_BUFFED_SALE_REAL_MATRIX_PASS cases=1 casts=1 combats=1 checks='+str(n)+'\n'
 return row,log,n

def main():
 checks=[];ready=r.NEW_VALIDATORS_READY;count=r.NEW_TEST_METADATA['pure_checks'];r.NEW_VALIDATORS_READY=True;r.NEW_TEST_METADATA['pure_checks']=44
 row,log,n=fixture()
 with tempfile.TemporaryDirectory(prefix='buffed_sale_synthetic_',dir=Path(__file__).parent) as tmp:
  root=Path(tmp);path=root/r.NEW_TEST_METADATA['scenario_file']
  def full(value,text=log):path.write_text(json.dumps(value));return r.validate('lava_buffed_sale_real_matrix',text,None,root)
  assert full(row)==(n,row);checks.append('synthetic_frozen_real_schema_NOT_GAME')
  later,laterlog,nn=fixture(3);assert full(later,laterlog)==(nn,later);checks.append('same_positive_round_not_hardcoded_round1')
  mutations=[(['checks'],n,'pre_file_count'),(['checks'],True,'integer_not_bool'),(['seed'],1,'seed'),(['scope'],'global native game','global_scope'),(['darkcrest_final_tier'],5,'acquisition_level_not_minion_tier'),(['coin_pre_source_fixture'],False,'fixture_disclosure'),(['entirely_natural_game'],True,'natural_claim'),(['actual_lava_rebuy_tested'],True,'actual_rebuy_not_tested'),(['old_full_matrix_repeated'],True,'old_full_not_repeated'),(['new_token_uid'],'u40','no_token_reuse'),(['old_token_uid'],'u10','token_not_body'),(['sale','mini_uid'],'u30','live_original_mini'),(['sale','lava_uid'],'u10','sold_original_lava'),(['sale','index'],1,'sold_original_position'),(['sale','gold_after'],5,'gold_delta'),(['sale','stock_after'],14,'stock_delta'),(['sale','sold_after'],0,'sale_counter'),(['sale','uid_after'],51,'no_uid_allocation'),(['sale','rng_after'],8,'no_rng_change'),(['sale','native_preview_attack'],4,'no_buff_pollution'),(['sale','native_preview_health'],6,'native_preview_health'),(['sale','preview_not_actual_rebuy'],False,'preview_not_rebuy'),(['sale','owner_bound_history_gate_observed'],False,'history_gate_observed'),(['sale','actual_shop_buy_attempted'],True,'not_actual_shop_challenge'),(['sale','retirement','owner'],1,'owner_bound'),(['sale','retirement','owner'],False,'owner_int'),(['sale','retirement','round'],0,'positive_round'),(['sale','retirement','sequence'],0,'native_sequence'),(['sale','retirement','mini_buffed'],False,'buffed_retirement'),(['sale','departed_stats','attack'],6,'single_buff'),(['sale','departed_stats','kept'],0,'kept1_before_sale'),(['casts',0,'round'],2,'same_round'),(['casts',0,'target_uid'],'u30','original_lava_target'),(['casts',0,'source_uid'],'u30','original_mini_cast_source'),(['casts',0,'token_uid'],'u42','original_consumed_token'),(['casts',0,'attack_after'],6,'only_one_cast'),(['casts',0,'health'],6,'lava_health'),(['acquisitions',0,'rolls'],81,'bounded_mini_roll'),(['acquisitions',1,'source_owned'],True,'pre_source_acquisition'),(['combat_start','event'],'combat_end','native_combat_event'),(['combat_start','left'],[],'own_side_nonempty'),(['combat_start','right'],[],'enemy_nonempty'),(['combat_start','left',0,'golden'],True,'ordinary_mini_only'),(['combat_start','left',0,'uid'],'u20','lava_absent'),(['combat_start','left',1,'card_id'],'BG36_508','correct_darkcrest_id'),(['combat_start','sequence'],False,'native_event_strict_integer')]
  for keys,value,label in mutations:
   bad=deepcopy(row);target=bad
   for k in keys[:-1]:target=target[k]
   target[keys[-1]]=value;checks.append(rejected(lambda:full(bad),label))
  for field in row:
   bad=deepcopy(row);bad.pop(field);checks.append(rejected(lambda:full(bad),'missing_root_'+field))
  for field in row['sale']:
   bad=deepcopy(row);bad['sale'].pop(field);checks.append(rejected(lambda:full(bad),'missing_sale_'+field))
  bad=deepcopy(row);bad['casts'].append(deepcopy(bad['casts'][0]));checks.append(rejected(lambda:full(bad),'second_cast'))
  bad=deepcopy(row);bad['global_rebuy_block']=True;checks.append(rejected(lambda:full(bad),'extra_unproven_scope_key'))
  for text,label in [(log+'PASS extra\n','pass_count'),(log.replace('casts=1','casts=2'),'two_cast_marker'),(log.replace('PASS original_live_mini_required_before_buffed_sale','PASS missing'),'live_mini_gate_marker'),(log.replace('PASS original_waiting_token_bound_to_exact_mini_owner_round','PASS missing'),'issuance_three_times'),(log+'SCRIPT ERROR: synthetic\n','engine_error')]:checks.append(rejected(lambda:full(row,text),label))
  reverse=log.replace('PASS public_native_first_trident_cast','PASS TEMP').replace('PASS public_native_buffed_lava_sell','PASS public_native_first_trident_cast').replace('PASS TEMP','PASS public_native_buffed_lava_sell');checks.append(rejected(lambda:full(row,reverse),'cast_then_sale_order'))
  lines=['PASS '+k for k,v in r.BUFFED_SALE_PURE_MARKERS.items() for _ in range(v)]+['PASS '+k+str(i) for k,v in r.BUFFED_SALE_PURE_PREFIX_COUNTS.items() for i in range(v)];assert len(lines)==44
  summary={'passed':44,'failed':0,'failures':[],'real_game_run':False,'actual_provenance_proven':False,'scope':r.BUFFED_SALE_PURE_SCOPE}
  def plog(value):return '\n'.join(lines)+'\nDARKCREST_LAVA_BUFFED_SALE_CONTENT_CONTRACT '+json.dumps(value)+'\n'
  assert r.validate('lava_buffed_sale_content_contract',plog(summary),44,root)==(44,None);checks.append('synthetic_pure44_shape_not_actual_run')
  for key,value in [('passed',43),('failed',True),('real_game_run',True),('actual_provenance_proven',True),('scope','real native retirement authority')]:
   bad=dict(summary);bad[key]=value;checks.append(rejected(lambda:r.validate('lava_buffed_sale_content_contract',plog(bad),44,root),'pure_bad_'+key))
  checks.append(rejected(lambda:r.validate('lava_buffed_sale_content_contract',plog(summary).replace(lines[0]+'\n','',1),44,root),'missing_pure_marker'))
  r.NEW_TEST_METADATA['pure_checks']=None;checks.append(rejected(lambda:r.validate('lava_buffed_sale_content_contract',plog(summary),44,root),'UNKNOWN_actual_count_refuses'))
 r.NEW_TEST_METADATA['pure_checks']=count;r.NEW_VALIDATORS_READY=ready
 print(json.dumps({'status':'PASS_SYNTHETIC_BUFFED_SALE_SCHEMA_NOT_GAMEPLAY','checks':len(checks),'labels':checks,'game_started':False,'godot_started':False,'actual_count_not_inferred':True},indent=2))
if __name__=='__main__':main()
