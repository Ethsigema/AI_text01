"""Small synthetic Python validator tests. No Godot, Catalog, Game, or real source-tree scan."""
from pathlib import Path
import hashlib
import json
import tempfile
from run_remote_lava_buffed_sale import (validate, require_frozen, verify_tree, scan_tree,
    validate_source_map, validate_paths, dump, TESTS, sha, write_new, NEW_TEST_METADATA, validate_restore_receipt)
from audit_lava_buffed_sale_attempt import classify_attempt
import run_remote_lava_buffed_sale as runner


def rejected(fn, label):
    try: fn()
    except (ValueError, AssertionError, KeyError, FileNotFoundError, TypeError): return label
    raise AssertionError('Validator accepted negative case: ' + label)


def main():
    passed=[]
    # UNKNOWN is a hard refusal, not an implicit success or fallback to old validators.
    prior_status=NEW_TEST_METADATA['status'];NEW_TEST_METADATA['status']='UNKNOWN_SYNTHETIC_NEGATIVE'
    try:passed.append(rejected(require_frozen, 'unknown_new_metadata_fails_closed'))
    finally:NEW_TEST_METADATA['status']=prior_status
    prior_map=runner.FROZEN_SOURCE['source_map_sha256'];runner.FROZEN_SOURCE['source_map_sha256']='UNKNOWN_SYNTHETIC_NEGATIVE'
    try:passed.append(rejected(require_frozen, 'unknown_source_map_fails_closed'))
    finally:runner.FROZEN_SOURCE['source_map_sha256']=prior_map
    NEW_TEST_METADATA['status']='FROZEN_REVIEWED';prior_ready=runner.NEW_VALIDATORS_READY;runner.NEW_VALIDATORS_READY=False
    try:passed.append(rejected(require_frozen, 'metadata_status_alone_cannot_enable_unknown_validators'))
    finally:NEW_TEST_METADATA['status']=prior_status;runner.NEW_VALIDATORS_READY=prior_ready
    assert len(TESTS)==13 and TESTS[0][2]==3600 and all(row[2]==180 for row in TESTS[1:])
    assert [row[3] for row in TESTS[2:]]==[85,102,344,89,140,211,966,810,68,166,267]
    assert all('real_matrix' not in row[1] for row in TESTS[2:])
    passed.append('one_new_full_and_new_pure_plus_exact_eleven_old_pure_only')
    with tempfile.TemporaryDirectory(prefix='permanent_synthetic_', dir=Path(__file__).parent) as temp:
        root=Path(temp)
        # Wrong/unknown fixed source commits must stop before touching a package.
        wrong_commit='a'*40 if runner.FROZEN_SOURCE_COMMIT!='a'*40 else 'b'*40
        try:
            runner.verify_package(root/'absent_package',root/'restore.json',root/'download.json',
                wrong_commit,'b'*64,'c'*64,root/'restored_snapshot')
        except ValueError as exc:
            assert str(exc)=='Source commit is not the reviewed published freeze'
        else:raise AssertionError('Unknown/unpinned commit accepted')
        passed.append('unknown_or_wrong_fixed_source_commit_refused_before_package_access')
        passed.append(rejected(lambda:validate('unknown_contract','',None,root),'unknown_label_refused'))
        passed.append(rejected(lambda:validate('lava_buffed_sale_real_matrix','UNTRUSTED_NEW_FULL_PASS cases=1 checks=1\nPASS fake\n',None,root),'fabricated_full_pass_without_scenario_refused'))
        passed.append(rejected(lambda:validate('lava_buffed_sale_content_contract','',None,root),'empty_pure_refused'))
        passed.append(rejected(lambda:validate('source_eot_contract','DARKCREST_SOURCE_EOT_CONTRACT passed=68 failed=0\n',68,root),'old_summary_without_pass_lines_refused'))
        passed.append(rejected(lambda:validate('source_eot_contract','PASS fake\nERROR: bad\nDARKCREST_SOURCE_EOT_CONTRACT passed=68 failed=0\n',68,root),'error_marker_refused'))
        bad={'passed':140,'failed':0,'failures':[],'scope':'detached sale context and authority rejection observations only','real_game_run':False,'live_capacity_tested':True,'partial_failure_live_injection':False}
        log=('PASS x\n'*140)+'DARKCREST_LAVA_SALE_CONTENT_CONTRACT '+json.dumps(bad)+'\n'
        passed.append(rejected(lambda:validate('lava_sale_content_contract',log,140,root),'old_sale_wrong_semantic_claim_refused'))
        passed.append(rejected(lambda:validate_source_map({'../escape':{'bytes':1,'sha256':'a'*64}},{'source_files':1,'source_bytes':1}),'unsafe_source_map_refused'))
        passed.append(rejected(lambda:validate_source_map({'x':{'bytes':True,'sha256':'a'*64}},{'source_files':1,'source_bytes':1}),'boolean_byte_count_refused'))
        a=root/'candidate';b=root/'restored_snapshot';a.mkdir();b.mkdir();(a/'x').write_bytes(b'original');(b/'x').write_bytes(b'original')
        # Exact single-tree restore contract, using only small synthetic metadata.
        restore={'status':'PASS_REMOTE_UNACCEPTED_SINGLE_TREE_SOURCE_RESTORE_BYTES_ONLY',
                 'source_commit':'a'*40,'source_map_sha256':'b'*64,'restored_tree':str(b),
                 'fresh_base_checkpoint_then_single_target_tree':True,'separate_runtime_copy_created':False,
                 'game_started':False,'gameplay_acceptance':False,
                 'restored':{'aggregate_sha256':'c'*64,'files':1,'bytes':8,'missing':[],'extra':[],'mismatched':[]}}
        def valid_restore(value):validate_restore_receipt(value,b,'a'*40,'b'*64,'c'*64,1,8)
        valid_restore(restore);passed.append('exact_single_tree_restore_metadata_positive')
        for field,bad,label in [
            ('status','PASS_REMOTE_UNACCEPTED_SOURCE_RESTORE_BYTES_ONLY','old_restore_status_refused'),
            ('fresh_base_checkpoint_then_single_target_tree',False,'missing_fresh_base_checkpoint_refused'),
            ('separate_runtime_copy_created',True,'separate_runtime_copy_refused'),
            ('restored_tree',str(a),'wrong_exact_restored_tree_path_refused')]:
            wrong=dict(restore);wrong[field]=bad
            passed.append(rejected(lambda:valid_restore(wrong),label))
        payload=b'original';expected={'x':{'bytes':len(payload),'sha256':sha(payload)}}
        agg=hashlib.sha256(b'x\0'+str(len(payload)).encode()+b'\0'+payload).hexdigest()
        require_a,_=verify_tree(a,expected,agg)
        assert require_a['matches'] is True
        passed.append('synthetic_full_source_scan_positive_not_gameplay')
        (b/'x').write_bytes(b'changed')
        observed,_=scan_tree(b,expected,agg);assert observed['matches'] is False and observed['mismatched']==['x']
        passed.append(rejected(lambda:verify_tree(b,expected,agg),'changed_source_refused'))
        passed.append(rejected(lambda:validate_paths(a,a,root),'same_source_roots_refused'))
        evidence=root/'independent_tests';evidence.mkdir()
        first=TESTS[0][0];(evidence/(first+'_STARTED.json')).write_text('{}');(evidence/(first+'.log')).write_text('started but no result')
        second=TESTS[1][0];write_new(evidence/(second+'_result.json'),{'process_started':True,'source_commit':'wrong'})
        third=TESTS[2][0];write_new(evidence/(third+'_PRECHECK.json'),{})
        rows,errors=classify_attempt(evidence,{}, {'source_commit':'a'*40}, b,{})
        assert rows[first]['classification']=='launch_or_execution_without_completion_receipt'
        assert rows[second]['classification']=='executed_validation_or_evidence_failed'
        assert rows[third]['classification']=='preflight_only_not_started'
        assert rows[TESTS[3][0]]['classification']=='omitted' and errors
        passed.append('audit_failure_preserves_executed_uncertain_preflight_and_omitted')
        # Positive/negative process classifications require complete synthetic
        # evidence, not real Godot output or a changed real source tree.
        bindings={'source_commit':'a'*40,'aggregate_sha256':'d'*64}
        source_map={source:{'bytes':1,'sha256':sha(b'x')} for _,source,_,_ in TESTS}
        prepared={}
        def receipt_for(index,process_started,exit_code,reason,log=''):
            label,source,budget,_=TESTS[index]
            wrapper=evidence/(label+'.gd');wrapper.write_text('synthetic external wrapper only\n')
            prepared[wrapper.name]={'bytes':wrapper.stat().st_size,'sha256':sha(wrapper.read_bytes())}
            log_path=evidence/(label+'.log');log_path.write_text(log)
            map_path=evidence/(label+'_source_map.json');write_new(map_path,source_map)
            tree={'matches':True,'aggregate_sha256':bindings['aggregate_sha256'],'missing':[],'extra':[],'mismatched':[]}
            precheck={**bindings,'runtime_tree':str(b),'source':source,'runtime_mode':runner.RUNTIME_MODE,
                      'source_map_file':map_path.name,'observed_source_map_sha256':sha(map_path.read_bytes()),'tree':tree}
            write_new(evidence/(label+'_PRECHECK.json'),precheck)
            command=['godot','--headless','--path',str(b),'--script',str(wrapper)]
            result={**bindings,'process_started':process_started,'source':source,'runtime_mode':runner.RUNTIME_MODE,
                    'source_sha256':source_map[source]['sha256'],'command':command,'wrapper_sha256':prepared[wrapper.name]['sha256'],
                    'log_sha256':sha(log_path.read_bytes()),'start_tree':tree,'source_snapshot_matches':True,
                    'timeout_seconds':budget,'rss_soft_limit':512*1024**2,'exit':exit_code,'reason':reason,
                    'started_at_utc':'2026-11-12T00:00:00+00:00','finished_at_utc':'2026-11-12T00:00:00+00:00'}
            write_new(evidence/(label+'_result.json'),result)
            if process_started:write_new(evidence/(label+'_STARTED.json'),{**bindings,'command':command})
            return result
        receipt_for(4,True,1,'exited','FAIL synthetic intentional process failure\n')
        receipt_for(5,False,None,'launch_failed')
        source_index=[x[0] for x in TESTS].index('source_eot_contract')
        label=TESTS[source_index][0]
        valid=receipt_for(source_index,True,0,'exited','PASS synthetic\n'*68+'DARKCREST_SOURCE_EOT_CONTRACT passed=68 failed=0\n')
        write_new(evidence/(label+'_VALIDATED.json'),{'result':valid,'result_sha256':sha((evidence/(label+'_result.json')).read_bytes()),
                  'passed_checks':68,'log_sha256':valid['log_sha256'],'failures':[]})
        rows,errors=classify_attempt(evidence,source_map,bindings,b,prepared)
        assert rows[TESTS[4][0]]['classification']=='process_failed'
        assert rows[TESTS[5][0]]['classification']=='launch_failed_not_executed'
        assert rows[label]['classification']=='executed_validated' and rows[label]['revalidated_checks']==68
        assert rows[TESTS[3][0]]['classification']=='omitted' and errors
        passed.extend(['synthetic_process_failure_is_executed_not_omitted','synthetic_launch_failure_is_not_executed',
                       'synthetic_legacy_log_revalidation_positive_not_gameplay','other_failures_never_promote_omitted_tests'])
        evidence=root/'first_full_failed_only';evidence.mkdir();prepared={}
        receipt_for(0,True,1,'exited','FAIL synthetic first full Game failure\n')
        rows,errors=classify_attempt(evidence,source_map,bindings,b,prepared)
        assert rows[TESTS[0][0]]['classification']=='process_failed'
        assert sum(row['classification']=='omitted' for row in rows.values())==12
        assert sum(row['process_started'] is True for row in rows.values())==1 and len(errors)==1
        passed.append('first_full_failure_preserves_exactly_twelve_not_run_tests')
    result={'status':'PASS_SYNTHETIC_PREPARATION_CHECKS_NOT_GAMEPLAY','checks':len(passed),'labels':passed,
            'godot_started':False,'game_started':False,'real_source_tree_scanned':False,
            'metadata_status':NEW_TEST_METADATA['status'],'source_metadata_still_unknown':not isinstance(runner.FROZEN_SOURCE['source_files'],int)}
    print(json.dumps(result,sort_keys=True))


if __name__=='__main__':main()
