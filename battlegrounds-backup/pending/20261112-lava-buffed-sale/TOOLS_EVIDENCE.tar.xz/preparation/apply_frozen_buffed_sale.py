"""Apply only prevalidated new overlays to the verified independent working copy."""
from pathlib import Path
import argparse,datetime,fcntl,hashlib,json,shutil
r=Path(__file__).resolve().parents[1];p=r/'candidate';e=r/'evidence'
ap=argparse.ArgumentParser();ap.add_argument('--implementation-freeze',type=Path,required=True);ap.add_argument('--tests-freeze',type=Path,required=True);a=ap.parse_args()
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
with (r.parent/'develop_empty_ghost_20261112/.independent_full_game.lock').open('r') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert (r/'preparation/CANDIDATE_PREIMAGE_VERIFIED.json').is_file()
 assert not (e/'APPLIED_FROZEN_BUFFED_SALE.json').exists()
 impl=json.loads(a.implementation_freeze.read_text());tests=json.loads(a.tests_freeze.read_text())
 pre=json.loads((r/'preparation/CANDIDATE_PREIMAGE_SOURCE_SHA256.json').read_text())
 assert set(impl)=={'core/darkcrest_lava_play.gd','core/darkcrest_host.gd'}
 test_files=tests['files'];assert set(test_files)=={'content_contract.gd','real_matrix.gd','README.md'}
 operations=[];changes={}
 for n,h in impl.items():
  assert sha(p/n)==pre[n] and sha(r/'implementation_overlay'/n)==h
  operations.append((r/'implementation_overlay'/n,p/n))
 for n,v in test_files.items():
  h=v if isinstance(v,str) else v['sha256'];src=r/'tests_overlay'/n;dst=p/'tests/darkcrest_lava_buffed_sale_20261112'/n
  assert src.is_file() and sha(src)==h and not dst.exists()
  operations.append((src,dst))
 old='darkcrest-mini-after-cast-sale-candidate-20261112';new='darkcrest-lava-buffed-sale-candidate-20261112'
 revisions={}
 for n in ['core/darkcrest_sources.gd','data/darkcrest_overlay.json']:
  assert sha(p/n)==pre[n];s=(p/n).read_text();assert s.count(old)==1;revisions[n]=s.replace(old,new)
 # No target writes occur until every frozen input, target preimage and revision is checked.
 e.mkdir(exist_ok=True)
 for src,dst in operations:
  n=dst.relative_to(p).as_posix();changes[n]={'before':pre.get(n),'after':sha(src)}
  dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dst)
 for n,s in revisions.items():
  (p/n).write_text(s);changes[n]={'before':pre[n],'after':sha(p/n)}
 shutil.copyfile(r/'preparation/CANDIDATE_PREIMAGE_SOURCE_SHA256.json',r/'PREIMAGE_HASHES.json')
 report={'status':'UNACCEPTED_FROZEN_BUFFED_SALE_APPLIED_NO_GAME','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'implementation_freeze_sha256':sha(a.implementation_freeze),'tests_freeze_sha256':sha(a.tests_freeze),'changes':changes,'previous_source_untouched':True}
 (e/'APPLIED_FROZEN_BUFFED_SALE.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
