# 第16批只读驱动溯源收口

## 最终结论

本轮可确认的是历史字节关系，不能确认当前项目对应的唯一 `tools/build_effect_catalog.py`。没有生成、安装或发布任何驱动候选，没有运行或导入历史编译器，没有运行 Godot、完整游戏或存档。

原 XML 单文件候选可独立备份；它不等于驱动恢复或完整项目验收。原有两份 runtime、旧备份和 XML 候选压缩包均未修改。本目录仅包含诊断证据。

## 驱动版本调查

- 179 份保存的整本副本对应 98 个 SHA256，均与此前记录一致。
- 原 manifest 图的 95 条边中，92 条通过精确位置、精确上下文及输出哈希补丁核验；另外确认过 2 条已保存整本间的补丁连接。此次没有更改这些统计，也没有把图终点、文件名或文件大小当作当前版本证明。
- 四份 Boogie/Imperial 整本的独立字节比较确认：保存的合并结果 `f608ca3744320b5abfcc94effa203031f300d00fa5c2ad7a839d1e86a6f6d474` 恰好保留双方各 10 行新增 hook，无其他变化。这解释了原 Boogie shared patch 为何不能直接用于并发修改后的 Imperial 分支。这是四方字节证明，不是找到了原始 merge patch，也不增加原补丁验证边数。原 pending blob `77abf0af06ab23231250387d9bd288391f30b58be1eefbbe9c752640191851ed` 仍未恢复。
- Energy Recycling proposal 中确有两份完全相同的 7 行编译 hook。其自身补丁精确逆向只移除第二份，因此所得前像不是保存的 Apples 整本。没有删除、修正或运行这两份 hook。
- Patient Scout proposal 相比保存的 Energy 整本，还加入 Scribe、Mystic Bloom、Treasure Hoard，并用 Scout 替换第二份 Energy hook。因此不能仅凭“更大”或名称较后就选作当前驱动。

三个精确逆补丁前像再次复现，但不是独立找到的历史原件：

- Apples：559,150 bytes，`a8c0924e778fd0ce5f0f4a895c292380b93f9d70dbd9eefed4d261c5c22b2d56`。
- Energy：560,057 bytes，`3373169c8e18c1566f46fa78eadd2945e9011cf69c61007efdb3c0ceb89714e1`。
- Scout：561,957 bytes，`7ff4ff4859d4cf8c124e2a9cc10ff4475aa5413398035a9c005b5d4654bd2071`。

此前五份索引合计检查 190,463 条记录，找到 358 条驱动文件名记录，但仍只有已知 98 个哈希；三个前像均无精确哈希命中。这个数字是索引记录数，不是唯一文件数。本次没有重复大规模解压或索引扫描。结论仅适用于已检查的本地材料，不能宣称所有外部来源都不存在。

## 实际依赖与风险

当前 `tools/` 有 23 个 Python 文件。对各历史整本的直接 AST import 清单检查实际文件存在性，发现每版缺少 771–851 个非标准库直接模块名，全部版本的并集 852、交集 771。计数包含条件及函数内部 import，不代表每一项都会运行；未闭合传递依赖或动态路径。它与 345 条未解决 runtime 工具引用是不同指标，不能相加或互相替代。

`core/catalog.gd:1410–1413` 读取 Cthun/Titanic 的 RUNTIME_PATHS 内容并纳入哈希；两组路径均包含缺失的驱动。`core/catalog.gd:2100–2105` 形成 execution/base execution fingerprint；`core/game.gd:14131` 保存指纹，`:14493` 比较加载指纹，不匹配即返回 ERR_INVALID_DATA。驱动即使没有被执行，恢复其字节也可能改变存档身份。没有验收旧存档兼容性，也不能断言缺失驱动是唯一启动阻碍。

历史编译器存在顶层写入 `data/catalog.json` 和 `data/effect_coverage.json` 的语句，因此导入或运行它不是只读检查。此次仅将源代码和补丁作为数据读取。

Titanic 的局部 manifest `6fd5ef38… → 7b2959d4…` 和 Cthun 后续 `7b2959d4… → e0f2250a…` 说明历史家族整合关系，不能充当当前整本的发布 pin。

## 已封存 XML 候选

目标仅为 `evidence/portable_legacy/CardDefs.Bacon_latest.xml`，15,824,602 bytes；历史 SHA256 为 `c385e3d67bfc2c52408059fbb0399b41164c8d1b78d3dd1619a6fb1882116690`，Git blob 为 `a5fc0a8ec52c9264850c8eb958b6c0d5723083ef`。固定来源为 HearthSim/hsdata commit `27fbd2323aec20cab1c6ecc7d5f55cf12729f956`，版本 36.6.3.253932。

已经独立核验双哈希、完整 XML 解析、build 253932、5,786 个 Entity，以及 Hand/Piranha 的 5 份已有原生片段字节一致性。它是历史来源准备和四项静态验证脚本所需的原聚合输入。没有安装进现有 runtime，也没有恢复另一个 `research/supplemental/CardDefs.Bacon_latest.xml` 缓存路径。

固定上游根目录及 README 未提供明确游戏数据再分发许可；不能套用其他 HearthSim 代码许可。候选中保留了许可边界。本轮未向外发布。

已封存包：

`historical_tools_batch16_dependency_audit_20261109/historical_tools_batch16_xml_original_candidate_20261109.tar.xz`

大小 1,804,348 bytes，SHA256 `3d37a9d1a0ee2d61939e88f8ced995622ca22fd84ba7f9dabe8c4f2df6bafa7d`。原包已经逐项回读 49 个文件；本次再次确认包大小与哈希不变。本目录不替换该包。

## 保持不变的边界

- 来源候选备份 `3b0061fcf3a55850eeda689818f7cc1700700750`、此前诊断备份 `758e26e1ecefaebfbcc7166912da412eb7197994` 保留。
- 两份 SOURCE_CONTRACT.md 仍缺失；没有编写替代声明或新增豁免。Hand 合同的历史 pin 仍为 `fb79811c28c9e21d802cc7c97c97070b1ce4748cf85a4ce65bba3b57d34d45cd`。Piranha 仍没有可信原件或独立 pin。
- Murloc host 当前较后版本保持原样，仍为 `2ab2af61bf8993575fa47ed60afbe7998840d02af479d0c295fdb3fa134101a3`；此前四处历史补丁已经精确往返说明版本差异，无需替换。
- 345 条未解决 runtime 工具引用没有因 XML 证据包而减少。原有普通/金色、部分实现及卡池状态没有改变。
- 两份完整 runtime 此前各 27,920 文件、1,549,340,406 bytes，完整树哈希 `5ba04ef124fc78cf20e2a942a60589fb92dc76e6808155648226a534a4599e05`。本轮只重新检查关键源文件、目标缺失状态和包哈希，没有伪称再次全量验收。
- 完整编译器、游戏行为、旧指纹迁移及存档兼容均未验收。

## 后续需要的确切证据

优先取得与当前 core/data 同一权威项目快照中的整本 `tools/build_effect_catalog.py`、原始归档或提交身份、整本哈希及依赖锁定/来源清单。另一条路线是取得上述三个前像的独立原件，再取得带前后哈希和明确顺序的整合记录，覆盖 Shady Aristocrat、Denathrius、Energy 重复/去重、Scribe、Mystic Bloom、Treasure Hoard 和 Scout。仅逆补丁产生字节、自己排序补丁或猜测去重不足以恢复发布版本。

本轮到达有限的来源证据终点；不是权限拒绝、执行待批准或仍在运行的测试。新的可信来源到来前，不应盲选版本或通过完整编译器试跑来代替来源闭合。

## 证据导航

- `compiler/FINAL_CHAIN_SUPPLEMENT.md`：最后一轮局部链结论，补充而不覆盖早期报告。
- `compiler/BOOGIE_FOUR_WAY_BYTE_PROOF.json`、`PROPOSAL_BYTE_DIFFERENCES.json`、`EXACT_PREIMAGE_RECHECK.json`：字节证明、补丁 pin 与前像。
- `compiler/INDEX_SCOPE_SUPPLEMENT.json`：五份索引范围及有限负结果。
- `compiler/CURRENT_VERSIONS.json`、`CURRENT_DIRECT_IMPORT_GAPS.json`：98 版与直接依赖缺口。
- `runtime/RUNTIME_DEPENDENCIES.json`：真实文件读取、指纹及存档比较位置。
- `FINAL_STATE_PIN_CHECK.json`：本轮选定源文件与已封存 XML 包复核。
- `FILES_SHA256.json`：本目录文件摘要。历史源和补丁只读取，诊断使用 128 MiB 地址空间上限，最后字节分析峰值 35,792 KiB。
