import pathlib,json,hashlib,difflib,re,resource
O=pathlib.Path(__file__).parent;R=pathlib.Path('historical_tools_batch15_20261109T195018Z/runtime')
x=json.load(open('historical_tools_batch10_20261109T164415Z/static_evidence/BUILD_COMPILER_STATIC_PROJECTION.json'))
def H(b):return hashlib.sha256(b).hexdigest()
def get(h):
 p=x['versions'][h]['paths'][0];b=(R/p).read_bytes();assert H(b)==h;return b
base='5034a8843fa6084cca8ef976f45c7255e29a7b5c0f581eacd8329b75ea6fff12';imperial='43d33ce0360f207b91683d21d8e9df9482e509b1a729fbff8a5ad0c2db5dd567';boogie='c9cdfbe7158f1a1c564e8284ad3d95393e7d1277a7f5211eac7ee9959daa1419';merged='f608ca3744320b5abfcc94effa203031f300d00fa5c2ad7a839d1e86a6f6d474'
def ops(a,b):
 aa=a.splitlines(keepends=True);bb=b.splitlines(keepends=True)
 return [{'tag':t,'old_start':i,'old_end':j,'new_start':k,'new_end':l,'old_lines':[q.decode() for q in aa[i:j]],'new_lines':[q.decode() for q in bb[k:l]]} for t,i,j,k,l in difflib.SequenceMatcher(None,aa,bb,autojunk=False).get_opcodes() if t!='equal']
a,b,c,d=map(get,[base,imperial,boogie,merged]);ib=ops(a,b);bc=ops(a,c);bm=ops(b,d)
assert len(ib)==len(bc)==len(bm)==1 and all(z[0]['tag']=='insert' for z in [ib,bc,bm]);assert bc[0]['new_lines']==bm[0]['new_lines'];assert len(ib[0]['new_lines'])==len(bc[0]['new_lines'])==10
pos=ib[0]['old_start'];assert pos==bc[0]['old_start'];lines=a.splitlines(keepends=True)
derived=b''.join(lines[:pos])+''.join(ib[0]['new_lines']+bc[0]['new_lines']).encode()+b''.join(lines[pos:]);assert derived==d
result={'kind':'Four preserved whole-file byte comparison, not an original merge patch or executed historical merger','base':base,'imperial_branch':imperial,'boogie_branch':boogie,'merged_whole':merged,'base_to_imperial':ib,'base_to_boogie':bc,'imperial_to_merged':bm,'exact_imperial_then_boogie_insertion_hash':H(derived),'original_pending_blob_recovered':False}
(O/'BOOGIE_FOUR_WAY_BYTE_PROOF.json').write_text(json.dumps(result,indent=2))
seq=['kidnap_sack_native_recovery/candidates','timewarped_apples_native/proposed','energy_recycling_native/proposed','patient_scout_native/proposed'];out=[]
for p,q in zip(seq,seq[1:]):
 a=(R/'research'/p/'tools/build_effect_catalog.py').read_bytes();b=(R/'research'/q/'tools/build_effect_catalog.py').read_bytes();out.append({'from':p,'from_sha256':H(a),'to':q,'to_sha256':H(b),'observed_byte_changes':ops(a,b)})
(O/'PROPOSAL_BYTE_DIFFERENCES.json').write_text(json.dumps(out,indent=2))
# Independently reverse only one exact documented compiler hunk per proposal; no fuzzy placement.
checks=[]
for n in ['timewarped_apples_native','energy_recycling_native','patient_scout_native']:
 p=R/'research'/n;patch=(p/'shared_host.patch').read_bytes();alllines=patch.splitlines(keepends=True);start=alllines.index(b'--- a/tools/build_effect_catalog.py\n');end=next((i for i in range(start+1,len(alllines)) if alllines[i].startswith(b'--- ')),len(alllines));section=alllines[start+2:end]
 headers=[i for i,l in enumerate(section) if l.startswith(b'@@ ')];assert len(headers)==1 and headers[0]==0
 m=re.match(rb'@@ -(\d+),(\d+) \+(\d+),(\d+) @@',section[0]);assert m
 old=[l[1:] for l in section[1:] if l[:1] in [b' ',b'-']];new=[l[1:] for l in section[1:] if l[:1] in [b' ',b'+']];assert len(old)==int(m[2]) and len(new)==int(m[4])
 whole=(p/'proposed/tools/build_effect_catalog.py').read_bytes();ls=whole.splitlines(keepends=True);at=int(m[3])-1;assert ls[at:at+len(new)]==new
 pre=b''.join(ls[:at]+old+ls[at+len(new):]);checks.append({'proposal':n,'proposal_sha256':H(whole),'patch_sha256':H(patch),'exact_reverse_preimage_sha256':H(pre),'bytes':len(pre),'energy_import_occurrences':pre.count(b'from energy_recycling_patterns import'),'preimage_is_known_complete_copy':H(pre) in x['versions']})
(O/'EXACT_PREIMAGE_RECHECK.json').write_text(json.dumps(checks,indent=2));print(json.dumps(checks,indent=2));print('Boogie additive bytes proven, max rss',resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)
