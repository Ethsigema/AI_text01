# Final bounded driver-chain investigation

## Newly established local fact: Boogie additive merge

The four preserved whole-file hashes were freshly checked. The common base5034a884… differs from Imperial branch43d33ce0… only by a10-line Imperial hook insertion. The same base differs from Boogie branchc9cdfbe7… only by a10-line Boogie hook insertion at the same base position. Preserved merged wholef608ca37… is byte-for-byte exactly the base with Imperial's block followed by Boogie's block. Imperial branch→merged changes nothing except the same10-line Boogie block.

BOOGIE_FOUR_WAY_BYTE_PROOF.json contains full hashes, zero-based line spans, inserted lines and exact result hash. This closes the narrow question of whether the saved resolved driver preserves both contributions. It is a fresh four-way byte comparison, not a recovered original merge patch, not execution of parent_merge_record.py and not a new successful shared-patch edge. The existing92/95 manifest-edge patch statistic remains unchanged. The original unresolved pending blob77abf0af… is still not recovered. The saved parent_merge_record.py explicitly describes concatenating Imperial and Boogie conflict sides; its source was read, not executed.

This local historical merge does not identify the current release or establish an uninterrupted chain to the three later proposals. It does not verify runtime behavior.

## New concrete reason not to select the largest or later-named proposal

PROPOSAL_BYTE_DIFFERENCES.json records fresh exact whole-file differences:

- Kidnap Sack674a4e50…→Timewarped Applescf910d52… inserts Shady Aristocrat, Apples and Denathrius hooks. This is observed byte content, not proof of a historical authoritative release transition.
- Applescf910d52…→Energy565f7f8f… inserts TWO byte-identical7-line Energy Recycling import/compile/order blocks. The complete Energy proposal therefore contains a duplicated compilation hook. Its own shared patch's exact reverse removes only the second block, leaving one Energy block in the preimage3373169c… . Do not repair or delete either block based on this audit; the duplication is a reason to obtain the original integration record, not an invitation to invent it.
- Energy565f7f8f…→Patient Scouta8fb42cc… adds Scribe, Mystic Bloom and Treasure Hoard hooks and replaces the second Energy block with a Scout block. Its own reverse Scout patch leaves the other new hooks and one Energy block, producing7ff4ff48… . Thus its predecessor is not the saved whole Energy proposal.

These exact differences explain why sequence-by-size and casual application of one family patch would skip unrelated edits or retain a duplicated hook. They do not determine whether/how those drafts were ultimately accepted.

## Independently rechecked preimages

Only each original compiler patch section was interpreted as unified-diff data, with exact positions and exact old/new line counts. No fuzzy context matching, source execution, import or generated-driver writes occurred. Results reproduce the prior hashes:

- Apples preimage:559150 bytes, a8c0924e778fd0ce5f0f4a895c292380b93f9d70dbd9eefed4d261c5c22b2d56.
- Energy preimage:560057 bytes,3373169c8e18c1566f46fa78eadd2945e9011cf69c61007efdb3c0ceb89714e1.
- Scout preimage:561957 bytes,7ff4ff4859d4cf8c124e2a9cc10ff4475aa5413398035a9c005b5d4654bd2071.

EXACT_PREIMAGE_RECHECK.json pins original patch hashes and outputs. These are reproducible inverse-diff byte states, not independently preserved historical originals. The earlier190463-record index scan found no matching original member for any of them and no compiler whole version beyond the known98. No index scan was repeated in this pass.

## Finite endpoint and exact evidence still needed

There is enough evidence for the Boogie local additive-content statement, but still no evidence-backed unique current driver candidate. No further broad extraction or compiler run is justified merely to fill this gap.

To continue safely, obtain one of:

1. The actual integrated tools/build_effect_catalog.py from the authoritative project snapshot corresponding to the current core/data state, with original archive or commit identity and a pinned whole-file hash, plus its dependency lock/source manifest. A later filename alone is insufficient.
2. Independently preserved originals matching the three preimage hashes above, plus recorded before/after hashes and ordered integration artifacts for Shady Aristocrat, Denathrius, Energy duplication/removal, Scribe, Mystic Bloom, Treasure Hoard and Scout. An exact inverse patch alone does not prove which state was installed or that subsequent patches are complete.
3. For the unresolved historical Boogie conflict state itself, the original pending77abf0af… blob or original merge output with its input pins. It is not required to prove the saved resolved whole preserves both10-line blocks, but would be required to claim recovery of the original conflict artifact.

Even a verified driver does not close771–851 direct-import file gaps, the separately counted345 runtime-source-reference gaps, aggregate-input provenance or the two missing SOURCE_CONTRACT.md files. The XML candidate tar remains untouched; its acceptance is a separate parent-task decision.

Cthun/Titanic runtime path declarations and their local manifests provide historical family integration context only. Parent reports Titanic6fd5ef38…→7b2959d4… and later Cthun→e0f2250a…; neither pin is a current-release selector. Restoring any driver bytes can change execution fingerprints and saved-state acceptance. No gameplay or save compatibility was tested or claimed.

## Scope

All new files stay in this independent audit directory. Existing reports, both runtime copies, backup archives and XML candidate tar were not modified. No driver was installed, emitted as a candidate, imported, executed or published. New read-only byte analysis ran under128MiB address-space limit with35792KiB peak RSS. This is a source-evidence limitation, not a permission denial or pending execution.
