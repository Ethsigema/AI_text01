# Index coverage supplement

This supplements, without modifying, REPORT.md's main-index-only coverage statement. The existing main-index result of87451 records was reused. Four additional indexes were streamed under128MiB address-space limit:

- supplemental_archives/MEMBERS.jsonl:49870 records.
- additional_archives/MEMBERS.jsonl:2274 records.
- large_known_overlays/MEMBERS.jsonl:50387 records.
- resume_source_audit/excluded_text_supplement/FILES.jsonl:481 records.

The four original content indexes therefore cover189982 records; with the current excluded-text supplement the combined count is190463. These are indexed occurrences, not unique physical files.

None of the four added indexes contains a member whose final filename is build_effect_catalog.py. None contains any of the three exact preimage SHA256 values listed in INDEX_SCOPE_SUPPLEMENT.json. The combined result remains358 driver-name occurrences,98 distinct driver hashes, zero new complete-driver hashes and zero exact preimage hits. Thus no minimal archive-location follow-up or new candidate is warranted by this scan.

This is an index-level bounded negative result, not proof that external/unindexed sources lack the bytes. No archives were decompressed, no historical code was executed/imported, and no existing files were edited. The supplement records each scanned index SHA256. New scan peak RSS10200KiB.
