import pathlib,json,hashlib,resource
O=pathlib.Path(__file__).parent
base=pathlib.Path('historical_tools_batch15_contract_content_audit_20261110T050100Z')
old=json.load(open(O/'INDEX_COMPILER_MEMBERS.json'));known={d['sha256'] for d in old};wanted=set(json.load(open(O/'ISOLATED_PREIMAGE_INDEX_CHECK.json'))['target_hashes'])
paths=[base/d/'MEMBERS.jsonl' for d in ['supplemental_archives','additional_archives','large_known_overlays']]+[pathlib.Path('historical_tools_batch15_resume_source_audit_20261110/excluded_text_supplement/FILES.jsonl')]
results=[];new=[];hits=[];driver_hashes=set(known)
for p in paths:
 count=0;named=[];ph=[];h=hashlib.sha256()
 with open(p,'rb') as f:
  for line in f:
   h.update(line)
   if not line.strip():continue
   count+=1;d=json.loads(line)
   if d.get('sha256') in wanted:ph.append(d);hits.append(d)
   if d.get('origin','').replace('\\','/').split('/')[-1]=='build_effect_catalog.py':
    named.append(d);driver_hashes.add(d.get('sha256'))
    if d.get('sha256') not in known:new.append(d)
 results.append({'index':str(p),'index_sha256':h.hexdigest(),'records':count,'driver_name_occurrences':len(named),'driver_unique_hashes':sorted({d['sha256'] for d in named}),'new_driver_hashes':sorted({d['sha256'] for d in named if d['sha256'] not in known}),'exact_preimage_hits':ph})
summary={'scope':'Only four additional JSONL indexes streamed; no archive extraction or source execution. Main index results reused from immutable prior outputs. Counts are occurrences, not deduplicated files.','indexes':results,'main_index_records_reused':87451,'four_content_index_records':87451+sum(d['records'] for d in results[:3]),'all_five_index_records':87451+sum(d['records'] for d in results),'total_driver_name_occurrences':len(old)+sum(d['driver_name_occurrences'] for d in results),'total_driver_unique_hashes':len(driver_hashes),'new_driver_records':new,'exact_preimage_hits_all_indexes':hits,'main_index_preimage_hits_reused':[],'target_preimage_hashes':sorted(wanted),'max_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
(O/'INDEX_SCOPE_SUPPLEMENT.json').write_text(json.dumps(summary,indent=2))
print(json.dumps({k:v for k,v in summary.items() if k!='indexes'},indent=2));print([(d['index'],d['records'],d['driver_name_occurrences'],len(d['new_driver_hashes']),len(d['exact_preimage_hits'])) for d in results])
