import json,hashlib,pathlib,sys,ast,resource
O=pathlib.Path(__file__).parent
R=pathlib.Path('historical_tools_batch15_20261109T195018Z/runtime')
A=pathlib.Path('historical_tools_batch10_20261109T164415Z/static_evidence/BUILD_COMPILER_STATIC_PROJECTION.json')
def sha(p):
 h=hashlib.sha256()
 with open(p,'rb') as f:
  for b in iter(lambda:f.read(65536),b''):h.update(b)
 return h.hexdigest()
x=json.load(open(A)); known=set(x['versions']); checks=[]; gaps={}; union=set(); common=None
for h,v in x['versions'].items():
 paths=v['paths']; verified=[{'path':p,'sha256':sha(R/p)} for p in paths]
 missing=sorted(m for m in v['direct_import_modules'] if m.split('.')[0] not in sys.stdlib_module_names and not (R/'tools'/f'{m.replace(".","/")}.py').is_file() and not (R/'tools'/m.replace('.','/')/'__init__.py').is_file())
 gaps[h]=missing; union.update(missing); common=set(missing) if common is None else common.intersection(missing)
 checks.append({'sha256':h,'bytes':v['bytes'],'paths':verified,'all_match':all(i['sha256']==h for i in verified),'missing_direct_modules':len(missing)})
with open(O/'CURRENT_VERSIONS.json','w') as f:json.dump(checks,f,indent=2)
with open(O/'CURRENT_DIRECT_IMPORT_GAPS.json','w') as f:json.dump({'by_version':gaps,'union':sorted(union),'common':sorted(common)},f,indent=2)
index=[]
for line in open('historical_tools_batch15_contract_content_audit_20261110T050100Z/MEMBERS.jsonl'):
 d=json.loads(line)
 if d['origin'].endswith('/build_effect_catalog.py'):
  d['in_prior_98']=d['sha256'] in known; index.append(d)
with open(O/'INDEX_COMPILER_MEMBERS.json','w') as f:json.dump(index,f,indent=2)
cons=[]
for folder in ['core','tools']:
 for p in (R/folder).rglob('*'):
  if p.suffix not in ['.py','.gd']:continue
  with open(p,errors='replace') as f:
   for i,line in enumerate(f,1):
    if 'build_effect_catalog' in line or 'CardDefs.Bacon_latest.xml' in line:cons.append({'path':str(p.relative_to(R)),'line':i,'text':line.rstrip()})
with open(O/'DIRECT_CONSUMERS.json','w') as f:json.dump(cons,f,indent=2)
summary={'scope':'Read-only current hashes and direct-module file presence. Reuses prior AST inventory; no historical code imported or executed. No unique current driver selected.', 'projection_sha256':sha(A),'copies':sum(len(c['paths']) for c in checks),'versions':len(checks),'all_copies_match':all(c['all_match'] for c in checks),'missing_direct_modules_range':[min(map(len,gaps.values())),max(map(len,gaps.values()))],'missing_direct_modules_union':len(union),'missing_direct_modules_common':len(common),'indexed_members':len(index),'index_unique_hashes':len({v['sha256'] for v in index}),'index_new_hashes':sorted({v['sha256'] for v in index if not v['in_prior_98']}),'target_exists':(R/'tools/build_effect_catalog.py').exists(),'aggregate_xml_exists':(R/'evidence/portable_legacy/CardDefs.Bacon_latest.xml').exists(),'runtime_tools_py':len(list((R/'tools').glob('*.py'))),'max_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
with open(O/'SUMMARY.json','w') as f:json.dump(summary,f,indent=2)
print(json.dumps(summary,indent=2));print(json.dumps(cons,indent=2))
