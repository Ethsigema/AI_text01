# Compiler source trace, independent read-only audit

## Result

Historical whole drivers are preserved; the exact current integrated driver is not established by the available chain. No candidate is installed, published, synthesized, or selected as current. No compiler, generator, historical module, Godot, gameplay or save process was executed. The current missing target is `tools/build_effect_catalog.py` in batch15/runtime. All 179 historical copies remain byte-exact to the prior audit's 98 hashes.

The prior exact-context/hash patch audit establishes 92 of 95 manifest edges and two additional known-version edges. The raw graph has six components, reconciled claimed graph four. A claimed graph is not a release chronology. Boogie integration/pending edges are not validated by the shared patch; pending records include merge_exit 1. File size, path names and endpoint status cannot choose a current version.

The three isolated whole proposals remain specifically disconnected:

- Patient Scout: `research/patient_scout_native/proposed/tools/build_effect_catalog.py`, 562358 bytes, SHA256 a8fb42cc515623822f47852c026a76abf538ed2b8bd044677f221a9f9bf53b4d. Exact reverse shared patch produces unobserved preimage 7ff4ff4859d4cf8c124e2a9cc10ff4475aa5413398035a9c005b5d4654bd2071.
- Energy Recycling: `research/energy_recycling_native/proposed/tools/build_effect_catalog.py`, 560467 bytes, SHA256 565f7f8f7a938b8039a4057276e0cfae4d2d5f242e1c1eceaadeb7f28c780964. Reverse produces 3373169c8e18c1566f46fa78eadd2945e9011cf69c61007efdb3c0ceb89714e1.
- Timewarped Apples: `research/timewarped_apples_native/proposed/tools/build_effect_catalog.py`, 559647 bytes, SHA256 cf910d5284c2b7875ad339f1274a32cd53921bb251ee236143c1e24d17826fb4. Reverse produces a8c0924e778fd0ce5f0f4a895c292380b93f9d70dbd9eefed4d261c5c22b2d56.

These reverse results are existing audit findings, not new authoritative historical versions. A streamed comparison of all 87451 entries in batch15 content MEMBERS.jsonl found none of these three preimage hashes. The same index holds 358 compiler-named member occurrences but only the previously known 98 unique hashes. This is bounded index evidence, not a claim that every possible external source has been searched.

## Regression risk and closure

Across the 98 preserved versions, Hand Murloc import hooks occur in 93, Piranha hooks in 95, Timewarped Apples in 3, Energy Recycling in 2, and Patient Scout in only 1. The smallest preserved driver has none of these five hooks. This demonstrates why an arbitrary older whole copy can regress source coverage; presence alone does not validate implementation semantics or prove the largest version is complete/current.

Current `tools/` has 23 Python files. Reusing the SHA-verified prior direct AST import inventory and checking actual current module files yields 771–851 missing non-stdlib direct import names, union852/common771. Includes conditional/function-local imports; not all necessarily execute. Transitive imports and dynamically computed paths were not evaluated. This is distinct from the parent's 345 unresolved runtime-source-reference metric and must not be added to it or described as only345 compiler helpers.

`evidence/portable_legacy/CardDefs.Bacon_latest.xml` remains absent. Preserved per-card XML is evidence for individually audited families, not a byte-identical replacement for this aggregate. Existing prior I/O audit identifies top-level compiler writes to `data/catalog.json` and `data/effect_coverage.json`; an import or full invocation is not a read-only diagnostic.

## Runtime / saved-state boundary

Parent's independently inspected static consumers: `core/catalog.gd:1410–1413` traverses CthunSources/TitanicSources.RUNTIME_PATHS and incorporates file-content hashes; both path arrays declare `tools/build_effect_catalog.py`. Catalog:2100–2105 aggregates execution/base_execution_fingerprint; `core/game.gd:14131` saves it and :14493 compares it during loading. Thus restoring driver bytes can affect saved-state identity even without running the compiler. This is not merely an offline developer utility. No old-save compatibility is claimed. Parent retains the full consumer evidence separately.

Both SOURCE_CONTRACT.md gaps, the more recent Hand Murloc host revision, current pool/status holds, and lack of full gameplay/save acceptance remain unchanged.

## Files and scope

- CURRENT_VERSIONS.json: all179 copy hashes, sizes and per-version missing-import counts.
- CURRENT_DIRECT_IMPORT_GAPS.json: missing module names per version, union and intersection.
- INDEX_COMPILER_MEMBERS.json: all358 indexed compiler-name occurrences.
- ISOLATED_PREIMAGE_INDEX_CHECK.json: bounded exact-hash negative result.
- HOOK_VERSION_COUNTS.json: exact hash sets for the five hook families.
- SUMMARY.json and audit.py: current recomputation and method, 34288KiB peak RSS; process address-space limit128MiB.
- DIRECT_CONSUMERS.json is only a literal text hit list in core/tools, not a classified runtime dependency graph; the parent's consumer findings supersede treating raw-string provenance hits as file reads.

Prior source evidence: batch10/shared_tool_review/README.md, RECONCILED_GRAPH.json, UNASSOCIATED_PATCH_CHECKS.json, and static_evidence/BUILD_COMPILER_STATIC_PROJECTION.json (SHA256 b36dd9273110d91243908202b68c2fafa1f8dfd25e273eeb28a9ea46bf0ec070). No prior runtime, backup or audit file was changed.
