"""Static current-runtime dependency evidence, not a runtime test."""
from pathlib import Path
import hashlib,json,re,resource,sys
resource.setrlimit(resource.RLIMIT_AS,(134217728,134217728))
if sys.flags.optimize:raise RuntimeError('Assertions required')
ROOT=Path.cwd();R=ROOT/'historical_tools_batch15_20261109T195018Z/runtime';OUT=Path(__file__).resolve().parent
TARGETS=['tools/build_effect_catalog.py','evidence/portable_legacy/CardDefs.Bacon_latest.xml']
files=['core/catalog.gd','core/game.gd','core/custom_shop.gd','core/titanic_guardian_sources.gd','core/cthun_tentacle_sources.gd','core/kerrigan_zerg_sources.gd','core/brukan_elements_sources.gd','ui/main.gd','project.godot','main.tscn']
meta={};texts={};lines={}
for name in files:
 b=(R/name).read_bytes();meta[name]={'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()};texts[name]=b.decode();lines[name]=texts[name].splitlines()
def snippet(name,a,b):
 return {'path':name,'sha256':meta[name]['sha256'],'start_line':a,'end_line':b,'lines':[{'line':i,'text':lines[name][i-1]} for i in range(a,b+1)]}
paths={}
for name in ['core/titanic_guardian_sources.gd','core/cthun_tentacle_sources.gd']:
 m=re.search(r'^const RUNTIME_PATHS\s*(?::[^=]+)?\s*=\s*(\[.*\])$',texts[name],re.M);assert m
 arr=json.loads(m[1]);assert TARGETS[0] in arr
 paths[name]={'declared_paths':arr,'missing_paths':[x for x in arr if not (R/x).exists()]}
refs={t:[] for t in TARGETS}
for folder in ['core','ui','tools']:
 for p in (R/folder).rglob('*'):
  if not p.is_file() or p.suffix not in {'.gd','.py'}:continue
  for n,line in enumerate(p.read_text(errors='replace').splitlines(),1):
   for t in TARGETS:
    if t in line:refs[t].append({'path':str(p.relative_to(R)),'line':n,'line_sha256':hashlib.sha256(line.encode()).hexdigest(),'excerpt':line[:400],'complete_line_preserved_in_source':True})
report={'status':'STATIC_DEPENDENCY_AND_SAVE_FINGERPRINT_TRACE_ONLY','source_candidate_backup':'3b0061fcf3a55850eeda689818f7cc1700700750','latest_diagnostic_backup_reported_by_parent':'758e26e1ecefaebfbcc7166912da412eb7197994','targets_missing':{t:not (R/t).exists() for t in TARGETS},'source_files':meta,'source_runtime_paths':paths,'direct_literal_reference_scan':{'scope':'Only .gd and .py under current core, ui and tools; dynamic path construction and research scripts excluded from this scan','references':refs},'snippets':[
 snippet('core/catalog.gd',212,213),snippet('core/catalog.gd',1404,1417),snippet('core/catalog.gd',2098,2110),snippet('core/catalog.gd',2189,2208),snippet('core/game.gd',14131,14145),snippet('core/game.gd',14487,14497),snippet('core/custom_shop.gd',85,105),snippet('core/custom_shop.gd',114,120),snippet('ui/main.gd',153,161)],'findings':[
 'If load_catalog reaches lines1410-1413, it hashes the text of CthunSources and TitanicSources declared runtime paths, including tools/build_effect_catalog.py twice. These loops do not execute Python.',
 'Catalog lines2100-2105 fold these hashes into execution_fingerprint and base_execution_fingerprint. Restoring/changing a driver can therefore affect runtime/save identity even if no compiler runs.',
 'Game.save_to serializes execution_fingerprint. Game._read_scoped_game compares the saved fingerprint to CustomShop.effective_catalog fingerprint and returns ERR_INVALID_DATA on mismatch before publishing catalog assignment.',
 'CustomShop.fingerprint begins with the base execution fingerprint; room-specific additions do not remove the base dependency.',
 'UI startup calls catalog.load_catalog and exposes its load_errors. The examined load path reads existing JSON catalogs; no Python execution call appears in ui/main.gd, core/catalog.gd or core/game.gd. This does not prove all scripts never execute tools.',
 'The exact aggregate XML path appears only inside source metadata dictionaries in the current core/ui/tools literal scan. This is not evidence that XML is irrelevant to generation or validation, nor proof of all dynamic consumers.',
 'No current catalog load, fingerprint recomputation in Godot, game effect, full compiler, save or resume was run. A missing driver alone is not proven to be the sole startup blocker, and no save compatibility is accepted.'
 ],'source_changes':[],'full_game_or_save_accepted':False,'max_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
assert all(report['targets_missing'].values())
(OUT/'RUNTIME_DEPENDENCIES.json').open('x').write(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'status':report['status'],'source_runtime_paths':paths,'direct_literal_reference_counts':{k:len(v) for k,v in refs.items()},'source_changes':[],'max_rss_kib':report['max_rss_kib']},ensure_ascii=False,indent=2))
