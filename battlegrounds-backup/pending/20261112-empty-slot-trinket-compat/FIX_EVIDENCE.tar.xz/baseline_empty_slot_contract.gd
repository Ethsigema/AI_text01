extends SceneTree
const Pen=preload("res://core/waterlogged_pen_host.gd")
const Observer=preload("res://core/owned_observer_resources.gd")
func _initialize():
 var options={"left_tier":1,"right_tier":1,"left_hand":[],"right_hand":[],"left_hand_count":0,"right_hand_count":0,"left_is_ghost":false,"right_is_ghost":false,"delayed_gold_context":{"owners":[0,-1]},"maximum_history_context":{"owners":[0,-1]}}
 options[Pen.CONTEXT]=[{"owner":0,"trinkets":[],"ledger":{"owner":0,"slots":{}},"id":""},{"owner":-1,"trinkets":[],"ledger":{"owner":-1,"slots":{}},"id":""}]
 options[Observer.CONTEXT]=[{"error":"","owner_id":0,"trinkets":[],"entries":[]},{"error":"","owner_id":-1,"trinkets":[],"entries":[]}]
 var pen=Pen.combat_domain([],[],options)
 var observer=Observer.new().initialize({"_options":options,"_boards":[[],[]]})
 print("BASELINE_EMPTY_SLOT_OBSERVATION ",JSON.stringify({"pen_error":pen,"observer_error":observer,"scope":"pure pre-change fixture observation, not a newly run native Game"}))
 if pen!="waterlogged_pen_combat_owner_snapshot" or observer!="shield_resource_changed_context":quit(1);return
 print("BASELINE_EMPTY_SLOT_GATE_REPRODUCED checks=2")
 quit(0)
