extends RefCounted
## Pinned Cursed Crystal revision. Partial holds and previous proof boundaries remain.
const REVISION: String="partial-37.0.2-vibrant_bubble_spell-v1"
const ID: String="BG32_MagicItem_892t"
const OVERLAY: String="data/patch_3702_vibrant_bubble_spell_overlay.json"
const FILE_SHA256: Dictionary={"data/patch_3702_vibrant_bubble_spell_overlay.json":"9f17a256582d0239a14fbac2703bf61f3f9794660a372f276c89d304174ef01b","research/patch_3702_vibrant_bubble/BG32_MagicItem_892.native.xml":"dcf1027fd35dc0ecf9568228081ddc88a798da2e08ae2b02737f48c5c99d8545","research/patch_3702_vibrant_bubble/BG32_MagicItem_892t.native.xml":"f4c03332e3aa08b6d24d489bdf11bc213c4d48d6b8947373e2fcee3109a1824c","research/patch_3702_vibrant_bubble/PREFLIGHT.json":"3637b2e0a90d44ccfe92f92ca036d58c818397c8e94d44f8d546a604516ec763","research/patch_3702_vibrant_bubble/RESULT.md":"43c4d385df7db27612eed1865fd09c4e0c98a754be4498e46c9d42dd9632e79b","research/patch_3702_vibrant_bubble/THIRD_PARTY_RECEIPT.json":"0b58974754a3ce72521d52b6e7973c348b420d10605818db7cd70bc5340c50ee","research/patch_3702_vibrant_bubble/apprentice-of-sefin.js":"1f5e6018a99c37505db8dad4c5793d1f6699f68c0a3374916e294cdd0dd644f4","research/patch_3702_vibrant_bubble/bubble-gunner.js":"2a74201cce9add36773aa890f16beb85fdafdd1604f91a453b8a900d63cc5603","research/patch_3702_vibrant_bubble/cards-data.js":"3cef0706d1ff96f693dcad8c33999b67e95c06858881fbd0c8c399678b9ad24a","research/patch_3702_vibrant_bubble/native_global_en.json":"2b04ff66a51761f9bc13874a256a76feb90eb2a7cb429f6658fad32fa92d74af","research/patch_3702_vibrant_bubble/native_global_receipt.json":"c913fc81b4124894cfa37e50bd2df4ba34162e34315550071154c862bb534db9","research/patch_3702_vibrant_bubble/official_api_trinkets.json":"4abef90cd72c7a3e7a6ca971cc4326fe8dece62da70799ac147449cd459acf16","research/patch_3702_vibrant_bubble/package.json":"3e19a83eba1cc5c1a1b68f8cc856749d61c7a5af45fb44a419f8297704c8f0ea","core/vibrant_bubble.gd":"01b6452f4009142c2543b5f0407eba1d7c0e2a9122ed9e14556422f0da0f1505","core/game.gd":"2373572c775251faf58677e87ccaf353d1132259a97fad99e27d575490be4778","core/trinket_spellcraft.gd":"0a358e56920c1947039e618a3a2478c276c60e1cd4e95f49a5a24821dfddcc82","core/native_hand_spell_target.gd":"a2cde01e638861b3212673dc84f58f29e14b42722cc4e3c5f21453cee6675a9c"}
const RUNTIME_PATHS: Array=["core/patch_3702_vibrant_bubble_spell_sources.gd","core/catalog.gd","data/patch_3702_vibrant_bubble_spell_overlay.json","research/patch_3702_vibrant_bubble/BG32_MagicItem_892.native.xml","research/patch_3702_vibrant_bubble/BG32_MagicItem_892t.native.xml","research/patch_3702_vibrant_bubble/PREFLIGHT.json","research/patch_3702_vibrant_bubble/RESULT.md","research/patch_3702_vibrant_bubble/THIRD_PARTY_RECEIPT.json","research/patch_3702_vibrant_bubble/apprentice-of-sefin.js","research/patch_3702_vibrant_bubble/bubble-gunner.js","research/patch_3702_vibrant_bubble/cards-data.js","research/patch_3702_vibrant_bubble/native_global_en.json","research/patch_3702_vibrant_bubble/native_global_receipt.json","research/patch_3702_vibrant_bubble/official_api_trinkets.json","research/patch_3702_vibrant_bubble/package.json","core/vibrant_bubble.gd","core/game.gd","core/trinket_spellcraft.gd"]
const EXPECTED_RAW: Dictionary={}
const EXPECTED_COMPILED: Dictionary={}
const EXPECTED_BASELINE: Dictionary={}
const EFFECTIVE_FIELDS: Dictionary={"supported":true,"effects":[{"type":"spell_vibrant_bubble_random_keyword","source_id":"BG32_MagicItem_892t","scope":"target","tribe":"鱼人","allow_shop":true,"count":1,"keywords":["taunt","divine_shield","reborn","venomous","windfury","stealth"]}],"default_pool":false,"pool_supported":false,"cost":0,"coverage_rule":"native_vibrant_bubble_bounded_v1","coverage_text_sha256":"3c5454799e8f1cfbc783cfb9dd7a270656e5a5f79aa74b7021ba1e24d9ba5f9e","implementation_status":"partial_pending_unified_validation","conditional_support":{"rule":"vibrant_bubble_ordinary_hand_spellcraft_v1","reason":"Six keywords from pinned extracted client localization; exclusion of already held keywords is THIRD-PARTY simulator corroboration, not official algorithm proof. Ordinary owned trinket actual hand target cast only. No full-card completeness claim. Shop, permanent sources, all six outcomes, full-hand and automatic/listener combinations require separate acceptance."},"id":"BG32_MagicItem_892t","card_code":"BG32_MagicItem_892t","dbf_id":"121139","name":"鲜活气泡","text":"使一个鱼人随机获得一个额外关键词。","kind":"spell","category":"塑造法术","categories":["塑造法术"],"tier":null,"attack":null,"health":null,"armor":null,"tribes":[],"keywords":[],"is_golden":false,"normal_id":null,"golden_id":null,"solo_eligible":true,"duos_exclusive":false,"requires_teammate_effect":false,"source_url":"https://hearthstone.blizzard.com/en-us/battlegrounds/121138/","provenance":{"native_entity":"research/patch_3702_vibrant_bubble/BG32_MagicItem_892t.native.xml","native_full_sha256":"103890e791863c743dd4b873e4cb789b711543ba839f923f677ebba6d672ff5a"},"image":"","pool_blocker":"没有已确认的普通酒馆法术池资格；保留原法术身份，可由对应机制生成，或显式配置自定义入店参数。","temporary":true}
const EXPECTED_CURRENT: Dictionary={"supported":true,"effects":[{"type":"spell_vibrant_bubble_random_keyword","source_id":"BG32_MagicItem_892t","scope":"target","tribe":"鱼人","allow_shop":true,"count":1,"keywords":["taunt","divine_shield","reborn","venomous","windfury","stealth"]}],"default_pool":false,"pool_supported":false,"cost":0,"coverage_rule":"native_vibrant_bubble_bounded_v1","coverage_text_sha256":"3c5454799e8f1cfbc783cfb9dd7a270656e5a5f79aa74b7021ba1e24d9ba5f9e","implementation_status":"partial_pending_unified_validation","conditional_support":{"rule":"vibrant_bubble_ordinary_hand_spellcraft_v1","reason":"Six keywords from pinned extracted client localization; exclusion of already held keywords is THIRD-PARTY simulator corroboration, not official algorithm proof. Ordinary owned trinket actual hand target cast only. No full-card completeness claim. Shop, permanent sources, all six outcomes, full-hand and automatic/listener combinations require separate acceptance."},"id":"BG32_MagicItem_892t","card_code":"BG32_MagicItem_892t","dbf_id":"121139","name":"鲜活气泡","text":"使一个鱼人随机获得一个额外关键词。","kind":"spell","category":"塑造法术","categories":["塑造法术"],"tier":null,"attack":null,"health":null,"armor":null,"tribes":[],"keywords":[],"is_golden":false,"normal_id":null,"golden_id":null,"solo_eligible":true,"duos_exclusive":false,"requires_teammate_effect":false,"source_url":"https://hearthstone.blizzard.com/en-us/battlegrounds/121138/","provenance":{"native_entity":"research/patch_3702_vibrant_bubble/BG32_MagicItem_892t.native.xml","native_full_sha256":"103890e791863c743dd4b873e4cb789b711543ba839f923f677ebba6d672ff5a"},"image":"","pool_blocker":"没有已确认的普通酒馆法术池资格；保留原法术身份，可由对应机制生成，或显式配置自定义入店参数。","temporary":true}

static func accepts_id(value: Variant) -> bool:
	return value is String and value==ID

static func same(actual: Variant,expected: Variant) -> bool:
	# JSON integral floats are admissible. Booleans/strings/fractions/nonfinite values are not numbers.
	if expected is int or expected is float:
		return (actual is int or actual is float) and not actual is bool and is_finite(float(actual)) and is_finite(float(expected)) and actual==floor(actual) and expected==floor(expected) and actual==expected
	if typeof(actual)!=typeof(expected): return false
	if expected is Dictionary:
		if actual.size()!=expected.size(): return false
		for key in expected:
			if not actual.has(key) or not same(actual[key],expected[key]): return false
		return true
	if expected is Array:
		if actual.size()!=expected.size(): return false
		for index in range(expected.size()):
			if not same(actual[index],expected[index]): return false
		return true
	return actual==expected

static func proof_error() -> String:
	# Startup-only disk proof. Hot source_error/program/get_card never calls this.
	for path in FILE_SHA256:
		if not FileAccess.file_exists("res://"+path) or FileAccess.get_sha256("res://"+path)!=FILE_SHA256[path]: return "partial_3702_vibrant_bubble_spell_evidence_changed:"+str(path)
	var packet: Variant=JSON.parse_string(FileAccess.get_file_as_string("res://"+OVERLAY))
	var expected_packet: Dictionary={"revision":REVISION,"cards":[{"id":ID,"expected_raw":EXPECTED_RAW,"expected_compiled":EXPECTED_COMPILED,"expected_baseline":EXPECTED_BASELINE,"effective_fields":EFFECTIVE_FIELDS}]}
	if not same(packet,expected_packet): return "partial_3702_vibrant_bubble_spell_changed_packet"
	var baseline: Dictionary=EXPECTED_RAW.duplicate(true);baseline.merge(EXPECTED_COMPILED,true)
	if not same(baseline,EXPECTED_BASELINE): return "partial_3702_vibrant_bubble_spell_invalid_baseline_derivation"
	baseline.merge(EFFECTIVE_FIELDS,true)
	if not same(baseline,EXPECTED_CURRENT) or str(EXPECTED_CURRENT.text).sha256_text()!=EXPECTED_CURRENT.coverage_text_sha256: return "partial_3702_vibrant_bubble_spell_invalid_current_derivation"
	return ""

static func input_error(decoded: Variant,path: String) -> String:
	# Called before generic numeric normalization. Historical input is authenticated in full.
	var expected: Dictionary={}
	if path=="res://data/catalog_raw.json": expected=EXPECTED_RAW
	elif path=="res://data/catalog.json": expected=EXPECTED_COMPILED
	if not decoded is Dictionary or not decoded.get("cards") is Array:
		return "partial_3702_vibrant_bubble_spell_missing_input:"+path if not expected.is_empty() else ""
	var matches: Array=[]
	for card in decoded.cards:
		if card is Dictionary and accepts_id(card.get("id")): matches.append(card)
	if expected.is_empty(): return "" if matches.is_empty() else "partial_3702_vibrant_bubble_spell_unexpected_input:"+path
	if matches.size()!=1: return "partial_3702_vibrant_bubble_spell_missing_or_duplicate_input:"+path
	return "" if same(matches[0],expected) else "partial_3702_vibrant_bubble_spell_changed_whole_input:"+path

static func apply_overlay(cards: Dictionary) -> String:
	# Startup already proved immutable files. No disk reads or normalization here.
	if cards.has(ID): return "partial_3702_vibrant_bubble_spell_changed_whole_baseline"
	var merged: Dictionary={};merged.merge(EFFECTIVE_FIELDS,true)
	if not same(merged,EXPECTED_CURRENT): return "partial_3702_vibrant_bubble_spell_changed_effective_derivation"
	cards[ID]=merged
	return ""

static func source_error(card: Dictionary) -> String:
	# Small in-memory, typed, exact whole-current-row guard. No file access or hashing.
	if not accepts_id(card.get("id")): return "partial_3702_vibrant_bubble_spell_unknown_source"
	return "" if same(card,EXPECTED_CURRENT) else "partial_3702_vibrant_bubble_spell_changed_whole_effective_source"
