extends RefCounted
## Pinned Cursed Crystal revision. Partial holds and previous proof boundaries remain.
const REVISION: String="partial-37.0.2-timewarp_theotar-rebuilt-20261107"
const ID: String="BG34_Giant_335"
const OVERLAY: String="data/patch_3702_timewarp_theotar_overlay.json"
const FILE_SHA256: Dictionary={"data/patch_3702_timewarp_theotar_overlay.json":"67f0ab5a9c2709beacc2db5abf15e1ef9df29d67586737d12a1e102d7b1ef171","research/patch_3702_timewarp_theotar/BG34_Giant_335.native.xml":"1268ee53c55b5c1778d957e5dcd82b81b48bac66d5835e160384cf7ec4a152d6","research/patch_3702_timewarp_theotar/evidence.json":"86d81f55450352fe718949dd23adbf81743827c284bbcca0ebd279215909ddd3","core/recruit_extensions.gd":"05b0e1eb6b98fe44d30f909dca598bd4d273c3dc967c33f90beb24d592b5cdd9","core/timewarp_theotar_sources.gd":"f15e56ab3098ee8c0fe16d8ac97996408aabfee24d0ca1dd08ca20650ba62d1c","core/game.gd":"2373572c775251faf58677e87ccaf353d1132259a97fad99e27d575490be4778","core/combat.gd":"d341b6c2afd08018822ffbdb1399382c95c072916269425fdf8b50b8484683ca"}
const RUNTIME_PATHS: Array=["core/patch_3702_timewarp_theotar_sources.gd","core/catalog.gd","data/patch_3702_timewarp_theotar_overlay.json","research/patch_3702_timewarp_theotar/BG34_Giant_335.native.xml","research/patch_3702_timewarp_theotar/evidence.json","core/recruit_extensions.gd","core/timewarp_theotar_sources.gd","core/game.gd","core/combat.gd"]
const EXPECTED_RAW: Dictionary={}
const EXPECTED_COMPILED: Dictionary={}
const EXPECTED_BASELINE: Dictionary={}
const EFFECTIVE_FIELDS: Dictionary={"id":"BG34_Giant_335","card_code":"BG34_Giant_335","dbf_id":"127501","name":"时空扭曲西塔尔","kind":"minion","category":"随从","categories":["随从","时空扭曲"],"mechanisms":["时空扭曲"],"tier":5,"attack":8,"health":8,"cost":null,"tribes":["全部"],"keywords":[],"effects":[{"type":"on_play_timewarp_theotar","source_id":"BG34_Giant_335","attack":6,"health":6}],"text":"在你使用没有类型的随从牌后，使每个类型的各一个友方随从获得+6/+6。","supported":true,"default_pool":false,"pool_supported":false,"is_golden":false,"normal_id":null,"golden_id":"BG34_Giant_335_G","image":"","solo_eligible":true,"source_url":"https://github.com/HearthSim/hsdata","native_source_build":"37.0.2.256589","native_chronum_cost":2,"coverage_text_sha256":"118ea0a7bcbfdf387d632aaa91f64a7dd5773180b2e9ff0bcbb2aa7ee424efb9","implementation_status":"partial_native_factory_fixture","conditional_support":{"rule":"timewarp_theotar_typeless_play_rebuilt_20261107","reason":"Native typeless play listener, source-inclusive distinct recipient type matching using existing local randomized maximum matching. Natural parent acquisition, official RNG equivalence, broad compositions and golden gameplay unvalidated. New reconstruction, not recovery of lost checkpoint."},"pool_blocker":"没有已确认的普通商店随从资格；衍生物、伙伴或时空扭曲内容需由对应机制生成，或显式配置自定义入店参数。"}
const EXPECTED_CURRENT: Dictionary={"id":"BG34_Giant_335","card_code":"BG34_Giant_335","dbf_id":"127501","name":"时空扭曲西塔尔","kind":"minion","category":"随从","categories":["随从","时空扭曲"],"mechanisms":["时空扭曲"],"tier":5,"attack":8,"health":8,"cost":null,"tribes":["全部"],"keywords":[],"effects":[{"type":"on_play_timewarp_theotar","source_id":"BG34_Giant_335","attack":6,"health":6}],"text":"在你使用没有类型的随从牌后，使每个类型的各一个友方随从获得+6/+6。","supported":true,"default_pool":false,"pool_supported":false,"is_golden":false,"normal_id":null,"golden_id":"BG34_Giant_335_G","image":"","solo_eligible":true,"source_url":"https://github.com/HearthSim/hsdata","native_source_build":"37.0.2.256589","native_chronum_cost":2,"coverage_text_sha256":"118ea0a7bcbfdf387d632aaa91f64a7dd5773180b2e9ff0bcbb2aa7ee424efb9","implementation_status":"partial_native_factory_fixture","conditional_support":{"rule":"timewarp_theotar_typeless_play_rebuilt_20261107","reason":"Native typeless play listener, source-inclusive distinct recipient type matching using existing local randomized maximum matching. Natural parent acquisition, official RNG equivalence, broad compositions and golden gameplay unvalidated. New reconstruction, not recovery of lost checkpoint."},"pool_blocker":"没有已确认的普通商店随从资格；衍生物、伙伴或时空扭曲内容需由对应机制生成，或显式配置自定义入店参数。"}

static func accepts_id(value: Variant) -> bool:
	return value is String and value==ID

static func same(actual: Variant,expected: Variant) -> bool:
	# JSON integral floats are admissible. Booleans/strings/fractions/nonfinite values are not numbers.
	if expected is int or expected is float:
		return (actual is int or actual is float) and not actual is bool and is_finite(float(actual)) and is_finite(float(expected)) and actual==floor(actual) and expected==floor(expected) and actual==expected
	if typeof(actual)!=typeof(expected): return false
	if expected is Dictionary:
		if actual.size()!=expected.size(): return false
		for key in expected:
			if not actual.has(key) or not same(actual[key],expected[key]): return false
		return true
	if expected is Array:
		if actual.size()!=expected.size(): return false
		for index in range(expected.size()):
			if not same(actual[index],expected[index]): return false
		return true
	return actual==expected

static func proof_error() -> String:
	# Startup-only disk proof. Hot source_error/program/get_card never calls this.
	for path in FILE_SHA256:
		if not FileAccess.file_exists("res://"+path) or FileAccess.get_sha256("res://"+path)!=FILE_SHA256[path]: return "partial_3702_timewarp_theotar_evidence_changed:"+str(path)
	var packet: Variant=JSON.parse_string(FileAccess.get_file_as_string("res://"+OVERLAY))
	var expected_packet: Dictionary={"revision":REVISION,"cards":[{"id":ID,"expected_raw":EXPECTED_RAW,"expected_compiled":EXPECTED_COMPILED,"expected_baseline":EXPECTED_BASELINE,"effective_fields":EFFECTIVE_FIELDS}]}
	if not same(packet,expected_packet): return "partial_3702_timewarp_theotar_changed_packet"
	var baseline: Dictionary=EXPECTED_RAW.duplicate(true);baseline.merge(EXPECTED_COMPILED,true)
	if not same(baseline,EXPECTED_BASELINE): return "partial_3702_timewarp_theotar_invalid_baseline_derivation"
	baseline.merge(EFFECTIVE_FIELDS,true)
	if not same(baseline,EXPECTED_CURRENT) or str(EXPECTED_CURRENT.text).sha256_text()!=EXPECTED_CURRENT.coverage_text_sha256: return "partial_3702_timewarp_theotar_invalid_current_derivation"
	return ""

static func input_error(decoded: Variant,path: String) -> String:
	# Called before generic numeric normalization. Historical input is authenticated in full.
	var expected: Dictionary={}
	if path=="res://data/catalog_raw.json": expected=EXPECTED_RAW
	elif path=="res://data/catalog.json": expected=EXPECTED_COMPILED
	if not decoded is Dictionary or not decoded.get("cards") is Array:
		return "partial_3702_timewarp_theotar_missing_input:"+path if not expected.is_empty() else ""
	var matches: Array=[]
	for card in decoded.cards:
		if card is Dictionary and accepts_id(card.get("id")): matches.append(card)
	if expected.is_empty(): return "" if matches.is_empty() else "partial_3702_timewarp_theotar_unexpected_input:"+path
	if matches.size()!=1: return "partial_3702_timewarp_theotar_missing_or_duplicate_input:"+path
	return "" if same(matches[0],expected) else "partial_3702_timewarp_theotar_changed_whole_input:"+path

static func apply_overlay(cards: Dictionary) -> String:
	if cards.has(ID): return "timewarp_theotar_unexpected_existing_source"
	cards[ID]=EXPECTED_CURRENT.duplicate(true)
	return ""

static func source_error(card: Dictionary) -> String:
	# Small in-memory, typed, exact whole-current-row guard. No file access or hashing.
	if not accepts_id(card.get("id")): return "partial_3702_timewarp_theotar_unknown_source"
	return "" if same(card,EXPECTED_CURRENT) else "partial_3702_timewarp_theotar_changed_whole_effective_source"
