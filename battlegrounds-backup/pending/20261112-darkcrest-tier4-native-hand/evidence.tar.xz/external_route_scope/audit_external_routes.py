from pathlib import Path
import json,re,hashlib
ROOT=Path('/workspace/scratch/dd4f12b08ec0/develop_20261112_darkcrest/fresh_remote/restored_darkcrest_candidate')
OLD=Path('/workspace/scratch/dd4f12b08ec0/develop_20261112_rider/fresh_remote/restored_rider_candidate')
OUT=Path(__file__).parent
TOKENS={'BG31_920t','BG31_920_Gt'}
def const(path,name):
    m=re.search(r'^const '+name+r'[^=]*=\s*(.*)$',(ROOT/path).read_text(),re.M)
    assert m,(path,name)
    return json.loads(m.group(1))
def cards(root,name):
    value=json.loads((root/name).read_text())['cards']
    return {c['id']:c for c in value} if isinstance(value,list) else value
pairs=const('core/random_spellcraft_sources.gd','PAIRS')
vashj=const('core/vashj_resource_sources.gd','DEPENDENCIES')
zesty=const('core/zesty_spellcraft_sources.gd','CHILDREN')
assert len(pairs)==20 and not (TOKENS & set(pairs.values()))
assert not(TOKENS & set(vashj)) and not(TOKENS & set(zesty))
scope=json.loads((ROOT/'data/current_scope_manifest.json').read_text())
minions=set(scope['official']['minion_ids']+scope['naga_overlay']['minion_ids'])
spells=set(scope['official']['spell_ids']+scope['optional']['naga_spell_ids'])
old_cards=cards(OLD,'data/catalog.json');old_raw=cards(OLD,'data/catalog_raw.json')
for id in TOKENS:
    assert old_cards[id]['supported'] is True
    assert old_cards[id]['effects']==[{'type':'spell_generate_tier_one_naga','count':2 if '_G' in id else 1}]
for id in ['BG31_920','BG31_920_G']:
    assert old_raw[id]['supported'] is False
    assert id not in old_cards
paths=['core/random_spellcraft_sources.gd','core/random_spellcraft_host.gd','core/combat_spellcraft_resources.gd','core/refresh_spellcraft_clock.gd','core/vashj_resource_sources.gd','core/zesty_spellcraft_sources.gd']
records=[]
for path in paths:
    current=(ROOT/path).read_bytes();older=(OLD/path).read_bytes()
    assert current==older
    records.append({'path':path,'identical_to_rider':True,'sha256':hashlib.sha256(current).hexdigest()})
result={'method':'read-only static JSON/source audit; no Game or Godot runtime executed','current_root':str(ROOT),'baseline_root':str(OLD),'random_spellcraft_pairs':pairs,'target_tokens_in_random_domain':sorted(TOKENS & set(pairs.values())),'vashj_dependency_count':len(vashj),'target_tokens_in_vashj_dependencies':sorted(TOKENS & set(vashj)),'zesty_child_count':len(zesty),'target_tokens_in_zesty_children':sorted(TOKENS & set(zesty)),'scope_membership':{id:{'minion':id in minions,'spell':id in spells} for id in ['BG31_920','BG26_505','BG32_836','BG23_014','BG34_Giant_211','BG34_Giant_322','BG26_590','BG23_HERO_304_Buddy','BG28_606','BG34_Treasure_950']},'identical_files':records,'assertions':'PASS'}
(OUT/'static_audit.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'assertions':'PASS','random_domain_size':len(pairs),'target_tokens_present':False,'vashj_dependencies':len(vashj),'zesty_children':len(zesty),'identical_baseline_files':len(records)},ensure_ascii=False))
