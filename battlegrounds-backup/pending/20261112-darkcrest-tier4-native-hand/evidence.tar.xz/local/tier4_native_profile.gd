extends SceneTree
const IDS=["BG26_505","BG34_925","BG33_319","BG36_508","BG35_921"]
var passed=0
func check(ok: bool,label: String) -> bool:
 print("PASS " if ok else "FAIL ",label)
 if not ok:quit(1);return false
 passed+=1;return true
func _initialize():
 print("LOAD_BEGIN")
 var Game=load("res://core/game.gd")
 if not check(Game!=null and Game.can_instantiate(),"complete_game"):return
 var cat=load("res://core/catalog.gd").new();cat.load_catalog()
 if not check(cat.load_errors.is_empty(),"complete_catalog"):print(JSON.stringify(cat.load_errors));return
 var game=Game.new();var room=load("res://core/room_config.gd").new();room.reset(cat)
 room.data.enabled_minions=IDS+["BG36_921"];room.data.enabled_spells=["BG28_810"];room.data.selected_hero="TB_BaconShop_HERO_01";room.data.enabled_heroes=["TB_BaconShop_HERO_01"];room.data.bot_count=1;room.data.seed=20261114
 for key in ["enabled_anomalies","enabled_quests","enabled_rewards","enabled_trinkets"]:room.data[key]=[]
 if not check(game.start(room.data,cat).get("ok",false),"actual_profile_room"):return
 var p=game.state.players[0]
 for index in range(3):
  var coin=game._unit(cat.get_card("BG28_810"));game._add_hand(p,coin)
  if not check(game.apply_command(0,{"type":"play","index":p.hand.find(coin),"target":-1,"position":-1}).get("ok",false),"actual_tavern_coin_"+str(index)):return
 var records={};var units={}
 for id in IDS:
  records[id]=cat.get_card(id).duplicate(true)
  var unit=game._unit(records[id])
  if not check(not unit.is_empty(),"actual_factory_"+id):return
  game._add_hand(p,unit)
  if not check(p.hand.any(func(x):return is_same(x,unit)) and game.state.phase=="recruit","actual_native_hand_delivery_"+id):return
  units[id]=unit.duplicate(true)
  var extra=[]
  for key in unit:
   if key not in Game.Rider.UNIT_FIELDS:extra.append(str(key))
  print("PROFILE ",JSON.stringify({"id":id,"name":unit.name,"attack":unit.attack,"health":unit.health,"extra_fields":extra,"pool_count":unit.pool_count}))
 if not check(game.GlobalCards.player_error(p).is_empty(),"native_global_owner_layer_valid"):return
 var result={"scope":"actual factory plus original add_hand profiling; NOT stock-owned Darkcrest generation","cards":records,"units":units,"global_counters":p.get(game.GlobalCards.STATE),"checks":passed}
 var output=get_script().resource_path.get_base_dir()+"/TIER4_NATIVE_PROFILE.json"
 var file=FileAccess.open(output,FileAccess.WRITE)
 if not check(file!=null,"profile_output_file"):return
 file.store_string(JSON.stringify(result,"  ")+"\n");file.close()
 print("TIER4_NATIVE_PROFILE_PASS checks=",passed)
 quit(0)
