"""Read-only static audit. Never imports/starts Godot or writes to the input tree."""
from pathlib import Path
import hashlib, json, re
ROOT = Path('/workspace/scratch/dd4f12b08ec0/develop_20261112_darkcrest/fresh_remote/restored_darkcrest_candidate')
OUT = Path(__file__).resolve().parent
IDS = ['BG26_505','BG34_925','BG33_319','BG36_508','BG35_921']
read_paths = set()
def read(path):
    read_paths.add(path)
    return (ROOT/path).read_text()
def js(path): return json.loads(read(path))
def const(path, name):
    m = re.search(r'^const '+re.escape(name)+r'(?:\s*:\s*\w+)?\s*=\s*(.+)$', read(path), re.M)
    assert m, (path,name)
    return json.loads(m[1])
raw={x['id']:x for x in js('data/catalog_raw.json')['cards']}
compiled={x['id']:x for x in js('data/catalog.json')['cards']}
merged={i:c|compiled.get(i,{}) for i,c in raw.items()}
scope=js('data/current_scope_manifest.json')
enabled=(set(scope['official']['minion_ids'])|set(scope['naga_overlay']['minion_ids']))-set(scope['excluded_aberration_minion_ids'])
tier4=sorted(i for i in enabled if i in merged and merged[i].get('tier')==4 and set(merged[i].get('tribes',[]))&{'纳迦','全部','all'})
assert tier4==sorted(IDS),tier4
modules={'BG26_505':'zesty_spellcraft_sources.gd','BG34_925':'seafloor_cast_sources.gd','BG33_319':'stat_spell_resource_sources.gd','BG36_508':'cagey_autocast_sources.gd','BG35_921':'abyssal_striker_sources.gd'}
rows=[]
for i in IDS:
    path='core/'+modules[i]
    c=merged[i]
    assert c['supported'] is True and c['pool_supported'] is True and c['default_pool'] is False
    assert c['kind']=='minion' and c['is_golden'] is False and c['tier']==4
    if i!='BG33_319':
        module_raw=const(path,'RAW'); module_compiled=const(path,'EXPECTED')
        assert raw[i]==module_raw[i],i
        assert compiled[i]==module_compiled[i],i
        source_check='exact whole raw and compiled dictionaries match module RAW/EXPECTED'
    else:
        source=const(path,'SOURCES')[i]
        assert all(c.get(k)==v for k,v in source.items()),i
        source_check='all native SOURCES keys match; separate full raw+compiled record retained'
    rows.append({'id':i,'name':c['name'],'native_stats':[c['attack'],c['health']],'keywords':c['keywords'],'effects':c['effects'],'source_module':path,'source_check':source_check,'raw_provenance':c['provenance'],'source_urls':c.get('source_urls',[])})
closure_checks={}
for f in ['zesty_spellcraft_sources.gd','seafloor_cast_sources.gd','cagey_autocast_sources.gd','abyssal_striker_sources.gd']:
    path='core/'+f
    module_raw=const(path,'RAW'); module_expected=const(path,'EXPECTED')
    checks={i:merged.get(i)==(module_raw[i]|module_expected[i]) for i in module_raw}
    assert all(checks.values()),(f,checks)
    closure_checks[f]=checks
for name in ['SOURCES','CANDIDATES']:
    checks={i:all(merged.get(i,{}).get(k)==v for k,v in c.items()) for i,c in const('core/stat_spell_resource_sources.gd',name).items()}
    assert all(checks.values()),(name,checks)
    closure_checks['stat_spell_resource_sources.gd:'+name]=checks
hand=js('research/darkcrest/hand_candidate_records.json')
host_fields=const('core/rider_host.gd','UNIT_FIELDS')
assert all(i not in hand for i in IDS)
assert 'zesty_spellcraft_turn' not in host_fields
assert 'bulk_global_card_applied' not in host_fields
assert 'unit[STATE]={"source_id":unit.card_id,"uid":unit.uid,"used_round":0}' in read('core/zesty_spellcraft_sources.gd')
assert 'const MARKER: String = "bulk_global_card_applied"' in read('core/bulk_global_card_stats.gd')
for p in ['core/game.gd','core/darkcrest_host.gd','core/darkcrest_sources.gd','core/bulk_random_resource_host.gd','core/limited_turn_state.gd','tests/darkcrest_20261112/real_matrix.gd','tests/darkcrest_20261112/README.md']:
    read(p)
report={'status':'PASS_STATIC_AUDIT_ONLY','game_started':False,'factory_executed':False,'runtime_acceptance':False,'input_root':str(ROOT),'scope_revision':scope['revision'],'complete_current_scope_tier4_naga_or_all':tier4,'sources':rows,'static_family_contract_checks':closure_checks,'historical_hand_tier4':[i for i,c in hand.items() if c.get('tier')==4],'stat_spell_factory_closure_ids':const('core/stat_spell_resource_sources.gd','IDS'),'stat_spell_factory_closure_candidates':list(const('core/stat_spell_resource_sources.gd','CANDIDATES')),'source_hashes':{p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in sorted(read_paths)}}
(OUT/'STATIC_AUDIT.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
(OUT/'TIER4_COMPLETE_STATIC_RECORDS.json').write_text(json.dumps({'scope':'Complete source records derived by raw | compiled only. Must compare against actual loaded Catalog before admission; not a runtime snapshot.','records':{i:{'raw':raw[i],'compiled':compiled[i],'merged_static':merged[i]} for i in IDS}},ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'status':report['status'],'ids':tier4,'raw_exact_modules':4,'native_subset_module':1,'input_unchanged_by_script':True,'game_started':False},ensure_ascii=False))
