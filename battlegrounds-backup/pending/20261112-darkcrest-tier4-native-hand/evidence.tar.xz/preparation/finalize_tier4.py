from pathlib import Path
import hashlib,json
r=Path(__file__).resolve().parent;p=r/'game_candidate';e=r/'evidence'
assert json.loads((e/'darkcrest_tier4_matrix_result.json').read_text())['exit']==0
discovery=json.loads((e/'TIER4_MATRIX_RESULT.json').read_text());seeds=[];seen=set()
for case in discovery['cases']:
 if case['id'] not in seen:seeds.append(case['seed']);seen.add(case['id'])
assert len(seeds)==5 and seeds[0]==20261112
(e/'TIER4_DISCOVERY_RESULT.json').write_text(json.dumps(discovery,indent=2)+'\n')
(e/'BEFORE_TIER4_FINAL_HASHES.json').write_text(json.dumps({f.relative_to(p).as_posix():hashlib.sha256(f.read_bytes()).hexdigest() for f in p.rglob('*') if f.is_file()},indent=2)+'\n')
f=p/'core/darkcrest_host.gd';s=f.read_text();old='''\tif id in TierFour.IDS:
		var view: Dictionary=TierFour.comparison_view(game,p,u)
		if not view.ok: return str(view.error)
		var issue: String=hand_state_error(view.unit,card,game.Rider.UNIT_FIELDS)'''
new='''\tif id in TierFour.IDS:
		# Reject malformed ordinary fields before native history projections.
		# This disposable shape is never used as an actor or passed to projection.
		var shape: Dictionary=u.duplicate(true)
		if id=="BG26_505": shape.erase(game.Zesty.Sources.STATE)
		if id=="BG35_921":
			shape.erase(game.GlobalCards.MARKER)
			for key in ["attack","health","max_health"]:
				if not u.get(key) is int: return "darkcrest_invalid_abyssal_stat_type"
			shape.attack=int(card.attack);shape.health=int(card.health);shape.max_health=int(card.health)
		var issue: String=hand_state_error(shape,card,game.Rider.UNIT_FIELDS)
		if not issue.is_empty(): return issue
		var view: Dictionary=TierFour.comparison_view(game,p,u)
		if not view.ok: return str(view.error)
		issue=hand_state_error(view.unit,card,game.Rider.UNIT_FIELDS)'''
assert old in s;s=s.replace(old,new);f.write_text(s)
f=p/'tests/darkcrest_tier4_20261112/real_matrix.gd';s=f.read_text().replace('"bad_stats","extra"','"bad_stats","null_tribes","bad_effects","bad_keywords","bad_stat_type","extra"').replace('   "extra":bad.activate_used_round','   "null_tribes":bad.tribes=null\n   "bad_effects":bad.effects=7\n   "bad_keywords":bad.keywords={}\n   "bad_stat_type":bad.attack="bad"\n   "extra":bad.activate_used_round').replace('for value in [0,3,high,high+1]:','for value in [0,1,3,high,high+1]:').replace('var held=command(0,','var held=game.apply_command(0,').replace('held=command(0,','held=game.apply_command(0,')
s=s.replace(' for index in range(24):\n  if not tier4_case(20261112+index,index==0):return\n  if coverage.size()==5:break',' var fixture_seeds='+json.dumps(seeds,separators=(',',':'))+'\n for index in range(fixture_seeds.size()):\n  if not tier4_case(fixture_seeds[index],index==0):return');f.write_text(s)
replacements={
'darkcrest-native-eot-candidate-20261112':'darkcrest-tier4-native-hand-candidate-20261112',
'partial_darkcrest_native_eot_verified_slice':'partial_darkcrest_tier4_native_hand_verified_slice',
'darkcrest_native_eot_candidate_20261112':'darkcrest_tier4_native_hand_candidate_20261112',
'Real Game limited slice: fresh ordinary native shop acquisition; original end-of-turn scheduler, tier 1/2/3 stock-weighted generation, waiting and expiry. Tier 4 is an admission boundary, not an official cap. Golden, post-grant purchase, mixed boards, inheritance and saves held.':'Real Game limited slice: fresh ordinary native shop acquisition; original end-of-turn scheduler, tier 1 through 4 stock-weighted generation, waiting and expiry. Tier 4 admits the complete five current Naga candidates and their native unplayed hand histories. Tier 4 remains an admission boundary, not an official cap. Golden, post-grant purchase, mixed boards, inheritance and saves held.'}
for name in ['core/darkcrest_sources.gd','data/darkcrest_overlay.json']:
 f=p/name;s=f.read_text()
 for a,b in replacements.items():assert a in s,(name,a);s=s.replace(a,b)
 f.write_text(s)
# Keep historical scripts unchanged, but explicitly retire their now-obsolete tier4 hold assertion.
f=p/'tests/darkcrest_20261112/README.md';s=f.read_text();s+='\n## 后续版本说明\n\n本目录real_matrix.gd保留上一批历史断言，其中“4级必须拒绝”已被新Tier4受限实现取代。当前版本请运行tests/darkcrest_tier4_20261112/real_matrix.gd；它继承本文件的原生准备/等待测试，并覆盖1至4级生成及原生等待回归，不执行旧4级拒绝断言。其它纯合同仍有效。历史日志不是本版验收。\n';f.write_text(s)
(p/'tests/darkcrest_tier4_20261112/README.md').write_text('''# 暗潮4级完整随机域与原生手牌验证

Godot 4.6.3，完整Game进程串行运行，建议1800秒软时限与至少4GiB可用内存。

    godot --headless --path <工程> --script <工程>/tests/darkcrest_tier4_20261112/real_matrix.gd

矩阵继承上一批真实准备/等待方法，不能只拷本文件而遗漏旧脚本。通过房间初始seed进行独立真实对局，不改运行中RNG、库存、UID、等级、手牌或候选。启用当前完整5名4级娜迦；重复真实来源购买、出牌、原生EOT与战斗，直到观察5种原始加权结果。每次核对完整域、随机票、库存、UID、消耗、原生历史层和下回合保留。酒馆币筹资是实际工厂/入手/公开施法的测试准备，不冒充普通商店取得币。

负例只修改脱离真实状态的深副本。异常数组、属性类型、UID、原生base、ownership、Zesty次数历史、Abyssal全局历史层、额外buff与未知字段均必须安全拒绝，并确认真实状态不变。先验证常规形状，再在原对象上只读调用原生历史投影，最后对副本剥层并复核印刷体。数值边界是纯合同，不冒充游戏自然累积极值。

覆盖1/2/3级受影响回归与满手双来源等待。4→5明确继续拒绝；与其他随从混合出牌、金色/三连/复制、存档和全游戏未验收。5名生成随从自身全部能力不属于本测试验收。
''')
print('FINAL_TIER4_SHAPE_GUARD_METADATA_AND_TESTS_PREPARED')
