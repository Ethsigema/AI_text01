from pathlib import Path
r=Path(__file__).resolve().parent;p=r/'game_candidate';f=p/'core/darkcrest_tier_four.gd';s=f.read_text().replace('const Global=preload("res://core/bulk_global_card_stats.gd")\n','').replace('const Zesty=preload("res://core/zesty_spellcraft_sources.gd")\n','').replace('history_error(player: Dictionary)','history_error(game,player: Dictionary)').replace('history_error(player)','history_error(game,player)').replace('Global.','game.GlobalCards.').replace('Zesty.','game.Zesty.Sources.')
s=s.replace('\tvar copy: Dictionary=unit.duplicate(true)','\tif not unit.get("uid") is String or unit.uid.is_empty(): return {"ok":false,"error":"darkcrest_hand_uid_required"}\n\tvar copy: Dictionary=unit.duplicate(true)');f.write_text(s)
f=p/'core/darkcrest_host.gd';s=f.read_text().replace('raw_id not in STRICT_HAND_BODIES and raw_id not in TierFour.IDS:','(raw_id not in STRICT_HAND_BODIES and raw_id not in TierFour.IDS):');f.write_text(s)
(p/'tests/darkcrest_tier4_20261112').mkdir(exist_ok=True)
(p/'tests/darkcrest_tier4_20261112/real_matrix.gd').write_text('''extends "res://tests/darkcrest_20261112/real_matrix.gd"
const T4=["BG26_505","BG33_319","BG34_925","BG35_921","BG36_508"]
var coverage={}
var records=[]
func quick_parent() -> Dictionary:
 var p=game.state.players[0]
 var index=find_parent()
 if not must(index>=0 and fund(6),"native_parent_offer_and_gold"):return {}
 var parent=p.shop[index]
 if not must(command(0,{"type":"buy","index":index}).get("ok",false) and p.hand.has(parent),"native_parent_purchase"):return {}
 return parent
func held_snapshot() -> Dictionary:
 var all=live_snapshot()
 # Public rejected commands are recorded by the normal dispatcher.
 all.erase("commands")
 return all
func rejection_contracts(unit: Dictionary) -> bool:
 var p=game.state.players[0]
 var before=live_snapshot()
 for mutation in ["missing_uid","empty_uid","bad_base","bad_pool","bad_kind","bad_stats","extra","missing_history","changed_history","foreign_history","used_history"]:
  var bad=unit.duplicate(true)
  match mutation:
   "missing_uid":bad.erase("uid")
   "empty_uid":bad.uid=""
   "bad_base":bad.base_unit.attack+=1
   "bad_pool":bad.pool_count=0
   "bad_kind":bad.pool_kind="spell"
   "bad_stats":bad.attack+=1
   "extra":bad.activate_used_round=game.state.round
   "missing_history":
    if unit.card_id=="BG26_505":bad.erase(game.Zesty.Sources.STATE)
    elif unit.card_id=="BG35_921":bad.erase(game.GlobalCards.MARKER)
    else:bad.temporary=true
   "changed_history":
    if unit.card_id=="BG26_505":bad[game.Zesty.Sources.STATE]=[]
    elif unit.card_id=="BG35_921":bad[game.GlobalCards.MARKER].value+=1
    else:bad.spellcraft_kept=1
   "foreign_history":
    if unit.card_id=="BG26_505":bad[game.Zesty.Sources.STATE].uid="u9999999"
    elif unit.card_id=="BG35_921":bad[game.GlobalCards.MARKER].owner=1
    else:bad.spell_triggers=1
   "used_history":
    if unit.card_id=="BG26_505":bad[game.Zesty.Sources.STATE].used_round=1
    elif unit.card_id=="BG35_921":bad[game.GlobalCards.MARKER].attack+=1
    else:bad.attachments=[{}]
  if not must(not game._darkcrest_host.hand_error(game,bad,p).is_empty(),"detached_reject_"+unit.card_id+"_"+mutation):return false
 if not must(game.Darkcrest.Sources.same(before,live_snapshot()),"all_detached_contracts_preserve_live_state_"+unit.card_id):return false
 return true
func history_contracts() -> bool:
 var p=game.state.players[0]
 var before=live_snapshot()
 var detached=p.duplicate(true)
 @warning_ignore("integer_division")
 var high: int=game.GlobalCards.MAX_COUNTER/2
 for value in [0,3,high,high+1]:
  detached[game.GlobalCards.STATE].tavern_spells=value
  if not must(game.GlobalCards.state_error(detached).is_empty(),"native_history_scalar_valid_"+str(value)):return false
  var issue=game.Darkcrest.TierFour.history_error(game,detached)
  if not must(issue.is_empty() if value<=high else issue=="bulk_global_card_amount_overflow","tier4_pre_rng_history_boundary_"+str(value)):return false
 return must(game.Darkcrest.Sources.same(before,live_snapshot()),"detached_numeric_contracts_preserve_live_state")
func tier4_case(seed_value: int,lower_regression: bool) -> bool:
 if not setup_room(seed_value):return false
 var p=game.state.players[0]
 var parent=quick_parent()
 if parent.is_empty() or not source_play(parent):return false
 for tier in [1,2,3]:
  var old_tokens=p.hand.filter(func(u):return u.card_id=="BG31_920t")
  if lower_regression and not cast_level(parent,tier):return false
  if not next_round(parent,tier+1):return false
  if not lower_regression and not must(not p.hand.any(func(u):return u.uid==old_tokens[0].uid),"native_uncast_token_expiry_tier"+str(tier)):return false
 var tokens=p.hand.filter(func(u):return u.card_id=="BG31_920t")
 if not must(tokens.size()==1 and game._darkcrest_host._spells[tokens[0].uid].tier==4,"actual_tier4_issued_token"):return false
 var token=tokens[0]
 var before_uids=p.hand.map(func(u):return u.uid)
 var before_stock=game.pool.duplicate(true)
 var before_spells=p.stats.spells
 var tavern_history=p[game.GlobalCards.STATE].tavern_spells
 var next_uid=game.next_uid
 var prior_event_count=game.events.size()
 var domain=game.BulkResourceHost.domain(game)
 var choices=game.BulkResourceHost.candidates(domain,domain.stock,{"kind":"minion","tier":4,"tribe":"纳迦"})
 if not must(choices.map(func(c):return c.id)==T4 and choices.all(func(c):return c.weight>0),"unchanged_full_five_positive_weight_tier4_domain"):print(JSON.stringify(choices));return false
 var total=0
 for choice in choices:total+=choice.weight
 if not must(command(0,{"type":"play","index":p.hand.find(token),"target":-1,"position":-1}).get("ok",false),"public_tier4_token_cast"):return false
 var obtained=p.hand.filter(func(u):return u.uid not in before_uids)
 if not must(obtained.size()==1,"one_actual_tier4_acquisition"):return false
 var unit=obtained[0]
 if not must(unit.card_id in T4 and unit.tier==4 and unit.uid=="u"+str(next_uid) and game.next_uid==next_uid+1,"original_factory_identity_and_uid"):return false
 if not must(unit.pool_id==unit.card_id and unit.pool_kind=="minion" and unit.pool_count==1,"actual_owned_stock_stamp"):return false
 var changed=[]
 for id in before_stock:
  if before_stock[id]!=game.pool.get(id):changed.append(id)
 if not must(changed==[unit.card_id] and game.pool[unit.card_id]==before_stock[unit.card_id]-1,"exact_selected_stock_debit_once"):return false
 var random_events=game.events.slice(prior_event_count).filter(func(e):return e.get("type")=="rng" and e.get("reason")=="random_generated_minion")
 if not must(random_events.size()==1 and random_events[0].range==total,"original_weighted_rng_draw_full_domain"):print(JSON.stringify(game.events.slice(prior_event_count)));return false
 var ticket=random_events[0].value
 var expected=""
 for choice in choices:
  if ticket<choice.weight:expected=choice.id;break
  ticket-=choice.weight
 if not must(expected==unit.card_id,"actual_ticket_matches_selected_complete_domain"):return false
 if not must(p.stats.spells==before_spells+1 and p[game.GlobalCards.STATE].tavern_spells==tavern_history and not p.hand.has(token),"spellcraft_consumed_once_not_a_tavern_spell"):return false
 if not must(game._darkcrest_host.hand_error(game,unit,p).is_empty() and game._darkcrest_host.owner_error(game,p).is_empty() and game.GlobalCards.player_error(p).is_empty(),"native_hand_and_owner_valid_after_tier4"):return false
 if unit.card_id=="BG26_505":
  if not must(unit[game.Zesty.Sources.STATE]=={"source_id":unit.card_id,"uid":unit.uid,"used_round":0},"native_fresh_zesty_history_retained"):return false
 if unit.card_id=="BG35_921":
  if not must(tavern_history>0 and unit.attack==2+2*tavern_history and unit.health==1+tavern_history and unit.max_health==unit.health and unit.base_unit.attack==2 and unit.base_unit.health==1,"native_abyssal_nonzero_tavern_history_and_printed_base"):return false
  if not must(unit[game.GlobalCards.MARKER]=={"owner":p.id,"counter":"tavern_spells","value":tavern_history,"attack":2*tavern_history,"health":tavern_history},"native_abyssal_exact_owner_layer"):return false
 if not coverage.has(unit.card_id) and not rejection_contracts(unit):return false
 if lower_regression and not history_contracts():return false
 if not must(command(0,{"type":"freeze"}).get("ok",false) and command(0,{"type":"freeze"}).get("ok",false),"ordinary_commands_preserve_tier4_hand"):return false
 var before=held_snapshot()
 var held=command(0,{"type":"play","index":p.hand.find(unit),"target":-1,"position":-1})
 if not must(not held.get("ok",true) and held.error=="darkcrest_other_play_held" and game.Darkcrest.Sources.same(before,held_snapshot()),"active_darkcrest_generated_card_play_still_held_without_mutation"):return false
 before=held_snapshot()
 held=command(0,{"type":"end_turn"})
 if not must(not held.get("ok",true) and held.error=="darkcrest_next_tier_outside_finite_candidate" and game.Darkcrest.Sources.same(before,held_snapshot()),"tier4_to5_admission_boundary_remains_held"):return false
 if not must(command(0,{"type":"sell","index":p.board.find(parent)}).get("ok",false),"native_sell_original_parent"):return false
 var old_round=game.state.round
 if not must(command(1,{"type":"end_turn"}).get("ok",false) and command(0,{"type":"end_turn"}).get("ok",false) and game.state.phase=="recruit" and game.state.round==old_round+1,"native_next_recruit_after_parent_sale"):return false
 if not must(p.hand.any(func(u):return is_same(u,unit)) and game._darkcrest_host.hand_error(game,unit,p).is_empty() and game.GlobalCards.player_error(p).is_empty(),"actual_tier4_hand_retained_across_round"):return false
 coverage[unit.card_id]=int(coverage.get(unit.card_id,0))+1
 var record={"seed":seed_value,"id":unit.card_id,"uid":unit.uid,"choices":choices,"rng":random_events[0],"tavern_history":tavern_history,"attack":unit.attack,"health":unit.health,"coverage":coverage.duplicate(true)}
 records.append(record)
 print("TIER4_CASE_PASS ",JSON.stringify(record))
 return true
func _initialize():
 print("TIER4_LOAD_BEGIN")
 var Game=load("res://core/game.gd")
 if not must(Game!=null and Game.can_instantiate(),"complete_game_script"):return
 cat=load("res://core/catalog.gd").new();cat.load_catalog()
 if not must(cat.load_errors.is_empty(),"complete_catalog"):print(JSON.stringify(cat.load_errors));return
 for index in range(24):
  if not tier4_case(20261112+index,index==0):return
  if coverage.size()==5:break
 if not must(coverage.size()==5,"all_five_real_unmodified_rng_outcomes_observed"):return
 if not waiting_case():return
 var result={"scope":"ordinary native Darkcrest tier4 full five-card domain and unplayed hand state; not ability or whole-scope acceptance","checks":checks,"coverage":coverage,"cases":records,"waiting_regression":true,"lower_tier_regression":true}
 var file=FileAccess.open(get_script().resource_path.get_base_dir()+"/TIER4_MATRIX_RESULT.json",FileAccess.WRITE)
 if not must(file!=null,"matrix_result_file"):return
 file.store_string(JSON.stringify(result,"  ")+"\\n");file.close()
 print("DARKCREST_TIER4_REAL_MATRIX_PASS cases=",records.size()," checks=",checks," coverage=",JSON.stringify(coverage))
 quit(0)
''')
(r/'evidence/darkcrest_tier4_matrix.gd').write_text('extends "res://tests/darkcrest_tier4_20261112/real_matrix.gd"\n')
