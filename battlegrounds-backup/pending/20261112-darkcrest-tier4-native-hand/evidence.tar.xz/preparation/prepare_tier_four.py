from pathlib import Path
import json,re,hashlib
r=Path(__file__).resolve().parent;p=r/'game_candidate';e=r/'evidence'
profile=json.loads((e/'TIER4_NATIVE_PROFILE.json').read_text());assert json.loads((e/'tier4_native_profile_result.json').read_text())['exit']==0
static=json.loads((r/'research_tier4/TIER4_COMPLETE_STATIC_RECORDS.json').read_text())['records']
ids=['BG26_505','BG33_319','BG34_925','BG35_921','BG36_508']
assert set(profile['cards'])==set(ids)
for id in ids:assert profile['cards'][id]==static[id]['merged_static']
(e/'BEFORE_TIER4_HASHES.json').write_text(json.dumps({f.relative_to(p).as_posix():hashlib.sha256(f.read_bytes()).hexdigest() for f in p.rglob('*') if f.is_file()},indent=2)+'\n')
helper='''extends RefCounted
## Finite native hand-state admission only. No live unit/stat/UID/pool writer.
const Sources=preload("res://core/darkcrest_sources.gd")
const Global=preload("res://core/bulk_global_card_stats.gd")
const Zesty=preload("res://core/zesty_spellcraft_sources.gd")
const IDS: Array=["BG26_505","BG33_319","BG34_925","BG35_921","BG36_508"]
static func history_error(player: Dictionary) -> String:
	var issue: String=Global.state_error(player)
	if not issue.is_empty(): return issue
	# The complete native BG35_921 program is fixed at +2/+1 per Tavern spell.
	# Match Global.projection's own numeric admission before the weighted draw.
	@warning_ignore("integer_division")
	var maximum: int=Global.MAX_COUNTER/2
	return "bulk_global_card_amount_overflow" if int(player[Global.STATE].tavern_spells)>maximum else ""
static func candidate_error(game,player: Dictionary,id: String) -> String:
	if id not in IDS: return ""
	var issue: String=""
	match id:
		"BG26_505": issue=game.Zesty.Sources.closure_error(game.catalog)
		"BG33_319": issue=game.StatSpellResources.Sources.closure_error(game.catalog)
		"BG34_925": issue=game.SeafloorCast.Sources.closure_error(game.catalog)
		"BG35_921":
			issue=game.GlobalCards.closure_error(game.catalog,id)
			if issue.is_empty(): issue=history_error(player)
		"BG36_508": issue=game.CageyCast.Sources.closure_error(game.catalog)
	return issue
static func comparison_view(game,player: Dictionary,unit: Dictionary) -> Dictionary:
	# A detached comparison view is not a minted actor or proof of acquisition.
	# The caller separately checks its complete source and original native shape.
	var id: String=str(unit.get("card_id",""))
	if id not in IDS: return {"ok":false,"error":"darkcrest_unknown_tier4_hand_identity"}
	if not player.get("id") is int or player.id<0 or player.id>=game.state.players.size() or not is_same(game.state.players[player.id],player): return {"ok":false,"error":"darkcrest_actual_tier4_hand_owner_required"}
	var copy: Dictionary=unit.duplicate(true)
	if id=="BG26_505":
		var issue: String=Zesty.unit_error(unit,int(game.state.round))
		if not issue.is_empty(): return {"ok":false,"error":issue}
		if unit[Zesty.STATE].used_round!=0: return {"ok":false,"error":"darkcrest_used_zesty_hand_held"}
		copy.erase(Zesty.STATE)
	if id=="BG35_921":
		var issue: String=history_error(player)
		if issue.is_empty(): issue=Global.unit_error(unit)
		if not issue.is_empty(): return {"ok":false,"error":issue}
		if not unit.has(Global.MARKER): return {"ok":false,"error":"darkcrest_abyssal_native_owner_layer_required"}
		var projected: Dictionary=Global.projection(player,unit,"hand")
		if not projected.ok: return projected
		if not Sources.same(projected.unit,unit): return {"ok":false,"error":"darkcrest_abyssal_owner_layer_not_current"}
		issue=Global.strip(copy)
		if not issue.is_empty(): return {"ok":false,"error":issue}
	return {"ok":true,"error":"","unit":copy}
'''
(p/'core/darkcrest_tier_four.gd').write_text(helper)
f=p/'core/darkcrest_host.gd';s=f.read_text();s=s.replace('const Sources=preload("res://core/darkcrest_sources.gd")','const Sources=preload("res://core/darkcrest_sources.gd")\nconst TierFour=preload("res://core/darkcrest_tier_four.gd")')
m=re.search(r'^const HAND_BODIES: Array=(.+)$',s,re.M);v=json.loads(m[1]);v+=ids;s=s[:m.start(1)]+json.dumps(v,separators=(',',':'))+s[m.end(1):]
s=s.replace('issue=hand_error(game,u)','issue=hand_error(game,u,p)')
s=s.replace('raw_id not in STRICT_HAND_BODIES:', 'raw_id not in STRICT_HAND_BODIES and raw_id not in TierFour.IDS:')
s=s.replace('func hand_error(game,u: Dictionary) -> String:', 'func hand_error(game,u: Dictionary,p: Dictionary={}) -> String:')
old='\tif id in STRICT_HAND_BODIES:\n\t\tvar issue: String=hand_state_error(u,card,game.Rider.UNIT_FIELDS)'
new='''\tif id in TierFour.IDS:
		var view: Dictionary=TierFour.comparison_view(game,p,u)
		if not view.ok: return str(view.error)
		var issue: String=hand_state_error(view.unit,card,game.Rider.UNIT_FIELDS)
		if issue.is_empty(): issue=game.LimitedTurn.validate_unit_state(u,game.state.round)
		if issue.is_empty(): issue=game.Thaumaturgy.unit_error(u)
		return issue
	if id in STRICT_HAND_BODIES:
		var issue: String=hand_state_error(u,card,game.Rider.UNIT_FIELDS)'''
assert old in s;s=s.replace(old,new)
old='\t\tissue=candidate_source_error(str(id),card)\n\t\tif not issue.is_empty(): return issue'
new=old+'\n\t\tissue=TierFour.candidate_error(game,p,str(id))\n\t\tif not issue.is_empty(): return issue';assert old in s;s=s.replace(old,new)
f.write_text(s)
f=p/'core/darkcrest_sources.gd';s=f.read_text();m=re.search(r'^const EXPECTED_HAND = (.+)$',s,re.M);v=json.loads(m[1]);v.update(profile['cards']);s=s[:m.start(1)]+json.dumps(v,ensure_ascii=False,separators=(',',':'))+s[m.end(1):]
(p/'research/darkcrest/hand_candidate_records.json').write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
new_paths=['core/darkcrest_tier_four.gd','core/zesty_spellcraft_sources.gd','core/zesty_spellcraft_host.gd','core/bulk_global_card_stats.gd','core/abyssal_striker_sources.gd','core/seafloor_cast_sources.gd','core/stat_spell_resource_sources.gd','core/cagey_autocast_sources.gd']
m=re.search(r'^const FILE_SHA256 = (.+)$',s,re.M);v=json.loads(m[1]);v.update({n:hashlib.sha256((p/n).read_bytes()).hexdigest() for n in new_paths});s=s[:m.start(1)]+json.dumps(v,ensure_ascii=False,separators=(',',':'))+s[m.end(1):]
m=re.search(r'^const RUNTIME_PATHS = (.+)$',s,re.M);v=json.loads(m[1]);v+= [n for n in new_paths if n not in v];s=s[:m.start(1)]+json.dumps(v,ensure_ascii=False,separators=(',',':'))+s[m.end(1):];f.write_text(s)
print('TIER4_DATA_AND_HAND_ADMISSION_PREPARED; GAMEPLAY_NOT_YET_VERIFIED')
