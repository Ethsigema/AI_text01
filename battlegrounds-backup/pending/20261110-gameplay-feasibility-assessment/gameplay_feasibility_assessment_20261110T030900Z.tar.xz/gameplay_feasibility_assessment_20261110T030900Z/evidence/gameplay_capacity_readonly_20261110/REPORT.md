# 低内存玩法测试能力只读检查

状态：STATIC_CAPACITY_REVIEW_ONLY，未执行任何新玩法测试。只执行了 Godot --version（4.6.3.stable.official.7d41c59c4）、只读内存信息，以及限定技术文件阅读/128MiB Python 依赖闭包检查。原 runtime、旧成果与存档均未写入；未启动 Game、Combat、Catalog、编译器或完整项目；未联网。

基准树：/workspace/scratch/dd4f12b08ec0/historical_tools_batch14_20261109T191857Z/runtime。

## 结论

无需先恢复完整 tools/build_effect_catalog.py，就能推进两个真实生产模块执行边界的独立行为候选。应将完整脚本逐字复制到一个新的最小 Godot 项目后调用，而不是抽取函数、改源码或伪造 res://core/game.gd。以下入口会写入测试玩家字典，超过纯注册/validator 测试，但不代表实际 Game 根命令、施法消费、触发派发、存档或 UI 已验收。

## 入口 1：南海卖艺者的次回合铸币

- 来源：普通 BG26_135，金色 BG26_135_G；原模块的 IDENTITIES 独立固定 +1/+2，不由普通翻倍推导。
- 文件及接口：core/delayed_minion_gold.gd:124 build_event；:285 commit_event；:302 settle_recruit。
- 最小脚本闭包：delayed_minion_gold.gd (20,877 B) → prime_mate_sources.gd (18,360 B) → pool_identity.gd (2,004 B)，合计 41,241 B。均 extends RefCounted，无静态实例初始化、Game/Combat/Catalog preload。
- 最小调用示意（在测试中对每个返回值检查 ok）：
  - p = {"id":0,"alive":true,"gold":5}
  - effect = Delayed.effects_for_id("BG26_135")[0]
  - built = Delayed.build_event(0,"BG26_135","u1",effect,3,"fixture:1",0,"recruit")
  - Delayed.commit_event(p,built.event)：直接写 p.minion_gold_ledger，gold 仍为 5。
  - Delayed.settle_recruit(p,4)：直接写 p.gold=6，receipt.paid_round=4。
- 可覆盖：普通/金色 +1/+2；同一事件重复不追加/不重付；同一事务索引内容冲突；错误 owner/phase/amount；ghost 跳过；死亡玩家跳过；错过约定回合拒绝；数值溢出；出售/移除来源后仍结算已赚收入；JSON 数字往返后继续结算。后者仅内存 JSON fixture，不读旧存档。
- 普通卖艺者路径不调用 PrimeMate.validation_evidence，因此执行闭包不需要 research/prime_mate_sources 证据文件。不要把这一点推广为领长副官可跳过证据。
- 未验证：真实战吼命令是否派发这个 event、下一回合普通收入的集成先后顺序。事件 fixture 不是 Game 触发证明。

## 入口 2：钻探原油的永久铸币上限 +1

- 来源：BG28_805，data/source_catalog/spells.json:20823 处第283行记录为“钻探原油”，文字为“你的铸币上限提高1枚。”；data/catalog.json:19394 起对应已有 overlay 是 [{"type":"spell_increase_max_gold","amount":1}]，当前 supported/default_pool=true。只是读取既有值，未改准入或重新证明编译结果。
- 文件及接口：core/gold_income.gd:37 handle_effect；实际修改在 :32 increase；下一回合基础收入计算在 :19 base_income。
- 最小脚本闭包：gold_income.gd 单文件 4,578 B，无 preload/load。有效 spell 分支只需一个带 state Dictionary 和 _log(name,payload) 方法的测试记录器；_log 记录调用而不接管资源运算。不是伪造 Game，也无需实现 EfficientEngineer。
- 最小调用示意：engine.state={"phase":"recruit"}；p={"id":0,"gold":5,"max_gold":10,"gold_income_bonus":0}；GoldIncome.handle_effect(engine,p,{"type":"spell_increase_max_gold","amount":1})。预期 max_gold=11、gold_income_bonus=1、当前 gold 保持5，且产生 max_gold_increased 日志。GoldIncome.base_income(p,10) 预期11。
- 可覆盖：99上限饱和、98→99、99不再增加、重复独立施法每次增加、非法类型/字段/增量进入 error 且不变更玩家、未知 type 返回 false。必须使用合法初始玩家状态；该 spell 叶的前置玩家校验依赖上层，不宣称它能拒绝所有坏玩家。
- 未验证：手牌消耗、费用、真正 source→effect 绑定、法术计数与监听者顺序。handle_effect 的 spell 分支并不校验 source card_id；用 BG28_805 的精确已有程序仅把测试语义绑定到该效果，不能当完整该卡通过。

## 不列为第三个真实提交入口

core/acquired_income_effects.gd 虽只有它与 gold_income.gd 两文件、20,497 B，但 :219 commit_plan 仅重验并返回 plan.duplicate(true)，不修改玩家。其“小费罐”+4现钱/+4上限路径仍由上层领取次数、现钱、GoldIncome.increase 和投递提交。不能将它报为饰品真实提交已测。其他已查看的小 host 有实际 Game 身份要求、整组派发或多级 preload；不为凑数量制造替代 executor。

## 现有 runner 与资源预估

- 当前 gates/gate.gd 只 preload Hand/Piranha 来源脚本并使用 MiniCatalog；不是玩法 runner。
- gates/run.py 是可复用的监管结构，不可原样当上述玩法测试：它的输入、mode、白名单 preload 集合及 CASES 均固定给上一批来源门禁，需在新的工作目录另建自己的白名单及测试脚本。
- 可复用限制：Python 128MiB；Godot 2GiB地址空间、2 CPU、串行、RSS达到192MiB停止、45秒、启动 MemAvailable≥1GiB、运行低于640MiB停止、5ms轮询；使用 os.wait4 报告实际 Godot PID 峰值RSS，遇 SCRIPT ERROR 停止并保留日志。
- 已有 after/PROCESS.json 的来源门禁历史测量为 69,208 KiB maxrss，1.83秒。这不是上述两项的新测量。上述脚本闭包小、无自动大目录扫描，预计接近该量级，192MiB内有合理尝试空间；但文件字节数不能保证RSS，首次受控运行才能给实测结论。
- 本轮主机 MemAvailable 约 8.8GiB，达到启动门槛；真正运行前仍需重查，同时拒绝已有其他Godot并行。版本查询出现 Fontconfig 无可写缓存提示，但返回版本成功；新 runner 应像现有 guard 一样把 HOME/XDG 指向新目录，避免读写用户缓存。

## 下一步最小范围

优先仅做入口1：复制三个原脚本，逐个hash相符，建立空 project.godot + SceneTree 测试；由守护进程串行启动，不拷贝 runtime 根、main.tscn、data 全量或 research 全量。通过后再给入口2建一文件独立测试。所有输出以 LEAF_BEHAVIOR_CANDIDATE 标识，保持完整Game、编译驱动、旧存档未验收。
