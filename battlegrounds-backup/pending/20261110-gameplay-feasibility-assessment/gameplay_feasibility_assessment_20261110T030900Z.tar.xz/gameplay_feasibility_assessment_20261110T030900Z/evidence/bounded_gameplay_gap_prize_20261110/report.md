# 只读玩法缺口：爱宠福利 → 挑衅的船工

结论：推荐只推进这一条具体组合。两张卡均已有当前 supported 映射，真实 Game 调度已存在；缺的是奖品的属性变化到原生获得攻击力监听之间的整组执行，不是注册或驱动恢复。

- 爱宠福利 BGS_Treasures_028（DBF66424）：友方随从永久圣盾、风怒、+15/+15。
- 挑衅的船工 BG21_018（DBF72061）：2/5；从其他来源获得攻击力后 +1生命。原始普通健康船工应从2/5成为17/21，关键词各一份，仅一次获得攻击力反应。+15不是触发15次。

## 已确认的真实调用顺序

core/game.gd：_play:4016 → _play_without_murder_hand_parent:4037；4672先调用_prize_play_error；5929/5948调用PrizeBuffs.cast_error；4980移除原手牌；法术分支5260开始，5484调用_apply_recruit_effect，6409调用PrizeBuffs.handle_effect。

core/prize_buff_effects.gd：cast_plan:230验证原生来源、实例、player区域/层并生成+15/+15和永久关键词的更新；cast_error:258只返回该计划的error。commit:263重建计划，269对获得攻击力监听直接返回attack_gain_prize_shadow_group_unimplemented；282 handle_effect将phase设error。已知拒绝在真实手牌移除之后，预检没有发现。该卡原生cost=0，不称额外扣金币。没有运行Game，不能宣称已复现实局损失或验证外层回滚。

## 可复用整组接口与实现边界

core/attack_gain_listeners.gd：reaction_plan:95在完整board shadow上按source/repeat/target顺序产生before/after记录；apply_reactions_to_shadow:126只写shadow；prepare_recruit:143核actual owner、原生反应和私有生命累计上界；commit_recruit:164核同一owner与record.before，每条走engine._buff并维护_attack_gain_health_totals、记attack_gain_health事件。Game._buff:6756/6791/6813已有这些真接口。

建议新增桥放入cast_plan整次预演：先模拟奖品原增益和关键词，再在同一player/board shadow投射完整AttackGain反应，累计全组数值和私有计数上界；commit重建比较完整计划后保留live字典引用提交。不能仅移除269的拒绝，也不能只末尾health+=1。若复用commit_recruit，记录的before必须包含已授予的奖品关键词，否则快照校验失败。真实_buff还有多种其他观察者，初始边界只允许原生普通018、纯数值健康体、无其他观察者/光环/临时层/阈值或复制继承交集，未知组合提前保留拒绝。放宽必须有对应整组投射，不能缩小候选或掩盖回调。

最小正常/异常用例：普通2/5→17/21并仅1次反应；无监听普通目标仅+15/+15；已持盾风怒不重复关键词；反应前生命为int64最大值、私有counter溢出、重复UID、变化/过期计划、错误原生effects、错误target zone全部在预检拒绝且原对象不变；提交仍保留原引用。完整Game手牌/经济原子性另行集成验收，不能用受限host替身替代该结论。

## 本地来源证据与局限

research/native_prize_entities.json:184含028完整未改写XML；独立重算实体sha256=120e8707e431dbd8b6524364acf81b9ea34392ec85ee74c0f23f7512991b7564一致；两个TAG_SCRIPT_DATA_NUM为15。其来源pin为HearthSim/hsdata commit 27fbd2323aec20cab1c6ecc7d5f55cf12729f956，build36.6.3.253932，CardDefs.Bacon.xml。

research/attack_gain_sources/native_quantities.json:37给出普通018完整效果文本模板、ATK2/HEALTH5、TAG_SCRIPT_DATA_NUM_2=1；raw_rows.json:2提供中文全文、DBF、普通/金色链接、工作簿第907行和wiki oldid160337；raw_rows:201同一hsdata commit URL。programs.json:2和expected_compiled.json明确health1/repeats1。当前data/catalog.json:18539、45269两者supported=true。

该副本缺少上述完整CardDefs主文件；只能声明本地完整028实体hash已核，018本地抽取数值+工作簿/wiki+commit pin互证，不能声称重新核过整份源文件或普通推导金色。此任务不需联网补源，也不扩大到金色。

## 不依赖完整编译driver的原因

两张卡的当前源行和compiled overlay已存在；可用不可变两卡catalog fixture直接调用真实PrizeBuffs.cast_plan/apply/commit及现有AttackGain接口，测试真实提交的属性、关键词、私有counter、原对象引用和异常不变性，不必生成新catalog或跑完整Game。preload闭包是247个现有原字节脚本、7318392字节、无Game、无缺失（附SHA清单）。这只是静态闭包大小，不保证192MiB下实际可加载；由能力测试单独判定。若原字节闭包解析/资源失败，应报告阻塞而不是stub所有依赖后声称真实链通过。

## 排除项

旧runtime_coverage/effect_coverage大幅落后当前catalog，不作新缺口依据。南海卖艺者的delayed_minion_gold已有Game6398、10434、11710和Combat6182真实排队/结算，不作为新增玩法。Alleycat纯数值/层交集依赖846文件21.5MB且语义更宽，不作更小备选。

本调查只读取技术源码、目录和研究证据，没有修改runtime旧文件、没有编写玩法代码、没有执行Godot/Game/完整Catalog/完整driver、没有网络访问。
