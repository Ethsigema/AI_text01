extends SceneTree
const PrizeBuffs = preload("res://core/prize_buff_effects.gd")
func _initialize() -> void:
	print("PRIZEBUFFS_PRELOAD_ONLY_OK")
	quit(0)
