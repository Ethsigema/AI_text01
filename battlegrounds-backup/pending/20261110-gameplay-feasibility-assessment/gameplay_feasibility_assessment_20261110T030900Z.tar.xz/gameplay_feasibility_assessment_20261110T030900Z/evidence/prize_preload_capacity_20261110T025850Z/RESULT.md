# PrizeBuffs 原字节闭包加载能力实测

结果：受控 RSS 停止，未完成 preload。不是玩法失败，也没有验收任何效果。

- 目标：原 core/prize_buff_effects.gd 的实际 preload 闭包，仅执行 preload→打印成功标记→quit。
- 源树：/workspace/scratch/dd4f12b08ec0/historical_tools_batch14_20261109T191857Z/runtime。
- 闭包：247 个原字节脚本，7,318,392 字节；不存在 Game/Combat/Catalog，未发现 class_name 或 _static_init。精确 manifest 与边存于 INPUT_MANIFEST.json。
- 原源码以 copyfile 复制到全新 project/core；运行前后每文件 SHA256 均与固定输入相同。不改依赖、不提取/替换函数、不使用 stub、不调用任何 PrizeBuffs 方法。
- 环境：Godot 4.6.3，单次串行，2 CPU；启动可用内存超过1GiB，无其他Godot进程。HOME/XDG指向本次新结果目录。
- 限额保持：Godot 2GiB地址空间，RSS192MiB停止，45秒超时，运行可用内存低于640MiB停止；Python128MiB。
- 实测：1.2438436秒；reason=controlled_RSS_stop；exit=-15；os.wait4 maxrss=196,588 KiB；采样RSS峰值=201,486,336字节（超过192MiB阈值201,326,592字节）。两个指标来自不同内核采样口径，均原样保留。
- 成功标记未出现。native.log只有Godot版本，无SCRIPT ERROR；因此不能声称解析成功，也不能归因为解析缺依赖。
- 无重试、无提高限额、无削弱依赖图、无执行完整Game、Catalog、编译驱动或任何玩法。

文件：result/PROCESS.json（最终状态与资源）；result/LAUNCH.json（实际启动参数）；result/native.log；result/samples.jsonl；INPUT_MANIFEST.json（闭包及哈希）；prepare.py、run.py（本次代码，均未自动重试）。

结论：本次完整原字节 PrizeBuffs 加载在现行 RSS 门槛下没有完成，所以无法据此继续承诺 BGS_Treasures_028→BG21_018 的整组执行验收。不要以新猜测的 stub、替换 Exact 比较器或抽取函数冒称完整模块测试。若维持当前低内存规则，先测此前报告的 delayed_minion_gold 三文件真实账本提交/结算或 gold_income 单文件真实资源变更，更有实际进展空间。该选择不表示相关 Game 集成已经通过。
