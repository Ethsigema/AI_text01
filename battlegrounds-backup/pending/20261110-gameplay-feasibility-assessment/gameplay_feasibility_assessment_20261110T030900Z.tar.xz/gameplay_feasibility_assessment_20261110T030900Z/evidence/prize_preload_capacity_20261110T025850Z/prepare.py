from pathlib import Path
import hashlib,json,re,resource,shutil
resource.setrlimit(resource.RLIMIT_AS,(128*1024**2,2*1024**3))
root=Path(__file__).resolve().parent
src=Path('/workspace/scratch/dd4f12b08ec0/historical_tools_batch14_20261109T191857Z/runtime')
project=root/'project';project.mkdir(exist_ok=False)
pending=['core/prize_buff_effects.gd'];seen=set();edges=[];manifest={};flags=[]
pattern=re.compile(r'preload\s*\(\s*([\"\'])(res://[^\"\'\n]+)\1\s*\)')
while pending:
 rel=pending.pop()
 if rel in seen:continue
 seen.add(rel)
 assert rel.startswith('core/') and '..' not in Path(rel).parts,rel
 assert rel not in ['core/game.gd','core/combat.gd','core/catalog.gd'],rel
 f=src/rel;data=f.read_bytes();s=data.decode('utf-8')
 refs=[m.group(2)[6:] for m in pattern.finditer(s)]
 refs += re.findall(r'^extends\s+[\"\']res://([^\"\'\n]+)[\"\']',s,re.M)
 if re.search(r'^static\s+func\s+_static_init\b',s,re.M):flags.append({'file':rel,'type':'static_init'})
 if re.search(r'^class_name\s+',s,re.M):flags.append({'file':rel,'type':'class_name'})
 dst=project/rel;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(f,dst)
 expected=hashlib.sha256(data).hexdigest();assert hashlib.file_digest(dst.open('rb'),'sha256').hexdigest()==expected
 manifest[rel]={'bytes':len(data),'sha256':expected}
 for dep in refs:edges.append([rel,dep]);pending.append(dep)
(project/'project.godot').write_text('[application]\nconfig/name="Bounded PrizeBuffs preload-only capacity"\n[rendering]\nrenderer/rendering_method="gl_compatibility"\n')
(project/'probe.gd').write_text('extends SceneTree\nconst PrizeBuffs = preload("res://core/prize_buff_effects.gd")\nfunc _initialize() -> void:\n\tprint("PRIZEBUFFS_PRELOAD_ONLY_OK")\n\tquit(0)\n')
report={'status':'PREPARED_NOT_EXECUTED','source_runtime':str(src),'root_module':'core/prize_buff_effects.gd','file_count':len(manifest),'total_source_bytes':sum(x['bytes'] for x in manifest.values()),'flags':flags,'literal_preload_edges':edges,'files':manifest,'script_behavior':'preload original PrizeBuffs only, print marker and quit; no module instantiation or method calls','game_catalog_combat_loaded':False}
(root/'INPUT_MANIFEST.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:report[k] for k in ['status','file_count','total_source_bytes','flags','game_catalog_combat_loaded']},ensure_ascii=False))
