# PrizeBuffs 单次384MiB能力复试

结果：FAILED_OR_CONTROLLED_STOP / controlled_RSS_stop。未完成preload，未执行任何玩法。

本次按明确新授权仅运行一次，将RSS停止阈值从192MiB改为384MiB，同时提高系统余量保护：启动至少2GiB MemAvailable，运行低于1GiB停止。仍为单Godot进程、2CPU、2GiB地址空间、45秒、5ms监测；Python128MiB。未改变依赖、校验或源代码，未使用stub。

- 新目录：prize_preload_capacity_384_20261110T030233Z。
- 原字节闭包：247文件，7,318,392字节，与192MiB试验的每个SHA256及每条preload边完全相同。
- 运行内容：原PrizeBuffs preload，然后打印成功标记并退出；没有实例化或调用模块方法。没有Game、Combat、Catalog或driver。
- Godot4.6.3，启动前无其它Godot；启动可用内存9,455,276,032B，退出后9,419,812,864B。
- 2.9568528秒时受控停止，exit=-15。
- wait4实际Godot PID峰值RSS：393,232KiB。
- 采样RSS峰值：402,894,848B，超过384MiB门槛402,653,184B。
- 成功标记未出现。合并stdout/stderr完整日志73B，仅Godot版本；无SCRIPT ERROR或解析错误记录。不能声称解析成功，也不能判定缺失依赖。
- 复制项目及原源码运行后哈希全部不变。
- 192MiB记录未修改，其PROCESS.json SHA256仍为359a62b0cb851cf909e57a7713fa341e504e70b421eb1822ab6e3cc822ef95c7。
- 未再次启动、未提高上限；结束后没有遗留Godot进程。

详细证据：INPUT_MANIFEST.json、TRIAL_PLAN.json、result/LAUNCH.json、result/PROCESS.json、result/native.log、result/samples.jsonl。

结论：当前一次384MiB预算也未能加载原PrizeBuffs完整闭包。BGS_Treasures_028→BG21_018整组真实交互和手牌拒绝无副作用仍未验收，不能以加载尝试当作通过。保留失败能力记录，并停止这条运行路线；此前两条小闭包仅静态确认可作为独立行为测试候选，尚未实际测试。
