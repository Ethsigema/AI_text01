from pathlib import Path
import hashlib,json,os,resource,subprocess,time
resource.setrlimit(resource.RLIMIT_AS,(128*1024**2,2*1024**3))
root=Path(__file__).resolve().parent;project=root/'project';out=root/'result';out.mkdir(exist_ok=False)
manifest=json.loads((root/'INPUT_MANIFEST.json').read_text())
for rel,expected in manifest['files'].items():
 assert hashlib.file_digest((project/rel).open('rb'),'sha256').hexdigest()==expected['sha256'],rel
assert len(list((project/'core').glob('*.gd')))==manifest['file_count']
assert not manifest['flags']
AS=2*1024**3;RSS=384*1024**2;START=2*1024**3;LOW=1024**3;TIMEOUT=45;POLL=.005
plan={'address_space_limit_bytes':AS,'python_address_space_limit_bytes':128*1024**2,'cpu_count':2,'minimum_available_before_start_bytes':START,'minimum_system_available_bytes':LOW,'soft_RSS_abort_bytes':RSS,'timeout_seconds':TIMEOUT,'poll_seconds':POLL,'parallel_Godot':False}
def available():return int(next(line.split()[1] for line in Path('/proc/meminfo').read_text().splitlines() if line.startswith('MemAvailable:')))*1024
others=[]
for f in Path('/proc').glob('[0-9]*/comm'):
 try:
  if 'godot' in f.read_text().lower():others.append(f.parent.name)
 except (OSError,PermissionError):pass
argv=['/usr/local/bin/godot','--headless','--single-threaded-scene','--render-thread','safe','--path',str(project),'--script',str(project/'probe.gd')]
env=os.environ.copy();home=out/'home'
for d in [home,home/'config',home/'data',home/'cache']:d.mkdir(parents=True,exist_ok=True)
env.update(HOME=str(home),XDG_CONFIG_HOME=str(home/'config'),XDG_DATA_HOME=str(home/'data'),XDG_CACHE_HOME=str(home/'cache'))
metadata={'argv':argv,'plan':plan,'memory_available_before_bytes':available(),'other_Godot':others,'source_count':manifest['file_count'],'source_bytes':manifest['total_source_bytes'],'maxrss_method':'os.wait4 exact Godot PID','original_bytes_preserved':True,'gameplay_executed':False,'full_Game_loaded':False,'full_Catalog_loaded':False,'full_compiler_executed':False}
(out/'LAUNCH.json').write_text(json.dumps(metadata,indent=2)+'\n')
if others or metadata['memory_available_before_bytes']<START:
 metadata['status']='NOT_LAUNCHED_SAFETY_PREFLIGHT';(out/'PROCESS.json').write_text(json.dumps(metadata,indent=2)+'\n');print(json.dumps(metadata));raise SystemExit(2)
def limits():
 resource.setrlimit(resource.RLIMIT_AS,(AS,AS));os.sched_setaffinity(0,set(sorted(os.sched_getaffinity(0))[:2]))
t=time.monotonic();reason='process_exit';peak=0;usage=None
with (out/'native.log').open('wb') as log,(out/'samples.jsonl').open('w',buffering=1) as samples:
 p=subprocess.Popen(argv,env=env,stdout=log,stderr=subprocess.STDOUT,preexec_fn=limits)
 def reap(block=False):
  global usage
  pid,status,ru=os.wait4(p.pid,0 if block else os.WNOHANG)
  if pid:p.returncode=os.waitstatus_to_exitcode(status);usage=ru;return True
  return False
 try:
  while not reap():
   try:
    sample={line.split(':',1)[0]:line.split(':',1)[1].strip() for line in Path(f'/proc/{p.pid}/status').read_text().splitlines() if line.split(':',1)[0] in ['VmRSS','VmSize','VmPeak','VmHWM','Threads']}
    sample.update(elapsed_seconds=time.monotonic()-t,available_bytes=available());rss=int(sample.get('VmRSS','0 kB').split()[0])*1024;peak=max(peak,rss);samples.write(json.dumps(sample)+'\n')
    if rss>=RSS:reason='controlled_RSS_stop'
    elif sample['available_bytes']<LOW:reason='controlled_headroom_stop'
   except (FileNotFoundError,ProcessLookupError):pass
   if time.monotonic()-t>TIMEOUT:reason='controlled_timeout'
   log_text=(out/'native.log').read_text(errors='replace')
   if 'SCRIPT ERROR:' in log_text:reason='controlled_script_error'
   if reason!='process_exit':
    p.terminate();deadline=time.monotonic()+2
    while time.monotonic()<deadline and not reap():time.sleep(.005)
    if p.returncode is None:p.kill();reap(True)
    break
   time.sleep(POLL)
 except BaseException:
  if p.returncode is None:p.kill();reap(True)
  raise
log_text=(out/'native.log').read_text(errors='replace')
parsed=('PRIZEBUFFS_PRELOAD_ONLY_OK' in log_text and 'SCRIPT ERROR:' not in log_text and 'ERROR:' not in log_text)
metadata.update(exit=p.returncode,reason=reason,seconds=time.monotonic()-t,maxrss_kib=usage.ru_maxrss,sampled_peak_rss_bytes=peak,memory_available_after_bytes=available(),success_marker_present='PRIZEBUFFS_PRELOAD_ONLY_OK' in log_text,status='PASS_PRELOAD_ONLY' if p.returncode==0 and reason=='process_exit' and parsed else 'FAILED_OR_CONTROLLED_STOP')
metadata['source_hashes_after_unchanged']=all(hashlib.file_digest((project/rel).open('rb'),'sha256').hexdigest()==expected['sha256'] for rel,expected in manifest['files'].items())
source=Path(manifest['source_runtime'])
metadata['original_source_hashes_after_unchanged']=all(hashlib.file_digest((source/rel).open('rb'),'sha256').hexdigest()==expected['sha256'] for rel,expected in manifest['files'].items())
(out/'PROCESS.json').write_text(json.dumps(metadata,indent=2)+'\n')
print(json.dumps({key:metadata[key] for key in ['status','exit','reason','seconds','maxrss_kib','sampled_peak_rss_bytes','success_marker_present','source_hashes_after_unchanged']}))
print(log_text[-6000:])
raise SystemExit(0 if metadata['status']=='PASS_PRELOAD_ONLY' else 1)
