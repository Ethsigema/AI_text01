extends RefCounted
## Pinned Cursed Crystal revision. Partial holds and previous proof boundaries remain.
const REVISION: String="partial-37.0.2-timewarp_amalgam-rebuilt-20261107"
const ID: String="BG34_Giant_336"
const OVERLAY: String="data/patch_3702_timewarp_amalgam_overlay.json"
const FILE_SHA256: Dictionary={"data/patch_3702_timewarp_amalgam_overlay.json":"07984d38743fba3cc01fc5fab352730c28662bbcad42caec8a1b68322dc6bbe2","research/patch_3702_timewarp_amalgam/BG34_Giant_336.native.xml":"49a35a8dccad1ab90bd40a79d24007d9d1dfd2a1b4084e53cc817d19011befdf","research/patch_3702_timewarp_amalgam/evidence.json":"10d959ff421d1a0fffc17de38334eac2b887da127d3d44257725204e17710974","core/timewarp_amalgam_host.gd":"cce0ec9651a6ee91b3b46096b04c5396cb7e0589373932fb4f3fcb250cde5aca","core/game.gd":"9491f54d2e07be2a2c4cdb715caea32d56b4ea9242ea51a29893f557663226fe","core/combat.gd":"44e08d150849ccad418841ab29790ff928b7e996a5c03a401cd6879d852af08e","core/recruit_extensions.gd":"05b0e1eb6b98fe44d30f909dca598bd4d273c3dc967c33f90beb24d592b5cdd9"}
const RUNTIME_PATHS: Array=["core/patch_3702_timewarp_amalgam_sources.gd","core/catalog.gd","data/patch_3702_timewarp_amalgam_overlay.json","research/patch_3702_timewarp_amalgam/BG34_Giant_336.native.xml","research/patch_3702_timewarp_amalgam/evidence.json","core/timewarp_amalgam_host.gd","core/game.gd","core/combat.gd","core/recruit_extensions.gd"]
const EXPECTED_RAW: Dictionary={}
const EXPECTED_COMPILED: Dictionary={}
const EXPECTED_BASELINE: Dictionary={}
const EFFECTIVE_FIELDS: Dictionary={"attack":7,"health":9,"text":"在你使用一张随从牌后，在本局对战中使酒馆中该类型的随从获得+4/+4。","supported":true,"effects":[{"type":"on_play_timewarp_amalgam","source_id":"BG34_Giant_336","attack":4,"health":4,"count":1}],"keywords":[],"pool_supported":false,"default_pool":false,"coverage_text_sha256":"787c5066223a93205aa6df38126ad7d052fbc6bd5dd5e92f6b808095f359c193","implementation_status":"partial_single_type_play_factory_fixture","conditional_support":{"rule":"timewarp_amalgam_single_type_shop_rebuilt_20261107","reason":"Single-type plays and ALL-type plays grant permanent Tavern bonuses. ALL selects every typed minion once per literal and excludes typeless minions. Ordinary dual-type unions, golden gameplay, natural acquisition and broad combinations remain partial."},"pool_blocker":"没有已确认的普通商店随从资格；衍生物、伙伴或时空扭曲内容需由对应机制生成，或显式配置自定义入店参数。","id":"BG34_Giant_336","card_code":"BG34_Giant_336","dbf_id":"127884","name":"时空扭曲融合怪","kind":"minion","category":"随从","categories":["随从","时空扭曲"],"mechanisms":["时空扭曲"],"tier":5,"cost":null,"tribes":["全部"],"is_golden":false,"normal_id":null,"golden_id":"BG34_Giant_336_G","image":"","solo_eligible":true,"source_url":"https://github.com/HearthSim/hsdata","native_source_build":"37.0.2.256589"}
const EXPECTED_CURRENT: Dictionary={"attack":7,"health":9,"text":"在你使用一张随从牌后，在本局对战中使酒馆中该类型的随从获得+4/+4。","supported":true,"effects":[{"type":"on_play_timewarp_amalgam","source_id":"BG34_Giant_336","attack":4,"health":4,"count":1}],"keywords":[],"pool_supported":false,"default_pool":false,"coverage_text_sha256":"787c5066223a93205aa6df38126ad7d052fbc6bd5dd5e92f6b808095f359c193","implementation_status":"partial_single_type_play_factory_fixture","conditional_support":{"rule":"timewarp_amalgam_single_type_shop_rebuilt_20261107","reason":"Single-type plays and ALL-type plays grant permanent Tavern bonuses. ALL selects every typed minion once per literal and excludes typeless minions. Ordinary dual-type unions, golden gameplay, natural acquisition and broad combinations remain partial."},"pool_blocker":"没有已确认的普通商店随从资格；衍生物、伙伴或时空扭曲内容需由对应机制生成，或显式配置自定义入店参数。","id":"BG34_Giant_336","card_code":"BG34_Giant_336","dbf_id":"127884","name":"时空扭曲融合怪","kind":"minion","category":"随从","categories":["随从","时空扭曲"],"mechanisms":["时空扭曲"],"tier":5,"cost":null,"tribes":["全部"],"is_golden":false,"normal_id":null,"golden_id":"BG34_Giant_336_G","image":"","solo_eligible":true,"source_url":"https://github.com/HearthSim/hsdata","native_source_build":"37.0.2.256589"}

static func accepts_id(value: Variant) -> bool:
	return value is String and value==ID

static func same(actual: Variant,expected: Variant) -> bool:
	# JSON integral floats are admissible. Booleans/strings/fractions/nonfinite values are not numbers.
	if expected is int or expected is float:
		return (actual is int or actual is float) and not actual is bool and is_finite(float(actual)) and is_finite(float(expected)) and actual==floor(actual) and expected==floor(expected) and actual==expected
	if typeof(actual)!=typeof(expected): return false
	if expected is Dictionary:
		if actual.size()!=expected.size(): return false
		for key in expected:
			if not actual.has(key) or not same(actual[key],expected[key]): return false
		return true
	if expected is Array:
		if actual.size()!=expected.size(): return false
		for index in range(expected.size()):
			if not same(actual[index],expected[index]): return false
		return true
	return actual==expected

static func proof_error() -> String:
	# Startup-only disk proof. Hot source_error/program/get_card never calls this.
	for path in FILE_SHA256:
		if not FileAccess.file_exists("res://"+path) or FileAccess.get_sha256("res://"+path)!=FILE_SHA256[path]: return "partial_3702_timewarp_amalgam_evidence_changed:"+str(path)
	var packet: Variant=JSON.parse_string(FileAccess.get_file_as_string("res://"+OVERLAY))
	var expected_packet: Dictionary={"revision":REVISION,"cards":[{"id":ID,"expected_raw":EXPECTED_RAW,"expected_compiled":EXPECTED_COMPILED,"expected_baseline":EXPECTED_BASELINE,"effective_fields":EFFECTIVE_FIELDS}]}
	if not same(packet,expected_packet): return "partial_3702_timewarp_amalgam_changed_packet"
	var baseline: Dictionary=EXPECTED_RAW.duplicate(true);baseline.merge(EXPECTED_COMPILED,true)
	if not same(baseline,EXPECTED_BASELINE): return "partial_3702_timewarp_amalgam_invalid_baseline_derivation"
	baseline.merge(EFFECTIVE_FIELDS,true)
	if not same(baseline,EXPECTED_CURRENT) or str(EXPECTED_CURRENT.text).sha256_text()!=EXPECTED_CURRENT.coverage_text_sha256: return "partial_3702_timewarp_amalgam_invalid_current_derivation"
	return ""

static func input_error(decoded: Variant,path: String) -> String:
	# Called before generic numeric normalization. Historical input is authenticated in full.
	var expected: Dictionary={}
	if path=="res://data/catalog_raw.json": expected=EXPECTED_RAW
	elif path=="res://data/catalog.json": expected=EXPECTED_COMPILED
	if not decoded is Dictionary or not decoded.get("cards") is Array:
		return "partial_3702_timewarp_amalgam_missing_input:"+path if not expected.is_empty() else ""
	var matches: Array=[]
	for card in decoded.cards:
		if card is Dictionary and accepts_id(card.get("id")): matches.append(card)
	if expected.is_empty(): return "" if matches.is_empty() else "partial_3702_timewarp_amalgam_unexpected_input:"+path
	if matches.size()!=1: return "partial_3702_timewarp_amalgam_missing_or_duplicate_input:"+path
	return "" if same(matches[0],expected) else "partial_3702_timewarp_amalgam_changed_whole_input:"+path

static func apply_overlay(cards: Dictionary) -> String:
	if cards.has(ID): return "timewarp_amalgam_unexpected_existing_source"
	cards[ID]=EXPECTED_CURRENT.duplicate(true)
	return ""

static func source_error(card: Dictionary) -> String:
	# Small in-memory, typed, exact whole-current-row guard. No file access or hashing.
	if not accepts_id(card.get("id")): return "partial_3702_timewarp_amalgam_unknown_source"
	return "" if same(card,EXPECTED_CURRENT) else "partial_3702_timewarp_amalgam_changed_whole_effective_source"
