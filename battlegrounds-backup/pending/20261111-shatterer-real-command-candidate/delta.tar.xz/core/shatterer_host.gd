extends RefCounted
## Independent candidate. The only stat writer is the original Game._buff.
const Sources=preload("res://core/shatterer_sources.gd")
const MAX: int=9223372036854775807
const IDS: Array=["BG31_035","BG31_035_G"]
const PLAY_IDS: Array=["BG23_000","BG23_000_G","BG23_007","BG23_007_G","BG31_035","BG31_035_G"]
static func fail(issue: String) -> Dictionary: return {"ok":false,"error":issue}
static func integer(value: Variant) -> bool: return value is int and value>=0
static func active(unit: Dictionary) -> bool:
	return unit.get("kind")=="minion" and unit.get("health") is int and unit.health>0 and not unit.get("_pending_destroy",false) and not unit.get("silenced",false) and not unit.get("abilities_disabled",false)
static func naga(unit: Dictionary) -> bool:
	return unit.get("kind")=="minion" and unit.get("tribes",[]).any(func(t):return t in ["纳迦","全部","all"])
static func triggered(p: Dictionary,played: Dictionary) -> bool:
	return naga(played) and p.get("board",[]).any(func(u):return u.get("card_id") in IDS and active(u) and not is_same(u,played) and u.get("uid")!=played.get("uid"))
static func owner_error(engine,p: Dictionary) -> String:
	if engine.state.get("phase")!="recruit" or not p.get("alive",false): return "shatterer_actual_recruit_owner_required"
	if not integer(p.get("id")) or p.id>=engine.state.get("players",[]).size() or not is_same(engine.state.players[p.id],p): return "shatterer_actual_owner_required"
	if not integer(engine.state.get("round")) or not integer(engine.state.get("command_sequence")): return "shatterer_actual_clock_required"
	var seen: Dictionary={}
	for zone in ["board","hand","shop"]:
		if not p.get(zone) is Array: return "shatterer_actual_zones_required"
		for unit in p[zone]:
			if not unit is Dictionary or not unit.get("uid") is String or unit.uid.is_empty() or seen.has(unit.uid): return "shatterer_unique_actual_uid_required"
			seen[unit.uid]=true
	return ""
static func safe_counter(value: Variant) -> bool:
	return (value is int or value is float) and is_finite(float(value)) and value>=0 and value<=9007199254740991 and value==floor(value)
static func amount(id: String,spells: Variant) -> Dictionary:
	if id not in IDS or not safe_counter(spells): return fail("shatterer_invalid_counter_or_source")
	var multiplier: int=1 if id==IDS[0] else 2
	@warning_ignore("integer_division")
	var steps: int=int(spells)/3
	if steps>4611686018427387902: return fail("shatterer_amount_overflow")
	return {"ok":true,"error":"","amount":multiplier*(1+steps)}
static func source_error(engine,source: Dictionary) -> String:
	var issue: String=Sources.unit_error(source)
	if not issue.is_empty(): return issue
	var card: Dictionary=engine.catalog.get_card(str(source.get("card_id","")))
	return Sources.source_error(card)
static func prefix_error(engine,p: Dictionary,played: Dictionary,mode: String) -> String:
	if mode!="play" or "magnetic" in played.get("keywords",[]): return "shatterer_magnetic_prefix_partial"
	if played.get("card_id") not in PLAY_IDS: return "shatterer_other_naga_prefix_partial"
	var card: Dictionary=engine.catalog.get_card(str(played.card_id))
	if card.is_empty() or card.get("kind")!="minion" or card.get("tribes")!=played.get("tribes") or card.get("effects")!=played.get("effects") or card.get("is_golden",false)!=played.get("golden",false): return "shatterer_played_native_program_required"
	for effect in played.get("effects",[]):
		if effect.get("type") not in ["spellcraft",Sources.TYPE]: return "shatterer_battlecry_transform_prefix_partial"
	return ""
# Finite first candidate: fail BEFORE the original hand-play body for every
# excluded prefix. These are scope restrictions, not claims that those legal
# game combinations can never be supported.
static func domain_error(engine,p: Dictionary) -> String:
	if p.get("hero_id")!="TB_BaconShop_HERO_01": return "shatterer_other_hero_prefix_partial"
	for key in ["hero_identity_id","hero_identity_portrait","hero_power_replacement_history"]:
		if p.has(key): return "shatterer_replaced_hero_identity_partial"
	for owner in engine.state.players:
		for key in ["native_denathrius_initial_quest","native_shady_aristocrat_quests"]:
			if owner.has(key): return "shatterer_secondary_quest_slot_partial:"+key
		if owner.get("hero_id")=="BG22_HERO_007": return "shatterer_azshara_capture_partial"
		for key in ["active_quest","reward_active","trinkets"]:
			if not owner.get(key,{} if key=="active_quest" else []).is_empty(): return "shatterer_owned_mechanism_prefix_partial"
	for key in ["permanent_tribe_bonuses","discover","discover_queue"]:
		if not p.get(key,{} if key=="permanent_tribe_bonuses" else []).is_empty(): return "shatterer_pending_owner_layer_partial"
	for key in ["native_elemental_given_attack","native_elemental_given_health","native_ditch_guardian_given_stats","native_enhanced_spawn_given_stats"]:
		if p.has(key): return "shatterer_historical_giver_layer_partial:"+key
	var master=engine._master_realities_host
	if master==null or master._depth!=0 or master._draining or not master._queue.is_empty() or not master._pending.is_empty() or not master._reserved.is_empty(): return "shatterer_pending_stat_queue_partial"
	if not engine._pressure_observation_error.is_empty() or not engine._azshara_observation_error.is_empty() or not engine._pressure_observed.is_empty() or not engine._azshara_observed.is_empty(): return "shatterer_pending_global_observation_partial"
	if not engine._pressure_initial_observed.is_empty() or not engine._pressure_independent_observed.is_empty(): return "shatterer_secondary_quest_observation_partial"
	for zone in ["board","hand"]:
		for unit in p[zone]:
			if unit.get("kind")=="spell" and zone=="hand": continue
			if unit.get("card_id") not in PLAY_IDS: return "shatterer_other_owned_minion_prefix_partial"
			var card: Dictionary=engine.catalog.get_card(str(unit.card_id))
			if card.is_empty() or card.get("effects")!=unit.get("effects") or card.get("tribes")!=unit.get("tribes") or card.get("is_golden",false)!=unit.get("golden",false): return "shatterer_owned_native_program_required"
			if unit.get("temporary")!=false or unit.get("is_spellcraft")!=false: return "shatterer_temporary_or_spellcraft_minion_partial"
			var base: Dictionary={"card_id":card.id,"name":card.get("name",str(card.id)),"tier":int(card.get("tier",1)),"attack":int(card.attack),"health":int(card.health),"max_health":int(card.health),"keywords":card.get("keywords",[]),"tribes":card.tribes,"effects":card.effects,"golden":card.get("is_golden",false)}
			if not Sources.same(unit.get("base_unit"),base): return "shatterer_non_native_base_unit_partial"
			if unit.get("tier")!=base.tier or not Sources.same(unit.get("keywords"),base.keywords) or not Sources.same(unit.get("permanent_keywords"),base.keywords): return "shatterer_changed_native_body_layer_partial"
			if unit.get("golden_rebase_state")!="additive_v1": return "shatterer_nonadditive_or_legacy_entity_partial"
			for key in ["temporary_buffs","attachments"]:
				if not unit.get(key,[]).is_empty(): return "shatterer_attached_or_temporary_layer_partial"
			for key in unit:
				if key not in UNIT_FIELDS: return "shatterer_unknown_entity_layer_partial:"+str(key)
			if unit.get("recruit_shop_aura_attack",0)!=0 or unit.get("recruit_shop_aura_health",0)!=0: return "shatterer_shop_aura_layer_partial"
	return ""
const UNIT_FIELDS: Array=["uid","card_id","name","kind","tier","attack","health","max_health","keywords","tribes","effects","golden","cost","temporary","is_spellcraft","temporary_buffs","permanent_keywords","text","image","pool_count","spellcraft_kept","spell_triggers","attachments","pool_components","magnetic_tribes","individually_frozen","blood_gems_received_turn","recruit_shop_bonus_applied","recruit_shop_aura_attack","recruit_shop_aura_health","base_unit","golden_rebase_state","pool_id","pool_kind","silenced","abilities_disabled","_pending_destroy"]
static func prepare(engine,p: Dictionary,index: int,mode: String="play") -> Dictionary:
	if not engine._shatterer_play_context.is_empty(): return fail("shatterer_nested_play_partial")
	if index<0 or index>=p.get("hand",[]).size(): return {"ok":true,"active":false}
	var played: Dictionary=p.hand[index]
	if not triggered(p,played): return {"ok":true,"active":false}
	var issue: String=owner_error(engine,p)
	if issue.is_empty(): issue=prefix_error(engine,p,played,mode)
	if issue.is_empty(): issue=domain_error(engine,p)
	if not issue.is_empty(): return fail(issue)
	if not engine._shatterer_play_context.is_empty(): return fail("shatterer_nested_play_partial")
	for source in p.board:
		if source.get("card_id") not in IDS or not active(source): continue
		issue=source_error(engine,source)
		if not issue.is_empty(): return fail(issue)
		var vector: Dictionary=amount(str(source.card_id),p.get("stats",{}).get("spells"))
		if not vector.ok: return vector
		for key in ["attack","health","max_health"]:
			if not source.get(key) is int or source[key]<(0 if key=="attack" else 1) or source[key]>MAX-int(vector.amount): return fail("shatterer_stat_overflow_or_invalid")
		if source.health>source.max_health: return fail("shatterer_invalid_source_health")
	return {"ok":true,"active":true,"owner":p,"sources":p.board.filter(func(u):return u.get("card_id") in IDS and active(u)),"played":played,"played_uid":played.uid,"round":engine.state.round,"sequence":engine.state.command_sequence,"started":false,"finished":false,"cursor":0,"order":[],"used":[],"dispatch_source":{}}
static func ticket_error(engine,p: Dictionary,played: Dictionary) -> String:
	var t: Dictionary=engine._shatterer_play_context
	if t.is_empty() or not is_same(t.get("owner"),p) or not is_same(t.get("played"),played) or t.get("played_uid")!=played.get("uid") or t.get("round")!=engine.state.round or t.get("sequence")!=engine.state.command_sequence or t.get("finished",true): return "shatterer_actual_play_ticket_required"
	return owner_error(engine,p)
static func begin_notify(engine,p: Dictionary,played: Dictionary) -> String:
	if engine._shatterer_play_context.is_empty() and not triggered(p,played): return ""
	var issue: String=ticket_error(engine,p,played)
	if not issue.is_empty(): return issue
	var t: Dictionary=engine._shatterer_play_context
	if t.started or not p.board.any(func(u):return is_same(u,played)) or p.hand.any(func(u):return is_same(u,played)): return "shatterer_actual_consumed_hand_play_required"
	for source in p.board:
		if source.get("card_id") in IDS and active(source) and source.uid!=played.uid and not t.sources.any(func(original):return is_same(original,source)): return "shatterer_new_prefix_source_partial"
	t.started=true
	t.order=p.board.filter(func(u):return u.get("uid")!=played.uid)
	return ""
static func on_play(engine,p: Dictionary,source: Dictionary,played: Dictionary) -> String:
	var t: Dictionary=engine._shatterer_play_context
	if t.is_empty(): return "shatterer_unbound_trigger" if source.get("card_id") in IDS and active(source) and naga(played) else ""
	var issue: String=ticket_error(engine,p,played)
	if not issue.is_empty(): return issue
	if not t.started or t.cursor>=t.order.size() or not is_same(t.order[t.cursor],source) or not is_same(t.dispatch_source,source): return "shatterer_actual_board_dispatch_order_required"
	t.cursor+=1
	if source.get("card_id") not in IDS or not active(source) or not naga(played): return ""
	if source.uid==played.uid or t.used.has(source.uid) or not p.board.any(func(u):return is_same(u,source)): return "shatterer_actual_source_required"
	issue=source_error(engine,source)
	if not issue.is_empty(): return issue
	var vector: Dictionary=amount(str(source.card_id),p.get("stats",{}).get("spells"))
	if not vector.ok: return str(vector.error)
	t.used.append(source.uid)
	# No local +=, fake callback, shadow commit, or extracted Game dependency.
	engine._buff(source,int(vector.amount),int(vector.amount),source)
	if engine.state.get("phase")=="error": return "shatterer_native_buff_failed"
	return ""
static func finish_notify(engine,p: Dictionary,played: Dictionary) -> String:
	var t: Dictionary=engine._shatterer_play_context
	if t.is_empty(): return ""
	var issue: String=ticket_error(engine,p,played)
	if not issue.is_empty(): return issue
	if not t.started or t.cursor!=t.order.size(): return "shatterer_incomplete_dispatch"
	t.finished=true
	return ""
static func legal_actions(engine,player_id: int,commands: Array) -> Array:
	if engine.state.is_empty() or player_id<0 or player_id>=engine.state.players.size(): return commands
	var p: Dictionary=engine.state.players[player_id]
	return commands.filter(func(c):
		if c.get("type") not in ["play","magnetize"]: return true
		return prepare(engine,p,int(c.get("index",-1)),str(c.type)).ok
	)
