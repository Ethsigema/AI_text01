extends SceneTree
func _initialize():
 var s=load("res://core/shatterer_sources.gd")
 var pool=load("res://core/pool_identity.gd")
 var n=0
 for id in s.IDS:
  var original=s.EXPECTED_CURRENT[id].duplicate(true)
  assert(s.source_error(original).is_empty());n+=1
  var extra=original.duplicate(true);extra.unrecognized=true
  assert(not s.source_error(extra).is_empty());n+=1
  for blocker in [pool.MINION_REASON,"wrong",false,1,null]:
   var card=original.duplicate(true);card.pool_blocker=blocker
   var allowed=(id==s.IDS[1] and blocker is String and blocker==pool.MINION_REASON)
   assert(s.source_error(card).is_empty()==allowed);n+=1
  var changed=original.duplicate(true);changed.attack+=1
  assert(not s.source_error(changed).is_empty());n+=1
 print("PASS_SHATTERER_SOURCE_CONTRACT ",n)
 quit(0)
