extends SceneTree
func _initialize() -> void:
 print("LOAD_BEGIN ",Time.get_ticks_msec())
 var script = load("res://core/game.gd")
 if script == null or not script.can_instantiate():
  print("LOAD_FAILED")
  quit(2)
  return
 print("LOAD_OK")
 var game = script.new()
 print("INSTANCE_OK")
 var cat_script = load("res://core/catalog.gd")
 if cat_script == null or not cat_script.can_instantiate():
  print("CATALOG_SCRIPT_FAILED")
  quit(3)
  return
 var cat = cat_script.new()
 print("CATALOG_BEGIN ",Time.get_ticks_msec())
 cat.load_catalog()
 print("CATALOG_ERRORS ",JSON.stringify(cat.load_errors))
 if not cat.load_errors.is_empty():
  quit(4)
  return
 print("CATALOG_OK")
 var room_script = load("res://core/room_config.gd")
 var room = room_script.new()
 room.reset(cat)
 room.data.enabled_minions=["BG31_035","BG23_000","BG23_007"]
 room.data.enabled_spells=[]
 room.data.selected_hero="TB_BaconShop_HERO_01"
 room.data.enabled_heroes=["TB_BaconShop_HERO_01"]
 room.data.enabled_anomalies=[]
 room.data.enabled_quests=[]
 room.data.enabled_rewards=[]
 room.data.enabled_trinkets=[]
 print("START_BEGIN ",Time.get_ticks_msec())
 var started=game.start(room.data,cat)
 print("START_RESULT ",JSON.stringify(started))
 if not started.get("ok",false):
  quit(5)
  return
 var p=game.state.players[0]
 for id in ["BG31_035","BG23_000"]:
  var u=game._unit(cat.get_card(id))
  if u.is_empty():
   print("FACTORY_FAILED ",id)
   quit(6)
   return
  game._add_hand(p,u)
  var index=p.hand.find(u)
  print("REAL_UNIT ",id," ",u.uid," hand_index=",index)
  if index<0:
   quit(7)
   return
  var played=game._play(p,index,-1,-1)
  print("PLAY_RESULT ",id," ",JSON.stringify(played)," PHASE ",game.state.phase)
  if not played.get("ok",false):
   quit(8)
   return
 var shatterer=p.board.filter(func(u):return u.card_id=="BG31_035")[0]
 print("SHATTERER_ACTUAL_STATS ",shatterer.attack," ",shatterer.health," ",shatterer.max_health)
 if shatterer.attack!=7 or shatterer.health!=5 or shatterer.max_health!=5:
  quit(9)
  return
 print("PASS_REAL_SHATTERER_PLAY_BUFF ",Time.get_ticks_msec())
 quit(0)
