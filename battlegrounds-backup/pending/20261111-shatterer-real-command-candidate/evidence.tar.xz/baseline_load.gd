extends SceneTree
func _initialize() -> void:
 print("LOAD_BEGIN")
 var script = load("res://core/game.gd")
 if script == null or not script.can_instantiate():
  print("LOAD_FAILED")
  quit(2)
  return
 print("LOAD_OK")
 var game = script.new()
 print("INSTANCE_OK")
 var cat_script = load("res://core/catalog.gd")
 if cat_script == null or not cat_script.can_instantiate():
  print("CATALOG_SCRIPT_FAILED")
  quit(3)
  return
 var cat = cat_script.new()
 print("CATALOG_BEGIN")
 cat.load_catalog()
 print("CATALOG_ERRORS ",JSON.stringify(cat.load_errors))
 if not cat.load_errors.is_empty():
  quit(4)
  return
 print("CATALOG_OK")
 quit(0)
