extends RefCounted
## Private, non-serialized finite candidate. No RNG, UID, pool or hand writer here.
const Sources=preload("res://core/darkcrest_sources.gd")
const MAX_TIER: int=4 # Admission boundary, NOT an asserted official cap.
const HAND_BODIES: Array=["BG36_921","BG31_330","BG23_001","BG23_000","BG23_009","BG23_002","BG31_924","BG_GIL_681","BG23_011","BGS_200","BG33_315","BG23_010","BG23_007","BG23_004","BG23_006","BG23_003"]
var _parents: Dictionary={}
var _grants: Dictionary={}
var _spells: Dictionary={}
var _cast: Dictionary={}
var _delivery: Dictionary={}
var _delivery_receipts: Array=[]
var _eot: Dictionary={}
var _purchase_projection: Dictionary={}
static func integer(v: Variant,lo: int,hi: int) -> bool:
	return (v is int or v is float) and not v is bool and is_finite(float(v)) and v==floor(v) and v>=lo and v<=hi
static func result(issue: String="") -> Dictionary: return {"ok":issue.is_empty(),"error":issue}
static func parent(u: Dictionary) -> bool: return u.get("card_id") in Sources.PARENTS
static func spell(u: Dictionary) -> bool: return u.get("card_id") in Sources.SPELLS
static func actual(game) -> bool:
	if not game is RefCounted: return false
	var script: Variant=game.get_script()
	return script is Script and script.resource_path=="res://core/game.gd"
static func count(p: Dictionary,id: String) -> int:
	var n: int=0
	for u in p.get("board",[])+p.get("hand",[]):
		if u.get("card_id")==id and not u.get("golden",false): n+=1
	return n
func fresh(game,u: Dictionary) -> String:
	if not parent(u): return ""
	if not actual(game) or not Sources.unit_error(u).is_empty() or not u.get("uid") is String or u.uid.is_empty() or _parents.has(u.uid): return "darkcrest_invalid_fresh_factory"
	_parents[u.uid]={"unit":u,"id":u.card_id,"tier":1,"last_eot":-1,"shop_origin":false}
	return ""
func offered(u: Dictionary) -> String:
	if not parent(u): return ""
	var r: Dictionary=_parents.get(u.get("uid",""),{})
	if not is_same(r.get("unit"),u): return "darkcrest_original_shop_factory_required"
	r.shop_origin=true
	return ""
static func persisted_claimed(state: Dictionary) -> bool:
	for p in state.get("players",[])+state.get("ghosts",[]):
		if not p is Dictionary: continue
		for zone in ["board","hand","shop"]:
			for u in p.get(zone,[]):
				if u is Dictionary and (parent(u) or spell(u)): return true
	return false
func parent_error(u: Dictionary) -> String:
	var issue: String=Sources.unit_error(u)
	if not issue.is_empty(): return issue
	var r: Dictionary=_parents.get(u.get("uid",""),{})
	if not parent(u) or not is_same(r.get("unit"),u) or r.get("id")!=u.get("card_id"): return "darkcrest_saved_copied_or_transformed_parent_held"
	if r.get("shop_origin")!=true: return "darkcrest_nonshop_birth_held"
	if not integer(r.get("tier"),1,MAX_TIER) or not integer(r.get("last_eot"),-1,2147483647): return "darkcrest_invalid_growth_record"
	if u.get("silenced",false) or u.get("abilities_disabled",false) or u.get("_pending_destroy",false) or u.get("health",0)<=0: return "darkcrest_disabled_parent_held"
	if not u.get("attachments",[]).is_empty() or not u.get("temporary_buffs",[]).is_empty() or u.get("keywords",[])!=Sources.EXPECTED_CURRENT[u.card_id].get("keywords",[]): return "darkcrest_modified_parent_held"
	return ""
func owner_error(game,p: Dictionary) -> String:
	if not _purchase_projection.is_empty() and not is_same(_purchase_projection.engine.get_ref(),game): return "darkcrest_projection_engine_mismatch"
	if not actual(game) or not integer(p.get("id"),0,game.state.players.size()-1) or not is_same(game.state.players[int(p.id)],p): return "darkcrest_actual_owner_required"
	if p.get("hero_id")!="TB_BaconShop_HERO_01" or not game._enabled("anomalies").is_empty(): return "darkcrest_owner_program_held"
	for field in ["hero_identity_id","hero_identity_portrait","hero_power_replacement_history","native_denathrius_initial_quest","native_shady_aristocrat_quests","native_elemental_given_attack","native_elemental_given_health","native_ditch_guardian_given_stats","native_enhanced_spawn_given_stats"]:
		if p.has(field): return "darkcrest_other_owner_history_held:"+field
	for k in ["active_quest","reward_active","trinkets","permanent_tribe_bonuses","discover","discover_queue","next_combat_spell_queue"]:
		if p.get(k,{}) not in [{},[],"",null]: return "darkcrest_owner_layer_held:"+k
	if not game._mechanic_effects(p).is_empty(): return "darkcrest_mechanic_listener_held"
	var issue: String=game.Rider.queue_error(p)
	if not issue.is_empty(): return "darkcrest_"+issue
	for u in p.board:
		if not parent(u): return "darkcrest_other_board_listener_held"
		issue=parent_error(u)
		if not issue.is_empty(): return issue
	for u in p.hand:
		if parent(u):
			issue=parent_error(u)
			if not issue.is_empty(): return issue
		elif spell(u):
			issue=spell_error(p,u,int(game.state.round))
			if not issue.is_empty(): return issue
		else:
			issue=hand_error(game,u)
			if not issue.is_empty(): return issue
	for id in Sources.PARENTS:
		if count(p,id)>2: return "darkcrest_triple_inheritance_held"
	return ""
# Only these five tier2/3 identities receive the new narrow content gate.
# A matching state is factory-compatible, never proof of actual factory origin.
const STRICT_HAND_BODIES: Array=["BG23_009","BG23_002","BG31_924","BG23_007","BG23_004"]
static func candidate_source_error(id: String,card: Dictionary) -> String:
	if id not in HAND_BODIES or card.get("supported")!=true or not Sources.same(card,Sources.EXPECTED_HAND.get(id,{})):
		return "darkcrest_complete_random_candidate_held:"+id
	return ""
# Pure content check. The actual-game caller supplies the unchanged Rider fields.
# This function never constructs a unit, allocates a UID or touches pool/RNG/hand.
static func hand_state_error(u: Dictionary,card: Dictionary,allowed_fields: Array) -> String:
	var raw_id: Variant=u.get("card_id")
	if not raw_id is String or raw_id not in STRICT_HAND_BODIES: return "darkcrest_strict_hand_identity_held"
	var id: String=raw_id
	var issue: String=candidate_source_error(id,card)
	if not issue.is_empty(): return issue
	for key in u:
		if key not in allowed_fields: return "darkcrest_unknown_hand_field:"+str(key)
	if not u.get("uid") is String or u.uid.is_empty(): return "darkcrest_hand_uid_required"
	var expected: Dictionary={"card_id":id,"name":card.get("name",id),"kind":"minion","tier":int(card.tier),"attack":int(card.attack),"health":int(card.health),"max_health":int(card.health),"keywords":card.get("keywords",[]),"tribes":card.get("tribes",[]),"effects":card.get("effects",[]),"golden":false,"cost":int(card.get("cost",0) if card.get("cost")!=null else 0),"temporary":false,"is_spellcraft":false,"temporary_buffs":[],"permanent_keywords":card.get("keywords",[]),"text":card.get("text",""),"image":card.get("image",""),"pool_count":1,"spellcraft_kept":0,"spell_triggers":0,"attachments":[],"pool_components":[],"magnetic_tribes":card.get("magnetic_tribes",[]),"individually_frozen":false,"blood_gems_received_turn":0,"recruit_shop_bonus_applied":{},"recruit_shop_aura_attack":0,"recruit_shop_aura_health":0,"golden_rebase_state":"additive_v1","pool_id":id}
	# Ordinary shop minions omit this field; Bulk resource minions include it.
	if u.has("pool_kind"): expected.pool_kind="minion"
	for key in expected:
		if not u.has(key) or not Sources.same(u[key],expected[key]): return "darkcrest_hand_native_field_held:"+str(key)
	for key in ["attack","health","max_health"]:
		if not integer(u[key],0 if key=="attack" else 1,1000000000): return "darkcrest_hand_native_stat_range_held"
	for key in ["silenced","abilities_disabled","_pending_destroy"]:
		if u.has(key) and not Sources.same(u[key],false): return "darkcrest_disabled_hand_held:"+str(key)
	var base: Dictionary={"card_id":id,"name":expected.name,"tier":expected.tier,"attack":expected.attack,"health":expected.health,"max_health":expected.max_health,"keywords":expected.keywords,"tribes":expected.tribes,"effects":expected.effects,"golden":false}
	if not Sources.same(u.get("base_unit"),base): return "darkcrest_hand_native_base_held"
	return ""
func hand_error(game,u: Dictionary) -> String:
	if not actual(game): return "darkcrest_actual_hand_owner_required"
	var id: String=str(u.get("card_id",""))
	if id not in HAND_BODIES or u.get("kind")!="minion" or u.get("golden",false): return "darkcrest_other_hand_listener_held"
	var card: Dictionary=game.catalog.get_card(id)
	if not Sources.same(card,Sources.EXPECTED_HAND[id]): return "darkcrest_changed_candidate_source"
	if id in STRICT_HAND_BODIES:
		var issue: String=hand_state_error(u,card,game.Rider.UNIT_FIELDS)
		if issue.is_empty(): issue=game.LimitedTurn.validate_unit_state(u,game.state.round)
		if issue.is_empty(): issue=game.Thaumaturgy.unit_error(u)
		return issue
	# Existing tier1/legacy finite hand admission is unchanged in this revision.
	for key in ["effects","tribes","keywords"]:
		if not Sources.same(u.get(key),card.get(key,[])): return "darkcrest_changed_hand_program"
	if u.get("temporary")!=false or u.get("is_spellcraft")!=false or not u.get("attachments",[]).is_empty() or not u.get("temporary_buffs",[]).is_empty(): return "darkcrest_hand_layer_held"
	for key in u:
		if key not in game.Rider.UNIT_FIELDS: return "darkcrest_unknown_hand_field:"+str(key)
	return ""
func active(p: Dictionary) -> bool:
	return (p.get("board",[])+p.get("hand",[])).any(func(u):return parent(u) or spell(u))
func command_error(game,p: Dictionary,command: Dictionary) -> String:
	if not _purchase_projection.is_empty() and (not is_same(_purchase_projection.engine.get_ref(),game) or p.get("id")!=_purchase_projection.owner or (not Sources.same(command,_purchase_projection.command) and not Sources.same(command,_purchase_projection.internal_command))): return "darkcrest_projection_command_mismatch"
	var action: String=str(command.get("type",command.get("action","")))
	var incoming: Dictionary={}
	var index: Variant=command.get("index",-1)
	if action=="buy" and integer(index,0,p.shop.size()-1): incoming=p.shop[int(index)]
	if not active(p) and not parent(incoming): return ""
	var issue: String=owner_error(game,p)
	if not issue.is_empty(): return issue
	if action not in ["buy","play","spell","sell","refresh","roll","freeze","upgrade","end_turn","move"]: return "darkcrest_other_command_held"
	if action=="buy":
		if not parent(incoming) or incoming.get("golden",false): return "darkcrest_other_purchase_held"
		if count(p,str(incoming.get("card_id","")))>=2: return "darkcrest_third_purchase_inheritance_held"
		return parent_error(incoming)
	if action in ["play","spell"] and integer(index,0,p.hand.size()-1):
		var u: Dictionary=p.hand[int(index)]
		if parent(u):
			if u.get("golden",false): return "darkcrest_golden_acquisition_held"
			if _grants.get(u.get("uid",""),{}).get("round")==game.state.round: return "darkcrest_duplicate_turn_grant"
			return parent_error(u)
		if not spell(u): return "darkcrest_other_play_held"
		return cast_error(game,p,u)
	if action=="end_turn": return end_error(game,p)
	return ""
func queue_error(game,p: Dictionary,sources: Array) -> String:
	for u in sources:
		if not parent(u): continue
		var issue: String=owner_error(game,p)
		if issue.is_empty(): issue=parent_error(u)
		if not issue.is_empty(): return issue
		var old: Dictionary=_grants.get(u.uid,{})
		if old.get("round")==game.state.round: return "darkcrest_duplicate_turn_grant"
		if not p.board.any(func(live):return is_same(live,u)): return "darkcrest_live_grant_source_required"
	return ""
func register_grants(game,p: Dictionary,sources: Array) -> String:
	var issue: String=queue_error(game,p,sources)
	if not issue.is_empty(): return issue
	for u in sources:
		if parent(u): _grants[u.uid]={"owner":p.id,"round":game.state.round,"unit":u,"id":u.card_id,"tier":_parents[u.uid].tier,"delivered":false}
	return ""
# A window is minted only by the original Waiting.flush after its live checks.
# This private capability and each receipt are same-object, non-serialized values.
func _window_error(game,p: Dictionary,window: Variant) -> String:
	if not actual(game) or not is_same(game._darkcrest_host,self): return "darkcrest_actual_delivery_host_required"
	if not integer(p.get("id"),0,game.state.players.size()-1) or not is_same(game.state.players[int(p.id)],p): return "darkcrest_actual_delivery_owner_required"
	var guard: String=str(game.get_instance_id())+":"+str(p.id)
	if not window is RefCounted or not is_same(game.SpellcraftWaiting._active_flushes.get(guard),window): return "darkcrest_original_waiting_window_required"
	return ""
func snapshot(game,p: Dictionary,ticket: Dictionary,window: Variant) -> Dictionary:
	if ticket.get("source_card_id") not in Sources.PARENTS: return {"ok":true,"error":"","active":false}
	var issue: String=_window_error(game,p,window)
	if not issue.is_empty(): return result(issue)
	if not _delivery.is_empty(): return result("darkcrest_unresolved_or_reentrant_delivery")
	if game.state.phase!="recruit" or not p.get("spellcraft_waiting",[]).any(func(t):return is_same(t,ticket)): return result("darkcrest_live_waiting_ticket_required")
	var r: Dictionary=_grants.get(ticket.get("source_uid",""),{})
	if r.is_empty() or r.get("delivered")!=false or r.get("blocked",false) or r.get("owner")!=p.id or r.get("round")!=game.state.round or r.get("id")!=ticket.get("source_card_id") or ticket.get("spell_card_id")!=Sources.SPELLS[Sources.PARENTS.find(r.id)]: return result("darkcrest_invalid_generation_ticket")
	if ticket.size()!=6 or ticket.get("effect_index")!=0 or ticket.get("round")!=game.state.round or ticket.get("count")!=1: return result("darkcrest_exact_single_token_ticket_required")
	issue=owner_error(game,p)
	if issue.is_empty(): issue=parent_error(r.unit)
	if not issue.is_empty(): return result(issue)
	if not p.board.any(func(u):return is_same(u,r.unit)): return result("darkcrest_grant_source_departed")
	if not integer(game.next_uid,1,2147483646): return result("darkcrest_generation_uid_headroom_held")
	var receipt: RefCounted=RefCounted.new()
	_delivery={"window":window,"receipt":receipt,"owner":p,"ticket":ticket,"original_ticket":ticket.duplicate(true),"grant":r,"grant_owner":r.owner,"grant_id":r.id,"source_unit":r.unit,"tier":r.tier,"round":game.state.round,"spell_id":ticket.spell_card_id,"uid_before":game.next_uid,"state":"prepared","unit":{},"add_hand_called":false}
	return {"ok":true,"error":"","active":true,"receipt":receipt}
func _delivery_error(game,p: Dictionary,plan: Dictionary,stage: String) -> String:
	if _delivery.is_empty() or not is_same(_delivery.get("receipt"),plan.get("receipt")) or not is_same(_delivery.get("owner"),p) or _delivery.get("state")!=stage: return "darkcrest_original_delivery_receipt_required"
	var issue: String=_window_error(game,p,_delivery.window)
	if not issue.is_empty(): return issue
	var grant: Dictionary=_delivery.grant
	if not is_same(_grants.get(_delivery.original_ticket.source_uid),grant) or grant.get("delivered")!=false or grant.get("blocked",false) or game.state.round!=_delivery.round: return "darkcrest_delivery_grant_changed"
	if grant.get("owner")!=_delivery.grant_owner or grant.get("round")!=_delivery.round or grant.get("id")!=_delivery.grant_id or grant.get("tier")!=_delivery.tier or not is_same(grant.get("unit"),_delivery.source_unit): return "darkcrest_prepared_grant_fields_changed"
	return ""
func _record_delivery(game,outcome: String,issue: String) -> void:
	# Observation, not a rollback certificate. UID and original host effects stay.
	_delivery_receipts.append({"outcome":outcome,"error":issue,"owner":_delivery.owner.id,"round":_delivery.round,"source_uid":_delivery.original_ticket.source_uid,"token_uid":_delivery.unit.get("uid",""),"uid_before":_delivery.uid_before,"uid_after":game.next_uid,"add_hand_called":_delivery.add_hand_called,"phase_after":game.state.phase})
	if _delivery_receipts.size()>64: _delivery_receipts.pop_front()
func abort_delivery(game,p: Dictionary,plan: Dictionary,reason: String) -> String:
	if not plan.get("active",false): return ""
	var stage: String=str(_delivery.get("state",""))
	if stage not in ["prepared","bound"]: return "darkcrest_cannot_abort_started_delivery"
	var issue: String=_delivery_error(game,p,plan,stage)
	if not issue.is_empty(): return issue
	# No _add_hand has been called through this receipt. Never erase a real card.
	_record_delivery(game,"aborted_before_delivery",reason)
	_delivery={}
	return ""
func bind_delivery(game,p: Dictionary,u: Dictionary,plan: Dictionary) -> String:
	if not plan.get("active",false): return ""
	var issue: String=_delivery_error(game,p,plan,"prepared")
	if not issue.is_empty(): return issue
	if not Sources.unit_error(u).is_empty() or u.get("card_id")!=_delivery.spell_id or u.get("uid")!="u"+str(_delivery.uid_before) or game.next_uid!=_delivery.uid_before+1 or _spells.has(u.get("uid")) or u.get("is_spellcraft")!=true or u.get("expires_at_end_turn")!=true: return "darkcrest_invalid_actual_token_factory"
	if p.hand.any(func(held):return is_same(held,u) or held.get("uid")==u.uid): return "darkcrest_token_already_present"
	if not Sources.same(_delivery.ticket,_delivery.original_ticket): return "darkcrest_prepared_ticket_changed"
	_delivery.unit=u;_delivery.state="bound"
	return ""
func begin_delivery(game,p: Dictionary,plan: Dictionary) -> String:
	if not plan.get("active",false): return ""
	var issue: String=_delivery_error(game,p,plan,"bound")
	if not issue.is_empty(): return issue
	if not Sources.same(_delivery.ticket,_delivery.original_ticket) or not p.get("spellcraft_waiting",[]).any(func(t):return is_same(t,_delivery.ticket)): return "darkcrest_original_ticket_before_debit_required"
	_delivery.state="delivering";_delivery.add_hand_called=true
	return ""
static func delivery_observation(p: Dictionary,u: Dictionary,uid_before: int,spell_id: String,ticket: Dictionary,original_ticket: Dictionary) -> Dictionary:
	# Read-only classification. It cannot issue a receipt or mutate any registry.
	var same_count: int=0;var uid_count: int=0;var hand_clean: bool=true
	var seen: Dictionary={}
	var hand: Variant=p.get("hand")
	if not hand is Array: return {"outcome":"held","ticket_clean":false,"same_object_count":0,"same_uid_count":0,"hand_clean":false}
	for held in hand:
		if not held is Dictionary: hand_clean=false;continue
		var uid: Variant=held.get("uid")
		if not uid is String or uid.is_empty() or seen.has(uid): hand_clean=false
		else: seen[uid]=true
		if is_same(held,u): same_count+=1
		if uid==u.get("uid"): uid_count+=1
	var expected: Dictionary=original_ticket.duplicate(true);expected.count=0
	var pending: Variant=p.get("spellcraft_waiting",[])
	var ticket_clean: bool=Sources.same(ticket,expected) and pending is Array
	if pending is Array:
		for remaining in pending:
			if not remaining is Dictionary: ticket_clean=false;continue
			if is_same(remaining,ticket) or (remaining.get("source_uid")==original_ticket.source_uid and remaining.get("effect_index")==original_ticket.effect_index): ticket_clean=false
	var identity_clean: bool=u.get("uid")=="u"+str(uid_before) and u.get("card_id")==spell_id and Sources.unit_error(u).is_empty() and u.get("is_spellcraft")==true and u.get("expires_at_end_turn")==true
	var outcome: String="held"
	if hand_clean and same_count==1 and uid_count==1 and identity_clean: outcome="committed"
	elif hand_clean and same_count==0 and uid_count==0 and ticket_clean and identity_clean: outcome="aborted"
	return {"outcome":outcome,"ticket_clean":ticket_clean,"same_object_count":same_count,"same_uid_count":uid_count,"hand_clean":hand_clean}
static func delivery_transition(pending: Dictionary,spells: Dictionary,observed: Dictionary) -> Dictionary:
	# Pure scalar field-change instructions, NOT authority. No input is mutated.
	# Unit/ticket/window/grant object graphs are never copied or returned here.
	var grant: Dictionary=pending.get("grant",{})
	if pending.get("state")!="delivering" or grant.get("delivered")!=false or grant.get("blocked",false): return {"apply":false,"ok":false,"error":"darkcrest_delivery_transition_replay_or_invalid_state","outcome":"held"}
	var u: Dictionary=pending.get("unit",{})
	var outcome: String=str(observed.get("outcome","held"))
	var issue: String="";var receipt_outcome: String=""
	var set_delivered: bool=false;var set_blocked: bool=false
	var issue_spell: Dictionary={}
	if outcome=="committed" and not spells.has(u.get("uid")):
		issue_spell={"uid":u.uid,"owner":pending.grant_owner,"round":pending.round,"id":u.card_id,"tier":pending.tier,"used":false}
		set_delivered=true
		issue="" if observed.get("ticket_clean",false) else "darkcrest_delivered_ticket_changed"
		receipt_outcome="committed_observed_in_hand"
	elif outcome=="aborted" and not spells.has(u.get("uid")):
		receipt_outcome="aborted_not_observed_in_hand"
	else:
		outcome="held";set_blocked=true
		issue="darkcrest_uncertain_delivery_state";receipt_outcome="held_uncertain_delivery"
	return {"apply":true,"ok":issue.is_empty(),"error":issue,"outcome":outcome,"receipt_outcome":receipt_outcome,"set_delivered":set_delivered,"set_blocked":set_blocked,"issue_spell":issue_spell,"clear_pending":true,"restore_original_ticket":outcome=="aborted"}
func complete_delivery(game,p: Dictionary,plan: Dictionary) -> Dictionary:
	if not plan.get("active",false): return {"ok":true,"error":"","active":false}
	var issue: String=_delivery_error(game,p,plan,"delivering")
	if not issue.is_empty(): return {"ok":false,"error":issue,"active":true,"outcome":"held"}
	var observed: Dictionary=delivery_observation(p,_delivery.unit,_delivery.uid_before,_delivery.spell_id,_delivery.ticket,_delivery.original_ticket)
	var transition: Dictionary=delivery_transition(_delivery,_spells,observed)
	if not transition.apply: return {"ok":false,"error":transition.error,"active":true,"outcome":"held"}
	# Sole applying path: in-place grant writes and the original token object.
	# The pure helper cannot mutate a registry or provide production authority.
	if not transition.issue_spell.is_empty():
		var fields: Dictionary=transition.issue_spell
		_spells[fields.uid]={"unit":_delivery.unit,"owner":fields.owner,"round":fields.round,"id":fields.id,"tier":fields.tier,"used":fields.used}
		_delivery.unit.text=Sources.EXPECTED_CURRENT[fields.id].text.replace("等级1","等级"+str(fields.tier))
		game._log("darkcrest_token_received",{"player":p.id,"source_uid":_delivery.original_ticket.source_uid,"source_id":_delivery.grant_id,"token_uid":fields.uid,"token_id":fields.id,"tier":fields.tier,"round":fields.round})
	if transition.set_delivered: _delivery.grant.delivered=true
	if transition.set_blocked: _delivery.grant.blocked=true
	_record_delivery(game,transition.receipt_outcome,transition.error)
	if transition.clear_pending: _delivery={}
	return {"ok":transition.ok,"error":transition.error,"active":true,"outcome":transition.outcome}
func spell_error(p: Dictionary,u: Dictionary,round_number: int) -> String:
	var r: Dictionary=_spells.get(u.get("uid",""),{})
	if not spell(u) or not Sources.unit_error(u).is_empty() or not is_same(r.get("unit"),u) or r.get("id")!=u.get("card_id") or r.get("owner")!=p.get("id") or r.get("round")!=round_number or r.get("used")!=false or not integer(r.get("tier"),1,MAX_TIER): return "darkcrest_unissued_copied_expired_or_used_token"
	if u.get("is_spellcraft")!=true or u.get("expires_at_end_turn")!=true: return "darkcrest_changed_token_expiry"
	return ""
# Check the full enabled pool BEFORE BulkResourceHost filters supported records.
# No candidate list is passed to the draw; the original weighted domain remains intact.
func cast_error(game,p: Dictionary,u: Dictionary) -> String:
	var issue: String=spell_error(p,u,int(game.state.round))
	if not issue.is_empty(): return issue
	issue=owner_error(game,p)
	if not issue.is_empty(): return issue
	if u.card_id==Sources.SPELLS[1]: return "darkcrest_golden_two_draw_commit_held"
	var n: int=1
	if not integer(game.next_uid,1,2147483647-n): return "darkcrest_uid_headroom_held"
	if p.hand.size()-1+n>10: return "darkcrest_delivery_capacity_held"
	var tier: int=int(_spells[u.uid].tier)
	var total: int=0
	for id in game.pool:
		if id not in game._enabled("minions"): continue
		var card: Dictionary=game.catalog.get_card(str(id))
		if card.is_empty(): return "darkcrest_unknown_enabled_pool_member"
		if card.get("tier")!=tier or card.get("kind")!="minion" or card.get("is_golden",false): continue
		var tribes: Array=card.get("tribes",[])
		if "纳迦" not in tribes and "全部" not in tribes and "all" not in tribes: continue
		if not integer(game.pool[id],0,2147483647): return "darkcrest_invalid_pool_stock"
		if game.pool[id]==0: continue
		issue=candidate_source_error(str(id),card)
		if not issue.is_empty(): return issue
		# Two sequential draws can repeat while stock remains. Refuse ANY
		# possible automatic triple before the first RNG/stock/UID mutation.
		if count(p,str(id))+mini(n,int(game.pool[id]))>=3: return "darkcrest_random_output_triple_held"
		total+=int(game.pool[id])
		if total>2147483647: return "darkcrest_weight_overflow"
	if total<n: return "darkcrest_insufficient_complete_stock_held"
	return ""
func begin_cast(game,p: Dictionary,index: int) -> String:
	if index<0 or index>=p.hand.size() or not spell(p.hand[index]): return ""
	if not _cast.is_empty(): return "darkcrest_reentrant_cast"
	var u: Dictionary=p.hand[index]
	var issue: String=cast_error(game,p,u)
	if not issue.is_empty(): return issue
	_cast={"owner":p,"unit":u,"record":_spells[u.uid],"consumed":false}
	return ""
func consume(p: Dictionary,u: Dictionary,effect: Dictionary) -> Dictionary:
	if _cast.is_empty() or not is_same(_cast.get("owner"),p) or not is_same(_cast.get("unit"),u) or _cast.get("consumed")!=false or not Sources.same(effect,Sources.program(str(u.get("card_id")))[0]): return result("darkcrest_original_cast_dispatch_required")
	_cast.consumed=true;_cast.record.used=true
	return {"ok":true,"error":"","tier":_cast.record.tier,"count":2 if u.card_id==Sources.SPELLS[1] else 1}
func finish_cast() -> void: _cast={}
static func needs_plan(p: Dictionary) -> bool:
	for u in p.get("board",[]):
		if not u is Dictionary: continue
		if parent(u): return true
		for effect in u.get("effects",[]):
			if effect is Dictionary and effect.get("type")==Sources.EOT: return true
	return false
func end_error(game,p: Dictionary) -> String:
	if not active(p) and not needs_plan(p): return ""
	var issue: String=owner_error(game,p)
	if not issue.is_empty(): return issue
	# Other board identities, including Drakkari, fail existing owner_error.
	# Reject owner/trinket repeat families rather than silently dropping repeats.
	if game.EndTurnRepeats.has_modifier(p): return "darkcrest_eot_repeat_family_held"
	for u in p.board:
		if parent(u):
			if u.card_id!=Sources.PARENTS[0] or u.get("golden")!=false: return "darkcrest_golden_eot_held"
			var r: Dictionary=_parents[u.uid]
			if r.tier>=MAX_TIER: return "darkcrest_next_tier_outside_finite_candidate"
			if r.last_eot>=game.state.round: return "darkcrest_duplicate_or_future_end_turn"
	return ""
func round_error(game) -> String:
	for p in game.state.players:
		var issue: String=end_error(game,p)
		if not issue.is_empty(): return issue
	return ""
func advance(_game,_p: Dictionary) -> String:
	# No board-wide writer. Keep a refusing stub for old callers/tests.
	return "darkcrest_original_complete_eot_callback_required"
func begin_eot(game,p: Dictionary,plan: Dictionary) -> String:
	if not needs_plan(p): return ""
	if not actual(game) or not is_same(game._darkcrest_host,self): return "darkcrest_actual_eot_host_required"
	if not _eot.is_empty() or not game._darkcrest_eot_callback.is_empty(): return "darkcrest_nested_eot_schedule"
	if game.state.phase!="end_turn": return "darkcrest_original_eot_required"
	var issue: String=end_error(game,p)
	if not issue.is_empty(): return issue
	var fresh_plan: Dictionary=game.EndTurnRepeats.build_plan(p,game.catalog,game._eot_effect_error,game.state.round,str(game.state.phase))
	if not fresh_plan.get("ok",false): return str(fresh_plan.get("error","darkcrest_invalid_eot_plan"))
	if not Sources.same(plan,fresh_plan) or plan.get("count")!=1: return "darkcrest_changed_or_repeated_eot_plan"
	var expected: Array=[]
	var records: Array=[]
	for index in range(p.board.size()):
		var u: Dictionary=p.board[index]
		if u.card_id!=Sources.PARENTS[0] or u.get("golden")!=false: return "darkcrest_nonordinary_eot_source_held"
		expected.append({"kind":"native","host_uid":u.uid,"source_uid":u.uid,"card_id":u.card_id,"board_index":index,"effects":[Sources.eot_effect(u.card_id)]})
		var r: Dictionary=_parents[u.uid]
		records.append({"unit":u,"record":r,"tier":r.tier,"last_eot":r.last_eot})
	if expected.is_empty() or not Sources.same(plan.programs,expected): return "darkcrest_incomplete_or_foreign_eot_programs"
	_eot={"owner":p,"round":game.state.round,"sequence":game.state.command_sequence,"programs":expected,"records":records,"next":0}
	return ""
func _eot_state_error(game,p: Dictionary) -> String:
	if not actual(game) or not is_same(game._darkcrest_host,self): return "darkcrest_actual_eot_host_required"
	if _eot.is_empty() or not is_same(_eot.get("owner"),p): return "darkcrest_issued_eot_schedule_required"
	if game.state.phase!="end_turn" or game.state.round!=_eot.round or game.state.command_sequence!=_eot.sequence: return "darkcrest_eot_schedule_clock_changed"
	var issue: String=owner_error(game,p)
	if not issue.is_empty(): return issue
	if game.EndTurnRepeats.has_modifier(p): return "darkcrest_eot_repeat_family_held"
	if p.board.size()!=_eot.records.size(): return "darkcrest_eot_board_changed"
	if not integer(_eot.get("next"),0,_eot.records.size()): return "darkcrest_eot_invalid_schedule_cursor"
	for index in range(_eot.records.size()):
		var before: Dictionary=_eot.records[index]
		var program: Dictionary=_eot.programs[index]
		var u: Dictionary=p.board[index]
		var r: Dictionary=_parents.get(program.host_uid,{})
		if not is_same(u,before.unit) or not is_same(r,before.record): return "darkcrest_eot_copied_or_departed_source"
		if u.get("uid")!=program.host_uid or u.get("card_id")!=program.card_id or u.get("golden")!=false: return "darkcrest_eot_source_identity_changed"
		var done: bool=index<int(_eot.next)
		if r.get("tier")!=int(before.tier)+(1 if done else 0) or r.get("last_eot")!=(_eot.round if done else before.last_eot): return "darkcrest_eot_growth_state_changed"
	return ""
func execute_eot(game,p: Dictionary,program: Dictionary,repeat_index: int,occurrence_index: int) -> String:
	var issue: String=_eot_state_error(game,p)
	if not issue.is_empty(): return issue
	var callback: Dictionary=game._darkcrest_eot_callback
	if callback.size()!=7 or not is_same(callback.get("owner"),p) or not is_same(callback.get("program"),program) or callback.get("used")!=false: return "darkcrest_original_eot_callback_required"
	if callback.get("round")!=_eot.round or callback.get("sequence")!=_eot.sequence or callback.get("repeat_index")!=repeat_index or callback.get("occurrence_index")!=occurrence_index: return "darkcrest_changed_eot_callback"
	if repeat_index!=0 or occurrence_index!=0: return "darkcrest_repeated_eot_callback_held"
	var index: int=int(_eot.next)
	if index>=_eot.programs.size(): return "darkcrest_eot_schedule_already_consumed"
	if not Sources.same(program,_eot.programs[index]): return "darkcrest_unissued_or_changed_eot_program"
	var u: Dictionary=p.board[index]
	var r: Dictionary=_parents[u.uid]
	issue=Sources.eot_wrapper_error(game.catalog.get_card(str(u.card_id)),program.effects[0])
	if not issue.is_empty(): return issue
	# Never call end_error here: earlier sources already have last_eot == round.
	if r.tier>=MAX_TIER or r.last_eot>=game.state.round: return "darkcrest_duplicate_or_outside_eot_step"
	callback.used=true
	var previous_tier: int=int(r.tier)
	r.tier+=1
	r.last_eot=game.state.round
	u.text=str(Sources.EXPECTED_CURRENT[u.card_id].text).replace("等级1","等级"+str(r.tier))
	_eot.next+=1
	game._log("darkcrest_tier_upgraded",{"player":p.id,"source_id":u.card_id,"source_uid":u.uid,"before":previous_tier,"after":r.tier,"round":game.state.round})
	return ""
func finish_eot(game,p: Dictionary) -> String:
	if _eot.is_empty(): return "darkcrest_missing_eot_schedule" if needs_plan(p) else ""
	var issue: String=_eot_state_error(game,p)
	if not issue.is_empty(): return issue
	return "" if _eot.next==_eot.programs.size() else "darkcrest_incomplete_eot_schedule"
func cancel_eot() -> void:
	_eot={}

# Ordinary purchase preflight runs the complete command on a detached Game.
# Only fresh, never-played parent acquisitions are projected. This creates no
# live grant/token/window and never exports shadow state back to the live Game.
func bind_purchase_projection(game,shadow,player_id: int,command: Dictionary) -> String:
	if not actual(game) or not is_same(game._darkcrest_host,self): return "darkcrest_live_projection_host_required"
	if not integer(player_id,0,game.state.players.size()-1): return "darkcrest_projection_owner_required"
	var p: Dictionary=game.state.players[player_id]
	var index: Variant=command.get("index")
	if command.get("type",command.get("action",""))!="buy" or not integer(index,0,p.shop.size()-1): return ""
	if not parent(p.shop[int(index)]) and not active(p): return ""
	var issue: String=command_error(game,p,command)
	if not issue.is_empty(): return issue
	if not _purchase_projection.is_empty() or not _cast.is_empty() or not _delivery.is_empty() or not _eot.is_empty() or not _grants.is_empty() or not _spells.is_empty(): return "darkcrest_post_grant_purchase_projection_held"
	if not p.board.is_empty() or not p.get("spellcraft_waiting",[]).is_empty(): return "darkcrest_nonfresh_purchase_projection_held"
	if not actual(shadow) or is_same(game,shadow) or is_same(game._darkcrest_host,shadow._darkcrest_host) or game._ordinary_purchase_projecting or not shadow._ordinary_purchase_projecting: return "darkcrest_detached_purchase_game_required"
	if not is_same(shadow.catalog,game.catalog): return "darkcrest_projection_catalog_changed"
	for key in ["room","state","events","command_log","last_combats","pool","spell_pool","_attack_gain_health_totals"]:
		if is_same(game.get(key),shadow.get(key)) or not Sources.same(game.get(key),shadow.get(key)): return "darkcrest_projection_public_cursor_changed:"+key
	if shadow.next_uid!=game.next_uid or shadow.rng.seed!=game.rng.seed or shadow.rng.state!=game.rng.state or is_same(shadow.rng,game.rng): return "darkcrest_projection_factory_cursor_changed"
	var target=shadow._darkcrest_host
	if not target._parents.is_empty() or not target._grants.is_empty() or not target._spells.is_empty() or not target._delivery.is_empty() or not target._cast.is_empty() or not target._eot.is_empty() or not target._purchase_projection.is_empty(): return "darkcrest_projection_host_not_fresh"
	for other in game.state.players:
		if other.id!=player_id and active(other): return "darkcrest_other_projection_owner_held"
	var records: Dictionary={}
	var detached: Dictionary=shadow.state.players[player_id]
	for zone in ["shop","hand"]:
		for offset in range(p[zone].size()):
			var live: Dictionary=p[zone][offset]
			if not parent(live): continue
			issue=parent_error(live)
			if not issue.is_empty(): return issue
			var record: Dictionary=_parents[live.uid]
			if live.card_id!=Sources.PARENTS[0] or record.tier!=1 or record.last_eot!=-1: return "darkcrest_nonfresh_projection_parent_held"
			var copy: Dictionary=detached[zone][offset]
			if is_same(copy,live) or not Sources.same(copy,live) or records.has(copy.uid): return "darkcrest_projection_parent_copy_changed"
			records[copy.uid]={"unit":copy,"id":record.id,"tier":record.tier,"last_eot":record.last_eot,"shop_origin":record.shop_origin}
	if not records.has(p.shop[int(index)].uid): return "darkcrest_projection_target_not_bound"
	target._parents=records
	target._purchase_projection={"engine":weakref(shadow),"owner":player_id,"command":command.duplicate(true),"internal_command":{"type":"buy","index":int(index)}}
	return ""
func release_purchase_projection() -> void:
	if _purchase_projection.is_empty(): return
	_parents={};_grants={};_spells={};_cast={};_delivery={};_eot={};_delivery_receipts=[]
	_purchase_projection={}
