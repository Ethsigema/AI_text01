extends SceneTree
var game
var cat
var checks=0
const IDS=["BG36_921","BG31_330","BG23_000","BG23_009","BG23_002","BG31_924","BG23_007","BG23_004","BG26_505","BG34_925","BG33_319","BG36_508","BG35_921","BG31_920"]
func must(ok: bool,label: String) -> bool:
 checks+=1
 print("PASS " if ok else "FAIL ",label)
 if not ok:
  if game!=null:print("EVENTS ",JSON.stringify(game.events.slice(-3)))
  quit(1)
 return ok
func fund(target: int) -> bool:
 var p=game.state.players[0]
 for i in range(100):
  if p.gold>=target:return true
  var u=game._unit(cat.get_card("BG28_810"))
  if u.is_empty():return false
  game._add_hand(p,u)
  var before=p.gold
  var result=game.apply_command(0,{"type":"play","index":p.hand.find(u),"target":-1,"position":-1})
  if not result.get("ok",false) or p.gold<=before:print("FUND_FAILURE ",JSON.stringify(result));return false
 return false
func find_parent() -> int:
 var p=game.state.players[0]
 for attempt in range(80):
  for index in range(p.shop.size()):
   if p.shop[index].card_id=="BG31_920":return index
  if not fund(10):return -1
  var result=game.apply_command(0,{"type":"roll"})
  if not result.get("ok",false):print("REFRESH_FAILURE ",JSON.stringify(result));return -1
 return -1
func cast_level(parent: Dictionary,tier: int) -> bool:
 var p=game.state.players[0]
 var tokens=p.hand.filter(func(u):return u.card_id=="BG31_920t")
 if not must(tokens.size()==1,"one_actual_token_tier"+str(tier)):return false
 var token=tokens[0]
 if not must(game._darkcrest_host._parents[parent.uid].tier==tier and game._darkcrest_host._spells[token.uid].tier==tier,"native_source_and_issued_snapshot_tier"+str(tier)):return false
 if not must(token.text.contains("等级"+str(tier)),"actual_token_display_tier"+str(tier)):return false
 var before_uids=p.hand.map(func(u):return u.uid)
 var before_stock=game.pool.duplicate(true)
 var before_spells=p.stats.spells
 var result=game.apply_command(0,{"type":"play","index":p.hand.find(token),"target":-1,"position":-1})
 if not must(result.get("ok",false),"actual_token_public_cast_tier"+str(tier)):print(JSON.stringify(result));return false
 var acquired=p.hand.filter(func(u):return u.uid not in before_uids)
 if not must(acquired.size()==1,"one_actual_received_naga_tier"+str(tier)):return false
 var u=acquired[0]
 if not must(u.kind=="minion" and u.tier==tier and ("纳迦" in u.tribes or "全部" in u.tribes or "all" in u.tribes) and u.pool_kind=="minion" and u.pool_id==u.card_id and u.pool_count==1,"real_factory_owned_naga_tier"+str(tier)):return false
 if not must(p.stats.spells==before_spells+1 and not p.hand.any(func(h):return h.uid==token.uid),"native_cast_consumption_and_counter_tier"+str(tier)):return false
 var changed=[]
 for id in before_stock:
  if before_stock[id]!=game.pool.get(id):changed.append(id)
 if not must(changed==[u.card_id] and game.pool[u.card_id]==before_stock[u.card_id]-1,"real_stock_debited_once_tier"+str(tier)):return false
 print("ACQUIRED ",JSON.stringify({"tier":tier,"source_uid":parent.uid,"token_uid":token.uid,"id":u.card_id,"uid":u.uid,"pool_before":before_stock[u.card_id],"pool_after":game.pool[u.card_id]}))
 return true
func next_round(parent: Dictionary,next_tier: int) -> bool:
 var old=game.state.round
 if not must(game.apply_command(1,{"type":"end_turn"}).get("ok",false),"opponent_public_ready_"+str(old)):return false
 var result=game.apply_command(0,{"type":"end_turn"})
 if not result.get("ok",false):print("END_FAILURE ",JSON.stringify(result))
 if not must(result.get("ok",false) and game.state.phase=="recruit" and game.state.round==old+1,"actual_eot_combat_next_recruit_"+str(old)):return false
 var events=game.events.filter(func(e):return e.get("type")=="darkcrest_tier_upgraded" and e.get("source_uid")==parent.uid and e.get("round")==old)
 print("GROWTH ",JSON.stringify(events))
 if not must(events.size()==1 and events[0].before==next_tier-1 and events[0].after==next_tier,"one_native_eot_growth_"+str(old)):return false
 return must(game._darkcrest_host._eot.is_empty() and game._darkcrest_eot_callback.is_empty(),"eot_context_released_"+str(old))
func setup_room(seed_value: int) -> bool:
 game=load("res://core/game.gd").new()
 var room=load("res://core/room_config.gd").new();room.reset(cat)
 room.data.enabled_minions=IDS.duplicate();room.data.enabled_spells=["BG28_810"]
 room.data.selected_hero="TB_BaconShop_HERO_01";room.data.enabled_heroes=["TB_BaconShop_HERO_01"];room.data.bot_count=1;room.data.seed=seed_value
 for key in ["enabled_anomalies","enabled_quests","enabled_rewards","enabled_trinkets"]:room.data[key]=[]
 var started=game.start(room.data,cat)
 if not must(started.get("ok",false),"actual_room_"+str(seed_value)):print(JSON.stringify(started));return false
 var p=game.state.players[0]
 for tier in [2,3,4,5]:
  if not must(fund(int(p.upgrade_cost)+3),"coin_funding_upgrade_"+str(tier)):return false
  if not must(game.apply_command(0,{"type":"upgrade"}).get("ok",false) and p.tier==tier,"public_upgrade_"+str(tier)):return false
 return true
func buy_parent() -> Dictionary:
 var p=game.state.players[0]
 var index=find_parent()
 if not must(index>=0,"real_darkcrest_offer"):return {}
 if not must(fund(6),"real_purchase_gold"):return {}
 var parent=p.shop[index]
 if not must(game.apply_command(0,{"type":"buy","index":index}).get("ok",false) and p.hand.has(parent),"real_parent_buy"):return {}
 return parent
func source_play(parent: Dictionary) -> bool:
 var p=game.state.players[0]
 return must(game.apply_command(0,{"type":"play","index":p.hand.find(parent),"target":-1,"position":-1}).get("ok",false) and p.board.has(parent),"public_darkcrest_play_"+parent.uid)
func growth_case() -> bool:
 if not setup_room(20261112):return false
 var p=game.state.players[0]
 var parent=buy_parent()
 if parent.is_empty() or not source_play(parent):return false
 for tier in [1,2,3]:
  if not cast_level(parent,tier):return false
  if tier<3 and not next_round(parent,tier+1):return false
 if not next_round(parent,4):return false
 var tokens=p.hand.filter(func(u):return u.card_id=="BG31_920t")
 if not must(tokens.size()==1,"tier4_token_is_real_but_unaccepted_domain"):return false
 var token=tokens[0]
 var before_hand=p.hand.duplicate(true);var before_pool=game.pool.duplicate(true);var before_rng=str(game.rng.state);var before_uid=game.next_uid;var before_count=p.stats.spells
 var held=game.apply_command(0,{"type":"play","index":p.hand.find(token),"target":-1,"position":-1})
 print("EXPECTED_TIER4_HOLD ",JSON.stringify(held))
 if not must(not held.get("ok",true) and str(held.get("error","")).begins_with("darkcrest_complete_random_candidate_held:"),"full_tier4_domain_held_before_consumption"):return false
 if not must(game.Darkcrest.Sources.same(before_hand,p.hand) and game.Darkcrest.Sources.same(before_pool,game.pool) and str(game.rng.state)==before_rng and game.next_uid==before_uid and p.stats.spells==before_count and not game._darkcrest_host._spells[token.uid].used,"tier4_hold_preserves_hand_stock_rng_uid_counter"):return false
 var end=game.apply_command(0,{"type":"end_turn"})
 if not must(not end.get("ok",true) and end.get("error")=="darkcrest_next_tier_outside_finite_candidate" and game.state.phase=="recruit" and game.state.round==4 and game._darkcrest_host._parents[parent.uid].tier==4,"finite_boundary_refuses_instead_of_clamping"):return false
 print("GROWTH_CASE_PASS")
 return true
func fill_eight_native_hands() -> bool:
 var p=game.state.players[0]
 var allowed=["BG23_009","BG23_002","BG31_924","BG23_007","BG23_004"]
 for attempt in range(240):
  if p.hand.size()==8:return true
  var chosen=-1
  for index in range(p.shop.size()):
   var id=p.shop[index].card_id
   if id in allowed and p.hand.filter(func(u):return u.card_id==id).size()<2:chosen=index;break
  if chosen>=0:
   if not fund(4):return false
   var result=game.apply_command(0,{"type":"buy","index":chosen})
   if not result.get("ok",false):print("FILL_BUY_FAILURE ",JSON.stringify(result));return false
  else:
   if not fund(3):return false
   if not game.apply_command(0,{"type":"roll"}).get("ok",false):return false
 return false
func buy_two_parents() -> Array:
 var p=game.state.players[0]
 for attempt in range(240):
  var offers=p.shop.filter(func(u):return u.card_id=="BG31_920")
  if offers.size()>=2:
   if not fund(6):return []
   var selected=[offers[0],offers[1]]
   for source in selected:
    var result=game.apply_command(0,{"type":"buy","index":p.shop.find(source)})
    if not result.get("ok",false):print("TWO_BUY_FAILURE ",JSON.stringify(result));return []
   return selected
  if not fund(3):return []
  if not game.apply_command(0,{"type":"roll"}).get("ok",false):return []
 return []
func waiting_case() -> bool:
 if not setup_room(20261113):return false
 var p=game.state.players[0]
 if not must(fill_eight_native_hands(),"eight_real_shop_bought_tier2_3_nagas"):return false
 var parents=buy_two_parents()
 if not must(parents.size()==2 and p.hand.size()==10,"two_real_shop_parents_fill_ten_card_hand"):return false
 var first=parents[0];var second=parents[1]
 if not source_play(first):return false
 if not cast_level(first,1):return false
 if not must(p.hand.size()==10 and p.hand.has(second),"actual_generated_naga_leaves_full_hand"):return false
 if not next_round(first,2):return false
 if not must(game.SpellcraftWaiting.pending_count(p)==1 and p.hand.size()==10 and not p.hand.any(func(u):return u.card_id=="BG31_920t"),"native_full_hand_waits_without_fake_token"):return false
 if not must(game._darkcrest_host._parents[second.uid].tier==1 and game._darkcrest_host._parents[second.uid].last_eot==-1,"hand_parent_does_not_receive_board_eot"):return false
 if not source_play(second):return false
 var tokens=p.hand.filter(func(u):return u.card_id=="BG31_920t")
 if not must(tokens.size()==1 and game.SpellcraftWaiting.pending_count(p)==1,"real_second_play_frees_one_slot_and_resumes_waiting"):return false
 var token=tokens[0]
 var receipt=game.events.filter(func(e):return e.get("type")=="darkcrest_token_received" and e.get("token_uid")==token.uid)
 if not must(receipt.size()==1 and receipt[0].source_uid==first.uid and receipt[0].tier==2 and game._darkcrest_host._spells[token.uid].tier==2,"waiting_delivers_original_first_source_tier2_snapshot"):return false
 if not must(p.spellcraft_waiting.size()==1 and p.spellcraft_waiting[0].source_uid==second.uid and game._darkcrest_host._grants[second.uid].tier==1 and not game._darkcrest_host._grants[second.uid].delivered,"second_source_tier1_ticket_stays_pending"):return false
 var old_ticket=p.spellcraft_waiting[0]
 if not next_round(first,3):return false
 var second_events=game.events.filter(func(e):return e.get("type")=="darkcrest_tier_upgraded" and e.get("source_uid")==second.uid and e.get("round")==2)
 if not must(second_events.size()==1 and second_events[0].before==1 and second_events[0].after==2 and game._darkcrest_host._parents[second.uid].tier==2,"native_scheduler_advances_second_source_once"):return false
 if not must(p.spellcraft_waiting.size()==1 and p.spellcraft_waiting[0].round==3 and p.spellcraft_waiting[0].source_uid==second.uid and not is_same(p.spellcraft_waiting[0],old_ticket) and game._darkcrest_host._grants[second.uid].tier==2,"old_pending_ticket_cancelled_and_new_round_snapshot_issued"):return false
 if not must(not p.hand.any(func(u):return u.uid==token.uid),"uncast_old_token_expires_natively"):return false
 var new_tokens=p.hand.filter(func(u):return u.card_id=="BG31_920t")
 if not must(new_tokens.size()==1 and game._darkcrest_host._spells[new_tokens[0].uid].tier==3 and new_tokens[0].text.contains("等级3"),"new_first_source_tier3_waiting_delivery"):return false
 print("WAITING_CASE_PASS")
 return true
func _initialize():
 print("LOAD_BEGIN")
 var Game=load("res://core/game.gd")
 if not must(Game!=null and Game.can_instantiate(),"complete_game_script"):return
 cat=load("res://core/catalog.gd").new();cat.load_catalog()
 if not must(cat.load_errors.is_empty(),"complete_catalog"):print(JSON.stringify(cat.load_errors));return
 for id in ["BG31_920","BG31_920_G","BG31_920t","BG31_920_Gt"]:
  if not must(not cat.get_card(id).is_empty(),"complete_source_"+id):return
 if not growth_case():return
 if not waiting_case():return
 print("DARKCREST_REAL_MATRIX_PASS cases=2 checks=",checks)
 quit(0)
