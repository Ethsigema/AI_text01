extends SceneTree
var game
var cat
var checks=0
const IDS=["BG36_921","BG31_330","BG23_000","BG23_009","BG23_002","BG31_924","BG23_007","BG23_004","BG26_505","BG34_925","BG33_319","BG36_508","BG35_921","BG31_920"]
func must(ok: bool,label: String) -> bool:
 checks+=1
 print("PASS " if ok else "FAIL ",label)
 if not ok:
  if game!=null:print("EVENTS ",JSON.stringify(game.events.slice(-3)))
  quit(1)
 return ok
func fund(target: int) -> bool:
 var p=game.state.players[0]
 for i in range(100):
  if p.gold>=target:return true
  var u=game._unit(cat.get_card("BG28_810"))
  if u.is_empty():return false
  game._add_hand(p,u)
  var before=p.gold
  var result=game.apply_command(0,{"type":"play","index":p.hand.find(u),"target":-1,"position":-1})
  if not result.get("ok",false) or p.gold<=before:print("FUND_FAILURE ",JSON.stringify(result));return false
 return false
func find_parent() -> int:
 var p=game.state.players[0]
 for attempt in range(80):
  for index in range(p.shop.size()):
   if p.shop[index].card_id=="BG31_920":return index
  if not fund(10):return -1
  var result=game.apply_command(0,{"type":"roll"})
  if not result.get("ok",false):print("REFRESH_FAILURE ",JSON.stringify(result));return -1
 return -1
func cast_level(parent: Dictionary,tier: int) -> bool:
 var p=game.state.players[0]
 var tokens=p.hand.filter(func(u):return u.card_id=="BG31_920t")
 if not must(tokens.size()==1,"one_actual_token_tier"+str(tier)):return false
 var token=tokens[0]
 if not must(game._darkcrest_host._parents[parent.uid].tier==tier and game._darkcrest_host._spells[token.uid].tier==tier,"native_source_and_issued_snapshot_tier"+str(tier)):return false
 if not must(token.text.contains("等级"+str(tier)),"actual_token_display_tier"+str(tier)):return false
 var before_uids=p.hand.map(func(u):return u.uid)
 var before_stock=game.pool.duplicate(true)
 var before_spells=p.stats.spells
 var result=game.apply_command(0,{"type":"play","index":p.hand.find(token),"target":-1,"position":-1})
 if not must(result.get("ok",false),"actual_token_public_cast_tier"+str(tier)):print(JSON.stringify(result));return false
 var acquired=p.hand.filter(func(u):return u.uid not in before_uids)
 if not must(acquired.size()==1,"one_actual_received_naga_tier"+str(tier)):return false
 var u=acquired[0]
 if not must(u.kind=="minion" and u.tier==tier and ("纳迦" in u.tribes or "全部" in u.tribes or "all" in u.tribes) and u.pool_kind=="minion" and u.pool_id==u.card_id and u.pool_count==1,"real_factory_owned_naga_tier"+str(tier)):return false
 if not must(p.stats.spells==before_spells+1 and not p.hand.any(func(h):return h.uid==token.uid),"native_cast_consumption_and_counter_tier"+str(tier)):return false
 var changed=[]
 for id in before_stock:
  if before_stock[id]!=game.pool.get(id):changed.append(id)
 if not must(changed==[u.card_id] and game.pool[u.card_id]==before_stock[u.card_id]-1,"real_stock_debited_once_tier"+str(tier)):return false
 print("ACQUIRED ",JSON.stringify({"tier":tier,"source_uid":parent.uid,"token_uid":token.uid,"id":u.card_id,"uid":u.uid,"pool_before":before_stock[u.card_id],"pool_after":game.pool[u.card_id]}))
 return true
func next_round(parent: Dictionary,next_tier: int) -> bool:
 var old=game.state.round
 if not must(game.apply_command(1,{"type":"end_turn"}).get("ok",false),"opponent_public_ready_"+str(old)):return false
 var result=game.apply_command(0,{"type":"end_turn"})
 if not result.get("ok",false):print("END_FAILURE ",JSON.stringify(result))
 if not must(result.get("ok",false) and game.state.phase=="recruit" and game.state.round==old+1,"actual_eot_combat_next_recruit_"+str(old)):return false
 var events=game.events.filter(func(e):return e.get("type")=="darkcrest_tier_upgraded" and e.get("source_uid")==parent.uid and e.get("round")==old)
 print("GROWTH ",JSON.stringify(events))
 if not must(events.size()==1 and events[0].before==next_tier-1 and events[0].after==next_tier,"one_native_eot_growth_"+str(old)):return false
 return must(game._darkcrest_host._eot.is_empty() and game._darkcrest_eot_callback.is_empty(),"eot_context_released_"+str(old))
func _initialize():
 print("LOAD_BEGIN")
 var Game=load("res://core/game.gd")
 if not must(Game!=null and Game.can_instantiate(),"complete_game_script"):return
 cat=load("res://core/catalog.gd").new();cat.load_catalog()
 print("CATALOG_ERRORS ",JSON.stringify(cat.load_errors))
 if not must(cat.load_errors.is_empty(),"complete_catalog"):return
 for id in ["BG31_920","BG31_920_G","BG31_920t","BG31_920_Gt"]:
  if not must(not cat.get_card(id).is_empty(),"complete_source_"+id):return
 game=Game.new()
 var room=load("res://core/room_config.gd").new();room.reset(cat)
 room.data.enabled_minions=IDS.duplicate();room.data.enabled_spells=["BG28_810"]
 room.data.selected_hero="TB_BaconShop_HERO_01";room.data.enabled_heroes=["TB_BaconShop_HERO_01"];room.data.bot_count=1;room.data.seed=20261112
 for key in ["enabled_anomalies","enabled_quests","enabled_rewards","enabled_trinkets"]:room.data[key]=[]
 var started=game.start(room.data,cat)
 print("START ",JSON.stringify(started))
 if not must(started.get("ok",false),"actual_limited_room"):return
 var p=game.state.players[0]
 for tier in [2,3,4,5]:
  if not must(fund(int(p.upgrade_cost)+3),"actual_coin_funding_upgrade_"+str(tier)):return
  if not must(game.apply_command(0,{"type":"upgrade"}).get("ok",false) and p.tier==tier,"actual_public_upgrade_"+str(tier)):return
 var index=find_parent()
 if not must(index>=0,"real_shop_offers_darkcrest"):return
 if not must(fund(6),"actual_purchase_funding"):return
 var parent=p.shop[index]
 if not must(game.apply_command(0,{"type":"buy","index":index}).get("ok",false) and p.hand.has(parent),"actual_shop_purchase"):return
 if not must(game.apply_command(0,{"type":"play","index":p.hand.find(parent),"target":-1,"position":-1}).get("ok",false) and p.board.has(parent),"actual_parent_public_play"):return
 for tier in [1,2,3]:
  if not cast_level(parent,tier):return
  if tier<3 and not next_round(parent,tier+1):return
 print("DARKCREST_REAL_GROWTH_PASS checks=",checks)
 quit(0)
