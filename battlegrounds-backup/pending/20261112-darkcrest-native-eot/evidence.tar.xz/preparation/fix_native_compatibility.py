from pathlib import Path
import json,hashlib,subprocess
r=Path(__file__).resolve().parent;p=r/'game_candidate'
h={f.relative_to(p).as_posix():hashlib.sha256(f.read_bytes()).hexdigest() for f in p.rglob('*') if f.is_file()}
(r/'evidence/BEFORE_NATIVE_COMPAT_HASHES.json').write_text(json.dumps(h,indent=2)+'\n')
subprocess.run(['patch','-p1','-i',str((r/'research_old_candidate/seafloor_current_annotation_compat.patch').resolve())],cwd=p,check=True)
f=p/'core/darkcrest_host.gd';s=f.read_text();old='"pool_id":id,"pool_kind":"minion"}\n\tfor key in expected:';new='"pool_id":id}\n\t# Ordinary shop minions omit this field; Bulk resource minions include it.\n\tif u.has("pool_kind"): expected.pool_kind="minion"\n\tfor key in expected:';assert s.count(old)==1;s=s.replace(old,new);f.write_text(s)
