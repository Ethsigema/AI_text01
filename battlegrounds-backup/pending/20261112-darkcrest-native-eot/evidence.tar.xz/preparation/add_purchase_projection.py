from pathlib import Path
import json,hashlib
r=Path(__file__).resolve().parent;p=r/'game_candidate'
(r/'evidence/BEFORE_PROJECTION_HASHES.json').write_text(json.dumps({f.relative_to(p).as_posix():hashlib.sha256(f.read_bytes()).hexdigest() for f in p.rglob('*') if f.is_file()},indent=2)+'\n')
f=p/'core/darkcrest_host.gd';s=f.read_text();s=s.replace('var _eot: Dictionary={}','var _eot: Dictionary={}\nvar _purchase_projection: Dictionary={}')
s=s.replace('func owner_error(game,p: Dictionary) -> String:\n','func owner_error(game,p: Dictionary) -> String:\n\tif not _purchase_projection.is_empty() and not is_same(_purchase_projection.engine.get_ref(),game): return "darkcrest_projection_engine_mismatch"\n')
s=s.replace('func command_error(game,p: Dictionary,command: Dictionary) -> String:\n','func command_error(game,p: Dictionary,command: Dictionary) -> String:\n\tif not _purchase_projection.is_empty() and (not is_same(_purchase_projection.engine.get_ref(),game) or p.get("id")!=_purchase_projection.owner or not Sources.same(command,_purchase_projection.command)): return "darkcrest_projection_command_mismatch"\n')
s+='''
# Ordinary purchase preflight runs the complete command on a detached Game.
# Only fresh, never-played parent acquisitions are projected. This creates no
# live grant/token/window and never exports shadow state back to the live Game.
func bind_purchase_projection(game,shadow,player_id: int,command: Dictionary) -> String:
	if not actual(game) or not is_same(game._darkcrest_host,self): return "darkcrest_live_projection_host_required"
	if not integer(player_id,0,game.state.players.size()-1): return "darkcrest_projection_owner_required"
	var p: Dictionary=game.state.players[player_id]
	var index: Variant=command.get("index")
	if command.get("type")!="buy" or not integer(index,0,p.shop.size()-1): return ""
	if not parent(p.shop[int(index)]) and not active(p): return ""
	var issue: String=command_error(game,p,command)
	if not issue.is_empty(): return issue
	if not _purchase_projection.is_empty() or not _cast.is_empty() or not _delivery.is_empty() or not _eot.is_empty() or not _grants.is_empty() or not _spells.is_empty(): return "darkcrest_post_grant_purchase_projection_held"
	if not p.board.is_empty() or not p.get("spellcraft_waiting",[]).is_empty(): return "darkcrest_nonfresh_purchase_projection_held"
	if not actual(shadow) or is_same(game,shadow) or is_same(game._darkcrest_host,shadow._darkcrest_host) or game._ordinary_purchase_projecting or not shadow._ordinary_purchase_projecting: return "darkcrest_detached_purchase_game_required"
	if not is_same(shadow.catalog,game.catalog): return "darkcrest_projection_catalog_changed"
	for key in ["room","state","events","command_log","last_combats","pool","spell_pool","_attack_gain_health_totals"]:
		if is_same(game.get(key),shadow.get(key)) or not Sources.same(game.get(key),shadow.get(key)): return "darkcrest_projection_public_cursor_changed:"+key
	if shadow.next_uid!=game.next_uid or shadow.rng.seed!=game.rng.seed or shadow.rng.state!=game.rng.state or is_same(shadow.rng,game.rng): return "darkcrest_projection_factory_cursor_changed"
	var target=shadow._darkcrest_host
	if not target._parents.is_empty() or not target._grants.is_empty() or not target._spells.is_empty() or not target._delivery.is_empty() or not target._cast.is_empty() or not target._eot.is_empty() or not target._purchase_projection.is_empty(): return "darkcrest_projection_host_not_fresh"
	for other in game.state.players:
		if other.id!=player_id and active(other): return "darkcrest_other_projection_owner_held"
	var records: Dictionary={}
	var detached: Dictionary=shadow.state.players[player_id]
	for zone in ["shop","hand"]:
		for offset in range(p[zone].size()):
			var live: Dictionary=p[zone][offset]
			if not parent(live): continue
			issue=parent_error(live)
			if not issue.is_empty(): return issue
			var record: Dictionary=_parents[live.uid]
			if live.card_id!=Sources.PARENTS[0] or record.tier!=1 or record.last_eot!=-1: return "darkcrest_nonfresh_projection_parent_held"
			var copy: Dictionary=detached[zone][offset]
			if is_same(copy,live) or not Sources.same(copy,live) or records.has(copy.uid): return "darkcrest_projection_parent_copy_changed"
			records[copy.uid]={"unit":copy,"id":record.id,"tier":record.tier,"last_eot":record.last_eot,"shop_origin":record.shop_origin}
	if not records.has(p.shop[int(index)].uid): return "darkcrest_projection_target_not_bound"
	target._parents=records
	target._purchase_projection={"engine":weakref(shadow),"owner":player_id,"command":command.duplicate(true)}
	return ""
func release_purchase_projection() -> void:
	if _purchase_projection.is_empty(): return
	_parents={};_grants={};_spells={};_cast={};_delivery={};_eot={};_delivery_receipts=[]
	_purchase_projection={}
'''
f.write_text(s)
f=p/'core/owned_purchase_host.gd';s=f.read_text();old='\tshadow._ordinary_purchase_projecting=true\n\tvar result: Dictionary=shadow.apply_command(player_id,command.duplicate(true))';new='\tshadow._ordinary_purchase_projecting=true\n\tvar darkcrest_projection_issue: String=engine._darkcrest_host.bind_purchase_projection(engine,shadow,player_id,command)\n\tif not darkcrest_projection_issue.is_empty(): return darkcrest_projection_issue\n\tvar result: Dictionary=shadow.apply_command(player_id,command.duplicate(true))\n\tshadow._darkcrest_host.release_purchase_projection()';assert s.count(old)==1;s=s.replace(old,new);f.write_text(s)
