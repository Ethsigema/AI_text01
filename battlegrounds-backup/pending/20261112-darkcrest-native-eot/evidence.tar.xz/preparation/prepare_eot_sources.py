from pathlib import Path
import json,re
r=Path(__file__).resolve().parent;p=r/'game_candidate';f=p/'core/darkcrest_sources.gd';s=f.read_text()
s=s.replace('const TYPE = "spell_generate_tier_one_naga"','const TYPE = "spell_generate_tier_one_naga"\nconst EOT = "end_turn_darkcrest_upgrade"')
def replace_const(name,edit):
 global s
 pat=re.compile(r'^const '+name+r' = (.*)$',re.M);m=pat.search(s);assert m;v=json.loads(m[1]);edit(v);s=s[:m.start(1)]+json.dumps(v,ensure_ascii=False,separators=(',',':'))+s[m.end(1):]
def effects(v):
 for id in ['BG31_920','BG31_920_G']:
  assert len(v[id]['effects'])==1
  v[id]['effects'].append({'type':'end_turn_darkcrest_upgrade','source_id':id})
replace_const('EFFECTIVE_FIELDS',effects);replace_const('EXPECTED_CURRENT',effects)
f.write_text(s)
f=p/'data/darkcrest_overlay.json';v=json.loads(f.read_text())
for entry in v['cards']:
 if entry['id'] in ['BG31_920','BG31_920_G']:entry['effective_fields']['effects'].append({'type':'end_turn_darkcrest_upgrade','source_id':entry['id']})
f.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
# New tokens continue to snapshot source tier in the private issued receipt;
# only their displayed text follows that already-issued tier.
f=p/'core/darkcrest_host.gd';s=f.read_text();needle='\t\t_spells[fields.uid]={"unit":_delivery.unit,"owner":fields.owner,"round":fields.round,"id":fields.id,"tier":fields.tier,"used":fields.used}\n';assert s.count(needle)==1
s=s.replace(needle,needle+'\t\t_delivery.unit.text=Sources.EXPECTED_CURRENT[fields.id].text.replace("等级1","等级"+str(fields.tier))\n\t\tgame._log("darkcrest_token_received",{"player":p.id,"source_uid":_delivery.original_ticket.source_uid,"source_id":_delivery.grant_id,"token_uid":fields.uid,"token_id":fields.id,"tier":fields.tier,"round":fields.round})\n');f.write_text(s)
