from pathlib import Path
import re,json,shutil,hashlib
r=Path(__file__).resolve().parent;p=r/'game_candidate';a=r/'research_old_candidate/20261110-darkcrest-domain-review/extracted/darkcrest_domain_review_20261110T054142Z/candidate'
new=['core/darkcrest_host.gd','core/darkcrest_sources.gd','data/darkcrest_overlay.json']+[x.relative_to(a).as_posix() for x in sorted((a/'research/darkcrest').iterdir()) if x.is_file()]
for n in new:
 dest=p/n;assert not dest.exists(),n;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(a/n,dest)
changes=[]
for name in ['game','catalog','spellcraft_waiting']:
 lines=(r/f'research_old_candidate/compare_core_{name}.gd.diff').read_text().splitlines(keepends=True);s=(p/f'core/{name}.gd').read_text();hunks=[];group=None
 for line in lines:
  if line.startswith('@@'):
   if group is not None:hunks.append(group)
   group=[]
  elif group is not None:group.append(line)
 if group is not None:hunks.append(group)
 for group in hunks:
  before=''.join(x[1:] for x in group if x.startswith((' ','-')))
  after=''
  for x in group:
   if x.startswith((' ','+')):
    if x.startswith('+') and ('var darkcrest_eot_issue: String=_darkcrest_host.advance(self,p)' in x or 'if not _native_result({"ok":darkcrest_eot_issue.is_empty(),"error":darkcrest_eot_issue}): return' in x):continue
    after+=x[1:]
   elif x=='-\t_rider_combat_authority={}\n':after+=x[1:]
  assert s.count(before)==1,(name,before[:100],s.count(before));s=s.replace(before,after,1)
 (p/f'core/{name}.gd').write_text(s);changes.append({'file':f'core/{name}.gd','hunks':len(hunks)})
# Preserve exact native golden annotation while keeping all other source fields exact.
f=p/'core/darkcrest_sources.gd';s=f.read_text();old='\treturn "" if same(card,EXPECTED_CURRENT[card.id]) else "darkcrest_changed_whole_source"';assert s.count(old)==1
s=s.replace(old,'\tvar expected: Dictionary=EXPECTED_CURRENT[card.id].duplicate(true)\n\tif card.id==PARENTS[1] and card.has("pool_blocker"):\n\t\texpected.pool_blocker=preload("res://core/pool_identity.gd").MINION_REASON\n\treturn "" if same(card,expected) else "darkcrest_changed_whole_source"');f.write_text(s)
(r/'evidence/IMPORT.json').write_text(json.dumps({'copied':new,'patched':changes,'preserved':['Rider base_unit flag in Combat','Game rider authority release'],'omitted':['archive whole-board advance after hero EOT']},indent=2)+'\n');print(json.dumps(changes))
