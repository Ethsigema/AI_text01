from pathlib import Path
import json,hashlib,shutil,re
r=Path(__file__).resolve().parent;p=r/'game_candidate';e=r/'evidence'
assert json.loads((e/'darkcrest_real_matrix_v4_result.json').read_text())['exit']==0
(e/'BEFORE_FINAL_HASHES.json').write_text(json.dumps({f.relative_to(p).as_posix():hashlib.sha256(f.read_bytes()).hexdigest() for f in p.rglob('*') if f.is_file()},indent=2)+'\n')
f=p/'core/darkcrest_host.gd';s=f.read_text();s=s.replace('not Sources.same(command,_purchase_projection.command)', '(not Sources.same(command,_purchase_projection.command) and not Sources.same(command,_purchase_projection.internal_command))');s=s.replace('if command.get("type")!="buy" or not integer(index,0,p.shop.size()-1): return ""','if command.get("type",command.get("action",""))!="buy" or not integer(index,0,p.shop.size()-1): return ""');s=s.replace('"command":command.duplicate(true)}','"command":command.duplicate(true),"internal_command":{"type":"buy","index":int(index)}}');f.write_text(s)
replacements={
'darkcrest-turn-candidate-20261110':'darkcrest-native-eot-candidate-20261112',
'partial_darkcrest_turn_candidate_uninstalled':'partial_darkcrest_native_eot_verified_slice',
'darkcrest_gameplay_candidate_20261110':'darkcrest_native_eot_candidate_20261112',
'Finite fresh-source tiers 1 through 4, private once-per-turn snapshot. Original filtered stock-weighted draw and original hand delivery. Full engine not executed; golden acquisition and inheritance held.':'Real Game limited slice: fresh ordinary native shop acquisition; original end-of-turn scheduler, tier 1/2/3 stock-weighted generation, waiting and expiry. Tier 4 is an admission boundary, not an official cap. Golden, post-grant purchase, mixed boards, inheritance and saves held.'}
for name in ['core/darkcrest_sources.gd','data/darkcrest_overlay.json']:
 f=p/name;s=f.read_text()
 for a,b in replacements.items():assert a in s,(name,a);s=s.replace(a,b)
 f.write_text(s)
s=(e/'darkcrest_real_matrix_v4.gd').read_text()
s=re.sub(r'^ print\("PARENT_PREBUY .*\n','',s,flags=re.M)
s=s.replace('var parent=p.shop[index]\n if not must','var parent=p.shop[index]\n if not projection_checks(parent,index):return {}\n if not must')
helper='''func projection_cursor(p: Dictionary) -> Dictionary:
 return {"player":p.duplicate(true),"totals":game._attack_gain_health_totals.duplicate(true),"next_uid":game.next_uid,"rng_seed":game.rng.seed,"rng_state":game.rng.state,"pool":game.pool.duplicate(true),"spell_pool":game.spell_pool.duplicate(true)}
func live_snapshot() -> Dictionary:
 return {"state":game.state.duplicate(true),"pool":game.pool.duplicate(true),"spell_pool":game.spell_pool.duplicate(true),"rng":str(game.rng.state),"uid":game.next_uid,"events":game.events.duplicate(true),"commands":game.command_log.duplicate(true),"parents":game._darkcrest_host._parents.duplicate(true),"grants":game._darkcrest_host._grants.duplicate(true),"spells":game._darkcrest_host._spells.duplicate(true)}
func projection_checks(parent: Dictionary,index: int) -> bool:
 var p=game.state.players[0]
 var cmd={"type":"buy","index":index}
 var before=live_snapshot()
 var issue=game.OwnedPurchases.command_preflight(game,0,cmd)
 if not must(issue.is_empty(),"complete_native_purchase_projection_passes"):print(issue);return false
 if not must(game.Darkcrest.Sources.same(before,live_snapshot()) and is_same(p.shop[index],parent),"native_projection_preserves_all_live_state_and_identity"):return false
 for mutation in ["uid","program","shared_object"]:
  var detached=game.OwnedPurchases.Prefix.create(game,projection_cursor(p))
  if not must(detached.get("ok",false),"native_detached_cursor_"+mutation):return false
  var shadow=detached.engine
  if mutation=="uid":shadow.state.players[0].shop[index].uid="u9999999"
  if mutation=="program":shadow.state.players[0].shop[index].effects[1].source_id="forged"
  if mutation=="shared_object":shadow.state.players[0].shop[index]=parent
  issue=game._darkcrest_host.bind_purchase_projection(game,shadow,0,cmd)
  if not must(not issue.is_empty() and shadow._darkcrest_host._parents.is_empty(),"reject_changed_or_shared_projection_"+mutation):return false
 var detached=game.OwnedPurchases.Prefix.create(game,projection_cursor(p))
 if not must(detached.get("ok",false),"native_detached_cursor_exact"):return false
 var shadow=detached.engine
 var external={"action":"buy","index":index,"trace":"exact_extra_metadata"}
 issue=game._darkcrest_host.bind_purchase_projection(game,shadow,0,external)
 if not must(issue.is_empty(),"projection_accepts_exact_original_action_form"):print(issue);return false
 if not must(shadow._darkcrest_host.command_error(shadow,shadow.state.players[0],external).is_empty() and shadow._darkcrest_host.command_error(shadow,shadow.state.players[0],cmd).is_empty(),"projection_original_and_native_internal_buy_only"):return false
 if not must(not shadow._darkcrest_host.command_error(shadow,shadow.state.players[0],{"type":"freeze"}).is_empty(),"projection_refuses_other_command"):return false
 if not must(not shadow._darkcrest_host.parent_error(parent).is_empty() and not shadow._darkcrest_host.owner_error(game,p).is_empty(),"projected_records_cannot_authorize_live_objects_or_game"):return false
 shadow._darkcrest_host.release_purchase_projection()
 if not must(shadow._darkcrest_host._parents.is_empty() and shadow._darkcrest_host._purchase_projection.is_empty(),"projection_release_erases_detached_records"):return false
 return must(game.Darkcrest.Sources.same(before,live_snapshot()) and game._darkcrest_host.parent_error(parent).is_empty(),"all_projection_contracts_leave_live_state_unchanged")
'''
s=s.replace('func buy_parent() -> Dictionary:',helper+'func buy_parent() -> Dictionary:')
(e/'darkcrest_real_matrix_final.gd').write_text(s)
s=(e/'darkcrest_source_eot_contract_v2.gd').read_text();s=s.replace('  for malformed in [null,true,7,"invalid",{}]:','  bad=base.duplicate(true);bad.effects[1].type="end_turn_forged"\n  check(not S.eot_combat_unit_error(bad,true).is_empty(),"reject_changed_base_eot_type_"+id)\n  bad=live.duplicate(true);bad.effects[1].type="end_turn_forged"\n  check(not S.eot_combat_unit_error(bad).is_empty(),"reject_changed_live_eot_type_"+id)\n  for malformed in [null,true,7,"invalid",{}]:');(e/'darkcrest_source_eot_contract_final.gd').write_text(s)
t=p/'tests/darkcrest_20261112';t.mkdir(exist_ok=False,parents=True)
for src,name in [('darkcrest_real_matrix_final.gd','real_matrix.gd'),('darkcrest_source_eot_contract_final.gd','source_eot_contract.gd'),('darkcrest_sources_archived.gd','darkcrest_sources_archived.gd'),('hand_shape_contract.gd','hand_shape_contract.gd'),('seafloor_annotation_contract_final.gd','seafloor_annotation_contract.gd')]:shutil.copyfile(e/src,t/name)
(t/'README.md').write_text('''# 暗潮真实回合结束片段测试

Godot 4.6.3。逐个执行，不要并行加载完整 Game。real_matrix.gd 需要约3GB运行内存，建议900秒软时限；其它合同只加载相关模块。

    godot --headless --path <恢复工程> --script <恢复工程>/tests/darkcrest_20261112/real_matrix.gd
    godot --headless --path <恢复工程> --script <恢复工程>/tests/darkcrest_20261112/source_eot_contract.gd
    godot --headless --path <恢复工程> --script <恢复工程>/tests/darkcrest_20261112/hand_shape_contract.gd
    godot --headless --path <恢复工程> --script <恢复工程>/tests/darkcrest_20261112/seafloor_annotation_contract.gd

source_eot_contract.gd须与darkcrest_sources_archived.gd一起保留。后者只用于历史来源比较，不是运行时实现。矩阵通过真实酒馆币筹资、公开升级/刷新/购买/出牌/结束回合完成两个受限房间；不直接写金币、成长等级、随机数、库存或手牌。预演负例只改独立副本，前后核验原状态不变。纯合同fixture不证明实体真实来源。

仅普通初始商店来源、1/2/3级生成、原生回合结束/塑造等待/到期片段；4级及以后、金色/三连/复制、出牌后再购买、混合战队、饰品/其他英雄、完整对局和存档仍未验收。旧失败与最终成功保存在包内evidence，不累加为最终覆盖数。
''')
print('Final source metadata, projection command shapes and shipped tests prepared')
