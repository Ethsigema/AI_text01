from pathlib import Path
import re,hashlib,json
r=Path(__file__).resolve().parent;p=r/'game_candidate';archive=r/'research_old_candidate/20261110-darkcrest-domain-review/extracted/darkcrest_domain_review_20261110T054142Z/candidate';pre=json.loads((r/'PREIMAGE_HASHES.json').read_text());pat=re.compile(r'("((?:res://)?[^"\n]+\.[a-z0-9]+)"\s*:\s*")([0-9a-f]{64})(")');updates=[];history=[]
for f in sorted((r/'evidence').glob('PIN_UPDATES*.json')):history+=json.loads(f.read_text()).get('updates',[])
h=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
extra={}
for f in sorted((r/'evidence').glob('BEFORE_*_HASHES.json')):
 for n,v in json.loads(f.read_text()).items():extra.setdefault(n,set()).add(v)
for iteration in range(30):
 changed=False
 for f in sorted(p.glob('core/*.gd')):
  s=f.read_text();replacements=[]
  for m in pat.finditer(s):
   name=m[2].removeprefix('res://');target=p/name
   if not target.is_file():continue
   actual=h(target)
   if actual==m[3]:continue
   allowed={pre.get(name)}|extra.get(name,set())
   if (archive/name).is_file():allowed.add(h(archive/name))
   allowed.update(x['new'] for x in history+updates if x['target']==name)
   if m[3] not in allowed:raise ValueError(('unexplained pin drift',str(f),name,m[3],actual))
   replacements.append((m.start(3),m.end(3),actual));updates.append({'source':f.relative_to(p).as_posix(),'target':name,'old':m[3],'new':actual})
  if replacements:
   for a,b,value in reversed(replacements):s=s[:a]+value+s[b:]
   f.write_text(s);changed=True
 if not changed:break
else:raise ValueError('dependency cycle')
checks=0
for f in sorted(p.glob('core/*.gd')):
 for m in pat.finditer(f.read_text()):
  target=p/m[2].removeprefix('res://')
  if target.is_file():assert h(target)==m[3],(f,target);checks+=1
index=len(list((r/'evidence').glob('PIN_UPDATES*.json')))+1
(r/f'evidence/PIN_UPDATES_{index:02d}.json').write_text(json.dumps({'existing_pins_matched':checks,'updates':updates},indent=2)+'\n');print('updated',len(updates),'pins;',checks,'existing pins match')
