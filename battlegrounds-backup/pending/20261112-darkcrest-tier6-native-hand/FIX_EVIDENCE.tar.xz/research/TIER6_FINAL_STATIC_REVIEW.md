# Tier6 最终静态复核

对象：10:17:49 UTC 冻结的本轮六文件，基线为已验证 fd0355f Tier5，而非任一空位修复候选。未运行Godot、未修改candidate。

## 结论

未发现本次改动的新增静态阻塞；这不是玩法通过或完整源码验收。检查时 host/generation/Game/hand records/overlay 五项SHA与冻结表一致，darkcrest_sources因协调线程进行repin已发生变化，不能宣称六项全部仍与旧冻结SHA一致。

## 实际调用与保护

- Game._play 4032 调用 begin_cast，后者完整执行 cast_error，成功后才进入原play及6558 consume。故新增 generation_preconsume_error 与 Tier6历史门槛先于消耗、抽取、UID和pool写入。
- preconsume查 _spells[u.uid] 同一unit、owner、round、unused；source_uid必须非空String；grant要求原owner/round/delivered/notblocked，grant.unit与parent.unit同一引用，原BG31_920身份及parent_error必须通过。domain_ids只认native int 5/6，tier_receipts_match要求token/grant/parent三者同档且int。未制造临时cast伪装消费验证。
- UID native int与当前完整候选库存native int在消费前检查；未知enabled card、完整源记录改变、任何正库存未审域成员、潜在triple和不足库存均拒绝。Tier5沿原域，Tier6新增四种，不过滤成单张以制造测试通过。
- Generation.begin在消费后、真实draw前重新绑定host/game/owner/token并独立枚举排序的完整enabled正库存域，对照Bulk原生candidates。原draw仍只传kind/tier/tribe，不传缩减候选。原生domain最终运行时等价尚待测试。
- active.cast_tier及source_record固定本次档位；drawn/received使用该档domain，继续验证独立RNG重放、唯一factory UID、整pool唯一扣减、原hand append、旧hand/board对象与深值未变、原parent注册集。成功play返回前仍检查committed，cancel不抹掉旧birth凭证。
- Tier6域无BG31_920；_origins写入仍仅BG31_920，cast_tier固定5合理。四个非暗潮body没有获得private owner provenance，不能据此上场开启新玩法。
- Tier6四卡hand gate额外拒绝非expected/uid/base_unit/三个false-disabled字段，其原生效果/种族/base/统计/stock stamp等照旧核对；不靠删除marker通过。已有hand records逐项相等，仅新增四卡。
- Tier6历史门槛仅tier==6时执行：GlobalCards.state_error + Beasts.FIELDS零值（含expiry，保守零历史）。修复了all Gatekeeper可能在_add_hand receive时加兽层而消耗后失败的问题。Tier5不套此新历史门槛。
- MAX_TIER从5提升6仅让原完整EOT推进5→6；达到6后下一EOT仍held。golden、triple、mixed在场及其它机制门禁未放开。

## 必须保留的验证边界

Catalog-only先前未完成，因此四张静态完整record并不等于已由本版本真实Catalog成功加载，也不能称factory/四人完整域已通过。应以独立恢复后真实四人生成各输出、native hand fields/全域stock+RNG凭证及原Tier5回归证明。

建议负例至少覆盖：token/grant/parent单方跨档或float档位、复制token/不同owner、float UID/候选stock、BG36_640兽层非零在消耗前拒绝且token/pool/RNG/UID不变、任意额外hand marker、域成员源记录改变、潜在triple、取消后重复begin、Tier6再次EOT拒绝。

整pool唯一扣减检查仍在drawn阶段检查所有库存类型；preconsume仅检查本次候选的库存类型。这是沿用的有限验证边界，不能宣称所有无关pool损坏均在消费前被拒绝。真实来源host内部state被外部任意篡改的全局防护亦非本次完整游戏证明。
