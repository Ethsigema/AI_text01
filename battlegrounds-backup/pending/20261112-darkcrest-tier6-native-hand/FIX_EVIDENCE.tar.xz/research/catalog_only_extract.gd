extends SceneTree
const Catalog=preload("res://core/catalog.gd")
func _initialize() -> void:
 var catalog=Catalog.new()
 catalog.load_catalog()
 var cards={}
 for id in ["BG31_035","BG32_837","BG36_622","BG36_640"]: cards[id]=catalog.get_card(id)
 print("TIER6_CATALOG_ONLY ",JSON.stringify({"errors":catalog.load_errors,"cards":cards}))
 quit(0 if catalog.load_errors.is_empty() else 1)
