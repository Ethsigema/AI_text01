"""Archive only completed restore receipts/tools; never touches live Game evidence."""
from pathlib import Path
import json,hashlib,shutil,tarfile,io,datetime
ROOT=Path(__file__).resolve().parent.parent;R=ROOT/'remote_snapshot_dd428c2';P=ROOT/'restore_receipt_package'
def sha(b):return hashlib.sha256(b).hexdigest()
def enc(j):return (json.dumps(j,indent=2,sort_keys=True)+'\n').encode()
def main():
 import argparse
 ap=argparse.ArgumentParser();ap.add_argument('--execute',action='store_true',required=True);ap.parse_args()
 assert not P.exists();d=json.loads((R/'FRESH_PACKAGE_DOWNLOAD_VERIFIED.json').read_text());assert d['source_commit']=='dd428c21867d4c15340ff6d4d8868d027d1067e4' and d['files']==17
 for row in d['records']:
  b=(R/'package'/row['filename']).read_bytes();assert len(b)==row['bytes'] and sha(b)==row['sha256']
 restore=json.loads((R/'INDEPENDENT_RESTORE_VERIFIED.json').read_text());assert restore['source_commit']==d['source_commit'] and not restore['game_started'] and not restore['gameplay_acceptance']
 fixed=json.loads((R/'FIX_EVIDENCE_VERIFIED.json').read_text());assert fixed['members']==21 and fixed['every_member_rehashed']
 shutil.copytree(R/'package',P)
 tools={}
 names=['preparation/run_remote_tier6.py','preparation/audit_tier6_attempt.py','preparation/REMOTE_RUNNER_PREPARATION_VERIFIED.json','preparation/prepare_restore_receipt.py','preparation/prepare_publication_outcome.py','preparation/verify_final_publication.py','fresh_remote/download_fresh.py','fresh_remote/verify_baseline.py','fresh_remote/snapshot_tools/common.py','fresh_remote/snapshot_tools/build_unaccepted.py','fresh_remote/snapshot_tools/add_frozen_evidence.py','fresh_remote/snapshot_tools/restore_fixed_remote.py','fresh_remote/snapshot_tools/verify_remote_evidence.py','fresh_remote/snapshot_tools/PREPARATION_VERIFIED.json','fresh_remote/snapshot_tools/FIXED_REMOTE_dd428c2_METADATA.json']
 for n in names:
  p=ROOT/n;before=p.stat();b=p.read_bytes();after=p.stat();assert (before.st_size,before.st_mtime_ns)==(after.st_size,after.st_mtime_ns),n;tools[n]=b
 tools['TOOL_SNAPSHOT_NOTE.json']=enc({'captured_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'completed tool source snapshot only; no live test logs or HOME/cache','gameplay_acceptance':False,'some_tools_are_prepared_not_executed':True})
 with tarfile.open(P/'TOOLS_EVIDENCE.tar.xz','w:xz') as t:
  for n,b in sorted(tools.items()):
   x=tarfile.TarInfo(n);x.size=len(b);x.mode=0o644;x.mtime=0;t.addfile(x,io.BytesIO(b))
 members={n:{'bytes':len(b),'sha256':sha(b)} for n,b in tools.items()}
 with tarfile.open(P/'TOOLS_EVIDENCE.tar.xz') as t:assert {x.name:{'bytes':x.size,'sha256':sha(t.extractfile(x).read())} for x in t}==members
 (P/'TOOLS_EVIDENCE_MANIFEST.json').write_bytes(enc({'source_commit':d['source_commit'],'archive_sha256':sha((P/'TOOLS_EVIDENCE.tar.xz').read_bytes()),'members':members}))
 for source,dest in [('INDEPENDENT_RESTORE_VERIFIED.json','REMOTE_SNAPSHOT_RESTORE_VERIFIED.json'),('FIX_EVIDENCE_VERIFIED.json','REMOTE_FIX_EVIDENCE_VERIFIED.json'),('FRESH_PACKAGE_DOWNLOAD_VERIFIED.json','REMOTE_SNAPSHOT_DOWNLOAD_VERIFIED.json')]:shutil.copyfile(R/source,P/dest)
 (P/'RESTORE_VERIFIED.md').write_text('# Fixed Tier6 source restoration only, gameplay still unaccepted\n\nSource commit dd428c21867d4c15340ff6d4d8868d027d1067e4. All 17 files were actually freshly downloaded and checked by size/Git SHA/SHA256; all 21 source-evidence members were rehashed. Same-stage 60 prerequisites were separately freshly downloaded, then rehashed for restoration.\n\nActual independent restoration and second full read: 27,968 files, 1,550,696,801 bytes; source map f6305aee3349b70d01292b351ac0923a2a3152b56a1f41fb1f18c763410d3e9c, aggregate d72e2b1a7a0b6c257c3001f63959a9f717b2a1645feb02c33002c728786cf2fc, no differences.\n\nThis receipt proves bytes only. No completed gameplay acceptance is claimed. Tools include prepared but not executed future outcome/publication helpers. No live Game logs, process state, HOME/cache or hypothetical results are archived. Original 17-file source package remains preserved unchanged in its original directory and fixed source commit; only the checksum file of this separate receipt copy is regenerated. No paused empty-slot candidate source is included.\n')
 (P/'SHA256SUMS.txt').write_text(''.join(sha(p.read_bytes())+'  '+p.name+'\n' for p in sorted(P.iterdir()) if p.is_file() and p.name!='SHA256SUMS.txt'))
 old={x['filename']:x for x in d['records']};records=[];changed=[]
 for p in sorted(P.iterdir()):
  b=p.read_bytes();row={'name':p.name,'bytes':len(b),'sha256':sha(b),'git_sha':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()};records.append(row)
  if p.name not in old or old[p.name]['sha256']!=row['sha256']:changed.append(row)
 assert [x['name'] for x in changed if x['name'] in old]==['SHA256SUMS.txt']
 report={'status':'LOCAL_BYTES_ONLY_RECEIPT_READY_NOT_PUBLISHED','source_commit':d['source_commit'],'folder':'battlegrounds-backup/pending/20261112-darkcrest-tier6-native-hand','files':len(records),'bytes':sum(x['bytes'] for x in records),'tool_members':len(members),'records':records,'changed_records':changed}
 (ROOT/'RESTORE_RECEIPT_UPLOAD_METADATA.json').write_bytes(enc(report));print(json.dumps({k:v for k,v in report.items() if k not in ['records','changed_records']},indent=2));print('CHANGED',','.join(x['name'] for x in changed))
if __name__=='__main__':main()
