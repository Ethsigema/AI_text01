"""One explicit serial execution of the fixed remote Darkcrest Tier6 candidate.

Preparation is read-only without --execute. Never downloads, uploads, or changes
source inputs. Full Game runs once; only the five listed contracts follow it. Failed empty-slot candidates are excluded; historical evidence is retained.
"""
from pathlib import Path, PurePosixPath
import argparse
import datetime
import fcntl
import gzip
import hashlib
import json
import os
import re
import shutil
import signal
import subprocess
import time

T6 = ['BG31_035', 'BG32_837', 'BG36_622', 'BG36_640']
T5 = ['BG23_008', 'BG31_920', 'BG31_925', 'BG32_111', 'BG32_820', 'BG32_835']
BASELINE = {'source_commit': '3da3922e990fd2ed2637d1cc95c8a6e11322e32f', 'receipt_commit': 'fd0355f88ef67f7e05fb5eae8c7e677356624734', 'empty_slot_v1_v2_v3_excluded': True}
PINNED_TESTS = {'tests/darkcrest_tier6_20261112/real_matrix.gd': '03ee88b1b50f8b1212fb8d7e5d71445347084576238a8905eb9c29e976f12914', 'tests/darkcrest_tier6_20261112/content_contract.gd': '01e5874b444db4950cd9a3a08aec18a0bd4443c28c2a17500f59ee39f38eb787', 'tests/darkcrest_tier5_20261112/content_contract.gd': 'd039a22573d7340d0779e17adbbc70b0e2f3f958334fd7c742bdd4b6e3bd6248', 'tests/darkcrest_20261112/source_eot_contract.gd': '2d37ee1063792093a0fd1ad683c2e8786f196caad43abe0c82ea831caaaf7790', 'tests/darkcrest_20261112/hand_shape_contract.gd': '1577c66e9524b4db1875309104cf55cf67d254d1e024a41b9b094fff8331fa2e', 'tests/darkcrest_20261112/seafloor_annotation_contract.gd': 'c0e0046fa010ccfb83d87bedf87a4616b23fef5e1700e88438f27f9aca6dc4cb'}
TESTS = [('tier6_real_matrix', 'tests/darkcrest_tier6_20261112/real_matrix.gd', 4200, None), ('tier6_content_contract', 'tests/darkcrest_tier6_20261112/content_contract.gd', 180, None), ('tier5_content_contract', 'tests/darkcrest_tier5_20261112/content_contract.gd', 180, 810), ('source_eot_contract', 'tests/darkcrest_20261112/source_eot_contract.gd', 180, 68), ('hand_shape_contract', 'tests/darkcrest_20261112/hand_shape_contract.gd', 180, 166), ('seafloor_annotation_contract', 'tests/darkcrest_20261112/seafloor_annotation_contract.gd', 180, 267)]
FIXTURE = 'tests/darkcrest_20261112/darkcrest_sources_archived.gd'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def dump(value):
    return (json.dumps(value, sort_keys=True, indent=2) + '\n').encode()


def write_new(path, value):
    with path.open('xb') as stream:
        stream.write(dump(value))


def read_json(path):
    return json.loads(path.read_text())


def safe(name):
    return bool(name) and not PurePosixPath(name).is_absolute() and '..' not in PurePosixPath(name).parts and '\\' not in name


def verify_tree(tree, expected, aggregate):
    assert tree.is_dir() and not tree.is_symlink(), str(tree)
    actual = {}
    combined = hashlib.sha256()
    paths = list(tree.rglob('*'))
    assert all(not path.is_symlink() for path in paths), 'Source symlink forbidden'
    for path in sorted((path for path in paths if path.is_file()), key=lambda path: path.relative_to(tree).as_posix()):
        name = path.relative_to(tree).as_posix()
        assert safe(name), name
        data = path.read_bytes()
        actual[name] = {'bytes': len(data), 'sha256': sha(data)}
        combined.update(name.encode() + b'\0' + str(len(data)).encode() + b'\0' + data)
    missing = sorted(set(expected) - set(actual))
    extra = sorted(set(actual) - set(expected))
    mismatched = sorted(name for name in actual.keys() & expected.keys() if actual[name] != expected[name])
    result = {'files': len(actual), 'bytes': sum(row['bytes'] for row in actual.values()),
              'aggregate_sha256': combined.hexdigest(), 'missing': missing, 'extra': extra, 'mismatched': mismatched}
    assert not missing and not extra and not mismatched and combined.hexdigest() == aggregate, result
    return result, {name: row['sha256'] for name, row in actual.items()}


def stop(process):
    if process.poll() is not None:
        return
    os.killpg(process.pid, signal.SIGTERM)
    try:
        process.wait(timeout=2)
    except subprocess.TimeoutExpired:
        os.killpg(process.pid, signal.SIGKILL)
        process.wait()


def rss_for_group(group):
    rss = 0
    for proc in Path('/proc').iterdir():
        if not proc.name.isdigit():
            continue
        try:
            fields = (proc / 'stat').read_text().rsplit(')', 1)[1].split()
            if int(fields[2]) == group:
                rss += int((proc / 'statm').read_text().split()[1]) * os.sysconf('SC_PAGE_SIZE')
        except (OSError, ValueError, IndexError):
            pass
    return rss


def run_test(label, source_name, budget, commit, run_tree, evidence, expected, aggregate, env, prepared):
    # Re-read the complete run tree, not merely its test entry point.
    tree, hashes = verify_tree(run_tree, expected, aggregate)
    write_new(evidence / (label + '_hashes.json'), hashes)
    for name, meta in prepared.items():
        data = (evidence / name).read_bytes()
        assert len(data) == meta['bytes'] and sha(data) == meta['sha256'], name
    available = int(next(line.split()[1] for line in Path('/proc/meminfo').read_text().splitlines()
                         if line.startswith('MemAvailable:'))) * 1024
    limit = min(4 * 1024**3, available // 2)
    assert limit >= (3 * 1024**3 if label == 'tier6_real_matrix' else 512 * 1024**2), 'Insufficient memory for guarded test'
    wrapper = evidence / (label + '.gd')
    cmd = ['godot', '--headless', '--path', str(run_tree), '--script', str(wrapper)]
    started = utc()
    t = time.monotonic()
    peak = 0
    reason = 'exited'
    with (evidence / (label + '.log')).open('x') as log:
        process = subprocess.Popen(cmd, stdout=log, stderr=subprocess.STDOUT, env=env, start_new_session=True)
        try:
            while process.poll() is None:
                rss = rss_for_group(process.pid)
                peak = max(peak, rss)
                if rss > limit or time.monotonic() - t > budget:
                    reason = 'rss_soft_limit' if rss > limit else 'timeout'
                    stop(process)
                    break
                time.sleep(.1)
        except BaseException:
            reason = 'runner_interrupted'
            raise
        finally:
            stop(process)
            data = (evidence / (label + '.log')).read_bytes()
            result = {'source_commit': commit, 'source': source_name, 'command': cmd,
                      'source_sha256': expected[source_name]['sha256'], 'wrapper_sha256': prepared[wrapper.name]['sha256'],
                      'log_sha256': sha(data), 'started_at_utc': started, 'finished_at_utc': utc(),
                      'exit': process.wait(), 'reason': reason, 'elapsed': time.monotonic() - t,
                      'sampled_process_group_peak_rss': peak, 'rss_soft_limit': limit, 'available_start': available,
                      'timeout_seconds': budget, 'memory_enforcement': 'sampled process-group soft limit, not a cgroup hard cap',
                      'source_snapshot_matches': True, 'start_tree': tree}
            write_new(evidence / (label + '_result.json'), result)
    print(label, json.dumps(result), flush=True)
    text = data.decode()
    failures = [line for line in text.splitlines() if re.search(r'^\s*FAIL(?:\s|$)', line)
                or any(marker in line for marker in ['SCRIPT ERROR:', 'Parse Error:', 'COMMAND_FAILURE', 'WARNING:', 'ERROR:'])]
    assert result['exit'] == 0 and reason == 'exited' and not failures, (label, result, failures)
    return result, text


def validate(label, log, expected_checks, evidence):
    scenario = None
    if label == 'tier6_real_matrix':
        rows = re.findall(r'^DARKCREST_TIER6_REAL_MATRIX_PASS cases=(\d+) checks=(\d+) coverage=(.+)$', log, re.M)
        assert len(rows) == 1, 'Missing or duplicated full Game success marker'
        case_count, count = int(rows[0][0]), int(rows[0][1])
        scenario = read_json(evidence / 'TIER6_MATRIX_RESULT.json')
        assert 4 <= case_count <= 16 and scenario['checks'] + 1 == count
        assert scenario['scope'] == 'ordinary Darkcrest tier6 native hand acquisition only'
        assert len(scenario['cases']) == case_count and scenario['seed_plan'] == list(range(20261120,20261136))
        cases = scenario['cases']
        assert [row['seed'] for row in cases] == scenario['seed_plan'][:case_count]
        assert [json.loads(line.removeprefix('TIER6_CASE_PASS ')) for line in log.splitlines() if line.startswith('TIER6_CASE_PASS ')] == cases
        observed = {}
        for row in cases:
            assert row['id'] in T6
            observed[row['id']] = observed.get(row['id'], 0) + 1
            choices = row['choices']
            assert [entry['id'] for entry in choices] == T6
            assert all(type(entry['stock']) is int and entry['stock'] > 0 for entry in choices)
            assert len({entry['stock'] for entry in choices}) > 1
            draw = row['rng']; total = sum(entry['stock'] for entry in choices)
            assert draw['type'] == 'rng' and draw['reason'] == 'random_generated_minion'
            assert draw['range'] == total and type(draw['value']) is int and 0 <= draw['value'] < total
            ticket = draw['value']; selected = None
            for entry in choices:
                if ticket < entry['stock']:
                    selected = entry['id']; break
                ticket -= entry['stock']
            assert selected == row['id']
            assert all(re.fullmatch(r'u[1-9][0-9]*', row[key]) for key in ['uid','source_uid','token_uid'])
            assert len({row[key] for key in ['uid','source_uid','token_uid']}) == 3
        assert set(observed) == set(T6) and observed == scenario['coverage'] == json.loads(rows[0][2])
        assert all(scenario[key] is True for key in ['four_player_rooms','five_actual_eots','tier5_triple_boundary_reused','no_live_state_injection'])
        assert all(scenario[key] is False for key in ['old_tier5_full_matrix_repeated','golden_gameplay_tested','other_output_abilities_opened'])
        assert len(scenario['lower_tier_records']) == 1
        lower = scenario['lower_tier_records'][0]
        assert lower['seed'] == 20261120 and lower['id'] in T5
        assert [entry['id'] for entry in lower['choices']] == T5 and all(entry['stock'] > 0 for entry in lower['choices'])
    elif label in ['tier6_content_contract', 'tier5_content_contract']:
        marker = 'DARKCREST_TIER6_CONTENT_CONTRACT ' if label == 'tier6_content_contract' else 'DARKCREST_TIER5_CONTENT_CONTRACT '
        rows = [json.loads(line.removeprefix(marker)) for line in log.splitlines() if line.startswith(marker)]
        assert len(rows) == 1
        summary = rows[0]; count = summary['passed']
        assert count == expected_checks and summary['failed'] == 0 and summary['failures'] == []
        assert summary['ids'] == (T6 if label == 'tier6_content_contract' else T5)
        assert summary['scope'] == 'pure fixture content and identity observations only, not actual acquisition or provenance'
        if label == 'tier6_content_contract': assert summary['real_game_run'] is False
    elif label == 'source_eot_contract':
        count = expected_checks
        assert log.splitlines().count('DARKCREST_SOURCE_EOT_CONTRACT passed=68 failed=0') == 1
    elif label == 'seafloor_annotation_contract':
        rows = [json.loads(line.removeprefix('SEAFLOOR_ANNOTATION_CONTRACT ')) for line in log.splitlines() if line.startswith('SEAFLOOR_ANNOTATION_CONTRACT ')]
        assert len(rows) == 1
        summary = rows[0]; count = summary['checks']
        assert count == expected_checks and summary['failures'] == 0 and summary['scope'] == 'source_contract_only_no_Game_or_Catalog'
    else:
        rows = [json.loads(line) for line in log.splitlines() if line.startswith('{') and 'darkcrest_five_strict_hand_shapes' in line]
        assert len(rows) == 1
        summary = rows[0]; count = summary['passed']
        assert count == expected_checks and summary['failed'] == 0 and summary['failures'] == []
    assert sum(line.startswith('PASS ') for line in log.splitlines()) == count, (label, 'PASS count does not match summary')
    return count, scenario


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--commit', required=True, help='Fixed remote source commit, 40 lowercase hex characters')
    parser.add_argument('--restored-snapshot', required=True, type=Path)
    parser.add_argument('--package', type=Path, help='Fixed remote downloaded package; default restored_snapshot sibling package')
    parser.add_argument('--restore-report', type=Path, help='Default sibling INDEPENDENT_RESTORE_VERIFIED.json')
    parser.add_argument('--output', type=Path, help='Default restored snapshot parent; run_tree and independent_tests must not exist')
    parser.add_argument('--source-map-sha256', required=True, help='Parent-verified frozen Tier6 uncompressed source-map SHA256')
    parser.add_argument('--aggregate-sha256', required=True, help='Parent-verified frozen Tier6 aggregate SHA256')
    parser.add_argument('--new-contract-checks', required=True, type=int, help='Actual frozen-source pure-contract check count, not an estimate')
    parser.add_argument('--execute', action='store_true', help='Required to create copies or run any process')
    args = parser.parse_args()
    assert re.fullmatch(r'[0-9a-f]{40}', args.commit), 'Use a fixed full source commit'
    for value in [args.source_map_sha256, args.aggregate_sha256]:
        assert re.fullmatch(r'[0-9a-f]{64}', value), 'Require explicit frozen Tier6 SHA256 values'
    assert args.new_contract_checks > 0
    frozen_map_sha = args.source_map_sha256
    frozen_aggregate = args.aggregate_sha256
    source = args.restored_snapshot.resolve()
    tranche_root = Path(__file__).resolve().parent.parent
    assert tranche_root in source.parents, 'Use the separate Tier6 remote snapshot'
    package = (args.package or source.parent / 'package').resolve()
    restore_report = (args.restore_report or source.parent / 'INDEPENDENT_RESTORE_VERIFIED.json').resolve()
    output = (args.output or source.parent).resolve()
    assert output != source and source not in output.parents, 'Never place generated artifacts inside source tree'
    assert tranche_root in output.parents or output == tranche_root, 'Keep output in the Tier6 tranche'
    manifest = read_json(package / 'MANIFEST.json')
    map_bytes = gzip.decompress((package / 'SOURCE_MAP.json.gz').read_bytes())
    assert sha(map_bytes) == manifest['source_map_sha256'] == frozen_map_sha
    assert manifest['aggregate_sha256'] == frozen_aggregate
    expected = json.loads(map_bytes)
    assert all(safe(name) for name in expected)
    assert len(expected) == manifest['source_files']
    assert sum(row['bytes'] for row in expected.values()) == manifest['source_bytes']
    for name, checksum in PINNED_TESTS.items():
        assert expected[name]['sha256'] == checksum, ('Frozen test changed', name)
    report = read_json(restore_report)
    assert report['source_commit'] == args.commit and report['source_map_sha256'] == frozen_map_sha
    assert report.get('status', '').startswith('PASS_'), 'Prior fixed-commit remote restore verification required'
    restored_report = report['restored']
    assert restored_report['aggregate_sha256'] == frozen_aggregate
    assert restored_report['files'] == manifest['source_files'] and restored_report['bytes'] == manifest['source_bytes']
    assert all(not restored_report[key] for key in ['missing', 'extra', 'mismatched'])
    for _, name, _, _ in TESTS:
        assert name in expected, name
    assert FIXTURE in expected
    if not args.execute:
        print(json.dumps({'status': 'CONFIGURATION_ONLY_NOT_EXECUTED', 'source_commit': args.commit,
                          'source_map_sha256': frozen_map_sha, 'tests': TESTS, 'game_started': False}, indent=2))
        return
    output.mkdir(parents=True, exist_ok=True)
    lock_path = tranche_root.parent / 'develop_empty_ghost_20261112' / '.independent_full_game.lock'
    lock = lock_path.open('a')
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    run_tree = output / 'run_tree'
    evidence = output / 'independent_tests'
    assert not run_tree.exists() and not evidence.exists(), 'Never overwrite an earlier run'
    initial_source, _ = verify_tree(source, expected, frozen_aggregate)
    shutil.copytree(source, run_tree)
    initial_run, _ = verify_tree(run_tree, expected, frozen_aggregate)
    evidence.mkdir()
    prepared = {}
    for label, name, _, _ in TESTS:
        data = ('extends "res://' + name + '"\n').encode()
        path = evidence / (label + '.gd')
        path.write_bytes(data)
        prepared[path.name] = {'bytes': len(data), 'sha256': sha(data), 'source': name,
                               'source_sha256': expected[name]['sha256'], 'kind': 'external_wrapper'}
    fixture_data = (source / FIXTURE).read_bytes()
    assert {'bytes': len(fixture_data), 'sha256': sha(fixture_data)} == expected[FIXTURE]
    fixture_path = evidence / 'darkcrest_sources_archived.gd'
    fixture_path.write_bytes(fixture_data)
    prepared[fixture_path.name] = {**expected[FIXTURE], 'source': FIXTURE, 'kind': 'remote_fixture_copy'}
    write_new(evidence / 'PREPARED_FROM_REMOTE.json', {'source_commit': args.commit, 'source_map_sha256': frozen_map_sha,
              'prepared_at_utc': utc(), 'verified_tier5_baseline': BASELINE, 'entries': prepared, 'initial_trees': {'restored_snapshot': initial_source, 'run_tree': initial_run}})
    env = os.environ.copy()
    for key, folder in [('HOME', 'home'), ('XDG_CACHE_HOME', 'cache'), ('XDG_CONFIG_HOME', 'config'), ('XDG_DATA_HOME', 'data')]:
        destination = evidence / folder
        destination.mkdir()
        env[key] = str(destination)
    runs = {}
    prior_end = None
    for label, name, budget, count in TESTS:
        if label == 'tier6_content_contract':
            count = args.new_contract_checks
        result, log = run_test(label, name, budget, args.commit, run_tree, evidence, expected, frozen_aggregate, env, prepared)
        assert prior_end is None or result['started_at_utc'] >= prior_end
        prior_end = result['finished_at_utc']
        count, scenario = validate(label, log, count, evidence)
        runs[label] = {'source': name, 'passed_checks': count, 'log_sha256': result['log_sha256'],
                       'test_sha256': expected[name]['sha256'], 'source_snapshot_matches': True, 'failures': [], 'result': result}
        if scenario is not None:
            runs[label]['verified_scenario_fields'] = scenario
            runs[label]['scenario_sha256'] = sha((evidence / 'TIER6_MATRIX_RESULT.json').read_bytes())
        write_new(evidence / (label + '_VALIDATED.json'), runs[label])
    # Reject all changes and extras, including generated source-tree caches.
    trees = {'restored_snapshot': verify_tree(source, expected, frozen_aggregate)[0],
             'run_tree': verify_tree(run_tree, expected, frozen_aggregate)[0]}
    for name, meta in prepared.items():
        data = (evidence / name).read_bytes()
        assert len(data) == meta['bytes'] and sha(data) == meta['sha256'], name
    final = {'status': 'PASS_FIXED_REMOTE_DARKCREST_TIER6_MATRIX_AND_CONTRACTS_POST_TEST_DOUBLE_REHASH',
             'verified_at_utc': utc(), 'source_commit': args.commit, 'source_map_sha256': frozen_map_sha,
             'verified_tier5_baseline': BASELINE, 'trees': trees, 'tests': runs, 'fixtures': prepared, 'sequential_game_execution': True,
             'full_game_processes': 1, 'old_tier5_full_matrix_repeated': False,
             'full_game_acceptance': False,
             'default_pool_promoted': False, 'scope': 'ordinary Darkcrest Tier6 complete-domain native hand acquisition only'}
    write_new(output / 'INDEPENDENT_GAME_VERIFICATION.json', final)
    print('DARKCREST_TIER6_REMOTE_MATRIX_CONTRACTS_AND_DOUBLE_REHASH_PASS', flush=True)


if __name__ == '__main__':
    main()
