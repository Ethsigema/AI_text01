"""Preparation only until explicitly invoked after parent freeze. No Game/upload."""
from common import *
import argparse,tarfile,io,shutil,subprocess

def main():
 ap=argparse.ArgumentParser(description=__doc__)
 ap.add_argument('--freeze-confirmed',action='store_true',required=True)
 ap.add_argument('--reconstruction-note',type=Path,required=True)
 ap.add_argument('--output',type=Path,required=True)
 args=ap.parse_args();out=args.output.resolve();source=ROOT.parent/'candidate'
 assert not out.exists() and not out.is_relative_to(source)
 assert args.reconstruction_note.is_file()
 recovery=json.loads((ROOT/'CURRENT_RECOVERY_VERIFIED.json').read_text())
 assert recovery['status']=='PASS_CURRENT_ENVIRONMENT_INDEPENDENT_RESTORE_AND_DOUBLE_TREE_REHASH'
 base_bytes=gzip.decompress((ROOT/'base_package/SOURCE_MAP.json.gz').read_bytes());base=json.loads(base_bytes)
 assert sha(base_bytes)=='7fec8d69e82de8bfcb7373549951f9456671b5c3980135d6ec6f983a3daf5ed7'
 old=json.loads((ROOT/'TIER5_SOURCE_MAP.json').read_text())
 assert sha(dump(old))=='7701a57e0cf2e97b82149be5ad6cc3d82e38a443b56477998daa80b4350f5014'
 target,aggregate=scan(source);assert target
 # Do not silently omit caches or files from a claimed complete frozen source tree.
 assert not any(n.startswith('.godot/') for n in target),'Freeze a cache-free source tree first'
 changed={n:v for n,v in target.items() if base.get(n)!=v};removed=sorted(set(base)-set(target))
 out.mkdir(parents=True)
 with tarfile.open(out/'delta.tar.xz','w:xz') as t:
  for n,v in sorted(changed.items()):
   b=(source/n).read_bytes();assert {'bytes':len(b),'sha256':sha(b)}==v,n
   member=tarfile.TarInfo(n);member.size=len(b);member.mode=0o644;member.mtime=0;t.addfile(member,io.BytesIO(b))
 delta=(out/'delta.tar.xz').read_bytes()
 with (out/'SOURCE_MAP.json.gz').open('xb') as f:f.write(gzip.compress(dump(target),mtime=0))
 write(out/'CHANGES_FROM_TIER5.json',{'previous_commit':PREVIOUS_COMMIT,'added':{n:v for n,v in target.items() if n not in old},'modified':{n:{'before':old[n],'after':v} for n,v in target.items() if n in old and old[n]!=v},'removed':{n:old[n] for n in sorted(set(old)-set(target))}})
 for n in ['CURRENT_RECOVERY_VERIFIED.json','CURRENT_EVIDENCE_VERIFIED.json','FRESH_DOWNLOAD_VERIFIED.json','BASE_RESTORE_CURRENT.json','TIER5_RESTORE_CURRENT.json']:
  shutil.copyfile(ROOT/n,out/n)
 shutil.copyfile(args.reconstruction_note,out/'RECONSTRUCTION_NOTE.md')
 shutil.copyfile(ROOT/'tier5_package/restore_increment.py',out/'restore_increment.py')
 manifest={'format_version':1,'status':STATUS,'created_at_utc':utc(),'remote_folder':REMOTE_FOLDER,'base_content_commit':BASE_COMMIT,'base_folder':'battlegrounds-backup/consolidated/20261111-batch14-restored','base_map_sha256':sha(base_bytes),'source_map_sha256':sha(dump(target)),'aggregate_sha256':aggregate,'source_files':len(target),'source_bytes':sum(v['bytes'] for v in target.values()),'archive':'delta.tar.xz','archive_bytes':len(delta),'archive_sha256':sha(delta),'changed_files':changed,'removed':removed,'previous_candidate_commit':PREVIOUS_COMMIT,'previous_source_commit':'3da3922e990fd2ed2637d1cc95c8a6e11322e32f','scope':'Isolated ordinary Darkcrest Tier6 native hand candidate, based only on accepted Tier5; paused empty-slot changes excluded','original_worktree_recovered':False,'unknown_unuploaded_tier5_recovered':False,'full_scope_acceptance':False,'gameplay_tests_run_for_this_snapshot':False,'historical_discovery_is_acceptance':False,'old_backups_preserved':True,'note':'Unaccepted Darkcrest Tier6 candidate from fixed accepted Tier5 only; paused empty-slot candidates are excluded. Prior Tier5 tests do not validate Tier6 or the changed tree.'}
 write(out/'MANIFEST.json',manifest)
 verify(source,target,aggregate) # Source must still equal freeze after package assembly.
 with tarfile.open(out/'delta.tar.xz','r:xz') as t:
  members={}
  for x in t:
   assert x.isfile() and safe(x.name) and x.name not in members
   b=t.extractfile(x).read();members[x.name]={'bytes':len(b),'sha256':sha(b)}
  assert members==changed
 write(out/'BUILD_VERIFIED.json',{'status':'PASS_FROZEN_BYTES_AND_ARCHIVE_ONLY_NOT_GAME_ACCEPTANCE','created_at_utc':utc(),'source_map_sha256':manifest['source_map_sha256'],'aggregate_sha256':aggregate,'source_files':len(target),'source_bytes':manifest['source_bytes'],'game_started':False,'uploads':0})
 (out/'RECOVERY.md').write_text(f"""# Tier6 未验收累积候选恢复

状态：{STATUS}。这不是完整游戏或全量最新内容验收。仅从已验证Tier5继续，暂停的空位候选未带入；不声称找回未上传内容。保留旧工作树与全部备份。

## 输入准备
需要 Python 3.12+、约4GB恢复磁盘；以下命令从一个新工作目录执行。

1. 下载原始Release为 `original_release.zip`：
https://github.com/Ethsigema/AI_text01/releases/download/battlegrounds-handoff-20261101/battlegrounds_new_scope_handoff_20261101.zip
大小324,041,102字节；SHA256 `33b3a1a12185cf9035cec33da4fff7008c7680194eb045b37234fbb934803d65`。

2. 下载固定batch14目录全部24文件到 `base_package/`，保持文件名：
https://github.com/Ethsigema/AI_text01/tree/{BASE_COMMIT}/battlegrounds-backup/consolidated/20261111-batch14-restored
必须有restore.py、MANIFEST.json、SOURCE_MAP.json.gz、BASE_MEMBERS.json.gz及13片payload.tar.xz.part0000至part0012。

3. 从同一固定提交下载本候选目录全部文件到 `tier6_package/`。目录为 `{REMOTE_FOLDER}`，首次源码提交号以发布回执为准。不要混用不同提交的MANIFEST、delta或校验清单。证据包不是源码，不要解进工程。

## 核验并实际恢复
```sh
printf '%s\\n' '33b3a1a12185cf9035cec33da4fff7008c7680194eb045b37234fbb934803d65  original_release.zip' | sha256sum -c -
(cd base_package && sha256sum -c SHA256SUMS.txt)
(cd tier6_package && sha256sum -c SHA256SUMS.txt)
python3 base_package/restore.py --base-zip original_release.zip --destination restored_batch14 --report BASE_RESTORE.json
python3 tier6_package/restore_increment.py --base-tree restored_batch14 --base-map base_package/SOURCE_MAP.json.gz --destination restored_tier6 --report TIER6_RESTORE.json
```
两个输出目录和两个报告必须不存在。**本包是相对batch14的累积增量，直接叠batch14，不能叠Tier5或空位候选。** 不需要逐层叠历史包，也不能只解增量当完整工程。

两个恢复器实际重新读取每个文件，验证完整路径集、长度和SHA256；输入SHA256SUMS只校验包文件，不能替代源码恢复核验。基线应报告PASS_ACTUAL_DISK_RESTORE_EVERY_FILE_REHASHED（27,920文件、1,549,340,406字节）。候选应报告PASS_INCREMENT_RESTORED_AND_EVERY_FILE_REHASHED，{len(target):,}文件、{manifest['source_bytes']:,}字节；missing/extra/mismatched均为空。

完整每文件SHA/大小见解压后的SOURCE_MAP.json.gz。解压地图内容SHA256：`{manifest['source_map_sha256']}`。
聚合SHA256：`{aggregate}`；TIER6_RESTORE.json的aggregate_sha256必须一致。

工程入口 `restored_tier6/project.godot`，对应Godot 4.6.3。先保留这棵核验树，另复制运行以免缓存/测试输出污染源码证据。恢复成功仅证明字节可重建；真实玩法验收必须另有固定来源的实际测试回执。若包内附带证据归档，按相邻成员清单逐项验证，不把历史成绩算作本候选通过。
""")
 (out/'SHA256SUMS.txt').write_text(''.join(sha(p.read_bytes())+'  '+p.name+'\n' for p in sorted(out.iterdir()) if p.is_file()))
 print(json.dumps({'status':STATUS,'output':str(out),'files':len(target),'source_map_sha256':manifest['source_map_sha256'],'aggregate_sha256':aggregate}))
if __name__=='__main__':main()
