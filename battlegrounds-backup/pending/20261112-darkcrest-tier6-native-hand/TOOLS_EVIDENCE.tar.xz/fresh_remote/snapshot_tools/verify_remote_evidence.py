"""Explicit read-only member verification after fixed-commit download/restore."""
from common import *
import argparse,tarfile

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--execute',action='store_true',required=True);ap.add_argument('--remote-directory',type=Path,required=True);ap.add_argument('--commit',required=True);a=ap.parse_args()
 r=a.remote_directory.resolve();p=r/'package';report=json.loads((r/'INDEPENDENT_RESTORE_VERIFIED.json').read_text());dl=json.loads((r/'FRESH_PACKAGE_DOWNLOAD_VERIFIED.json').read_text());assert report['source_commit']==dl['source_commit']==a.commit and report['snapshot_status']==STATUS
 expected=json.loads((p/'FIX_EVIDENCE_MANIFEST.json').read_text());seen=set();total=0
 with tarfile.open(p/'FIX_EVIDENCE.tar.xz') as t:
  for x in t:
   assert x.isfile() and safe(x.name) and x.name not in seen
   b=t.extractfile(x).read();assert {'bytes':len(b),'sha256':sha(b)}==expected[x.name];seen.add(x.name);total+=len(b)
 assert seen==set(expected)
 write(r/'FIX_EVIDENCE_VERIFIED.json',{'status':'PASS_FIXED_REMOTE_TIER6_EVIDENCE_EVERY_MEMBER','source_commit':a.commit,'checked_at_utc':utc(),'members':len(seen),'bytes':total,'archive_sha256':sha((p/'FIX_EVIDENCE.tar.xz').read_bytes()),'every_member_rehashed':True,'missing':[],'extra':[],'mismatched':[],'game_started':False,'historical_failure_evidence_not_acceptance':True})
 print('PASS_FIXED_REMOTE_TIER6_EVIDENCE_EVERY_MEMBER',len(seen))
if __name__=='__main__':main()
