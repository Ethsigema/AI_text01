from pathlib import Path
import json,gzip,hashlib,sys,datetime,tarfile
R=Path(__file__).resolve().parent;sys.path.insert(0,str(R/'snapshot_tools'))
from common import scan,verify,sha,dump,write,utc,safe
base_bytes=gzip.decompress((R/'base_package/SOURCE_MAP.json.gz').read_bytes());base=json.loads(base_bytes)
assert sha(base_bytes)=='7fec8d69e82de8bfcb7373549951f9456671b5c3980135d6ec6f983a3daf5ed7'
m=json.loads((R/'tier5_package/MANIFEST.json').read_text());target=dict(base)
for n in m['removed']:del target[n]
target.update(m['changed_files']);encoded=dump(target)
assert sha(encoded)=='7701a57e0cf2e97b82149be5ad6cc3d82e38a443b56477998daa80b4350f5014'
assert gzip.decompress((R/'tier5_package/SOURCE_MAP.json.gz').read_bytes())==encoded
with (R/'TIER5_SOURCE_MAP.json').open('xb') as f:f.write(encoded)
trees={'restored_base':verify(R/'restored_base',base,'5ba04ef124fc78cf20e2a942a60589fb92dc76e6808155648226a534a4599e05'),'restored_tier5':verify(R/'restored_tier5',target,'ca24bc997ed0661ea9b5c45194fb19c76777d66b1a0bbfaf19724b580d0b6612')}
assert trees['restored_tier5']['files']==27965 and trees['restored_tier5']['bytes']==1550610791
dl=json.loads((R/'FRESH_DOWNLOAD_VERIFIED.json').read_text());assert dl['files']==60
for row in dl['records']:
 b=(R/row['filename']).read_bytes();assert len(b)==row['bytes'] and sha(b)==row['sha256']
# Rebuild provenance archive is historic evidence, not a new Game execution.
expected=json.loads((R/'tier5_package/REBUILD_EVIDENCE_MANIFEST.json').read_text());seen=set()
with tarfile.open(R/'tier5_package/REBUILD_EVIDENCE.tar.xz') as t:
 for x in t:
  assert x.isfile() and safe(x.name) and x.name not in seen
  b=t.extractfile(x).read();assert {'bytes':len(b),'sha256':sha(b)}==expected[x.name];seen.add(x.name)
assert seen==set(expected) and len(seen)==40
write(R/'CURRENT_EVIDENCE_VERIFIED.json',{'status':'PASS_FRESH_TIER5_REBUILD_EVIDENCE_MEMBERS','members':40,'checked_at_utc':utc(),'historical_tests_not_current_execution':True})
write(R/'CURRENT_RECOVERY_VERIFIED.json',{'status':'PASS_CURRENT_ENVIRONMENT_INDEPENDENT_RESTORE_AND_DOUBLE_TREE_REHASH','checked_at_utc':utc(),'fixed_commit':'fd0355f88ef67f7e05fb5eae8c7e677356624734','source_commit':'3da3922e990fd2ed2637d1cc95c8a6e11322e32f','fresh_download_files':60,'fresh_download_bytes':dl['bytes'],'source_map_sha256':sha(encoded),'trees':trees,'game_started':False,'uploads':0,'old_download_bytes_reused':False,'old_files_preserved':True})
print('PASS_NEW_STAGE_60_FRESH_DOWNLOADS_AND_TIER5_DOUBLE_REHASH')
