"""Explicit completed-attempt packaging only; never Godot, source editing or upload."""
from pathlib import Path
import argparse,json,gzip,hashlib,tarfile,io,shutil,fcntl,datetime
from run_remote_tier6 import TESTS,validate,verify_tree
ROOT=Path(__file__).resolve().parent.parent;R=ROOT/'remote_snapshot_dd428c2';E=R/'independent_tests'
COMMIT='dd428c21867d4c15340ff6d4d8868d027d1067e4'
MAP='f6305aee3349b70d01292b351ac0923a2a3152b56a1f41fb1f18c763410d3e9c'
AGG='d72e2b1a7a0b6c257c3001f63959a9f717b2a1645feb02c33002c728786cf2fc'
def sha(b):return hashlib.sha256(b).hexdigest()
def enc(j):return (json.dumps(j,indent=2,sort_keys=True)+'\n').encode()
def read(p):return json.loads(p.read_text())
def put(p,b):
 with p.open('xb') as f:f.write(b)
def archive(files):
 out=io.BytesIO()
 with tarfile.open(fileobj=out,mode='w:xz') as t:
  for n,b in sorted(files.items()):
   x=tarfile.TarInfo(n);x.size=len(b);x.mode=0o644;x.mtime=0;t.addfile(x,io.BytesIO(b))
 data=out.getvalue();members={n:{'bytes':len(b),'sha256':sha(b)} for n,b in files.items()}
 with tarfile.open(fileobj=io.BytesIO(data),mode='r:xz') as t:assert {x.name:{'bytes':x.size,'sha256':sha(t.extractfile(x).read())} for x in t}==members
 return data,{'source_commit':COMMIT,'archive_sha256':sha(data),'members':members}
def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--execute',action='store_true',required=True);ap.add_argument('--outcome',choices=['success','failure'],required=True);a=ap.parse_args()
 lock=(ROOT.parent/'develop_empty_ghost_20261112/.independent_full_game.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 audit=read(R/'POST_ATTEMPT_SOURCE_AUDIT.json');assert audit['source_commit']==COMMIT and audit['source_map_sha256']==MAP
 assert audit['status']=='PASS_POST_ATTEMPT_SOURCE_INTEGRITY_AUDIT_ONLY'
 expected=json.loads(gzip.decompress((R/'package/SOURCE_MAP.json.gz').read_bytes()))
 assert sha((json.dumps(expected,indent=2,sort_keys=True)+'\n').encode())==MAP
 trees={n:verify_tree(R/n,expected,AGG)[0] for n in ['restored_snapshot','run_tree']}
 for n,row in trees.items():assert row['files']==27968 and row['bytes']==1550696801
 assert read(R/'INDEPENDENT_RESTORE_VERIFIED.json')['source_commit']==COMMIT
 # The originally downloaded 17 source-package files remain untouched in place.
 original=read(R/'FRESH_PACKAGE_DOWNLOAD_VERIFIED.json');assert original['source_commit']==COMMIT and original['files']==17
 for row in original['records']:
  b=(R/'package'/row['filename']).read_bytes();assert len(b)==row['bytes'] and sha(b)==row['sha256']
 runs={};omitted=[];prior=None
 for label,source,_,count in TESTS:
  p=E/(label+'_result.json');log=E/(label+'.log')
  if not p.exists():assert not log.exists(),'Incomplete process receipt';omitted.append(label);continue
  result=read(p);b=log.read_bytes();assert result['source_commit']==COMMIT and result['source']==source and sha(b)==result['log_sha256']
  assert result['source_sha256']==expected[source]['sha256']
  assert prior is None or result['started_at_utc']>=prior;prior=result['finished_at_utc'];runs[label]=result
 files={'independent_tests/'+p.name:p.read_bytes() for p in E.iterdir() if p.is_file() and p.suffix in {'.gd','.log','.json'}}
 for name in ['run_remote_tier6.py','audit_tier6_attempt.py','prepare_publication_outcome.py','verify_final_publication.py']:files['preparation/'+name]=(ROOT/'preparation'/name).read_bytes()
 for n in ['POST_ATTEMPT_SOURCE_AUDIT.json','INDEPENDENT_RESTORE_VERIFIED.json','FIX_EVIDENCE_VERIFIED.json','FRESH_PACKAGE_DOWNLOAD_VERIFIED.json']:files[n]=(R/n).read_bytes()
 post={'checked_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_commit':COMMIT,'source_map_sha256':MAP,'trees':trees,'game_started_by_packager':False,'original_17_package_files_unchanged':True}
 files['PACKAGING_POST_TEST_REHASH.json']=enc(post)
 files['research/NEXT_TIER6_CONTINUATION_EVIDENCE.md']=(ROOT/'research/NEXT_TIER6_CONTINUATION_EVIDENCE.md').read_bytes()
 files['RESTORE_RECEIPT_PUBLICATION_VERIFIED.json']=(ROOT/'RESTORE_RECEIPT_PUBLICATION_VERIFIED.json').read_bytes()
 if a.outcome=='success':
  assert audit['runner_success_receipt_present'] and not omitted
  final=read(R/'INDEPENDENT_GAME_VERIFICATION.json');assert final['source_commit']==COMMIT and final['source_map_sha256']==MAP and final['status']=='PASS_FIXED_REMOTE_DARKCREST_TIER6_MATRIX_AND_CONTRACTS_POST_TEST_DOUBLE_REHASH'
  assert final['trees']==trees and final['full_game_processes']==1 and not final['full_game_acceptance'] and not final['default_pool_promoted']
  scenario=None
  for label,source,_,count in TESTS:
   result=runs[label];assert result['exit']==0 and result['reason']=='exited'
   log=(E/(label+'.log')).read_text();assert not any(x.startswith('FAIL ') or 'SCRIPT ERROR:' in x or 'Parse Error:' in x or 'COMMAND_FAILURE' in x for x in log.splitlines())
   n,case=validate(label,log,966 if label=='tier6_content_contract' else count,E)
   record=read(E/(label+'_VALIDATED.json'));assert record==final['tests'][label] and record['passed_checks']==n and record['log_sha256']==sha(log.encode())
   if case is not None:scenario=case
  assert scenario is not None
  files['INDEPENDENT_GAME_VERIFICATION.json']=(R/'INDEPENDENT_GAME_VERIFICATION.json').read_bytes()
  data,members=archive(files);P=ROOT/'final_package';assert not P.exists()
  early=ROOT/'restore_receipt_package';early_meta=read(ROOT/'RESTORE_RECEIPT_UPLOAD_METADATA.json')
  for row in early_meta['records']:
   b=(early/row['name']).read_bytes();assert len(b)==row['bytes'] and sha(b)==row['sha256']
  shutil.copytree(early,P)
  game=runs['tier6_real_matrix'];checks=final['tests']['tier6_real_matrix']['passed_checks']
  note=f'''# Ordinary Darkcrest Tier6: finite native hand-acquisition slice

Fixed source: {COMMIT}. Actual checks: {checks}; actual seeds: {[x['seed'] for x in scenario['cases']]}; complete-domain result counts: {scenario['coverage']}.

One complete headless Game process in fixed four-player test rooms: eight real Tier6 generations, plus one separate Tier5 triple-boundary room. Coin funding is a test fixture made through the original factory/_add_hand and publicly cast, not Coins naturally purchased in a shop or a complete player experience. Darkcrest purchase/play, five EOT growths and random generation use actual public commands. All four positive-stock weighted choices are checked on every draw; original RNG/stock/UID/factory/hand chain. The scenario no_live_state_injection flag means no direct alteration of RNG/stock/tier/token/UID; it does not mean no test fixtures exist. Actual per-case choices, RNG tickets, UIDs and seeds are in GAMEPLAY_MATRIX_RESULT.json. The first room actually casts tiers 1–5; its Tier5 output is not a newly generated Darkcrest parent. Tier5 triple boundary and this lower-tier regression are included, not a repeat of the old full six-output Tier5 matrix or its generated-parent native progression. The 810-check contract is pure; old fd0355f generated-parent gameplay remains old baseline evidence, not new dd428c2 evidence.

Pure contracts independently rerun: 966 / 810 / 68 / 166 / 267. Game elapsed {game['elapsed']} seconds, sampled peak process-group RSS {game['sampled_process_group_peak_rss']} bytes. Sampling is not a cgroup hard limit.

Both remote-restored and runtime trees rehashed after tests and again before packaging: 27,968 files / 1,550,696,801 bytes, map {MAP}, aggregate {AGG}. Fixed dependency and restore receipts included. The original 17-file source package remains untouched; this is a separate publication package with appended receipts and regenerated checksums.

Scope is ordinary Tier6 native hand acquisition only. Output minion active abilities/playing them, golden two-draw gameplay, Tier7+, mixed-board interactions, copies/triples beyond the tested refusal, saves, full matches, UI, default whole pool and complete latest minion/spell/trinket acceptance remain unverified. No new heroes, no paused empty-slot candidate changes, no full CI claim. Earlier empty-slot failures remain isolated, not resolved by this tranche. Post-Tier6 EOT remains held; NEXT_TIER6_CONTINUATION_EVIDENCE.md is a future research note with historical player reports but no strong official saturation-algorithm evidence, not implementation or acceptance evidence. Original Catalog OOM/timeout logs remain preserved in FIX_EVIDENCE and are failures, not passes. Prior local/static/historical tests are not substituted for this fixed-source run.

This local receipt is not proof of publication; fixed final-commit download and archive-member verification are still required.
'''
  additions={'GAMEPLAY_VERIFIED_SLICE.md':note.encode(),'GAMEPLAY_EVIDENCE.tar.xz':data,'GAMEPLAY_EVIDENCE_MANIFEST.json':enc(members),'GAMEPLAY_INDEPENDENT_VERIFICATION.json':enc(final),'GAMEPLAY_MATRIX_RESULT.json':enc(scenario),'GAMEPLAY_FINAL_AUDIT.json':enc(post),'REMOTE_SNAPSHOT_DOWNLOAD_VERIFIED.json':(R/'FRESH_PACKAGE_DOWNLOAD_VERIFIED.json').read_bytes(),'REMOTE_SNAPSHOT_RESTORE_VERIFIED.json':(R/'INDEPENDENT_RESTORE_VERIFIED.json').read_bytes(),'REMOTE_FIX_EVIDENCE_VERIFIED.json':(R/'FIX_EVIDENCE_VERIFIED.json').read_bytes()}
  for n,b in additions.items():
   if (P/n).exists():assert (P/n).read_bytes()==b,n
   else:put(P/n,b)
  metadata_name='FINAL_PUBLICATION_FILES.json'
 else:
  assert not audit['runner_success_receipt_present'] and not (R/'INDEPENDENT_GAME_VERIFICATION.json').exists()
  assert runs and (omitted or any(x['exit']!=0 or x['reason']!='exited' for x in runs.values()))
  P=ROOT/'failed_run_receipt_package';assert not P.exists();P.mkdir()
  failure={**post,'status':'FAILED_OR_INCOMPLETE_NATIVE_RUN_NO_GAMEPLAY_ACCEPTANCE','actual_results':runs,'tests_without_receipt':omitted,'not_run_tests_are_not_passes':True,'not_rollback':True}
  files['FAILED_NATIVE_RUN_REHASH.json']=enc(failure);data,members=archive(files)
  for n,b in {'FAILED_NATIVE_RUN_REHASH.json':enc(failure),'FAILED_NATIVE_RUN_EVIDENCE.tar.xz':data,'FAILED_NATIVE_RUN_EVIDENCE_MANIFEST.json':enc(members),'FAILED_NATIVE_RUN.md':('Fixed source '+COMMIT+'. Actual failure and skipped tests are recorded without promotion to acceptance. Both source trees unchanged; no rollback. See result/log and omitted-tests list. Original Catalog OOM/timeout and prior static/pure results are not gameplay passes.').encode()}.items():put(P/n,b)
  metadata_name='FAILED_RUN_UPLOAD_METADATA.json'
 # Only the copied publication checksum file is regenerated; original package unchanged.
 sums=''.join(sha(p.read_bytes())+'  '+p.name+'\n' for p in sorted(P.iterdir()) if p.is_file() and p.name!='SHA256SUMS.txt');(P/'SHA256SUMS.txt').write_text(sums)
 records=[]
 for p in sorted(P.iterdir()):
  assert p.is_file();b=p.read_bytes();records.append({'name':p.name,'bytes':len(b),'sha256':sha(b),'git_sha':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()})
 if a.outcome=='success':
  early_rows={x['name']:x for x in read(ROOT/'RESTORE_RECEIPT_UPLOAD_METADATA.json')['records']}
  changed=[x for x in records if x['name'] not in early_rows or early_rows[x['name']]['sha256']!=x['sha256']]
  assert [x['name'] for x in changed if x['name'] in early_rows]==['SHA256SUMS.txt']
  put(ROOT/'FINAL_UPLOAD_METADATA.json',enc({'status':'LOCAL_FINITE_SLICE_RECEIPTS_READY_NOT_PUBLISHED','source_commit':COMMIT,'previous_receipt_commit':'635f8e94abf5f98abb0310bfc5b552cde10ca3d5','folder':'battlegrounds-backup/pending/20261112-darkcrest-tier6-native-hand','files':len(records),'bytes':sum(x['bytes'] for x in records),'records':records,'changed_records':changed}))
 put(ROOT/metadata_name,enc(records if a.outcome=='success' else {'source_commit':COMMIT,'files':len(records),'bytes':sum(x['bytes'] for x in records),'records':records}))
 print(json.dumps({'status':'LOCAL_OUTCOME_PACKAGE_ONLY_NOT_PUBLISHED','outcome':a.outcome,'files':len(records),'bytes':sum(x['bytes'] for x in records),'path':str(P)}))
if __name__=='__main__':main()
