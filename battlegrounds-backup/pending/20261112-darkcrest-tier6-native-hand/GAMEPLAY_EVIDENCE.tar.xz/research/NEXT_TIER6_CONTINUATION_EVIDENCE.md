# 下一步备选：Tier6 后继续回合的证据评估

研究日期：2026-11-12 UTC。只读本地源码/证据与网页，未运行 Game、未修改冻结 candidate、未上传。当前 Tier6 后 EOT held 边界保持不变。

## 结论

**已有历史玩家实测叙述，支持六本连续多回合生成，而不是到六本就结束玩法；但本轮未找到官方明确 cap=6 或服务端饱和实现代码。不能把“全局固定6封顶”当作已证实规则。**

最有用的新证据是 2025-03-30 暴雪论坛玩家报告：金色暗潮连续数回合拿六本纳迦。它是实际体验的一手叙述，但不是官方人员答复、没有回放/标签日志、且使用金色；因此尚不足以直接认证当前版本普通暗潮内部数值是饱和于6还是继续增长而生成时钳制。

另有历史七本畸变房间能升级到7的玩家证据，明确反对把所有模式硬编码成6。本批不开放Tier7、畸变或金色；该证据仅用于限定推论。

## 本地原生证据：确知与不能推出之处

- `candidate/research/darkcrest/BG31_920.native.xml`，DBF115555：英文“Spellcraft: Get a random Tier @ Naga. (Improves each turn!)”；TAG_SCRIPT_DATA_NUM_1=1；END_OF_TURN_TRIGGER=1；TECH_LEVEL=5是本体酒馆等级，不是生成上限。
- `candidate/research/darkcrest/BG31_920t.native.xml`，DBF116478：随机Tier @ Naga；TAG_SCRIPT_DATA_NUM_1=1。
- 上述XML只有实体标签与文本，没有6、最大等级、clamp/min、饱和停止升级、重复回合处理的执行代码。金色实体同样不能填补此缺口。
- 原始XML来源记录：`candidate/research/darkcrest/native_source.json` 指向既有CardDefs.Bacon_latest.xml，记录整体SHA c385e3d67bfc2c52408059fbb0399b41164c8d1b78d3dd1619a6fb1882116690。
- 两个实体SHA256：普通 c6e4e14bfb5aebe9f348a5179736200384e9de761c86aad277c944a3625d0512；token e73a4939ae341c39233554d611e68d3a6c279a82dce860851f7862670363c59f。
- 本工程 `core/darkcrest_host.gd:7` 明注MAX_TIER6只是有限准入边界；约440/506的拒绝与509的tier+=1是本地实现，不能循环用作官方证据。未找到与暗潮对应的官方可执行行为脚本。

## 网页证据（均于2026-11-12实际检索/读取）

### A. 明确多回合六本的玩家一手叙述，非官方裁定

URL: https://us.forums.blizzard.com/en/hearthstone/t/darkcrest-strategist-potential-bug/144045
标题：Darkcrest Strategist Potential Bug。发帖：SleepyAether-1662，2025-03-30 15:39。
关键短句：“tier 6 nagas for several turns in a row”。作者说明使用金色暗潮，约获得9张，质疑随机分布而非升级边界。页面未见官方答复。
价值：比单纯卡文更直接支持六本后仍有后续Spellcraft。限制：历史版本、金色、无录像/Power.log，无法确认具体父体tag是否保持6。

### B. 历史七本例外，不能推广固定6

URL: https://www.reddit.com/r/BobsTavern/comments/1j7s6tk/can_we_do_something_with_this_please/
标题：Can we do something with this please? 搜索索引约2025年3月；正文当前仅显示相对日期“2y ago”，未核到精确日期，不把索引近似当准确发帖日。
原帖抱怨养成后拿硬币；回复讨论七本扎尔吉拉库存耗尽，并明确限定“Only when the anomaly is in”。这些是社区讨论，不是官方补丁说明。
价值：历史行为可能依房间最大等级变化；不应实现无条件全模式cap6。限制：无当前版本普通非畸变回放，本批不实现其相关模式。

### C. 达上限的旁证

URL: https://us.forums.blizzard.com/en/hearthstone/t/battlegrounds-minons-in-tavern/144312
标题：Battlegrounds minons in Tavern。Aokighara-1654，2025-04-04 01:50。
作者称暗潮“being on max”，仍生成当时高本候选。没有写出最大值或算法，仅是玩家旁证。

### D. 官方资料：仅证明入池，不证明cap

URL: https://hearthstone.blizzard.com/en-us/news/24204092/32-2-2-patch-notes
作者Blizzard Entertainment，2025-05-13。明确暗潮加入随从池，但未找到上限/饱和规则说明。官方出处不意味着能从未写内容推断规则。

### E. 未解决的卡库查询

https://hearthstone.wiki.gg/wiki/Battlegrounds/Darkcrest_Strategist ：搜索能找到，直接读取403；不声称读到了该页notes。
https://www.amalgadon.com/minion/darkcrest-strategist ：实际读取页称尚无overview/tips，仅卡片资料；无法补足cap，且页面当前版本/轮换不能替代本工程冻结来源。

检索用词包括英文卡名+maximum/caps/cap/stops/Tier6/Tier7/turns、BG31_920、Evolving Strategy maximum，以及中文“暗潮战略专家 上限/最高/六/七”。未找到官方明确处理算法，不是证明此资料不存在。

## 最小补证与实现前条件

1. 最优：可溯源到当前目标版本的官方行为脚本/开发者解释，明确普通无畸变房中达到6之后的父体计数、token等级及刷新规则。
2. 否则：一段有版本与房间条件的官方客户端正常对局录像，最好配公开可核的Power.log。普通暗潮从5→6，至少再经过两个EOT/招募开始；记录父体等级显示/tag、每轮原生新token等级、施放输出、旧token过期。不能只展示一个六本输出。
3. 若只能证明输出持续六本而看不到父体tag，必须明确选择“按观测实现”而不是声称原生内部计数已验证。需要父线程决定是否达到项目证据门槛，本研究不自行解除held。
4. 若证据支持无畸变房六本饱和，最小改动须把“升级值保持6”与“每轮EOT已处理/新轮grant”分开：last_eot仍每轮前进、防同轮重复；next recruit新发且唯一token，消费回执绑定新round；不得复用旧grant绕过used/replay。不必开放四张输出在场监听，不碰金色、Tier7、畸变、odd房。
5. 实现后的本地Game回归只能验证复制品符合所选规则，不能反过来充当官方cap证据。至少完整4候选正库存的四人连续两轮Tier6原生施放，旧token/旧round/重复EOT/重复cast负例，以及满手等原held边界。

**建议：可将“无畸变普通暗潮六本后继续轮次”列作有历史观测支持的下一候选，但目前仍缺当前普通模式饱和细节的强证据，不应直接把MAX_TIER guard改成min(6,tier+1)并称官方实现。**
