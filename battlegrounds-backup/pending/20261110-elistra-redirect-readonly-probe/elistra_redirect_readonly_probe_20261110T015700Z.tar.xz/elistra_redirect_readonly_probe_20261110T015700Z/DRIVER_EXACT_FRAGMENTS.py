def emit(c,es,k=(),rule='reviewed_exact',**kw):out[c['id']]={'id':c['id'],'supported':True,'effects':es,'keywords':list(k),'coverage_rule':rule,'coverage_text_sha256':hashlib.sha256(c['text'].encode()).hexdigest(),'default_pool':False,**kw}

for identity in ELISTRA_REDIRECT_IDS:
 out.pop(identity,None)
 c=cards.get(identity)
 compiled=compile_elistra_redirect(c,cards,root=R)
 if compiled is not None:
  metadata={k:v for k,v in compiled.items() if k not in ('effects','keywords','coverage_rule')}
  emit(c,compiled['effects'],compiled['keywords'],rule=compiled['coverage_rule'],**metadata)

ordered_ids=[identity for identity in ordered_ids if identity not in ELISTRA_REDIRECT_IDS]

ordered_ids.extend(identity for identity in ELISTRA_REDIRECT_IDS if identity in out)
