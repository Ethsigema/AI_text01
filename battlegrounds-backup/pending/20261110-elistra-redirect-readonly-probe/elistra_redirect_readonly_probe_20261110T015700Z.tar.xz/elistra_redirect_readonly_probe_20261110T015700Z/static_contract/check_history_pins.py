"""Read selected historical metadata. No archive extraction or source execution."""
import gzip,hashlib,json,pathlib,resource
resource.setrlimit(resource.RLIMIT_AS,(128*1024**2,128*1024**2))
O=pathlib.Path(__file__).resolve().parent;W=O.parent;R=W/'historical_tools_batch14_20261109T191857Z/runtime';F='research/elistra_redirect_native_recovery/'
pins=json.loads((O/'INPUTS_SHA256.json').read_text());pinmap={r['path']:r for r in pins}
def pin(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(65536),b''):h.update(b)
 d={'path':str(p.relative_to(W)),'bytes':p.stat().st_size,'sha256':h.hexdigest()};pinmap[d['path']]=d;return d
def load(p):pin(p);return json.loads(p.read_text())
source=load(R.parent/'SOURCE_MAP.json')
selected=['core/elistra_redirect_sources.gd',F+'candidates/core/elistra_redirect_sources.gd',F+'candidates/tools/elistra_redirect_patterns.py',F+'candidate.patch',F+'manifest.json',F+'raw_rows.json',F+'candidates/tools/build_effect_catalog.py',F+'before/tools/build_effect_catalog.py']
sourcechecks=[]
for rel in selected:
 actual=pin(R/rel);sourcechecks.append({'path':rel,'saved_source_map_entry':source.get(rel),'actual_sha256':actual['sha256'],'matches_source_map':source.get(rel,{}).get('sha256')==actual['sha256']})
inventory=load(W/'compiler_pin_contract_audit_20261109T230342Z/DRIVER_PIN_INVENTORY.json')
driverpins=[x for x in inventory['all_records'] if x['metadata_path']==F+'manifest.json']
versions=load(W/'historical_tools_batch16_driver_closeout_20261109T205039Z/compiler/CURRENT_VERSIONS.json')
selectedsha={'f73a4864eaa5d129508c082eb1126bb7cf7a7d600f3fa6698e3e5b0e46cec8ef','260f3d719d16e0ccc5c3c8527427a0b3e44e0ca69c61b9a6efad2f393c511ebc'}
vs=[x for x in versions if x['sha256'] in selectedsha]
p=W/'driver_mapping_contract_20261109T230410Z/versions/260f3d719d16e0ccc5c3c8527427a0b3e44e0ca69c61b9a6efad2f393c511ebc.json.gz';pin(p)
with gzip.open(p,'rt') as f: record=json.load(f)
mapping={k:record[k] for k in ('sha256','bytes','paths')}
patch=(R/(F+'candidate.patch')).read_text()
joined=[{'line':i+1,'line_text':s} for i,s in enumerate(patch.splitlines()) if '--- /dev/null' in s and not s.startswith('--- /dev/null')]
result={'source_map_selected_checks':sourcechecks,'historical_driver_inventory_declarations':driverpins,'preserved_driver_versions':vs,'existing_ast_record_identity':mapping,'patch_joined_headers':joined,'scope':'Only one previously extracted gzip AST record was read as JSON. No archive extraction or historical executable evaluation. Hash metadata establishes historical identities, not current driver selection or deployment authorization.','max_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
(O/'HISTORICAL_PINS.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
(O/'INPUTS_SHA256.json').write_text(json.dumps(sorted(pinmap.values(),key=lambda x:x['path']),ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'selected_source_map_matches':sum(x['matches_source_map'] for x in sourcechecks),'source_map_checks':len(sourcechecks),'preserved_versions':len(vs),'driver_pin_declarations':len(driverpins),'joined_patch_headers':joined,'max_rss_kib':result['max_rss_kib']},ensure_ascii=False,indent=2))
