# Elistra 历史来源、真实编译 hook 与当前 GD 契约

## 结论

1. 可独立保留历史工具整本，但不能认作已恢复当前编译器：`tools/elistra_redirect_patterns.py` 当前不存在；历史整本 SHA256 为 `94f4398484c99accb054bc125f896317aa2b3e611d702119ca14d3e5a37ecefa`，5771 bytes。历史 manifest、原树 SOURCE_MAP、整本及工具新增 patch 片段相互一致。
2. 当前 `core/elistra_redirect_sources.gd` 与历史候选逐字节相同，SHA256 为 `1ba1f47dcf21e814476fd634bf143a0e36eede3956399fb78ee377e86ca4199d`。其 RAW、EXPECTED、PROGRAMS 常量分别与封存 JSON 相等。这里不是用相似实现代替当前文件。
3. `raw_rows.json` **有历史封存 pin，但 compile_card 没有消费该 pin**。封存 SHA256 为 `e94544aeae79ae363083b3cee4d9cb84ccb89811a56e60edda869d755a0dea5a`，13826 bytes，见 manifest.files 对应记录，before=null。当前 research 文件、候选副本及 SOURCE_MAP 均一致。漏项是编译期绑定，不是来源资料从未存在。
4. 真实历史 hook 已从完整保存源码确认，采用 `cards.get(identity)` 传参，随后调用 emit，不是仅凭人工测试包装器猜测。当前完整 driver 仍不存在；之前处理过程、真实 Catalog 加载与游戏执行均未证实。

## 精确来源和版本边界

- 整个 `candidate.patch` SHA256 为 `dda35c4a77318f8b8d7260b133d68747cd00ddd93524e974e890668ec2f2d246`，与 manifest 一致。
- 对工具新文件、GD 新文件和 driver 两处增量，分别在内存中逐行核验原位置、上下文、hunk 行数，不使用 fuzzy matching；结果分别等于已保存整本。仅保存三个精确片段，没有向原树应用 patch。
- 不能把“整包 hash 正确”误写成“整包可直接应用”：XML 尾部没有最终换行，patch 第605和686行把后续文件头粘为 `+\t--- /dev/null`。本次没有修复或运行整包 patch；三个选定片段不受这两个粘连影响。
- 历史 driver before SHA 为 `f73a4864eaa5d129508c082eb1126bb7cf7a7d600f3fa6698e3e5b0e46cec8ef`，after 为 `260f3d719d16e0ccc5c3c8527427a0b3e44e0ca69c61b9a6efad2f393c511ebc`。manifest、先前 DRIVER_PIN_INVENTORY、已保存版本索引和本次文件重算一致。单独读取了已提取 mapping 契约中这个 after 版本的 gzip JSON 索引，没有解压历史归档。
- manifest 明确为 `static_only_candidate_not_runtime_validated`；EXPECTED 仍声明 `partial_implementation_pending_unified_validation`、ordinary pool/default pool false。不能将它升级为当前整合版本选择、统一运行验收或当前轮换事实。
- native manifest 记录 HearthSim commit `f7e80e44cf0d02b5c6e6de2817d4d920cdcb9cb2`、build225000、完整 CardDefs 响应 hash。本次只核验本地两份实体 XML 和这个封存 manifest，没有重新取得/验证完整上游响应，也未重新查验当前版本缺席陈述。两份 XML 的 ID/DBF、T7、8/8与16/16、直接圣盾/复生、嘲讽仅 ReferencedTag、缺 COST/race及中文文本与 fixtures 的关系均有小型 JSON 证据。

## compile_card 的确切输入与来源约束

`PROOF_SHA256` 只包含 native_source_manifest.json 和两份 XML，三个当前文件均匹配。函数不解析 XML，不验证 raw_rows 的封存 hash，也不加载历史 recovery manifest、GD RAW、programs.json 或 expected_compiled.json。

函数先要求 card 为 dict 且其 id 属于二选一，再验证三个 proof 文件；随后直接 JSON 读取 raw_rows，并用普通 Python `!=` 检查 `cards.get(identity)` 与两个 JSON 行。两行全部比较成功后，从工具内置 EXPECTED 取静态结果并 deepcopy，排除 id、supported、coverage_text_sha256。

由源码可得的限制：

- 该检查绑定的是“当前 root 下 raw_rows 与当前 cards 双行相等”。同时一致修改两者不一定触发拒绝；封存 manifest 的 raw pin 未参与运行路径，三份 proof 不包含 raw 行 hash。
- 原始 card 参数除 id 外不参与整行比较，没有独立 `card == cards[card.id]` 要求。真实 hook 的取值方式对 detached-card 测试可达性有约束，不能将任意手工 detached 调用直接说成该 hook 可达。
- Python 结构相等会把 bool 与数值1/0视为相等；当前 GD Exact.same 先区分类型，仅 int/float 有数值相等例外。因此两个语言的“整行相等”不是同一契约。
- 缺 raw 文件、坏 JSON、缺 identity 键或异常 mapping 等情形不都返回 None，源码没有统一捕获异常。未知 ID 在文件读取前直接返回 None。
- 返回使用 deepcopy，不直接把原始 row、EXPECTED 中嵌套对象作为输出别名。返回仍只是 overlay，不是完整源行。

本 worker 没有执行工具；针对变化输入的实测由父任务单独完成。本报告只给独立静态来源和真实调用契约，不能冒充全部实测通过。

## 历史 driver 的实际映射与 emit

精确 after 版本的关键行：

- 134：import compile_card 为 compile_elistra_redirect，同时 import SOURCE_IDS。
- 518–530：读取 catalog_raw 及10个补充源；既有 catalog.json 只用于 prior_catalog_ids 顺序，不作为 raw 编译输入。
- 531：`cards={c['id']:c for c in raw}`，同键后行整行覆盖，不是字段 merge。
- 532–535：QuestIdentity → `raw=list(cards.values())` → HeroValues → FinalSource。raw 是新列表但共享行对象，不是深复制。之后还有 confirmed value overrides 和大量其他编译函数。
- 3275–3283：遍历两个 identity，先删除旧 out，`c=cards.get(identity)`，`compile_elistra_redirect(c,cards,root=R)`；非 None 时拆分 metadata 后调用 emit；ordered_ids 再移除并追加成功 ID。
- 559 的 emit：out 外部 key 与输出内部 id 使用当时 `c['id']`，supported=True，coverage text hash 来自当时 c.text；尾部 `**kw` 可以覆盖一般字段。但此已 pin 工具明确不返回 id、supported、coverage_text_sha256，也不通过 metadata 重返 effects、keywords、coverage_rule，因此不能把通用 kw 风险错误归于这个固定返回值。
- 最后输出 `[out[identity] for identity in ordered_ids]`，没有统一重绑输出内部 id 的步骤；随后写覆盖率文件。这也是不导入/执行 driver 做只读调查的原因。

此 driver 有846个“整个 cards 作为参数”的静态 Call 站点，其中339个位于 Elistra hook 之前。计数不是执行次数或实际修改次数。按当前 runtime/tools 本地 .py 存在性检查，非标准库直接模块条目有789项缺失，包括两个前置预处理 recruit_quest_identity 和 hero_value_overrides；这不是完整 Python sys.path/传递依赖解析。既不能由这些函数名推定归一化结果，也不能由静态 hook 推定真实执行能够到达它。

## 当前 Catalog 和 card 的有限事实

流式读取当前 driver 对应11份原始 JSON：Elistra 两行只出现在 catalog_raw.json，均与封存 raw_rows 完全相同。其他10份没有这两个 ID。当前 catalog.json 的两行完整等于封存 EXPECTED。这些是固定文件事实，不是整条运行顺序等价性。

当前 Catalog：

- preload 当前 ElistraSources，并将其 TYPE 纳入效果集合。
- 第1387行遍历 RUNTIME_PATHS，其中包括缺失 Python 工具、raw_rows、JSON及native源，把内容 hash 纳入执行身份。这段不是 compile_card 的 raw pin 校验，也不能凭未运行的 FileAccess 错误行为断言缺文件一定被阻止。
- 四处加载入口分别执行 raw_source_error，或合并编译 overlay 后执行 source_error。当前 source_error 比较完整 RAW+EXPECTED，仅有指定 pool_blocker 例外。
- 第13566行对 claimed card 执行 source_error 与双来源 closure_error，出错则关 supported/default_pool/pool_supported；第16666行验证整个程序；第18584行声明双来源依赖。
- Catalog 的一般载入采用原记录 deep duplicate 后字段 merge，区别于 Python raw 建字典的整行覆盖。get_card 末尾直接返回 cards.get(id,{})，不能概括为所有读取都再次执行 Elistra 专用校验。
- 当前 game.gd 的 `_factory_unit(card,preview_uid)` 第9284行检查 source_error 与 closure_error；第16326行另有 unit_error 检查。本次仅读取具体源码片段，未运行 Game、Card 工厂、完整 Catalog、Combat 或 Godot。

当前 GD SAME 排除 bool/number 别名；因此编译期接受变更不自动等于当前 Catalog/工厂接受，更不能等于游戏可达。相反，静态存在拒绝 guard 也不等于已验证该输入在完整载入中的最终行为。

## 最小可执行依赖与未验证范围

独立 Python 小测试的最小输入为：已 pin 工具整本、标准库 pathlib/copy/hashlib/json、显式 root、三份精确 proof 文件、可读 raw_rows，以及含双行的 mapping 和所选 card。不需要历史 driver、Catalog、Game、Combat、Godot或网络。若依赖默认 ROOT，路径按实际工具安装位置 `__file__.parents[1]` 决定；不能把 recovery candidates 目录原位默认根误当 runtime 根。

GD source 本身还有 phase_undead_army_sources.gd 和 pool_identity.gd 两个 preload；运行 Catalog/工厂需要更大依赖图，未在本次闭合。当前完整编译驱动和大量模块缺失，历史 pin 不是当前运行授权或依赖可用性证明。完整编译器前序变换、hook 实际可达、其他 hook 后续改写、Catalog 最终加载状态、真实对局/存档兼容全部未运行、未验收。

## 证据、安全范围与复核

目录内只有本次审计脚本、两份结果 JSON、输入 pin 清单、精选带行号源码/patch片段、报告、日志和白名单 manifest。不复制源树整本、私聊、凭据、缓存或归档。不联网、不重试下载、不改原树与旧成果。

`STATIC_RESULTS.json` 与 `HISTORICAL_PINS.json` 给出机器可读结果；`evidence/` 给出精确片段；`INPUTS_SHA256.json` 是实际读取输入的完整清单。两个审计 Python 均限制128MiB地址空间，峰值 RSS 分别66928/38876 KiB。最终另逐一重算输入，检查调查期间没有变化。白名单 manifest 明确列出本目录产物，不把源输入误列为可交付副本。
