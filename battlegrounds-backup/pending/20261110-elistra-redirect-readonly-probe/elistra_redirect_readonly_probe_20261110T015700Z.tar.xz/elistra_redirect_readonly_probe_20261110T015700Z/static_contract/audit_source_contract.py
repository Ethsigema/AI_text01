"""Local static read-only audit. No historical Python/GDScript is executed."""
import ast, hashlib, json, pathlib, re, resource, xml.etree.ElementTree as ET
resource.setrlimit(resource.RLIMIT_AS, (128 * 1024**2, 128 * 1024**2))
O = pathlib.Path(__file__).resolve().parent
W = O.parent
R = W / 'historical_tools_batch14_20261109T191857Z/runtime'
F = 'research/elistra_redirect_native_recovery/'
D = R / F
inputs = {}
def digest(data): return hashlib.sha256(data).hexdigest()
def pin(p):
    p=pathlib.Path(p); h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(65536),b''): h.update(b)
    v={'path':str(p.relative_to(W)), 'bytes':p.stat().st_size, 'sha256':h.hexdigest()}
    inputs[v['path']]=v
    return v
def read(p): pin(p); return pathlib.Path(p).read_text()
def load(p): return json.loads(read(p))
def dump(name, obj): (O/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
def excerpt(label, p, ranges):
    lines=read(p).splitlines()
    content='SOURCE: '+str(p.relative_to(W))+'\nSHA256: '+pin(p)['sha256']+'\n'
    for a,b in ranges:
        content+='\n'+''.join(f'{i}: {lines[i-1]}\n' for i in range(a,b+1))
    (O/'evidence'/label).write_text(content)

manifest=load(D/'manifest.json')
patch=read(D/'candidate.patch')
tool_path=D/'candidates/tools/elistra_redirect_patterns.py'
tool=read(tool_path)
gd_path=R/'core/elistra_redirect_sources.gd'
gd=read(gd_path)
candidate_gd=read(D/'candidates/core/elistra_redirect_sources.gd')
driver_path=D/'candidates/tools/build_effect_catalog.py'
driver=read(driver_path)
before=read(D/'before/tools/build_effect_catalog.py')
rows=load(D/'raw_rows.json')
expected=load(D/'expected_compiled.json')
programs=load(D/'programs.json')
native_manifest=load(D/'native_source_manifest.json')
assignments={n.targets[0].id:ast.literal_eval(n.value) for n in ast.parse(tool).body
             if isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Name)
             and n.targets[0].id in ('SOURCE_IDS','EXPECTED','PROOF_SHA256')}
ids=list(assignments['SOURCE_IDS'])
gd_raw=json.loads(re.search(r'^const RAW: Dictionary=(.*)$',gd,re.M)[1])
gd_expected=json.loads(re.search(r'^const EXPECTED: Dictionary=(.*)$',gd,re.M)[1])
gd_programs=json.loads(re.search(r'^const PROGRAMS: Dictionary=(.*)$',gd,re.M)[1])
gd_paths=json.loads(re.search(r'^const RUNTIME_PATHS: Array=(.*)$',gd,re.M)[1])
proof_checks=[]
for rel,sha in assignments['PROOF_SHA256'].items():
    item=pin(R/rel); proof_checks.append({**item,'declared':sha,'match':item['sha256']==sha})
selected=['tools/elistra_redirect_patterns.py','tools/build_effect_catalog.py','core/elistra_redirect_sources.gd',F+'raw_rows.json']
manifest_checks=[]
for item in manifest['files']:
    if item['path'] not in selected: continue
    candidate=pin(R/item['candidate'])
    manifest_checks.append({'path':item['path'],'after_sha256':item['after_sha256'],
       'after_matches':candidate['sha256']==item['after_sha256'],
       'before_sha256':item['before_sha256'], 'bytes_match':candidate['bytes']==item['after_bytes']})

def patch_section(target):
    marker='+++ b/'+target+'\n'
    start=patch.index(marker)
    previous=patch.rfind('\n--- ',0,start)
    if previous<0: previous=0
    else: previous+=1
    end=patch.find('\n--- ',start)
    return patch[previous:(end+1 if end>=0 else len(patch))]
def apply_selected(section, old):
    # Exact line positions, contexts, and declared hunk counts. No fuzzy matching.
    lines=section.splitlines(keepends=True); old=old.splitlines(keepends=True)
    i=2; cursor=0; out=[]; hunks=[]
    while i<len(lines):
        m=re.fullmatch(r'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@\n',lines[i])
        assert m,lines[i]
        a,ac,b,bc=int(m[1]),int(m[2] or 1),int(m[3]),int(m[4] or 1)
        point=a-1 if ac else a; assert point>=cursor
        out.extend(old[cursor:point]); cursor=point; i+=1; oc=nc=0
        while i<len(lines) and not lines[i].startswith('@@ '):
            mark=lines[i][0]; text=lines[i][1:]
            assert mark in ' +-',repr(lines[i])
            if mark in ' -': assert old[cursor]==text; cursor+=1;oc+=1
            if mark in ' +': out.append(text);nc+=1
            i+=1
        assert (oc,nc)==(ac,bc),(oc,nc,ac,bc)
        hunks.append({'old_start':a,'old_count':ac,'new_start':b,'new_count':bc})
    out.extend(old[cursor:]); return ''.join(out),hunks
patch_checks=[]
for target,old,new in [('tools/elistra_redirect_patterns.py','',tool),('tools/build_effect_catalog.py',before,driver),('core/elistra_redirect_sources.gd','',gd)]:
    section=patch_section(target); rebuilt,hunks=apply_selected(section,old)
    assert rebuilt==new
    name=target.replace('/','__')+'.patch'
    (O/'evidence'/name).write_text(section)
    patch_checks.append({'target':target,'exact_apply_in_memory':True,'hunks':hunks,'result_sha256':digest(rebuilt.encode()),'fragment_sha256':digest(section.encode())})

native=[]
for identity in ids:
    p=R/(F+'native/'+identity+'.xml'); xml=read(p); entity=ET.fromstring(xml)
    tags={x.attrib['name']:x for x in entity.findall('Tag')}
    values={k:x.attrib.get('value') for k,x in tags.items()}
    zh=tags['CARDTEXT'].findtext('zhCN'); en=tags['CARDTEXT'].findtext('enUS')
    native.append({'id':identity,'entity_id':entity.attrib['CardID'],'dbf':entity.attrib['ID'],
       'sha256':pin(p)['sha256'],'tags':{k:values.get(k) for k in ['ATK','HEALTH','TECH_LEVEL','CARDTYPE','DIVINE_SHIELD','REBORN','PREMIUM','COST','CARDRACE','TAUNT','BACON_TRIPLE_UPGRADE_MINION_ID','BACON_TRIPLED_BASE_MINION_ID']},
       'taunt_referenced':entity.find('ReferencedTag[@name="TAUNT"]').attrib['value'],
       'enUS':en,'zhCN':zh,'stripped_zh_matches_row_text':re.sub(r'<[^>]+>|\s','',zh)==rows[identity]['text'],
       'text_sha256_matches_expected':digest(rows[identity]['text'].encode())==expected[identity]['coverage_text_sha256']})

# Stream card-array input, retaining only the two relevant rows.
class Stream:
    def __init__(self,f): self.f=f;self.buf='';self.pos=0;self.dec=json.JSONDecoder()
    def fill(self): self.buf=self.buf[self.pos:]+self.f.read(65536);self.pos=0
    def ws(self):
        while True:
            while self.pos<len(self.buf) and self.buf[self.pos].isspace():self.pos+=1
            if self.pos<len(self.buf):return
            self.fill()
            if not self.buf:return
    def char(self): self.ws();return self.buf[self.pos] if self.pos<len(self.buf) else ''
    def take(self,c): assert self.char()==c;self.pos+=1
    def value(self):
        self.ws()
        while True:
            try: v,end=self.dec.raw_decode(self.buf,self.pos);self.pos=end;return v
            except json.JSONDecodeError:
                old=len(self.buf)-self.pos;self.fill()
                if len(self.buf)==old:raise
    def cards(self):
        self.take('{');first=True;found=False
        while self.char()!='}':
            if not first:self.take(',')
            first=False;key=self.value();self.take(':')
            if key=='cards':
                assert not found;found=True;self.take('[');firstrow=True
                while self.char()!=']':
                    if not firstrow:self.take(',')
                    firstrow=False;yield self.value()
                self.take(']')
            else:self.value()
        self.take('}');assert not self.char() and found
source_paths=re.findall(r"raw\+=json.loads\(\(R/'([^']+)'",driver)
source_paths=['data/catalog_raw.json']+source_paths
source_files=[];selected_rows={};compiled_rows={}
for rel in source_paths+['data/catalog.json']:
    p=R/rel;matches=[];count=0;meta=pin(p)
    with p.open() as f:
        for row in Stream(f).cards():
            count+=1
            if row.get('id') in ids:
                ident=row['id'];matches.append({'id':ident,'row_index':count-1,'matches_fixture':row==rows[ident]})
                if rel=='data/catalog.json':compiled_rows[ident]=row
                else:selected_rows[ident]=row
    source_files.append({**meta,'row_count':count,'elistra_matches':matches})
compiled_comparison={i:{'equals_expected':compiled_rows.get(i)==expected[i],
   'actual_keys':sorted(compiled_rows.get(i,{})), 'expected_keys':sorted(expected[i])} for i in ids}

tree=ast.parse(driver)
hook_line=next(n.lineno for n in ast.walk(tree) if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=='compile_elistra_redirect')
calls=[n for n in ast.walk(tree) if isinstance(n,ast.Call) and (any(isinstance(a,ast.Name) and a.id=='cards' for a in n.args) or any(isinstance(k.value,ast.Name) and k.value.id=='cards' for k in n.keywords))]
imports=[]
for n in ast.walk(tree):
    if isinstance(n,ast.ImportFrom) and n.module: imports.append({'line':n.lineno,'module':n.module,'local_module_exists':(R/'tools'/(n.module+'.py')).is_file()})
    elif isinstance(n,ast.Import):
        for a in n.names:imports.append({'line':n.lineno,'module':a.name,'local_module_exists':(R/'tools'/(a.name+'.py')).is_file()})
std={'pathlib','collections','hashlib','json','re','copy','ast','typing','sys','os','xml','math','itertools'}
missing=[x for x in imports if x['module'].split('.')[0] not in std and not x['local_module_exists']]
summary={'status':'static_source_and_contract_audit_only','runtime_tool_exists':(R/'tools/elistra_redirect_patterns.py').is_file(),
 'runtime_driver_exists':(R/'tools/build_effect_catalog.py').is_file(),'tool_sha256':pin(tool_path)['sha256'],
 'patch_sha256':pin(D/'candidate.patch')['sha256'],'manifest_patch_sha256_matches':digest(patch.encode())==manifest['patch_sha256'],
 'current_gd_sha256':pin(gd_path)['sha256'],'current_gd_equals_historical_candidate':gd==candidate_gd,
 'manifest_selected_files':manifest_checks,'selected_exact_patch_checks':patch_checks,
 'proof_checks':proof_checks,'raw_rows_in_proof_sha256':F+'raw_rows.json' in assignments['PROOF_SHA256'],
 'raw_rows_sealed_sha256':pin(D/'raw_rows.json')['sha256'],'raw_rows_equal_gd_literal':rows==gd_raw,
 'tool_expected_equals_saved_json_and_gd':assignments['EXPECTED']==expected==gd_expected,
 'programs_equal_gd':programs==gd_programs,'historical_manifest_status':manifest['status'],
 'native_manifest_build':native_manifest['build'],'native_manifest_url_claim':native_manifest['source_url'],
 'full_response_hash_is_claim_not_independently_revalidated':native_manifest['full_response_sha256'],
 'source_files':source_files,'raw_input_pair_equals_fixture':selected_rows==rows,'compiled_pair_comparison':compiled_comparison,
 'native_xml_static_checks':native,'runtime_fingerprint_paths':gd_paths,
 'historical_driver':{'sha256':pin(driver_path)['sha256'],'before_sha256':pin(D/'before/tools/build_effect_catalog.py')['sha256'],
   'hook_line':hook_line,'all_whole_cards_call_syntax_sites':len(calls),'whole_cards_call_syntax_sites_before_hook':sum(n.lineno<hook_line for n in calls),
   'missing_nonstdlib_direct_module_entries':len(missing),'missing_preprocessors':[x for x in missing if x['module'] in ('recruit_quest_identity','hero_value_overrides')],
   'elistra_module_import':[x for x in imports if x['module']=='elistra_redirect_patterns']},
 'scope':{'network':False,'original_or_old_output_writes':False,'historical_code_executed':False,'godot_game_combat_catalog_executed':False,'archive_extraction':False,'python_address_space_limit_bytes':128*1024**2},
 'max_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
dump('STATIC_RESULTS.json',summary)
excerpt('TOOL_SOURCE.txt',tool_path,[(1,15)])
excerpt('SOURCE_METHODS.txt',gd_path,[(1,5),(8,64)])
excerpt('EXACT_COMPARATOR.txt',R/'core/phase_undead_army_sources.gd',[(8,21)])
excerpt('HISTORICAL_DRIVER.txt',driver_path,[(129,137),(518,559),(3274,3285),(len(driver.splitlines())-7,len(driver.splitlines()))])
excerpt('CURRENT_CATALOG.txt',R/'core/catalog.gd',[(208,212),(1385,1390),(2189,2209),(3229,3240),(5078,5089),(6919,6930),(8760,8771),(11810,11826),(13564,13572),(14838,14843),(16664,16671),(18582,18586)])
excerpt('CURRENT_CARD_FACTORY.txt',R/'core/game.gd',[(9036,9039),(9280,9288),(16323,16328)])
excerpt('RECOVERY_SOURCE_SELECTION.txt',D/'build_candidates.py',[(23,38),(46,53)])
# Keep selected input pins only, not unrelated source-map or archive contents.
dump('INPUTS_SHA256.json',sorted(inputs.values(),key=lambda x:x['path']))
print(json.dumps({k:summary[k] for k in ['tool_sha256','current_gd_equals_historical_candidate','raw_rows_in_proof_sha256','raw_rows_equal_gd_literal','raw_input_pair_equals_fixture','historical_driver','max_rss_kib']},ensure_ascii=False,indent=2))
