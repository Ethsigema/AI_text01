from pathlib import Path
import hashlib,json,resource,subprocess,sys
# Leave the supervisor's hard ceiling unchanged; child test/verification scripts self-limit to 128MiB.
# Godot is independently bounded and monitored in run_godot.py.
H=Path(__file__).resolve().parent
if len(sys.argv)!=2:raise SystemExit('Usage: python replay_to_new.py /absolute/new/directory')
D=Path(sys.argv[1]).resolve();assert not D.exists();D.mkdir(parents=True)
pins=json.loads((H/'REPLAY_INPUTS.json').read_text())
for rel,pin in pins.items():
 p=Path(rel);assert not p.is_absolute() and '..' not in p.parts
 b=(H/p).read_bytes();assert len(b)==pin['bytes'] and hashlib.sha256(b).hexdigest()==pin['sha256']
 d=D/p;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(b)
for script in ['test_original.py','run_godot.py','verify_results.py']:
 result=subprocess.run([sys.executable,str(D/script)],capture_output=True,text=True)
 (D/(script+'.stdout.log')).write_text(result.stdout);(D/(script+'.stderr.log')).write_text(result.stderr)
 assert result.returncode==0,(script,result.returncode,result.stderr)
for rel,pin in pins.items():assert hashlib.sha256((D/rel).read_bytes()).hexdigest()==pin['sha256']
def strip_peak(v):
 v=dict(v);v.pop('max_rss_kib',None);return v
assert strip_peak(json.loads((D/'PYTHON_REPORT.json').read_text()))==strip_peak(json.loads((H/'PYTHON_REPORT.json').read_text()))
assert strip_peak(json.loads((D/'VERIFIED_RESULTS.json').read_text()))==strip_peak(json.loads((H/'VERIFIED_RESULTS.json').read_text()))
outputs=['GODOT_first.json','GODOT_repeat.json','GODOT_first.stderr.log','GODOT_repeat.stderr.log','GODOT_first.stdout.log','GODOT_repeat.stdout.log','DRIVER_EXACT_FRAGMENTS.py','ORIGINAL_OUTPUTS.json']
for rel in outputs:assert (D/rel).read_bytes()==(H/rel).read_bytes(),rel
report={'input_files':len(pins),'byte_equal_outputs':outputs,'python_report_equal_except_resource_peak':True,'verification_equal_except_resource_peak':True,'replay_directory':str(D),'old_inputs_not_modified':True}
(D/'REPLAY_RESULT.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
