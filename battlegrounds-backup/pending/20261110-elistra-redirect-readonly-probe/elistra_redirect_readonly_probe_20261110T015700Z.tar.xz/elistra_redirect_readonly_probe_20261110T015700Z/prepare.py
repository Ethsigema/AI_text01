from pathlib import Path
import ast,hashlib,json,re,resource,shutil
resource.setrlimit(resource.RLIMIT_AS,(128*1024**2,128*1024**2))
H=Path(__file__).resolve().parent;R=H.parent/'historical_tools_batch14_20261109T191857Z/runtime';F='research/elistra_redirect_native_recovery/'
B=json.loads((R.parent/'SOURCE_MAP.json').read_text());pins={}
rels=[F+x for x in ['manifest.json','candidate.patch','native_source_manifest.json','native/BGS_205.xml','native/TB_BaconUps_306.xml','raw_rows.json','programs.json','expected_compiled.json','candidates/tools/elistra_redirect_patterns.py','candidates/tools/build_effect_catalog.py','candidates/core/elistra_redirect_sources.gd']]+['core/elistra_redirect_sources.gd','core/phase_undead_army_sources.gd','core/pool_identity.gd']
for rel in rels:
 p=R/rel;b=p.read_bytes();sha=hashlib.sha256(b).hexdigest();assert sha==B[rel]['sha256'];d=H/'original_inputs'/rel;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(b);assert p.stat().st_ino!=d.stat().st_ino;pins[rel]={'sha256':sha,'bytes':len(b)}
 if rel.startswith('core/'):
  d=H/'gd_minimal'/rel;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(b)
manifest=json.loads((R/F/'manifest.json').read_text())
for rel in ['tools/elistra_redirect_patterns.py','core/elistra_redirect_sources.gd']:
 rec=next(x for x in manifest['files'] if x['path']==rel);assert pins[F+'candidates/'+rel]['sha256']==rec['after_sha256']
 assert rec['before_sha256'] is None
assert (H/'original_inputs/core/elistra_redirect_sources.gd').read_bytes()==(H/'original_inputs'/F/'candidates/core/elistra_redirect_sources.gd').read_bytes()
gdsource=(R/'core/elistra_redirect_sources.gd').read_text();gd={name:json.loads(re.search(r'^const '+name+r': (?:Dictionary|Array)=(.*)$',gdsource,re.M)[1]) for name in ['RAW','EXPECTED','PROGRAMS','IDS','RUNTIME_PATHS']}
for name,fn in [('RAW','raw_rows.json'),('EXPECTED','expected_compiled.json'),('PROGRAMS','programs.json')]:assert json.dumps(gd[name],sort_keys=True)==json.dumps(json.loads((R/F/fn).read_text()),sort_keys=True)
const={}
for n in ast.parse((R/F/'candidates/tools/elistra_redirect_patterns.py').read_text()).body:
 if isinstance(n,ast.Assign) and n.targets[0].id!='ROOT':const[n.targets[0].id]=ast.literal_eval(n.value)
assert json.dumps(const['EXPECTED'],sort_keys=True)==json.dumps(gd['EXPECTED'],sort_keys=True)
for path,digest in const['PROOF_SHA256'].items():assert pins[path]['sha256']==digest
assert F+'raw_rows.json' not in const['PROOF_SHA256']
def walk(v,p=[]):
 yield p,v
 if type(v) is dict:
  for k,x in v.items():yield from walk(x,p+[k])
 if type(v) is list:
  for k,x in enumerate(v):yield from walk(x,p+[k])
cases=[]
def add(regime,identity,path,op,**kw):cases.append({'label':f'{len(cases):04d}:{regime}:{identity}:{op}:'+'.'.join(map(str,path)),'regime':regime,'identity':identity,'path':path,'op':op,**kw})
for identity in gd['IDS']:
 for regime in ['detached','coupled','companion']:
  add(regime,identity,[],'canonical')
  for path,op in [(['text'],'change_string'),(['attack'],'number_delta'),(['health'],'number_delta'),(['tier'],'delete'),(['cost'],'null_to_false'),(['tribes'],'append_item'),([],'extra_key'),([],'id_only'),(['id'],'change_string'),(['is_golden'],'toggle_bool'),(['attack'],'numeric_float'),(['tier'],'numeric_float'),(['images',0,'row'],'numeric_float'),(['attack'],'number_string'),(['attack'],'nan'),(['attack'],'pos_inf')]:add(regime,identity,path,op)
  target=identity if regime!='companion' else next(x for x in gd['IDS'] if x!=identity)
  for path,v in walk(gd['RAW'][target]):
   if type(v) is bool:
    add(regime,identity,path,'bool_to_int');add(regime,identity,path,'bool_to_float')
 for v in [None,[],0,'invalid']:add('detached',identity,[],'invalid_root',value=v);add('mapping_root',identity,[],'invalid_root',value=v)
 for op in ['canonical','extra_unrelated','swap_rows','duplicate_normal','duplicate_golden']:add('mapping_root',identity,[],op)
 for dep in gd['IDS']:add('mapping_root',identity,[dep],'delete');add('mapping_root',identity,[dep],'invalid_member')
 for path,op in [(['text'],'change_string'),(['attack'],'number_delta'),(['tier'],'delete'),(['cost'],'null_to_false'),([],'extra_key'),(['supported'],'bool_to_int'),(['is_golden'],'bool_to_int')]:
  add('coherent_raw_file',identity,path,op)
  add('raw_file_only',identity,path,op)
 for op in ['missing_raw','malformed_json','null_json','list_json','missing_identity','nonrow_identity','array_member']:
  add('bad_raw_file',identity,[],op)
 for path in const['PROOF_SHA256']:
  for op in ['proof_changed','proof_missing']:add('bad_proof',identity,[],op,proof_path=path)
(H/'CASES.json').write_text(json.dumps(cases,ensure_ascii=False,indent=2)+'\n');(H/'GD_CONSTANTS.json').write_text(json.dumps(gd,ensure_ascii=False,indent=2)+'\n');(H/'INPUT_PINS.json').write_text(json.dumps(pins,indent=2)+'\n')
(H/'gd_minimal/project.godot').write_text('[application]\nconfig/name="Elistra readonly source probe"\n[rendering]\nrenderer/rendering_method="gl_compatibility"\n')
for rel in [*const['PROOF_SHA256'],F+'raw_rows.json']:
 dst=H/'fixture_root'/rel;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(H/'original_inputs'/rel,dst)
report={'case_count':len(cases),'original_inputs':len(pins),'gd_scripts':3,'raw_proof_omitted':True,'new_correction_created':False,'tool_installed':False,'max_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
(H/'PREPARATION.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
