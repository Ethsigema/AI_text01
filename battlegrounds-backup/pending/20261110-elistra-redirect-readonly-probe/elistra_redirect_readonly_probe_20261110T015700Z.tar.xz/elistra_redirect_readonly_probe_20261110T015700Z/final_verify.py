from pathlib import Path
import hashlib,json,resource
resource.setrlimit(resource.RLIMIT_AS,(128*1024**2,128*1024**2))
H=Path(__file__).resolve().parent;W=H.parent;R=W/'historical_tools_batch14_20261109T191857Z/runtime'
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for chunk in iter(lambda:f.read(1024*1024),b''):h.update(chunk)
 return h.hexdigest()
pins=json.loads((H/'INPUT_PINS.json').read_text());checked={}
for rel,pin in pins.items():
 for kind,p in [('original',R/rel),('snapshot',H/'original_inputs'/rel)]:
  assert p.stat().st_size==pin['bytes'] and sha(p)==pin['sha256'];checked[kind+':'+rel]=pin
worker_input_counts={}
for folder,filename in [('static_contract','INPUTS_SHA256.json'),('review_independent','INPUT_PINS.json')]:
 p=H/folder/filename
 assert p.exists(),str(p)
 data=json.loads(p.read_text())
 records=data if isinstance(data,list) else [{'path':k,**v} for k,v in data.items()]
 for rec in records:
  rel=Path(rec['path']);assert not rel.is_absolute() and '..' not in rel.parts
  q=W/rel;assert q.stat().st_size==rec['bytes'] and sha(q)==rec['sha256'],str(q)
 worker_input_counts[folder]=len(records)
old=json.loads((W/'spellteach_combined_dependency_audit_20261110T010950Z/FINAL_SOURCE_VERIFICATION.json').read_text())['old_archives']
old['spellteach_combined_dependency_audit_20261110T010950Z.tar.xz']='d684f9e5bde5193f95e8fecb242a7d49cc17adb7f796dc380c81d91b89174e40'
for rel,digest in old.items():assert sha(W/rel)==digest
boundary={'core/catalog.gd':'5ba81a78d4924e4596dada5cb8f1a9ad5877d7bed6c7d350ca370d8bff955a72','core/game.gd':'84ea17caff1c22d082badf6118f8fdde02e35616d4d156b28430b02313504410','core/spellteach_murloc_sources.gd':'11f8b3b06cc65b484ae379fbeaf825843df0f22d55c1887d23eba152d3b41ca5','core/spellteach_murloc_host.gd':'fa080e10757bde93b3c7b75332855576dcca08f7b2a4fdc589dc20907fe7cafe'}
for rel,digest in boundary.items():assert sha(R/rel)==digest
assert sha(R.parent/'SOURCE_MAP.json')=='7fec8d69e82de8bfcb7373549951f9456671b5c3980135d6ec6f983a3daf5ed7'
scope=json.loads((W/'historical_tools_batch15_20261109T195018Z/REMAINING_SCOPE.json').read_text())['remaining_targets'];assert 'tools/elistra_redirect_patterns.py' in scope;assert len(scope)==345;assert all(not (R/rel).exists() for rel in scope)
assert not (R/'evidence/portable_legacy/CardDefs.Bacon_latest.xml').exists()
for rel,pin in json.loads((H/'REPLAY_INPUTS.json').read_text()).items():assert sha(H/rel)==pin['sha256']
r={'status':'SELECTED_SOURCE_AND_OLD_ARCHIVE_PINS_UNCHANGED','worker_input_records_rechecked':worker_input_counts,'selected_original_files':len(pins),'source_snapshots_verified':len(pins),'runtime_boundary_files':boundary,'old_archives':old,'remaining_scope_count':len(scope),'elistra_target_in_remaining_scope':True,'remaining_tools_missing':345,'xml_candidate_not_installed':True,'no_full_tree_revalidation_claim':True,'no_game_or_full_driver_run':True,'no_network_attempted':True,'no_old_save_read':True,'tool_installed':False,'new_correction_created':False,'max_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
(H/'FINAL_VERIFICATION.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
