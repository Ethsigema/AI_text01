from pathlib import Path
import json, os, resource, subprocess, time

H=Path(__file__).resolve().parent
def available_kib():
 for line in Path('/proc/meminfo').read_text().splitlines():
  if line.startswith('MemAvailable:'):return int(line.split()[1])
assert available_kib()>=1024*1024
env=os.environ.copy()
for key,sub in [('HOME','isolated_home'),('XDG_CACHE_HOME','isolated_cache'),('XDG_DATA_HOME','isolated_data'),('XDG_CONFIG_HOME','isolated_config')]:
 p=H/sub;p.mkdir(exist_ok=True);env[key]=str(p)
env['GODOT_SILENCE_ROOT_WARNING']='1'
def bound():
 resource.setrlimit(resource.RLIMIT_AS,(2*1024**3,2*1024**3))
 resource.setrlimit(resource.RLIMIT_CORE,(0,0))
summary=[]
for run in ['first','repeat']:
 command=['/usr/local/bin/godot','--headless','--path',str(H/'gd_minimal'),'--script','res://gate.gd','--',str(H/f'GODOT_{run}.json')]
 start=time.monotonic();peak=0;stopped=None
 with (H/f'GODOT_{run}.stdout.log').open('w') as out,(H/f'GODOT_{run}.stderr.log').open('w') as err:
  p=subprocess.Popen(command,stdout=out,stderr=err,env=env,preexec_fn=bound)
  while p.poll() is None:
   stat=Path(f'/proc/{p.pid}/status')
   try:
    for line in stat.read_text().splitlines():
     if line.startswith('VmRSS:'):peak=max(peak,int(line.split()[1]))
   except FileNotFoundError:pass
   if peak>192*1024:stopped='rss_192MiB'
   elif available_kib()<640*1024:stopped='system_available_under_640MiB'
   elif time.monotonic()-start>45:stopped='timeout_45s'
   if stopped:p.kill();p.wait();break
   time.sleep(.02)
 code=p.returncode
 record={'run':run,'exit_code':code,'seconds':round(time.monotonic()-start,3),'peak_rss_kib':peak,'stopped':stopped,'max_address_space_bytes':2*1024**3,'rss_stop_kib':192*1024}
 summary.append(record);(H/'GODOT_RUNS.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(record))
 assert code==0 and stopped is None
 stderr=(H/f'GODOT_{run}.stderr.log').read_text()
 assert 'ERROR:' not in stderr and 'SCRIPT ERROR' not in stderr,stderr
assert json.loads((H/'GODOT_first.json').read_text())==json.loads((H/'GODOT_repeat.json').read_text())
print('Two Godot reports exactly match.')
