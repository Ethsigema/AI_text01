"""Read-only independent audit; does not import/execute the historical project.

Only outputs in this script's own directory are written. Python/Godot outcomes
are independently modeled from the inspected source, not represented as reruns.
"""
from pathlib import Path
from copy import deepcopy
from collections import Counter
import argparse, ast, hashlib, json, math, re, resource

resource.setrlimit(resource.RLIMIT_AS, (128*1024**2, 128*1024**2))
HERE = Path(__file__).resolve().parent
args=argparse.ArgumentParser(description=__doc__)
args.add_argument('--workspace',type=Path,default=HERE.parent,help='Root containing the three named input evidence directories.')
BASE = args.parse_args().workspace.resolve()
P = BASE/'elistra_redirect_readonly_probe_20261110T015700Z'
R = BASE/'historical_tools_batch14_20261109T191857Z/runtime'
F = 'research/elistra_redirect_native_recovery/'
inputs = {}
checks = []

def read(path):
    b = path.read_bytes()
    inputs[str(path.relative_to(BASE))] = {'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest()}
    return b

def jread(path): return json.loads(read(path))
def check(name, value):
    assert value, name
    checks.append(name)
def same_json(a,b): return json.dumps(a,sort_keys=True,ensure_ascii=False)==json.dumps(b,sort_keys=True,ensure_ascii=False)

pins = jread(P/'INPUT_PINS.json')
source_map = jread(R.parent/'SOURCE_MAP.json')
for rel, pin in pins.items():
    a, b = read(R/rel), read(P/'original_inputs'/rel)
    check('historical_and_copy_pin:'+rel, a==b and len(a)==pin['bytes'] and hashlib.sha256(a).hexdigest()==pin['sha256']==source_map[rel]['sha256'])
    check('independent_inode:'+rel, (R/rel).stat().st_ino!=(P/'original_inputs'/rel).stat().st_ino)
    if rel.startswith('core/'):
        check('minimal_gd_exact:'+rel, read(P/'gd_minimal'/rel)==a)
del source_map
probe_files = ['prepare.py','test_original.py','run_godot.py','gd_minimal/gate.gd','gd_minimal/project.godot',
               'CASES.json','GD_CONSTANTS.json','DRIVER_EXACT_FRAGMENTS.py','ORIGINAL_OUTPUTS.json','PREPARATION.json',
               'PYTHON_REPORT.json','PYTHON_RUN.stdout.log','GODOT_RUNS.json','GODOT_first.json','GODOT_repeat.json',
               'GODOT_first.stdout.log','GODOT_repeat.stdout.log','GODOT_first.stderr.log','GODOT_repeat.stderr.log']
for name in probe_files: read(P/name)
gd_source = read(R/'core/elistra_redirect_sources.gd').decode()
gd = {n: json.loads(re.search(r'^const '+n+r': (?:Dictionary|Array)=(.*)$',gd_source,re.M)[1])
      for n in ['RAW','EXPECTED','PROGRAMS','IDS','RUNTIME_PATHS']}
check('gd_constants_exact', same_json(gd,jread(P/'GD_CONSTANTS.json')))
RAW, EXPECTED, IDS = gd['RAW'],gd['EXPECTED'],gd['IDS']
for const,fn in [('RAW','raw_rows.json'),('EXPECTED','expected_compiled.json'),('PROGRAMS','programs.json')]:
    check('gd_constant_matches_historical:'+const, same_json(gd[const],jread(R/F/fn)))
source = read(R/F/'candidates/tools/elistra_redirect_patterns.py').decode()
tree = ast.parse(source)
const = {n.targets[0].id:ast.literal_eval(n.value) for n in tree.body if isinstance(n,ast.Assign) and n.targets[0].id!='ROOT'}
check('python_expected_matches_gd',same_json(const['EXPECTED'],EXPECTED))
proof = const['PROOF_SHA256']
check('three_proofs_and_raw_omission',len(proof)==3 and F+'raw_rows.json' not in proof)
for path,digest in proof.items(): check('proof_digest:'+path,pins[path]['sha256']==digest)
reference = ast.parse('''def compile_card(card,cards,root=ROOT):
    if not isinstance(card,dict) or card.get('id') not in SOURCE_IDS: return None
    root=Path(root)
    if any(not (root/path).is_file() or hashlib.sha256((root/path).read_bytes()).hexdigest()!=digest for path,digest in PROOF_SHA256.items()): return None
    rows=json.loads((root/'research/elistra_redirect_native_recovery/raw_rows.json').read_text())
    if any(cards.get(identity)!=rows[identity] for identity in SOURCE_IDS): return None
    return {k:deepcopy(v) for k,v in EXPECTED[card['id']].items() if k not in ('id','supported','coverage_text_sha256')}
''').body[0]
check('compile_card_inspected_logic_exact',ast.dump(next(n for n in tree.body if isinstance(n,ast.FunctionDef)))==ast.dump(reference))
driver_text = read(R/F/'candidates/tools/build_effect_catalog.py').decode()
driver = ast.parse(driver_text)
emit = next(n for n in driver.body if isinstance(n,ast.FunctionDef) and n.name=='emit')
hook = next(n for n in driver.body if isinstance(n,ast.For) and isinstance(n.iter,ast.Name) and n.iter.id=='ELISTRA_REDIRECT_IDS')
pos = driver.body.index(hook)
nodes = [emit,hook,*driver.body[pos+1:pos+3]]
fragments = '\n\n'.join(ast.get_source_segment(driver_text,n) for n in nodes)+'\n'
check('saved_emit_hook_fragments_exact',read(P/'DRIVER_EXACT_FRAGMENTS.py').decode()==fragments)
node_lines = [{'kind':type(n).__name__,'first':n.lineno,'last':n.end_lineno} for n in nodes]
del driver,driver_text,nodes,tree
dependencies = set()
pending = ['core/elistra_redirect_sources.gd','core/pool_identity.gd']
while pending:
    name = pending.pop()
    if name in dependencies: continue
    dependencies.add(name)
    code = read(P/'gd_minimal'/name).decode()
    pending.extend(re.findall(r'(?:preload|load)\("res://([^\"]+)"\)',code))
check('only_three_dependency_scripts',dependencies=={'core/elistra_redirect_sources.gd','core/phase_undead_army_sources.gd','core/pool_identity.gd'})
check('no_other_minimal_gd_files',set(str(x.relative_to(P/'gd_minimal')) for x in (P/'gd_minimal').rglob('*.gd'))==dependencies|{'gate.gd'})

cases = jread(P/'CASES.json'); py = jread(P/'PYTHON_REPORT.json'); godot = jread(P/'GODOT_first.json')
check('repeat_report_byte_equal',read(P/'GODOT_first.json')==read(P/'GODOT_repeat.json'))
check('262_unique_labels',len(cases)==262 and len({x['label'] for x in cases})==262)
check('262_aligned_reports',len(py['results'])==len(godot['results'])==262 and all(c['label']==p['label']==g['label'] for c,p,g in zip(cases,py['results'],godot['results'])))
check('driver_nodes_metadata',py['executed_driver_nodes']==node_lines and py['full_driver_executed'] is False)
check('compiled_outputs_match_constants',same_json(jread(P/'ORIGINAL_OUTPUTS.json'),EXPECTED))
check('no_godot_failures',godot['failures']==[])
check('probe_boundaries_declared',all(godot[k] is True for k in ['strict_ingress_is_composed_diagnostic_not_single_project_entry','closure_does_not_enforce_key_equals_inline_id','catalog_interface_is_minimal_probe_not_full_catalog']) and godot['game_catalog_host_or_save_run'] is False)

def mutate(value,c):
    op,path=c['op'],c['path']
    if op=='canonical': return value
    if op=='invalid_root': return deepcopy(c['value'])
    if op=='swap_rows': return {IDS[0]:value[IDS[1]],IDS[1]:value[IDS[0]]}
    if op=='duplicate_normal': return {i:deepcopy(value[IDS[0]]) for i in IDS}
    if op=='duplicate_golden': return {i:deepcopy(value[IDS[1]]) for i in IDS}
    if op=='id_only': return {'id':value['id']}
    if op=='extra_unrelated': return dict(value,**{'not-a-source':{'id':'not-a-source'}})
    if op=='invalid_member': value[path[0]]=None; return value
    p=value
    for key in path[:-1]: p=p[key]
    if op=='delete': del p[path[-1]]; return value
    old=p[path[-1]] if path else value
    if op=='change_string': new=old+'__changed__'
    elif op=='number_delta': new=old+1
    elif op=='toggle_bool': new=not old
    elif op=='null_to_false': new=False
    elif op in ['bool_to_float','numeric_float']: new=float(old)
    elif op=='bool_to_int': new=int(old)
    elif op=='number_string': new=str(old)
    elif op=='append_item': new=old+['__extra__']
    elif op=='extra_key': new=dict(old,__extra__=True)
    elif op=='nan': new=float('nan')
    elif op=='pos_inf': new=float('inf')
    else: raise AssertionError(op)
    if path: p[path[-1]]=new; return value
    return new

def equal_gd(a,b):
    # Exact.same: bool is deliberately not a numeric type in Godot.
    if type(a) in (int,float) and type(b) in (int,float): return a==b
    if type(a) is not type(b): return False
    if isinstance(a,dict): return a.keys()==b.keys() and all(equal_gd(a[k],b[k]) for k in a)
    if isinstance(a,list): return len(a)==len(b) and all(equal_gd(x,y) for x,y in zip(a,b))
    return a==b
def raw_ok(c): return isinstance(c,dict) and c.get('id') in IDS and equal_gd(c,RAW[c['id']])
def strict(card,cards): return raw_ok(card) and isinstance(cards,dict) and all(isinstance(cards.get(i),dict) and cards[i].get('id')==i and raw_ok(cards[i]) for i in IDS)
def source_error(c):
    # Inputs exercised here all use either native ids or empty missing rows.
    if c.get('id') not in IDS: return ''
    e=deepcopy(RAW[c['id']]); e.update(EXPECTED[c['id']])
    if 'pool_blocker' in c: e['pool_blocker']=pool_reason
    return '' if equal_gd(c,e) else 'elistra_redirect_whole_source_changed'
def closure(cards):
    for i in IDS:
        c=cards.get(i,{})
        issue=source_error(c)
        if issue or not c.get('supported',False): return issue or 'elistra_redirect_missing_native_source'
    return ''
pool_text=read(R/'core/pool_identity.gd').decode()
pool_reason=json.loads(re.search(r'^const MINION_REASON:String=(.*)$',pool_text,re.M)[1])

def inputs_for(c):
    identity,regime=c['identity'],c['regime']
    cards,card,rows=deepcopy(RAW),deepcopy(RAW[identity]),deepcopy(RAW)
    if regime=='detached': card=mutate(card,c)
    elif regime=='coupled': cards[identity]=mutate(cards[identity],c);card=cards[identity]
    elif regime=='companion':
        other=next(i for i in IDS if i!=identity);cards[other]=mutate(cards[other],c);card=cards[identity]
    elif regime=='mapping_root': cards=mutate(cards,c)
    elif regime in ['coherent_raw_file','raw_file_only']:
        rows[identity]=mutate(rows[identity],c)
        if regime=='coherent_raw_file': cards=deepcopy(rows);card=cards[identity]
    elif regime=='bad_raw_file':
        op=c['op']
        if op=='missing_identity': del rows[identity]
        elif op=='nonrow_identity': rows[identity]=None
        elif op=='array_member': rows[identity]=[]
        elif op=='null_json': rows=None
        elif op=='list_json': rows=[]
    return card,cards,rows
def compile_model(card,cards,rows,c):
    if not isinstance(card,dict) or card.get('id') not in IDS: return None
    if c['regime']=='bad_proof': return None
    if c['regime']=='bad_raw_file':
        if c['op']=='missing_raw': raise FileNotFoundError()
        if c['op']=='malformed_json': raise json.JSONDecodeError('','',0)
    if any(cards.get(i)!=rows[i] for i in IDS): return None
    return {k:deepcopy(v) for k,v in EXPECTED[card['id']].items() if k not in ('id','supported','coverage_text_sha256')}
def outcome(fn):
    try: return fn(),None
    except Exception as e: return None,type(e).__name__

computed=[]
for c,p,g in zip(cases,py['results'],godot['results']):
    card,cards,rows=inputs_for(c)
    result,error=outcome(lambda:compile_model(card,cards,rows,c))
    assert (result is not None,error)==(p['original_accept'],p['original_error']),c['label']
    out,calls={},[]
    def model_hook():
        for identity in IDS:
            out.pop(identity,None)
            current=cards.get(identity)
            calls.append({'row_id':current.get('id') if isinstance(current,dict) else None,'loop_key':identity,'card_is_exact_current_key_value':True})
            compiled=compile_model(current,cards,rows,c)
            if compiled is not None:
                meta={k:v for k,v in compiled.items() if k not in ('effects','keywords','coverage_rule')}
                out[current['id']]={'id':current['id'],'supported':True,'effects':compiled['effects'],'keywords':compiled['keywords'],'coverage_rule':compiled['coverage_rule'],'coverage_text_sha256':hashlib.sha256(current['text'].encode()).hexdigest(),'default_pool':False,**meta}
    _,hook_error=outcome(model_hook)
    assert (sorted(out),hook_error,calls)==(p['exact_hook_accepted_ids'],p['exact_hook_error'],p['exact_hook_calls']),c['label']
    assert same_json(out,p['exact_hook_outputs']),c['label']
    # File-only and bad-file/proof regimes have no corresponding GD in-memory mutation.
    gdcard,gdcards=card,cards
    if c['regime'] in ['raw_file_only','bad_raw_file','bad_proof']: gdcard,gdcards=deepcopy(RAW[c['identity']]),deepcopy(RAW)
    issue=None
    if isinstance(gdcards,dict) and len(out)==len(IDS) and hook_error is None:
        compiled=deepcopy(gdcards)
        for i,v in out.items():
            if isinstance(compiled.get(i),dict): compiled[i].update(v)
        issue=closure(compiled)
    accepted=strict(gdcard,gdcards)
    assert (raw_ok(gdcard),accepted,issue)==(g['actual_supplied_card_raw_gate_accept'],g['strict_ingress_accept'],g['actual_hook_output_closure_error']),c['label']
    computed.append({'label':c['label'],'regime':c['regime'],'original_accept':result is not None,'original_error':error,'hook_error':hook_error,'strict_accept':accepted,'closure_error':issue})
check('all_262_python_and_hook_records_match_independent_model',True)
check('all_262_gd_records_match_source_semantics_model',True)
by_regime={}
for regime in sorted({c['regime'] for c in cases}):
    rr=[r for r in computed if r['regime']==regime]
    a={'cases':len(rr),'accepts':sum(r['original_accept'] for r in rr),'exceptions':sum(r['original_error'] is not None for r in rr),'hook_exceptions':sum(r['hook_error'] is not None for r in rr)}
    b={'cases':len(rr),'full_hook_outputs':sum(r['closure_error'] is not None for r in rr),'hook_output_closure_reject':sum(bool(r['closure_error']) for r in rr),'original_accept':a['accepts'],'original_accept_gd_reject':sum(r['original_accept'] and not r['strict_accept'] for r in rr),'original_exception':a['exceptions'],'strict_ingress_accept':sum(r['strict_accept'] for r in rr)}
    check('recomputed_counts:'+regime,a==py['by_regime'][regime] and b==godot['counts'][regime])
    by_regime[regime]=b
for s in godot['structural_probes']:
    d={i:{**deepcopy(RAW[i]),**deepcopy(EXPECTED[i])} for i in IDS};op=s['case']
    if op in ['swap_rows','duplicate_normal','duplicate_golden','extra_unrelated']: d=mutate(d,{'op':op,'path':[]})
    elif op.startswith('missing_'): del d[IDS[0 if op=='missing_normal' else 1]]
    elif op=='both_pool_blockers':
        for i in IDS: d[i]['pool_blocker']=pool_reason
    elif op=='invalid_pool_blocker': d[IDS[0]]['pool_blocker']='wrong'
    elif op=='projection_fields': d[IDS[0]]['source_shop_fields']={'tier':7,'cost':None,'pool_supported':False}
    elif op=='unsupported': d[IDS[0]]['supported']=False
    elif op=='extra_field': d[IDS[0]]['extra']=True
    issue=closure(d)
    check('structural_model:'+op,issue==s['closure_error'] and (not issue)==s['accepted'])
check('effect_probe_counts',len(godot['effect_probes'])==12 and sum(p['accepted'] for p in godot['effect_probes'])==2)
check('unit_probe_counts',len(godot['unit_probes'])==20 and sum(p['accepted'] for p in godot['unit_probes'])==6)
runs=jread(P/'GODOT_RUNS.json')
check('two_successful_recorded_godot_runs',len(runs)==2 and all(r['exit_code']==0 and r['stopped'] is None for r in runs))
check('recorded_stderr_empty',all(read(P/f'GODOT_{k}.stderr.log')==b'' for k in ['first','repeat']))
check('logs_report_262_zero_failures',all(b'Cases 262; failures 0;' in read(P/f'GODOT_{k}.stdout.log') for k in ['first','repeat']))
check('partial_flags_preserved',all(e['default_pool'] is False and e['pool_supported'] is False and e['implementation_status']=='partial_implementation_pending_unified_validation' for e in EXPECTED.values()))
bool_rows=[(c,p,g) for c,p,g in zip(cases,py['results'],godot['results']) if c['regime'] in ['coupled','companion'] and c['op'] in ['bool_to_int','bool_to_float']]
bool_maps={json.dumps(inputs_for(c)[1],sort_keys=True,ensure_ascii=False) for c,p,g in bool_rows}
bool_units={'test_cases':len(bool_rows),'unique_corrupted_maps':len(bool_maps),'actual_hook_compile_invocations':sum(len(p['exact_hook_calls']) for c,p,g in bool_rows),'closure_rejections':sum(bool(g['actual_hook_output_closure_error']) for c,p,g in bool_rows)}
check('bool_alias_units_are_not_interchangeable',bool_units=={'test_cases':48,'unique_corrupted_maps':24,'actual_hook_compile_invocations':96,'closure_rejections':40})
coherent=[(c,p,g) for c,p,g in zip(cases,py['results'],godot['results']) if c['regime']=='coherent_raw_file']
check('only_supported_overlay_normalizes_coherent_cases',len(coherent)==14 and all(p['original_accept'] for c,p,g in coherent) and [(c['identity'],c['path'],c['op']) for c,p,g in coherent if g['actual_hook_output_closure_error']=='']==[(i,['supported'],'bool_to_int') for i in IDS])
check('static_unclaimed_supported_rows_not_rejected_by_closure_model',closure({i:{'id':'unrelated','supported':True} for i in IDS})=='')
# Supplement: inspect the parent's separate portable rerun; do not rerun it.
Q=BASE/'elistra_portable_replay_20261110T020700Z'
replay_inputs=jread(P/'REPLAY_INPUTS.json')
check('portable_replay_29_inputs',len(replay_inputs)==29)
for rel,pin in replay_inputs.items():
    original,portable=read(P/rel),read(Q/rel)
    check('portable_input_pin:'+rel,original==portable and hashlib.sha256(portable).hexdigest()==pin['sha256'] and len(portable)==pin['bytes'])
replay=jread(Q/'REPLAY_RESULT.json')
for rel in replay['byte_equal_outputs']: check('portable_output_equal:'+rel,read(P/rel)==read(Q/rel))
for rel in ['PYTHON_REPORT.json','VERIFIED_RESULTS.json']:
    a,b=jread(P/rel),jread(Q/rel)
    a.pop('max_rss_kib');b.pop('max_rss_kib')
    check('portable_output_equal_except_peak:'+rel,a==b)
portable_runs=jread(Q/'GODOT_RUNS.json')
check('portable_two_successful_recorded_godot_runs',len(portable_runs)==2 and all(r['exit_code']==0 and r['stopped'] is None for r in portable_runs))
for rel in ['test_original.py.stderr.log','run_godot.py.stderr.log','verify_results.py.stderr.log']: check('portable_stderr_empty:'+rel,read(Q/rel)==b'')
check('read_inputs_unchanged',all(hashlib.sha256((BASE/rel).read_bytes()).hexdigest()==pin['sha256'] for rel,pin in inputs.items()))
report={'status':'pass_with_explicit_scope_limits','method':'Independent Python static verification and independent semantic models; no historical scripts, Godot, full driver, Game, Combat, Catalog, host, save or network executed.',
        'source_probe':str(P.relative_to(BASE)),'input_count':len(inputs),'checks_passed':len(checks),'checks':checks,'case_count':262,'by_regime':by_regime,
        'total_original_accept':sum(r['original_accept'] for r in computed),'total_original_exceptions':sum(r['original_error'] is not None for r in computed),
        'total_strict_ingress_accept':sum(r['strict_accept'] for r in computed),'total_original_accept_gd_reject':sum(r['original_accept'] and not r['strict_accept'] for r in computed),
        'gd_dependency_scripts':sorted(dependencies),'structural_probes':godot['structural_probes'],'effect_probe_count':12,'unit_probe_count':20,'bool_alias_statistic_units':bool_units,
        'additional_static_only_probe':{'unclaimed_supported_rows_can_pass_closure_by_source_semantics':True,'not_part_of_recorded_godot_cases':True},
        'portable_replay_evidence_verified':True,'portable_recorded_godot_runs':portable_runs,
        'original_reported_godot_runs':runs,'original_godot_version':godot['godot_version'],'max_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
        'raw_file_proof_omission_confirmed':True,'game_reachability_established':False,'independent_godot_rerun':False,'all_read_inputs_hash_unchanged':True}
(HERE/'INPUT_PINS.json').write_text(json.dumps(inputs,indent=2)+'\n')
(HERE/'RESULTS.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:report[k] for k in ['status','checks_passed','case_count','input_count','max_rss_kib','total_original_accept','total_original_exceptions','total_strict_ingress_accept','total_original_accept_gd_reject']},indent=2))
