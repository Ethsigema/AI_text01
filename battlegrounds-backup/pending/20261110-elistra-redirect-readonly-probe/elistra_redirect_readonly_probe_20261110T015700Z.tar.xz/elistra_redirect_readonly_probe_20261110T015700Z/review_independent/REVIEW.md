# Elistra 小测试证据独立审查

## 结论

现有证据准确支持“历史源编译器与真实 emit/hook 的有界探针发现若干输入契约差异”。没有发现这批已记录结果与所检源代码相矛盾，也没有证据证明差异在真实游戏入口可达。应保留延期安装、延期统一验收的结论。

本审查没有执行原测试脚本、历史驱动、Godot、Game、Combat、Catalog、host 或存档流程；没有联网。只在独立审查目录写入文件，以 Python 静态解析和独立语义模型交叉核验已记录结果。127 项断言通过，103 个实际读取输入已记录 SHA-256；128 MiB 地址空间硬上限下峰值约 64 MiB。原证据与历史树没有被修改。

## 源码与探针忠实性

- 14 个历史输入与原探针复制件、INPUT_PINS.json、历史 SOURCE_MAP.json 一致；复制件不是相同 inode。这里验证的是所提供本地快照，不是远端仓库或当前分支。
- 历史 elistra_redirect_patterns.py 的原 compile_card 逻辑、常量与 PROOF_SHA256 已解析核对。原 test_original.py 执行的是该原模块，显式把 root 指向隔离 fixture，而不是另写的修正版。
- 原 test_original.py 从候选 build_effect_catalog.py 抽出真实 emit（第 559 行）、真实 Elistra for-hook（3275–3281 行）及紧邻排序节点（3282–3283 行）；DRIVER_EXACT_FRAGMENTS.py 与这些源片段逐字一致。没有运行完整驱动及其先前处理流程。
- 真 hook 直接执行 c=cards.get(identity)，再把同一对象和同一 cards 传入 compile_elistra_redirect。262 记录的调用轨迹与这一事实一致。detached 参数并不是这个 hook 的输入路径。
- gd_minimal 的项目依赖恰为 3 个未经修改的原 GD：elistra_redirect_sources.gd、phase_undead_army_sources.gd、pool_identity.gd。另有 1 个自写 gate.gd 测试夹具。不能把“三个项目依赖”写成“总共只有三个 GD 文件”。
- gate.gd 真实调用原 raw_source_error/source_error/closure_error/effect_error/unit_error。ProbeCatalog 是最小 get_card 字典接口，不是生产 Catalog。RUNTIME_PATHS 只是常量中的路径列表，不代表这些脚本被加载运行。

## 262 例核验结果

逐条核对所有 case label、Python 接受/异常、hook 调用与完整输出、GD raw gate/strict_ingress/实际 hook 输出闭包结果，均与独立源语义模型一致。原报告汇总可从逐条记录重算。

| 组 | 例数 | 原 Python 接受 | 原 Python 异常 | 完整 hook 输出例 | 其闭包拒绝例 |
|---|---:|---:|---:|---:|---:|
| detached | 66 | 56 | 0 | 66 | 0 |
| coupled | 58 | 32 | 0 | 32 | 20 |
| companion | 58 | 32 | 0 | 32 | 20 |
| mapping_root | 26 | 4 | 8 | 4 | 0 |
| coherent_raw_file | 14 | 14 | 0 | 14 | 12 |
| raw_file_only | 14 | 4 | 0 | 4 | 0 |
| bad_raw_file | 14 | 0 | 10 | 0 | 0 |
| bad_proof | 12 | 0 | 0 | 0 | 0 |

总计原 Python 142 接受、18 异常；诊断 strict_ingress 68 接受；原 Python 接受而该诊断拒绝的情况 110 个。110 不是 110 个真实运行时漏洞：其中 detached 差异 48 个，实际 hook 始终使用未污染的 canonical map，闭包全部通过。

coupled/companion 的布尔换数值测试共 48 个 case，对应 24 个唯一污染 map；每 case 的真实 hook 调用两次编译器，因此是 96 次 hook 编译调用。40 是闭包评估拒绝的 case 数。VERIFIED_RESULTS.json 中带 calls 的统计字段应在文字中注明具体单位，不能把这些数互换。

除 262 例矩阵外，原 Godot 记录还包含 12 个结构探针、12 个 effect 探针、20 个 unit 探针。结构探针已独立建模核对；effect/unit 探针已检查源语义和记录，数量/接受数分别为 12/2、20/6，但本审查没有重跑 Godot。

## 关键事实与解释边界

### 1. raw_rows.json 未被原编译器的 PROOF_SHA256 直接绑定

PROOF_SHA256 只有原生 manifest 和两份 XML。compile_card 读 raw_rows.json，但只比较 cards[key] 与该文件内容，不把它与固定 RAW 常量比对。该缺口由源码和原实测同时支持，不是因为本审查改写了编译器。

14 个 coherent_raw_file case 同时改动 fixture raw 文件与调用 map，包括 text、attack、删 tier、cost=null→false、额外字段、supported=false→0、is_golden→数值。原编译器 14/14 接受，原真实 hook 14/14 产出两身份。

不能据此写“全部 14 个错误编译结果穿透闭包”：实际 emit 后再与实际 hook map 合并，闭包拒绝 12/14。另 2 例是 supported=false→0，emit 把 supported 覆盖成 true，合并结果与原编译源一致，闭包通过。text 变异会影响真实 emit 的 coverage_text_sha256，并非把 EXPECTED 原封不动塞入结果。

raw_file_only 的 4 次接受来自 Python 把 false/0、true/1 当作相等；它们不意味着所有 raw 文件变化都会接受。

### 2. strict_ingress 是自写诊断组合，不是项目入口

gate.gd 的注释和结果元数据对此表述正确。它拼接原 GD raw_source_error 与“每个 map key 必须等于行内 id”的额外约束。closure_error 并不实施后一约束。

bad_proof、bad_raw_file、raw_file_only 的 GD 内存参数仍为原始 RAW，未重现对应磁盘损坏。所以这些组的 strict_ingress 接受只说明内存诊断通过，不代表 GD 验证了或漏过了那些文件。原 Python 对 malformed/missing raw 的异常也应保留为异常，不能归为干净拒绝。

### 3. 闭包 key/inline-id 差异

原闭包只对 get_card(key) 的返回行按它自己的 inline id 调用 source_error，再检查 supported。已记录的结构探针确认：交换两原生行、重复 normal、重复 golden 均可通过；缺行、错误 blocker、额外字段等反例被拒绝。

同样的交换/重复发生在 Python 原始 mapping_root 输入时会因不等于 raw_rows.json 而拒绝。这是不同入口契约的差异，不能拿结构探针的接受代替“真实 hook 接受了交换 map”。

补充的静态推论：closure_error 也没有明确要求返回行必须属于 Elistra。无 Elistra id/card_id/effect claim、仅 supported=true 的无关行会被 source_error 当作不适用而放行，随后通过 supported 检查。因此按这段源码，两个 key 均返回例如 {id: unrelated, supported: true} 也能通过。该反例只做静态语义断言，没有纳入原 12 个结构 Godot 实测，也没有证明实际 Catalog 会返回这样的行。不能包装成已实测的游戏漏洞。

### 4. 正反例覆盖的正确用途

- canonical 与数值 int/float 等价性是正例；bool/int 混同是 Python 与 GD 精确比较的差异，不应把合法数值等价也列为缺陷。
- proof 缺失/变动 12 例全部拒绝，说明现有三个 proof 检查有效，不说明 raw 文件也受该 hash 绑定。
- 原 effect_gate 会拒绝多字段、缺 source、错 type/source 与 null；unit 例验证 native、干净 base buff 及部分非法 base/program 等情况。这些不是全输入域的充分验证。
- default_pool=false、pool_supported=false、partial_implementation_pending_unified_validation 在原输出中保留。任何通过数不支持改成已安装或完整支持。

## 两次记录与便携重放

原 GODOT_first.json 与 GODOT_repeat.json 逐字相同，两个已记录进程 exit=0，stderr 空，报告 failures=[]。日志记录 Godot 4.6.3；这是记录的版本，不是本审查新启动的版本。

后续 elistra_portable_replay_20261110T020700Z 的 29 个白名单输入与原探针逐字及 hash 一致；8 个声明可逐字比较的输出已逐字重核；PYTHON_REPORT.json 和 VERIFIED_RESULTS.json 只剔除 max_rss_kib 后一致；其两次 Godot 已记录运行也成功。便携重放是父任务已有的执行证据，本审查只读取核验，未再次启动。

## 未证明的事项

未运行完整驱动的前置/后置流程、生产 Catalog 构建与读取、Game、Combat、host、factory、真实输入恢复链路或存档；未证明异样 map/文件在真实入口可达；未验证实际攻击重定向、RNG/UID/伤害/复生流程；未安装工具或修复代码；未确认官方当前卡池/轮换。固定片段、最小接口和手造结构测试不能替代这些验证。

## 审查包与复核

INPUT_PINS.json 是实际读取的 103 个输入的精确白名单及 SHA-256。RESULTS.json 为机器可读结果，review.py 为独立审查脚本，RUN.stdout.log/RUN.stderr.log 为本次审查运行日志。MANIFEST.json 仅允许这 6 个产物及 manifest 自身；不包含输入大副本、缓存、私聊、凭据、旧存档或隐含目录打包。

重新执行：python review.py --workspace /path/to/workspace。workspace 须包含脚本指定的历史树、原探针、便携重放三个目录；所有输出仍只写到 review.py 所在目录。脚本不会运行这些输入中的代码。
