extends RefCounted
## Ordinary eligibility is separate from executable effects and explicit sandbox stock.
const MINION_REASON:String="没有已确认的普通商店随从资格；衍生物、伙伴或时空扭曲内容需由对应机制生成，或显式配置自定义入店参数。"
const SPELL_REASON:String="没有已确认的普通酒馆法术池资格；保留原法术身份，可由对应机制生成，或显式配置自定义入店参数。"
static func _historical(card:Dictionary,seasons:Array,key:String)->bool:
	for preset in seasons:
		if card.get("id","") in preset.get(key,[]):return true
	return false
static func special_source(card:Dictionary)->bool:
	var status:String=str(card.get("fields",{}).get("status",""))
	if "衍生" in status or "英雄专属" in status or "机制限定" in status:return true
	if card.get("category","") in ["衍生物","伙伴","英雄专属"]:return true
	if card.get("fields",{}).get("timewarped") == "是":return true
	for mechanism in card.get("mechanisms",[]):
		if mechanism in ["时空扭曲","暗月奖品","伙伴","英雄专属","衍生物"]:return true
	return false
static func minion_identity(card:Dictionary,seasons:Array)->bool:
	if card.get("kind","")!="minion" or card.get("is_golden",false) or card.get("excluded",false) or not card.get("solo_eligible",true):return false
	if _historical(card,seasons,"minion_ids"):return true
	if special_source(card):return false
	return card.get("category","")=="随从"
static func spell_identity(card:Dictionary,seasons:Array)->bool:
	if card.get("kind","")!="spell" or card.get("excluded",false) or not card.get("solo_eligible",true):return false
	var tavern:bool=card.get("category","") in ["酒馆","酒馆法术"]
	for category in card.get("categories",[]):tavern=tavern or category in ["酒馆","酒馆法术"]
	if not tavern:return false
	if _historical(card,seasons,"spell_ids"):return true
	if special_source(card):return false
	return card.get("fields",{}).get("status","")=="常规池"
