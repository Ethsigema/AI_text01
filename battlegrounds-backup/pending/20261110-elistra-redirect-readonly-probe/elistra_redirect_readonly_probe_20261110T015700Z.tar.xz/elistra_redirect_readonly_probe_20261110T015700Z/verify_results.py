from pathlib import Path
import json,hashlib,resource,collections,xml.etree.ElementTree as ET
resource.setrlimit(resource.RLIMIT_AS,(128*1024**2,128*1024**2))
H=Path(__file__).resolve().parent;F='research/elistra_redirect_native_recovery/'
cases=json.loads((H/'CASES.json').read_text());py=json.loads((H/'PYTHON_REPORT.json').read_text());g=json.loads((H/'GODOT_first.json').read_text());g2=json.loads((H/'GODOT_repeat.json').read_text());assert g==g2 and not g['failures']
assert len(cases)==len(py['results'])==len(g['results'])==262
assert all(a['label']==b['label']==c['label'] for a,b,c in zip(cases,py['results'],g['results']))
assert py['input_unchanged_all_cases'] and py['independent_fixtures_reset_to_original']
expected={'bad_proof':(12,0,0,0,0),'bad_raw_file':(14,0,10,0,0),'coherent_raw_file':(14,14,0,14,12),'companion':(58,32,0,32,20),'coupled':(58,32,0,32,20),'detached':(66,56,0,66,0),'mapping_root':(26,4,8,4,0),'raw_file_only':(14,4,0,4,0)}
for k,v in expected.items():
 c=g['counts'][k];assert tuple(c[x] for x in ['cases','original_accept','original_exception','full_hook_outputs','hook_output_closure_reject'])==v
for r in py['results']:
 assert all(c['card_is_exact_current_key_value'] for c in r['exact_hook_calls'])
 if r['exact_hook_accepted_ids']:assert set(r['exact_hook_accepted_ids'])=={'BGS_205','TB_BaconUps_306'}
assert all(x['accepted']==(x['case'] in ['canonical','swap_rows','duplicate_normal','duplicate_golden','both_pool_blockers','extra_unrelated']) for x in g['structural_probes'])
assert len(g['effect_probes'])==12 and sum(x['accepted'] for x in g['effect_probes'])==2
assert len(g['unit_probes'])==20 and sum(x['accepted'] for x in g['unit_probes'])==6
for run in ['first','repeat']:
 assert not (H/f'GODOT_{run}.stderr.log').read_bytes()
for rel,pin in json.loads((H/'INPUT_PINS.json').read_text()).items():
 b=(H/'original_inputs'/rel).read_bytes();assert len(b)==pin['bytes'] and hashlib.sha256(b).hexdigest()==pin['sha256']
for rel in [F+'native_source_manifest.json',F+'native/BGS_205.xml',F+'native/TB_BaconUps_306.xml',F+'raw_rows.json']:
 assert (H/'fixture_root'/rel).read_bytes()==(H/'original_inputs'/rel).read_bytes()
manifest=json.loads((H/'original_inputs'/F/'native_source_manifest.json').read_text());native=[]
for i in ['BGS_205','TB_BaconUps_306']:
 root=ET.fromstring((H/'original_inputs'/F/f'native/{i}.xml').read_bytes());tags={x.get('name'):x for x in root.findall('Tag')};e=manifest['entities'][i]
 assert root.get('CardID')==i and root.get('ID')==e['dbf_id']
 for k,v in e['native_tags'].items():assert (tags[k].get('value') if k in tags else None)==v
 for k,v in e['pair_tag'].items():assert tags[k].get('value')==v
 assert 'COST' not in tags and 'CARDRACE' not in tags and 'TAUNT' not in tags
 assert any(x.get('name')=='TAUNT' for x in root.findall('ReferencedTag'))
 for language in ['enUS','zhCN']:assert tags['CARDTEXT'].find(language).text==e[language]
 native.append({'id':i,'dbf_id':e['dbf_id'],'build_manifest_claim':manifest['build'],'native_tags_pair_text_match':True,'direct_taunt':False,'reference_taunt':True,'no_current_rotation_claim':True})
summary={'status':'BOUNDED_SOURCE_PROBE_VERIFIED_DEFER_INSTALL','case_count':262,'original_accepts':sum(x['original_accept'] for x in py['results']),'original_exceptions':sum(x['original_error'] is not None for x in py['results']),'accept_vs_composed_raw_diagnostic_differences':sum(x['original_accept_gd_reject'] for x in g['counts'].values()),'detached_not_actual_hook_body_difference':g['counts']['detached']['original_accept_gd_reject'],'real_hook_shaped_bool_alias_calls':48,'unique_corrupted_maps_bool_alias':24,'bool_alias_closure_reject_calls':40,'coherent_raw_file_changed_calls':14,'coherent_raw_closure_reject_calls':12,'coherent_raw_supported_overlay_normalizes_calls':2,'structure_cases':12,'effect_cases':12,'unit_cases':20,'native_inputs':native,'godot_reports_byte_equal':(H/'GODOT_first.json').read_bytes()==(H/'GODOT_repeat.json').read_bytes(),'actual_game_reachability_proven':False,'full_driver_run':False,'new_correction_created':False,'installed':False,'max_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
(H/'VERIFIED_RESULTS.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n');print(json.dumps(summary,ensure_ascii=False,indent=2))
