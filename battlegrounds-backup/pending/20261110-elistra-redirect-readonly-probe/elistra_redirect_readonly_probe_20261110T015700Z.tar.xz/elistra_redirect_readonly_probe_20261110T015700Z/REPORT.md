# 艾丽斯特拉工具缺口：历史原件与当前 GD 有限契约审查

## 决定

继续暂缓安装。本轮只增加可复查的来源与差异证据，没有改原树、修正历史工具、修复整包补丁，或创建新修正候选。当前 345 项工具缺口仍全部缺失，艾丽斯特拉属于这个范围。

历史整本和当前 GD 来源能够明确对应，但运行时校验契约不同；当前完整编译驱动及依赖未闭合。小测试不能升级为真实 Game、旧存档或完整游戏验收。

## 强来源与不能混淆的版本限制

- 历史工具 `tools/elistra_redirect_patterns.py`：5771 bytes，SHA256 `94f4398484c99accb054bc125f896317aa2b3e611d702119ca14d3e5a37ecefa`。整本、manifest after pin、SOURCE_MAP 和精确新增片段一致。
- 当前 GD `core/elistra_redirect_sources.gd`：19934 bytes，SHA256 `1ba1f47dcf21e814476fd634bf143a0e36eede3956399fb78ee377e86ca4199d`，与历史候选逐字节相同。RAW、EXPECTED、PROGRAMS 与封存 JSON 一致。
- `raw_rows.json` 有历史封存 pin：13826 bytes，SHA256 `e94544aeae79ae363083b3cee4d9cb84ccb89811a56e60edda869d755a0dea5a`。问题是 compile_card 没有消费这个 pin，不是来源哈希不存在。
- 工具只在运行时核验 native manifest 和两份 XML 三个哈希。两份实体的 ID/DBF、T7、8/8与16/16、直接圣盾/复生、嘲讽仅 ReferencedTag、无直接 COST/race及独立中英文本均符合保存 manifest。build225000、上游 commit 和完整响应 hash 是保存元数据，本次未联网重新取得完整上游响应，未认定当前轮换。
- 历史 driver 精确前后像为 f73a4864… → 260f3d719…，仅能证明该历史候选。当前 driver 缺失，不能将这个 pin 当成当前整合版本。
- 整包 candidate.patch SHA256 `dda35c4a77318f8b8d7260b133d68747cd00ddd93524e974e890668ec2f2d246` 与 manifest 一致，但第605和686行有 XML 尾部未换行造成的文件头粘连。工具、GD及driver的选定片段已在内存中精确重构；整包不能直接视为可应用补丁。原补丁保留不改。

## 实际执行边界

Python 只执行了审读后的原工具和历史 driver 的四个精确 AST 节点：emit（559行）、Elistra循环（3275–3281行）、ordered_ids 两步（3282–3283行）。没有导入完整 driver。显式 root 指向独立 fixture_root，三份proof与raw_rows都是普通副本，每例后最终复原并核对。

真实 hook 使用 cards.get(identity) 取同一映射中的行传给 compile_card；其返回 overlay 不含 id、supported、coverage_text_sha256。真实 emit 用 c.id 写 key 和行内id，supported=True，覆盖文本hash来自 c.text。测试保留了这些行为，没有用常量输出替代 emit，也没有让 detached 伪造样例冒充该 hook 可达。

GD 只载入当前实际 ElistraSources、Exact（phase_undead_army_sources.gd）和 PoolIdentity 三个源文件，使用最小 get_card 接口。实际 raw_source_error、source_error、closure_error、effect_error、unit_error均按原字节运行。诊断 strict_ingress 是“实际逐行raw gate + 指定key/id契约”的组合，不是项目内单一入口，且并非closure_error所保证的映射不变量。

## 262 个小样例的结果

每轮含262项入口/文件变异、12项结构、12项effect、20项unit，共306个编号样例。原始报告给出每例具体错误，不能用总数当作完整覆盖率。

- Python原工具接受142项，18项抛出异常。异常分为8项非法cards根类型、10项缺失/坏raw文件，不算拒绝返回或成功。三份proof的改变/删除共12项均返回None且hook无输出。
- detached 66项：56项原工具接受，48项不符合诊断raw契约。真实 hook 仍使用未改映射，因此这66项的实际hook输出均规范且闭包接受。不能将这48项差异说成真实hook缺陷已经可达。
- coupled 与 companion 各58项：各32项原工具接受，各24项bool/数值别名不符合实际GD raw契约。合计48个测试case对应24个唯一坏映射；其中40次闭包评估拒绝真实emit后的结果，8次supported变异被emit覆盖规范化。每个case的真实hook遍历两个身份，这48个case实际包含96次compile调用，不能把case数当成hook调用数。当前GD没有因此被弱化。
- coherent_raw_file 14项：在独立副本里同步改变raw_rows和输入映射，保留三个proof不变，原工具及真实hook全部接受；实际GD raw校验全部拒绝。12项在emit合并后仍被闭包拒绝，2项supported变异被覆盖。改变涵盖文本、攻击、缺tier、cost、额外字段、supported/is_golden数值化。这证明编译函数没有验证既有raw pin，但不证明真实运行输入曾被这样改变。
- raw_file_only 14项：实际GD输入保持原样，只有独立文件变化。4项布尔/数值相等变化被Python接受，另外10项返回None。GD不在这个函数内读proof文件，因此这里不把文件错误误称为GD校验缺陷。
- mapping_root 26项：4项规范/额外无关项接受；8项根类型错误抛异常；交换/重复/丢失来源等其余输入未产生双行成功输出。

bool与数值差异来自Python普通结构相等；GD Exact.same区分bool和数值，只对int/float允许数值相等。canonical和相等float等正例保留，没有把数值表达方式变化一概当坏输入。

## 结构、effect和unit正反例

实际closure_error接受规范双行、合法pool_blocker和额外无关行。同时也接受交换两行、重复普通行、重复金色行三个结构反例：它逐行按行内id验证，不检查查询key等于行内id。这个独立最小接口结果不意味着真实Catalog构建能产生同样映射。独立审查另指出静态函数没有明确要求get_card结果属于Elistra：非claimed行可能通过source_error，再仅检查supported。该补充未作为本轮Godot动态样例，不能视为已运行或真实游戏可达。

错误pool_blocker、缺失来源、额外字段、未支持标记和外加投影字段在本探针中拒绝。effect 12项仅2个规范程序通过。unit 20项中6项通过：每个来源的规范unit、等值float tier、带干净原生base的buff unit；无base直接buff、改坏base、嵌套base、错身份/程序/tier均拒绝。它们验证的是原函数，不执行战斗重定向、伤害、死亡/复生或工厂全过程。

## 当前来源与真实流程尚未闭合

静态独立复核确认：当前11份driver输入JSON中只有catalog_raw包含这两行，内容匹配封存RAW；当前catalog.json两行匹配EXPECTED。Catalog及工厂有来源/闭包guard，但没有运行这些入口。

保存driver里有846个整个cards参数静态调用点，其中339个位于Elistra前；直接模块本地检查有789项缺失，包括前置QuestIdentity/HeroValues。这不是执行次数或完整传递依赖分析；789按这个历史driver直接模块检查，口径不同于当前345项恢复范围，不是新增345之外任务。前序变换、其他hook后续改写、真实Catalog加载结果和整条运行可达性仍未证实。

Elistra RUNTIME_PATHS包含缺失Python工具与raw/proof文件，Catalog将内容hash纳入execution_fingerprint。任何以后新增工具或修正都需另核对执行身份及旧存档边界，本轮不计算完整fingerprint、不绕过检查、不读旧存档，也不保证兼容。

## 重复性、资源与原件保护

首次Godot两轮结果逐字节一致。另以29个显式白名单输入建立全新便携目录，重跑原Python、两轮Godot和验证脚本，8个结果/日志逐字节一致；Python结果仅排除实测内存峰值后相同。四次Godot每次不到1秒、峰值约69–71MiB，均未出现脚本错误。无完整Godot项目扫描，无Game/Combat/完整Catalog/完整driver执行。

Python测试和核验脚本限制128MiB地址空间；Godot2GiB地址空间、RSS192MiB/45秒停止阈值，运行前MemAvailable至少1GiB，运行时低于640MiB停止。HOME/XDG独立；缓存、凭据、私聊、旧存档和isolated目录不入白名单包。没有网络调用或重试已取消下载。

末尾重算14项选定原始输入与副本、四项运行时边界文件、SOURCE_MAP、29个重放输入和12份旧归档，均保持原值；另有独立静态审查34项输入的复核；独立证据评审127项断言通过，103项实际读取输入已固定哈希，未再次运行Godot。此结论不是重新hash完整27920项源码树。XML候选仍未安装，四份全局原核验证据和两份全局合同仍未找到，家族材料不替代它们。

## 安全下一步

本包只封存原件、测试与差异证据，不作安装候选。以后如有明确新修正任务，可单独研究如何消费已封存raw pin、区分bool/数值、保证输入card/map契约和明确坏文件行为；必须保留历史原件并注明新修正、非原样恢复或最新版。完整驱动和依赖未闭合前仍不安装，不通过放宽GD使历史工具显得一致。

证据入口：VERIFIED_RESULTS.json、PYTHON_REPORT.json、GODOT_first.json；static_contract/REPORT.md及精确片段；review_independent/的独立复核；FINAL_VERIFICATION.json；REPLAY_INPUTS.json和replay_to_new.py。重放只应指向新目录，不在已封存目录内直接运行会覆盖输出的脚本。
