from pathlib import Path
import difflib
root=Path(__file__).resolve().parents[2]
out=Path(__file__).parent/'patches'
def save(name,before,after):
 (out/(name.replace('/','__')+'.patch')).write_text(''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='a/'+name,tofile='b/'+name)))
name='core/spellteach_murloc_sources.gd';before=(root/name).read_text();after=before
old='''		if id!=CHILD or not fields(row,["uid","owner","source_id","source_uid","purchased_uid","spell_id","round","sequence","spell_program"]) or row.uid!=unit.uid or row.source_id not in PARENTS or not uid(row.source_uid) or not uid(row.purchased_uid) or not integer(row.owner) or not integer(row.round,1) or not integer(row.sequence,1) or not row.spell_id is String or not row.spell_program is Array: return "spellteach_invalid_actual_purchase_binding"
		if row.uid in [row.source_uid,row.purchased_uid] or row.source_uid==row.purchased_uid: return "spellteach_aliased_purchase_binding"
'''
new='''		if not row is Dictionary: return "spellteach_invalid_actual_purchase_binding"
		if row.get("source_id")=="BG35_MagicItem_750":
			# Owned source is an actual acquired slot, never a fabricated minion UID.
			if id!=CHILD or not fields(row,["uid","owner","source_id","source_slot","acquired_event_index","purchased_uid","spell_id","round","sequence","spell_program"]) or row.uid!=unit.uid or not integer(row.source_slot,0,7) or not integer(row.acquired_event_index) or not uid(row.purchased_uid) or row.uid==row.purchased_uid or not integer(row.owner) or not integer(row.round,1) or not integer(row.sequence,1) or not row.spell_id is String or not row.spell_program is Array: return "spellteach_invalid_owned_purchase_binding"
		else:
			if id!=CHILD or not fields(row,["uid","owner","source_id","source_uid","purchased_uid","spell_id","round","sequence","spell_program"]) or row.uid!=unit.uid or row.source_id not in PARENTS or not uid(row.source_uid) or not uid(row.purchased_uid) or not integer(row.owner) or not integer(row.round,1) or not integer(row.sequence,1) or not row.spell_id is String or not row.spell_program is Array: return "spellteach_invalid_actual_purchase_binding"
			if row.uid in [row.source_uid,row.purchased_uid] or row.source_uid==row.purchased_uid: return "spellteach_aliased_purchase_binding"
'''
after=after.replace(old,new);save(name,before,after)
name='core/spellteach_murloc_host.gd';before=(root/name).read_text();after=before.replace('const POLICY:', 'const Owned=preload("res://core/spellteach_trinket_host.gd")\nconst POLICY:',1)
after=after.replace('\tvar receipts: Dictionary={};var quotas: Dictionary={};var purchases: Dictionary={}', '\tvar owned: Dictionary=Owned.saved_receipts(state,catalog,events)\n\tif not str(owned.error).is_empty(): return str(owned.error)\n\tvar receipts: Dictionary=owned.receipts;var quotas: Dictionary={};var purchases: Dictionary={}',1)
save(name,before,after)
name='core/spellteach_murloc_cast.gd';before=(root/name).read_text();after=before
needle='\tfor leaf in engine.Mechanisms._effects(engine,p)+engine.catalog.get_card(str(p.get("hero_id",""))).get("effects",[]):\n'
after=after.replace(needle,needle+'\t\tif leaf.get("type")=="owned_tavern_spell_purchase_teach_murloc": continue # Purchase-only source, not a spell-cast observer.\n',1)
needle='\tif binding.owner!=p.id: return "spellteach_foreign_taught_owner"\n'
after=after.replace(needle,needle+'\tif binding.get("source_id")=="BG35_MagicItem_750":\n\t\tissue=engine.SpellteachTrinket.Sources.closure_error(engine.catalog)\n\t\tif not issue.is_empty(): return issue\n',1)
save(name,before,after)
name='core/game.gd';before=(root/name).read_text();after=before
# Independent transient capability, included in existing guarded save/load/command paths.
after=after.replace('var _spellteach_buy_context: Dictionary={}', 'const SpellteachTrinket=preload("res://core/spellteach_trinket_host.gd")\nvar _spellteach_trinket_buy_context: Dictionary={}\nvar _spellteach_buy_context: Dictionary={}',1)
after=after.replace('not _spellteach_buy_context.is_empty() or not _spellteach_cast_context.is_empty()', 'not _spellteach_buy_context.is_empty() or not _spellteach_cast_context.is_empty() or not _spellteach_trinket_buy_context.is_empty()')
after=after.replace('_spellteach_buy_context={};_spellteach_cast_context={}', '_spellteach_buy_context={};_spellteach_cast_context={};_spellteach_trinket_buy_context={}')
needle='\tif not spellteach_buy_ticket.ok: return _fail(str(spellteach_buy_ticket.error))\n'
after=after.replace(needle,needle+'\tvar spellteach_trinket_ticket: Dictionary=SpellteachTrinket.prepare_buy(self,p,u,quoted)\n\tif not spellteach_trinket_ticket.ok: return _fail(str(spellteach_trinket_ticket.error))\n',1)
needle='\tif spellteach_buy_ticket.get("active",false) and (health_buy_ticket.active or bought_armor_ticket.get("active",false)): return _fail("spellteach_alternative_currency_or_no_hand_purchase_partial")\n'
after=after.replace(needle,needle+'\tif spellteach_trinket_ticket.get("active",false) and (health_buy_ticket.active or bought_armor_ticket.get("active",false)): return _fail("spellteach_trinket_alternative_currency_or_no_hand_partial")\n',1)
needle='\tif spellteach_buy_ticket.get("active",false): _spellteach_buy_context=spellteach_buy_ticket\n'
after=after.replace(needle,needle+'\tif spellteach_trinket_ticket.get("active",false): _spellteach_trinket_buy_context=spellteach_trinket_ticket\n',1)
needle='\tif not spellteach_paid_issue.is_empty(): return _fail(spellteach_paid_issue)\n'
after=after.replace(needle,needle+'\tvar spellteach_trinket_paid_issue: String=SpellteachTrinket.paid(self,p,u,cost)\n\tif not spellteach_trinket_paid_issue.is_empty(): return _fail(spellteach_trinket_paid_issue)\n',1)
needle='\tvar spellteach_buy_finish_issue: String=Spellteach.finish_buy(self)\n'
after=after.replace(needle,'\tvar spellteach_trinket_finish_issue: String=SpellteachTrinket.finish(self)\n\tif not spellteach_trinket_finish_issue.is_empty(): return _fail(spellteach_trinket_finish_issue)\n'+needle,1)
needle='\t\tvar pen_acquisition_issue: String=WaterloggedPen.acquisition_error(self,p,card)\n'
after=after.replace(needle,'\t\tvar spellteach_trinket_acquisition_issue: String=SpellteachTrinket.acquisition_error(self,p,card)\n\t\tif not spellteach_trinket_acquisition_issue.is_empty(): return _fail(spellteach_trinket_acquisition_issue)\n'+needle,1)
# Enroll in the existing authentic owned event envelope, including acquisition.
after=after.replace('and not WaterloggedPen.has_source(p)', 'and not SpellteachTrinket.has_source(p) and not WaterloggedPen.has_source(p)')
save(name,before,after)
name='core/mechanism_effects.gd';before=(root/name).read_text();after=before
needle='static func on_event(engine, p: Dictionary, event: String, context: Dictionary = {}) -> void:\n'
after=after.replace(needle,needle+'\tif event=="mechanic_acquired" and context.get("source_id")==engine.SpellteachTrinket.Sources.ID:\n\t\tvar owned_teach_issue: String=engine.SpellteachTrinket.acquired(engine,p,context)\n\t\tif not owned_teach_issue.is_empty(): _eot_fail(engine,owned_teach_issue);return\n\tif event=="buy":\n\t\tvar owned_teach_buy_issue: String=engine.SpellteachTrinket.dispatch(engine,p,context)\n\t\tif not owned_teach_buy_issue.is_empty(): _eot_fail(engine,owned_teach_buy_issue);return\n',1)
save(name,before,after)
