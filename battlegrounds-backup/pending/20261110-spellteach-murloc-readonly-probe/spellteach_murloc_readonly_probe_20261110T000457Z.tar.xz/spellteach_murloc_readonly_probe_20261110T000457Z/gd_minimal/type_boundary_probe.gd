extends SceneTree
const Current=preload("res://core/spellteach_murloc_sources.gd")
const Historical=preload("res://historical/spellteach_murloc_sources.gd")
func _init(): call_deferred("_run")
func _run():
	var args: PackedStringArray=OS.get_cmdline_user_args();var label: String=args[0]
	var source_id: Variant=true if label=="bool" else (1 if label=="int" else ([] if label=="array" else null))
	var identity: String=Current.CHILD;var raw: Dictionary=Current.RAW[identity]
	var unit: Dictionary={"card_id":identity,"effects":Current.PROGRAMS[identity].duplicate(true),"kind":"minion","name":raw.name,"golden":raw.is_golden,"tribes":raw.tribes.duplicate(true),"tier":raw.tier,"text":raw.text,"uid":"u101"}
	unit[Current.TAUGHT]={"uid":"u101","owner":0,"source_id":source_id,"source_uid":"u102","purchased_uid":"u103","spell_id":"PROBE_NOT_EXECUTED","round":1,"sequence":1,"spell_program":[]}
	var historical_return: String=Historical.unit_error(unit)
	var current_return: String=Current.unit_error(unit)
	var file=FileAccess.open(args[1],FileAccess.WRITE)
	file.store_string(JSON.stringify({"case":label,"historical_return":historical_return,"current_return":current_return,"return_values_are_not_acceptance_if_stderr_has_script_error":true,"synthetic_unit_only_not_host_or_Game":true},"\t")+"\n");file.close()
	quit(0)
