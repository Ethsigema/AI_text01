# 魔鳍真菌学家与魔鳍学徒：历史工具及当前 GD 的只读定向审查

## 结论

原工具具有相互吻合的历史 manifest、完整创建节和八份运行时 proof pin，原字节可明确识别；但原工具与实际 GD 的输入拒绝域不同，当前 GD 的新增绑定分支还有独立的非法字段类型诊断边界。因此继续暂缓恢复/安装。本轮没有创建修正版本、改原树或更改旧备份。

目标为 `tools/spellteach_murloc_native_patterns.py`，三成员为普通/金色魔鳍真菌学家 BG33_891、BG33_891_G，以及魔鳍学徒 BG33_890t。

- 原工具：23,459 bytes，SHA-256 `72a753e0ec02e8760ee920b1311bca0c58086da49dcd2fd506bf074adf0d1c8f`。
- 历史候选 GD：`465267b111c12f3cba4a18eef1285ed0544340207139953ea57a548dc7072f6e`。
- 当前 GD：`11f8b3b06cc65b484ae379fbeaf825843df0f22d55c1887d23eba152d3b41ca5`。
- 1197主探针中，原工具接受603次，实际GD诊断组合接受363次，240次差异均由布尔/数值普通相等造成。当前真实目标数据没有发现污染。

## 1. 历史来源与补丁边界

原工具的 manifest add 记录、保留文件和原 candidate.patch 中完整工具创建节逐字一致。八份 proof 为三份原生XML、raw_rows.json、programs.json、expected_compiled.json、native_evidence.json、contract.json，历史候选和当前文件均符合原工具固定 SHA。

但原整包 candidate.patch 第837行实际为 `+}--- /dev/null`，data/catalog.json 尾行与家族 contract.json 的旧文件头粘连。工具自身创建节完整，可提取并核pin，不代表整包补丁可以直接应用。本轮没有修补、重写或应用该旧补丁。

历史 manifest 的候选阶段、旧 APPLIED/APPLY_BLOCKED 与 admission/process记录分别原样保留，不将不同阶段拼成当前验收。旧 admission 虽记录 source/syntax 通过，也明确 Game未实例化、效果未执行、gameplay未验收；它不是本轮完整运行证据。

原生XML实体、DBF、名称、攻血、星级、鱼人类型、1/2次配额和共同学徒关联符合本地记录。XML含占位符和标记，RAW是保存的显示文本，不虚称二者原文逐字相同，也不编造学徒实际绑定的法术。

八个proof pin不包含Python/GD/host源码哈希，因此proof全通过不等于执行代码版本已认证。家族contract.json不是仍缺失的两份全局合同，不能拿它填补既有缺口。

## 2. 历史 GD 与当前 GD 的真实变化

RAW、EXPECTED、PROGRAMS、PROOF_SHA256及其余代码均未变化。唯一代码差异是 unit_error 的 TAUGHT 分支新增 BG35_MagicItem_750 饰品来源：使用 source_slot/acquired_event_index，而不是普通/金色父体的 source_uid；保留原父体来源分支。

已存 `research/spellteach_trinket_runtime/patches/core__spellteach_murloc_sources.gd.patch` 精确解释该变化，在内存中可把已核pin历史GD重建为当前GD原字节。该文件和 author_patches.py 另以原字节保存；没有执行作者脚本。该目录没有独立before/after pin manifest，不能把“本地补丁解释一致”升级为完整版本来源或应用验收。

20个合成unit校验探针中，普通父体绑定及1/2配额边界两版行为一致。规范饰品绑定和整值float槽位两例由历史拒绝变为当前允许，与代码变化一致。其余非法槽位、UID、缺失/额外字段、程序不匹配等按预期拒绝。

这些unit使用明确标记的合成法术stub，仅调用unit_error做局部格式/程序比较，没有真实购买、槽位持有、教授、施放或Game操作。单独允许不代表真实流程可达。

### 新增分支的非法字段类型边界

单独追加的实际GD探针把合法父体形状binding的source_id改为 true、整数1、空数组，三类分别重复两次：

- 历史GD正常返回 spellteach_invalid_actual_purchase_binding。
- 当前GD在原文件第66行的字符串比较产生 Invalid operands 诊断，随后调用者收到空String返回。
- null控制例两版都正常拒绝，无诊断。

这六次预期诊断错误单独保存在 type_boundary_probe，不计作正常接受，也不因为exit=0或返回空字符串就称为通过。它们证明当前新增分支的局部类型稳健性问题，不证明真实游戏绕过或事故可达性。没有改当前GD来隐藏问题。

真实调用侧还有实际owner/手牌对象、原槽ledger、取得事件、支付与购买完成、完整收据及Spellteach.saved_error检查；源码位置和哈希见static_contract。完整调用链未执行，不能省略这些条件推断结果。

## 3. 原工具与当前GD的定向正反例

只执行原工具和同家族driver的三个原始AST节点：目标for循环及两条重排。与此前其他家族不同，此hook直接写 `out[identity]=compiled`，没有执行emit或整个编译器。

GD仅加载三份当前原源码（SpellteachSources、Exact、PoolIdentity），另加一份历史SpellteachSources作版本比较。ProbeCatalog只是最小get_card/cards/source_catalog接口，没有加载完整Catalog。

| 受测方式 | 组数 | 原工具接受 | GD诊断组合接受 | 原接受/GD拒绝 | 原异常 | 合成/合并后closure拒绝 |
|---|---:|---:|---:|---:|---:|---:|
| 独立传入card | 324 | 150 | 90 | 60 | 0 | 54 |
| card就是同一mapping行 | 276 | 150 | 90 | 60 | 0 | 54 |
| 改另一个成员，覆盖两个同伴调用 | 552 | 300 | 180 | 120 | 0 | 108 |
| mapping根/键/成员边界 | 45 | 3 | 3 | 0 | 21 | 0 |
| 合计 | 1197 | 603 | 363 | 240 | 21 | 216 |

原工具检查传入card正文，但使用普通Python相等，不能区分bool与等值数字。240次差异为bool→int84、bool→float84、number→bool72。不能把本工具说成完全不校验detached正文。

真实耦合/同伴形状的180次差异调用覆盖60种唯一坏mapping：42种bool→数值，加18种数值1→True。54种在RAW+EXPECTED合并后仍坏，实际closure拒绝；6种只改supported，被固定EXPECTED覆盖恢复。因此该部分合并后拒绝是162次，不是180次。detached另60次属于函数接口测试，54次closure拒绝来自人为替回该对象的诊断合成，不是实际hook输出。这些closure计算都使用测试中的变异RAW与固定编译输出合并，没有证明变异曾写入真实raw文件或会被完整Catalog读取。

所有数字叶的等值float及bool替换、所有布尔叶的int/float与翻转、代表性NaN/±Inf、文本/结构/id/缺成员等均覆盖。输入不变、输出深拷贝、原partial标记及default_pool=false、pool_supported=false保持。每个无异常hook场景验证陈旧目标输出清除/替换、无关输出保留及固定三成员顺序。21个非法mapping根在hook早期中断，不算清理成功或完整驱动已修复。

该诊断组合调用实际raw_error/proof_error，并加上该Python工具的三成员键/id契约；它不是项目现有单一入口，也不能说closure_error本身强制键/id一致。

## 4. proof门控与结构域

原Python对合法card先读取、哈希八份proof，再检查mapping和传入正文。逐proof改字节/缺失并对三个ID调用，共48次负例：字节变化抛ValueError，缺失抛FileNotFoundError，均未接受。未知card在proof之前返回None；合法card配非法mapping时，坏proof先报错。原hook则在调用前已有cards.get步骤，顺序不能混为一谈。

实际GD的16组proof变体均由proof_error和closure_error拒绝，closure在读取catalog之前退出；raw_error本身仍独立于proof。所有修改仅发生于新测试副本，并在每次后恢复、回读哈希一致。原proof文件从未修改。

另外17个结构探针与17个效果探针均记录真实结果：

- closure可以接受任意ProbeCatalog中的完整行交换、轮换或重复，也允许若干未配套/星级不同的局部shop投影；当前和历史行为一致。
- 缺成员、错误pool blocker、非法布尔星级/额外custom字段等被拒绝。
- 此家族integer允许范围内整值float，不能套用其他家族的int-only规则。
- 效果的等值float配额允许，bool混用、错误参数/施法归属、额外字段等拒绝。

这些任意映射/投影fixture不是实际Catalog或Shop会产生它们的证明。90个保存的目标hook都以cards.get(identity)取卡，而且成功输出前原工具要求三个外部键各匹配固定RAW，所以目标hook成功输出的外部键和行内id在这个局部契约内一致。

## 5. 当前数据与依赖边界

重新核验98个历史driver代表原件，90版含同形目标hook，8版不含。当前20个Catalog输入只命中6条目标记录：raw零基656/657/2433与compiled零基3353/3354/3355，分别逐类型严格等于RAW与EXPECTED；其余18输入没有目标行。本轮再次核对所依据的263项源/历史证据pin未变，没有当前目标数据污染证据。

当前Catalog摄入对这些字符串id按行id构建key；但这不是全部预处理/overlay的全局不变式。目标hook前仍有831–923个整张cards传参的静态站点，不能据此断言所有前置函数不改数据。完整driver版本和依赖仍没有闭合。

345个目标工具仍缺失，XML36.6.3候选未安装。既有四份原证据、两份全局合同及Game/宿主玩法/旧存档未验收边界不变。本轮没有生成新修正，也没有尝试安装或恢复任何工具。

安全下一步是保留原件与本轮差异证据，分别评估编译器数值比较和当前GD字段类型检查的明确新修正；任何新版本都应独立标识、重验，不覆盖历史原件，更不能绕过未闭合的驱动与集成验收。

## 6. 独立复核、复跑及文件

独立Python模型重建1197主例、真实3节点hook及48proof负例，核对22份主原件/副本以及两份追加版本来源；计数、类型差异与原件哈希一致。独立审阅另核对类型诊断日志，没有把它冒充另一次Godot运行。详情见review_independent。

主GD两轮无错误日志、JSON逐字一致。30文件便携副本再次跑原工具、主GD双轮及独立类型探针；主JSON、proof结果和类型探针逐例JSON一致，Python报告也逐字一致，资源运行记录另存。便携复跑不依赖原runtime，使用已有Godot，不下载或安装：

`python3 replay_to_new.py /一个尚不存在的新目录`

REPLAY_INPUTS.json固定30份最小输入。verify_final.py依赖当前本地源树/旧档做额外只读核验，不是便携入口。原工具证明材料和所有旧补丁以原字节保存；不要运行保存的完整driver、历史作者脚本或直接应用整包candidate.patch。

主Python测试RSS约62.8MiB、独立复核约67MiB，均限128MiB地址空间。主/便携Godot峰值约79MiB，每轮约2.2–2.7秒；类型探针约65MiB，每次不足一秒。Godot具192MiB RSS停止线、45秒超时、2GiB地址空间和系统可用内存检查。

八份以前封包回读哈希未变。全程本地，没有联网、下载、重试被取消第14批操作或更改原树/旧备份。封包排除HOME/XDG、缓存、凭据、私聊、旧存档和临时破坏proof副本，只收录白名单原件、测试、报告及必要的诊断日志。
