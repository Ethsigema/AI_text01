from pathlib import Path
import ast,json,hashlib,resource,difflib
resource.setrlimit(resource.RLIMIT_AS,(128*1024**2,128*1024**2))
H=Path(__file__).resolve().parent;R=H.parent/'historical_tools_batch14_20261109T191857Z/runtime';F='research/spellteach_murloc_native_recovery/';T=F+'candidates/tools/spellteach_murloc_native_patterns.py'
baseline=json.loads((R.parent/'SOURCE_MAP.json').read_text());s=(R/T).read_text();const={n.targets[0].id:ast.literal_eval(n.value) for n in ast.parse(s).body if isinstance(n,ast.Assign)}
assert hashlib.sha256(s.encode()).hexdigest()=='72a753e0ec02e8760ee920b1311bca0c58086da49dcd2fd506bf074adf0d1c8f'
rels=[T,F+'manifest.json',F+'candidate.patch',F+'admission.json',F+'APPLIED.json',F+'APPLY_BLOCKED.json',F+'PROCESS_RESULT.json',F+'admission_first_missing_classification.json',F+'check_admission.gd',F+'candidates/core/spellteach_murloc_sources.gd',F+'candidates/tools/build_effect_catalog.py','core/spellteach_murloc_sources.gd','core/phase_undead_army_sources.gd','core/pool_identity.gd']+list(const['PROOF_SHA256'])
pins={}
for rel in rels:
 b=(R/rel).read_bytes();pin={'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()};assert pin==baseline[rel];pins[rel]=pin;p=H/'original_inputs'/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
 if rel in const['PROOF_SHA256']:assert pin['sha256']==const['PROOF_SHA256'][rel]
for rel in ['core/spellteach_murloc_sources.gd','core/phase_undead_army_sources.gd','core/pool_identity.gd']+list(const['PROOF_SHA256']):
 p=H/'gd_minimal'/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((R/rel).read_bytes())
p=H/'gd_minimal/historical/spellteach_murloc_sources.gd';p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((R/(F+'candidates/core/spellteach_murloc_sources.gd')).read_bytes())
for rel in const['PROOF_SHA256']:
 p=H/'python_minimal'/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((R/rel).read_bytes())
p=H/'python_minimal/tools/spellteach_murloc_native_patterns.py';p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((R/T).read_bytes())
(H/'gd_minimal/project.godot').write_text('config_version=5\n[application]\nconfig/name="Spellteach isolated source probes"\n[rendering]\nrenderer/rendering_method="gl_compatibility"\n')
(H/'INPUT_PINS.json').write_text(json.dumps(pins,indent=2,sort_keys=True)+'\n')
(H/'CONSTANTS.json').write_text(json.dumps(const,ensure_ascii=False,indent=2)+'\n')
old=(R/(F+'candidates/core/spellteach_murloc_sources.gd')).read_text();new=(R/'core/spellteach_murloc_sources.gd').read_text();(H/'HISTORICAL_TO_CURRENT_GD.patch').write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='historical/core/spellteach_murloc_sources.gd',tofile='current/core/spellteach_murloc_sources.gd')))
cases=[];seen=set();IDS=const['SOURCE_IDS']
def add(regime,identity,path,op,target_id=None,**extra):
 target_id=target_id or identity;key=(regime,identity,target_id,tuple(path),op,json.dumps(extra.get('value'),sort_keys=True))
 if key in seen:return
 seen.add(key);cases.append({'label':f'{len(cases):04d}:{regime}:{identity}:{target_id}:{op}:'+'.'.join(map(str,path)),'regime':regime,'identity':identity,'target_id':target_id,'path':path,'op':op,**extra})
def walk(x,path=[]):
 yield path,x
 if type(x) is dict:
  for k,v in x.items():yield from walk(v,path+[k])
 elif type(x) is list:
  for k,v in enumerate(x):yield from walk(v,path+[k])
for target,row in const['RAW'].items():
 roles=[('detached',target),('coupled',target)]+[('companion',i) for i in IDS if i!=target]
 for regime,identity in roles:
  for op,path in [('canonical',[]),('all_numbers_float',[]),('id_only',[]),('change_string',['text']),('change_string',['id']),('id_swap',['id']),('extra_key',[]),('number_delta',['health']),('number_string',['attack']),('nan',['attack']),('pos_inf',['attack']),('neg_inf',['attack']),('replace_null',[]),('replace_array',[]),('merged_card',[])]:add(regime,identity,path,op,target)
  for path,value in walk(row):
   if type(value) is bool:
    for op in ['bool_to_int','bool_to_float','toggle_bool']:add(regime,identity,path,op,target)
   elif type(value) is int:
    for op in ['numeric_float','number_bool']:add(regime,identity,path,op,target)
 for value in [None,False,0,0.0,'',[],{},['bad']]:
  add('mapping_root',target,[],'invalid_root',value=value)
  add('detached',target,[],'invalid_root',value=value)
 for value in [None,False,1,1.0,[],{},['bad'],'not-a-source']:
  add('detached',target,['id'],'replace_value',value=value)
 for op in ['swap_parents','rotate_all','duplicate_row','extra_unrelated']:
  add('mapping_root',target,[],op,target)
 for missing in IDS:add('mapping_root',target,[missing],'delete')
(H/'CASES.json').write_text(json.dumps(cases,ensure_ascii=False,indent=2)+'\n')
(H/'PREPARATION.json').write_text(json.dumps({'case_count':len(cases),'original_inputs':len(pins),'PROOF_files':len(const['PROOF_SHA256']),'current_GD_scripts':3,'historical_GD_scripts':1,'original_tool_sha256':pins[T]['sha256'],'current_GD_sha256':pins['core/spellteach_murloc_sources.gd']['sha256'],'historical_GD_sha256':pins[F+'candidates/core/spellteach_murloc_sources.gd']['sha256'],'new_correction_created':False,'installed':False,'max_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss},indent=2)+'\n');print('prepared',len(cases),'cases;',len(pins),'original inputs')
