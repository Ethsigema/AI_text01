for identity in SPELLTEACH_IDS:
 out.pop(identity,None)
 c=cards.get(identity)
 compiled=compile_spellteach(c,cards,root=R)
 if compiled is not None: out[identity]=compiled

ordered_ids=[identity for identity in ordered_ids if identity not in SPELLTEACH_IDS]

ordered_ids.extend(identity for identity in SPELLTEACH_IDS if identity in out)
