from pathlib import Path
from copy import deepcopy
import ast,hashlib,json,resource,sys,types
resource.setrlimit(resource.RLIMIT_AS,(128*1024**2,128*1024**2));resource.setrlimit(resource.RLIMIT_CPU,(45,45));sys.dont_write_bytecode=True
H=Path(__file__).resolve().parent;ROOT=H/'python_minimal';p=ROOT/'tools/spellteach_murloc_native_patterns.py';s=p.read_text();t=ast.parse(s)
for n in t.body:
 if isinstance(n,ast.Assign):ast.literal_eval(n.value)
 elif isinstance(n,ast.ImportFrom):assert (n.module,[v.name for v in n.names]) in [('copy',['deepcopy']),('pathlib',['Path'])]
 elif isinstance(n,ast.Import):assert [v.name for v in n.names]==['hashlib']
 else:assert isinstance(n,ast.FunctionDef) and n.name=='compile_card'
original=types.ModuleType('original_spellteach');original.__file__=str(p);exec(compile(t,str(p),'exec'),original.__dict__);IDS=original.SOURCE_IDS
import mutations
mutations.IDS=IDS;mutations.original=original

def frozen(v):return json.dumps(v,ensure_ascii=False,sort_keys=True)
def inputs(c):
 cards=deepcopy(original.RAW);card=deepcopy(original.RAW[c['identity']])
 if c['regime']=='detached':card=mutations.mutate(card,c)
 elif c['regime'] in ['coupled','companion']:
  cards[c['target_id']]=mutations.mutate(cards[c['target_id']],c);card=cards[c['identity']]
 else:cards=mutations.mutate(cards,c)
 return card,cards
D=H/'original_inputs/research/spellteach_murloc_native_recovery/candidates/tools/build_effect_catalog.py';ds=D.read_text();dt=ast.parse(ds)
hook=next(n for n in dt.body if isinstance(n,ast.For) and isinstance(n.iter,ast.Name) and n.iter.id=='SPELLTEACH_IDS');at=dt.body.index(hook);nodes=[hook]+dt.body[at+1:at+3];assert all('SPELLTEACH_IDS' in ast.unparse(n) for n in nodes)
code=compile(ast.Module(body=nodes,type_ignores=[]),'exact_spellteach_hook','exec');(H/'DRIVER_EXACT_FRAGMENTS.py').write_text('\n\n'.join(ast.get_source_segment(ds,n) for n in nodes)+'\n')
results=[]
for c in json.loads((H/'CASES.json').read_text()):
 card,cards=inputs(c);before=repr([card,cards]);err=None
 try:out=original.compile_card(card,cards,root=ROOT)
 except Exception as e:out=None;err=type(e).__name__
 assert repr([card,cards])==before
 if out is not None:assert frozen(out)==frozen(original.EXPECTED[card['id']])
 stale={i:{'id':i,'stale':True} for i in IDS};stale['unrelated']={'id':'unrelated','keep':True};calls=[]
 def instrument(c,all_cards,root):
  calls.append({'key':ns.get('identity'),'same_key_object':type(all_cards) is dict and c is all_cards.get(ns.get('identity')),'root_is_isolated':Path(root)==ROOT})
  return original.compile_card(c,all_cards,root=root)
 ns={'cards':cards,'out':deepcopy(stale),'ordered_ids':['unrelated']+list(reversed(IDS)),'SPELLTEACH_IDS':IDS,'compile_spellteach':instrument,'R':ROOT};hookerr=None
 try:exec(code,ns)
 except Exception as e:hookerr=type(e).__name__
 assert repr([card,cards])==before
 emitted=[i for i in IDS if i in ns['out'] and not ns['out'][i].get('stale',False)]
 if hookerr is None:
  assert ns['out']['unrelated']==stale['unrelated']
  assert ns['ordered_ids']==['unrelated']+emitted
  for i in emitted:assert frozen(ns['out'][i])==frozen(original.EXPECTED[i])
  assert all(x['same_key_object'] and x['root_is_isolated'] for x in calls)
 results.append({'label':c['label'],'regime':c['regime'],'op':c['op'],'original_accept':out is not None,'original_error':err,'actual_hook_emitted_ids':emitted,'actual_hook_error':hookerr,'hook_calls':calls,'remaining_stale_ids':[i for i in IDS if ns['out'].get(i,{}).get('stale',False)],'input_unchanged':True,'hook_clean_output_and_order_pass':hookerr is None})
outputs={i:original.compile_card(deepcopy(original.RAW[i]),deepcopy(original.RAW)) for i in IDS}
for i in IDS:
 a=original.compile_card(deepcopy(original.RAW[i]),deepcopy(original.RAW),root=ROOT);b=original.compile_card(deepcopy(original.RAW[i]),deepcopy(original.RAW),root=ROOT);a['effects'][0]['extra']=True;a['conditional_support']['extra']=True
 assert 'extra' not in b['effects'][0] and 'extra' not in b['conditional_support'];assert frozen(b)==frozen(original.EXPECTED[i]);assert b['pool_supported'] is False and b['default_pool'] is False and 'partial' in b['implementation_status']
(H/'ORIGINAL_OUTPUTS.json').write_text(json.dumps(outputs,ensure_ascii=False,indent=2)+'\n')
proof=[]
for index,(rel,digest) in enumerate(original.PROOF_SHA256.items()):
 for mode in ['changed_bytes','missing']:
  root=H/'proof_variants'/f'{index:02d}_{mode}';root.mkdir(parents=True,exist_ok=True)
  for source_rel in original.PROOF_SHA256:
   if source_rel==rel and mode=='missing':continue
   dest=root/source_rel;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes((ROOT/source_rel).read_bytes()+(b' ' if source_rel==rel and mode=='changed_bytes' else b''))
  for identity in IDS:
   err=None;out=None
   try:out=original.compile_card(deepcopy(original.RAW[identity]),deepcopy(original.RAW),root=root)
   except Exception as e:err=type(e).__name__;msg=str(e)
   assert out is None and err==('ValueError' if mode=='changed_bytes' else 'FileNotFoundError')
   if mode=='changed_bytes':assert msg=='spellteach_murloc_native_proof_changed:'+rel
   proof.append({'path':rel,'mode':mode,'identity':identity,'accepted':False,'exception':err,'expected_rejection':True})
  assert original.compile_card({'id':'foreign'},None,root=root) is None
  # Direct call checks proofs before malformed cards; historical hook does .get first.
  try:original.compile_card(deepcopy(original.RAW[IDS[0]]),None,root=root)
  except Exception as e:assert type(e).__name__==('ValueError' if mode=='changed_bytes' else 'FileNotFoundError')
for rel,digest in original.PROOF_SHA256.items():assert hashlib.sha256((ROOT/rel).read_bytes()).hexdigest()==digest
(H/'PYTHON_PROOF_TESTS.json').write_text(json.dumps({'tests':proof,'valid_card_tests':len(proof),'unknown_card_returns_None_before_proof_check':True,'direct_proof_check_precedes_invalid_mapping_root':True,'original_proof_files_unchanged':True},indent=2)+'\n')
report={'case_count':len(results),'original_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'driver_sha256':hashlib.sha256(D.read_bytes()).hexdigest(),'executed_driver_nodes':[{'kind':type(n).__name__,'first':n.lineno,'last':n.end_lineno} for n in nodes],'full_driver_executed':False,'proofs_checked_by_original_at_runtime':True,'default_root_is_isolated_copy':True,'deepcopy_partial_pool_and_input_checks_pass':True,'results':results,'by_regime':{},'max_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
for regime in sorted({x['regime'] for x in results}):
 rows=[x for x in results if x['regime']==regime];report['by_regime'][regime]={'cases':len(rows),'accepts':sum(x['original_accept'] for x in rows),'direct_exceptions':sum(x['original_error'] is not None for x in rows),'hook_exceptions':sum(x['actual_hook_error'] is not None for x in rows)}
(H/'PYTHON_REPORT.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k!='results'},indent=2))
