"""Reproduce bounded original-tool and actual-GD evidence, not installation or gameplay."""
from pathlib import Path
import json,hashlib,subprocess,sys,resource
resource.setrlimit(resource.RLIMIT_AS,(128*1024**2,resource.RLIM_INFINITY))
H=Path(__file__).resolve().parent;assert len(sys.argv)==2;D=Path(sys.argv[1]).resolve();assert not D.exists();D.mkdir(parents=True)
manifest=json.loads((H/'REPLAY_INPUTS.json').read_text())
for rel,pin in manifest.items():
 b=(H/rel).read_bytes();assert len(b)==pin['bytes'] and hashlib.sha256(b).hexdigest()==pin['sha256'];p=D/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b);assert p.stat().st_ino!=(H/rel).stat().st_ino
for script in ['test_original.py','run_godot.py','run_type_boundary.py']:subprocess.run([sys.executable,'-B',str(D/script)],check=True)
gd=json.loads((D/'GODOT_first.json').read_text());assert gd==json.loads((D/'GODOT_repeat.json').read_text()) and not gd['failures'];assert gd['case_count']==1197
assert sum(x['original_accept_GD_reject'] for x in gd['counts'].values())==240
assert sum(x['strict_accept'] for x in gd['counts'].values())==363
assert len(gd['proof_tests'])==16 and len(gd['historical_current_unit_probes'])==20
boundary=json.loads((D/'type_boundary_probe/RESULT.json').read_text());assert sum(x['actual_script_errors'] for x in boundary['records'])==6 and boundary['current_source_field_type_diagnostic_cases']==3
for rel,pin in manifest.items():assert hashlib.sha256((D/rel).read_bytes()).hexdigest()==pin['sha256'],rel
result={'status':'PASS_REPRODUCTION_OF_LIMITED_DIFFERENCES_AND_DIAGNOSTICS_NOT_INSTALLATION_APPROVAL','destination':str(D),'copied_files':len(manifest),'original_source_runtime_needed':False,'main_cases':1197,'strict_positive_cases':363,'original_accept_GD_diagnostic_reject':240,'Python_proof_negative_calls':48,'GD_proof_mutations':16,'historical_current_unit_cases':20,'separate_current_source_type_error_cases':3,'recorded_expected_type_errors_across_two_repeats':6,'no_new_correction_or_installation':True,'full_driver_Catalog_Game_hosts_or_saves_run':False}
(D/'REPLAY_RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
