from pathlib import Path
import ast,hashlib,json,resource,collections
resource.setrlimit(resource.RLIMIT_AS,(128*1024**2,128*1024**2))
H=Path(__file__).resolve().parent;W=H.parent;R=W/'historical_tools_batch14_20261109T191857Z/runtime'
def read(p):return json.loads(p.read_text())
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
base=read(R.parent/'SOURCE_MAP.json');pins=read(H/'INPUT_PINS.json');extra=read(H/'ADDITIONAL_SOURCE_PINS.json')
for rel,pin in dict(pins,**extra).items():
 assert pin==base[rel]
 for p in [R/rel,H/'original_inputs'/rel]:assert sha(p)==pin['sha256'] and p.stat().st_size==pin['bytes']
const=read(H/'CONSTANTS.json')
for rel,digest in const['PROOF_SHA256'].items():
 for root in ['python_minimal','gd_minimal']:assert sha(H/root/rel)==digest
for rel in ['core/spellteach_murloc_sources.gd','core/phase_undead_army_sources.gd','core/pool_identity.gd']:assert sha(H/'gd_minimal'/rel)==pins[rel]['sha256']
assert sha(H/'gd_minimal/historical/spellteach_murloc_sources.gd')==pins['research/spellteach_murloc_native_recovery/candidates/core/spellteach_murloc_sources.gd']['sha256']
assert sha(H/'python_minimal/tools/spellteach_murloc_native_patterns.py')=='72a753e0ec02e8760ee920b1311bca0c58086da49dcd2fd506bf074adf0d1c8f'
source=read(H/'static_contract/SOURCE_PINS.json')+read(H/'static_contract/CALLER_PROVENANCE.json')['read_pins']
for pin in source:assert sha(W/pin['path'])==pin['sha256'],pin['path']
for pin in read(H/'static_contract/FILES_SHA256.json'):assert sha(H/'static_contract'/pin['path'])==pin['sha256']
py=read(H/'PYTHON_REPORT.json');gd=read(H/'GODOT_first.json');cases=read(H/'CASES.json');assert gd==read(H/'GODOT_repeat.json') and not gd['failures'];assert len(cases)==py['case_count']==gd['case_count']==1197
assert sum(x['original_accept'] for x in py['results'])==603
assert sum(x['strict_accept'] for x in gd['counts'].values())==363
assert sum(x['original_accept_GD_reject'] for x in gd['counts'].values())==240
assert sum(x['original_accept_compiled_closure_reject'] for x in gd['counts'].values())==216
assert sum(x['original_exception'] for x in gd['counts'].values())==21
assert all(x['input_unchanged'] for x in py['results'])
unique=set();kept=set();actual_calls=0;actual_closure_reject=0;op_counts=collections.Counter()
for c,p,g in zip(cases,py['results'],gd['results']):
 assert c['label']==p['label']==g['label'] and g['actual_raw_accept']==g['historical_raw_accept']
 if c['regime']=='detached':assert g['compiled_projection']=='hypothetical_detached_replacement_not_actual_hook'
 if p['original_accept'] and not g['strict_accept']:
  op_counts[c['op']]+=1
  if c['regime'] in ['coupled','companion']:
   actual_calls+=1;key=(c['target_id'],tuple(c['path']),c['op']);unique.add(key)
   assert p['actual_hook_error'] is None and p['actual_hook_emitted_ids']==const['SOURCE_IDS']
   assert all(x['same_key_object'] and x['root_is_isolated'] for x in p['hook_calls'])
   if g['compiled_closure_error']:actual_closure_reject+=1;kept.add(key)
assert (actual_calls,len(unique),actual_closure_reject,len(kept))==(180,60,162,54)
assert dict(op_counts)=={'bool_to_int':84,'bool_to_float':84,'number_bool':72}
assert len(gd['structural_probes'])==17 and len(gd['effect_probes'])==17 and len(gd['proof_tests'])==16 and len(gd['historical_current_unit_probes'])==20
proof=read(H/'PYTHON_PROOF_TESTS.json');assert proof['valid_card_tests']==48 and all(x['expected_rejection'] for x in proof['tests'])
assert all(x['catalog_reads_before_reject']==0 and x['raw_gate_remains_independent'] and x['isolated_copy_restored'] for x in gd['proof_tests'])
unit_delta=[x['case'] for x in gd['historical_current_unit_probes'] if x['current_accept']!=x['historical_accept']];assert unit_delta==['owned_binding','owned_float_slot']
for run in ['first','repeat']:
 for stream in ['stdout','stderr']:
  t=(H/f'GODOT_{run}.{stream}.log').read_text();assert 'SCRIPT ERROR' not in t and 'ERROR:' not in t
boundary=read(H/'type_boundary_probe/RESULT.json');assert sum(x['actual_script_errors'] for x in boundary['records'])==6
for x in boundary['records']:
 t=(H/f"type_boundary_probe/{x['case']}_{x['repeat']}.stderr.log").read_text();assert t.count('SCRIPT ERROR:')==x['actual_script_errors']
 if x['actual_script_errors']:assert x['current_return']=='' and 'res://core/spellteach_murloc_sources.gd:66' in t
for rel,pin in read(H/'REPLAY_INPUTS.json').items():assert sha(H/rel)==pin['sha256']
portable=read(H/'PORTABLE_REPLAY_RESULT.json');D=Path(portable['destination']);assert portable['copied_files']==30 and not portable['original_source_runtime_needed']
for rel in ['GODOT_first.json','GODOT_repeat.json','PYTHON_PROOF_TESTS.json']:assert sha(D/rel)==sha(H/rel)
a=read(D/'PYTHON_REPORT.json');b=read(H/'PYTHON_REPORT.json');a.pop('max_rss_kib');b.pop('max_rss_kib');assert a==b
for label in ['bool','int','array','null']:
 for repeat in [1,2]:assert sha(D/f'type_boundary_probe/{label}_{repeat}.json')==sha(H/f'type_boundary_probe/{label}_{repeat}.json')
old=read(W/'titanic_guardian_correction_review_20261109T234448Z/FINAL_VERIFICATION.json')['prior_archives_unchanged'];old['titanic_guardian_correction_review_20261109T234448Z.tar.xz']='005f831d5c3a1f6833a935014e182bfe14adbec017da0a26a472f21190ff0c19'
for rel,digest in old.items():assert sha(W/rel)==digest
remaining=read(W/'historical_tools_batch15_20261109T195018Z/REMAINING_SCOPE.json')['remaining_targets'];assert len(remaining)==345 and all(not (R/rel).exists() for rel in remaining)
assert not (R/'evidence/portable_legacy/CardDefs.Bacon_latest.xml').exists()
result={'status':'PASS_REPRODUCTION_OF_LOCAL_DIFFERENCES_NOT_RESTORATION_ACCEPTANCE','original_input_pins':len(pins),'additional_version_source_pins':len(extra),'source_pin_records_rechecked':len(source),'unique_source_paths_rechecked':len({p['path'] for p in source}),'current_and_historical_GD_unchanged':True,'proof_copies_restored_and_hash_matched':8,'main_cases':1197,'original_accepts':603,'strict_positive_cases':363,'original_accept_GD_diagnostic_reject':240,'all_discrepant_compiled_closure_reject_calls_including_hypothetical_detached':216,'actual_coupled_companion_discrepant_calls':actual_calls,'unique_discrepant_mapping_variants':len(unique),'actual_coupled_companion_closure_reject_calls':actual_closure_reject,'unique_mapping_variants_retained_bad_after_overlay':len(kept),'detached_only_differential_calls':60,'original_invalid_mapping_exceptions':21,'differential_operations':dict(op_counts),'python_proof_negative_calls':48,'GD_proof_mutations':16,'structure_probes':17,'effect_probes':17,'historical_current_unit_probes':20,'valid_string_source_binding_version_differences':unit_delta,'separate_invalid_source_id_type_cases':3,'expected_GD_script_errors_in_separate_double_runs':6,'source_type_errors_not_counted_as_acceptance':True,'portable_files':30,'remaining_missing_tools':345,'XML_candidate_not_installed':True,'old_archives_unchanged':old,'new_correction_created':False,'installed':False,'full_compiler_Catalog_Game_hosts_or_saves_executed':False,'max_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
(H/'FINAL_VERIFICATION.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps(result,ensure_ascii=False,indent=2))
