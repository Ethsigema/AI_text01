from pathlib import Path
import os,subprocess,time,resource,json,hashlib
H=Path(__file__).resolve().parent;D=H/'type_boundary_probe';D.mkdir(exist_ok=True)
env=os.environ.copy()
for key,sub in [('HOME','isolated_home'),('XDG_CACHE_HOME','isolated_cache'),('XDG_DATA_HOME','isolated_data'),('XDG_CONFIG_HOME','isolated_config')]:
 p=D/sub;p.mkdir(exist_ok=True);env[key]=str(p)
env['GODOT_SILENCE_ROOT_WARNING']='1'
def available():
 return next(int(x.split()[1]) for x in Path('/proc/meminfo').read_text().splitlines() if x.startswith('MemAvailable:'))
def limits():
 resource.setrlimit(resource.RLIMIT_AS,(2*1024**3,2*1024**3));resource.setrlimit(resource.RLIMIT_CORE,(0,0))
records=[]
for label in ['bool','int','array','null']:
 assert available()>1024*1024
 for repeat in [1,2]:
  out=D/f'{label}_{repeat}.json';start=time.monotonic();peak=0
  with (D/f'{label}_{repeat}.stdout.log').open('w') as stdout,(D/f'{label}_{repeat}.stderr.log').open('w') as stderr:
   p=subprocess.Popen(['/usr/local/bin/godot','--headless','--path',str(H/'gd_minimal'),'--script','res://type_boundary_probe.gd','--',label,str(out)],env=env,stdout=stdout,stderr=stderr,preexec_fn=limits)
   while p.poll() is None:
    try:
     for line in Path(f'/proc/{p.pid}/status').read_text().splitlines():
      if line.startswith('VmRSS:'):peak=max(peak,int(line.split()[1]))
    except FileNotFoundError:pass
    if peak>192*1024 or available()<640*1024 or time.monotonic()-start>45:p.kill();p.wait();raise RuntimeError('resource stop')
    time.sleep(.02)
  assert p.returncode==0
  error=(D/f'{label}_{repeat}.stderr.log').read_text();result=json.loads(out.read_text());errors=error.count('SCRIPT ERROR:')
  assert result['historical_return']=='spellteach_invalid_actual_purchase_binding'
  if label=='null':assert errors==0 and result['current_return']=='spellteach_invalid_actual_purchase_binding'
  else:
   assert errors==1 and result['current_return']==''
   assert 'Invalid operands' in error and "in operator '=='" in error and 'res://core/spellteach_murloc_sources.gd:66' in error
  records.append({'case':label,'repeat':repeat,'exit_code':p.returncode,'actual_script_errors':errors,'current_empty_return_is_not_acceptance':bool(errors),'seconds':round(time.monotonic()-start,3),'peak_rss_kib':peak,'historical_return':result['historical_return'],'current_return':result['current_return']})
 assert (D/f'{label}_1.json').read_bytes()==(D/f'{label}_2.json').read_bytes()
report={'status':'REPRODUCED_LOCAL_GD_DIAGNOSTIC_ERRORS_NOT_GAME_REACHABILITY','records':records,'current_source_field_type_diagnostic_cases':3,'null_control_normal_rejection':True,'historical_version_all_normal_rejections':True,'full_pipeline_executed':False,'source_modified':False}
(D/'RESULT.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
