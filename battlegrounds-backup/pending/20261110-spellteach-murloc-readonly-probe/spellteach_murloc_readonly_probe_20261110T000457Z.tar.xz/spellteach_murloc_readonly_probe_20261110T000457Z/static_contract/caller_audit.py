"""Only read source text and write this audit directory; no Godot or project Python."""
import hashlib,json,pathlib,resource
resource.setrlimit(resource.RLIMIT_AS,(128*1024*1024,128*1024*1024))
W=pathlib.Path('/workspace/scratch/dd4f12b08ec0');R=W/'historical_tools_batch14_20261109T191857Z/runtime';D=pathlib.Path(__file__).resolve().parent
pins=[]
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(65536),b''):h.update(b)
 return h.hexdigest()
def pin(p):
 d={'path':str(p.relative_to(W)),'bytes':p.stat().st_size,'sha256':sha(p)};pins.append(d);return d
def excerpt(p,ranges):
 record=pin(p);ls=p.read_text().splitlines();out=['FILE '+record['path']+' SHA256 '+record['sha256']]
 for a,b in ranges:out+=['\n'+'\n'.join(f'{n}: {ls[n-1]}' for n in range(a,min(b,len(ls))+1))]
 return '\n'.join(out)
folder=R/'research/spellteach_trinket_runtime'
files=[pin(p) for p in sorted(folder.rglob('*')) if p.is_file()]
author=folder/'author_patches.py';text=author.read_text()
manifest_candidates=[p['path'] for p in files if 'manifest' in pathlib.Path(p['path']).name.lower()]
expected_pins=['465267b111c12f3cba4a18eef1285ed0544340207139953ea57a548dc7072f6e','11f8b3b06cc65b484ae379fbeaf825843df0f22d55c1887d23eba152d3b41ca5']
pin_mentions={value:[str(p.relative_to(W)) for p in folder.rglob('*') if p.is_file() and value in p.read_text()] for value in expected_pins}
snippets=[excerpt(R/'core/spellteach_murloc_cast.gd',[(13,39),(89,99)]),excerpt(R/'core/spellteach_murloc_host.gd',[(4,15),(111,128),(137,156)]),excerpt(R/'core/spellteach_trinket_sources.gd',[(19,45)]),excerpt(R/'core/spellteach_trinket_host.gd',[(13,30),(32,44),(46,118),(120,159)]),excerpt(R/'core/game.gd',[(3551,3562),(3623,3631),(3716,3726),(8528,8538)]),excerpt(R/'core/mechanism_effects.gd',[(232,241)]),excerpt(author,[(1,23)])]
(D/'ACTUAL_CALLER_EXCERPTS.txt').write_text('\n\n'.join(snippets)+'\n')
result={'runtime_patch_folder_files':files,'manifest_files_found_in_exact_runtime_patch_folder':manifest_candidates,'independent_before_after_pin_mentions_in_exact_folder':pin_mentions,'author_method':'author_patches.py reads current root source, applies string.replace, saves unified diff; no asserted before/after digest in this folder. Author script was not run.','scope':'Static guards and wiring only; no cast/host/Game/save execution and no claim that arbitrary validator-only fixtures are reachable.','read_pins':pins,'all_source_pins_unchanged':all(sha(W/p['path'])==p['sha256'] for p in pins),'max_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
(D/'CALLER_PROVENANCE.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k not in ['runtime_patch_folder_files','read_pins']},ensure_ascii=False,indent=2))
