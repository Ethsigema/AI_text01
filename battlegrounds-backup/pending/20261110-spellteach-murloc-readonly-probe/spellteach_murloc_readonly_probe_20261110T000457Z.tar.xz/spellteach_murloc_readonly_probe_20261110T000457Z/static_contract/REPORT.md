# 魔鳍工具只读恢复契约审查

## 结论

固定原工具、manifest、创建补丁的工具节和八项 proof 均能相互对齐。当前 GD 的改变只有 `unit_error` 对魔鳍标签 `BG35_MagicItem_750` 来源绑定的扩展，RAW、EXPECTED、PROGRAMS、PROOF_SHA256 及所有其他代码未变。当前 20 个 Catalog 数据文件的目标行仍严格匹配该工具。

这支持继续做隔离、低资源的单工具定向验证，不等于允许安装、运行完整编译器或回退当前 GD。原工具在 runtime/tools 中仍缺失。整个历史 candidate.patch 含一处真实的文件头粘连，不能称为可直接应用的补丁。本审查没有修改 runtime、旧证据或旧备份。

原四份全局证据与两份全局合同的未找到边界保持。本次没有重扫该全局问题；这里的 research/spellteach_murloc_sources/contract.json 只是该家族局部源合同，不能替代它们。

## 1. 原件、创建节与 proof

- 原工具 candidates/tools/spellteach_murloc_native_patterns.py：SHA256 `72a753e0ec02e8760ee920b1311bca0c58086da49dcd2fd506bf074adf0d1c8f`，23,459 字节。manifest 的 add 记录、精确新增节负载、实际文件一致。
- 历史 GD：`465267b111c12f3cba4a18eef1285ed0544340207139953ea57a548dc7072f6e`。当前 GD：`11f8b3b06cc65b484ae379fbeaf825843df0f22d55c1887d23eba152d3b41ca5`。
- candidate.patch：`c1dd54eaabbd5da7e8beadd29278c34fcdd2db681576bffbb7bf70d9421c6554`。工具新增节是独立的 `--- /dev/null` / `+++ b/tools/spellteach_murloc_native_patterns.py` / 17 行 hunk，可逐字提取并核 pin。
- 但补丁第 837 行实际为 `+}--- /dev/null`，data/catalog.json 的结尾与 contract.json 旧文件头粘连。下一行才是 `+++ b/research/spellteach_murloc_sources/contract.json`。不能将工具节可提取推成整个补丁可应用。审计仅提取该 contract 的新增负载核对，明确记录旧头不成立；没有修复或应用原补丁。
- 审查选定 11 个对象：工具、历史 GD、历史 driver，以及 8 个 proof。全部候选字节符合 manifest，hunk 负载可还原到候选字节；其中 contract 的边界异常单独标明，其余 10 节旧文件头有效。

八项 proof 在历史 candidates 和当前 runtime 两处均符合原工具的 PROOF_SHA256：三份 native XML、raw_rows.json、programs.json、expected_compiled.json、native_evidence.json、contract.json。详见 SOURCE_CONSISTENCY.json，其中保存完整 SHA256，不截断。

Python RAW/EXPECTED/PROOF 与两版 GD 对应常量逐类型一致；两版 GD 的 PROGRAMS 一致且逐类型等于 programs.json 和 EXPECTED 各行的 effects。八个 proof pin 不包括 Python/GD/host 的源码哈希，不能把 proof 全过理解为执行代码版本已认证。

XML 实体的 CardID/dbf/name、攻击/血量/星级符合 RAW；普通与金色父体配额分别 1/2，二者演化指向同一 dbf 122285 学徒；学徒是 1/1、鱼人、战吼。XML 文本含占位符与标记，而工作簿 RAW 是展示文本，未虚称两者原文逐字相同。RAW 文本的 coverage SHA 符合 EXPECTED。

## 2. 历史 GD 到当前 GD

唯一差异在 unit_error 的 TAUGHT 分支：

1. 先明确拒绝非 Dictionary。
2. 当 source_id 为 BG35_MagicItem_750 时，绑定必须恰含 uid/owner/source_id/source_slot/acquired_event_index/purchased_uid/spell_id/round/sequence/spell_program 这 11 个键；slot 为 0–7 的整数，acquired_event_index 非负，child UID 必须与 purchased UID 不同。
3. 其他来源保留原父体校验：10 个指定键，source_id 必须是普通/金色父体，source_uid/purchased_uid/child uid 互不混淆。
4. 两条分支随后都校验绑定的完整 spell_program 与 catalog 中当前法术 effects 一致。

`research/spellteach_trinket_runtime/patches/core__spellteach_murloc_sources.gd.patch` 与本次历史到当前的完整 unified diff **逐字相同**。在内存中以已核 pin 的历史 GD 为输入应用该已存单独补丁，得到的字节与当前 GD **完全相同**。未改原树。

该 runtime 补丁目录只有 author_patches.py 和五份补丁，没有 manifest，也未发现上述 before/after SHA 文本。author_patches.py 是读取当时 root 文件、string.replace、生成 unified diff；本次只读，未执行。因此可以证明本地补丁精确解释差异，不能声称找到独立的 before/after pin manifest 或完整历史应用验收。详见 GD_CHANGE_PROVENANCE.json 与 CALLER_PROVENANCE.json。

## 3. 实际 caller 与映射 key/id

98 个历史 driver 版本均以一个实际源文件重新核 SHA，再使用已有压缩 AST 记录并核对目标调用行与次数。90 版包含目标 hook，8 版不含；90 版的片段完全相同：

`for identity in SPELLTEACH_IDS` → `out.pop(identity,None)` → `c=cards.get(identity)` → `compile_spellteach(c,cards,root=R)` → 成功时 `out[identity]=compiled`，之后移除目标旧顺序并按固定 SOURCE_IDS 顺序追加成功输出。

由于 compile 在返回前要求三个 `cards[target] == RAW[target]`，且 c 就从当次 identity 取出，**这个实际目标 hook 的成功结果内部 id 与外部 out[identity] 一致**。不必假设所有其他 cards 条目都满足 key=id。无目标 hook 的 8 版不能当成此工具的调用方。

但是此目标 hook 前有 831–923 个整张 cards 传参语法站点；历史 candidate 自身为 831 个。构造 cards 时 `{c['id']:c for c in raw}` 只是初始局部保证，不能推成完整历史流水线不变式。terminal 直接序列化 out 的值，没有借外部键重写值的 id。没有运行 driver。

当前 Catalog 的本地摄入路径为 original 深复制，取 `id=str(card.get('id',''))`，跳过空串；已有记录深复制后 `merged.merge(card,true)`，最后 `cards[id]=merged`。对本次三个字符串身份、严格匹配的实际行，这一步形成 key=id。后续大量预处理/overlay 不在此局部证明内；get_card 最终按入参 key 返回 `cards.get(id,{})`，未增加全局 key/id 校验。不能用验证器可接受的任意错键 fixture 声称实际 Catalog 会产生该映射。

## 4. 当前 20 输入与调用顺序

只在两个文件出现目标行，其余 18 个文件均无目标命中：

- data/catalog_raw.json 零基 656、657、2433，分别为 BG33_891、BG33_891_G、BG33_890t，逐类型严格等于 RAW。
- data/catalog.json 零基 3353、3354、3355，同一顺序，逐类型严格等于 EXPECTED。
- 直接按文件顺序字段合并，三个结果逐类型严格等于 RAW + EXPECTED。这里只是目标行直接合并，不是 Catalog 实际执行结果。
- quest_identity_overrides、removed_hero_value_overrides、final_bg_source_overrides、catalog_value_overrides 无三个目标 ID 文本。season_presets 含普通 BG33_891，是历史池信息，不是效果权限或全局预处理等价证据。

原 Python compile 顺序：先构造 root Path；再 card 必须是 dict 且 id 命中，否则 None；之后按定义顺序读并哈希全部八份 proof；再检查三目标 cards 映射；最后检查传入 card 整行相等并 deepcopy EXPECTED。proof 缺失由 read_bytes 抛异常，字节改变抛 ValueError；不是静默返回 None。Python 的普通相等不是类型严格比较，本报告的严格匹配结论来自审计 exact 函数，不能转嫁成原工具的输入域保证。

当前 GD：raw_error/source_error/effect_error/unit_error 本身不读 proof。closure_error 先 proof_error，再对 source_catalog 或 self 和当前 catalog 的每个 IDS 调 source_error。Catalog 在 1692–1693 行先将 RUNTIME_PATHS 文本哈希加入 fingerprint；该 fingerprint 不是逐项固定哈希验收。raw 行校验/compiled 合并校验先于末段 source_error→closure_error。源码中虽然有四处相同输入校验片段，本审查只标记它们的静态位置，不推算运行次数。最小 Sources preload 图仅三个文件：spellteach_murloc_sources.gd、phase_undead_army_sources.gd、pool_identity.gd。

## 5. 新饰品来源的实际静态保护

unit_error 只做局部格式和程序校验，并不验证实际持有/购买记录。真实入口有额外保护，不能用只调 unit_error 的合成正例代替可达性证明：

- spellteach_trinket_host.prepare_buy 检查实际已拥有饰品槽、原槽收据、每轮最多两次、真实商店对象/command、既有收据、支付方式、手牌容量、无普通父体混合触发和其他未证购买顺序。
- paid/dispatch 检查实际 owner/context/command 对象身份、扣费、购买计数增加、从 shop 移出并进入 hand、原槽 ledger 与法术程序未变。新 binding 的 source_slot 和 acquired_event_index 来自实际 ledger，不来自任意传入 child；真实工厂结果还与 preview 逐值比较，并写事件。
- Cast.prepare 要求真实 recruit owner、实际 hand 对象与容量、command；先 `_entry_error`（unit_error→家族 closure→owner；饰品 binding 再走饰品 closure），随后调用 Spellteach.saved_error。
- saved_error 先 Owned.saved_receipts：核取得事件、唯一 owner、原 slot/event index、购买事件、次数/回放和完整绑定；再把仍持有单位的 TAUGHT 与对应收据逐字段比较。
- 当前 Game 的购买、付费、完成、饰品取得入口及 mechanism_effects 的取得/buy 事件均有静态接线。没有执行这些函数，没有验证完整交易回滚、战斗或存档。

精确源文件 pin 与行号见 ACTUAL_CALLER_EXCERPTS.txt、CURRENT_CODE_EXCERPTS.txt。上述结论是源码可见的保护，不是证明不存在任何其他调用或绕行。

## 6. 范围、资源和交付

审查完全本地、离线；不下载、不访问或重试已取消操作，不安装、不运行任何历史 Python 模块、完整 compiler、Catalog、Game、host、Godot 或存档。Python 均设置 128 MiB 地址空间限制；主审计峰值 RSS 43,304 KiB，调用侧审计 16,384 KiB。

初次计时命令因 /usr/bin/time 不存在而未启动 Python；初版审计解析器遇到上述真实补丁头粘连后停止，后改为显式记录异常并只提取负载；调用侧脚本曾有本地 Path 下标笔误，已修正后通过。失败日志保留，所有更改仅在新审计目录。不是项目代码测试失败，也没有修复原补丁。

主审计读取的 250 个源/既有证据文件均做结束后重新哈希不变校验；调用侧读取也单独回查。所有输出在本目录，文件清单与 SHA256 见 FILES_SHA256.json。

建议：保持暂停恢复/安装，结合父任务的独立定向测试决定下一步。即使定向测试通过，也仅支持该工具隔离复制与特定兼容域，不覆盖全 driver 来源、两项缺失预处理、全局四证据/两合同，以及游戏/存档验收。
