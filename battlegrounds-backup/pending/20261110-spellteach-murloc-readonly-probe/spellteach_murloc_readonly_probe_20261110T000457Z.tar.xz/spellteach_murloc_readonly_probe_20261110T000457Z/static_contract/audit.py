"""Read-only source audit; no project Python module imported or executed."""
import ast, collections, difflib, gzip, hashlib, json, pathlib, re, resource
import xml.etree.ElementTree as ET
resource.setrlimit(resource.RLIMIT_AS,(128*1024*1024,128*1024*1024))
W=pathlib.Path('/workspace/scratch/dd4f12b08ec0')
R=W/'historical_tools_batch14_20261109T191857Z/runtime'
F=R/'research/spellteach_murloc_native_recovery'
S=R/'research/spellteach_murloc_sources'
D=pathlib.Path(__file__).resolve().parent
M=W/'driver_mapping_contract_20261109T230410Z'
read_pins={}
def digest(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(65536),b''):h.update(b)
 return h.hexdigest()
def pin(p):
 row={'path':str(p.relative_to(W)),'bytes':p.stat().st_size,'sha256':digest(p)}
 read_pins[row['path']]=row
 return row
def dump(name,obj):(D/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
def exact(a,b):
 if type(a) is not type(b):return False
 if isinstance(a,dict):return a.keys()==b.keys() and all(exact(a[k],b[k]) for k in a)
 if isinstance(a,(list,tuple)):return len(a)==len(b) and all(exact(x,y) for x,y in zip(a,b))
 return a==b
def py_literals(p):
 pin(p);result={}
 for n in ast.parse(p.read_text()).body:
  if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name):
   try:result[n.targets[0].id]=ast.literal_eval(n.value)
   except (ValueError,TypeError):pass
 return result
def gd_literals(p):
 pin(p);result={}
 for line in p.read_text().splitlines():
  m=re.match(r'const (RAW|EXPECTED|PROGRAMS|PROOF_SHA256|RUNTIME_PATHS|IDS|PARENTS): \w+=(.*)',line)
  if m:result[m[1]]=json.loads(m[2])
 return result
def patch_sections(text):
 sections={};lines=text.splitlines(keepends=True);i=0
 while i<len(lines):
  if not lines[i].startswith('+++ '):i+=1;continue
  previous=lines[i-1] if i else '';old=previous[4:].strip() if previous.startswith('--- ') else None
  new=lines[i][4:].strip();i+=1;body=[]
  while i<len(lines) and not lines[i].startswith(('--- ','+++ ')):body.append(lines[i]);i+=1
  sections[new.removeprefix('b/')]={'old':old,'new':new,'body':body,'old_header_valid':old is not None,'line_before_new_header':previous.rstrip('\n')}
 return sections
def apply_memory(old,section):
 lines=old.splitlines(keepends=True);result=[];pos=0
 for line in section['body']:
  if line.startswith('@@ '):
   match=re.match(r'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@',line);assert match
   start=int(match[1]);count=int(match[2] or 1);at=start-1 if count else start
   assert at>=pos;result.extend(lines[pos:at]);pos=at
  elif line.startswith(' '):assert lines[pos]==line[1:];result.append(lines[pos]);pos+=1
  elif line.startswith('-'):assert lines[pos]==line[1:];pos+=1
  elif line.startswith('+'):result.append(line[1:])
  elif line.startswith('\\'):raise ValueError('unexpected no-newline marker')
  else:raise ValueError(repr(line))
 result.extend(lines[pos:]);return ''.join(result)
tool=F/'candidates/tools/spellteach_murloc_native_patterns.py'
oldgd=F/'candidates/core/spellteach_murloc_sources.gd';gd=R/'core/spellteach_murloc_sources.gd'
t=py_literals(tool);old=gd_literals(oldgd);now=gd_literals(gd);IDS=t['SOURCE_IDS'];RAW=t['RAW'];EXPECTED=t['EXPECTED']
manifest=json.loads((F/'manifest.json').read_text());pin(F/'manifest.json')
patch=F/'candidate.patch';patch_pin=pin(patch);sections=patch_sections(patch.read_text())
assert patch_pin['sha256']==manifest['patch']['sha256']
relevant=['tools/spellteach_murloc_native_patterns.py','core/spellteach_murloc_sources.gd','tools/build_effect_catalog.py']+list(t['PROOF_SHA256'])
checks=[]
for target in relevant:
 row=next(x for x in manifest['files'] if x['target']==target)
 candidate=R/row['candidate'];cp=pin(candidate);before=R/row['before_snapshot'] if row['before_snapshot'] else None
 original=before.read_text() if before else ''
 if before:assert pin(before)['sha256']==row['before_sha256']
 reconstructed=apply_memory(original,sections[target]).encode()
 checks.append({'target':target,'manifest':row,'candidate_pin':cp,'matches_manifest':cp['sha256']==row['after_sha256'],'patch_old_header_valid':sections[target]['old_header_valid'],'line_before_new_header':sections[target]['line_before_new_header'],'patch_reconstructed_payload_sha256':hashlib.sha256(reconstructed).hexdigest(),'patch_payload_matches_exact_candidate':reconstructed==candidate.read_bytes(),'current':pin(R/target) if (R/target).exists() else {'missing':True},'proof_pin':t['PROOF_SHA256'].get(target)})
 for c in ['matches_manifest','patch_payload_matches_exact_candidate']:assert checks[-1][c]
const_checks={k:{'history_equals_current_type_strict':exact(old[k],now[k]),'python_equals_current_type_strict':exact(t[k],now[k]) if k in t else None} for k in now}
const_checks['IDS']['python_equals_current_type_strict']=exact(list(IDS),now['IDS'])
for key,name in [('RAW','raw_rows.json'),('EXPECTED','expected_compiled.json'),('PROGRAMS','programs.json')]:
 value=json.loads((S/name).read_text());pin(S/name)
 const_checks[key]['current_equals_json_type_strict']=exact(now[key],value)
 const_checks[key]['python_equals_json_type_strict']=exact(t[key],value) if key in t else None
const_checks['effects_equal_programs']=all(exact(EXPECTED[i]['effects'],now['PROGRAMS'][i]) for i in IDS)
proof=[{'path':name,'expected_sha256':sha,'current_pin':pin(R/name),'current_matches':digest(R/name)==sha,'historical_candidate_matches':digest(F/'candidates'/name)==sha} for name,sha in t['PROOF_SHA256'].items()]
runtime=[{'path':name,'exists':(R/name).exists(),'pin':pin(R/name) if (R/name).exists() else None} for name in now['RUNTIME_PATHS']]
native=[]
for identity in IDS:
 p=S/'native'/f'{identity}.xml';root=ET.fromstring(p.read_text());tags={x.get('name'):x for x in root.findall('Tag')}
 text=tags['CARDTEXT'].findtext('zhCN');name=tags['CARDNAME'].findtext('zhCN')
 native.append({'id':identity,'entity_id':root.get('ID'),'card_id':root.get('CardID'),'name_matches_RAW':name==RAW[identity]['name'],'dbf_matches_RAW':root.get('ID')==RAW[identity]['dbf_id'],'native_tags':{k:tags[k].get('value') for k in ['ATK','HEALTH','TECH_LEVEL','CARDRACE','TAG_SCRIPT_DATA_NUM_1','BACON_EVOLUTION_CARD_ID','BACON_TRIPLE_UPGRADE_MINION_ID','BACON_TRIPLE_UPGRADE_MINION_ID','BATTLECRY','BACON_CANT_TRIPLE'] if k in tags},'body_matches_RAW':all(int(tags[tag].get('value'))==RAW[identity][field] for tag,field in [('ATK','attack'),('HEALTH','health'),('TECH_LEVEL','tier')]),'native_zhCN':text,'raw_text':RAW[identity]['text'],'coverage_text_hash_matches':hashlib.sha256(RAW[identity]['text'].encode()).hexdigest()==EXPECTED[identity]['coverage_text_sha256']})
dump('SOURCE_CONSISTENCY.json',{'tool':pin(tool),'historical_gd':pin(oldgd),'current_gd':pin(gd),'manifest':pin(F/'manifest.json'),'patch':patch_pin,'patch_boundary_warning':'Line 837 is +}--- /dev/null, not a standalone old-file header. contract.json added payload is exact, but whole patch is not claimed apply-ready. No original patch was changed.','patch_checks':checks,'constants':const_checks,'proof_checks':proof,'runtime_paths':runtime,'native':native,'scope':'Family-local source contract only; not the missing four global evidence artifacts or two global contracts.'})
delta=''.join(difflib.unified_diff(oldgd.read_text().splitlines(keepends=True),gd.read_text().splitlines(keepends=True),fromfile='a/core/spellteach_murloc_sources.gd',tofile='b/core/spellteach_murloc_sources.gd'))
(D/'HISTORICAL_CURRENT_GD.diff').write_text(delta)
trinket_patch=R/'research/spellteach_trinket_runtime/patches/core__spellteach_murloc_sources.gd.patch'
tp=pin(trinket_patch);reconstructed=apply_memory(oldgd.read_text(),patch_sections(trinket_patch.read_text())['core/spellteach_murloc_sources.gd'])
dump('GD_CHANGE_PROVENANCE.json',{'patch':tp,'exact_diff_equals_recorded_trinket_patch':delta==trinket_patch.read_text(),'recorded_patch_reconstructs_current_byte_exact':reconstructed.encode()==gd.read_bytes(),'reconstructed_sha256':hashlib.sha256(reconstructed.encode()).hexdigest(),'only_function_changed':'unit_error','all_parsed_constants_unchanged':all(exact(old[k],now[k]) for k in old)})

idxpath=W/'historical_tools_batch16_driver_closeout_20261109T205039Z/compiler/CURRENT_VERSIONS.json'
idx=json.loads(idxpath.read_text());pin(idxpath);drivers=[];forms=collections.defaultdict(list)
for row in idx:
 ev=M/'versions'/f"{row['sha256']}.json.gz";pin(ev);j=json.loads(gzip.decompress(ev.read_bytes()))
 calls=[c for c in j['whole_mapping_or_raw_argument_sites'] if c.get('function')=='compile_spellteach']
 p=R/row['paths'][0]['path'];assert pin(p)['sha256']==row['sha256'];ls=p.read_text().splitlines();hooks=[]
 assert len([line for line in ls if re.search(r'compile_spellteach\(',line)])==len(calls)
 for c in calls:
  n=c['line'];lo=n-4;hi=n+3;snippet='\n'.join(ls[lo-1:hi]);assert c['source'] in ls[n-1]
  forms[snippet].append(row['sha256']);hooks.append({'line':n,'call':c,'context_first_line':lo,'context':snippet,'pre_hook_whole_cards_sites':sum(x['line']<n and 'cards' in x['objects'] for x in j['whole_mapping_or_raw_argument_sites'])})
 drivers.append({'sha256':row['sha256'],'paths':row['paths'],'representative_source_sha_checked':True,'source_path_checked':str(p.relative_to(R)),'hook_count':len(calls),'hooks':hooks,'initialization':j['initialization'],'preprocess':j['preprocess'],'terminal_catalog_write':j['terminal'][0]})
dump('DRIVER_TARGET_CONTRACT.json',{'index':pin(idxpath),'version_count':len(drivers),'with_hook':sum(bool(v['hooks']) for v in drivers),'hook_count_distribution':dict(collections.Counter(v['hook_count'] for v in drivers)),'hook_forms':[{'source':s,'count':len(v),'versions':v} for s,v in forms.items()],'drivers':drivers,'scope':'Cached AST evidence reused only after hashing one concrete current source per version and checking target lines/count; no historical driver import/execution.'})

class Stream:
 def __init__(self,f):self.f=f;self.b='';self.p=0;self.dec=json.JSONDecoder()
 def fill(self):self.b=self.b[self.p:]+self.f.read(65536);self.p=0
 def ws(self):
  while True:
   while self.p<len(self.b) and self.b[self.p].isspace():self.p+=1
   if self.p<len(self.b):return
   self.fill()
   if not self.b:return
 def char(self):self.ws();return self.b[self.p] if self.p<len(self.b) else ''
 def take(self,c):assert self.char()==c,(self.char(),c);self.p+=1
 def val(self):
  self.ws()
  while True:
   try:v,e=self.dec.raw_decode(self.b,self.p);self.p=e;return v
   except json.JSONDecodeError:
    oldlen=len(self.b)-self.p;self.fill()
    if len(self.b)==oldlen:raise
 def rows(self):
  self.take('{');first=True;found=False
  while self.char()!='}':
   if not first:self.take(',')
   first=False;k=self.val();self.take(':')
   if k=='cards':
    assert not found;found=True;self.take('[');firstrow=True
    while self.char()!=']':
     if not firstrow:self.take(',')
     firstrow=False;yield self.val()
    self.take(']')
   else:self.val()
  self.take('}');assert not self.char();assert found
catalog=R/'core/catalog.gd';cs=catalog.read_text();pin(catalog);paths=json.loads(re.search(r'for path in (\["res://data/catalog_raw.json".*?\]):',cs).group(1))
files=[];target_occ=[];merged={}
for path in paths:
 p=R/path.removeprefix('res://');before=pin(p);hits=[];count=0
 with p.open() as f:
  for n,c in enumerate(Stream(f).rows()):
   count+=1;i=c.get('id')
   if i in IDS:
    hits.append({'index_zero_based':n,'ordinal_one_based':n+1,'id':i,'type_strict_equal_RAW':exact(c,RAW[i]),'type_strict_equal_EXPECTED':exact(c,EXPECTED[i]),'canonical_json_sha256':hashlib.sha256(json.dumps(c,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest(),'keys':list(c)})
    merged.setdefault(i,{}).update(c);target_occ.append({'path':path,'index_zero_based':n,'id':i})
 assert before['sha256']==digest(p)
 files.append({'path':path,'rows':count,'pin':before,'target_hits':hits})
pre=[]
for name in ['quest_identity_overrides.json','removed_hero_value_overrides.json','final_bg_source_overrides.json','catalog_value_overrides.json','season_presets.json']:
 p=R/'data'/name;b=p.read_text();obj=json.loads(b)
 pre.append({'pin':pin(p),'target_string_mentions':[i for i in IDS if i in b],'top_keys':list(obj),'target_override_ids':[x.get('id') for x in obj.get('overrides',[]) if x.get('id') in IDS]})
dump('CURRENT_TARGET_DATA.json',{'catalog':pin(catalog),'files':files,'target_occurrences':target_occ,'limited_direct_merge_not_full_catalog_execution':[{'id':i,'merged_equals_RAW_plus_EXPECTED_type_strict':exact(merged[i],dict(RAW[i],**EXPECTED[i]))} for i in IDS],'preprocessor_data':pre,'max_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss})
pending=['core/spellteach_murloc_sources.gd'];closure={}
while pending:
 path=pending.pop()
 if path in closure:continue
 p=R/path;deps=re.findall(r'preload\("res://([^\"]+)"\)',p.read_text())
 closure[path]={'pin':pin(p),'preloads':deps};pending.extend(deps)
dump('MINIMUM_PRELOAD_CLOSURE.json',closure)
def excerpt(p,ranges):
 ls=p.read_text().splitlines();pin(p);out=['FILE '+str(p.relative_to(W))+' SHA256 '+digest(p)]
 for a,b in ranges:out+=['\n'+ '\n'.join(f'{n}: {ls[n-1]}' for n in range(a,min(b,len(ls))+1))]
 return '\n'.join(out)
snips=[excerpt(gd,[(1,10),(16,77)]),excerpt(oldgd,[(61,71)]),excerpt(tool,[(8,17)]),excerpt(catalog,[(867,874),(1690,1695),(2100,2108),(2186,2208),(2468,2474),(4238,4244),(6079,6085),(7920,7926),(9761,9767),(11635,11651),(11810,11822),(12131,12141),(12152,12155),(13111,13115),(14838,14843),(15930,15933),(18797,18803)]),excerpt(R/'core/phase_undead_army_sources.gd',[(7,20)]),excerpt(R/'core/spellteach_murloc_host.gd',[(44,61)]),excerpt(R/'core/spellteach_murloc_cast.gd',[(13,38)])]
(D/'CURRENT_CODE_EXCERPTS.txt').write_text('\n\n'.join(snips)+'\n')
all_unchanged=[]
for p,expected in read_pins.items():
 actual=digest(W/p);all_unchanged.append({'path':p,'before':expected['sha256'],'after':actual,'unchanged':actual==expected['sha256']});assert actual==expected['sha256']
dump('SOURCE_PINS.json',list(read_pins.values()))
dump('READONLY_RECHECK.json',{'all_unchanged':all(x['unchanged'] for x in all_unchanged),'files':all_unchanged})
summary={'directory':str(D),'tool_missing_in_runtime':not (R/'tools/spellteach_murloc_native_patterns.py').exists(),'proofs_verified':len(proof),'proofs_all_match':all(x['current_matches'] and x['historical_candidate_matches'] for x in proof),'candidate_payloads_exact':len(checks),'well_formed_selected_patch_old_headers':sum(x['patch_old_header_valid'] for x in checks),'whole_candidate_patch_apply_ready_claim':False,'candidate_patch_malformed_contract_header':True,'gd_patch_reconstructs_current':reconstructed.encode()==gd.read_bytes(),'driver_versions':len(drivers),'drivers_with_hook':sum(bool(v['hooks']) for v in drivers),'hook_forms':len(forms),'catalog_inputs':len(files),'target_occurrences':target_occ,'minimum_preload_files':list(closure),'all_read_sources_unchanged':True,'max_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'not_run':['full compiler','Catalog','Game','host','save/load','Godot','historical Python module'],'no_global_artifact_recovery_claim':True}
dump('SUMMARY.json',summary);print(json.dumps(summary,ensure_ascii=False,indent=2))
