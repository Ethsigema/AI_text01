from copy import deepcopy

def all_floats(v):
 if type(v) is int:return float(v)
 if type(v) is dict:return {k:all_floats(x) for k,x in v.items()}
 if type(v) is list:return [all_floats(x) for x in v]
 return v

def mutate(value,case):
 op=case['op'];path=case['path']
 if op=='canonical':return value
 if op=='swap_parents':value[IDS[0]],value[IDS[1]]=value[IDS[1]],value[IDS[0]];return value
 if op=='rotate_all':return {IDS[i]:value[IDS[(i+1)%len(IDS)]] for i in range(len(IDS))}
 if op=='duplicate_row':return {i:deepcopy(value[case['target_id']]) for i in IDS}
 if op=='all_numbers_float':return all_floats(value)
 if op=='merged_card':value.update(deepcopy(original.EXPECTED[value['id']]));return value
 if op=='custom_card':
  ident=value['id'];value.update(deepcopy(original.EXPECTED[ident]));value['source_shop_fields']={'tier':3,'cost':None,'pool_supported':False};value['tier']=4;return value
 if op=='swap_rows':return {IDS[0]:value[IDS[1]],IDS[1]:value[IDS[0]]}
 if op=='duplicate_normal':return {IDS[0]:value[IDS[0]],IDS[1]:deepcopy(value[IDS[0]])}
 if op=='duplicate_golden':return {IDS[0]:value[IDS[1]],IDS[1]:deepcopy(value[IDS[1]])}
 if op=='invalid_root':return deepcopy(case['value'])
 if op=='id_only':return {'id':value['id']}
 if op=='extra_unrelated':value['not-a-source']={'id':'not-a-source'};return value
 if op=='invalid_member':value[path[0]]=None;return value
 parent=value
 for part in path[:-1]:parent=parent[part]
 old_value=parent[path[-1]] if path else value
 if op=='delete':del parent[path[-1]];return value
 if op=='replace_value':updated=deepcopy(case['value'])
 elif op=='id_swap':updated=next(i for i in IDS if i!=old_value)
 elif op=='replace_null':updated=None
 elif op=='replace_array':updated=[]
 elif op=='replace_dict':updated={}
 elif op=='null_to_zero':updated=0
 elif op=='reverse_dict':updated=dict(reversed(list(old_value.items())))
 elif op=='bool_to_int':updated=int(old_value)
 elif op=='bool_to_float':updated=float(old_value)
 elif op=='toggle_bool':updated=not old_value
 elif op=='numeric_float':updated=float(old_value)
 elif op=='numeric_int':updated=int(old_value)
 elif op=='number_delta':updated=old_value+1
 elif op=='number_string':updated=str(old_value)
 elif op=='number_bool':updated=bool(old_value)
 elif op=='change_string':updated=old_value+'__changed__'
 elif op=='null_to_false':updated=False
 elif op=='extra_key':updated=deepcopy(old_value);updated['__extra__']=True
 elif op=='append_item':updated=deepcopy(old_value);updated.append('__extra__')
 elif op=='reverse_list':updated=list(reversed(old_value))
 elif op=='nan':updated=float('nan')
 elif op=='pos_inf':updated=float('inf')
 elif op=='neg_inf':updated=float('-inf')
 else:raise AssertionError(op)
 if path:parent[path[-1]]=updated
 else:value=updated
 return value
