# 独立复核：魔鳍原工具与 GD 定向探针

## 结论

在本次有限输入域内，主调查的计数、原工具执行、精确历史调用 hook、proof 前置顺序与隔离性均得到独立复核。没有形成候选修正，也没有安装或恢复原工具。

新增 `unit_error` 类型边界探针发现当前 GD 的局部稳健性缺陷：绑定的 `source_id` 为 `true`、`1` 或 `[]` 时，当前 GD 第 66 行与字符串比较触发 Godot `Invalid operands`，随后取得空 String 返回；历史版本对此正常拒绝。空返回不能当作接受或测试通过。这是直接调用验证器的合成输入结论，不是实际购买、Game、host 或存档路径可达性证明。

整体结论仍只能是“特定隔离兼容域已验证，存在另列的类型边界问题”，不能升级为版本验收、完整恢复许可或游戏行为验收。

## 1. 独立方法与范围

- `review.py` 仅在本目录 `review_independent/` 写文件；原 runtime、旧证据、主 probe 输入未改。
- Python 设置 128 MiB 地址空间和 60 秒 CPU 上限，独立重建全部 1,197 个输入，执行固定原工具，以及从固定历史 driver AST 独立选出的 3 个节点。未 import 主调查的 `mutations.py`、比较器或测试驱动。
- 比较预期由独立的带类型标记结构表示计算：布尔值与数字分开，有限且数值相等的 int/float 归为同类；另以显式布尔数值归一化预测原 Python 相等域。原工具只是被测对象，不作为比较 oracle。
- 复核了主 Godot 两轮报告、脚本、无错误日志，以及 17 结构 / 17 效果 / 16 proof 变体 / 20 unit 绑定和追加 8 次类型边界运行。复核者未另跑 Godot，未运行完整 compiler/Catalog/Game/host/cast/存档。
- 全程本地，没有联网、下载、凭据或私聊访问。初次审查脚本因 Python `SOURCE_IDS` tuple 与 JSON list 的传输表示差异停止；只对常量导出比对做 JSON 规范化后完整通过，不是被测工具故障。

## 2. 原件、常量与版本

- 原工具 SHA256：`72a753e0ec02e8760ee920b1311bca0c58086da49dcd2fd506bf074adf0d1c8f`。
- 当前 GD SHA256：`11f8b3b06cc65b484ae379fbeaf825843df0f22d55c1887d23eba152d3b41ca5`。
- 历史 GD SHA256：`465267b111c12f3cba4a18eef1285ed0544340207139953ea57a548dc7072f6e`。
- 对 INPUT_PINS 中 22 个文件逐一校验 runtime 和 original_inputs 两处，共 44 次；独立校验 python_minimal、gd_minimal 的工具、三个当前 GD、一份历史 GD和全部八项 proof。结束后再次核对原件和 proof，全部未变。
- Python 与两版 GD 的 RAW、EXPECTED、PROOF_SHA256 对齐。精确重建历史到当前的 unified diff 与已有 patch 完全一致，仅一个 hunk，位于 unit_error 的 TAUGHT 分支。
- 这验证本地证据的字节一致性，不是外部来源认证。八项 proof 不包含执行代码自身的固定 pin，因此 proof 通过不能证明代码版本已验收。
- 静态配套报告指出整个历史 candidate.patch 第 837 行存在 `+}--- /dev/null` 粘连。工具自身新增节可独立提取，不能据此称整个补丁可以直接 apply；未应用、修复该补丁。单独历史到当前 GD patch 能解释差异，也不补足独立 before/after manifest。

## 3. 主 1,197 例与三成员覆盖

全部逐例重建、执行并核对成功：

- detached：324 例，原工具接受 150，严格组合接受 90，差异 60。
- coupled：276 例，原工具接受 150，严格组合接受 90，差异 60。
- companion：552 例，原工具接受 300，严格组合接受 180，差异 120。
- mapping_root：45 例，原工具和组合各接受 3，非法非字典根抛 AttributeError 21 例。
- 合计原工具接受 603、严格组合接受 363，差异 240。

独立枚举 RAW 的三个成员，每个包含 7 个布尔叶和 28 个整数叶；检查每一叶均覆盖应有变体。每个 target 都覆盖 detached、coupled 以及另外两个 identity 的 companion，包含父体→学徒、学徒→两父体等全部六个有向 companion 配对。没有把 companion 简化为普通/金色父体两者。

240 个差异全部为布尔与数值混等：bool→int 84、bool→float 84、number→bool 72。相等的 int/float 被原工具与 GD comparator 同时接受。NaN/±Inf 不与当前有限 RAW 值相等。

其中 24 个差异仅修改 raw.supported，固定 EXPECTED 合并把这个字段覆盖，因此最终合成 compiled closure 并未拒绝；对应 compiled closure 拒绝数为 216（detached 54、coupled 54、companion 108）。不能说“240 个差异全部被最终 closure 拦截”。detached 的 compiled projection 明确是假设性替换，不是实际 hook 输入。

## 4. 真正调用的对象、旧输出与声明域

实际执行节点来自固定历史 driver 的第 7421–7427 行：For、Assign、Expr；与保存的 DRIVER_EXACT_FRAGMENTS.py 逐字相同。

- 每次调用传入 `c is cards[identity]`，并传同一 cards 对象和隔离 root。detached 的独立 card 不会被这个 hook 使用。
- 正常完成时先删除目标旧输出；拒绝的目标不会保留 stale 结果；未相关输出保持不变，目标顺序重新按 SOURCE_IDS 追加。
- 非字典 cards 根在第一次 `.get` 前已 pop 第一个目标，随后抛 AttributeError：后两个旧输出仍在、旧 ordered_ids 未整理。这里只是失败中的局部内存状态；没有执行最终输出写入，不能称出现了持久化陈旧结果。
- 输出保持 deepcopy、partial 状态、pool_supported=false、default_pool=false，输入未变。

`_strict_ingress` 是“实际 raw_error + proof + 局部键/id 条件”的诊断组合，不是项目单一实际入口。复核开始时注释误称键/id 由 closure_error 强制，已通知父任务；父任务只更正注释，未改测试语义。

实际 closure_error 迭代键、取出行，source_error 随后使用行内 id 自选预期值，并不把外部键与行内 id 比较。因此完整行交换、三成员轮换、全键重复普通行，以及部分 custom override 组合在任意 ProbeCatalog 中可通过。这些测试均明确标记为任意映射反例，不能推成实际 Catalog/完整编译流水线会产生它们。真实目标 hook 的成功返回更窄：三个 keyed raw 行先逐项匹配，故本 hook 的输出键/id 一致。

## 5. proof 顺序与异常分类

在本目录新建独立 proof 变体，重跑八文件 × 改字节/缺失 × 三 identity = 48 个 Python 负例：

- 改字节抛 ValueError，错误消息精确包含对应 proof 相对路径。
- 缺失抛 FileNotFoundError。
- 已知 identity 的直接 compile_card 先查 proof，再碰非法 cards 根。
- 未知 identity 返回 None，不触发 proof；实际历史 hook 则先调用 cards.get，非法根可在进入 compile 前失败。
- 默认 root 指向隔离副本；所有原 proof 均保持原 SHA。

Godot 16 个 proof 变体报告中，当前/历史 proof_error 和 closure_error 一致，closure 在读取任何 ProbeCatalog 行之前拒绝，reads=0；raw_error 仍独立于 proof。八个文件均恢复，主两轮输出完全一致且 stderr 无 ERROR/SCRIPT ERROR。不能把 raw_error/source_error/effect_error/unit_error 的单独通过当作 proof 已验证。

## 6. unit 版本差异与追加错误证据

原 20 个 unit 探针中，当前接受 5 个，历史接受 3 个；新增接受的只有 owned_binding 和 owned_float_slot。配额上界、布尔配额、别名 UID、变更程序等按报告拒绝。合成 `PROBE_SPELL_NOT_EXECUTED` 卡仅有 probe_only effects，用来满足局部程序一致性检查，没有真实法术执行或实际购买证据。

追加 type_boundary_probe 的 8 次运行已逐份核对脚本、JSON 与日志：

- `source_id=true`、`1`、`[]`，每项两次，共 6 条 SCRIPT ERROR；均指向当前 `core/spellteach_murloc_sources.gd:66`。
- 当前语句 `row.get("source_id")=="BG35_MagicItem_750"` 在检查字段类型前执行，出现 bool/String、int/String、Array/String 的不合法比较。每次取得的空返回必须视为诊断异常后的结果，不能当作 validator 接受。
- 历史版通过 Array membership 正常返回 `spellteach_invalid_actual_purchase_binding`。null 控制两版都正常拒绝，无脚本错误。
- 追加探针明确无 Catalog、无 host、无 Game；进程 exit=0 是测试脚本自身 quit(0)，不消除发生的错误。

因此“主 1,197 例的两轮 GD 无错误”成立；“所有新增测试都无错误”不成立。报告须并列保留主结果与局部类型边界缺陷，不能把后者吸收到通过计数中。

## 交付与未越界结论

- `review.py`：可重跑独立复核脚本。
- `RESULTS.json`：计数、pin 检查与资源摘要。
- `CASE_RESULTS.json`：全部 1,197 例的独立预期与实际 hook 输出。
- `PROOF_RESULTS.json`：48 个独立 proof 负例。
- `RUN.stdout.log`：最近完整通过的运行输出。

本复核不改四份旧全局证据和两份旧全局合同的未找到边界；局部家族 contract.json 不替代它们。不扩大到完整历史 driver 不变式、Catalog 预处理等价、源版本验收、实际交易/施法/回滚或存档验收。

## 补充复核

新增的两份版本来源原件与副本均逐字核对：饰品 GD patch SHA256 为 `fb539de8decbf886975ca69e21c66dd023d99512a202c7dd1ac5e1bdd1bf0474`，author_patches.py 为 `1955bb3d68aa0a498e06b51b0fd256a26c30fae6a09c0f0483ccbbdd718066e4`。原单独 GD patch 与 static_contract/HISTORICAL_CURRENT_GD.diff 逐字相同；与主调查 HISTORICAL_TO_CURRENT_GD.patch 仅头部标签不同（a/b 对 historical/current），hunk 完全一致。原 22 项主输入不变，这两项单列在 ADDITIONAL_CHECKS.json。

耦合与 companion 的 180 次差异调用按 target/path/op 去重，确为 60 个不同变异规格；其中 54 个在合成 EXPECTED overlay 后仍拒绝，6 个 supported 类型变异被覆盖恢复。这个去重按测试输入变异规格，不是完整流水线事故计数。

便携复跑当时由父任务另行进行，不包含在本复核的执行声明中。
