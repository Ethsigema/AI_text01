#!/usr/bin/env python3
"""Bounded independent read-only review; writes only beside this script.
The historical compiler and exact three driver AST nodes are subjects, never oracles.
Expected row equality uses independently tagged structural values, not either tool's comparator.
"""
import ast, collections, copy, difflib, hashlib, json, math, resource, sys, types
from pathlib import Path
resource.setrlimit(resource.RLIMIT_AS, (128*1024**2, 128*1024**2))
resource.setrlimit(resource.RLIMIT_CPU, (60, 60))
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent; H=HERE.parent
R=H.parent/'historical_tools_batch14_20261109T191857Z/runtime'
F='research/spellteach_murloc_native_recovery/'
TOOL=F+'candidates/tools/spellteach_murloc_native_patterns.py'
DRIVER=F+'candidates/tools/build_effect_catalog.py'
def readj(p): return json.loads(p.read_text())
def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def tag(v, loose=False):
    # Independent representation: bool is separate unless modeling Python numeric equality.
    t=type(v)
    if t is bool: return ('number',int(v)) if loose else ('bool',v)
    if t in (int,float):
        if t is float and not math.isfinite(v): return ('nonfinite',repr(v))
        return ('number',v)
    if t is dict: return ('object',tuple(sorted((k,tag(x,loose)) for k,x in v.items())))
    if t is list: return ('array',tuple(tag(x,loose) for x in v))
    if t is tuple: return ('tuple',tuple(tag(x,loose) for x in v))
    return (t.__name__,v)
def floats(v):
    if type(v) is int:return float(v)
    if type(v) is dict:return {k:floats(x) for k,x in v.items()}
    if type(v) is list:return [floats(x) for x in v]
    return v
source=(R/TOOL).read_text(); tree=ast.parse(source)
C={n.targets[0].id:ast.literal_eval(n.value) for n in tree.body if isinstance(n,ast.Assign)}
RAW=C['RAW']; IDS=C['SOURCE_IDS']; EXPECTED=C['EXPECTED']; PROOFS=C['PROOF_SHA256']
assert digest(R/TOOL)=='72a753e0ec02e8760ee920b1311bca0c58086da49dcd2fd506bf074adf0d1c8f'
assert tag(json.loads(json.dumps(C)))==tag(readj(H/'CONSTANTS.json'))
pins=readj(H/'INPUT_PINS.json'); pin_checks=[]
for rel,pin in pins.items():
    for place,base in [('runtime',R),('original_inputs',H/'original_inputs')]:
        p=base/rel
        assert p.stat().st_size==pin['bytes'] and digest(p)==pin['sha256'], (place,rel)
        pin_checks.append({'place':place,'path':rel,'sha256':pin['sha256']})
for base in [H/'python_minimal',H/'gd_minimal']:
    for rel,sha in PROOFS.items():assert digest(base/rel)==sha
assert digest(H/'python_minimal/tools/spellteach_murloc_native_patterns.py')==digest(R/TOOL)
for rel in ['core/spellteach_murloc_sources.gd','core/phase_undead_army_sources.gd','core/pool_identity.gd']:
    assert digest(H/'gd_minimal'/rel)==digest(R/rel)
old=(R/(F+'candidates/core/spellteach_murloc_sources.gd')).read_text(); new=(R/'core/spellteach_murloc_sources.gd').read_text()
assert digest(H/'gd_minimal/historical/spellteach_murloc_sources.gd')==hashlib.sha256(old.encode()).hexdigest()
patch=''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='historical/core/spellteach_murloc_sources.gd',tofile='current/core/spellteach_murloc_sources.gd'))
assert patch==(H/'HISTORICAL_TO_CURRENT_GD.patch').read_text()
assert len([l for l in patch.splitlines() if l.startswith('@@')])==1
for gd in [old,new]:
    vals={}
    for l in gd.splitlines():
        if l.startswith('const ') and ': Dictionary=' in l:
            name=l.split()[1].rstrip(':'); vals[name]=json.loads(l.split('=',1)[1])
    for key in ['RAW','EXPECTED','PROOF_SHA256']:assert tag(vals[key])==tag(C[key])

def mutate(v,c):
    op=c['op']; path=c['path']
    if op=='canonical':return v
    if op=='all_numbers_float':return floats(v)
    if op=='invalid_root':return copy.deepcopy(c['value'])
    if op=='swap_parents':return {**v,IDS[0]:v[IDS[1]],IDS[1]:v[IDS[0]]}
    if op=='rotate_all':return {key:v[IDS[(j+1)%3]] for j,key in enumerate(IDS)}
    if op=='duplicate_row':return {key:copy.deepcopy(v[c['target_id']]) for key in IDS}
    if op=='extra_unrelated':return {**v,'not-a-source':{'id':'not-a-source'}}
    if op=='id_only':return {'id':v['id']}
    if op=='merged_card':return {**v,**copy.deepcopy(EXPECTED[v['id']])}
    parent=v
    for key in path[:-1]:parent=parent[key]
    x=parent[path[-1]] if path else v
    if op=='delete':del parent[path[-1]];return v
    ops={'change_string':lambda:x+'__changed__','id_swap':lambda:next(i for i in IDS if i!=x),
         'extra_key':lambda:{**x,'__extra__':True},'number_delta':lambda:x+1,
         'number_string':lambda:str(x),'nan':lambda:float('nan'),'pos_inf':lambda:float('inf'),
         'neg_inf':lambda:float('-inf'),'replace_null':lambda:None,'replace_array':lambda:[],
         'numeric_float':lambda:float(x),'number_bool':lambda:bool(x),'bool_to_int':lambda:int(x),
         'bool_to_float':lambda:float(x),'toggle_bool':lambda:not x,'replace_value':lambda:copy.deepcopy(c['value'])}
    y=ops[op]()
    if path:parent[path[-1]]=y;return v
    return y

def inputs(c):
    cards=copy.deepcopy(RAW); card=copy.deepcopy(RAW[c['identity']])
    if c['regime']=='detached':card=mutate(card,c)
    elif c['regime'] in ('coupled','companion'):
        cards[c['target_id']]=mutate(cards[c['target_id']],c);card=cards[c['identity']]
    else:cards=mutate(cards,c)
    return card,cards

def raw_ok(card,loose=False):
    if type(card) is not dict or type(card.get('id')) is not str or card['id'] not in IDS:return False
    return tag(card,loose)==tag(RAW[card['id']],loose)
def expected_direct(card,cards):
    if type(card) is not dict or type(card.get('id')) is not str or card['id'] not in IDS:return False,None
    if type(cards) is not dict:return False,'AttributeError'
    return raw_ok(card,True) and all(tag(cards.get(i),True)==tag(RAW[i],True) for i in IDS),None

def strict_ok(card,cards):
    return raw_ok(card) and type(cards) is dict and all(raw_ok(cards.get(i)) and cards[i]['id']==i for i in IDS)

# Subject is executed only after import/top-level AST verification.
for n in tree.body:
    if isinstance(n,ast.Assign):ast.literal_eval(n.value)
    elif isinstance(n,ast.ImportFrom):assert n.module in ('copy','pathlib')
    elif isinstance(n,ast.Import):assert [x.name for x in n.names]==['hashlib']
    else:assert isinstance(n,ast.FunctionDef) and n.name=='compile_card'
subject=types.ModuleType('independent_review_subject');subject.__file__=str(H/'python_minimal/tools/spellteach_murloc_native_patterns.py')
exec(compile(tree,str(R/TOOL),'exec'),subject.__dict__)
ds=(R/DRIVER).read_text(); dt=ast.parse(ds)
start=next(k for k,n in enumerate(dt.body) if isinstance(n,ast.For) and isinstance(n.iter,ast.Name) and n.iter.id=='SPELLTEACH_IDS')
nodes=dt.body[start:start+3]
assert [type(x).__name__ for x in nodes]==['For','Assign','Expr']
assert '\n\n'.join(ast.get_source_segment(ds,n) for n in nodes)+'\n'==(H/'DRIVER_EXACT_FRAGMENTS.py').read_text()
hook=compile(ast.Module(body=nodes,type_ignores=[]),'independently_selected_exact_hook','exec')
cases=readj(H/'CASES.json'); pr=readj(H/'PYTHON_REPORT.json'); gd=readj(H/'GODOT_first.json'); gd2=readj(H/'GODOT_repeat.json')
assert gd==gd2 and not gd['failures'];assert len(cases)==len(pr['results'])==len(gd['results'])==1197
counts=collections.defaultdict(collections.Counter); gaps=[]; masked=[]; outcomes=[]
for c,p,g in zip(cases,pr['results'],gd['results']):
    assert c['label']==p['label']==g['label']
    card,cards=inputs(c); before=repr((card,cards)); expected,error=expected_direct(card,cards)
    out=None; actual_error=None
    try:out=subject.compile_card(card,cards,root=H/'python_minimal')
    except Exception as e:actual_error=type(e).__name__
    assert (out is not None,actual_error)==(expected,error)==(p['original_accept'],p['original_error']),c
    assert repr((card,cards))==before
    if out is not None:assert tag(out)==tag(EXPECTED[card['id']])
    strict=strict_ok(card,cards); raw=raw_ok(card)
    assert strict==g['strict_accept'] and raw==g['actual_raw_accept']==g['historical_raw_accept'],c
    stale={key:{'id':key,'stale':True} for key in IDS};stale['unrelated']={'id':'unrelated','keep':True}
    order=['unrelated']+list(reversed(IDS)); calls=[]
    def called(row,all_rows,root):
        calls.append((ns['identity'],row is all_rows.get(ns['identity']),all_rows is cards,root==H/'python_minimal'))
        return subject.compile_card(row,all_rows,root=root)
    ns={'SPELLTEACH_IDS':IDS,'cards':cards,'out':copy.deepcopy(stale),'ordered_ids':order.copy(),'R':H/'python_minimal','compile_spellteach':called}
    he=None
    try:exec(hook,ns)
    except Exception as e:he=type(e).__name__
    assert he==p['actual_hook_error']
    emitted=[i for i in IDS if i in ns['out'] and not ns['out'][i].get('stale',False)]
    if type(cards) is dict:
        want=[i for i in IDS if expected_direct(cards.get(i),cards)[0]]
        assert emitted==want and ns['ordered_ids']==['unrelated']+want
        assert all(all(t[1:]) for t in calls)
        assert not any(ns['out'].get(i,{}).get('stale') for i in IDS)
    else:
        assert he=='AttributeError' and not calls and ns['ordered_ids']==order
        assert IDS[0] not in ns['out'] and all(ns['out'][i]==stale[i] for i in IDS[1:])
    assert ns['out']['unrelated']==stale['unrelated'] and emitted==p['actual_hook_emitted_ids']
    assert repr((card,cards))==before
    cnt=counts[c['regime']];cnt['cases']+=1;cnt['original_accept']+=expected;cnt['strict_accept']+=strict;cnt['original_exceptions']+=error is not None
    if expected and not strict:
        cnt['gap']+=1;gaps.append(c)
        assert c['op'] in ('bool_to_int','bool_to_float','number_bool')
        if g['compiled_closure_error']=='':masked.append(c)
    outcomes.append({'label':c['label'],'expected_python_accept':expected,'expected_python_error':error,'expected_diagnostic_strict_accept':strict,'actual_hook_emitted_ids':emitted})
assert sum(v['original_accept'] for v in counts.values())==603
assert sum(v['strict_accept'] for v in counts.values())==363
assert len(gaps)==240 and len(masked)==24
# Independently enumerate bool/numeric paths, requiring all six ordered companion targets.
def leaves(v,path=()):
    if type(v) is dict:
        for k,x in v.items():yield from leaves(x,path+(k,))
    elif type(v) is list:
        for k,x in enumerate(v):yield from leaves(x,path+(k,))
    else:yield path,v
coverage=[]
case_keys={(c['regime'],c['identity'],c['target_id'],tuple(c['path']),c['op']) for c in cases}
assert len({json.dumps({k:v for k,v in c.items() if k!='label'},sort_keys=True) for c in cases})==len(cases)
for target,row in RAW.items():
    roles=[('detached',target),('coupled',target)]+[('companion',i) for i in IDS if i!=target]
    numeric=boolean=0
    for path,v in leaves(row):
        ops=['bool_to_int','bool_to_float','toggle_bool'] if type(v) is bool else ['numeric_float','number_bool'] if type(v) is int else []
        boolean+=type(v) is bool;numeric+=type(v) is int
        for role,identity in roles:
            for op in ops:assert (role,identity,target,path,op) in case_keys
    coverage.append({'target':target,'bool_leaves':boolean,'numeric_leaves':numeric,'roles':roles})
# Proof order and exception taxonomy independently replayed under new review-owned roots.
proof_results=[]
for k,(rel,sha) in enumerate(PROOFS.items()):
    for mode in ('changed_bytes','missing'):
        root=HERE/'proof_replay'/f'{k:02d}_{mode}'
        for src in PROOFS:
            if src==rel and mode=='missing':continue
            dest=root/src;dest.parent.mkdir(parents=True,exist_ok=True)
            dest.write_bytes((H/'python_minimal'/src).read_bytes()+(b' ' if src==rel and mode=='changed_bytes' else b''))
        typ='ValueError' if mode=='changed_bytes' else 'FileNotFoundError'
        for identity in IDS:
            try:subject.compile_card(copy.deepcopy(RAW[identity]),copy.deepcopy(RAW),root=root)
            except Exception as e:
                assert type(e).__name__==typ
                if typ=='ValueError':assert str(e)=='spellteach_murloc_native_proof_changed:'+rel
            else:raise AssertionError('Proof should reject')
            proof_results.append({'path':rel,'mode':mode,'identity':identity,'exception':typ})
        assert subject.compile_card({'id':'foreign'},None,root=root) is None
        try:subject.compile_card(copy.deepcopy(RAW[IDS[0]]),None,root=root)
        except Exception as e:assert type(e).__name__==typ
        else:raise AssertionError('Proof precedes invalid mapping')
for i in IDS:
    a=subject.compile_card(copy.deepcopy(RAW[i]),copy.deepcopy(RAW));b=subject.compile_card(copy.deepcopy(RAW[i]),copy.deepcopy(RAW))
    assert tag(a)==tag(EXPECTED[i]);a['effects'][0]['review_only']=True;a['conditional_support']['review_only']=True
    assert tag(b)==tag(EXPECTED[i]) and tag(subject.EXPECTED[i])==tag(EXPECTED[i])
    assert b['pool_supported'] is False and b['default_pool'] is False and b['implementation_status']=='partial_pending_unified_validation'
# Preserve original/new input integrity; only review_independent has been written.
for row in pin_checks:assert digest((R if row['place']=='runtime' else H/'original_inputs')/row['path'])==row['sha256']
for base in [H/'python_minimal',H/'gd_minimal']:
    for rel,sha in PROOFS.items():assert digest(base/rel)==sha
summary={'passed':True,'pin_files':len(pins),'pin_checks':len(pin_checks),'cases_independently_reconstructed_and_replayed':len(cases),'by_regime':dict(counts),'raw_gap_cases':len(gaps),'raw_gap_by_operation':dict(collections.Counter(x['op'] for x in gaps)),'fixed_output_merge_masks_cases':len(masked),'masked_paths':dict(collections.Counter('.'.join(map(str,x['path'])) for x in masked)),'case_coverage':coverage,'proof_replays':len(proof_results),'godot_reports_exact_match':True,'godot_rerun_by_reviewer':False,'gd_version_diff_hunks':1,'hook_nodes':[{'kind':type(n).__name__,'first':n.lineno,'last':n.end_lineno} for n in nodes],'source_integrity_after':True,'max_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
# Supplementary Godot evidence is inspected, not rerun by this reviewer.
assert len(gd['structural_probes'])==17 and len(gd['effect_probes'])==17 and len(gd['proof_tests'])==16 and len(gd['historical_current_unit_probes'])==20
for run in ('first','repeat'):
    log=(H/f'GODOT_{run}.stderr.log').read_text()
    assert 'ERROR:' not in log and 'SCRIPT ERROR' not in log
for test in gd['proof_tests']:
    assert test['current_error']==test['historical_error']==test['closure_error']=='spellteach_native_proof_changed:'+test['path']
    assert test['catalog_reads_before_reject']==0 and test['raw_gate_remains_independent'] and test['isolated_copy_restored']
for test in gd['historical_current_unit_probes']:
    assert test['synthetic_validation_only_not_actual_purchase_or_cast']
current_yes={x['case'] for x in gd['historical_current_unit_probes'] if x['current_accept']}
historical_yes={x['case'] for x in gd['historical_current_unit_probes'] if x['historical_accept']}
assert current_yes=={'parent_binding','owned_binding','owned_float_slot','normal_quota_1','golden_quota_2'}
assert historical_yes=={'parent_binding','normal_quota_1','golden_quota_2'}
bd=H/'type_boundary_probe'; boundary=readj(bd/'RESULT.json'); error_count=0
for record in boundary['records']:
    label=record['case']; repeat=record['repeat']; log=(bd/f'{label}_{repeat}.stderr.log').read_text(); actual=readj(bd/f'{label}_{repeat}.json')
    assert actual['historical_return']=='spellteach_invalid_actual_purchase_binding'
    assert actual['historical_return']==record['historical_return'] and actual['current_return']==record['current_return']
    if label=='null':assert not log and actual['current_return']=='spellteach_invalid_actual_purchase_binding'
    else:
        assert log.count('SCRIPT ERROR:')==1 and 'Invalid operands' in log and 'res://core/spellteach_murloc_sources.gd:66' in log
        assert actual['current_return']=='' and record['current_empty_return_is_not_acceptance'];error_count+=1
    assert (bd/f'{label}_1.json').read_bytes()==(bd/f'{label}_2.json').read_bytes()
assert len(boundary['records'])==8 and error_count==6
summary['supplementary_godot_evidence_inspected']={'structural':17,'effect':17,'proof_variants':16,'unit_bindings':20,'type_boundary_runs':8,'type_boundary_diagnostics':6,'reviewer_executed_Godot':False}
(HERE/'RESULTS.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
(HERE/'CASE_RESULTS.json').write_text(json.dumps(outcomes,ensure_ascii=False,indent=2)+'\n')
(HERE/'PROOF_RESULTS.json').write_text(json.dumps(proof_results,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(summary,ensure_ascii=False,indent=2))
