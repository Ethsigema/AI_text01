extends RefCounted
# Actual hand-play custody only. This does NOT certify a Darkcrest birth.
const Sources=preload("res://core/darkcrest_sources.gd")
const ID: String="BG23_009"
const KEYS: Array=["uid","card_id","name","kind","tier","attack","health","max_health","keywords","tribes","effects","golden","cost","temporary","is_spellcraft","temporary_buffs","permanent_keywords","text","image","pool_count","spellcraft_kept","spell_triggers","attachments","pool_components","magnetic_tribes","individually_frozen","blood_gems_received_turn","recruit_shop_bonus_applied","recruit_shop_aura_attack","recruit_shop_aura_health","golden_rebase_state","pool_id","pool_kind","base_unit","silenced","abilities_disabled","_pending_destroy"]
var _pending: Dictionary={}
var _board: Dictionary={}
static func shape_error(host,game,u: Dictionary) -> String:
	if u.get("card_id")!=ID: return "darkcrest_lava_wrong_identity"
	var issue: String=host.hand_state_error(u,game.catalog.get_card(ID),game.Rider.UNIT_FIELDS)
	if issue.is_empty(): issue=game.LimitedTurn.validate_unit_state(u,game.state.round)
	if not issue.is_empty(): return issue
	for key in u:
		if key not in KEYS: return "darkcrest_lava_unreviewed_field:"+str(key)
	for key in ["attack","health","max_health","spellcraft_kept"]:
		if not u.get(key) is int: return "darkcrest_lava_noninteger_state"
	if u.attack!=2 or u.health!=5 or u.max_health!=5 or u.spellcraft_kept!=0: return "darkcrest_lava_modified_or_used"
	return ""
func _actual(host,game,p: Dictionary) -> bool:
	if not host is RefCounted or not game is RefCounted: return false
	var host_script: Variant=host.get_script()
	var game_script: Variant=game.get_script()
	if not host_script is Script or host_script.resource_path!="res://core/darkcrest_host.gd" or not game_script is Script or game_script.resource_path!="res://core/game.gd": return false
	if not game.state.get("players") is Array: return false
	return is_same(game._darkcrest_host,host) and is_same(host._lava_play,self) and p.get("id") is int and p.id>=0 and p.id<game.state.players.size() and is_same(game.state.players[p.id],p)
static func _context_matches(context: Dictionary,p: Dictionary,u: Dictionary,index: int,position: int,round_number: int,sequence: int,nonce: RefCounted) -> bool:
	return context.size()==8 and context.get("origin") is String and context.origin=="actual_hand_play" and is_same(context.get("owner"),p) and is_same(context.get("unit"),u) and is_same(context.get("nonce"),nonce) and context.get("index") is int and context.index==index and context.get("position") is int and context.position==position and context.get("round") is int and context.round==round_number and context.get("sequence") is int and context.sequence==sequence
static func _unique(game,u: Dictionary) -> bool:
	var count: int=0
	for owner in game.state.players+game.state.get("ghosts",[]):
		for zone in ["board","hand","shop"]:
			for other in owner.get(zone,[]):
				if is_same(other,u) or other.get("uid")==u.get("uid"): count+=1
	return count==1
func preflight(host,game,p: Dictionary,u: Dictionary) -> String:
	if not _actual(host,game,p) or game.state.phase!="recruit": return "darkcrest_lava_actual_hand_play_required"
	if not p.hand.any(func(actual):return is_same(actual,u)) or not _unique(game,u): return "darkcrest_lava_original_unique_hand_required"
	if p.board.any(func(other):return not host.parent(other)) or p.board.size()>=7: return "darkcrest_lava_single_board_entry_held"
	if host.count(p,ID)>1: return "darkcrest_lava_multiple_copies_held"
	if _board.has(u.get("uid")): return "darkcrest_lava_replayed_entry"
	return shape_error(host,game,u)
func begin(host,game,p: Dictionary,index: int,context: Dictionary) -> String:
	if not _pending.is_empty(): return "darkcrest_lava_nested_play"
	if not _actual(host,game,p) or index<0 or index>=p.hand.size(): return "darkcrest_lava_actual_hand_play_required"
	if not is_same(context,game._darkcrest_lava_play_context) or context.size()!=8 or not context.get("position") is int or context.get("origin")!="actual_hand_play" or not context.get("nonce") is RefCounted or not is_same(context.nonce,game._darkcrest_lava_play_nonce): return "darkcrest_lava_native_play_context_required"
	var u: Dictionary=p.hand[index]
	if not _context_matches(context,p,u,index,context.position,game.state.round,game.state.command_sequence,game._darkcrest_lava_play_nonce): return "darkcrest_lava_changed_native_play_context"
	var issue: String=preflight(host,game,p,u)
	if not issue.is_empty(): return issue
	_pending={"engine":weakref(game),"owner":p,"unit":u,"context":context,"nonce":context.nonce,"index":index,"round":game.state.round,"sequence":game.state.command_sequence,"hand":p.hand.duplicate(),"hand_values":p.hand.duplicate(true),"board":p.board.duplicate(),"board_values":p.board.duplicate(true),"snapshot":u.duplicate(true),"requested_position":context.position,"position":context.position if context.position>=0 and context.position<=p.board.size() else p.board.size()}
	return ""
func complete(host,game,p: Dictionary,context: Dictionary) -> String:
	if _pending.is_empty(): return "darkcrest_lava_unbound_play_completion"
	var r: Dictionary=_pending
	if not _actual(host,game,p) or not is_same(r.engine.get_ref(),game) or not is_same(r.owner,p) or not is_same(context,r.context) or not is_same(context,game._darkcrest_lava_play_context) or not is_same(r.nonce,game._darkcrest_lava_play_nonce) or game.state.phase!="recruit" or game.state.round!=r.round or game.state.command_sequence!=r.sequence: return "darkcrest_lava_changed_play_completion"
	var u: Dictionary=r.unit
	if not _context_matches(context,p,u,r.index,r.requested_position,r.round,r.sequence,r.nonce): return "darkcrest_lava_mutated_play_context"
	var hand: Array=r.hand.duplicate();hand.remove_at(r.index)
	var hand_values: Array=r.hand_values.duplicate(true);hand_values.remove_at(r.index)
	if not host.Generation._same_objects(p.hand,hand) or not Sources.same(p.hand,hand_values) or not _unique(game,u) or p.board.size()!=r.board.size()+1: return "darkcrest_lava_nonunique_native_insertion"
	var board: Array=p.board.duplicate();var position: int=board.find(u)
	if position!=r.position or position<0 or not is_same(board[position],u): return "darkcrest_lava_original_board_object_required"
	board.remove_at(position)
	if not host.Generation._same_objects(board,r.board) or not Sources.same(board,r.board_values) or not Sources.same(u,r.snapshot): return "darkcrest_lava_changed_native_play_suffix"
	var issue: String=shape_error(host,game,u)
	if not issue.is_empty(): return issue
	_board[u.uid]={"engine":weakref(game),"owner":p,"unit":u,"snapshot":u.duplicate(true)}
	_pending={}
	return ""
func cancel() -> void:
	_pending={}
func board_error(host,game,p: Dictionary,u: Dictionary) -> String:
	var r: Dictionary=_board.get(u.get("uid"),{})
	if not _actual(host,game,p) or r.is_empty() or not is_same(r.engine.get_ref(),game) or not is_same(r.owner,p) or not is_same(r.unit,u) or not p.board.any(func(actual):return is_same(actual,u)) or not _unique(game,u): return "darkcrest_lava_unissued_board_entity"
	if not Sources.same(u,r.snapshot): return "darkcrest_lava_board_state_changed"
	return shape_error(host,game,u)
