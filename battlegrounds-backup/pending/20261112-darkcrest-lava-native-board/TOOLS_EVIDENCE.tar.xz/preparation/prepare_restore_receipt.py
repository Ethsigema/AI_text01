"""Archive only completed restore receipts/tools; never touches live Game evidence."""
from pathlib import Path
import json,hashlib,shutil,tarfile,io,datetime
ROOT=Path(__file__).resolve().parent.parent;R=ROOT/'remote_snapshot_5d98887';P=ROOT/'restore_receipt_package'
def sha(b):return hashlib.sha256(b).hexdigest()
def enc(j):return (json.dumps(j,indent=2,sort_keys=True)+'\n').encode()
def main():
 import argparse
 ap=argparse.ArgumentParser();ap.add_argument('--execute',action='store_true',required=True);ap.parse_args()
 assert not P.exists();d=json.loads((R/'FRESH_PACKAGE_DOWNLOAD_VERIFIED.json').read_text());assert d['source_commit']=='5d988875054ad4eea47d6615f8a9fdd65bfe7b4d' and d['files']==17
 for row in d['records']:
  b=(R/'package'/row['filename']).read_bytes();assert len(b)==row['bytes'] and sha(b)==row['sha256']
 restore=json.loads((R/'INDEPENDENT_RESTORE_VERIFIED.json').read_text());assert restore['source_commit']==d['source_commit'] and not restore['game_started'] and not restore['gameplay_acceptance']
 fixed=json.loads((R/'FIX_EVIDENCE_VERIFIED.json').read_text());assert fixed['members']==23 and fixed['every_member_rehashed']
 shutil.copytree(R/'package',P)
 tools={}
 names=['preparation/run_remote_lava.py','preparation/audit_lava_attempt.py','preparation/REMOTE_RUNNER_PREPARATION_VERIFIED.json','preparation/prepare_restore_receipt.py','preparation/repin_candidate.py','preparation/synthetic_validator_tests.py','preparation/SYNTHETIC_VALIDATOR_RESULT.json','fresh_remote/download_fresh.py','fresh_remote/verify_baseline.py','fresh_remote/snapshot_tools/common.py','fresh_remote/snapshot_tools/build_unaccepted.py','fresh_remote/snapshot_tools/add_frozen_evidence.py','fresh_remote/snapshot_tools/restore_fixed_remote.py','fresh_remote/snapshot_tools/verify_remote_evidence.py','fresh_remote/snapshot_tools/PREPARATION_VERIFIED.json','fresh_remote/snapshot_tools/FIXED_REMOTE_5d98887_METADATA.json']
 selected={n:sha((ROOT/n).read_bytes()) for n in names}
 assert selected['preparation/run_remote_lava.py']=='c4c7368aee2bb41f7a2dd371e1802e17b9a841c41e0df11964045307d393edc3'
 assert selected['preparation/audit_lava_attempt.py']=='172ff749712a3daa41cc3ed9a904efa8f3d24955debac95b9e5af16c3ee5fff9'
 (ROOT/'RESTORE_TOOL_SELECTION.json').write_bytes(enc(selected))
 for n in names:
  p=ROOT/n;before=p.stat();b=p.read_bytes();after=p.stat();assert (before.st_size,before.st_mtime_ns)==(after.st_size,after.st_mtime_ns),n;assert sha(b)==selected[n],n;tools[n]=b
 tools['TOOL_SNAPSHOT_NOTE.json']=enc({'captured_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'completed tool source snapshot only; no live test logs or HOME/cache','gameplay_acceptance':False,'some_tools_are_prepared_not_executed':True})
 with tarfile.open(P/'TOOLS_EVIDENCE.tar.xz','w:xz') as t:
  for n,b in sorted(tools.items()):
   x=tarfile.TarInfo(n);x.size=len(b);x.mode=0o644;x.mtime=0;t.addfile(x,io.BytesIO(b))
 members={n:{'bytes':len(b),'sha256':sha(b)} for n,b in tools.items()}
 with tarfile.open(P/'TOOLS_EVIDENCE.tar.xz') as t:assert {x.name:{'bytes':x.size,'sha256':sha(t.extractfile(x).read())} for x in t}==members
 (P/'TOOLS_EVIDENCE_MANIFEST.json').write_bytes(enc({'source_commit':d['source_commit'],'archive_sha256':sha((P/'TOOLS_EVIDENCE.tar.xz').read_bytes()),'members':members}))
 for source,dest in [('INDEPENDENT_RESTORE_VERIFIED.json','REMOTE_SNAPSHOT_RESTORE_VERIFIED.json'),('FIX_EVIDENCE_VERIFIED.json','REMOTE_FIX_EVIDENCE_VERIFIED.json'),('FRESH_PACKAGE_DOWNLOAD_VERIFIED.json','REMOTE_SNAPSHOT_DOWNLOAD_VERIFIED.json'),('CANDIDATE_REMOTE_RESTORE_DOUBLE_REHASH.json','CANDIDATE_REMOTE_RESTORE_DOUBLE_REHASH.json')]:shutil.copyfile(R/source,P/dest)
 (P/'RESTORE_VERIFIED.md').write_text('# Fixed Darkcrest+Lava source restoration only, gameplay still unaccepted\n\nSource commit 5d988875054ad4eea47d6615f8a9fdd65bfe7b4d. All 17 files were actually freshly downloaded and checked by size/Git SHA/SHA256; all 23 source-evidence members were rehashed. Same-stage 54 prerequisites were separately freshly downloaded, then rehashed for restoration.\n\nActual independent restoration and second full read: 27,972 files, 1,550,731,770 bytes; source map e84edfaea8bf19ee8650f179cb48d9093915a99ef5d0a54adebb3a01fc9b33c3, aggregate 1cbcbcc3a1c16f2271c2d27ba78b87ffad6009a07c4b0c2bb2d914f3ab01f814, no differences.\n\nThis receipt proves bytes only. No completed gameplay acceptance is claimed. Tools include prepared but not executed future outcome/publication helpers. No live Game logs, process state, HOME/cache or hypothetical results are archived. Original 17-file source package remains preserved unchanged in its original directory and fixed source commit; only the checksum file of this separate receipt copy is regenerated. No paused empty-slot candidate source is included.\n')
 (P/'SHA256SUMS.txt').write_text(''.join(sha(p.read_bytes())+'  '+p.name+'\n' for p in sorted(P.iterdir()) if p.is_file() and p.name!='SHA256SUMS.txt'))
 old={x['filename']:x for x in d['records']};records=[];changed=[]
 for p in sorted(P.iterdir()):
  b=p.read_bytes();row={'name':p.name,'bytes':len(b),'sha256':sha(b),'git_sha':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()};records.append(row)
  if p.name not in old or old[p.name]['sha256']!=row['sha256']:changed.append(row)
 assert [x['name'] for x in changed if x['name'] in old]==['SHA256SUMS.txt']
 report={'status':'LOCAL_BYTES_ONLY_RECEIPT_READY_NOT_PUBLISHED','source_commit':d['source_commit'],'folder':'battlegrounds-backup/pending/20261112-darkcrest-lava-native-board','files':len(records),'bytes':sum(x['bytes'] for x in records),'tool_members':len(members),'records':records,'changed_records':changed}
 (ROOT/'RESTORE_RECEIPT_UPLOAD_METADATA.json').write_bytes(enc(report));print(json.dumps({k:v for k,v in report.items() if k not in ['records','changed_records']},indent=2));print('CHANGED',','.join(x['name'] for x in changed))
if __name__=='__main__':main()
