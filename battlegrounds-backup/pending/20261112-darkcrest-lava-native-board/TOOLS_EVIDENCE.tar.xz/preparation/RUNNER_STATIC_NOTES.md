# Lava external runner preparation

This directory is outside the frozen candidate. No Godot was started during this preparation. Source commit 5d988875054ad4eea47d6615f8a9fdd65bfe7b4d is pending fresh remote restore and a separate explicit start instruction.

Expected source map: e84edfaea8bf19ee8650f179cb48d9093915a99ef5d0a54adebb3a01fc9b33c3.
Expected aggregate: 1cbcbcc3a1c16f2271c2d27ba78b87ffad6009a07c4b0c2bb2d914f3ab01f814.

## Runtime dependencies and separation

run_remote_lava.py uses Python 3 standard library only (pathlib, argparse, datetime, fcntl, gzip, hashlib, json, os, re, shutil, signal, subprocess, time), Linux /proc and flock, and Godot on PATH only when --execute is explicitly supplied. audit_lava_attempt.py imports the adjacent runner and uses standard-library modules; it never launches Godot. synthetic_validator_tests.py imports the same runner and uses temporary synthetic fixture files, not any project source or Game.

The frozen source manifest/map and exact restore receipt are required runtime inputs. The runner pins all seven test entry points; dependencies beyond those entries are bound by the complete source-map and aggregate hash. The external archived source fixture and generated wrappers are hashed independently. HOME and all three XDG paths, wrappers, results, and logs are outside both source trees. The historical empty-slot directory in the lock pathname is only a shared concurrency lock, not a test dependency.

## Execution and acceptance boundaries

One full Game process: new three-case Lava matrix, 3600-second budget. Only on its success run six serial pure contracts (211/966/810/68/166/267 checks). Do not repeat the old eight-room Tier6 matrix. Hash the full run tree before every test and both full trees at completion. Record source and wrapper SHA, UTC, elapsed time, sampled group RSS, command, exit, and log SHA. Reject FAIL, SCRIPT ERROR, Parse Error/ParseError, COMMAND_FAILURE, WARNING, ERROR. Failure stops subsequent contracts; preserve the attempt and audit both trees without retry.

Matrix acceptance requires all three cases, genuine two-source indices [0,2], observed positive Lava combat damage, original 2/5 and kept0 after next recruit, complete native candidate pools and weighted selection, and explicitly ordinary scope. Coin funding is a disclosed pre-Darkcrest fixture: this is not a wholly natural unfunded game, not permanent enchantment acceptance, and not default-pool promotion. Shape-only contracts and synthetic Python validators do not prove native provenance or gameplay.

## Reproducible preparation checks

Run `python develop_darkcrest_lava_20261112/preparation/synthetic_validator_tests.py` from the workspace. SYNTHETIC_VALIDATOR_RESULT.json records the actual new 10-check run. It tests three-case validator acceptance and rejection of no damage, wrong indices, missing kept0 evidence, expanded scope, wrong weighted draw, plus pure-summary counting and exact-tree corruption detection.

REMOTE_RUNNER_PREPARATION_VERIFIED.json is the retained earlier ad hoc summary. The new script is a reproducible implementation of those checks, not a claim of byte-for-byte recovery of the earlier ephemeral command. Neither result substitutes for the future fixed-commit Game run.

PREPARATION_DEPENDENCIES_SHA256.json binds tools, notes, both preparation results, and pinned frozen test inputs. It intentionally excludes itself and generated __pycache__. No production files were edited.
