"""Reproducible synthetic validator tests, not Godot/game acceptance."""
from pathlib import Path
import copy, hashlib, json, tempfile
import run_remote_lava as r

def main():
    checks=[]
    def passed(name): checks.append(name)
    assert len(r.TESTS)==7 and r.TESTS[0][0]=='lava_real_matrix' and [x[3] for x in r.TESTS[1:]]==[211,966,810,68,166,267]
    passed('one_game_six_contracts_order')
    choices=[{'id':i,'stock':j+2} for j,i in enumerate(r.T6)]
    t2=[{'id':i,'stock':3} for i in ['BG23_002','BG23_009','BG31_924']]
    cases=[dict(kind='generated_front_to6',seed=20261120,source_uid='u1',lava_uid='u2',source_tier=6,final_round=6,final_board_uids=['u2','u1'],lava_damage_events=1,tier2_choices=t2),dict(kind='generated_back_then_moves',seed=20261120,source_uid='u3',lava_uid='u4',source_tier=4,final_round=4,final_board_uids=['u3','u4'],lava_damage_events=0,tier2_choices=t2),dict(kind='shop_lava_two_sources',seed=20261220,lava_uid='u7',source_uids=['u5','u6'],source_tiers=[3,2],actual_board_indices=[0,2],final_round=3)]
    marks=[('original_lava_object_unchanged_after_play',3),('next_recruit_original_lava_2_5_kept0_after_combat',6),('two_source_eot_preserves_original_lava',1),('actual_lava_combat_damage_observed_without_recruit_mutation',1),('public_move_updates_real_source_index',1),('public_move_back_updates_source_index_again',1),('two_sources_straddle_lava_at_real_indices_0_2',1),('each_real_source_has_own_new_grant_0',1),('each_real_source_has_own_new_grant_1',1),('coin_fixture_only_before_darkcrest_owned',1)]
    lines=['PASS '+m for m,n in marks for _ in range(n)]
    scenario=dict(scope='ordinary Darkcrest plus one untouched ordinary Lava hand-to-board and real EOT index compatibility only',checks=len(lines)-1,cases=cases,combat_damage=[dict(uid='u2',event=dict(event='damage',target='u2',amount=1))],tier6_casts=[dict(id=r.T6[0],source_uid='u1',choices=choices,rng=dict(type='rng',reason='random_generated_minion',range=sum(x['stock'] for x in choices),value=0))],old_tier6_eight_case_matrix_repeated=False,permanent_enchantment_opened=False,no_live_state_injection=True)
    with tempfile.TemporaryDirectory(prefix='lava-validator-') as td:
        d=Path(td)
        def validate(s,ls=lines):
            (d/'DARKCREST_LAVA_MATRIX_RESULT.json').write_text(json.dumps(s))
            log='\n'.join(ls+['DARKCREST_LAVA_CASE_PASS '+json.dumps(row) for row in s['cases']]+['DARKCREST_LAVA_REAL_MATRIX_PASS cases=3 checks='+str(len(lines))])
            r.validate('lava_real_matrix',log,None,d)
        validate(scenario); passed('synthetic_three_case_positive')
        def reject(name,mutate):
            s=copy.deepcopy(scenario); ls=list(lines); mutate(s,ls)
            try: validate(s,ls)
            except AssertionError: passed(name); return
            raise AssertionError('accepted negative '+name)
        reject('no_damage_rejected',lambda s,l:s['cases'][0].update(lava_damage_events=0))
        reject('wrong_indices_rejected',lambda s,l:s['cases'][2].update(actual_board_indices=[0,1]))
        reject('wrong_kept_marker_rejected',lambda s,l:l.__setitem__(3,'PASS next_recruit_original_lava_2_5_kept1_after_combat'))
        reject('wrong_scope_rejected',lambda s,l:s.update(permanent_enchantment_opened=True))
        reject('wrong_weight_rejected',lambda s,l:s['tier6_casts'][0].update(id=r.T6[1]))
        summary=dict(passed=211,failed=0,failures=[],real_game_run=False,scope='detached untouched Lava shape and custody rejection contracts, not native play or birth provenance')
        r.validate('lava_content_contract','\n'.join(['PASS fixture']*211+['DARKCREST_LAVA_CONTENT_CONTRACT '+json.dumps(summary)]),211,d);passed('synthetic_pure211')
        tree=d/'tree';tree.mkdir();(tree/'a').write_bytes(b'a')
        expected={'a':{'bytes':1,'sha256':r.sha(b'a')}};agg=r.sha(b'a\0' + b'1\0a')
        r.verify_tree(tree,expected,agg);passed('exact_tree')
        (tree/'a').write_bytes(b'b')
        try:r.verify_tree(tree,expected,agg)
        except AssertionError:passed('tree_mutation_rejected')
        else:raise AssertionError('corruption accepted')
    print(json.dumps(dict(status='PASS_SYNTHETIC_VALIDATOR_ONLY',checks=checks,passed=len(checks),godot_started=False,game_started=False,notice='New reproducible preparation run; does not reconstruct an earlier ad hoc command or prove gameplay.'),indent=2))
if __name__=='__main__':main()
