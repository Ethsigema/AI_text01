from pathlib import Path
import json,gzip,sys,tarfile
R=Path(__file__).resolve().parent;sys.path.insert(0,str(R/'snapshot_tools'))
from common import verify,sha,dump,write,utc,safe
base_bytes=gzip.decompress((R/'base_package/SOURCE_MAP.json.gz').read_bytes());base=json.loads(base_bytes)
assert sha(base_bytes)=='7fec8d69e82de8bfcb7373549951f9456671b5c3980135d6ec6f983a3daf5ed7'
m=json.loads((R/'tier6_package/MANIFEST.json').read_text());target=dict(base)
for n in m['removed']:del target[n]
target.update(m['changed_files']);encoded=dump(target)
assert sha(encoded)=='f6305aee3349b70d01292b351ac0923a2a3152b56a1f41fb1f18c763410d3e9c'
assert gzip.decompress((R/'tier6_package/SOURCE_MAP.json.gz').read_bytes())==encoded
with (R/'TIER6_SOURCE_MAP.json').open('xb') as f:f.write(encoded)
trees={'restored_base':verify(R/'restored_base',base,'5ba04ef124fc78cf20e2a942a60589fb92dc76e6808155648226a534a4599e05'),'restored_tier6':verify(R/'restored_tier6',target,'d72e2b1a7a0b6c257c3001f63959a9f717b2a1645feb02c33002c728786cf2fc')}
assert trees['restored_tier6']['files']==27968 and trees['restored_tier6']['bytes']==1550696801
dl=json.loads((R/'FRESH_DOWNLOAD_VERIFIED.json').read_text());assert dl['files']==54
for row in dl['records']:
 b=(R/row['filename']).read_bytes();assert len(b)==row['bytes'] and sha(b)==row['sha256']
counts={}
for prefix,count in [('FIX',21),('TOOLS',16),('GAMEPLAY',45)]:
 meta=json.loads((R/f'tier6_package/{prefix}_EVIDENCE_MANIFEST.json').read_text());expected=meta if prefix=='FIX' else meta['members'];seen=set()
 if prefix!='FIX':assert meta['source_commit']=='dd428c21867d4c15340ff6d4d8868d027d1067e4' and sha((R/f'tier6_package/{prefix}_EVIDENCE.tar.xz').read_bytes())==meta['archive_sha256']
 with tarfile.open(R/f'tier6_package/{prefix}_EVIDENCE.tar.xz') as t:
  for x in t:
   assert x.isfile() and safe(x.name) and x.name not in seen
   b=t.extractfile(x).read();assert {'bytes':len(b),'sha256':sha(b)}==expected[x.name];seen.add(x.name)
 assert seen==set(expected) and len(seen)==count;counts[prefix]=count
assert sha((R/'tier6_package/GAMEPLAY_INDEPENDENT_VERIFICATION.json').read_bytes())=='4c6bd9f2831d402c75f718c600de9c1842e1a834984d2bbb77e805f31703d04a'
write(R/'CURRENT_EVIDENCE_VERIFIED.json',{'status':'PASS_FRESH_TIER6_ALL_THREE_EVIDENCE_ARCHIVES','members':counts,'checked_at_utc':utc(),'historical_tests_not_current_execution':True})
write(R/'CURRENT_RECOVERY_VERIFIED.json',{'status':'PASS_CURRENT_ENVIRONMENT_INDEPENDENT_RESTORE_AND_DOUBLE_TREE_REHASH','checked_at_utc':utc(),'fixed_commit':'15dcc5752827322968ca08d5643fa03ba7cf6934','source_commit':'dd428c21867d4c15340ff6d4d8868d027d1067e4','fresh_download_files':54,'fresh_download_bytes':dl['bytes'],'source_map_sha256':sha(encoded),'trees':trees,'game_started':False,'uploads':0,'old_download_bytes_reused':False,'old_files_preserved':True})
print('PASS_NEW_STAGE_54_FRESH_DOWNLOADS_AND_TIER6_DOUBLE_REHASH')
