"""Read-only source/log audit after one completed runner attempt. Never runs Godot."""
from pathlib import Path
import argparse
import fcntl
import gzip
import json
from run_remote_lava import sha, read_json, verify_tree, write_new, utc, TESTS

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--remote-root', required=True, type=Path)
    parser.add_argument('--commit', required=True)
    parser.add_argument('--source-map-sha256', required=True)
    parser.add_argument('--aggregate-sha256', required=True)
    args = parser.parse_args()
    lock_path = Path(__file__).resolve().parents[2]/'develop_empty_ghost_20261112/.independent_full_game.lock'
    lock = lock_path.open('a')
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    root = args.remote_root.resolve()
    manifest = read_json(root/'package/MANIFEST.json')
    raw = gzip.decompress((root/'package/SOURCE_MAP.json.gz').read_bytes())
    assert sha(raw) == manifest['source_map_sha256'] == args.source_map_sha256
    assert manifest['aggregate_sha256'] == args.aggregate_sha256
    restore = read_json(root/'INDEPENDENT_RESTORE_VERIFIED.json')
    assert restore['source_commit'] == args.commit and restore['source_map_sha256'] == args.source_map_sha256
    expected = json.loads(raw)
    trees = {name: verify_tree(root/name, expected, args.aggregate_sha256)[0] for name in ['restored_snapshot','run_tree']}
    evidence = root/'independent_tests'
    results = {}; omitted = []; failed = []; missing_started = []
    for label, source, _, _ in TESTS:
        receipt = evidence/(label+'_result.json'); log = evidence/(label+'.log')
        if not receipt.exists():
            if log.exists(): missing_started.append(label)
            else: omitted.append(label)
            continue
        result = read_json(receipt)
        assert result['source_commit'] == args.commit and result['source'] == source
        assert result['source_sha256'] == expected[source]['sha256']
        assert sha(log.read_bytes()) == result['log_sha256']
        results[label] = result
        if result['exit'] != 0 or result['reason'] != 'exited': failed.append(label)
    assert not missing_started, ('Runner may still be active or receipt incomplete; do not audit as complete', missing_started)
    verified = root/'INDEPENDENT_GAME_VERIFICATION.json'
    accepted = False
    if verified.exists():
        final = read_json(verified)
        assert final['source_commit'] == args.commit and final['source_map_sha256'] == args.source_map_sha256
        assert final['status'] == 'PASS_FIXED_REMOTE_DARKCREST_LAVA_MATRIX_AND_CONTRACTS_POST_TEST_DOUBLE_REHASH'
        assert len(results) == len(TESTS) and not failed and not omitted
        accepted = True
    report = {'status':'PASS_POST_ATTEMPT_SOURCE_INTEGRITY_AUDIT_ONLY', 'verified_at_utc':utc(),
              'source_commit':args.commit,'source_map_sha256':args.source_map_sha256,'trees':trees,
              'runner_success_receipt_present':accepted,'result_receipts':results,'failed_processes':failed,
              'tests_without_process_receipt':omitted,'not_run_tests_are_not_passes':True,
              'note':'Source integrity does not turn a failed, skipped or unvalidated gameplay test into a pass.',
              'godot_or_game_started_by_audit':False}
    write_new(root/'POST_ATTEMPT_SOURCE_AUDIT.json',report)
    print(json.dumps({'status':report['status'],'runner_success_receipt_present':accepted,'failed_processes':failed,'not_run':omitted}))
if __name__ == '__main__': main()
