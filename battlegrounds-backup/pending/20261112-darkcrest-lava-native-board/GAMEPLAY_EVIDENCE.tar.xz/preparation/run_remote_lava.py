"""One explicit serial execution of the fixed remote Darkcrest plus ordinary untouched Lava candidate.

Preparation is read-only without --execute. Never downloads, uploads, or changes
source inputs. Full Game runs once; only the six listed contracts follow it. Failed empty-slot candidates are excluded; historical evidence is retained.
"""
from pathlib import Path, PurePosixPath
import argparse
import datetime
import fcntl
import gzip
import hashlib
import json
import os
import re
import shutil
import signal
import subprocess
import time

T6 = ['BG31_035', 'BG32_837', 'BG36_622', 'BG36_640']
T5 = ['BG23_008', 'BG31_920', 'BG31_925', 'BG32_111', 'BG32_820', 'BG32_835']
BASELINE = {'source_commit': 'dd428c21867d4c15340ff6d4d8868d027d1067e4', 'receipt_commit_prefix': '15dcc575', 'empty_slot_v1_v2_v3_excluded': True}
PINNED_TESTS = {'tests/darkcrest_lava_20261112/real_matrix.gd': '63affd1ccbffd0b9208c31217f55ddacac2cc3aee375d2b24bb64ba2415e8612', 'tests/darkcrest_lava_20261112/content_contract.gd': '301a5c9e56618baf42ae6ccbd80eea92f3eadc27a3fcfa02030fb51052004beb', 'tests/darkcrest_tier6_20261112/content_contract.gd': '01e5874b444db4950cd9a3a08aec18a0bd4443c28c2a17500f59ee39f38eb787', 'tests/darkcrest_tier5_20261112/content_contract.gd': 'd039a22573d7340d0779e17adbbc70b0e2f3f958334fd7c742bdd4b6e3bd6248', 'tests/darkcrest_20261112/source_eot_contract.gd': '2d37ee1063792093a0fd1ad683c2e8786f196caad43abe0c82ea831caaaf7790', 'tests/darkcrest_20261112/hand_shape_contract.gd': '1577c66e9524b4db1875309104cf55cf67d254d1e024a41b9b094fff8331fa2e', 'tests/darkcrest_20261112/seafloor_annotation_contract.gd': 'c0e0046fa010ccfb83d87bedf87a4616b23fef5e1700e88438f27f9aca6dc4cb'}
TESTS = [('lava_real_matrix', 'tests/darkcrest_lava_20261112/real_matrix.gd', 3600, None), ('lava_content_contract', 'tests/darkcrest_lava_20261112/content_contract.gd', 180, 211), ('tier6_content_contract', 'tests/darkcrest_tier6_20261112/content_contract.gd', 180, 966), ('tier5_content_contract', 'tests/darkcrest_tier5_20261112/content_contract.gd', 180, 810), ('source_eot_contract', 'tests/darkcrest_20261112/source_eot_contract.gd', 180, 68), ('hand_shape_contract', 'tests/darkcrest_20261112/hand_shape_contract.gd', 180, 166), ('seafloor_annotation_contract', 'tests/darkcrest_20261112/seafloor_annotation_contract.gd', 180, 267)]
FIXTURE = 'tests/darkcrest_20261112/darkcrest_sources_archived.gd'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def dump(value):
    return (json.dumps(value, sort_keys=True, indent=2) + '\n').encode()


def write_new(path, value):
    with path.open('xb') as stream:
        stream.write(dump(value))


def read_json(path):
    return json.loads(path.read_text())


def safe(name):
    return bool(name) and not PurePosixPath(name).is_absolute() and '..' not in PurePosixPath(name).parts and '\\' not in name


def verify_tree(tree, expected, aggregate):
    assert tree.is_dir() and not tree.is_symlink(), str(tree)
    actual = {}
    combined = hashlib.sha256()
    paths = list(tree.rglob('*'))
    assert all(not path.is_symlink() for path in paths), 'Source symlink forbidden'
    for path in sorted((path for path in paths if path.is_file()), key=lambda path: path.relative_to(tree).as_posix()):
        name = path.relative_to(tree).as_posix()
        assert safe(name), name
        data = path.read_bytes()
        actual[name] = {'bytes': len(data), 'sha256': sha(data)}
        combined.update(name.encode() + b'\0' + str(len(data)).encode() + b'\0' + data)
    missing = sorted(set(expected) - set(actual))
    extra = sorted(set(actual) - set(expected))
    mismatched = sorted(name for name in actual.keys() & expected.keys() if actual[name] != expected[name])
    result = {'files': len(actual), 'bytes': sum(row['bytes'] for row in actual.values()),
              'aggregate_sha256': combined.hexdigest(), 'missing': missing, 'extra': extra, 'mismatched': mismatched}
    assert not missing and not extra and not mismatched and combined.hexdigest() == aggregate, result
    return result, {name: row['sha256'] for name, row in actual.items()}


def stop(process):
    if process.poll() is not None:
        return
    os.killpg(process.pid, signal.SIGTERM)
    try:
        process.wait(timeout=2)
    except subprocess.TimeoutExpired:
        os.killpg(process.pid, signal.SIGKILL)
        process.wait()


def rss_for_group(group):
    rss = 0
    for proc in Path('/proc').iterdir():
        if not proc.name.isdigit():
            continue
        try:
            fields = (proc / 'stat').read_text().rsplit(')', 1)[1].split()
            if int(fields[2]) == group:
                rss += int((proc / 'statm').read_text().split()[1]) * os.sysconf('SC_PAGE_SIZE')
        except (OSError, ValueError, IndexError):
            pass
    return rss


def run_test(label, source_name, budget, commit, run_tree, evidence, expected, aggregate, env, prepared):
    # Re-read the complete run tree, not merely its test entry point.
    tree, hashes = verify_tree(run_tree, expected, aggregate)
    write_new(evidence / (label + '_hashes.json'), hashes)
    for name, meta in prepared.items():
        data = (evidence / name).read_bytes()
        assert len(data) == meta['bytes'] and sha(data) == meta['sha256'], name
    available = int(next(line.split()[1] for line in Path('/proc/meminfo').read_text().splitlines()
                         if line.startswith('MemAvailable:'))) * 1024
    limit = min(4 * 1024**3, available // 2)
    assert limit >= (3 * 1024**3 if label == 'lava_real_matrix' else 512 * 1024**2), 'Insufficient memory for guarded test'
    wrapper = evidence / (label + '.gd')
    cmd = ['godot', '--headless', '--path', str(run_tree), '--script', str(wrapper)]
    started = utc()
    t = time.monotonic()
    peak = 0
    reason = 'exited'
    with (evidence / (label + '.log')).open('x') as log:
        process = subprocess.Popen(cmd, stdout=log, stderr=subprocess.STDOUT, env=env, start_new_session=True)
        try:
            while process.poll() is None:
                rss = rss_for_group(process.pid)
                peak = max(peak, rss)
                if rss > limit or time.monotonic() - t > budget:
                    reason = 'rss_soft_limit' if rss > limit else 'timeout'
                    stop(process)
                    break
                time.sleep(.1)
        except BaseException:
            reason = 'runner_interrupted'
            raise
        finally:
            stop(process)
            data = (evidence / (label + '.log')).read_bytes()
            result = {'source_commit': commit, 'source': source_name, 'command': cmd,
                      'source_sha256': expected[source_name]['sha256'], 'wrapper_sha256': prepared[wrapper.name]['sha256'],
                      'log_sha256': sha(data), 'started_at_utc': started, 'finished_at_utc': utc(),
                      'exit': process.wait(), 'reason': reason, 'elapsed': time.monotonic() - t,
                      'sampled_process_group_peak_rss': peak, 'rss_soft_limit': limit, 'available_start': available,
                      'timeout_seconds': budget, 'memory_enforcement': 'sampled process-group soft limit, not a cgroup hard cap',
                      'source_snapshot_matches': True, 'start_tree': tree}
            write_new(evidence / (label + '_result.json'), result)
    print(label, json.dumps(result), flush=True)
    text = data.decode()
    failures = [line for line in text.splitlines() if re.search(r'^\s*FAIL(?:\s|$)', line)
                or any(marker in line for marker in ['SCRIPT ERROR', 'Parse Error', 'ParseError', 'COMMAND_FAILURE', 'WARNING', 'ERROR:'])]
    assert result['exit'] == 0 and reason == 'exited' and not failures, (label, result, failures)
    return result, text


def validate(label, log, expected_checks, evidence):
    scenario = None
    if label == 'lava_real_matrix':
        rows = re.findall(r'^DARKCREST_LAVA_REAL_MATRIX_PASS cases=3 checks=(\d+)$', log, re.M)
        assert len(rows) == 1, 'Missing or duplicated new three-case matrix marker'
        count = int(rows[0]); scenario = read_json(evidence/'DARKCREST_LAVA_MATRIX_RESULT.json')
        assert scenario['checks'] + 1 == count
        assert scenario['scope'] == 'ordinary Darkcrest plus one untouched ordinary Lava hand-to-board and real EOT index compatibility only'
        assert scenario['old_tier6_eight_case_matrix_repeated'] is False
        assert scenario['permanent_enchantment_opened'] is False and scenario['no_live_state_injection'] is True
        cases = scenario['cases']; assert len(cases) == 3
        assert [row['kind'] for row in cases] == ['generated_front_to6','generated_back_then_moves','shop_lava_two_sources']
        assert [row['seed'] for row in cases] == [20261120,20261120,20261220]
        logged = [json.loads(line.removeprefix('DARKCREST_LAVA_CASE_PASS ')) for line in log.splitlines() if line.startswith('DARKCREST_LAVA_CASE_PASS ')]
        assert logged == cases
        front, moved, dual = cases
        for row in [front,moved]:
            assert [item['id'] for item in row['tier2_choices']] == ['BG23_002','BG23_009','BG31_924']
            assert all(type(item['stock']) is int and item['stock'] > 0 for item in row['tier2_choices'])
            assert re.fullmatch(r'u[1-9][0-9]*',row['lava_uid']) and row['lava_uid'] != row['source_uid']
        assert front['source_tier'] == 6 and front['final_round'] == 6
        assert front['final_board_uids'] == [front['lava_uid'],front['source_uid']]
        assert moved['source_tier'] == 4 and moved['final_round'] == 4
        assert moved['final_board_uids'] == [moved['source_uid'],moved['lava_uid']]
        assert dual['source_tiers'] == [3,2] and dual['actual_board_indices'] == [0,2] and dual['final_round'] == 3
        assert len(dual['source_uids']) == 2 and len(set(dual['source_uids']+[dual['lava_uid']])) == 3
        damage = scenario['combat_damage']
        assert front['lava_damage_events'] > 0
        assert len(damage) == front['lava_damage_events'] + moved['lava_damage_events']
        assert all(row['uid'] in [front['lava_uid'],moved['lava_uid']] and row['event']['event']=='damage' and row['event']['target']==row['uid'] and row['event']['amount']>0 for row in damage)
        lines = log.splitlines()
        for marker,minimum in [('PASS original_lava_object_unchanged_after_play',3),('PASS next_recruit_original_lava_2_5_kept0_after_combat',6),('PASS two_source_eot_preserves_original_lava',1),('PASS actual_lava_combat_damage_observed_without_recruit_mutation',1),('PASS public_move_updates_real_source_index',1),('PASS public_move_back_updates_source_index_again',1),('PASS two_sources_straddle_lava_at_real_indices_0_2',1),('PASS each_real_source_has_own_new_grant_0',1),('PASS each_real_source_has_own_new_grant_1',1),('PASS coin_fixture_only_before_darkcrest_owned',1)]:
            assert lines.count(marker) >= minimum, marker
        assert len(scenario['tier6_casts']) == 1
        cast = scenario['tier6_casts'][0]; choices = cast['choices']; draw = cast['rng']
        assert cast['id'] in T6 and [entry['id'] for entry in choices] == T6
        assert all(type(entry['stock']) is int and entry['stock']>0 for entry in choices)
        assert len({entry['stock'] for entry in choices}) > 1
        total = sum(entry['stock'] for entry in choices)
        assert draw['type']=='rng' and draw['reason']=='random_generated_minion' and draw['range']==total
        assert type(draw['value']) is int and 0<=draw['value']<total
        ticket=draw['value']; selected=None
        for entry in choices:
            if ticket<entry['stock']: selected=entry['id']; break
            ticket-=entry['stock']
        assert selected==cast['id'] and cast['source_uid']==front['source_uid']
    elif label == 'lava_content_contract':
        marker = 'DARKCREST_LAVA_CONTENT_CONTRACT '
        rows = [json.loads(line.removeprefix(marker)) for line in log.splitlines() if line.startswith(marker)]
        assert len(rows)==1
        summary=rows[0]; count=summary['passed']
        assert count==expected_checks and summary['failed']==0 and summary['failures']==[]
        assert summary['real_game_run'] is False
        assert summary['scope']=='detached untouched Lava shape and custody rejection contracts, not native play or birth provenance'
    elif label in ['tier6_content_contract', 'tier5_content_contract']:
        marker = 'DARKCREST_TIER6_CONTENT_CONTRACT ' if label == 'tier6_content_contract' else 'DARKCREST_TIER5_CONTENT_CONTRACT '
        rows = [json.loads(line.removeprefix(marker)) for line in log.splitlines() if line.startswith(marker)]
        assert len(rows) == 1
        summary = rows[0]; count = summary['passed']
        assert count == expected_checks and summary['failed'] == 0 and summary['failures'] == []
        assert summary['ids'] == (T6 if label == 'tier6_content_contract' else T5)
        assert summary['scope'] == 'pure fixture content and identity observations only, not actual acquisition or provenance'
        if label == 'tier6_content_contract': assert summary['real_game_run'] is False
    elif label == 'source_eot_contract':
        count = expected_checks
        assert log.splitlines().count('DARKCREST_SOURCE_EOT_CONTRACT passed=68 failed=0') == 1
    elif label == 'seafloor_annotation_contract':
        rows = [json.loads(line.removeprefix('SEAFLOOR_ANNOTATION_CONTRACT ')) for line in log.splitlines() if line.startswith('SEAFLOOR_ANNOTATION_CONTRACT ')]
        assert len(rows) == 1
        summary = rows[0]; count = summary['checks']
        assert count == expected_checks and summary['failures'] == 0 and summary['scope'] == 'source_contract_only_no_Game_or_Catalog'
    else:
        rows = [json.loads(line) for line in log.splitlines() if line.startswith('{') and 'darkcrest_five_strict_hand_shapes' in line]
        assert len(rows) == 1
        summary = rows[0]; count = summary['passed']
        assert count == expected_checks and summary['failed'] == 0 and summary['failures'] == []
    assert sum(line.startswith('PASS ') for line in log.splitlines()) == count, (label, 'PASS count does not match summary')
    return count, scenario


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--commit', required=True, help='Fixed remote source commit, 40 lowercase hex characters')
    parser.add_argument('--restored-snapshot', required=True, type=Path)
    parser.add_argument('--package', type=Path, help='Fixed remote downloaded package; default restored_snapshot sibling package')
    parser.add_argument('--restore-report', type=Path, help='Default sibling INDEPENDENT_RESTORE_VERIFIED.json')
    parser.add_argument('--output', type=Path, help='Default restored snapshot parent; run_tree and independent_tests must not exist')
    parser.add_argument('--source-map-sha256', required=True, help='Parent-verified frozen Lava uncompressed source-map SHA256')
    parser.add_argument('--aggregate-sha256', required=True, help='Parent-verified frozen Lava aggregate SHA256')
    parser.add_argument('--execute', action='store_true', help='Required to create copies or run any process')
    args = parser.parse_args()
    assert re.fullmatch(r'[0-9a-f]{40}', args.commit), 'Use a fixed full source commit'
    for value in [args.source_map_sha256, args.aggregate_sha256]:
        assert re.fullmatch(r'[0-9a-f]{64}', value), 'Require explicit frozen Lava SHA256 values'
    frozen_map_sha = args.source_map_sha256
    frozen_aggregate = args.aggregate_sha256
    source = args.restored_snapshot.resolve()
    tranche_root = Path(__file__).resolve().parent.parent
    assert tranche_root in source.parents, 'Use the separate Lava remote snapshot'
    package = (args.package or source.parent / 'package').resolve()
    restore_report = (args.restore_report or source.parent / 'INDEPENDENT_RESTORE_VERIFIED.json').resolve()
    output = (args.output or source.parent).resolve()
    assert output != source and source not in output.parents, 'Never place generated artifacts inside source tree'
    assert tranche_root in output.parents or output == tranche_root, 'Keep output in the Lava tranche'
    manifest = read_json(package / 'MANIFEST.json')
    map_bytes = gzip.decompress((package / 'SOURCE_MAP.json.gz').read_bytes())
    assert sha(map_bytes) == manifest['source_map_sha256'] == frozen_map_sha
    assert manifest['aggregate_sha256'] == frozen_aggregate
    expected = json.loads(map_bytes)
    assert all(safe(name) for name in expected)
    assert len(expected) == manifest['source_files']
    assert sum(row['bytes'] for row in expected.values()) == manifest['source_bytes']
    for name, checksum in PINNED_TESTS.items():
        assert expected[name]['sha256'] == checksum, ('Frozen test changed', name)
    report = read_json(restore_report)
    assert report['source_commit'] == args.commit and report['source_map_sha256'] == frozen_map_sha
    assert report.get('status', '').startswith('PASS_'), 'Prior fixed-commit remote restore verification required'
    restored_report = report['restored']
    assert restored_report['aggregate_sha256'] == frozen_aggregate
    assert restored_report['files'] == manifest['source_files'] and restored_report['bytes'] == manifest['source_bytes']
    assert all(not restored_report[key] for key in ['missing', 'extra', 'mismatched'])
    for _, name, _, _ in TESTS:
        assert name in expected, name
    assert FIXTURE in expected
    if not args.execute:
        print(json.dumps({'status': 'CONFIGURATION_ONLY_NOT_EXECUTED', 'source_commit': args.commit,
                          'source_map_sha256': frozen_map_sha, 'tests': TESTS, 'game_started': False}, indent=2))
        return
    output.mkdir(parents=True, exist_ok=True)
    lock_path = tranche_root.parent / 'develop_empty_ghost_20261112' / '.independent_full_game.lock'
    lock = lock_path.open('a')
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    run_tree = output / 'run_tree'
    evidence = output / 'independent_tests'
    assert not run_tree.exists() and not evidence.exists(), 'Never overwrite an earlier run'
    initial_source, _ = verify_tree(source, expected, frozen_aggregate)
    shutil.copytree(source, run_tree)
    initial_run, _ = verify_tree(run_tree, expected, frozen_aggregate)
    evidence.mkdir()
    prepared = {}
    for label, name, _, _ in TESTS:
        data = ('extends "res://' + name + '"\n').encode()
        path = evidence / (label + '.gd')
        path.write_bytes(data)
        prepared[path.name] = {'bytes': len(data), 'sha256': sha(data), 'source': name,
                               'source_sha256': expected[name]['sha256'], 'kind': 'external_wrapper'}
    fixture_data = (source / FIXTURE).read_bytes()
    assert {'bytes': len(fixture_data), 'sha256': sha(fixture_data)} == expected[FIXTURE]
    fixture_path = evidence / 'darkcrest_sources_archived.gd'
    fixture_path.write_bytes(fixture_data)
    prepared[fixture_path.name] = {**expected[FIXTURE], 'source': FIXTURE, 'kind': 'remote_fixture_copy'}
    write_new(evidence / 'PREPARED_FROM_REMOTE.json', {'source_commit': args.commit, 'source_map_sha256': frozen_map_sha,
              'prepared_at_utc': utc(), 'verified_tier6_baseline': BASELINE, 'entries': prepared, 'initial_trees': {'restored_snapshot': initial_source, 'run_tree': initial_run}})
    env = os.environ.copy()
    for key, folder in [('HOME', 'home'), ('XDG_CACHE_HOME', 'cache'), ('XDG_CONFIG_HOME', 'config'), ('XDG_DATA_HOME', 'data')]:
        destination = evidence / folder
        destination.mkdir()
        env[key] = str(destination)
    runs = {}
    prior_end = None
    for label, name, budget, count in TESTS:
        result, log = run_test(label, name, budget, args.commit, run_tree, evidence, expected, frozen_aggregate, env, prepared)
        assert prior_end is None or result['started_at_utc'] >= prior_end
        prior_end = result['finished_at_utc']
        count, scenario = validate(label, log, count, evidence)
        runs[label] = {'source': name, 'passed_checks': count, 'log_sha256': result['log_sha256'],
                       'test_sha256': expected[name]['sha256'], 'source_snapshot_matches': True, 'failures': [], 'result': result}
        if scenario is not None:
            runs[label]['verified_scenario_fields'] = scenario
            runs[label]['scenario_sha256'] = sha((evidence / 'DARKCREST_LAVA_MATRIX_RESULT.json').read_bytes())
        write_new(evidence / (label + '_VALIDATED.json'), runs[label])
    # Reject all changes and extras, including generated source-tree caches.
    trees = {'restored_snapshot': verify_tree(source, expected, frozen_aggregate)[0],
             'run_tree': verify_tree(run_tree, expected, frozen_aggregate)[0]}
    for name, meta in prepared.items():
        data = (evidence / name).read_bytes()
        assert len(data) == meta['bytes'] and sha(data) == meta['sha256'], name
    final = {'status': 'PASS_FIXED_REMOTE_DARKCREST_LAVA_MATRIX_AND_CONTRACTS_POST_TEST_DOUBLE_REHASH',
             'verified_at_utc': utc(), 'source_commit': args.commit, 'source_map_sha256': frozen_map_sha,
             'verified_tier6_baseline': BASELINE, 'trees': trees, 'tests': runs, 'fixtures': prepared, 'sequential_game_execution': True,
             'full_game_processes': 1, 'old_tier6_eight_case_matrix_repeated': False, 'permanent_enchantment_opened': False, 'coin_funding_fixture_used_before_darkcrest_owned': True, 'entirely_natural_game_without_fixtures': False,
             'full_game_acceptance': False,
             'default_pool_promoted': False, 'scope': 'ordinary Darkcrest plus one untouched ordinary Lava native hand-to-board and real EOT index compatibility only'}
    write_new(output / 'INDEPENDENT_GAME_VERIFICATION.json', final)
    print('DARKCREST_LAVA_REMOTE_MATRIX_CONTRACTS_AND_DOUBLE_REHASH_PASS', flush=True)


if __name__ == '__main__':
    main()
