# Lava matrix 与 runner 静态相容性复核

只读检查 candidate/tests/darkcrest_lava_20261112/real_matrix.gd、其继承的 Tier6/Tier5/原始矩阵辅助函数、preparation/run_remote_lava.py 及相关 Game/Combat 字段生产位置。未修改源码或runner，未运行Game。不构成玩法通过。

## 已检查

- 外部runner在independent_tests写入仅extends固定res://测试源的wrapper，并以该wrapper作为--script。测试的get_script().resource_path取最外层运行脚本，get_base_dir应为外部证据目录；DARKCREST_LAVA_MATRIX_RESULT.json与runner读取位置一致。子矩阵覆盖_initialize，不执行旧Tier6八案例初始化。
- Game原战斗结果写入left_player/right_player，随后append至last_combats；测试据此选择玩家0唯一战斗并按left/right选择combat_start公开战队。Combat的damage事件实际具有target UID和amount字段，正伤害筛选与runner一致，不把shield的amount0记为伤害。
- 三案例顺序与seed标签对齐：generated_front_to6 / 20261120；generated_back_then_moves / 20261120；shop_lava_two_sources / 20261220。
- 首案例开始round1，首次推进到2后生成Lava，再推进3、4、5、6，末source_tier6、round6、board=[lava,source]。移动案例推进到round4/tier4，末board=[source,lava]。双来源案例推进到round3，tier=[3,2]，实际来源board indices=[0,2]。
- inspect_lava_combat调用首案例4次、移动案例2次，共6次next_recruit_original_lava_2_5_kept0_after_combat标记；三个案例各一次原Lava play标记。runner的最低次数与实际调用数匹配。
- result.checks在matrix_result_file断言前取值，最终PASS marker的checks因此多1；runner按scenario.checks+1核对，未把写文件检查漏算或重复算。
- tier6_casts仅首案例追加一次；runner重演记录的完整4种正库存非均匀权重和单次rng票选择。两生成案例的tier2_choices必须完整3种正库存，未用缩减单张域冒充原生生成。

## 尚未验证

没有运行固定seed；不能静态保证种子仍抽到Lava、后续完整随机域/金币预算可达、实际战斗一定发生正伤害、玩家在多轮后存活或全部原生host兼容。正伤害存在条件与其它合法预期不得为了通过而下调；若实际失败，应保留日志并确定原因。

## Coin fixture 的准确边界

继承fund实际调用game._unit(BG28_810)与game._add_hand，再通过公开play金币筹资。Tier6覆盖的fund在任何Darkcrest已拥有前拒绝继续筹资，并打印coin_fixture_only_before_darkcrest_owned。故no_live_state_injection=true不能无条件解释为“完全无注入”。正确说明应是：预先金币筹资fixture例外；目标Lava/暗潮由原生获取与公开操作产生，不直接注入目标实体、成长、RNG或库存。该例外必须在最终回执保留，不能将fixture筹资称为自然经济对局。

结论：本轮静态检查未发现确定的测试/runner执行接口、字段或计数不相容；这不是运行成功或seed验证。
