# 暗潮 + 普通Lava原生手牌play组合候选

基线 source dd428c2 / final 15dcc575 的已恢复Tier6独立copy；不含empty v1–v3，不改变Tier6后EOT held。未跑Game、未repin、未上传。

## 实际5文件

1. 新 core/darkcrest_lava_play.gd：只读shape/preflight，实际Game原hand play开始/完成身份记录。只BG23_009普通2/5 kept0，完整来源/字段/原hand对象与全局唯一UID、一次唯一board插入；不允许第二Lava、buff、owner字段、附着、金色。记录不是Darkcrest出生凭证。普通shop原hand与暗潮生成原hand都可，实际样本来源分别说明。
2. core/darkcrest_host.gd：实例化helper；play仅该身份通过preflight；board只有完成的真实play原对象可通过；sale Lava在原命令消费前held；move保留原生路径且board身份验证不依赖旧位置。EOT保存全board引用和值、仅暗潮records/programs绑定真实board_index，严格比较原EndTurnRepeats完整计划，执行按原index；全board顺序/值变化拒绝，暗潮唯一允许值变化是本次正式成长text。未知board/程序拒绝，不改重复回调/6后EOT限制。
3. core/game.gd：仅原_play wrapper建立短生命context+RefCounted nonce；begin绑定owner、hand[index]原引用、round、sequence、归一化插入position；原_play_darkcrest_original成功后complete确认所有原hand/board实体与值、唯一移除插入；各失败wrapper出口清pending/context。成功board记录不由shape或复制context自行签发。Game重置同时清临时上下文。
4. core/darkcrest_sources.gd：新增helper runtime路径，revision更新。
5. data/darkcrest_overlay.json：仅同步revision。

## 原生时序

原Game._play_darkcrest_original整段成功后、_play返回前提交Lava的play记录。Lava在内部_grant_spellcraft因没有spellcraft生产效果立即return，无内部Waiting flush。外层command约3230的原_flush_spellcraft更晚，因此腾空手牌后的待发暗潮token会在真实board已获play许可后执行。局部hand快照只验证该play，不延续至外层flush。

外层flush若失败，仍报告命令失败；不伪称play回滚。已真实入场的Lava记录可保留，符合前缀已经发生的事实。失败的原play则绝不签发新board记录，清pending而不抹其它既有成功记录。

## 边界

- Game.Lava指时空扭曲BG34_Giant_678，不修改它；普通复用LimitedTurn.validate_unit_state与原招募被动。
- 无Tier2 Generation扩大；其真实测试域是当前manifest的BG23_002/BG23_009/BG31_924，排除仅legacy whitelist的BG_GIL_681。
- 本批不验证普通Lava永久保留外来塑造法术；计数必须0，外来spell继续held。
- move可走；暗潮active时sale Lava前置held，待独立离场审计。复制/保存重载仍不能恢复私有记录，原对象离场后新同uid对象不能复用。
- 未改Combat、普通Lava能力或核心招募语义，不承诺所有其它hosts已动态兼容。

## 目前检查

仅隔离HOME和XDG的两个script --check-only，helper与Host均exit0。没有Game运行。EOT私有wrongindex深分支没有伪造Game通过纯fixture；测试必须区分实际计划观察、假来源拒绝与尚未动态走到的深负例。

## v2冻结纠正

原LAVA_FROZEN_SHA256.json保留为v1证据。新helper独立要求Game/Host均真实RefCounted且script.resource_path精确匹配，并要求host._lava_play就是self，不能委托FakeHost.actual自报身份。complete除原context/nonce引用外，复验8字段size、类型、标量及owner/unit/nonce引用；begin保存requested_position以核原始请求，另保存归一化插入位置。v2仅helper字节变化，短check-only exit0，仍未Game。
