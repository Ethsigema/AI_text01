# Lava 有限组合实现最终静态复核

只读复核本轮candidate相对远端已验Tier6基线的helper、Host和Game实际diff。未Godot/未修改源码。最终基于LAVA_V3_FROZEN_SHA256.json（helper decf79e2…46a96），运行验收仍待进行。

## 已修阻塞

- _actual不再相信任意host.actual：检查真实RefCounted、Game/Host脚本路径、game._darkcrest_host以及host._lava_play==self、state.players实际owner引用。真实Game未start时先players Array检查，避免SCRIPT ERROR。
- complete不只比context容器引用：_context_matches重新核全部8字段，含nonce原引用、origin、owner/unit原对象、index、原requested_position、round、sequence及native int类型。raw position与原Game的越界append归一化规则一致。

## 其它实际检查

1. 原Game wrapper创建nonce/短窗口；begin拒嵌套，preflight只允许实际唯一hand对象、普通原生2/5 Lava/kept0、无额外marker/同类复数；shape不是单独board权限。
2. 原play成功后才complete，核hand对象和值仅减Lava、真实同一unit按原请求位置插入、旧board原引用及深值不变。失败清pending/context/nonce，不生成新board记录。
3. commit在外层command等待flush之前；Lava自身_grant_spellcraft无spellcraft effect早退，不内flush。局部hand精确条件不延续到后续原waiting补token，不跳过等待。
4. 持久board记录绑真实engine/owner/unit和完整snapshot，不绑定旧index。move后仍可认证唯一对象；active组合sell Lava前置held，不靠新同uid对象重签。
5. EOT原完整plan保持；Lava只作为非EOT来源留在全board快照。Darkcrest records保存实际board_index，_eot_state_error与execute_eot按该index且host_uid引用验证；全board同对象顺序冻结，Lava深值不变，已完成Darkcrest只允许原生成长text变化。多source index不再错当board index。
6. Game原factory/play/hand/Combat/RNG实现未被替换；不签发Darkcrest出生证明，不实现Lava永久buff机制。BG23_009与时空扭曲Lava host分离。当前范围kept必须0、临时/永久额外层拒绝。

未发现其余本次源码新增的静态阻塞。不能保证后续原生host全部接受；真实四人场景、Lava在Darkcrest前后位置、下一招募补发与继续原完整域生成，及copy/wrongowner/unownedhelper/nonce-field变更负例仍需实际验证。纯合同不等于完整Game通过；任何长测失败需保留原日志。无空位失败候选混入、无golden/triple/外来targeted Spellcraft或Tier6后EOT扩展声明。

边界：局部记录证明原play已完成，不是外层command tail整体成功；若尾flush失败，应报告失败并保留已发生play，不能假装回滚。全局任意代码篡改Game手牌历史不在此事务可单独证明的范围。
