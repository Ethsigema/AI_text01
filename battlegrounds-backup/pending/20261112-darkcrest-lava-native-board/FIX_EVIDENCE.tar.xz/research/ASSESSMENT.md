# 普通暗潮 + 普通熔岩潜伏者：只读实现评估

日期2026-11-12。仅读取 `develop_darkcrest_tier6_20261112/remote_snapshot_dd428c2/restored_snapshot`，对应父线程已验证 source dd428c2 / final 15dcc575。不改任何源码、不运行Game、不上传。空位链和无证据Tier6饱和均暂停。

## 建议与价值

值得作为下一项小组合，但交付应精确称“普通暗潮在场时原生手牌中的普通熔岩潜伏者可打出、留场普通战斗、暗潮继续原有限EOT/新轮Spellcraft”。不声称验证熔岩永久保留塑造法术的玩法：此组合只施放暗潮的无目标生成法术，不会触发熔岩被动，spellcraft_kept必须保持0。

建议首批仅1张正常未改动BG23_009留场，和原普通暗潮父体共存；其余身份、金色、三连、外来塑造法术、混合owner历史仍held。必要时允许其正常移动/出售；离场不能把同UID复制对象当原实体重新准入。

## 关键纠正：Game.Lava不是普通熔岩

- 普通BG23_009当前scope manifest约488行包含；完整既有hand_candidate_records为2本2/5纳迦，effect仅 `spellcraft_permanent,count=1`。
- Game:312 的 Lava 是 `timewarped_lava_host.gd`，Sources.IDS为BG34_Giant_678/金色；其实际效果为时空扭曲自施法链，不应复用为普通BG23_009准入或改宽其environment_error。
- 普通状态应复用 `limited_turn_state.gd`：LAVA_NORMAL、独立普通effect签名、validate_unit_state约117–132；Game:5322–5324原始定向手牌塑造法术消费keep额度；Game:12029原始reset_turn。现普通unit factory字段spellcraft_kept=0。
- Combat:708 的RECRUIT_EFFECTS已包含spellcraft_permanent，因此普通被动在战斗中按招募效果处理；不需要给Combat新增Lava能力。此点仅静态证据，必须真实战斗确认。

## 已确定的三层阻塞

1. darkcrest_host.command_error约188：非暗潮/token打出全部other_play_held。
2. owner_error约75：任何非暗潮board身份other_board_listener_held。会影响后续所有命令、原生新轮token队列、消费、EOT，不仅首次play。
3. begin_eot约451–470、_eot_state_error约472–490、execute_eot约491：假定每个board位置均为暗潮；records.size==board.size，程序index直接访问p.board[index]。只放白名单会在此失败，甚至错误对Lava应用暗潮成长。

## 最小安全实现建议

### A. 实际手牌play事务，不宣称Darkcrest-only出生

按父线程经reviewer传达的范围澄清，本批不要求给所有Tier2生成新增出生凭证。最窄边界是实际Game/owner/hand[index]原对象、唯一UID与真实play事务，而不是单纯数值shape。保存的凭证证明该原生手牌实体已经沿原play进入board，不证明其必定由暗潮生成。

现Generation的begin/drawn/received仅Tier5/6接线；Tier2仍走原Bulk draw与_add_hand。这个事实必须保留在交付说明中，不能把现hand_state_error纯内容检查称为暗潮出生认证。无需为本组合改Generation域或增加Tier2全域birth系统。

真实验收样本仍应从暗潮Tier2完整原生域抽出Lava（BG23_002、BG23_009、BG31_924；BG_GIL_681仅legacy hand whitelist，当前manifest不含，不纳入本批实际域），然后正常打出；这证明该具体命令序列的真实来源，不等于新helper强制所有被准入Lava都是暗潮所生。

### B. 原生手牌打出与board准入

- command_error仅对 action=play、原手牌索引指向实际Lava对象时准入；spell别名、金色、修改stats/effects/base、keep>0、临时/附着/owner层均拒。保持其它牌other_play_held。
- 在Game既有实际手牌消费/入场接线（5014 remove_at、5023 board.insert）前后做只读绑定/确认。禁止在command_error/合法动作枚举这种可重复纯检查里登记play来源或提前标记已打出。
- board_error同时验证原owner/原object/唯一UID、入场完成记录及完整未改动原生状态；LimitedTurn可作为内容检查但不是来源签发。
- 暗潮施放是无目标生成，普通Lava不会改变；所有外来Spellcraft仍由Darkcrest command/owner边界拒绝。真实play经过Game.Lava.play_error不会误进入时空扭曲host，因为Sources.claimed(BG23_009)=false。

### C. EOT完整计划重构但不新增能力

- 保存完整board对象顺序快照（含Lava），另外记录仅暗潮的程序/parent记录和各自board_index。
- expected programs使用真实board_index，严格等于EndTurnRepeats.build_plan输出；Lava无EOT program，不能为它造空program或漏验其它未知program。
- _eot_state_error校验全board对象和位置未变，Lava仍原快照；暗潮records按board_index访问，不再拿程序序号当board位置。
- execute_eot按已绑定program.board_index取原暗潮，保留callback一次性、last_eot、tier+1、MAX6 held。finish_eot仍要求全部且仅全部暗潮程序执行。
- 测Lava左右与move后位置；至少一个多暗潮夹Lava的纯排程负例，避免只在末尾Lava偶然通过。

### D. 其它原链检查与不应主动修改的host

- Game play原后缀继续：_sync_board_aura、GlobalCards.summon_changes/counter_record、RecruitEvents on_play、原battlecry遍历、SpellcraftWaiting等。普通Lava没有战吼或Spellcraft授予，不可手工跳过后缀。
- 当前Edwin/无饰品任务畸变、仅普通暗潮+普通Lava场上，未发现时空扭曲Lava环境guard会激活。普通纳迦也不因all匹配beast等所有族层。
- next recruit原LimitedTurn.reset_turn应把0保持0；SpellcraftWaiting.queue_error→Darkcrest.owner_error允许认证Lava后仍只给暗潮生成新token。
- 战斗使用原Combat输入克隆。不能将战斗中的临时伤害/uid作为招募实体新来源，战后原Lava对象仍需完整/未修改。非零伤害实战比空场更能验证这里。
- 不提前改其它combat resource host。若真实四人基线出现新具体阻塞，再定位；本评估不是全局兼容承诺。

预计修改：Darkcrest Host、Game少量原生play观察接线，Sources及相关证据mirror/runtime指纹；可用独立小Lava custody helper收纳来源/入场生命周期，但必须由原Game回执绑定。LimitedTurn、普通spellcraft_permanent效果及Combat语义不应改。

## 真实测试与负例

- 从正常4人房真实购买/打出普通暗潮→一次EOT到Tier2→真实token完整Tier2域抽取。用初始seed/合法命令寻找BG23_009，不改库存/RNG/UID/tier/token，不缩小成单候选。
- 原手牌正常play Lava在暗潮左/右，验证同一对象/UID从hand唯一移至board、完整后缀成功、只1次入场；另一局move交换位置后EOT。
- 经过真实非空对手战斗与next recruit，保留原Lava招募对象，keep=0，暗潮等级按原1→2→3等推进、下一轮真实token继续生成。至少再一轮，最终6后仍held。
- 拒绝：同值复制对象/换UID/换owner/旧记录/未完成play或仅伪造board形状；非Lava结果；第二Lava（若单张准入）、金色、三连、未知effects/附着/数值增益/keep=1；外来目标Spellcraft；排程期全board顺序/来源替换、程序漏项/重复/错误board_index、重复EOT/callback/旧round。
- 拒绝要在手牌消费/库存/RNG/UID修改前；原生play回执的后验负责检查原链没有发生意外副作用，不当作回滚机制。
- Tier1–6既有回归，不能称所有Lava永久法术组合已完成。

## 风险与选择

主要工作量不是普通Lava被动，而是实际hand→board事务闭环与混合board EOT映射，属于可控但非一行修改。此项确有真实增量，可把已生成的卡转为实际战力并继续轮次；建议做，不提出另一个更小替代分散范围。无需扩Tier2出生系统；但不能以shape白名单替代真实play身份/一次性事务证明。
