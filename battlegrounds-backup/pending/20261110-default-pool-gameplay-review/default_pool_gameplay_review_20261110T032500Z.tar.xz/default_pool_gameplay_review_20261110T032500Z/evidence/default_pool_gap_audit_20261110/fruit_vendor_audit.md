# 当前默认池有限范围缺口审计

结论：找到真实且非 placeholder 的当前默认随从 BG36_346 水果商贩，其“手牌空位不足时发动”仍明确拒绝。但源证据不明确该边界应烧牌、等待或禁止发动，因此这是可核实的保守实现缺口，不能报告为已证明的规则错误或直接删门禁。

## 当前范围与身份
- current_scope_manifest.json status=ready；official.minion_ids 含 BG36_346（第204行），excluded_aberration_minion_ids 不含。
- current_scope.gd:30–40、55–68：真实默认主池来自 manifest 官方名单加娜迦补充，排除畸变怪；不是 overlay.default_pool。
- patch_3702_membership_sources.gd:13–18 的 revision、官方随从名单、娜迦名单、排除名单与 manifest 静态逐一相同，manifest SHA256 匹配。未运行 scope_error/Catalog。
- catalog.json:16307 起同时给 supported/default_pool/pool_supported=true，conditional_support 明确保留满手牌和竞争队列限制，仅作旁证。
- source_catalog/minions.json，sheet1 工作簿行2123：普通、在池、3星3/6、发动（1）：获取2张香蕉果盘。非占位来源。
- Catalog:14543–14551 仍会根据金色与效果依赖的 supported 状态降级，未执行全量初始化故不声称运行后所有门禁已通过。末端14554–14568是其他指定股票覆盖，不是重新定义当前范围。

## 真实缺口与入口
- Game:3081 activate_minion -> MinionActivate.activate:409 -> preflight:410。
- MinionActivate:26–34 定义普通来源、金色来源、香蕉ID、10张上限以及普通2张/金色4张。
- preflight:362 在剩余空位小于生成张数时明确返回“发动在手牌空位不足时的等待/烧牌规则尚未核实。”
- activate:411 将其返回为 ok=false、paid=0、delivered=0，发生在扣费与给牌之前。9张或10张手牌均触发普通来源此门禁（其他前置校验通过时）。
- 同模块349还拒绝曾使用组件当回合三连后的再次发动，293–302保留竞争队列/付款监听顺序限制；未深入核这些组合。

## 不擅自补规则
- 原始 native XML research/lucky_egg_rebuilt/BG36_346.native.xml 的 CARDTEXT 仅为 Activate/Get Tavern Dish Bananas；不能证明满手牌的合法性或溢出时序。
- Game:9947–9955 转入真实给牌路径；10030–10041 通用满手牌契约记录 hand_overflow，并归还未入手实体。
- 当前发动完成分支433–442逐张调用 engine._unit/engine._add_hand，但日志 delivered=count 无条件按计划数统计。即使决定复用通用烧牌，也不能只删除362行，否则回执/日志可能把烧掉的牌计作 delivered。
- 奖励保护队列与付款监听不应由通用给牌烧牌路径推导；必须取得发动边界证据后分别定义。

## 可测性与成本
- 只静态追踪 literal preload；minion_activate.gd 闭包838个GD，2464条边，21,369,968字节，未发现Game/Combat/Catalog直接进入闭包。
- 这不是轻量独立模块。真实 activate 依赖宿主付款票据、BloodGems/Mechanisms监听、_unit、_add_hand、日志。fake host 给牌会替换本次关键语义，不能作为真实实现验收。
- 允许未来引擎验证时，应使用生产宿主分别测试8/9/10张手牌，核付款、USED标记、入手/溢出事件、UID、监听及回执；金色来源再测6/7/10。当前未运行任何测试，不声称这些案例通过。

## 范围限制
仅静态查读现有源码、当前JSON和原始源行/native XML；Python受128MiB限制。未运行Godot、Game、Combat、Catalog或完整编译器，未联网，未读缓存/凭据/私聊/旧存档，未改原树。没有完成当前默认池全量交互审计；不能据此声称其余卡完整或无缺口。
