# 有限只读候选调查

结论：BG31_035 碎地者是真实当前默认范围缺口，但本轮不可安全实现或声称在192MiB内验收。未推荐执行实验，未运行Godot/Game/Combat/Catalog/完整编译器。全部Python通过ulimit -v 131072运行。未改生产文件。

## 范围与证据

current_scope.gd:30–40、65–73选择manifest官方随从/法术并补纳迦、排除畸变，共317项。manifest status=ready。revision、minion_ids、naga_ids、excluded_ids与patch_3702_membership_sources.gd常量逐项一致，manifest SHA也匹配scope_error:13–18。SHA与源表完整记录见independent_candidate_evidence.json。

405项catalog.default_pool=true不能代表这一真实房间范围。317项有23项无catalog overlay，其中21项有原始来源行；BG35_912/BG36_883未在两张源表找到。多数缺overlay项已有patch_3702生产实现，不是新玩法。

## 最小真缺口：碎地者

BG31_035，普通6星6/4纳迦，source_catalog/minions.json sheet1 row1561：在你使用一张纳迦牌后，获得+1/+1。（在本局对战中，你每施放3个法术都会提升！）
BG31_035_G，金色独立row1562为12/8，获得+2/+2，其余文本相同。两条catalog_raw记录supported=false、effects=[]、quality_flags=[]，非placeholder。它们在core中只出现于成员及factory/dark-gift事实常量，无执行host；tools/*.py及catalog.gd未直接命中ID。runtime_coverage.json:10301也列not_implemented_or_dependency，仅作为旁证。catalog.gd:11820–11821为未声明supported的来源默认false；没有发现本ID后置overlay。

文字支持计入本局所有法术、包含入场前历史，而非仅酒馆法术。普通/金色基础增益可确定，**每档提升的确切数值、黄金提升规则、自动施法/战斗施法全入口计数一致性未由独立原生定值证据闭合**。未发现research下以BG31_035开头的独立native文件；不能把“未发现”写为不存在。

Game.game.gd:16655–16699真实_notify_played按board副本遍历并排除played本体，已有带私有上下文的on_play host接缝；接入需证明相同实际打出事件身份和完整触发顺序。Game:5496普通真实法术完成后增加p.stats.spells，之后另按_is_tavern_spell记录GlobalCards tavern_spells；5760额外施法也增加计数。因此计数不能改成酒馆专属。thaumaturgy.gd也读取p.stats.spells，但不能据此假定所有入口已完整闭合。

Game:6756起_buff不只是两个属性加法，还调用向量modifier、private gain plan、AttackGains、Aura等。禁止提取该函数或fake _buff代替真实状态提交。保留全部真实preload的Game静态闭包为2070文件/42,789,793字节源码（不是内存测量），与禁止运行Game条件不兼容；不能据小新模块本身大小推断192MiB验收可行。

## 其他真实缺口

BG31_920暗潮战略专家：5星4/5，row2417，塑造法术随机获取等级1纳迦，每回合提升。需要随机完整池、子法术和升级时序，较重。
BG31_925显眼的骑手：5星4/2，row2423，亡语所有纳迦+2/+1，每施放3法术提升。需要同类全局历史及战斗亡语同步。
EBG_Spell_037身份揭晓：5星3费，spells.json Sheet1 row339，发现新英雄技能。需要完整英雄技能选择和替换生命周期，不是小闭包。timewarp_rodeo_host:4只是允许名单，不是此效果实现。

这四项完整raw记录均supported=false/effects=[]，源文件与SHA已保存。没有把覆盖报告独自当真值。

## 拒绝点与真实preload闭包

threshold_damage_listeners:50，BG35_814在真实范围，atomic shadow达到6攻击时明确unimplemented；但这是已有机制的组合边界，222文件/6,938,723字节，不是新卡效果。
bulk_global_card_stats:213/285/542为禁用、负层重基准和乘法边界，239文件/7,358,737字节。
bulk_hero_damage_recruit:80为致死回溯边界，855文件/21,674,103字节。
discard_spell_cast_bridge:24为未知cast listener拒绝，7文件/150,635字节，但实际提交仍依赖engine.DiscardHost等动态host；不能以静态preload小声称真实运行闭包小。
combat_tribe_bonuses:25很小（4文件/36,156字节），但拒绝非combat duration，不足证明当前默认卡缺口。
thaumaturgy.gd的2文件/26,505字节是已实现同类计数例子，不能当本次新增效果。

因此本轮只交证据与不可安全实施限制，不试192MiB、不重试PrizeBuffs247、不提高上限、不削弱依赖。
