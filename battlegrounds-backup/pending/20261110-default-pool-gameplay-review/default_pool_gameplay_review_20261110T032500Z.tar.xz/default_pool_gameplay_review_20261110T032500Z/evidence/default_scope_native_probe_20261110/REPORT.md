# 当前默认池原函数验证

一次运行通过，27 个断言通过。实际 main_ids：{'minion': 247, 'spell': 70, 'hero': 116}。

指定四个随从、EBG_Spell_037 均在相应主池，两项 Prize 均不在任何主池。revision、官方随从删除、娜迦列表变动、status 非 ready 的内存副本均返回错误，三类 main_ids 全为空。res manifest 未修改。

原文件与复制文件运行后 SHA256 全保持一致。启动无其他 Godot，运行约 0.64 秒，wait4 峰值 RSS 61,668 KiB，低于 192 MiB 停止阈值；其余约束见 result/PROCESS.json。

只验证真实默认主池筛选边界。未运行 proof_error、Catalog、Game、Combat、select_defaults 或完整编译器，不是完整 Catalog 门禁或玩法验收。
