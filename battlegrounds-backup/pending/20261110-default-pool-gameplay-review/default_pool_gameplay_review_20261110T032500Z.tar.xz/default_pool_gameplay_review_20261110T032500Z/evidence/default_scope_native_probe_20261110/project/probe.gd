extends SceneTree
const CurrentScope = preload("res://core/current_scope.gd")
var failed: bool = false
func check(ok: bool, label: String) -> void:
 print(JSON.stringify({"assertion":label,"pass":ok}))
 if not ok: failed = true
func _initialize() -> void:
 var value: Dictionary = CurrentScope.manifest()
 var issue: String = CurrentScope.manifest_error(value)
 check(issue.is_empty(), "actual_manifest_valid")
 var ids: Dictionary = {}
 for kind in ["minion","spell","hero"]:
  ids[kind] = CurrentScope.main_ids(kind,value)
  print(JSON.stringify({"case":"valid", "kind":kind, "count":ids[kind].size(), "ids":ids[kind]}))
  check(ids[kind] == CurrentScope.main_ids(kind), "file_default_matches_"+kind)
 for id in ["BG36_346","BG31_035","BG31_920","BG31_925"]:
  check(id in ids.minion, "current_minion_"+id)
 check("EBG_Spell_037" in ids.spell, "current_spell_EBG_Spell_037")
 for id in ["BGS_Treasures_028","BG21_018"]:
  check(id not in ids.minion and id not in ids.spell and id not in ids.hero, "prize_not_main_"+id)
 for label in ["revision_changed","official_minion_removed","naga_changed","status_not_ready"]:
  var bad: Dictionary = value.duplicate(true)
  match label:
   "revision_changed": bad.revision += "-probe"
   "official_minion_removed": bad.official.minion_ids.remove_at(0)
   "naga_changed": bad.naga_overlay.minion_ids.remove_at(0)
   "status_not_ready": bad.status = "pending"
  var error: String = CurrentScope.manifest_error(bad)
  print(JSON.stringify({"case":label,"manifest_error":error}))
  check(not error.is_empty(),label+"_rejected")
  for kind in ["minion","spell","hero"]:
   var output: Array = CurrentScope.main_ids(kind,bad)
   print(JSON.stringify({"case":label,"kind":kind,"count":output.size()}))
   check(output.is_empty(),label+"_empty_"+kind)
 if not failed: print("CURRENT_SCOPE_NATIVE_FUNCTIONS_OK")
 quit(1 if failed else 0)
