extends RefCounted
const Patch3702Membership=preload("res://core/patch_3702_membership_sources.gd")
## Product scope only. Never changes source effects, lookup, factories or support.
const PATH: String = "res://data/current_scope_manifest.json"
const SCOPE_ID: String = "current_solo_six_extras_naga_20261029"
const FIELD: String = "product_scope"
const KEYS: Dictionary = {"minion":"enabled_minions","spell":"enabled_spells","hero":"enabled_heroes","anomaly":"enabled_anomalies","trinket":"enabled_trinkets","quest":"enabled_quests","reward":"enabled_rewards"}
const MAIN: Array = ["minion","spell","hero"]
const EXTRA_LABELS: Array = ["畸变","伙伴","饰品","时空扭曲","任务","黑暗之赐"]

static func manifest() -> Dictionary:
	if not FileAccess.file_exists(PATH): return {}
	var value: Variant=JSON.parse_string(FileAccess.get_file_as_string(PATH))
	return value if value is Dictionary else {}

static func manifest_error(value: Dictionary) -> String:
	var membership_issue: String=Patch3702Membership.scope_error(value)
	if not membership_issue.is_empty(): return membership_issue
	if value.get("status","")!="ready": return "当前版本成员清单仍待来源确认；不会回退到历史全池。"
	if value.get("scope_id","")!=SCOPE_ID or str(value.get("revision","")).is_empty(): return "当前范围清单身份或修订信息缺失。"
	if not value.get("official") is Dictionary: return "当前官方成员清单缺失。"
	for key in ["minion_ids","spell_ids","hero_ids"]:
		if not value.official.get(key) is Array or value.official[key].is_empty(): return "当前官方成员清单缺失："+key
		for id in value.official[key]:
			if not id is String or id.is_empty(): return "当前成员身份格式无效："+key
	if not value.get("excluded_aberration_minion_ids") is Array: return "畸变怪排除清单尚未提供。"
	if not value.get("naga_overlay") is Dictionary or not value.naga_overlay.get("minion_ids") is Array: return "下线前最后娜迦随从清单尚未提供。"
	return ""

static func main_ids(kind: String, value: Dictionary = {}) -> Array:
	var source: Dictionary=manifest() if value.is_empty() else value
	if not manifest_error(source).is_empty() or kind not in MAIN: return []
	var result: Array=[]
	for id in source.official[kind+"_ids"]:
		if kind=="minion" and id in source.excluded_aberration_minion_ids: continue
		if id not in result: result.append(id)
	if kind=="minion":
		for id in source.naga_overlay.minion_ids:
			if id not in source.excluded_aberration_minion_ids and id not in result: result.append(id)
	return result

static func extra_groups(card: Dictionary) -> Array:
	var result: Array=[]
	var tags: Array=card.get("mechanisms",[]).duplicate()
	tags.append_array(card.get("categories",[]))
	for group in EXTRA_LABELS:
		if group in tags or group=="饰品" and "酒馆饰品" in tags: result.append(group)
	var kind: String=str(card.get("kind",""))
	if kind=="anomaly" and "畸变" not in result: result.append("畸变")
	if kind=="trinket" and "饰品" not in result: result.append("饰品")
	if kind=="quest" and "任务" not in result: result.append("任务")
	if "任务奖励" in tags and "任务" not in result: result.append("任务")
	return result

static func allows_pool(kind: String, id: String, catalog, value: Dictionary = {}) -> bool:
	if kind in MAIN: return id in main_ids(kind,value)
	if kind not in KEYS: return false
	var card: Dictionary=catalog.get_card(id)
	if str(card.get("kind",""))!=kind: return false
	if kind in ["anomaly","trinket","quest"]: return true
	return kind=="reward" and ("任务" in extra_groups(card) or "黑暗之赐" in extra_groups(card))

static func select_defaults(data: Dictionary, catalog) -> void:
	var source: Dictionary=manifest()
	data[FIELD]={"id":SCOPE_ID,"revision":str(source.get("revision","pending"))}
	data.season_id=SCOPE_ID
	for kind in MAIN: data[KEYS[kind]]=main_ids(kind,source)
	# Extras retain original opt-in/default choices, not all simultaneous systems.
	for kind in ["anomaly","trinket","quest","reward"]:
		data[KEYS[kind]]=data.get(KEYS[kind],[]).filter(func(id):return allows_pool(kind,str(id),catalog,source))
	data.native_prizes=false
	data["scope_dependency_notice"]="主池按当前官方成员及指定娜迦补充；依赖冲突不自动删英雄、法术或改效果。"

static func room_errors(data: Dictionary, catalog) -> Array[String]:
	var errors: Array[String]=[]
	var source: Dictionary=manifest()
	var issue: String=manifest_error(source)
	if not issue.is_empty(): errors.append(issue);return errors
	var marker: Variant=data.get(FIELD)
	if not marker is Dictionary or marker.get("id","")!=SCOPE_ID or marker.get("revision","")!=source.revision:
		errors.append("旧房间/存档或不同成员修订不属于当前范围；原文件保留，请显式新建当前范围房间。")
		return errors
	for kind in KEYS:
		for id in data.get(KEYS[kind],[]):
			if not allows_pool(kind,str(id),catalog,source): errors.append("范围外条目暂不开放："+kind+" / "+str(id)+"；保留原数据，不自动删除。")
	for id in data.get("shop_overrides",{}):
		var kind: String=str(catalog.get_card(str(id)).get("kind",""))
		if kind not in ["minion","spell"] or not allows_pool(kind,str(id),catalog,source): errors.append("自定义入店不能绕过当前范围："+str(id))
	# The independent global prize switch is paused. Its actual anomaly/hero
	# dependencies remain available through their original native source routes.
	if data.get("native_prizes",false): errors.append("独立暗月奖品开关暂停；保留英雄/畸变原生奖品依赖及全部源代码。")
	return errors

static func records(catalog,kind: String,supported_only: bool=false) -> Array:
	var result: Array=[]
	var seen: Dictionary={}
	for card in catalog.list_cards(kind,"",supported_only):
		if allows_pool(kind,str(card.id),catalog): result.append(card);seen[card.id]=true
	# Missing local definitions stay visible as missing, not silently dropped.
	if kind in MAIN and not supported_only:
		for id in main_ids(kind):
			if not seen.has(id): result.append({"id":id,"name":id,"kind":kind,"supported":false,"pool_supported":false,"text":"当前范围成员；本地来源/实现定义待接入。"})
	return result

static func summary() -> String:
	var source: Dictionary=manifest()
	var issue: String=manifest_error(source)
	if not issue.is_empty(): return issue
	return "当前官方基础 + 下线前最后娜迦随从（定制补充），排除畸变怪。\n保留畸变、伙伴、饰品、时空扭曲、任务、黑暗之赐；未实现条目不自动移出。\n娜迦额外英雄/法术仅列可选资料，未自动加入；实际依赖限制保持原规则。"
