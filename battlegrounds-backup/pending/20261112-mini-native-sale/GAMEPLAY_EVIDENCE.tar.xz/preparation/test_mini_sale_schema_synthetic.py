"""Detached synthetic validator examples. Never Game, live entities, or runtime proof."""
from pathlib import Path
from copy import deepcopy
import json,tempfile
import run_remote_mini_sale as r

def rejected(fn,label):
 try:fn()
 except (ValueError,AssertionError,KeyError,TypeError,FileNotFoundError):return label
 raise AssertionError('Accepted synthetic negative '+label)

def full_fixture():
 diagnostic={'native_factory_preview':True,'actual_token_issuance':False,'uid_allocated':False,'zone_inserted':False,'shape_error':'',
   'key_types':[{'key':key,'key_type':pair[0],'value_type':pair[1]} for key,pair in r.NATIVE_PREVIEW_TOP_TYPES.items()],
   'base_key_types':[{'key':key,'key_type':pair[0],'value_type':pair[1]} for key,pair in r.NATIVE_PREVIEW_BASE_TYPES.items()]}
 passes=['PASS '+key for key,count in r.MINI_SALE_FULL_MARKERS.items() for _ in range(count)]+['PASS public_darkcrest_play_u30','PASS synthetic_dynamic_funding_observation']
 n=len(passes)
 log='MINI_NATIVE_PREVIEW_KEY_TYPES '+json.dumps(diagnostic)+'\nDARKCREST_MINI_SALE_MATRIX_LOAD_BEGIN\n'+'\n'.join(passes)+'\nDARKCREST_MINI_SALE_REAL_MATRIX_PASS cases=1 casts=1 combats=1 checks='+str(n)+'\n'
 row={'scope':r.MINI_SALE_SCOPE,'seed':20261120,'checks':n-1,'native_preview_diagnostic':diagnostic,
   'acquisitions':[{'id':'BG23_000','uid':'u10','rolls':80,'source_owned':False},{'id':'BG23_009','uid':'u20','rolls':100,'source_owned':False}],
   'sale':{'mini_uid':'u10','token_uid':'u40','index':1,'round':1,'gold_before':5,'gold_after':6,'stock_before':14,'stock_after':15,
           'sold_before':0,'sold_after':1,'uid_before':50,'uid_after':50,'rng_before':-1234,'rng_after':-1234,'retired':True,
           'retired_sequence':20,'token_same_reference':True,'token_record_same_reference':True},
   'casts':[{'round':1,'source_uid':'u10','token_uid':'u40','target_uid':'u20','attack_before':2,'attack_after':4,'health':5,'kept':1}],
   'combats':[{'round':1,'target_uid':'u20','combat_start':{'uid':'u20','card_id':'BG23_009','kind':'minion','golden':False,'attack':4,'health':5,'max_health':5},'recruit_attack':4,'recruit_health':5,'recruit_kept':0}],
   'darkcrest_uid':'u30','darkcrest_final_tier':2,'lava_uid':'u20','mini_uid':'u10','no_next_round_mini_token':True,
   'coin_pre_source_fixture':True,'entirely_natural_game':False,'sold_source_unused_expiry_tested':False,'old_full_matrix_repeated':False}
 return row,log,n

def main():
 passed=[];previous=r.NEW_TEST_METADATA['pure_checks'];r.NEW_TEST_METADATA['pure_checks']=102
 row,log,n=full_fixture()
 with tempfile.TemporaryDirectory(prefix='mini_sale_schema_',dir=Path(__file__).parent) as temp:
  root=Path(temp);path=root/r.NEW_TEST_METADATA['scenario_file']
  def full(value,text=log):
   path.write_text(json.dumps(value));return r.validate('mini_sale_real_matrix',text,None,root)
  assert full(row)==(n,row);passed.append('synthetic_exact_one_sale_cast_combat_positive_NOT_GAMEPLAY')
  mutations=[(['checks'],n,'checks_plus_one_required'),(['checks'],True,'strict_integer_checks'),(['seed'],123,'wrong_seed'),
   (['scope'],'all source departures','wrong_scope'),(['darkcrest_final_tier'],4,'old_source4_draft_rejected'),
   (['no_next_round_mini_token'],False,'unexpected_regrant'),(['coin_pre_source_fixture'],False,'hidden_fixture'),
   (['entirely_natural_game'],True,'false_natural_game_claim'),(['sold_source_unused_expiry_tested'],True,'unproven_sale_unused_expiry'),
   (['old_full_matrix_repeated'],True,'old_full_must_not_repeat'),(['acquisitions',0,'rolls'],81,'Mini_roll_bound'),
   (['acquisitions',1,'source_owned'],True,'wrong_acquisition_time'),(['sale','mini_uid'],'u20','wrong_sold_original'),
   (['sale','token_uid'],'u10','body_is_not_token'),(['sale','index'],0,'wrong_native_position'),(['sale','round'],2,'wrong_sale_round'),
   (['sale','gold_after'],5,'missing_sale_gold'),(['sale','stock_after'],14,'missing_native_stock_return'),
   (['sale','sold_after'],2,'wrong_sale_counter'),(['sale','uid_after'],51,'sale_must_not_allocate_uid'),
   (['sale','rng_after'],-1233,'sale_must_not_consume_rng'),(['sale','retired'],False,'missing_retirement'),
   (['sale','retired_sequence'],0,'invalid_retirement_sequence'),(['sale','token_same_reference'],False,'token_replaced'),
   (['sale','token_record_same_reference'],False,'token_record_replaced'),(['casts',0,'token_uid'],'u41','not_preserved_original_token'),
   (['casts',0,'source_uid'],'u30','wrong_cast_source'),(['casts',0,'round'],2,'cast_not_same_turn'),
   (['casts',0,'attack_after'],6,'old_two_cast_scope_rejected'),(['casts',0,'kept'],0,'missing_permanence_kept'),
   (['combats',0,'recruit_attack'],2,'lost_permanent_attack'),(['combats',0,'recruit_kept'],1,'missing_native_reset'),
   (['combats',0,'combat_start','attack'],2,'combat_copy_lost_buff'),(['combats',0,'combat_start','golden'],True,'golden_not_scope')]
  for keys,value,label in mutations:
   wrong=deepcopy(row);target=wrong
   for key in keys[:-1]:target=target[key]
   target[keys[-1]]=value;passed.append(rejected(lambda:full(wrong),label))
  for field in row:
   wrong=deepcopy(row);wrong.pop(field);passed.append(rejected(lambda:full(wrong),'missing_'+field))
  for field in ['casts','combats']:
   wrong=deepcopy(row);wrong[field].append(deepcopy(wrong[field][0]));passed.append(rejected(lambda:full(wrong),'extra_'+field))
  for text,label in [(log.replace('casts=1','casts=2'),'wrong_full_marker'),(log+'PASS extra\n','count_mismatch'),
    (log.replace('PASS completed_native_sale_custody_before_cast','PASS replaced'),'missing_completed_sale_custody_marker'),
    (log.replace('PASS original_waiting_token_bound_to_exact_mini_owner_round','PASS replaced'),'missing_actual_issuance_checks'),
    (log+'SCRIPT ERROR: synthetic\n','error_cannot_pass')]:passed.append(rejected(lambda:full(row,text),label))
  pure_lines=['PASS '+name for name,count in r.MINI_SALE_PURE_MARKERS.items() for _ in range(count)]
  pure_lines+=['PASS '+prefix+'synthetic'+str(index) for prefix,count in r.MINI_SALE_PURE_PREFIX_COUNTS.items() for index in range(count)]
  assert len(pure_lines)==102
  pure={'passed':102,'failed':0,'failures':[],'real_game_run':False,'actual_provenance_proven':False,'scope':r.MINI_SALE_PURE_SCOPE}
  def pure_log(value):return '\n'.join(pure_lines)+'\nDARKCREST_MINI_SALE_CONTENT_CONTRACT '+json.dumps(value)+'\n'
  assert r.validate('mini_sale_content_contract',pure_log(pure),102,root)==(102,None);passed.append('synthetic_pure102_schema_NOT_ACTUAL_COUNT_PROOF')
  for field,value,label in [('passed',60,'old_pure60_refused'),('failed',True,'boolean_fail_count'),('real_game_run',True,'pure_not_Game'),('actual_provenance_proven',True,'fake_refusals_not_provenance'),('scope','deep retired branches proven','unproven_deep_claim')]:
   wrong=dict(pure);wrong[field]=value;passed.append(rejected(lambda:r.validate('mini_sale_content_contract',pure_log(wrong),102,root),label))
  altered=pure_log(pure).replace('PASS fake_source_custody_cannot_authorize_cast','PASS omitted_fake_refusal')
  passed.append(rejected(lambda:r.validate('mini_sale_content_contract',altered,102,root),'missing_three_early_custody_refusals'))
  r.NEW_TEST_METADATA['pure_checks']=None
  passed.append(rejected(lambda:r.validate('mini_sale_content_contract',pure_log(pure),102,root),'UNKNOWN_actual_count_refused'))
 r.NEW_TEST_METADATA['pure_checks']=previous
 print(json.dumps({'status':'PASS_SYNTHETIC_MINI_SALE_SCHEMA_NOT_GAMEPLAY','checks':len(passed),'labels':passed,'game_started':False,'godot_started':False,'actual_new_pure_count_not_inferred':True,'actual_Game_count_not_assumed':True}))
if __name__=='__main__':main()
