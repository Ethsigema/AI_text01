from pathlib import Path,PurePosixPath
import json,hashlib,subprocess,tarfile,datetime
P=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
commit='ce927340b68be225d3389d8dd216d1404f6f06ac';folder='battlegrounds-backup/audits/20261112T1510Z-pre-next-cleanup'
meta=json.loads((P/'PRE_CLEANUP_UPLOAD_METADATA.json').read_text());assert meta['remote_folder']==folder and meta['files']==4
out=P/'pre_cleanup_remote_ce92734';out.mkdir(exist_ok=False)
pub={'commit':commit,'parent':'0318fed31abdec3b31dc6ce391d75d56112caa9c','remote_folder':folder,'files':4,'parent_publication_reported_by_coordinator':True};(P/'PRE_CLEANUP_PUBLICATION.json').write_text(json.dumps(pub,indent=2)+'\n')
records=[]
for row in meta['records']:
 n=row['name'];assert n==PurePosixPath(n).name and n not in ('','.','..')
 url=f'https://raw.githubusercontent.com/Ethsigema/AI_text01/{commit}/{folder}/{n}';p=out/n
 subprocess.run(['curl','-fsSL','--retry','3','--connect-timeout','30','--max-time','120',url,'-o',str(p)],check=True)
 b=p.read_bytes();assert len(b)==row['bytes'] and sha(b)==row['sha256'] and hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==row['git_sha'];records.append({**row,'url':url})
assert {p.name for p in out.iterdir()}=={x['name'] for x in records}
seen=set()
for line in (out/'SHA256SUMS.txt').read_text().splitlines():
 h,n=line.split('  ',1);assert n==PurePosixPath(n).name and n not in seen and n!='SHA256SUMS.txt';assert sha((out/n).read_bytes())==h;seen.add(n)
assert seen=={x['name'] for x in records}-{'SHA256SUMS.txt'}
m=json.loads((out/'LATE_EVIDENCE_MANIFEST.json').read_text());assert sha((out/'LATE_EVIDENCE.tar.xz').read_bytes())==m['archive_sha256'];actual={}
with tarfile.open(out/'LATE_EVIDENCE.tar.xz') as t:
 for x in t:
  assert x.isfile() and not PurePosixPath(x.name).is_absolute() and '..' not in PurePosixPath(x.name).parts and '\\' not in x.name and x.name not in actual
  b=t.extractfile(x).read();actual[x.name]={'bytes':len(b),'sha256':sha(b)}
assert actual==m['members'] and len(actual)==30
report={'status':'PASS_FRESH_PRE_CLEANUP_PUBLICATION_EVERY_FILE_AND_MEMBER','commit':commit,'remote_folder':folder,'files':len(records),'bytes':sum(x['bytes'] for x in records),'records':records,'members':len(actual),'member_bytes':sum(x['bytes'] for x in actual.values()),'every_member_rehashed':True,'sha256sums_sha256':sha((out/'SHA256SUMS.txt').read_bytes()),'checked_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'deleted':[],'game_started':False,'new_source_tree':False}
(P/'PRE_CLEANUP_PUBLICATION_VERIFIED.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k!='records'},indent=2))
