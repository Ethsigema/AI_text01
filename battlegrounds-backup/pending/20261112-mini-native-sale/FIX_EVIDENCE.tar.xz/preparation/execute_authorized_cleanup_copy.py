from pathlib import Path
import json,gzip,hashlib,fcntl,shutil,datetime,tarfile
R=Path.cwd();P=R/'develop_lava_next_20261112/preparation';sha=lambda b:hashlib.sha256(b).hexdigest();read=lambda p:json.loads(p.read_text());utc=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
ns={};exec((P/'cleanup_preflight.py').read_text().split('specs=')[0],ns);scan=ns['scan'];sums=ns['sums']
pre=read(P/'CLEANUP_PREFLIGHT.json');base=read(P/'BASE_INTERMEDIATE_PREFLIGHT.json');publication=read(P/'PRE_CLEANUP_PUBLICATION_VERIFIED.json');assert publication['commit']=='ce927340b68be225d3389d8dd216d1404f6f06ac' and publication['every_member_rehashed']
remote=P/'pre_cleanup_remote_ce92734'
for row in publication['records']:
 b=(remote/row['name']).read_bytes();assert len(b)==row['bytes'] and sha(b)==row['sha256']
with tarfile.open(remote/'LATE_EVIDENCE.tar.xz') as tar:
 for name in ['CLEANUP_PREFLIGHT.json','BASE_INTERMEDIATE_PREFLIGHT.json']:
  assert tar.extractfile('develop_lava_next_20261112/preparation/'+name).read()==(P/name).read_bytes()
allowed=[R/'recover_tier5_after_environment_change_20261112/candidate_rebuilt',R/'develop_lava_permanent_v2_20261112/candidate',R/'develop_lava_followup_20261112/fresh_remote/restored_base'];assert [Path(x['candidate_path']) for x in pre['targets']]+[Path(base['target'])]==allowed
with Path(pre['common_lock']).open('r') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);before=shutil.disk_usage(R)._asdict();checks=[];preserved=[]
 for row in pre['targets']:
  target=Path(row['candidate_path']);restore=Path(row['equivalent_preserved_restore']);pkg=(restore.parent.parent if restore.parent.name=='single_tree_restore' else restore.parent)/'package';m=read(pkg/'MANIFEST.json');raw=gzip.decompress((pkg/'SOURCE_MAP.json.gz').read_bytes());assert sha(raw)==row['source_map_sha256'] and sha((pkg/'MANIFEST.json').read_bytes())==row['manifest_sha256'];assert sha(Path(row['publication_receipt']).read_bytes())==row['publication_receipt_sha256'];expected=json.loads(raw)
  a=scan(target,expected,m['aggregate_sha256']);b=scan(restore,expected,m['aggregate_sha256']);assert a==row['candidate_full_check'] and b==row['restore_full_check'];sums(pkg)
  for p in map(Path,row['preserved_directories']):
   assert p.is_dir();preserved.append(p)
   if (p/'SHA256SUMS.txt').exists():sums(p)
  checks.append({'path':str(target),'equivalent':str(restore),'fullcheck':a})
 target=allowed[2];other=Path(base['equivalent_retained_base']);pkg=target.parent/'base_package';raw=gzip.decompress((pkg/'SOURCE_MAP.json.gz').read_bytes());assert sha(raw)==base['source_map_sha256'];expected=json.loads(raw);a=scan(target,expected,base['target_check']['aggregate_sha256']);b=scan(other,expected,base['retained_check']['aggregate_sha256']);assert a==base['target_check'] and b==base['retained_check'];sums(pkg);checks.append({'path':str(target),'equivalent':str(other),'fullcheck':a});preserved+=list(map(Path,base['preserved_paths']));assert all(x.exists() for x in preserved)
 for p in allowed:shutil.rmtree(p)
 assert all(not p.exists() for p in allowed) and all(p.exists() for p in preserved)
 after=shutil.disk_usage(R)._asdict();report={'status':'AUTHORIZED_EXACT_THREE_NON_BACKUP_DUPLICATES_DELETED','utc':utc(),'deleted_paths':list(map(str,allowed)),'checks':checks,'preserved_paths':list(map(str,preserved)),'before_disk':before,'after_disk':after,'available_bytes_increase':after['free']-before['free'],'history_scripts_unchanged':True,'old_sale_base_replacement':str(other),'backups_deleted':False,'game_started':False}
 (P/'CLEANUP_EXECUTED.json').write_text(json.dumps(report,indent=2)+'\n');print('DELETED_EXACT_THREE',report['available_bytes_increase'],flush=True)
 source=R/'develop_lava_permanent_v2_20261112/remote_snapshot_0b2962c/single_tree_restore/restored_snapshot';pkg=source.parent.parent/'package';raw=gzip.decompress((pkg/'SOURCE_MAP.json.gz').read_bytes());expected=json.loads(raw);m=read(pkg/'MANIFEST.json');one=scan(source,expected,m['aggregate_sha256']);two=scan(source,expected,m['aggregate_sha256']);assert one==two
 dest=P.parent/'candidate';assert not dest.exists();shutil.copytree(source,dest);copied=scan(dest,expected,m['aggregate_sha256']);assert copied==one
 (P/'CANDIDATE_PREIMAGE_SOURCE_MAP.json').write_bytes(raw);(P/'CANDIDATE_PREIMAGE_SOURCE_SHA256.json').write_text(json.dumps({n:x['sha256'] for n,x in expected.items()},indent=2,sort_keys=True)+'\n')
 result={'status':'PASS_ACCEPTED_MINI_V2_SOURCE_DOUBLE_READ_AND_INDEPENDENT_COPY','source_commit':'0b2962c294aa4c0e4354bdc119f2fecd732d3c03','final_commit':'7f88ffc807925d7c5c82345dffc91bab1b1516e0','source':str(source),'candidate':str(dest),'source_map_sha256':sha(raw),'source_first_read':one,'source_second_read':two,'candidate_verified':copied,'no_hardlinks':True,'game_started':False,'disk':shutil.disk_usage(R)._asdict()};(P/'CANDIDATE_PREIMAGE_VERIFIED.json').write_text(json.dumps(result,indent=2)+'\n');print('CANDIDATE_READY',result['disk'],flush=True)
