from pathlib import Path
import json,gzip,sys,tarfile,subprocess
R=Path(__file__).resolve().parent;sys.path.insert(0,str(R/'snapshot_tools'))
from common import verify,sha,dump,write,utc,safe
D=json.loads((R/'FRESH_DOWNLOAD_VERIFIED.json').read_text());assert D['files']==55
for row in D['records']:
 b=(R/row['filename']).read_bytes();assert len(b)==row['bytes'] and sha(b)==row['sha256']
for package in ['base_package','accepted_mini_package']:
 checked=set()
 for line in (R/package/'SHA256SUMS.txt').read_text().splitlines():
  h,n=line.split('  ',1);assert safe(n) and '/' not in n and n not in checked;assert sha((R/package/n).read_bytes())==h;checked.add(n)
 assert checked=={p.name for p in (R/package).iterdir() if p.is_file()}-{'SHA256SUMS.txt'}
base_bytes=gzip.decompress((R/'base_package/SOURCE_MAP.json.gz').read_bytes());base=json.loads(base_bytes)
assert sha(base_bytes)=='7fec8d69e82de8bfcb7373549951f9456671b5c3980135d6ec6f983a3daf5ed7'
m=json.loads((R/'accepted_mini_package/MANIFEST.json').read_text());target=dict(base)
for n in m['removed']:del target[n]
target.update(m['changed_files']);encoded=dump(target)
assert sha(encoded)=='ca877c349b8ac23c15e851a850cbf10cc260b66fffc22f04c45883dcffa72a22'
assert gzip.decompress((R/'accepted_mini_package/SOURCE_MAP.json.gz').read_bytes())==encoded
prior=json.loads((R.parent/'preparation/CANDIDATE_PREIMAGE_VERIFIED.json').read_text());assert prior['source_map_sha256']==sha(encoded) and prior['candidate_verified']['aggregate_sha256']==m['aggregate_sha256']
with (R/'ACCEPTED_MINI_SOURCE_MAP.json').open('xb') as f:f.write(encoded)
counts={}
for prefix,count in [('FIX',62),('TOOLS',57),('GAMEPLAY',127)]:
 meta=json.loads((R/f'accepted_mini_package/{prefix}_EVIDENCE_MANIFEST.json').read_text());expected=meta if prefix=='FIX' else meta['members'];seen=set()
 if prefix!='FIX':assert meta['source_commit']=='0b2962c294aa4c0e4354bdc119f2fecd732d3c03' and sha((R/f'accepted_mini_package/{prefix}_EVIDENCE.tar.xz').read_bytes())==meta['archive_sha256']
 with tarfile.open(R/f'accepted_mini_package/{prefix}_EVIDENCE.tar.xz') as t:
  for x in t:
   assert x.isfile() and safe(x.name) and x.name not in seen
   b=t.extractfile(x).read();assert {'bytes':len(b),'sha256':sha(b)}==expected[x.name];seen.add(x.name)
 assert seen==set(expected) and len(seen)==count;counts[prefix]=count
outcome=json.loads((R/'accepted_mini_package/GAMEPLAY_OUTCOME.json').read_text());assert outcome['outcome']=='success' and outcome['source_commit']=='0b2962c294aa4c0e4354bdc119f2fecd732d3c03';assert (R/'accepted_mini_package/GAMEPLAY_INDEPENDENT_VERIFICATION.json').exists()
write(R/'CURRENT_EVIDENCE_VERIFIED.json',{'status':'PASS_FRESH_ACCEPTED_MINI_ALL_THREE_EVIDENCE_ARCHIVES','members':counts,'checked_at_utc':utc(),'historical_tests_not_current_execution':True})
write(R/'ACCEPTED_MINI_PREIMAGE_METADATA_VERIFIED.json',{'status':'PASS_FRESH_ACCEPTED_MINI_MAP_ONLY_NO_NEW_ACCEPTED_MINI_TREE_RESTORE','fixed_commit':'7f88ffc807925d7c5c82345dffc91bab1b1516e0','source_commit':'0b2962c294aa4c0e4354bdc119f2fecd732d3c03','source_map_sha256':sha(encoded),'aggregate_sha256':m['aggregate_sha256'],'previous_candidate_preedit_report_sha256':sha((R.parent/'preparation/CANDIDATE_PREIMAGE_VERIFIED.json').read_bytes()),'fresh_accepted_mini_tree_restored':False,'current_editing_candidate_read_or_changed':False})
write(R/'CURRENT_INPUTS_VERIFIED.json',{'status':'PASS_FRESH_DEPENDENCIES_METADATA_ONLY_NO_BASE_OR_ACCEPTED_MINI_RESTORE','checked_at_utc':utc(),'fixed_commit':'7f88ffc807925d7c5c82345dffc91bab1b1516e0','source_commit':'0b2962c294aa4c0e4354bdc119f2fecd732d3c03','fresh_download_files':55,'fresh_download_bytes':D['bytes'],'source_map_sha256':sha(encoded),'base_map_sha256':sha(base_bytes),'fresh_base_restored':False,'fresh_accepted_mini_tree_restored':False,'game_started':False,'uploads':0,'old_download_bytes_reused':False,'old_files_preserved':True})
print('PASS_55_FRESH_INPUTS_METADATA_ONLY_NO_RESTORE',D['bytes'],flush=True)
