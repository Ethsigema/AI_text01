from pathlib import Path,PurePosixPath
import hashlib,json,gzip,datetime
ROOT=Path(__file__).resolve().parent.parent
REMOTE_FOLDER='battlegrounds-backup/pending/20261112-mini-native-sale'
BASE_COMMIT='5143e8fb41bc8332ce4ba196144172167a74318c'
PREVIOUS_COMMIT='7f88ffc807925d7c5c82345dffc91bab1b1516e0'
STATUS='UNACCEPTED_MINI_NATIVE_SALE_BEFORE_GAME'
def sha(b):return hashlib.sha256(b).hexdigest()
def dump(o):return (json.dumps(o,indent=2,sort_keys=True)+'\n').encode()
def write(p,o):
 with p.open('xb') as f:f.write(dump(o))
def safe(n):return bool(n) and not PurePosixPath(n).is_absolute() and '..' not in PurePosixPath(n).parts and '\\' not in n
def scan(tree):
 result={};agg=hashlib.sha256()
 paths=list(tree.rglob('*'))
 assert tree.is_dir() and not tree.is_symlink()
 assert all(not p.is_symlink() for p in paths),'Symlinks forbidden'
 for p in sorted((p for p in paths if p.is_file()),key=lambda p:p.relative_to(tree).as_posix()):
  n=p.relative_to(tree).as_posix();assert safe(n)
  b=p.read_bytes();result[n]={'bytes':len(b),'sha256':sha(b)};agg.update(n.encode()+b'\0'+str(len(b)).encode()+b'\0'+b)
 return result,agg.hexdigest()
def verify(tree,expected,aggregate):
 actual,h=scan(tree);assert actual==expected and h==aggregate,'Tree mismatch: '+str(tree)
 return {'files':len(actual),'bytes':sum(v['bytes'] for v in actual.values()),'aggregate_sha256':h,'missing':[],'extra':[],'mismatched':[]}
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
