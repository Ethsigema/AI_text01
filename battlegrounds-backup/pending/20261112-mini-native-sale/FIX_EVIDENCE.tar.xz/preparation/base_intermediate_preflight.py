from pathlib import Path
import json,gzip,hashlib,fcntl,stat,datetime
R=Path.cwd();P=R/'develop_lava_next_20261112/preparation';sha=lambda b:hashlib.sha256(b).hexdigest()
def scan(t,expected,agg):
 result={};h=hashlib.sha256();alloc=0
 for p in sorted(t.rglob('*'),key=lambda x:x.relative_to(t).as_posix()):
  s=p.lstat();assert not stat.S_ISLNK(s.st_mode)
  if stat.S_ISDIR(s.st_mode):continue
  assert stat.S_ISREG(s.st_mode) and s.st_nlink==1
  n=p.relative_to(t).as_posix();b=p.read_bytes();result[n]={'bytes':len(b),'sha256':sha(b)};h.update(n.encode()+b'\0'+str(len(b)).encode()+b'\0'+b);alloc+=s.st_blocks*512
 assert result==expected and h.hexdigest()==agg
 return {'files':len(result),'bytes':sum(x['bytes'] for x in result.values()),'aggregate_sha256':h.hexdigest(),'allocated_file_bytes':alloc,'unique':[],'missing':[],'extra':[],'mismatched':[],'symlinks_special_hardlinks':[]}
t=R/'develop_lava_followup_20261112/fresh_remote/restored_base';other=R/'recover_tier5_after_environment_change_20261112/restored_base';pkg=t.parent/'base_package';raw=gzip.decompress((pkg/'SOURCE_MAP.json.gz').read_bytes());expected=json.loads(raw);assert sha(raw)=='7fec8d69e82de8bfcb7373549951f9456671b5c3980135d6ec6f983a3daf5ed7';agg='5ba04ef124fc78cf20e2a942a60589fb92dc76e6808155648226a534a4599e05'
with (R/'develop_empty_ghost_20261112/.independent_full_game.lock').open('r') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX)
 a=scan(t,expected,agg);b=scan(other,expected,agg);assert a==b
 preserve=[R/'develop_lava_followup_20261112/remote_snapshot_73ef3f4/restored_snapshot',R/'develop_lava_followup_20261112/remote_snapshot_73ef3f4/independent_tests',pkg,t.parent/'original_release.zip',R/'develop_lava_followup_20261112/final_package',R/'develop_lava_followup_20261112/unaccepted_package',other];assert all(x.exists() for x in preserve)
 d={'status':'PASS_READ_ONLY_COMPLETED_BASE_INTERMEDIATE_EQUIVALENT','target':str(t),'classification':'completed_source_recovery_intermediate_base14_tree_not_final_snapshot_or_backup_package','classification_basis':'sale source cumulative restoration completed; tree exactly fixed batch14 with no candidate changes; retained identical base plus original Release/base package reconstruct it','equivalent_retained_base':str(other),'fixed_base_commit':'5143e8fb41bc8332ce4ba196144172167a74318c','source_map_sha256':sha(raw),'target_check':a,'retained_check':b,'preserved_paths':list(map(str,preserve)),'all_unique_bytes_absent':True,'future_old_restore_scripts_may_need_explicit_retained_base_path':True,'deleted':[],'utc':datetime.datetime.now(datetime.timezone.utc).isoformat()};(P/'BASE_INTERMEDIATE_PREFLIGHT.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d,indent=2))
