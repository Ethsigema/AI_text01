from pathlib import Path
import argparse,datetime,fcntl,hashlib,json,shutil
r=Path(__file__).resolve().parents[1];p=r/'candidate';e=r/'evidence'
ap=argparse.ArgumentParser();ap.add_argument('--implementation-freeze',type=Path,required=True);ap.add_argument('--tests-freeze',type=Path,required=True);ap.add_argument('--resume-verified-partial',action='store_true');a=ap.parse_args()
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
with (r.parent/'develop_empty_ghost_20261112/.independent_full_game.lock').open('r') as lock:
    fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    assert (r/'preparation/CANDIDATE_PREIMAGE_VERIFIED.json').exists()
    assert not (e/'APPLIED_FROZEN_MINI_SALE.json').exists()
    e.mkdir(exist_ok=True)
    impl=json.loads(a.implementation_freeze.read_text());tests=json.loads(a.tests_freeze.read_text())
    changes={}
    if a.resume_verified_partial:
        proof=json.loads((e/'APPLY_SETUP_FAILURE_AND_SAFE_RESUME.json').read_text());assert proof['resume_allowed_with_verified_partial'] is True
    for n,old in impl['preimage']['files'].items():
        assert sha(p/n) in ({old,impl['files'][n]} if a.resume_verified_partial else {old}),('preimage drift',n)
    for n,new in impl['files'].items():assert sha(r/'implementation_overlay'/n)==new,('overlay drift',n)
    test_dir='tests/darkcrest_mini_sale_20261112'
    for n,v in tests['files'].items():
        expected=v if isinstance(v,str) else v['sha256']
        src=r/'tests_overlay'/n;dst=p/test_dir/n
        assert sha(src)==expected and not dst.exists(),('test input or target drift',n)
    for n,new in impl['files'].items():
        dst=p/n;changes[n]={'before':impl['preimage']['files'][n],'after_overlay':new};shutil.copyfile(r/'implementation_overlay'/n,dst)
    for n,v in tests['files'].items():
        src=r/'tests_overlay'/n;dst=p/test_dir/n
        dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dst);changes[dst.relative_to(p).as_posix()]={'before':None,'after_overlay':sha(dst)}
    old='darkcrest-mini-native-key-repair-candidate-20261112';new='darkcrest-mini-native-sale-candidate-20261112'
    for n in ['core/darkcrest_sources.gd','data/darkcrest_overlay.json']:
        dst=p/n;s=dst.read_text();assert s.count(old)==1;dst.write_text(s.replace(old,new));changes[n]['after_revision']=sha(dst)
    shutil.copyfile(r/'preparation/CANDIDATE_PREIMAGE_SOURCE_SHA256.json',r/'PREIMAGE_HASHES.json')
    record={'status':'UNACCEPTED_FROZEN_OVERLAYS_APPLIED_NO_GAME','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'implementation_freeze_sha256':sha(a.implementation_freeze),'tests_freeze_sha256':sha(a.tests_freeze),'changes':changes,'previous_source_untouched':True}
    (e/'APPLIED_FROZEN_MINI_SALE.json').write_text(json.dumps(record,indent=2)+'\n')
    print(json.dumps({'files_applied':len(changes),'status':record['status']},indent=2))
