from pathlib import Path
import json,hashlib,tarfile,io,datetime
R=Path.cwd();P=R/'develop_lava_next_20261112/preparation';sha=lambda b:hashlib.sha256(b).hexdigest();enc=lambda o:(json.dumps(o,indent=2,sort_keys=True)+'\n').encode();read=lambda p:json.loads(p.read_text())
# Recheck the already downloaded audit, no new network/tree work.
a=R/'audit_20261112T1500Z';audit=read(a/'PUBLISHED_REMOTE_VERIFIED.json')
for x in audit['records']:
 b=(a/'published_remote_0318'/x['name']).read_bytes();assert len(b)==x['bytes'] and sha(b)==x['sha256']
source=R/'develop_lava_permanent_v2_20261112';failed=R/'develop_lava_permanent_20261112/FAILED_RUN_PUBLICATION_VERIFIED.json';assert read(failed)['outcome']=='failure'
coverage={'status':'SOURCE_AND_GAME_FAILURE_ARCHIVES_ALREADY_REMOTE_VERIFIED_LATE_RECEIPTS_SEPARATE','source_commit':'0b2962c294aa4c0e4354bdc119f2fecd732d3c03','final_commit':'7f88ffc807925d7c5c82345dffc91bab1b1516e0','final_receipt_sha256':sha((source/'FINAL_PUBLICATION_VERIFIED.json').read_bytes()),'final_files':30,'archive_members':391,'failed_predecessor_commit':'9d6ad450f4c5ad287b49612c9c2ba3de399cc67b','failed_predecessor_receipt_sha256':sha(failed.read_bytes()),'audit_commit':audit['commit'],'audit_files_rehashed':len(audit['records']),'late_small_receipts_not_in_previous_archives':read(P/'LOCAL_ONLY_SMALL_EVIDENCE.json')['records'],'cleanup_authorized':False,'cleanup_executed':False}
(P/'BACKUP_COVERAGE.json').write_bytes(enc(coverage))
files={}
def add(p):
 assert p.is_file() and not p.is_symlink();b=p.read_bytes();files[p.relative_to(R).as_posix()]=b
for x in read(P/'LOCAL_ONLY_SMALL_EVIDENCE.json')['records']:
 p=R/x['path'];assert sha(p.read_bytes())==x['sha256'];add(p)
for n in ['cleanup_preflight.py','CLEANUP_PREFLIGHT.json','CLEANUP_PREFLIGHT.log','base_intermediate_preflight.py','BASE_INTERMEDIATE_PREFLIGHT.json','BASE_INTERMEDIATE_PREFLIGHT.log','LOCAL_ONLY_SMALL_EVIDENCE.json','BACKUP_COVERAGE.json','build_late_evidence.py']:add(P/n)
for n in ['verify_final_publication.py','packaging_common.py','run_remote_lava_permanent.py','render_verified_slice.py']:add(source/'preparation'/n)
for p in [failed,a/'PUBLISHED_REMOTE_VERIFIED.json',a/'FINAL_ARCHIVE_MEMBERS_VERIFIED.json']:add(p)
out=P/'pre_cleanup_evidence_package';assert not out.exists();out.mkdir();mem={n:{'bytes':len(b),'sha256':sha(b)} for n,b in files.items()}
with tarfile.open(out/'LATE_EVIDENCE.tar.xz','w:xz') as t:
 for n,b in sorted(files.items()):
  info=tarfile.TarInfo(n);info.size=len(b);info.mode=0o644;info.mtime=0;t.addfile(info,io.BytesIO(b))
seen={}
with tarfile.open(out/'LATE_EVIDENCE.tar.xz') as t:
 for x in t:
  assert x.isfile() and x.name in mem and x.name not in seen;b=t.extractfile(x).read();seen[x.name]={'bytes':len(b),'sha256':sha(b)}
assert seen==mem
(out/'LATE_EVIDENCE_MANIFEST.json').write_bytes(enc({'members':mem,'archive_sha256':sha((out/'LATE_EVIDENCE.tar.xz').read_bytes())}))
(out/'README.md').write_text('''# 清理前迟到证据封存（未执行删除）

本包保留最终7f88新下载实际核验、首次HTTP403中止及4已成功/26串行续传证据、外部验证器diff与依赖，以及下一批只读空间预检。最终30文件/391成员全核通过；不重新跑Game、不复制大树。原source16非SUMS未改，失败前像9d6证据仍保留。

先验证SHA256SUMS.txt，再以LATE_EVIDENCE_MANIFEST.json逐tar regular member核SHA/长度。路径为工作区相对路径，恢复请解到新的空目录，不覆盖现有工程。本包不是完整工程备份：source0b2962c与final7f88目录保留完整累计包和恢复说明，原Release/base14依赖仍须按其说明获取。

预检两候选为已完成非备份开发副本，完整等价immutable源；sale restored_base为完成恢复流程的基线中间树，等价保留Tier5 restored_base，不是最终snapshot/备份包。这里没有删除授权或删除结果。若今后另获许可，仍须执行前重新锁定与完整核验。旧脚本引用sale基线目录的任务须改用保留等价base，不能声称原路径仍存在。

首轮候选预检曾因Tier5历史RECOVERY.md追加而停止；实查仅RECOVERY/SUMS文档差异，delta/map/manifest不变，最终预检已明确记录并全量重核通过。原失败Mini/空位树、所有backup/logs/audit树均不在清理范围。
''')
(out/'SHA256SUMS.txt').write_text(''.join(sha(p.read_bytes())+'  '+p.name+'\n' for p in sorted(out.iterdir()) if p.name!='SHA256SUMS.txt'))
rows=[]
for p in sorted(out.iterdir()):
 b=p.read_bytes();rows.append({'name':p.name,'path':'battlegrounds-backup/audits/20261112T1510Z-pre-next-cleanup/'+p.name,'bytes':len(b),'size':len(b),'sha256':sha(b),'git_sha':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()})
meta={'status':'FROZEN_LOCAL_LATE_EVIDENCE_NOT_UPLOADED','remote_folder':'battlegrounds-backup/audits/20261112T1510Z-pre-next-cleanup','files':len(rows),'bytes':sum(x['bytes'] for x in rows),'members':len(mem),'records':rows,'deleted':[]};(P/'PRE_CLEANUP_UPLOAD_METADATA.json').write_bytes(enc(meta));print(json.dumps(meta,indent=2))
