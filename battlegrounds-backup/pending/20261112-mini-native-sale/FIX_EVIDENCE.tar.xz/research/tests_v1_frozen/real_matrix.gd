extends "res://tests/darkcrest_lava_permanent_20261112/real_matrix.gd"
# One new actual sale/cast cycle, never inherited full initializer.
var mini_sale_effect={}
func observer_snapshot() -> Dictionary:
 var out=super.observer_snapshot()
 out.mini_sale_pending=observed_private_value(game._darkcrest_host._mini.get("_sale"))
 out.native_sale_context=observed_private_value(game._native_sale_operation_context)
 return out
func mini_sale_negatives(mini: Dictionary) -> bool:
 var p=game.state.players[0];var h=game._darkcrest_host;var helper=h._mini;var before=live_snapshot()
 if not must(helper.sale_preflight(h,game,p,mini).is_empty(),"original_mini_sale_preflight"):return false
 if not must(not helper.sale_preflight(h,game,p,mini.duplicate(true)).is_empty(),"copied_mini_sale_rejected"):return false
 if not must(not helper.sale_preflight(h,game,game.state.players[1],mini).is_empty(),"wrong_mini_sale_owner_rejected"):return false
 if not must(not helper.begin_sale(h,game,p,p.board.find(mini),{}).is_empty(),"unbound_mini_sale_context_rejected"):return false
 return must(game.Darkcrest.Sources.same(before,live_snapshot()),"mini_sale_negative_calls_preserve_live_state")
func sell_mini_keep_token(mini: Dictionary,token: Dictionary) -> bool:
 var p=game.state.players[0];var h=game._darkcrest_host;var helper=h._mini
 if not mini_sale_negatives(mini):return false
 var board=p.board.duplicate();var values=p.board.duplicate(true);var hand=p.hand.duplicate();var hand_values=p.hand.duplicate(true)
 var gold=p.gold;var sold=p.stats.sold;var pool=game.pool.duplicate(true);var spell_pool=game.spell_pool.duplicate(true);var uid=game.next_uid;var rng=game.rng.state;var seed=game.rng.seed
 var record=helper._board;var token_record=helper._tokens[token.uid];var token_record_values=h.Mini.token_facts(token_record);var token_keys=helper._tokens.keys()
 var index=p.board.find(mini);var round_before=game.state.round;var sequence_before=game.state.command_sequence
 if not must(command(0,{"type":"sell","index":index}).get("ok",false),"public_original_mini_sell"):return false
 board.remove_at(index);values.remove_at(index);pool[MINI]+=1
 if not must(h.Generation._same_objects(board,p.board) and h.purchase_value_same(values,p.board),"mini_sale_exact_board_removal"):return false
 if not must(h.Generation._same_objects(hand,p.hand) and h.purchase_value_same(hand_values,p.hand),"mini_sale_original_token_hand_unchanged"):return false
 if not must(p.gold==gold+1 and p.stats.sold==sold+1 and h.LavaPlay._sale_inventory_matches(game.pool,pool),"mini_sale_native_gold_stock_sold_deltas"):return false
 if not must(game.next_uid==uid and game.rng.state==rng and game.rng.seed==seed and h.LavaPlay._sale_inventory_matches(game.spell_pool,spell_pool) and absent_from_all_zones(mini),"mini_sale_no_uid_rng_spellpool_change"):return false
 if not must(is_same(helper._board,record) and helper._board.get("retired")==true and helper._board.get("retired_complete")==true and helper._board.get("retired_uid")==mini.uid and helper._board.get("retired_round")==round_before and helper._board.get("retired_sequence")==sequence_before and helper._sale.is_empty(),"mini_original_record_retired_once"):return false
 if not must(is_same(helper._tokens[token.uid],token_record) and is_same(token_record.get("owner"),p) and is_same(token_record.get("unit"),token) and h.purchase_value_same(token_record_values,h.Mini.token_facts(token_record)) and helper._tokens.keys()==token_keys and helper.token_error(h,game,p,token).is_empty(),"issued_token_authority_preserved_across_sale"):return false
 var after=live_snapshot()
 if not must(not helper.board_error(h,game,p,mini).is_empty() and not helper.sale_preflight(h,game,p,mini).is_empty(),"retired_original_mini_cannot_sell_again"):return false
 if not must(not helper.finish_sale(h,game,p,{}, {"ok":true}).is_empty(),"mini_sale_completion_replay_rejected"):return false
 if not must(h.Sources.same(after,live_snapshot()),"retired_mini_refusals_do_not_mutate"):return false
 mini_sale_effect={"mini_uid":mini.uid,"token_uid":token.uid,"index":index,"round":round_before,"gold_before":gold,"gold_after":p.gold,"stock_before":pool[MINI]-1,"stock_after":game.pool[MINI],"sold_before":sold,"sold_after":p.stats.sold,"uid_before":uid,"uid_after":game.next_uid,"rng_before":rng,"rng_after":game.rng.state,"retired":true,"retired_sequence":sequence_before,"token_same_reference":true,"token_record_same_reference":true}
 return true
func mini_sale_case() -> bool:
 var setup=prepare_room()
 if setup.is_empty():return false
 var mini=setup.mini;var lava=setup.lava;var parent=setup.parent;var p=game.state.players[0]
 if not public_lava_play(lava,0):return false
 if not must(command(0,{"type":"play","index":p.hand.find(mini),"target":-1,"position":1}).get("ok",false),"original_mini_publicplay_real_waiting_grant"):return false
 var token=trident()
 if token.is_empty() or not original_mini_token(token,mini):return false
 if not sell_mini_keep_token(mini,token):return false
 if not cast_first(mini,lava,parent,4) or not prepare_real_opponents():return false
 if not next_round(parent,2) or not inspect_permanent_combat(lava,4,1):return false
 var helper=game._darkcrest_host._mini
 if not must(absent_from_all_zones(mini) and not p.hand.any(func(u):return u.card_id==TRIDENT) and not p.board.any(func(u):return u.card_id==MINI) and not p.get("spellcraft_waiting",[]).any(func(ticket):return ticket.get("source_uid")==mini.uid or ticket.get("spell_card_id")==TRIDENT),"departed_mini_no_next_round_token"):return false
 if not must(helper._tokens.size()==1 and helper._tokens.has(token.uid) and helper._tokens[token.uid].used==true and helper._delivery.is_empty() and helper._flush_tokens.is_empty(),"no_mini_regrant_only_original_used_history"):return false
 var result={"scope":"single ordinary Mini sale retains previously issued original token for same-turn first Lava cast","seed":20261120,"checks":checks,"acquisitions":acquisition,"native_preview_diagnostic":native_preview_diagnostic,"sale":mini_sale_effect,"casts":mini_casts,"combats":buff_combats,"darkcrest_uid":parent.uid,"darkcrest_final_tier":2,"lava_uid":lava.uid,"mini_uid":mini.uid,"no_next_round_mini_token":true,"coin_pre_source_fixture":true,"entirely_natural_game":false,"sold_source_unused_expiry_tested":false,"old_full_matrix_repeated":false}
 var file=FileAccess.open(get_script().resource_path.get_base_dir()+"/DARKCREST_MINI_SALE_MATRIX_RESULT.json",FileAccess.WRITE)
 if not must(file!=null,"matrix_result_file"):return false
 file.store_string(JSON.stringify(result,"  ")+"\n");file.close();return true
func _initialize():
 print("DARKCREST_MINI_SALE_MATRIX_LOAD_BEGIN")
 var Game=load("res://core/game.gd")
 if not must(Game!=null and Game.can_instantiate(),"complete_game_script"):return
 cat=load("res://core/catalog.gd").new();cat.load_catalog()
 if not must(cat.load_errors.is_empty(),"complete_catalog"):return
 if not mini_sale_case():return
 print("DARKCREST_MINI_SALE_REAL_MATRIX_PASS cases=1 casts=1 combats=1 checks=",checks)
 quit(0)
