# One ordinary Mini departure, original child retained

Draft only until producer API freeze and source proof/parse verification. Canonical new paths: tests/darkcrest_mini_sale_20261112/{content_contract.gd,real_matrix.gd}. Existing corrected permanent344 and older eight pure2717 stay unchanged. Never repeat inherited full initializer or claim old131 full Game reran.

One sameGame/sameCatalog public route uses verified initial seed20261120 and unmodified23-card room. Mini and Lava bought before Darkcrest; original factory/add_hand/public Coin funding is explicitly a pre-source fixture. Native original Mini play/Waiting issues Trident. Public sell Mini: native gold/pool/sold +1, other board/hand/UID/RNG/spellpool unchanged, original source authority retired while original token ref/ready/source_uid/history remain unchanged. That same token is publicly cast on original Lava, producing4/5 kept1; one nonempty actual combat and next recruit preserve4/5 and reset kept0, Darkcrest grows1→2, no Mini child regrant.

Read-only copy/wrongowner/fabricated-context/retired-source preflights must leave full snapshots and private state unchanged. Do not invoke poisoning finish on a live unbound transaction merely to test rejection. Detached pure contexts can test shape and refusal, never successful provenance. No token copy inserted, source reentry, new second Mini, rebuy, golden, foreign target, same-turn second cast, buffed Lava sale or whole-game/default-pool acceptance.

The used original token cannot also test unused expiry. Sold-source UNUSED expiry is explicitly not live-tested, even though source-present unused expiry was historically verified. Native partial-sale-failure injection and capacity/lifetime stress are not performed. Existing native Lava permanence is not a newly added algorithm.

New JSON DARKCREST_MINI_SALE_MATRIX_RESULT.json is a single object, not cases array; final marker DARKCREST_MINI_SALE_REAL_MATRIX_PASS cases=1 casts=1 combats=1 checks=N. JSON checks is N-1 because the output-file check follows result construction. New pure marker/count will freeze with final production predicate APIs. Full receipt records source/factory preview as diagnostic, never token provenance.

## API-aligned draft

Mini pending field is _sale. Production completion preserves the original _board object and records retired/retired_complete plus exact UID/round/sequence. Tests observe this and retain original token registry references/facts. Pure static expected60 checks, not an observed run count: exact8-field sale context (including original plan ref/deep values), missing/extra/copied references/strict types, token_facts deep-copy boundary, fake-actual/unbound refusals, and isolated retired-looking fixture refusal. Detached retired fixture is explicitly not genuine retirement proof. Actual successful native departure and retired admission refusal are covered only by the real case.
