# Mini sale overlay v1

Exact source0b2962c preimage checked for all5 files. Only overlay changed. No fulltree copy, Game or repin.

API: Mini.sale_preflight(host,game,owner,unit), begin_sale(host,game,owner,index,original_operation), finish_sale(host,game,owner,original_operation,original_result). Pure sale_context_matches(host,c,p,u,uid,index,sold,round,sequence,plan,values) checks8fields/refs/strict values only, not authorization. token_facts excludes owner/unit references and compares remaining historical data. Private active observation is _sale.

Preflight checks full finite owner, original untouched Mini custody, no pending windows/tickets, exactly one current ready original child from this Mini, strict pool/gold/sold/UID types. Game invokes begin after original native operation begins, native sale body unmodified, finish unconditionally before operation end. Original sale hosts/pay/return/hand operations remain native.

Actual original departure revokes source board permission by retaining the same _board record with retired=true and retired_complete=false plus original retired_uid/round/sequence. Invalid caller cannot revoke another owner. Complete original context, departed unit original value, board-minus-source, hand unchanged, whole issued token refs/facts unchanged, gold+1/Mini pool+1/sold+1/no RNG/UID/spellpool change are required before retired_complete=true. _tokens are never cleared/reissued. Original failure preserved; partial departure poisons the combination and does not pretend rollback or successful usability of old token.

board_error rejects retired even if sameunit/UID is reinserted. Nonempty historical _board keeps secondMini play held. New Waiting still needs live source; issued child token_error/cast do not require its source on board. Existing native cast/reset/expiry semantics unchanged.

Selected formal test is oneGame: sell originalMini after original token received, cast that same child on originalLava, realcombat/nextrecruit verifies4/5 kept0 and no newMini child with Darkcrest level2. No claim for unused-child-after-sale expiry, Mini rebuy, secondMini or golden.

Helper standalone syntax passed. Full integrated parse, review, pure/native test and remote backup remain parent work; this source is not yet accepted.

## v2 source custody at cast
Only cast_preflight gains a source custody gate; token_error is unchanged so native mid-sale owner scans are not blocked. Actual helper/engine, original token ref/owner, source UID/original registry unit and engine WeakRef are checked first. A live source must pass original board_error. Retired source must have completed successful sale, exact owner/UID/snapshot, same round/prior command sequence, and be absent from every live player/ghost zone. Partial retirement or unobserved removal is held. Pure source_presence_error(host,record,p,source_uid,round,sequence,zones) tests content/presence only; callers cannot use its success as actual authority. V1 tar/SHA/diff preserved. Helper standalone syntax exit0; no Game.
