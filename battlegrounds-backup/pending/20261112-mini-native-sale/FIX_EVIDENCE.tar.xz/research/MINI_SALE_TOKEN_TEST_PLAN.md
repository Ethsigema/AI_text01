# Mini sale with previously issued token: read-only test design

Status: design only, no new implementation or tests written, no Game executed. Baseline is the actually verified 0b2962c restored source, not failed517a547. Previous full scenario131 and pure3061 passed according to parent; this plan does not claim any new pass.

## Reachable one-Game route

Reuse the exact verified initial seed20261120 / four Edwin / unchanged23-card room and original pre-source acquisition helpers. Actual previous scenario JSON records Mini u4 at0roll, Lava u28 at1roll, Darkcrest u118 and first native trident u123. These are evidence for likely low-cost reachability, not instructions to allocate or force those UIDs. New execution must record actual identities.

1. Same Game/Catalog start and unchanged preview-only factory shape check, if retained. Preview is not token provenance.
2. Public native buy Mini/Lava before Darkcrest, disclose native factory/add_hand/public Coin fixture only before source ownership. Public tavern upgrades and Darkcrest buy/play as before. Do not mutate RNG/pools/gold/UID/record or filter random domains.
3. Original Lava play, original Mini play: actual Waiting/factory grants exact original token, ready receipt bound to Mini source UID, owner, round. Snapshot this original token and record before sale.
4. Public sell original Mini, using actual current board index. Require native result ok, recruit phase unchanged, exact board removal only, hand token unchanged by identity and deep content, gold+1, sold+1, Mini pool+1 only, spellpool unchanged, UID/RNG unchanged. No native Waiting regrant or extra token. Across all player/ghost zones old Mini object/UID absent. Authoritative Mini play receipt retired exactly once, pending sale/context cleared; token receipt remains original, usable and same source UID, not reissued or rebound to fake source.
5. Public cast that original pre-sale token on the same original Lava, round unchanged: original token consumed, spells+1, attack2→4 health/max5 kept0→1, no temporary layer, native Lava receipt updated; no new UID/RNG/stock change. Darkcrest unchanged during sale/cast.
6. Prepare actual nonempty opponent boards by the already validated public buy/play helpers. Public ready/end all4, real combat and next recruit. Actual combat copy contains original Lava UID4/5; recruit original Lava4/5 kept0. Darkcrest1→2 and real source token/grant correct. No Mini board/hand, no BG23_000t in hand or waiting; Mini token registry has only original consumed receipt, no new issuance. Do not confuse new Darkcrest token with Mini regrant.

This is one new Game, one first-of-turn Mini cast after sale, one nonempty combat/recruit cycle. No need for a second Game or to repeat the previous two-cast/three-combat scenario.

## Negative checks without manufacturing authority

Before sale: copied Mini, wrong owner, unbound/fake sale context, copied legitimate-looking context/receipt and projection-tainted host must reject. Only invoke read-only preflight/validation APIs on live Game; completion methods may poison state and must not be called live without a real transaction. Pure fake-context tests can inspect isolated helper rejection but cannot claim successful source authentication.

After sale: old Mini cannot authorize another sale or board_error, cannot be reinserted; original token remains valid but its copy, wrong owner, copied Lava target and fake cast context must reject. Full snapshots include actual source state/players/zones, pool/spellpool, RNG/nextUID, all existing Mini fields, new pending sale/retired receipts, Lava play/sale/retired records, Darkcrest records/history, original record object identities. Successful cast then used-token replay preflight must reject without mutation. Do not actually issue a second public sell with now-shifted board index (would sell a different unit).

Production exact APIs remain pending. Detached pure contract should cover strict8-field native-sale context/plan identity and deep values if reused, strict int inventory/accounting vs float/bool/missing/extra keys, token/source retirement linkage, copied/fake owner/context/plan/refusal, replay/failed-init boundaries. Do not invent a success receipt in tests. Failure-after-native-removal/capacity saturation need isolated/static coverage or explicit not-tested status, not live state injection.

## Old regression policy and limits

Reuse existing helpers and immutable corrected344 pure plus eight older pure2717 if production pins permit. Do not run obsolete erroneous340 fixture or claim the old131 full scenario reran. The new Game covers authentic issuing and original permanent-cast/reset while changing only sale chronology. Previous two-turn accumulation and unused expiry remain historical verified results, not fresh coverage. Existing native permanence is not a new algorithm.

No Mini rebuy/replay source, second Mini, same-turn second spell, golden/multi-Lava, buffed Lava sale/rebuy or general token-generators. No UI/save/default-pool/full-game acceptance. Funding is an explicit fixture, not entirely natural match.

## Producer coordination

Producer proposes sale_preflight/begin_sale/finish_sale around original native-sale window, keeping the unique _board original receipt with retired=true rather than deleting _tokens. board_error rejects retired, nonempty _board still blocks another Mini; existing token references/source_uid/ready/used/history stay untouched. This is a proposed interface, not implemented approval. Tests should assert same original board record identity plus exact retired transition, not assume _board becomes empty. Single case consumes the sold-source token, so post-sale UNUSED expiry is not live-covered; it remains static/pure unless a later separately authorized scenario tests it. Existing before-sale-source unused expiry historical coverage cannot be presented as sold-source expiry coverage.
