# Next finite slice: sell Mini, retain its already-delivered Trident

2026-11-12. Read-only verified source: develop_lava_permanent_v2_20261112/remote_snapshot_0b2962c/single_tree_restore/restored_snapshot. Parent reports Game131/pure3061 accepted; not rerun here. No source edits, Game or tree copy.

## Recommendation

Yes: this is a small, useful next slice, substantially narrower than new Spellcraft sources or second-Mini/second-cast handling. Native Mini sale, old token ownership and native first permanent effect already exist separately. New work is a correct Mini source-departure receipt, not a new sale payout or new permanent effect.

Scope: one untouched ordinary Mini1/4, certified normal Lava, ordinary Darkcrest. The one current-round Trident has completed its original Waiting flush and is ready in hand. Sell Mini through native public command; old child remains usable on original Lava for this round's first cast. After native combat/recruit Mini does not generate another child. No Mini rebuy/reentry/secondMini/golden/buffs, foreign target, same-turn second cast, odd-room fixes or after-Tier6 EOT.

## Exact existing gates and source semantics

- darkcrest_host.gd:200 explicitly returns darkcrest_mini_sale_held. This is the immediate public refusal.
- darkcrest_mini.gd:74-81 board_error authenticates current source object, board presence, immutable body and original registry. preflight:31-40 already blocks any second play while _board is nonempty.
- token_error:82-87 validates actual helper, original child ref/owner/current round/unused/exact snapshot. It does NOT require the parent still on board. cast_preflight:156-169 validates ready token, idle windows, finite owner and original Lava; it does NOT query source board_error. Existing child authority is already source-origin rather than live-source tied.
- delivery_begin:90-104 correctly DOES require live source board_error and exact source ticket. This must remain true after sale: no live source means no new grant/delivery, not a reason to invalidate an already-delivered child.
- spellcraft_waiting.gd:188-201 explicitly cancels pending tickets only, comment 'Hand untouched'. game.gd:7070 calls cancel_source before board.remove_at; native sale does not erase issued hand child.
- game.gd:6919 original operation begins with exact8 fields; :6940 wrapper owns full native body. Existing Lava observer demonstrates begin/body/unconditional-finish/end ordering. :7072 removes original source before payout; later original gold/return/sold and many observers may fail after partial effects.
- game.gd:11072 original hand expiry; existing Mini expiry observer must remain in force for unspent child after source departure. Next recruit:12209 builds source list from current p.board, so absent Mini cannot regenerate. Existing Lava native-reset observer and Darkcrest growth should continue unchanged.

## Smallest safe implementation

1. Replace only public Mini sale-held with dedicated Mini sale_preflight. Require actual Game/owned Mini helper, no projection taint, finite owner validation, original unique untouched Mini and active ready board receipt; no play/cast/delivery/flush/reset/expiry/sale pending; no queued Mini ticket. For this slice require exactly one current-round ready unused original child in hand whose source_uid matches this source. This intentionally does not promise sale of Mini in arbitrary timing states.
2. Reuse original Game native sale operation8fields, not a new native sale executor. Bind exact operation reference and all fields, including generated_tier7_plan reference+deep value, original source record/ref/UID/owner, clock, board/hand snapshots and strict accounting. Original quote/payment/sale listeners/pool return stay untouched.
3. Finish unconditionally after original body before operation_end. On actual original departure retire ONLY source board authority, preserving _tokens and their original refs/snapshots/ready/used/expired history. Do not mark the ready child used/expired or issue a new one. Body failure after removal must still revoke source admission, retain actual partial state, and report original error; before-removal failure may retain unchanged source custody. No refunds, reruns or success-forging.
4. Prefer a retained one-source record explicitly marked retired, with board_error rejecting retired even if old object/UID is reinserted. Keeping this nonempty record also preserves existing second-play hold without a general reusable UID cache. If clearing _board instead, add an explicit permanent-for-this-finite-helper retired-source record checked by preflight; otherwise newMini would silently reopen. Retired source metadata is historical origin, never live grant capability. No additional arbitrary count cap is necessary for the single-sale scope.
5. Successful receipt: exact board-minus-source (all other refs/values), unchanged hand and original issued token records, gold+1, only Mini pool+1, sold+1, unchanged RNG/UID/spell_pool, original ticket cancellation semantics. Bound values/types strictly, reusing pure sale inventory/context checking where useful without sharing another helper's live authority. A local body receipt does not imply outer command-tail success.
6. Token validation can retain current semantics; optionally strengthen source_uid linkage to the original active-or-retired source record as history. Never require source live to cast/expire, and never replace original token provenance with 'source UID is known'. New deliveries still require source live and unretired. Retired source reinsertions, fake ticket and old context replay must reject.

Likely files: Mini helper, Host command gate, Game observer dispatch, Sources/revision metadata. No new Waiting behavior, Combat mechanics or permanent arithmetic should be necessary. Existing immutable Lava reset path and Mini expiry path do not consult live Mini board, so should continue after sale. This is static analysis, not yet real-game proof.

## Minimal real test and honest coverage

Primary one-room case: natural Mini/Lava-before-source acquisition, original source play/Lava play/Mini play and original child receipt; public sell Mini while child remains in hand; assert exact original sale accounting/hand preservation/source retired; cast same child on original Lava -> native4/5 kept1; EOT/nonempty combat/next recruit ->4/5 kept0, Darkcrest grows once, Mini absent, no new Mini ticket/child and no extra Mini factory UID. No direct pool/UID/RNG/ticket edits.

An important test distinction: ONE single Mini child cannot both be consumed after sale AND expire unused. To claim unused-token-after-sale expiry, add a second independent public-flow case with the same initial route but skip cast after sale, EOT and assert exact original child expired and no replacement. It is not valid to copy/fork live state, create a second token or call reset manually to pretend both branches were tested. If restricted to one case, choose sell-then-cast and label unused-after-sale expiry static-only despite prior source-present expiry acceptance.

Pure negatives: fake/wrongowner/duplicate UID/source shape, current token missing/wrongsource/copied/expired/not-ready, queued or in-flight window, copied/mutated/native-old sale operation, noninteger accounting, retired source reinsertions and repeat sale. Partial failure coverage must distinguish pure observation fixtures from actual native failure injection; do not claim all native sale observer failures exercised.

## Complexity and value

Low-to-medium compared with the prior Mini issuance/permanent lifecycle: the token authority already outlives parent presence conceptually, and sale operation is established. Primary risk is source retirement without accidentally clearing child authority or enabling source reentry; secondary risk is post-removal native failure before final accounting. No smaller alternative provides a comparable new interaction: merely permitting Mini move is largely already generic/native and would not prove this missing source/child split. Recommend this source-sale slice, with one primary real case and optional second expiry branch rather than broadening rebuy or repeat mechanics.
