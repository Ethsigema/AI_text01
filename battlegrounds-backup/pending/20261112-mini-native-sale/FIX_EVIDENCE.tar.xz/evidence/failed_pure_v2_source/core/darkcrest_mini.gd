extends RefCounted
# Observes original native operations. Never writes combat stats, counters or hand contents.
const ID="BG23_000"
const SPELL="BG23_000t"
const CHILD_SOURCE={"id":"BG23_000t","card_code":"BG23_000t","dbf_id":"83914","name":"迷你三叉戟","text":"直到下个回合，使一个随从获得+2攻击力。","kind":"spell","category":"塑造法术","tier":null,"attack":null,"health":null,"cost":0,"tribes":[],"normal_id":null,"golden_id":null,"is_golden":false,"solo_eligible":true,"duos_exclusive":false,"requires_teammate_effect":false,"keywords":[],"temporary":true,"effects":[{"type":"spell_buff","scope":"target","attack":2,"health":0,"allow_shop":true,"temporary":true}],"supported":true,"default_pool":false,"pool_supported":false,"image":"res://assets/cards/BG23_000t.jpg"}
const EFFECT=[{"type":"spell_buff","scope":"target","attack":2,"health":0,"allow_shop":true,"temporary":true}]
var _play: Dictionary={}
var _board: Dictionary={}
var _delivery: Dictionary={}
var _tokens: Dictionary={}
var _flush_tokens: Array=[]
var _flush_owner: Dictionary={}
var _flush_window: RefCounted=null
var _cast: Dictionary={}
var _reset: Dictionary={}
var _expiry: Dictionary={}
var _poison: String=""
var _sale: Dictionary={}
func actual(host,game,p: Dictionary) -> bool:
	if not host is RefCounted or not game is RefCounted: return false
	if not host.get_script() is Script or host.get_script().resource_path!="res://core/darkcrest_host.gd" or not game.get_script() is Script or game.get_script().resource_path!="res://core/game.gd": return false
	return not host._projection_only and is_same(game._darkcrest_host,host) and is_same(host._mini,self) and game.state.get("players") is Array and p.get("id") is int and p.id>=0 and p.id<game.state.players.size() and is_same(game.state.players[p.id],p)
func fail(issue: String) -> String:
	_poison=issue
	return issue
func shape_error(host,game,u: Dictionary) -> String:
	if u.get("card_id")!=ID: return "darkcrest_mini_identity"
	var issue: String=host.hand_state_error(u,game.catalog.get_card(ID),game.Rider.UNIT_FIELDS)
	if not issue.is_empty(): return issue
	if not u.get("attack") is int or not u.get("health") is int or not u.get("max_health") is int or not u.get("spellcraft_kept") is int or not u.get("pool_count") is int or u.pool_count!=1 or u.attack!=1 or u.health!=4 or u.get("max_health")!=4 or u.get("spellcraft_kept")!=0: return "darkcrest_mini_untouched_body_required"
	return ""
func preflight(host,game,p: Dictionary,u: Dictionary) -> String:
	if not actual(host,game,p) or game.state.phase!="recruit" or not _poison.is_empty(): return "darkcrest_mini_actual_healthy_host_required"
	if not _sale.is_empty() or not host._cast.is_empty() or not host._delivery.is_empty() or not host._eot.is_empty() or not host._generation._active.is_empty() or not _expiry.is_empty() or not _play.is_empty() or not _cast.is_empty() or not _delivery.is_empty() or not _reset.is_empty() or not _board.is_empty(): return "darkcrest_mini_single_source_window_held"
	if not p.hand.any(func(item):return is_same(item,u)) or not host.LavaPlay._unique(game,u) or host.count(p,ID)!=1 or p.board.size()>=7: return "darkcrest_mini_original_single_hand_required"
	if p.board.filter(func(item):return item.get("card_id")==host.LavaPlay.ID).size()!=1: return "darkcrest_mini_lava_first_required"
	if p.hand.size()>=10 or not p.get("spellcraft_waiting",[]).is_empty(): return "darkcrest_mini_capacity_waiting_held"
	var issue: String=host.owner_error(game,p)
	return shape_error(host,game,u) if issue.is_empty() else issue
static func context_matches(c: Dictionary,r: Dictionary) -> bool:
	if c.size()!=9: return false
	for key in ["owner","unit","target","nonce"]:
		if not is_same(c.get(key),r.get(key)): return false
	for key in ["index","position","round","sequence"]:
		if not c.get(key) is int or c[key]!=r.get(key): return false
	return c.get("kind") is String and c.kind==r.get("kind")
func window(host,game,p: Dictionary,r: Dictionary) -> bool:
	return actual(host,game,p) and r.get("engine") is WeakRef and is_same(r.engine.get_ref(),game) and is_same(r.get("context"),game._darkcrest_mini_context) and is_same(r.get("nonce"),game._darkcrest_mini_nonce) and context_matches(game._darkcrest_mini_context,r) and game.state.round==r.round and game.state.command_sequence==r.sequence
func begin(host,game,p: Dictionary,index: int,context: Dictionary) -> String:
	if not actual(host,game,p) or index<0 or index>=p.hand.size() or not is_same(context,game._darkcrest_mini_context) or not context.get("nonce") is RefCounted or not is_same(context.nonce,game._darkcrest_mini_nonce): return "darkcrest_mini_native_context_required"
	var u: Dictionary=p.hand[index]
	if context.size()!=9 or not context.get("index") is int or context.index!=index or not context.get("position") is int or not context.get("round") is int or context.round!=game.state.round or not context.get("sequence") is int or context.sequence!=game.state.command_sequence or not is_same(context.get("owner"),p) or not is_same(context.get("unit"),u): return "darkcrest_mini_context_fields_changed"
	if u.get("card_id")==ID:
		if context.get("kind")!="play" or context.get("target")!=null: return "darkcrest_mini_play_context_kind"
	elif u.get("card_id")==SPELL:
		if context.get("kind")!="cast" or not context.get("target") is Dictionary: return "darkcrest_mini_cast_context_kind"
	else: return "darkcrest_mini_context_identity"
	var issue: String=preflight(host,game,p,u) if u.get("card_id")==ID else cast_preflight(host,game,p,u,context.target)
	if not issue.is_empty(): return issue
	var r: Dictionary={"engine":weakref(game),"context":context,"owner":p,"unit":u,"target":context.get("target"),"nonce":context.nonce,"kind":"play" if u.card_id==ID else "cast","index":index,"position":context.get("position"),"round":game.state.round,"sequence":game.state.command_sequence,"hand":p.hand.duplicate(),"hand_values":p.hand.duplicate(true),"board":p.board.duplicate(),"board_values":p.board.duplicate(true),"snapshot":u.duplicate(true),"played":p.stats.played,"spells":p.stats.spells}
	if not context_matches(context,r): return "darkcrest_mini_context_fields_changed"
	if u.card_id==ID: _play=r
	else:
		r.expected=r.target.duplicate(true);r.expected.attack+=2;r.expected.spellcraft_kept=1
		r.before=r.target.duplicate(true);r.lava_record=host._lava_play._board[r.target.uid]
		_cast=r
	return ""
func inserted(host,game,p: Dictionary,u: Dictionary) -> String:
	if _play.is_empty() or not window(host,game,p,_play) or not is_same(_play.unit,u): return "darkcrest_mini_original_insert_window_required"
	var h: Array=_play.hand.duplicate();h.remove_at(_play.index)
	var b: Array=_play.board.duplicate();var position: int=_play.position if _play.position>=0 and _play.position<=b.size() else b.size();b.insert(position,u)
	if not host.Generation._same_objects(p.hand,h) or not host.Generation._same_objects(p.board,b) or not host.purchase_value_same(u,_play.snapshot): return fail("darkcrest_mini_insert_changed")
	_play.inserted=true
	return ""
func board_error(host,game,p: Dictionary,u: Dictionary) -> String:
	if not actual(host,game,p) or not _poison.is_empty() or _board.get("retired",false) or not host.LavaPlay._unique(game,u): return "darkcrest_mini_unissued_board"
	var r: Dictionary=_board
	if r.is_empty():
		if _play.is_empty() or not _play.get("inserted",false) or not window(host,game,p,_play): return "darkcrest_mini_unfinished_board"
		r=_play
	if not is_same(r.get("owner"),p) or not is_same(r.get("unit"),u) or not p.board.any(func(item):return is_same(item,u)) or not host.purchase_value_same(u,r.snapshot): return "darkcrest_mini_changed_board"
	return shape_error(host,game,u)
func token_error(host,game,p: Dictionary,u: Dictionary) -> String:
	if not actual(host,game,p) or not _poison.is_empty(): return "darkcrest_mini_unissued_token"
	var r: Dictionary=_tokens.get(u.get("uid"),{})
	if r.is_empty() and not _delivery.is_empty() and is_same(_delivery.get("unit"),u): r=_delivery
	if r.is_empty() or not is_same(r.get("unit"),u) or not is_same(r.get("owner"),p) or r.get("round")!=game.state.round or r.get("used",false) or not host.purchase_value_same(u,r.get("snapshot",{})): return "darkcrest_mini_copied_expired_or_used_token"
	return ""
static func flush_matches(active: Dictionary,guard: String,flush: Variant) -> bool:
	return flush is RefCounted and active.has(guard) and active.get(guard) is RefCounted and is_same(active.get(guard),flush)
func delivery_begin(host,game,p: Dictionary,ticket: Dictionary,flush: RefCounted) -> String:
	if not actual(host,game,p) or not _sale.is_empty() or not _delivery.is_empty() or not _poison.is_empty(): return "darkcrest_mini_delivery_host_required"
	var guard: String=str(game.get_instance_id())+":"+str(p.id)
	if not flush_matches(game.SpellcraftWaiting._active_flushes,guard,flush): return "darkcrest_mini_original_flush_required"
	var source: Dictionary={}
	for u in p.board:
		if u.get("uid")==ticket.get("source_uid"): source=u
	var issue: String=board_error(host,game,p,source)
	if not issue.is_empty(): return issue
	var expected: Dictionary={"source_uid":source.uid,"source_card_id":ID,"spell_card_id":SPELL,"effect_index":0,"round":game.state.round,"count":1}
	if not host.purchase_value_same(ticket,expected) or not p.get(game.SpellcraftWaiting.KEY,[]).any(func(t):return is_same(t,ticket)): return "darkcrest_mini_exact_ticket_required"
	for r in _tokens.values():
		if r.round<game.state.round and not r.get("used",false) and not r.get("expired",false): return "darkcrest_mini_unobserved_old_token_departure"
		if r.round==game.state.round: return "darkcrest_mini_duplicate_round_token"
	_flush_owner=p;_flush_window=flush
	_delivery={"owner":p,"source":source,"ticket":ticket,"ticket_values":expected,"window":flush,"round":game.state.round,"uid":game.next_uid,"hand":p.hand.duplicate(),"hand_values":p.hand.duplicate(true),"used":false}
	return ""
static func token_shape_error(host,game,u: Dictionary) -> String:
	var card: Dictionary=game.catalog.get_card(SPELL)
	for key in CHILD_SOURCE:
		if not card.has(key) or not host.purchase_value_same(card.get(key),CHILD_SOURCE[key]): return "darkcrest_mini_child_source_changed:"+str(key)
	if not u.get("uid") is String or u.uid.is_empty(): return "darkcrest_mini_child_uid_required"
	var expected: Dictionary={"uid":u.uid,"card_id":SPELL,"name":CHILD_SOURCE.name,"kind":"spell","tier":1,"attack":0,"health":1,"keywords":[],"tribes":[],"effects":EFFECT,"golden":false,"cost":0,"temporary":true,"is_spellcraft":true,"temporary_buffs":[],"permanent_keywords":[],"text":CHILD_SOURCE.text,"image":CHILD_SOURCE.image,"pool_count":0,"spellcraft_kept":0,"spell_triggers":0,"attachments":[],"pool_components":[],"magnetic_tribes":[],"individually_frozen":false,"blood_gems_received_turn":0,"recruit_shop_bonus_applied":{},"recruit_shop_aura_attack":0,"recruit_shop_aura_health":0}
	expected.max_health=expected.health
	expected.expires_at_end_turn=true
	expected.base_unit={"card_id":SPELL,"name":CHILD_SOURCE.name,"tier":1,"attack":0,"health":1,"max_health":1,"keywords":[],"tribes":[],"effects":EFFECT,"golden":false}
	return "" if host.purchase_value_same(u,expected) else "darkcrest_mini_full_native_child_shape_required"
func delivery_factory(host,game,p: Dictionary,u: Dictionary) -> String:
	if not actual(host,game,p) or _delivery.is_empty(): return "darkcrest_mini_missing_delivery"
	var r: Dictionary=_delivery
	var guard: String=str(game.get_instance_id())+":"+str(p.id)
	if not is_same(r.owner,p) or not flush_matches(game.SpellcraftWaiting._active_flushes,guard,r.get("window")) or not host.purchase_value_same(r.ticket,r.ticket_values): return fail("darkcrest_mini_changed_delivery_window")
	if u.get("card_id")!=SPELL or u.get("uid")!="u"+str(r.uid) or game.next_uid!=r.uid+1 or u.get("is_spellcraft")!=true or u.get("expires_at_end_turn")!=true or u.get("temporary")!=true or not host.purchase_value_same(u.get("effects"),EFFECT): return fail("darkcrest_mini_native_child_factory_required")
	var issue: String=token_shape_error(host,game,u)
	if not issue.is_empty(): return fail(issue)
	r.unit=u;r.snapshot=u.duplicate(true)
	return ""
func delivery_complete(host,game,p: Dictionary,u: Dictionary) -> String:
	if not actual(host,game,p) or _delivery.is_empty() or not is_same(_delivery.get("unit"),u): return "darkcrest_mini_unbound_delivery_complete"
	var r: Dictionary=_delivery
	var guard: String=str(game.get_instance_id())+":"+str(p.id)
	var spent_ticket: Dictionary=r.ticket_values.duplicate(true);spent_ticket.count=0
	if not is_same(r.owner,p) or not flush_matches(game.SpellcraftWaiting._active_flushes,guard,r.get("window")) or r.round!=game.state.round or game.next_uid!=r.uid+1 or not host.purchase_value_same(r.ticket,spent_ticket): return fail("darkcrest_mini_changed_delivery_completion_window")
	var source_issue: String=board_error(host,game,p,r.source)
	if not source_issue.is_empty(): return fail(source_issue)
	if not host.purchase_value_same(u,r.snapshot): return fail("darkcrest_mini_changed_delivered_child")
	var expected: Array=r.hand.duplicate();expected.append(u)
	var values: Array=r.hand_values.duplicate(true);values.append(r.snapshot)
	if not host.Generation._same_objects(p.hand,expected) or not host.purchase_value_same(p.hand,values) or not host.LavaPlay._unique(game,u) or p.get(game.SpellcraftWaiting.KEY,[]).any(func(t):return is_same(t,r.ticket)): return fail("darkcrest_mini_delivery_not_received")
	_tokens[u.uid]={"unit":u,"owner":p,"round":r.round,"snapshot":r.snapshot,"used":false,"source_uid":r.source.uid,"ready":false}
	_flush_tokens.append(u.uid)
	if not _play.is_empty(): _play.child=u
	_delivery={}
	return ""
func delivery_close(host,game,p: Dictionary,flush: RefCounted,issue: String) -> String:
	if not actual(host,game,p): return "darkcrest_mini_original_flush_close_required"
	var guard: String=str(game.get_instance_id())+":"+str(p.get("id"))
	if not flush_matches(game.SpellcraftWaiting._active_flushes,guard,flush): return "darkcrest_mini_original_flush_close_required"
	if _flush_window==null and _delivery.is_empty() and _flush_tokens.is_empty(): return ""
	if not is_same(p,_flush_owner) or not is_same(flush,_flush_window): return "darkcrest_mini_original_flush_close_required"
	if not _delivery.is_empty() or (not _flush_tokens.is_empty() and not issue.is_empty()):
		fail("darkcrest_mini_partial_delivery:"+issue)
	elif issue.is_empty():
		for uid in _flush_tokens: _tokens[uid].ready=true
	_delivery={};_flush_tokens=[];_flush_owner={};_flush_window=null
	return _poison
# Cast-only: native sale may inspect hand tokens before its completion observer.
func cast_source_error(host,game,p: Dictionary,token: Dictionary) -> String:
	if not actual(host,game,p) or not _poison.is_empty(): return "darkcrest_mini_cast_source_authority_required"
	var issued: Dictionary=_tokens.get(token.get("uid"),{})
	var source: Variant=_board.get("unit")
	var engine: Variant=_board.get("engine")
	if not is_same(issued.get("unit"),token) or not is_same(issued.get("owner"),p) or not source is Dictionary or source.get("card_id")!=ID or not source.get("uid") is String or issued.get("source_uid")!=source.uid or not is_same(_board.get("owner"),p) or not engine is WeakRef or not is_same(engine.get_ref(),game): return "darkcrest_mini_cast_original_source_required"
	var zones: Array=[]
	for owner in game.state.players+game.state.get("ghosts",[]):
		for zone in ["board","hand","shop"]: zones.append(owner.get(zone,[]))
	var issue: String=source_presence_error(host,_board,p,issued.source_uid,game.state.round,game.state.command_sequence,zones)
	if not issue.is_empty(): return issue
	return board_error(host,game,p,source) if not _board.get("retired",false) else ""
# Content-only predicate. Actual engine/issued token/owned record checks remain outside.
static func source_presence_error(host,record: Dictionary,p: Dictionary,source_uid: String,round_number: int,sequence: int,zones: Array) -> String:
	var source: Variant=record.get("unit")
	if not source is Dictionary or source.get("card_id")!=ID or source.get("uid")!=source_uid or not is_same(record.get("owner"),p): return "darkcrest_mini_cast_original_source_required"
	if not record.get("retired",false):
		if not p.get("board",[]).any(func(item):return is_same(item,source)): return "darkcrest_mini_cast_missing_live_source"
		return ""
	if record.get("retired")!=true or not record.get("retired") is bool or record.get("retired_complete")!=true or not record.get("retired_complete") is bool or record.get("retired_uid")!=source_uid or not record.get("retired_round") is int or record.retired_round!=round_number or not record.get("retired_sequence") is int or record.retired_sequence<0 or record.retired_sequence>=sequence: return "darkcrest_mini_cast_completed_sale_required"
	if not host.purchase_value_same(source,record.get("snapshot")): return "darkcrest_mini_cast_retired_source_changed"
	for zone in zones:
		if not zone is Array: return "darkcrest_mini_cast_invalid_zone"
		for item in zone:
			if not item is Dictionary or is_same(item,source) or item.get("uid")==source_uid: return "darkcrest_mini_cast_retired_source_still_present"
	return ""

func cast_preflight(host,game,p: Dictionary,u: Dictionary,target: Dictionary) -> String:
	var issue: String=token_error(host,game,p,u)
	if not issue.is_empty(): return issue
	if _tokens.get(u.get("uid"),{}).get("ready")!=true: return "darkcrest_mini_flush_not_completed"
	issue=cast_source_error(host,game,p,u)
	if not issue.is_empty(): return issue
	if not _sale.is_empty() or not host._cast.is_empty() or not host._delivery.is_empty() or not host._eot.is_empty() or not host._generation._active.is_empty() or not _expiry.is_empty() or not _play.is_empty() or not _cast.is_empty() or not _delivery.is_empty() or not _reset.is_empty(): return "darkcrest_mini_busy_cast"
	issue=host.owner_error(game,p)
	if not issue.is_empty(): return issue
	if not p.hand.any(func(item):return is_same(item,u)) or not host.LavaPlay._unique(game,u) or not p.board.any(func(item):return is_same(item,target)) or target.get("card_id")!=host.LavaPlay.ID: return "darkcrest_mini_original_lava_target_required"
	issue=host._lava_play.board_error(host,game,p,target)
	if not issue.is_empty(): return issue
	if target.get("spellcraft_kept")!=0: return "darkcrest_mini_second_cast_held"
	if not target.get("attack") is int or target.attack>2147483645: return "darkcrest_mini_attack_overflow_held"
	return ""
func lava_transition_matches(host,game,p: Dictionary,u: Dictionary) -> bool:
	if _cast.is_empty() or not window(host,game,p,_cast) or not is_same(_cast.target,u): return false
	var partial: Dictionary=_cast.before.duplicate(true);partial.spellcraft_kept=1
	return host.purchase_value_same(u,_cast.before) or host.purchase_value_same(u,partial) or host.purchase_value_same(u,_cast.expected)
func complete(host,game,p: Dictionary,result: Dictionary) -> String:
	var r: Dictionary=_play if not _play.is_empty() else _cast
	if r.is_empty() or not window(host,game,p,r): return fail("darkcrest_mini_changed_completion_window")
	if result.get("ok")!=true or game.state.phase!="recruit" or not _poison.is_empty():
		_play={};_cast={};return fail("darkcrest_mini_partial_native_operation")
	var hand: Array=r.hand.duplicate();hand.remove_at(r.index)
	var hand_values: Array=r.hand_values.duplicate(true);hand_values.remove_at(r.index)
	var board: Array=r.board.duplicate();var board_values: Array=r.board_values.duplicate(true)
	if r.kind=="play":
		if not r.get("inserted",false) or not r.get("child") is Dictionary: return fail("darkcrest_mini_missing_insert_or_child")
		hand.append(r.child);hand_values.append(_tokens[r.child.uid].snapshot)
		var position: int=r.position if r.position>=0 and r.position<=board.size() else board.size()
		board.insert(position,r.unit);board_values.insert(position,r.snapshot)
		if not host.Generation._same_objects(p.board,board) or not host.purchase_value_same(p.board,board_values) or not host.purchase_value_same(p.hand,hand_values) or _tokens[r.child.uid].get("ready")!=true: return fail("darkcrest_mini_changed_play_values")
		if p.stats.played!=r.played+1 or not host.Generation._same_objects(p.hand,hand): return fail("darkcrest_mini_changed_play_suffix")
		var issue: String=board_error(host,game,p,r.unit)
		if not issue.is_empty(): return fail(issue)
		_board={"owner":p,"unit":r.unit,"snapshot":r.snapshot,"engine":r.engine}
		_play={}
	else:
		var target_index: int=board.find(r.target)
		if target_index<0: return fail("darkcrest_mini_target_not_original_board")
		board_values[target_index]=r.expected
		if not host.Generation._same_objects(p.board,board) or not host.purchase_value_same(p.board,board_values) or not host.purchase_value_same(p.hand,hand_values): return fail("darkcrest_mini_changed_cast_values")
		if not host.Generation._same_objects(p.hand,hand) or p.stats.spells!=r.spells+1 or not host.purchase_value_same(r.target,r.expected) or not is_same(host._lava_play._board.get(r.target.uid),r.lava_record): return fail("darkcrest_mini_changed_cast_suffix")
		r.lava_record.snapshot=r.expected.duplicate(true);r.lava_record.mini_steps=int(r.lava_record.get("mini_steps",0))+1;r.lava_record.mini_round=game.state.round
		_tokens[r.unit.uid].used=true
		_cast={}
	return ""
func reset_begin(host,game,p: Dictionary,u: Dictionary) -> String:
	if not actual(host,game,p) or not _sale.is_empty() or not _reset.is_empty() or not _cast.is_empty() or not _play.is_empty() or not _poison.is_empty(): return "darkcrest_mini_reset_host_required"
	var r: Dictionary=host._lava_play._board.get(u.get("uid"),{})
	if r.is_empty() or not is_same(r.get("unit"),u) or not is_same(r.get("owner"),p) or not host.purchase_value_same(u,r.snapshot) or game.state.round!=int(r.get("mini_round",-1))+1: return "darkcrest_mini_reset_old_receipt_required"
	var c: Dictionary=game._darkcrest_mini_context
	if c.get("kind")!="reset" or not is_same(c.get("unit"),u) or not is_same(c.get("owner"),p) or not c.get("nonce") is RefCounted or not is_same(c.nonce,game._darkcrest_mini_nonce): return "darkcrest_mini_native_reset_window_required"
	_reset={"engine":weakref(game),"context":c,"owner":p,"unit":u,"target":c.get("target"),"nonce":c.nonce,"kind":"reset","index":c.get("index"),"position":c.get("position"),"round":game.state.round,"sequence":game.state.command_sequence,"record":r,"expected":r.snapshot.duplicate(true)}
	_reset.expected.spellcraft_kept=0
	return ""
func reset_complete(host,game,p: Dictionary,u: Dictionary) -> String:
	if _reset.is_empty() or not window(host,game,p,_reset) or not is_same(_reset.unit,u) or not host.purchase_value_same(u,_reset.expected): return fail("darkcrest_mini_changed_native_reset")
	_reset.record.snapshot=_reset.expected.duplicate(true)
	_reset.record.mini_round=game.state.round
	_reset={}
	return ""
func expiry_begin(host,game,p: Dictionary) -> String:
	if not actual(host,game,p) or not _sale.is_empty() or not _poison.is_empty() or not _expiry.is_empty(): return "darkcrest_mini_expiry_host_required"
	var c: Dictionary=game._darkcrest_mini_context
	if c.get("kind")!="expiry" or not is_same(c.get("owner"),p) or not c.get("nonce") is RefCounted or not is_same(c.nonce,game._darkcrest_mini_nonce): return "darkcrest_mini_native_expiry_window_required"
	var expiring: Array=[]
	for u in p.hand:
		if u.get("card_id")!=SPELL: continue
		var issue: String=token_error(host,game,p,u)
		if not issue.is_empty(): return issue
		expiring.append(u)
	_expiry={"engine":weakref(game),"context":c,"owner":p,"unit":c.get("unit"),"target":c.get("target"),"nonce":c.nonce,"kind":"expiry","index":c.get("index"),"position":c.get("position"),"round":game.state.round,"sequence":game.state.command_sequence,"units":expiring,"hand":p.hand.filter(func(u):return not u.get("expires_at_end_turn",false)),"values":p.hand.filter(func(u):return not u.get("expires_at_end_turn",false)).duplicate(true)}
	return ""
func expiry_complete(host,game,p: Dictionary) -> String:
	if _expiry.is_empty() or not window(host,game,p,_expiry) or not host.Generation._same_objects(p.hand,_expiry.hand) or not host.purchase_value_same(p.hand,_expiry.values): return fail("darkcrest_mini_changed_native_expiry")
	for u in _expiry.units:
		for owner in game.state.players+game.state.get("ghosts",[]):
			for zone in ["board","hand","shop"]:
				if owner.get(zone,[]).any(func(other):return is_same(other,u) or other.get("uid")==u.uid): return fail("darkcrest_mini_expired_token_still_present")
		_tokens[u.uid].expired=true
	_expiry={}
	return ""

# Original issued children survive this source's retirement. No new issuance here.
static func sale_context_matches(host,c: Dictionary,p: Dictionary,u: Dictionary,uid: String,index: int,sold: int,round_number: int,sequence: int,plan: Dictionary,values: Dictionary) -> bool:
	return c.size()==8 and is_same(c.get("owner"),p) and is_same(c.get("sold"),u) and c.get("sold_uid") is String and c.sold_uid==uid and c.get("index") is int and c.index==index and c.get("sales_before") is int and c.sales_before==sold and c.get("round") is int and c.round==round_number and c.get("sequence") is int and c.sequence==sequence and is_same(c.get("generated_tier7_plan"),plan) and host.purchase_value_same(plan,values)
static func token_facts(r: Dictionary) -> Dictionary:
	var facts: Dictionary=r.duplicate();facts.erase("owner");facts.erase("unit")
	return facts.duplicate(true)
func sale_preflight(host,game,p: Dictionary,u: Dictionary) -> String:
	if not actual(host,game,p) or game.state.phase!="recruit" or not _poison.is_empty(): return "darkcrest_mini_actual_sale_required"
	if not _sale.is_empty() or not _play.is_empty() or not _cast.is_empty() or not _delivery.is_empty() or not _reset.is_empty() or not _expiry.is_empty() or _flush_window!=null or not _flush_tokens.is_empty() or not host._cast.is_empty() or not host._delivery.is_empty() or not host._eot.is_empty() or not host._generation._active.is_empty() or not host._lava_play._pending.is_empty() or not host._lava_play._sale_pending.is_empty(): return "darkcrest_mini_busy_sale"
	var issue: String=host.owner_error(game,p)
	if issue.is_empty(): issue=board_error(host,game,p,u)
	if not issue.is_empty(): return issue
	if not p.get("spellcraft_waiting",[]).is_empty(): return "darkcrest_mini_sale_pending_grant_held"
	var children: Array=p.hand.filter(func(item):return item.get("card_id")==SPELL)
	if children.size()!=1: return "darkcrest_mini_sale_single_ready_child_required"
	var child: Dictionary=children[0]
	issue=token_error(host,game,p,child)
	if not issue.is_empty(): return issue
	var r: Dictionary=_tokens.get(child.get("uid"),{})
	if r.get("source_uid")!=u.uid or r.get("ready")!=true or r.get("expired",false) or not host.LavaPlay._unique(game,child): return "darkcrest_mini_sale_original_child_required"
	if not p.get("gold") is int or not p.get("stats",{}).get("sold") is int or not game.next_uid is int or game.next_uid<1 or not host.LavaPlay._sale_inventory_valid(game.pool) or not host.LavaPlay._sale_inventory_valid(game.spell_pool) or not game.pool.has(ID): return "darkcrest_mini_sale_accounting_held"
	if u.get("pool_id")!=ID or not u.get("pool_count") is int or u.pool_count!=1 or u.get("pool_kind","minion")!="minion": return "darkcrest_mini_sale_pool_held"
	return ""
func begin_sale(host,game,p: Dictionary,index: int,c: Dictionary) -> String:
	if not actual(host,game,p) or index<0 or index>=p.board.size(): return "darkcrest_mini_actual_sale_required"
	var u: Dictionary=p.board[index]
	var issue: String=sale_preflight(host,game,p,u)
	if not issue.is_empty(): return issue
	if not is_same(c,game._native_sale_operation_context) or not c.get("generated_tier7_plan") is Dictionary: return "darkcrest_mini_original_sale_operation_required"
	var plan: Dictionary=c.generated_tier7_plan
	if not host.purchase_value_same(plan,{"ok":true,"error":"","active":false}) or not sale_context_matches(host,c,p,u,u.uid,index,p.stats.sold,game.state.round,game.state.command_sequence,plan,plan): return "darkcrest_mini_changed_sale_operation"
	var tokens: Dictionary={}
	for uid in _tokens:
		var r: Dictionary=_tokens[uid]
		tokens[uid]={"record":r,"owner":r.owner,"unit":r.unit,"facts":token_facts(r)}
	_sale={"engine":weakref(game),"owner":p,"unit":u,"uid":u.uid,"record":_board,"source_values":u.duplicate(true),"context":c,"plan":plan,"plan_values":plan.duplicate(true),"index":index,"sold":p.stats.sold,"round":game.state.round,"sequence":game.state.command_sequence,"gold":p.gold,"pool":game.pool.duplicate(true),"spell_pool":game.spell_pool.duplicate(true),"next_uid":game.next_uid,"seed":game.rng.seed,"rng":game.rng.state,"board":p.board.duplicate(),"values":p.board.duplicate(true),"hand":p.hand.duplicate(),"hand_values":p.hand.duplicate(true),"tokens":tokens}
	return ""
func finish_sale(host,game,p: Dictionary,c: Dictionary,result: Dictionary) -> String:
	if _sale.is_empty(): return "darkcrest_mini_unbound_sale_completion"
	var r: Dictionary=_sale
	if not actual(host,game,p) or not is_same(r.engine.get_ref(),game) or not is_same(r.owner,p) or not is_same(_board,r.record) or not is_same(_board.get("unit"),r.unit): return "darkcrest_mini_changed_sale_authority"
	var departed: bool=not p.board.any(func(item):return is_same(item,r.unit))
	# Retirement is revocation only and happens even after partial native failure.
	if departed:
		_board.retired=true;_board.retired_complete=false;_board.retired_uid=r.uid;_board.retired_round=r.round;_board.retired_sequence=r.sequence
	_sale={}
	if not is_same(c,r.context) or not is_same(c,game._native_sale_operation_context) or not sale_context_matches(host,c,p,r.unit,r.uid,r.index,r.sold,r.round,r.sequence,r.plan,r.plan_values) or game.state.round!=r.round or game.state.command_sequence!=r.sequence: return fail("darkcrest_mini_changed_sale_completion")
	if result.get("ok")!=true:
		if departed: return fail("darkcrest_mini_partial_native_sale")
		return ""
	if game.state.phase!="recruit" or not departed: return fail("darkcrest_mini_sale_missing_departure")
	if not host.purchase_value_same(r.unit,r.source_values): return fail("darkcrest_mini_sale_changed_departed_source")
	for owner in game.state.players+game.state.get("ghosts",[]):
		for zone in ["board","hand","shop"]:
			if owner.get(zone,[]).any(func(item):return is_same(item,r.unit) or item.get("uid")==r.uid): return fail("darkcrest_mini_sold_entity_still_present")
	var board: Array=r.board.duplicate();board.remove_at(r.index)
	var values: Array=r.values.duplicate(true);values.remove_at(r.index)
	var pool: Dictionary=r.pool.duplicate(true);pool[ID]+=1
	if not host.Generation._same_objects(p.board,board) or not host.purchase_value_same(p.board,values) or not host.Generation._same_objects(p.hand,r.hand) or not host.purchase_value_same(p.hand,r.hand_values): return fail("darkcrest_mini_sale_changed_zones")
	if not p.gold is int or not p.stats.sold is int or p.gold!=r.gold+1 or p.stats.sold!=r.sold+1 or not host.LavaPlay._sale_inventory_matches(game.pool,pool) or not host.LavaPlay._sale_inventory_matches(game.spell_pool,r.spell_pool) or not game.next_uid is int or game.next_uid!=r.next_uid or game.rng.seed!=r.seed or game.rng.state!=r.rng: return fail("darkcrest_mini_sale_changed_accounting")
	if _tokens.size()!=r.tokens.size(): return fail("darkcrest_mini_sale_changed_token_registry")
	for uid in r.tokens:
		var before: Dictionary=r.tokens[uid]
		var current: Dictionary=_tokens.get(uid,{})
		if not is_same(current,before.record) or not is_same(current.get("owner"),before.owner) or not is_same(current.get("unit"),before.unit) or not host.purchase_value_same(token_facts(current),before.facts): return fail("darkcrest_mini_sale_changed_issued_child")
	_board.retired_complete=true
	return ""
