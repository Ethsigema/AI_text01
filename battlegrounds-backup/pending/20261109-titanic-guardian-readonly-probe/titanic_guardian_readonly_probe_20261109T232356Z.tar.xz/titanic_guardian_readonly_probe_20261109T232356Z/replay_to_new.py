"""Reproduce historical original/gate differences in a new isolated directory only."""
from pathlib import Path
import hashlib,json,subprocess,sys
H=Path(__file__).resolve().parent
assert len(sys.argv)==2;D=Path(sys.argv[1]).resolve();assert not D.exists();D.mkdir(parents=True)
files=json.loads((H/'REPLAY_INPUTS.json').read_text())
for rel,pin in files.items():
 p=H/rel;b=p.read_bytes();assert len(b)==pin['bytes'] and hashlib.sha256(b).hexdigest()==pin['sha256'];d=D/rel;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(b);assert d.stat().st_ino!=p.stat().st_ino
for script in ['test_original.py','check_native_inputs.py','run_godot.py']:subprocess.run([sys.executable,'-B',str(D/script)],check=True)
gd=json.loads((D/'GODOT_first.json').read_text());assert gd==json.loads((D/'GODOT_repeat.json').read_text()) and not gd['failures']
assert gd['case_count']==218
assert sum(v['original_accept_gd_reject'] for v in gd['counts'].values())==108
assert gd['counts']['coupled']['original_accept_gd_reject']==28 and gd['counts']['companion']['original_accept_gd_reject']==28
assert sum(v['original_exception'] for v in gd['counts'].values())==8
for rel,pin in files.items():
 if rel.startswith(('original_inputs/','gd_minimal/core/')):assert hashlib.sha256((D/rel).read_bytes()).hexdigest()==pin['sha256']
result={'status':'PASS_REPRODUCTION_OF_KNOWN_DIFFERENCES_NOT_RESTORATION_APPROVAL','destination':str(D),'copied_files':len(files),'original_source_tree_needed':False,'main_cases':218,'coupled_and_companion_discrepant_calls':56,'distinct_bool_alias_mapping_variants':28,'detached_only_discrepant_calls':52,'bad_mapping_exceptions':8,'new_correction_or_installation':False,'full_driver_catalog_game_or_save_run':False}
(D/'REPLAY_RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
