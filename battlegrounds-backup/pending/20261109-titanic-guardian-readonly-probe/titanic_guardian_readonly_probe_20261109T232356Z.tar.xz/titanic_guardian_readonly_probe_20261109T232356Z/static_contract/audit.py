"""Read-only target audit. Historical modules are data, never imported/executed."""
import ast, collections, gzip, hashlib, json, pathlib, re, resource
resource.setrlimit(resource.RLIMIT_AS,(128*1024*1024,128*1024*1024))
W=pathlib.Path('/workspace/scratch/dd4f12b08ec0')
R=W/'historical_tools_batch14_20261109T191857Z/runtime'
D=pathlib.Path(__file__).resolve().parent
F=R/'research/titanic_guardian_native_recovery'
M=W/'driver_mapping_contract_20261109T230410Z'
def digest(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(65536),b''):h.update(b)
 return h.hexdigest()
def pin(p):return {'path':str(p.relative_to(W)),'bytes':p.stat().st_size,'sha256':digest(p)}
def dump(name,obj):(D/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
def exact(a,b):
 if type(a) is not type(b):return False
 if isinstance(a,dict):return a.keys()==b.keys() and all(exact(a[k],b[k]) for k in a)
 if isinstance(a,(list,tuple)):return len(a)==len(b) and all(exact(x,y) for x,y in zip(a,b))
 return a==b
def literals(p):
 result={}
 for n in ast.parse(p.read_text()).body:
  if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name):
   try:result[n.targets[0].id]=ast.literal_eval(n.value)
   except (ValueError,TypeError):pass
 return result
tool=F/'candidates/tools/titanic_guardian_patterns.py'
t=literals(tool);IDS=t['SOURCE_IDS'];RAW=t['RAW'];EXPECTED=t['EXPECTED']
gd=R/'core/titanic_guardian_sources.gd';g={}
for line in gd.read_text().splitlines():
 m=re.match(r'const (RAW|EXPECTED|PROGRAMS|RUNTIME_PATHS|IDS): \w+=(.*)',line)
 if m:g[m[1]]=json.loads(m[2])
new=json.loads((F/'new_files_sha256.json').read_text());shared=json.loads((F/'shared_manifest.json').read_text())
newchecks=[]
for name,expected in new.items():
 paths=[F/'candidates'/name,R/name]
 newchecks.append({'path':name,'expected_sha256':expected,'locations':[dict(pin(p),matches_pin=digest(p)==expected) if p.exists() else {'path':str(p.relative_to(W)),'missing':True} for p in paths]})
sharedchecks=[]
for row in shared:
 p=R/row['candidate'];sharedchecks.append(dict(row,actual_sha256=digest(p),matches_after=digest(p)==row['after_sha256']))
sourcechecks={}
for k,name in [('RAW','raw_rows.json'),('EXPECTED','expected_compiled.json'),('PROGRAMS','programs.json')]:
 local=json.loads((F/name).read_text());sourcechecks[k]={'gd_equals_local_type_strict':exact(g[k],local),'python_equals_local_type_strict':exact(t[k],local) if k in t else None,'local_pin':pin(F/name)}
sourcechecks['IDS']={'python_equals_gd':list(IDS)==g['IDS']}
sourcechecks['programs']={'expected_effects_equal_programs':all(exact(EXPECTED[i]['effects'],g['PROGRAMS'][i]) for i in IDS),'overlay_equals_expected':exact(json.loads((F/'pending_catalog_overlay.json').read_text()),list(EXPECTED.values()))}
native=json.loads((F/'native_source_manifest.json').read_text());quant=json.loads((F/'native_quantities.json').read_text())
sourcechecks['native']={'entities_equal_quantities':exact(native['entities'],quant),'rows':[]}
for i in IDS:
 q=quant[i]; sourcechecks['native']['rows'].append({'id':i,'native_hash_matches':digest(F/'native'/f'{i}.xml')==q['native_sha256'],'raw_quantities_equal':all(exact(RAW[i][k],q[k]) for k in ['dbf_id','attack','health','tier']),'text_equal':RAW[i]['text']==q['zhCN'],'race_elemental':q['race']==18 and RAW[i]['tribes']==['元素'],'gold_multiplier':q['health_multiplier'],'operations':q['operations'],'native_links':q['native_links'],'coverage_text_hash_matches':hashlib.sha256(RAW[i]['text'].encode()).hexdigest()==EXPECTED[i]['coverage_text_sha256']})
patch=(F/'shared_changes.patch').read_text()
dump('SOURCE_CONSISTENCY.json',{'tool_pin':pin(tool),'gd_pin':pin(gd),'new_files_manifest_pin':pin(F/'new_files_sha256.json'),'shared_patch_pin':pin(F/'shared_changes.patch'),'build_candidates_pin':pin(F/'build_candidates.py'),'new_file_checks':newchecks,'shared_candidates':sharedchecks,'checks':sourcechecks,'patch_creates_tool':('+++ b/tools/titanic_guardian_patterns.py' in patch),'patch_contains_dev_null':('/dev/null' in patch),'patch_headers':[l for l in patch.splitlines() if l.startswith(('--- ','+++ '))],'runtime_paths':[{ 'path':p,'exists':(R/p).exists()} for p in g['RUNTIME_PATHS']]})

# Reuse static JSON indexes for target hooks; verify source bytes before snippets.
idx=json.loads((W/'historical_tools_batch16_driver_closeout_20261109T205039Z/compiler/CURRENT_VERSIONS.json').read_text())
drivers=[];forms=collections.defaultdict(list)
for row in idx:
 ev=M/'versions'/f"{row['sha256']}.json.gz"
 j=json.loads(gzip.decompress(ev.read_bytes()))
 calls=[c for c in j['whole_mapping_or_raw_argument_sites'] if c.get('function')=='compile_titanic_guardian']
 p=R/row['paths'][0]['path'];assert digest(p)==row['sha256']
 ls=p.read_text().splitlines();hooks=[]
 for c in calls:
  n=c['line'];lo=n-4;hi=n+8
  snippet='\n'.join(ls[lo-1:hi]);forms[snippet].append(row['sha256'])
  hooks.append({'line':n,'call':c,'context_snippet_first_line':lo,'context_snippet':snippet,'pre_hook_whole_cards_sites':sum(x['line']<n and 'cards' in x['objects'] for x in j['whole_mapping_or_raw_argument_sites'])})
 drivers.append({'sha256':row['sha256'],'paths':row['paths'],'source_sha_checked':True,'hook_count':len(calls),'hooks':hooks,'emit':j['emit'],'preprocess':j['preprocess'],'terminal_catalog_write':j['terminal'][0]})
dump('DRIVER_TARGET_CONTRACT.json',{'index_pin':pin(W/'historical_tools_batch16_driver_closeout_20261109T205039Z/compiler/CURRENT_VERSIONS.json'),'version_count':len(drivers),'with_hook':sum(bool(v['hooks']) for v in drivers),'hook_count_distribution':dict(collections.Counter(v['hook_count'] for v in drivers)),'hook_forms':[{'source':s,'count':len(v),'versions':v} for s,v in forms.items()],'drivers':drivers})

# Streaming JSON row parser copied in shape, not executed from prior audit.
class Stream:
 def __init__(self,f):self.f=f;self.b='';self.p=0;self.dec=json.JSONDecoder()
 def fill(self):self.b=self.b[self.p:]+self.f.read(65536);self.p=0
 def ws(self):
  while True:
   while self.p<len(self.b) and self.b[self.p].isspace():self.p+=1
   if self.p<len(self.b):return
   self.fill()
   if not self.b:return
 def char(self):self.ws();return self.b[self.p] if self.p<len(self.b) else ''
 def take(self,c):assert self.char()==c,(self.char(),c);self.p+=1
 def val(self):
  self.ws()
  while True:
   try:v,e=self.dec.raw_decode(self.b,self.p);self.p=e;return v
   except json.JSONDecodeError:
    old=len(self.b)-self.p;self.fill()
    if len(self.b)==old:raise
 def rows(self):
  self.take('{');first=True;found=False
  while self.char()!='}':
   if not first:self.take(',')
   first=False;k=self.val();self.take(':')
   if k=='cards':
    assert not found;found=True;self.take('[');firstrow=True
    while self.char()!=']':
     if not firstrow:self.take(',')
     firstrow=False;yield self.val()
    self.take(']')
   else:self.val()
  self.take('}');assert not self.char();assert found
catalog=R/'core/catalog.gd';cs=catalog.read_text();paths=json.loads(re.search(r'for path in (\["res://data/catalog_raw.json".*?\]):',cs).group(1))
files=[];target_occ=[];merged={}
for path in paths:
 p=R/path.removeprefix('res://');before=digest(p);hits=[];count=0
 with p.open() as f:
  for n,c in enumerate(Stream(f).rows()):
   count+=1;i=c.get('id')
   if i in IDS:
    hits.append({'index':n,'id':i,'type_strict_equal_RAW':exact(c,RAW[i]),'type_strict_equal_EXPECTED':exact(c,EXPECTED[i]),'canonical_json_sha256':hashlib.sha256(json.dumps(c,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest(),'keys':list(c)})
    merged.setdefault(i,{}).update(c)
    target_occ.append({'path':path,'index':n,'id':i})
 after=digest(p);assert before==after
 files.append({'path':path,'rows':count,'sha256':before,'bytes':p.stat().st_size,'target_hits':hits})
pre=[]
for name in ['quest_identity_overrides.json','removed_hero_value_overrides.json','final_bg_source_overrides.json','catalog_value_overrides.json','season_presets.json']:
 p=R/'data'/name;b=p.read_text();obj=json.loads(b)
 pre.append({'pin':pin(p),'target_string_mentions':[i for i in IDS if i in b],'top_keys':list(obj),'target_override_ids':[x.get('id') for x in obj.get('overrides',[]) if x.get('id') in IDS]})
dump('CURRENT_TARGET_DATA.json',{'catalog_pin':pin(catalog),'files':files,'target_occurrences':target_occ,'limited_direct_merge_not_full_catalog_execution':[{'id':i,'merged_equals_RAW_plus_EXPECTED_type_strict':exact(merged[i],dict(RAW[i],**EXPECTED[i]))} for i in IDS],'preprocessor_data':pre,'max_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss})

# Minimum preload graph of the target sources, not all Catalog/Game dependencies.
pending=['core/titanic_guardian_sources.gd'];closure={}
while pending:
 path=pending.pop()
 if path in closure:continue
 p=R/path;deps=re.findall(r'preload\("res://([^\"]+)"\)',p.read_text())
 closure[path]={'pin':pin(p),'preloads':deps};pending.extend(deps)
dump('MINIMUM_PRELOAD_CLOSURE.json',closure)
snips=[]
def excerpt(p,ranges):
 ls=p.read_text().splitlines();out=['FILE '+str(p.relative_to(W))+' SHA256 '+digest(p)]
 for a,b in ranges:out+=['\n'+ '\n'.join(f'{n}: {ls[n-1]}' for n in range(a,min(b,len(ls))+1))]
 return '\n'.join(out)
snips.append(excerpt(catalog,[(1408,1417),(2189,2208),(2468,2474),(3279,3286),(5128,5135),(6969,6976),(8810,8817),(11635,11650),(11810,11822),(12131,12141),(12172,12179),(12199,12202),(12502,12506),(14373,14379),(14838,14843),(15442,15445),(18797,18803)]))
snips.append(excerpt(R/'core/custom_shop.gd',[(17,40),(42,69),(103,141)]))
snips.append(excerpt(gd,[(9,75)]))
for p,ranges in [(R/'core/phase_undead_army_sources.gd',[(8,23)]),(R/'core/quest_identity_overrides.gd',[(1,34)]),(R/'core/hero_value_overrides.gd',[(1,30)]),(R/'tools/final_source_overrides.py',[(12,48)])]:snips.append(excerpt(p,ranges))
(D/'CURRENT_GD_EXCERPTS.txt').write_text('\n\n'.join(snips)+'\n')
dump('SOURCE_PINS.json',[pin(p) for p in [tool,gd,catalog,R/'core/custom_shop.gd',R/'core/phase_undead_army_sources.gd',R/'core/pool_identity.gd',F/'shared_changes.patch',F/'shared_manifest.json',F/'new_files_sha256.json',F/'build_candidates.py',F/'admission.json',F/'static_review.json']])
print(json.dumps({'output':str(D),'drivers':len(drivers),'with_hook':sum(bool(v['hooks']) for v in drivers),'hook_forms':len(forms),'files':len(files),'occurrences':target_occ,'closure':list(closure),'max_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss},ensure_ascii=False,indent=2))
