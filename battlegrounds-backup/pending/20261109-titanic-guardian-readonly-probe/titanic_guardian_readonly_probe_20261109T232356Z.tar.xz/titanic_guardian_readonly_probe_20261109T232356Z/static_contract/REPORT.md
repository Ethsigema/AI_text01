# Titanic Guardian 历史恢复与编译契约：只读定向复核

## 结论

1. 缺失工具有完整、同家族 manifest pin 验证通过的历史候选原件，可以按原字节识别；不是从零实现。它的来源边界是 candidate-only 构建产物，不是当前完整 driver 身份或 gameplay 验收证明。
2. 98 个索引历史 driver 中，79 个含 Titanic hook，且只有一种完整适配形式：`c=cards.get(identity)` 后传同一个 `cards`，再调用 `emit`。没有 Titanic direct-out 变体。其余19版没有 `titanic_guardian` 字串。
3. 函数接受 detached-card 与实际 hook 输入必须区分：detached-card 是该函数接口的局部缺口，但已见 hook 没有那样传参。Python 普通 equality 的 bool/number 混淆则不需要 detached card，可在同一 `cards` 行与 `c=cards.get(identity)` 的耦合调用形状中成立。当前 GD 的完整行比较区分 bool 和数值，因此二者不是同一拒绝域。
4. 当前20个 Catalog 输入中，两目标只在 raw 和 compiled 文件各出现一次；原始两行严格等于工具/GD 的 RAW，编译两行严格等于 EXPECTED。未发现当前目标行被污染。不能据此推出任意历史预处理或全部前置调用都不改行。
5. 本子任务只做静态与数据检查；没有运行历史工具、driver、Godot 或 Game，没有联网、下载、原大档解压、修复或发布。动态差异试验由父任务独立负责。

## 1. 历史原件、pin 与发布边界

runtime 根始终是 `historical_tools_batch14_20261109T191857Z/runtime`。

- 完整工具：`research/titanic_guardian_native_recovery/candidates/tools/titanic_guardian_patterns.py`，21,173 bytes，SHA256 `fc3dba9438f89860267b8db034b88415ba8d78ff6f905ba556beee29db248a29`。
- 当前 `core/titanic_guardian_sources.gd`：26,744 bytes，SHA256 `009fde54828dc10c9aba0c20a41c532cb1886ac0e7139524d73186af5ff8a6cd`。
- `new_files_sha256.json` SHA256 `4422c785061221636bb9df083e0f19ac022f4486bcf2c608ab780b84329c07fd` 独立列出以上两项及9项证据文件。全部11个候选文件符合 pin；对应 live 文件中10个仍符合 pin，唯工具缺失。
- `shared_manifest.json` 的19个候选共享文件全部符合 after_sha256。它不声称当前全部共享文件仍等于该历史候选，也不确定当前完整 driver 应为此版。
- `shared_changes.patch` SHA256 `42d28476803178a37f53a7f341aa320b76d8e3d08b9bce3c45ef7b7544482f11` 只有19个旧共享文件的差异，无 `/dev/null`、无新增 `tools/titanic_guardian_patterns.py` 创建 hunk。
- 完整工具的创建逻辑在 `build_candidates.py:31`，直接把常量和函数写到 candidates；265–271行明确序列化 candidate-only 内容，另建新文件哈希清单。没有运行此构建脚本。
- `static_review.json` 保存 `sealed_static_only_pending_parent_admission`；`admission.json` 保存旧时的 source/syntax admission 成功，同时明确 `game_instantiated=false`、`effects_executed=false`、`gameplay_acceptance=not_run`。两者不能充当本轮已执行的验收。
- 当前 `TitanicSources.RUNTIME_PATHS` 内缺失工具及 `tools/build_effect_catalog.py` 两项。Catalog 1412–1413行只是把这些路径内容的哈希加入执行指纹；这不是一个重新运行编译器的证明。

`SOURCE_CONSISTENCY.json` 保存全部逐文件结果。工具和GD的 RAW、EXPECTED 与本地 raw_rows.json / expected_compiled.json 按键、值、类型严格相等；GD PROGRAMS 等于 programs.json，EXPECTED.effects 等于 PROGRAMS；pending_catalog_overlay 等于 EXPECTED 的两行列表。原生XML重新解析确认 CardID、DBF、名称、攻血、星级、种族、独立中英文卡文、双向正常/金色链接与 quantities 一致；两份XML内容哈希符合 native pin。正常倍率1、金色倍率2，均为一次操作。证据为 `NATIVE_XML_CHECK.json`，没有访问 manifest 中的网络来源。

## 2. 实际历史 hook 与 emit

复用此前 `driver_mapping_contract_20261109T230410Z/versions/*.json.gz` 的静态语法记录，并重新读取、核验98个代表源码的 SHA256。没有重新扫描全部 imports，也没有导入历史模块。目标文本交叉检查同时确认79版各只有一次目标 import、一次目标 call；无 hook 的19版没有 Titanic 字串。

同家族候选 driver SHA256 `7b2959d426c7e89798cbefed84870971db88a360649d0ca577cf07f1d2ce452d`，7243–7252行：

```python
from titanic_guardian_patterns import SOURCE_IDS as TITANIC_GUARDIAN_IDS, compile_card as compile_titanic_guardian
for identity in sorted(TITANIC_GUARDIAN_IDS):
 out.pop(identity,None)
 c=cards.get(identity)
 compiled=compile_titanic_guardian(c,cards)
 if compiled is not None:
  metadata={k:v for k,v in compiled.items() if k not in ("effects","keywords","coverage_rule")}
  emit(c,compiled["effects"],compiled["keywords"],rule=compiled["coverage_rule"],**metadata)
ordered_ids=[identity for identity in ordered_ids if identity not in TITANIC_GUARDIAN_IDS]
ordered_ids.extend(identity for identity in sorted(TITANIC_GUARDIAN_IDS) if identity in out)
```

本版558行的 emit 将对象放到 `out[c['id']]`，先写默认 id、supported、effects、keywords、rule、源文本hash、default_pool，最后 `**kw`。Titanic 返回的 EXPECTED 包含 id、supported、coverage_text_sha256、default_pool，因此 metadata 会覆盖这些默认值。对完整标准 RAW 对，最终输出内容严格是 EXPECTED，不是把原始行全部写回，也不是 direct `out[identity]=compiled`。

工具本身仅检查 card 为 dict 且 id 在 SOURCE_IDS；它用 Python `!=` 验证 `cards.get(identity)` 的整对 RAW，然后 deepcopy 固定 EXPECTED。已见 hook 的 c 从该对同一个映射取得，所以在普通JSON对象域内，不需对 detached-card 反例赋予这个 hook 并未使用的调用方式。

但完整映射中的 `is_golden: false` 换成数值 `0`（或其它 bool/等值数值替换），Python equality 仍可能认为整对 RAW 相等。此时 c 仍取自同一张 cards 行，工具可返回固定 EXPECTED。GD `Exact.same` 允许 int/float 等值，但先后类型检查会拒绝 bool 与数值混用。这个结论是局部源码语义，不声称当前原始数据已发生该变异，也不声称完整 driver 已成功执行到此。

相同历史前置顺序为 QuestIdentity → raw=list(cards.values()) → HeroValues → FinalSource → confirmed value overrides。当前五份相关数据（quest_identity_overrides、removed_hero_value_overrides、final_bg_source_overrides、catalog_value_overrides、season_presets）均没有两个目标ID字串。现存 FinalSource 的固定19项IDS也不含目标；当前GD QuestIdentity只修BG27_Quest_800，HeroValues只修三个英雄。缺失的Python QuestIdentity/HeroValues源码不能用GD实现代替；79个 hook 之前另有813–827个整个cards作为实参的静态站点（包括预处理，非执行计数），不保证全路径不可变。

详见 `DRIVER_TARGET_CONTRACT.json`、`DRIVER_TARGET_TEXT_CROSSCHECK.json`。

## 3. 当前 Catalog、配对 closure 与 Shop 的顺序

当前 Catalog SHA256 `5ba81a78d4924e4596dada5cb8f1a9ad5877d7bed6c7d350ca370d8bff955a72`，1,854,233 bytes，与父任务基线、先前 CURRENT_DATA_CONTRACT 相同。先前 REPORT.md 把 for-path 写成2186；准确行号2189，先前 CATALOG_EXCERPTS 本身正确。本轮没有来源变化。

若此前其他保护检查通过，目标路径的真实源码顺序为：

1. load_catalog 先构造指纹及家族证据，再按2189行20文件列表加载。进入 catalog.json 前依次执行 DamageRegistry → QuestIdentity → FinalSource → HeroValues（2190–2202）。
2. 解析原始JSON后，在 generic numeric coercion 前遍历 raw_card（2468–2469）。Titanic 的同形校验块在3279、5128、6969、8810行重复出现于同一循环，不是互斥分支：非 catalog.json 且 ID属于两目标时调用 raw_source_error；catalog.json 时先 deep-copy 已加载源行，再 merge 编译行，然后 source_error。错误加入 load_errors。
3. 11635行才 `_normalize_numbers`；随后每行深复制，取得ID，合并到 cards。11810–11822行做字段合并、顶层数值规整、源文本hash及资格检查。后续通用overlay、confirmed数值override，再计算 ordinary pool。伙伴身份不在当前季节名单，故添加固定 pool_blocker 并保持 default_pool=false、pool_supported=false。
4. 12502–12506行：对于 claimed 行，先 source_error 成功，再 closure_error(self)。失败把该行的三项支持/池标志降为false并记 blocker。14373行以后对仍supported的行调用 `_validate_effects`；15442–15445再次做 source_error，要求depth=0、完整effects严格等于 PROGRAMS。
5. source_error（Titanic 26–42）核对完整 RAW+EXPECTED，允许仅规定的 pool_blocker 和 custom-shop projection。closure（43–58）对canonical和当前catalog的两个外部键逐一get_card，强制行内id等于所取键，再核对完整源行；canonical不能带source_shop_fields；自定义normal/golden必须配套且星级相同。
6. `CustomShop.effective_catalog` 先回到canonical、validate，再新建catalog对象并深复制cards，保留source_catalog。它给普通牌保存原始 tier/cost/pool_supported 后设置明确tier/cost/copies和pool_supported=true；金色保存原始来源、继承普通星级并写custom_shop_derived_from。它不重新 load_catalog，也没有直接调用Titanic closure，不能把通用Shop.validate说成Titanic专属完整校验。
7. 调用侧 RoomConfig.validate 245–247先Shop.validate再effective_catalog；Game.start 1697–1702先RoomConfig.validate再生成effective_catalog。Game._factory_unit 9167行对Titanic先source_error再closure_error，失败返回空对象。因此真正取得自定义单位时仍有专属双catalog、双成员闭包检查。这里只读这几段，不运行Game或构造其对象。

完整静态片段见 `CURRENT_GD_EXCERPTS.txt` 与 `GAME_SHOP_ORDER_EXCERPTS.txt`。其他家族可能提前返回、其他状态可能阻断；本报告描述源码局部顺序，不声称全Catalog成功加载。

## 4. 最小GD preload与当前20输入

只测试 TitanicSources 的三个源校验函数，最小静态preload闭包共3个文件：

- titanic_guardian_sources.gd → phase_undead_army_sources.gd、pool_identity.gd。
- phase_undead_army_sources.gd → pool_identity.gd；pool_identity无进一步preload。
- 不必preload Catalog、Shop、Game；closure可由带source_catalog与get_card的最小对象承载。此闭包不是完整Catalog或游戏的依赖闭包。

三个文件及边、哈希见 `MINIMUM_PRELOAD_CLOSURE.json`。

流式遍历当前20文件，逐文件前后哈希一致，未整读30MiB raw JSON：

- `data/catalog_raw.json` SHA256 `bf7cabaa5d8e6df51f25ddaef3f3edba5fdb9102d22b6a9ce2228516158a5c27`。零基行2083/2084各匹配正常/金色 RAW，类型也完全一致。
- `data/catalog.json` SHA256 `caae174bb5ecbfdaa7ff78065c38d473908d651fd1bdb2c94c5abf83193a87b8`。零基行3378/3379各严格匹配 EXPECTED。
- 其余18文件没有两目标行。只做这四条记录的字段合并，得到 RAW+EXPECTED 完全一致。该有限合并检查不等于执行全部Catalog预处理、gate、overlay、pool及template路径。

详见 `CURRENT_TARGET_DATA.json`，包含所有20输入文件pin、行数、目标位置与5份先行数据pin。

## 5. 资源、证据与限制

独立新目录 `titanic_restore_contract_20261109T232532Z`。audit.py 和 supplement.py 都设置128MiB地址空间上限，主审计峰值RSS43,032KiB，补充审计23,044KiB。`/usr/bin/time` 不存在，改用Python resource 记录，没有提高内存上限。

没有修改runtime、历史候选、旧备份或以前的审计。没有任何拒绝后绕路或重新触发已取消网络操作。这里没有恢复工具到tools，也没有生成修正版本。当前完整driver与两个Python预处理缺失仍是证据限制，而不是只读权限阻塞。

`FILES_SHA256.json` 封存本目录证据文件哈希；`SOURCE_PINS.json` 记录读取的关键原始源码。`FINAL_RECHECK.json` 再核验这些来源与本报告所依赖的目标输入未变。
