"""Additional static-only checks and snippets; never imports historical code."""
import ast,collections,hashlib,json,pathlib,re,resource,xml.etree.ElementTree as ET
resource.setrlimit(resource.RLIMIT_AS,(128*1024*1024,128*1024*1024))
W=pathlib.Path('/workspace/scratch/dd4f12b08ec0');R=W/'historical_tools_batch14_20261109T191857Z/runtime';D=pathlib.Path(__file__).resolve().parent;F=R/'research/titanic_guardian_native_recovery'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def pin(p):return {'path':str(p.relative_to(W)),'sha256':sha(p),'bytes':p.stat().st_size}
def dump(n,v):(D/n).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
j=json.loads((D/'DRIVER_TARGET_CONTRACT.json').read_text());checks=[]
for v in j['drivers']:
 p=R/v['paths'][0]['path'];s=p.read_text();assert sha(p)==v['sha256']
 checks.append({'sha256':v['sha256'],'has_hook':bool(v['hooks']),'target_module_text_count':s.count('titanic_guardian_patterns'),'target_call_text_count':s.count('compile_titanic_guardian('),'target_compile_import_alias_count':s.count('compile_card as compile_titanic_guardian'),'titanic_string_absent_if_no_hook':'titanic_guardian' not in s if not v['hooks'] else None})
dump('DRIVER_TARGET_TEXT_CROSSCHECK.json',{'checks':checks,'all_hook_versions_have_one_import_one_call':all(c['target_module_text_count']==c['target_call_text_count']==c['target_compile_import_alias_count']==1 for c in checks if c['has_hook']),'all_no_hook_versions_have_no_titanic_string':all(c['titanic_string_absent_if_no_hook'] for c in checks if not c['has_hook'])})
q=json.loads((F/'native_quantities.json').read_text());native=[]
for i,expected in q.items():
 p=F/'native'/f'{i}.xml';e=ET.fromstring(p.read_text());tags={t.get('name'):t for t in e.findall('Tag')}
 parsed={'dbf_id':e.get('ID'),'name_enUS':tags['CARDNAME'].findtext('enUS'),'name_zhCN':tags['CARDNAME'].findtext('zhCN'),'attack':int(tags['ATK'].get('value')),'health':int(tags['HEALTH'].get('value')),'tier':int(tags['TECH_LEVEL'].get('value')),'race':int(tags['CARDRACE'].get('value')),'enUS':tags['CARDTEXT'].findtext('enUS'),'zhCN':tags['CARDTEXT'].findtext('zhCN'),'native_links':{k:int(tags[k].get('value')) for k in ['BACON_TRIPLE_UPGRADE_MINION_ID','BACON_TRIPLED_BASE_MINION_ID'] if k in tags}}
 native.append({'id':i,'pin':pin(p),'parsed_fields':parsed,'all_fields_equal_quantities':all(parsed[k]==expected[k] for k in parsed),'cardid_equals_key':e.get('CardID')==i})
dump('NATIVE_XML_CHECK.json',native)
out=[]
for path,ranges in [('core/game.gd',[(1450,1453),(1697,1705),(9036,9044),(9164,9170),(14351,14353),(14487,14497)]),('core/room_config.gd',[(185,188),(239,249)])]:
 p=R/path;ls=p.read_text().splitlines();out.append('FILE '+str(p.relative_to(W))+' SHA256 '+sha(p))
 for a,b in ranges:out.append('\n'.join(f'{i}: {ls[i-1]}' for i in range(a,b+1)))
(D/'GAME_SHOP_ORDER_EXCERPTS.txt').write_text('\n\n'.join(out)+'\n')
sourcepins=json.loads((D/'SOURCE_PINS.json').read_text());sourcepins.extend(pin(R/p) for p in ['core/game.gd','core/room_config.gd']);dump('SOURCE_PINS.json',sourcepins)
print(json.dumps({'native_xml_fields_match':all(x['all_fields_equal_quantities'] and x['cardid_equals_key'] for x in native),'max_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}))
