from pathlib import Path
import ast,hashlib,json,re,resource
resource.setrlimit(resource.RLIMIT_AS,(128*1024**2,128*1024**2))
H=Path(__file__).resolve().parent;R=H.parent/'historical_tools_batch14_20261109T191857Z/runtime';B=json.loads((R.parent/'SOURCE_MAP.json').read_text());family='research/titanic_guardian_native_recovery/'
newfiles=json.loads((R/family/'new_files_sha256.json').read_text());pins={}
rels=[family+'new_files_sha256.json',family+'shared_manifest.json',family+'shared_changes.patch',family+'candidates/tools/build_effect_catalog.py','core/phase_undead_army_sources.gd','core/pool_identity.gd']
rels += [family+'candidates/'+p if p.startswith('tools/') else p for p in newfiles]
for rel in rels:
 p=R/rel;b=p.read_bytes();sha=hashlib.sha256(b).hexdigest();assert sha==B[rel]['sha256'];d=H/'original_inputs'/rel;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(b);assert d.stat().st_ino!=p.stat().st_ino;pins[rel]={'sha256':sha,'bytes':len(b)}
 if rel in ['core/titanic_guardian_sources.gd','core/phase_undead_army_sources.gd','core/pool_identity.gd']:
  d=H/'gd_minimal'/rel;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(b)
for target,sha in newfiles.items():
 rel=family+'candidates/'+target if target.startswith('tools/') else target
 assert pins[rel]['sha256']==sha
pysource=(R/family/'candidates/tools/titanic_guardian_patterns.py').read_text();constants={n.targets[0].id:ast.literal_eval(n.value) for n in ast.parse(pysource).body if isinstance(n,ast.Assign)}
gdsource=(R/'core/titanic_guardian_sources.gd').read_text();gd={name:json.loads(re.search(r'^const '+name+r': (?:Dictionary|Array)=(.*)$',gdsource,re.M)[1]) for name in ['RAW','EXPECTED','PROGRAMS','IDS','RUNTIME_PATHS']}
assert json.dumps(constants['RAW'],sort_keys=True)==json.dumps(gd['RAW'],sort_keys=True)
assert json.dumps(constants['EXPECTED'],sort_keys=True)==json.dumps(gd['EXPECTED'],sort_keys=True)
for name,fn in [('RAW','raw_rows.json'),('EXPECTED','expected_compiled.json'),('PROGRAMS','programs.json')]:assert json.dumps(gd[name],sort_keys=True)==json.dumps(json.loads((R/family/fn).read_text()),sort_keys=True)
def walk(v,p=[]):
 yield p,v
 if type(v) is dict:
  for k,x in v.items():yield from walk(x,p+[k])
 if type(v) is list:
  for k,x in enumerate(v):yield from walk(x,p+[k])
cases=[]
def add(regime,identity,path,op,**kw):cases.append({'label':f'{len(cases):03d}:{regime}:{identity}:{op}:'+'.'.join(map(str,path)),'regime':regime,'identity':identity,'path':path,'op':op,**kw})
for identity in gd['IDS']:
 for regime in ['detached','coupled','companion']:
  add(regime,identity,[],'canonical')
  for path,op in [(['text'],'change_string'),(['attack'],'number_delta'),(['health'],'number_delta'),(['tier'],'delete'),(['cost'],'null_to_false'),(['tribes'],'append_item'),([],'extra_key'),([],'id_only'),(['id'],'change_string'),(['is_golden'],'toggle_bool'),(['attack'],'numeric_float'),(['tier'],'numeric_float'),(['images',0,'row'],'numeric_float'),(['attack'],'number_string'),(['attack'],'nan'),(['attack'],'pos_inf')]:add(regime,identity,path,op)
  target=identity if regime!='companion' else next(x for x in gd['IDS'] if x!=identity)
  for path,v in walk(gd['RAW'][target]):
   if type(v) is bool:
    add(regime,identity,path,'bool_to_int');add(regime,identity,path,'bool_to_float')
 for v in [None,[],0,'invalid']:add('detached',identity,[],'invalid_root',value=v);add('mapping_root',identity,[],'invalid_root',value=v)
 for op in ['extra_unrelated','swap_rows','duplicate_normal','duplicate_golden']:add('mapping_root',identity,[],op)
 for dep in gd['IDS']:add('mapping_root',identity,[dep],'delete');add('mapping_root',identity,[dep],'invalid_member')
(H/'CASES.json').write_text(json.dumps(cases,ensure_ascii=False,indent=2)+'\n');(H/'GD_CONSTANTS.json').write_text(json.dumps(gd,ensure_ascii=False,indent=2)+'\n');(H/'INPUT_PINS.json').write_text(json.dumps(pins,indent=2)+'\n')
(H/'gd_minimal/project.godot').write_text('[application]\nconfig/name="Titanic original readonly probe"\n[rendering]\nrenderer/rendering_method="gl_compatibility"\n')
report={'case_count':len(cases),'original_tool_sha256':hashlib.sha256(pysource.encode()).hexdigest(),'original_inputs':len(pins),'gd_scripts':3,'same_original_bytes_no_correction_created':True,'tool_installed':False,'max_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
(H/'PREPARATION.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
