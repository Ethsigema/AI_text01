# 泰坦守护者历史工具：局部恢复可行性与实际 GD 门控复核

## 结论

已找到可按原字节识别、由同家族历史清单固定 SHA-256 的完整工具，但原样安装仍暂缓。本轮没有生成修正版本，也没有把工具、XML 候选或旧候选写入现有 runtime。

- 目标：`tools/titanic_guardian_patterns.py`，普通/金色 ID 为 `TB_BaconShop_HERO_39_Buddy`、`TB_BaconShop_HERO_39_Buddy_G`。
- 历史原件：21,173 bytes，SHA-256 `fc3dba9438f89860267b8db034b88415ba8d78ff6f905ba556beee29db248a29`。
- 当前实际 GD：`core/titanic_guardian_sources.gd`，26,744 bytes，SHA-256 `009fde54828dc10c9aba0c20a41c532cb1886ac0e7139524d73186af5ff8a6cd`。
- 218 个主探针中，原工具接受134次，严格 GD 诊断组合接受26次，存在108次“原接受、GD 组合拒绝”。两者不是同一校验契约。
- 当前真实 RAW 两行和已存编译两行分别严格匹配 RAW、EXPECTED。没有发现这些真实记录被污染，不宣称实际游戏出错。

## 1. 历史来源与恢复资格

原件来自保存的 `research/titanic_guardian_native_recovery/candidates/tools/`，不是重新编写或最新版下载。同家族 `new_files_sha256.json` 的11份新文件 pin 全部匹配；当前 live 中10份仍匹配，工具路径本身缺失。此清单能确认历史候选字节，不能独立证明当前完整编译驱动应该使用这一版。

原 `shared_changes.patch` 的 SHA-256 为 `42d28476803178a37f53a7f341aa320b76d8e3d08b9bce3c45ef7b7544482f11`，只含19个共享文件改动，无创建本工具的 hunk。创建代码位于保存的 `build_candidates.py:31`；本轮保留而没有执行该生成器。19个共享候选文件符合各自 after pin，不据此覆盖现有源码。

历史 static review 标记 pending admission；历史 admission 曾记录 source/syntax 通过，同时明确没有实例化 Game、没有执行效果、没有玩法验收。这些历史记录与本轮实测分开保存，不能合并宣称游戏完成。

两份独立普通/金色原生 XML 的 SHA、实体ID、DBF、攻血、等级、种族、中英文卡文、关联ID与原常量吻合；倍率分别1和2，均声明单次操作。来源 URL 是旧 manifest 的记录，本轮没有访问。工具及 GD raw gate 比较内嵌常量，不在运行时读取这些 proof 文件；XML核对仅作为本地静态来源证据。

## 2. 小范围正反例与实际调用形状

只执行经检查的原工具、同家族 driver 的 `emit`、Titanic 循环及两条重排语句，共4个 AST 节点。没有导入或运行完整 driver。GD 仅加载当前3份原源码：TitanicSources、Exact、PoolIdentity。ProbeCatalog 是只提供 `get_card`、`cards`、`source_catalog` 的最小接口，不是完整 Catalog。

| 受测方式 | 主探针 | 原工具接受 | GD 诊断组合接受 | 原接受而 GD 拒绝 | 原异常 | 合成/合并后 closure 拒绝 |
|---|---:|---:|---:|---:|---:|---:|
| 独立传入 card，mapping 不变 | 70 | 60 | 8 | 52 | 0 | 48 |
| card 就是同一个 mapping 行 | 62 | 36 | 8 | 28 | 0 | 24 |
| 改配对另一行，card 仍取 mapping | 62 | 36 | 8 | 28 | 0 | 24 |
| mapping 根/键/配对边界 | 24 | 2 | 2 | 0 | 8 | 0 |

上述严格入口是调用实际 `raw_source_error` 并组合 key=id 约束的诊断，不是项目现有的某个单一入口。

### 真实 hook 形状下仍存在的差异

在98个保存的历史 driver 中，79个含 Titanic hook，全部是 `c=cards.get(identity)` 后传同一个 cards，再经 emit 输出；其余19版没有目标字串。没有发现 Titanic direct-out 变体。

原工具使用 Python 普通字典相等，因此把布尔叶值换为等值0/1或0.0/1.0时仍可能接受。实际 GD 的 Exact.same 区分布尔和数值，但允许有限等值 int/float。耦合及配对模式的56次差异调用，覆盖同一批28种唯一坏 mapping，均通过确切历史 hook 片段得到常量 EXPECTED，且实测每次 card 均是当前外部键所取的同一个对象。

28种变体中24种坏字段在 RAW+EXPECTED 合并后保留，实际 GD closure 拒绝；其余4种仅改变 supported，被 EXPECTED 覆盖恢复。因此56次调用对应48次合并后拒绝，不应写成56次均失败。原始行 raw gate 对全部28种仍拒绝。

### 仅函数接口的 detached 差异

原工具只查独立 card 的类型和id，不查其正文。52次 detached 差异说明这个函数接口的缺口，但已见真实 hook 不会以这批独立对象传参。这里的48次 detached closure 拒绝来自人为把该对象替回 mapping 后的诊断合成，不是实际 hook 输出。每条结果均明确标记此 provenance。

另有8种非法 mapping 根使原函数/局部 hook 抛出 AttributeError。这不证明完整驱动会产生这种根，也不是生产崩溃证据。

### 额外小探针

- 13个结构/closure探针：规范配对、合法 pool blocker、合法 custom-shop 配对通过；错键、重复、缺成员、错误 blocker、非法投影、星级不一致和缺 canonical 等拒绝。
- 12个效果校验探针：正常及等值有限 float 通过；布尔倍率、错误倍率、附加字段、无穷数拒绝。这里只运行校验函数，不执行游戏效果。
- 独立复核新增6组陈旧输出清除/替换、无关输出保留、结果排序测试，均符合所取历史片段。
- 输出 deepcopy 隔离、输入不变、partial 标记、default_pool=false、pool_supported=false 均保持。没有弱化校验或池限制。

## 3. 当前流程证据与剩余阻断

当前 Catalog 的 Titanic raw/merged-source 检查在 generic number normalization 之前；后面另有 source/paired closure 和 effect gate。CustomShop 通用验证不等于 Titanic 专属验证，Game 工厂还有对应 source/closure 检查。本轮只读这些调用点，没有运行它们。

20个实际 Catalog 输入已流式复核。目标只在 raw 和 compiled 各出现两行；其余18个文件无目标行。当前五份前置配置无目标ID，不能据此替代缺失的 Python 预处理源码或证明前面的所有函数都不改整个 mapping。79版 hook 之前仍有813–827个把整个 cards 作为实参的静态站点，此数不是执行次数。

当前完整 driver 仍缺失，无法仅凭某个旧候选确定当前应恢复的精确版本。四份原证据与两份合同的既有缺失边界保持；没有伪造填补。本轮核验剩余345个工具目标仍缺失，36.6.3 XML 候选也未安装。Game、完整 Catalog、宿主玩法、完整编译器和旧存档未验收。

结论是“历史原字节可定位；对齐当前严格契约的安装资格不足”，不是权限拒绝或下载失败。下一步可以在另一个独立副本研究明确标记的新修正候选；必须保留此原件，处理 bool/number、映射/card关系及非法根，逐项重验实际 GD、编译契约和依赖。未获进一步任务前不把这种修正说成原样恢复，也不替换现有树。

## 4. 复核、资源和可复查文件

- 独立复核重新计算218行、20个原输入 pin、3份 GD 源字节、20个当前数据文件和两份XML。完整记录在 `review_independent/`。
- 两轮直接 GD 报告相同。最终31文件便携副本在全新目录复跑，Python语义及 GD JSON 再次一致，不依赖原 runtime。
- 主 Python/独立审查限制128 MiB地址空间；独立审查RSS约76.4 MiB。最终便携两轮 GD RSS峰值约64.1/63.4 MiB，各低于192 MiB停止线，均在一秒内退出；设置45秒超时、2 GiB地址空间和系统可用内存检查。
- `failures=[]` 只表示显式测试断言通过，包括成功重现108次已知差异，不是“零差异”或安装通过。
- `PREPARATION.json` 记录初始17份输入，最终补入历史生成器/static review/admission三份后，`INPUT_PINS.json` 为20份。
- `REPLAY_INPUTS.json` 固定31份最小复跑输入。执行 `python3 replay_to_new.py /一个尚不存在的新目录`；需要现有 `/usr/local/bin/godot`，不会下载或安装。不要执行保存的历史 build_candidates.py 或完整 driver。
- `final_verify.py` 依赖当前本地源树和旧档，重新核验所用来源、最终报告、345缺口及6份旧档未变。它不是便携复跑入口。
- `FILES_SHA256.json` 固定白名单封包成员。包中不包含隔离 HOME/XDG、Godot缓存、凭据、聊天、旧存档或大体积全量数据。

本轮全程本地，没有联网、下载、重新触发取消操作，没有改旧备份或原树，没有发布或安装工具。
