from pathlib import Path
import ast,collections,copy,hashlib,json,math,re,resource,sys
resource.setrlimit(resource.RLIMIT_AS,(128*1024**2,128*1024**2))
resource.setrlimit(resource.RLIMIT_CPU,(30,30))
sys.dont_write_bytecode=True
D=Path(__file__).resolve().parent; H=D.parent; W=H.parent
R=W/'historical_tools_batch14_20261109T191857Z/runtime';F='research/titanic_guardian_native_recovery/'
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(65536),b''):h.update(b)
 return h.hexdigest()
def exact(a,b):
 if type(a) is not type(b):return False
 if isinstance(a,dict):return a.keys()==b.keys() and all(exact(a[k],b[k]) for k in a)
 if isinstance(a,(list,tuple)):return len(a)==len(b) and all(exact(x,y) for x,y in zip(a,b))
 return a==b or isinstance(a,float) and math.isnan(a) and math.isnan(b)
def gd_same(a,b):
 if type(a) in (int,float) and type(b) in (int,float):return a==b
 if type(a) is not type(b):return False
 if type(a) is dict:return a.keys()==b.keys() and all(gd_same(a[k],b[k]) for k in a)
 if type(a) is list:return len(a)==len(b) and all(gd_same(x,y) for x,y in zip(a,b))
 return a==b
pins=json.loads((H/'INPUT_PINS.json').read_text()); source_map=json.loads((R.parent/'SOURCE_MAP.json').read_text())
checked=[]
for rel,pin in pins.items():
 a=H/'original_inputs'/rel;b=R/rel
 assert sha(a)==sha(b)==pin['sha256']==source_map[rel]['sha256']
 assert a.stat().st_size==b.stat().st_size==pin['bytes']==source_map[rel]['bytes']
 checked.append(rel)
for p in (H/'gd_minimal/core').glob('*.gd'):assert sha(p)==sha(R/'core'/p.name)
new=json.loads((R/F/'new_files_sha256.json').read_text())
for rel,s in new.items():assert s==pins[F+'candidates/'+rel if rel.startswith('tools/') else rel]['sha256']
ns={};p=H/'original_inputs'/F/'candidates/tools/titanic_guardian_patterns.py';tree=ast.parse(p.read_text())
assert [n.module for n in tree.body if isinstance(n,ast.ImportFrom)]==['copy']
assert not any(isinstance(n,ast.Import) for n in ast.walk(tree))
exec(compile(tree,str(p),'exec'),ns)
RAW=ns['RAW']; EXPECTED=ns['EXPECTED'];IDS=ns['SOURCE_IDS']; compile_card=ns['compile_card']
gd=json.loads((H/'GD_CONSTANTS.json').read_text())
assert exact(RAW,gd['RAW']) and exact(EXPECTED,gd['EXPECTED'])
assert list(IDS)==gd['IDS']
for key,file in [('RAW','raw_rows.json'),('EXPECTED','expected_compiled.json'),('PROGRAMS','programs.json')]:assert exact(gd[key],json.loads((R/F/file).read_text()))
# Independent case construction. Only the selected original hook nodes execute.
dp=H/'original_inputs'/F/'candidates/tools/build_effect_catalog.py';dt=ast.parse(dp.read_text())
emit=next(n for n in dt.body if isinstance(n,ast.FunctionDef) and n.name=='emit')
hooks=[n for n in dt.body if isinstance(n,ast.For) and ast.unparse(n.iter)=='sorted(TITANIC_GUARDIAN_IDS)'];assert len(hooks)==1
hook=hooks[0];at=dt.body.index(hook);nodes=[emit]+dt.body[at:at+3]
assert '\n\n'.join(ast.get_source_segment(dp.read_text(),n) for n in nodes)+'\n'==(H/'DRIVER_EXACT_FRAGMENTS.py').read_text()
hook_code=compile(ast.Module(body=nodes,type_ignores=[]),'independent_exact_hook','exec')

def alter(v,c):
 v=copy.deepcopy(v);op=c['op'];path=c['path']
 if op=='canonical':return v
 if op=='invalid_root':return copy.deepcopy(c['value'])
 if op=='extra_unrelated':return dict(v,**{'not-a-source':{'id':'not-a-source'}})
 if op=='swap_rows':return {IDS[0]:v[IDS[1]],IDS[1]:v[IDS[0]]}
 if op in ('duplicate_normal','duplicate_golden'):return {k:copy.deepcopy(v[IDS[op=='duplicate_golden']]) for k in IDS}
 if op=='id_only':return {'id':v['id']}
 if op=='invalid_member':v[path[0]]=None;return v
 if path:
  parent=v
  for k in path[:-1]:parent=parent[k]
  k=path[-1];old=parent[k]
 else:parent=None;old=v
 if op=='delete':del parent[k];return v
 ops={'bool_to_int':lambda:int(old),'bool_to_float':lambda:float(old),'numeric_float':lambda:float(old),'toggle_bool':lambda:not old,'number_delta':lambda:old+1,'number_string':lambda:str(old),'change_string':lambda:old+'__changed__','null_to_false':lambda:False,'extra_key':lambda:dict(old,__extra__=True),'append_item':lambda:old+['__extra__'],'nan':lambda:float('nan'),'pos_inf':lambda:float('inf')}
 changed=ops[op]()
 if parent is None:return changed
 parent[k]=changed;return v

def raw_accept(c):return type(c) is dict and c.get('id') in IDS and gd_same(c,RAW[c['id']])
cases=json.loads((H/'CASES.json').read_text());pyr=json.loads((H/'PYTHON_REPORT.json').read_text());gr=json.loads((H/'GODOT_first.json').read_text());gr2=json.loads((H/'GODOT_repeat.json').read_text())
assert exact(gr,gr2);assert len(cases)==len(pyr['results'])==len(gr['results'])==218
counts=collections.defaultdict(collections.Counter);actual_bad_maps=set();actual_retained_bad_maps=set();outcomes=[];normalized=[]
for c,pr,g in zip(cases,pyr['results'],gr['results']):
 i=c['identity'];r=c['regime'];cards=copy.deepcopy(RAW);card=copy.deepcopy(RAW[i])
 if r=='detached':card=alter(card,c)
 if r=='coupled':cards[i]=alter(cards[i],c);card=cards[i]
 if r=='companion':other=next(k for k in IDS if k!=i);cards[other]=alter(cards[other],c);card=cards[i]
 if r=='mapping_root':cards=alter(cards,c)
 before=copy.deepcopy((card,cards));error=None
 try:out=compile_card(card,cards)
 except Exception as exc:out=None;error=type(exc).__name__
 accepted=out is not None
 assert exact(before,(card,cards))
 assert accepted==pr['original_accept']==g['original_accept'] and error==pr['original_error']
 if accepted:assert exact(out,EXPECTED[card['id']])
 strict=raw_accept(card) and type(cards) is dict and all(type(cards.get(k)) is dict and cards[k].get('id')==k and raw_accept(cards[k]) for k in IDS)
 assert strict==g['strict_ingress_accept'];assert raw_accept(card)==g['actual_supplied_card_raw_gate_accept']
 calls=[]
 def instrument(row,allrows):
  calls.append({'row_id':row.get('id') if isinstance(row,dict) else None,'loop_key':n.get('identity'),'card_is_exact_current_key_value':isinstance(allrows,dict) and row is allrows.get(n.get('identity')),'card_is_one_of_mapping_value_objects':isinstance(allrows,dict) and any(row is x for x in allrows.values())})
  return compile_card(row,allrows)
 n={'cards':cards,'out':{},'ordered_ids':['unrelated']+list(reversed(IDS)),'TITANIC_GUARDIAN_IDS':IDS,'compile_titanic_guardian':instrument,'hashlib':hashlib};he=None
 try:exec(hook_code,n)
 except Exception as exc:he=type(exc).__name__
 assert sorted(n['out'])==pr['exact_hook_accepted_ids'] and he==pr['exact_hook_error'] and exact(calls,pr['exact_hook_calls'])
 assert all(exact(v,EXPECTED[k]) for k,v in n['out'].items())
 assert exact(before,(card,cards))
 if he is None:assert n['ordered_ids']==['unrelated']+sorted(n['out'])
 z=counts[r];z['cases']+=1;z['accepts']+=accepted;z['strict_accepts']+=strict;z['differential']+=accepted and not strict;z['exceptions']+=error is not None
 if accepted:
  adjusted=copy.deepcopy(cards)
  if r=='detached':adjusted[i]=copy.deepcopy(card)
  merged={k:dict(adjusted[k],**EXPECTED[k]) for k in IDS}
  closure_ok=all(gd_same(merged[k],dict(RAW[k],**EXPECTED[k])) for k in IDS)
  assert closure_ok==(g['compiled_closure_error']=='')
  z['closure_rejects']+=not closure_ok
  if not strict and closure_ok:normalized.append(c['label'])
  if r in ('coupled','companion') and not strict:
   assert c['op'] in ('bool_to_int','bool_to_float')
   assert len(n['out'])==2 and he is None and all(x['card_is_one_of_mapping_value_objects'] for x in calls)
   sig=json.dumps(cards,sort_keys=True,ensure_ascii=False);actual_bad_maps.add(sig)
   if not closure_ok:actual_retained_bad_maps.add(sig)
 outcomes.append({'label':c['label'],'reproduced':True})
for r,z in counts.items():
 assert z['cases']==gr['counts'][r]['cases'];assert z['differential']==gr['counts'][r]['original_accept_gd_reject']
assert sum(z['strict_accepts'] for z in counts.values())==26
assert sum(z['differential'] for z in counts.values())==108
assert gr['failures']==[] and len(gr['structural_probes'])==13 and len(gr['effect_probes'])==12
assert [r['case'] for r in gr['structural_probes'] if r['accepted']]==['canonical','both_pool_blockers','valid_custom']
assert all(e['accepted']==(e['op'] in ('canonical','float_equal')) for e in gr['effect_probes'])
for f in ['GODOT_first.stderr.log','GODOT_repeat.stderr.log','GODOT_first.stdout.log','GODOT_repeat.stdout.log']:
 s=(H/f).read_text();assert 'SCRIPT ERROR' not in s and 'ERROR:' not in s
# Verify direct data source pins, stream each target row independently. No full Catalog execution.
def array_rows(path):
 dec=json.JSONDecoder();buf='';pos=0
 with path.open() as f:
  while True:
   more=f.read(65536);buf+=more
   match=re.search(r'"cards"\s*:\s*\[',buf)
   if match:pos=match.end();break
   assert more
  done=False
  while not done:
   while True:
    while pos<len(buf) and (buf[pos].isspace() or buf[pos]==','):pos+=1
    if pos<len(buf):break
    more=f.read(65536);assert more;buf=buf[pos:]+more;pos=0
   if buf[pos]==']':break
   while True:
    try:obj,end=dec.raw_decode(buf,pos);pos=end;break
    except json.JSONDecodeError:
     more=f.read(65536);assert more;buf=buf[pos:]+more;pos=0
   yield obj
   if pos>65536:buf=buf[pos:];pos=0
current=json.loads((W/'titanic_restore_contract_20261109T232532Z/CURRENT_TARGET_DATA.json').read_text()); current_verified=[];merged={}
for f in current['files']:
 p=R/f['path'].removeprefix('res://');assert sha(p)==f['sha256'] and p.stat().st_size==f['bytes']
 hits=[];n=0
 for idx,row in enumerate(array_rows(p)):
  n+=1;i=row.get('id')
  if i in IDS:
   hits.append({'index':idx,'id':i,'raw':exact(row,RAW[i]),'expected':exact(row,EXPECTED[i])});merged.setdefault(i,{}).update(row)
 assert n==f['rows'] and len(hits)==len(f['target_hits'])
 for a,b in zip(hits,f['target_hits']):assert a['index']==b['index'] and a['id']==b['id'] and a['raw']==b['type_strict_equal_RAW'] and a['expected']==b['type_strict_equal_EXPECTED']
 current_verified.append({'path':f['path'],'rows':n,'hits':hits})
assert all(exact(merged[i],dict(RAW[i],**EXPECTED[i])) for i in IDS)
# Additional focused checks missing from the original empty-out harness.
stale_checks=[]
for scenario in ['canonical','bool_supported','bool_is_golden','text_changed','missing_normal','missing_golden']:
 rows=copy.deepcopy(RAW)
 if scenario=='bool_supported':rows[IDS[0]]['supported']=0
 elif scenario=='bool_is_golden':rows[IDS[0]]['is_golden']=0
 elif scenario=='text_changed':rows[IDS[0]]['text']+='__changed__'
 elif scenario=='missing_normal':del rows[IDS[0]]
 elif scenario=='missing_golden':del rows[IDS[1]]
 sentinel={'unrelated':True};out={i:{'stale':True} for i in IDS};out['unrelated']=sentinel
 frame={'cards':rows,'out':out,'ordered_ids':[IDS[1],'unrelated',IDS[0]],'TITANIC_GUARDIAN_IDS':IDS,'compile_titanic_guardian':compile_card,'hashlib':hashlib}
 exec(hook_code,frame)
 expected_accept=scenario in ['canonical','bool_supported','bool_is_golden']
 assert out['unrelated'] is sentinel
 assert set(out)==set(['unrelated']+list(IDS)) if expected_accept else set(out)=={'unrelated'}
 assert frame['ordered_ids']==['unrelated']+(sorted(IDS) if expected_accept else [])
 if expected_accept:assert all(exact(out[i],EXPECTED[i]) for i in IDS)
 stale_checks.append({'scenario':scenario,'stale_source_outputs_removed_or_replaced':True,'unrelated_output_preserved':True,'order_correct':True})
# Final labeled harness and portable replay have the same logical results.
for result in gr['results']:
 assert result['compiled_input_projection']==('hypothetical_detached_card_replacement_not_actual_hook' if result['regime']=='detached' else 'coupled_mapping_plus_exact_constant_outputs')
replay=W/'titanic_guardian_portable_replay_20261109T233500Z'
assert json.loads((replay/'GODOT_first.json').read_text())==gr
assert json.loads((replay/'GODOT_repeat.json').read_text())==gr
assert json.loads((replay/'REPLAY_RESULT.json').read_text())['status']=='PASS_REPRODUCTION_OF_KNOWN_DIFFERENCES_NOT_RESTORATION_APPROVAL'
# Independent local native XML checks; original URL is attribution, not a fetch.
import xml.etree.ElementTree as ET
manifest=json.loads((R/F/'native_source_manifest.json').read_text());quantities=json.loads((R/F/'native_quantities.json').read_text());native=[]
for idx,i in enumerate(IDS):
 p=R/F/'native'/f'{i}.xml';root=ET.fromstring(p.read_bytes());tags={x.attrib['name']:x for x in root.findall('Tag')};q=quantities[i]
 assert root.attrib['CardID']==i and root.attrib['ID']==RAW[i]['dbf_id']==q['dbf_id']
 assert sha(p)==q['native_sha256']==manifest['entities'][i]['native_sha256']
 for tag,key in [('ATK','attack'),('HEALTH','health'),('TECH_LEVEL','tier')]:assert int(tags[tag].attrib['value'])==RAW[i][key]==q[key]
 assert int(tags['CARDRACE'].attrib['value'])==18==q['race'] and RAW[i]['tribes']==['元素']
 assert tags['CARDTEXT'].findtext('zhCN')==RAW[i]['text']==q['zhCN']
 assert tags['CARDTEXT'].findtext('enUS')==q['enUS']==manifest['entities'][i]['enUS']
 assert tags['CARDNAME'].findtext('zhCN')==RAW[i]['name']==q['name_zhCN']
 assert q['health_multiplier']==idx+1==gd['PROGRAMS'][i][0]['health_multiplier'] and q['operations']==1
 if idx:assert 'twice that amount' in q['enUS']
 for k,v in q['native_links'].items():assert int(tags[k].attrib['value'])==v
 native.append({'id':i,'native_fragment_verified':True,'multiplier':idx+1,'operations':1})
report={'review_scope':'Independent Python reproduction and read-only static/data audit; original tool plus exact selected hook nodes executed, no full compiler/Game/Godot rerun','address_space_limit_bytes':128*1024**2,'original_inputs_pins_verified':len(checked),'minimal_gd_byte_identical_scripts':3,'cases_reproduced':len(outcomes),'counts':{k:dict(v) for k,v in counts.items()},'coupled_companion_differential_test_invocations':56,'unique_mutated_mappings_in_those_invocations':len(actual_bad_maps),'unique_mutated_mappings_retained_after_overlay':len(actual_retained_bad_maps),'normalized_after_overlay_labels':normalized,'godot_two_stored_reports_match':True,'godot_stored_log_error_markers':False,'godot_reexecuted':False,'full_catalog_or_game_executed':False,'current_files_verified':current_verified,'source_and_compiled_rows_match_constants_type_strict':True,'cases':outcomes,'max_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
report.update({'stale_output_and_order_checks':stale_checks,'detached_provenance_labels_checked':True,'final_harness_portable_replay_results_match':True,'native_fragments_verified':native,'reviewed_input_sha256':{f:sha(H/f) for f in ['INPUT_PINS.json','CASES.json','PYTHON_REPORT.json','GODOT_first.json','GODOT_repeat.json','gd_minimal/gate.gd','test_original.py','REPLAY_INPUTS.json']}})
(D/'REVIEW.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in ('cases','current_files_verified','normalized_after_overlay_labels')},ensure_ascii=False,indent=2))
