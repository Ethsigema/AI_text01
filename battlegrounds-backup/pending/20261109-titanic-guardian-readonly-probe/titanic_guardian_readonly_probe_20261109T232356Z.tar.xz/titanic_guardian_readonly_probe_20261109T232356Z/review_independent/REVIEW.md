# Titanic Guardian 原历史工具：独立只读复核

结论：证据支持“原工具在受测接口中存在 Python Bool/数值相等及 detached card 正文不校验的边界差异”；不支持“当前真实数据已坏、实际游戏已出错或原工具已可安全恢复”。在明确下面的测试边界后，主要计数和结论成立。没有修改原工具、原 GD、历史 runtime 或旧封包。

## 独立完成的验证

- 在 128 MiB 地址空间与 30 秒 CPU 上限下执行独立脚本，峰值 RSS 78,184 KiB；执行确切原工具和原 driver 的 emit、Titanic for、reorder 四个 AST 节点，不执行完整 driver。
- 20 份 INPUT_PINS 的 SHA-256/长度与保留 runtime 和 SOURCE_MAP 相符；3 个隔离 GD 脚本与真实源字节相同。原工具 SHA-256 为 fc3dba9438f89860267b8db034b88415ba8d78ff6f905ba556beee29db248a29。
- 独立复现全部 218 行的接受/拒绝、异常、hook 输出、实际当前 key 对应对象、输入不变和排序结果。输出与 EXPECTED 严格比较一致。
- 对 GD 保存结果的 raw gate/closure 逐行采用直接阅读真实 GD 后写成的独立 Python 等价模型核对。该模型仅是交叉验证，不冒充另一次 Godot 运行。
- 保存的两轮 Godot JSON 一致，无 stderr/stdout 错误标记；最终带 provenance 的结果也与 portable replay 的实际两轮结果一致。本复核未重跑 Godot。
- 流式读取 Catalog 加载序列的 20 个真实数据文件，重新验证字节 pins、行数、4 个目标出现位置及严格类型相等。RAW 两行匹配 RAW，compiled 两行匹配 EXPECTED，直接合并后也完全一致。
- 独立核对两份原 XML 的实体、DBF、攻血、等级、族、中英文、链接与单次 1/2 倍声明。这里只验证本地历史原材料，不重新访问来源 URL，也不把来源记录当成运行时读取 proof 文件的机制。
- 额外 6 组陈旧 out 测试验证 hook 删除/替换旧目标结果、保留无关结果及 reorder，全部通过。

## 计数

| regime | case | 原工具接受 | 组合严格门接受 | 原接受而组合门拒绝 | 原异常 | 合成/合并后 closure 拒绝 |
|---|---:|---:|---:|---:|---:|---:|
| detached | 70 | 60 | 8 | 52 | 0 | 48 |
| coupled | 62 | 36 | 8 | 28 | 0 | 24 |
| companion | 62 | 36 | 8 | 28 | 0 | 24 |
| mapping_root | 24 | 2 | 2 | 0 | 8 | 0 |
| 合计 | 218 | 134 | 26 | 108 | 8 | 96 |

13 个结构探针中 canonical、both_pool_blockers、valid_custom 接受，其余拒绝。12 个效果探针中 canonical 和等值 float 接受，其余拒绝。不要将这些探针数与 218 主 case 混为同一分母。

## 必须保留的含义和边界

1. 108 是诊断组合差异数。strict_ingress 是实际 raw_source_error 的逐行调用加 key=id 约束，不是当前生产代码的一个单一入口。
2. detached 的 52 次差异仅证明独立函数接口忽略所传 card 正文。真实 hook 始终以 cards.get(identity) 传参；对于 detached 变更，mapping 未变，hook 采用正常 mapping 行。detached 的 compiled_closure_error 是人为替换 mapping 后的反例，不能归于真实 hook 输出。最终每行已标记 hypothetical_detached_card_replacement_not_actual_hook。
3. coupled28 + companion28 是 56 次受测调用，覆盖同一批 28 种 Bool→0/1 或 0.0/1.0 的唯一 mapping 变体，不是 56 种独立坏数据路径。真实精确 hook 片段对这些变体均产出正常常量结果。
4. 这 28 种 mapping 中，24 种坏字段在 RAW+EXPECTED 合并后保留并使 closure 拒绝；其余 4 种仅改变 supported，合并时被 EXPECTED 覆盖。对应 56 次调用中有 48 次合并后 closure 拒绝，另 8 次被覆盖恢复。不能把全部 56 次都说成后续 closure 失败。
5. 8 个非法 mapping 根在独立工具及局部 hook 都产生 AttributeError。这是无效接口根的边界结果，不等于完整 driver 会实际产生该输入或生产流程会崩溃。
6. ProbeCatalog 只实现 get_card/cards/source_catalog；真正运行的是原 raw/source/closure/effect 方法及 3 个真实 preload 脚本。没有执行完整 Catalog、Game、玩法、存档或完整编译器。
7. 原 harness 的 failures=[] 只代表其显式断言全部通过，不意味着全输入空间或玩法验收完成。原空 out 无法验证清除历史结果；本复核已用 6 组独立补充测试覆盖这一局部缺口。主计数已独立重新断言。
8. 当前源数据、compiled 数据和原 source constants 正常且匹配。该测试证明的是潜在接口/类型安全边界，不能表述成已发生的游戏错误。

## 文件

- REVIEW.json：逐 case 复现标记、计数、原材料与数据核对、独立补充测试、审阅时输入哈希。
- review.py：本目录独立复核脚本。仅写本 review 目录，不更改被审阅证据。

原证据及 portable replay 的后续内容若改变，应按 REVIEW.json 的 reviewed_input_sha256 确认审阅是否仍对应同一版本。

## 最终冻结后的复跑核对

冻结后仅复查最终 REPLAY_INPUTS.json 与全新 titanic_guardian_portable_replay_20261109T234300Z 的实际复跑产物，没有再次执行测试。31 个 manifest 条目的 SHA-256 与长度同时匹配证据包及全新复跑目录；此前受审输入除 REPLAY_INPUTS.json 的哈希刷新外没有变化。

- 两轮新 Godot JSON 与证据包受审 JSON 字节相同，两轮均 exit 0、无停止条件、无错误日志。
- 新 Python 报告除 max_rss_kib 外语义完全相同；ORIGINAL_OUTPUTS.json 与 DRIVER_EXACT_FRAGMENTS.py 字节相同。
- 最终结果为 PASS_REPRODUCTION_OF_KNOWN_DIFFERENCES_NOT_RESTORATION_APPROVAL，218 主 case、56 次 coupled/companion 差异调用、28 种唯一 Bool 映射、52 次 detached 差异与 8 次异常保持不变。
- 包内最终结果副本实际文件名为 FINAL_REPLAY_REPLAY_RESULT.json；运行记录为 FINAL_REPLAY_GODOT_RUNS.json。它们与新复跑目录原产物字节相同。REVIEW.json 已补记这两份文件、最终日志与最终 REPLAY_INPUTS.json 的审阅哈希。
