from pathlib import Path
from copy import deepcopy
import ast,hashlib,json,resource,sys,types
resource.setrlimit(resource.RLIMIT_AS,(128*1024**2,128*1024**2));sys.dont_write_bytecode=True
H=Path(__file__).resolve().parent;F='research/titanic_guardian_native_recovery/'
source=(H/'original_inputs'/F/'candidates/tools/titanic_guardian_patterns.py').read_text();tree=ast.parse(source)
for n in tree.body:
 if isinstance(n,ast.Assign):ast.literal_eval(n.value)
 elif isinstance(n,ast.ImportFrom):assert n.module=='copy' and [v.name for v in n.names]==['deepcopy']
 elif isinstance(n,ast.Expr):assert isinstance(n.value,ast.Constant) and isinstance(n.value.value,str)
 else:assert isinstance(n,ast.FunctionDef) and n.name=='compile_card'
module=types.ModuleType('historical_titanic');exec(compile(tree,'historical_titanic','exec'),module.__dict__)
IDS=module.SOURCE_IDS

def frozen(v):return json.dumps(v,ensure_ascii=False,sort_keys=True)
def mutate(value,case):
 op=case['op'];path=case['path']
 if op=='canonical':return value
 if op=='swap_rows':return {IDS[0]:value[IDS[1]],IDS[1]:value[IDS[0]]}
 if op=='duplicate_normal':return {IDS[0]:value[IDS[0]],IDS[1]:deepcopy(value[IDS[0]])}
 if op=='duplicate_golden':return {IDS[0]:value[IDS[1]],IDS[1]:deepcopy(value[IDS[1]])}
 if op=='invalid_root':return deepcopy(case['value'])
 if op=='id_only':return {'id':value['id']}
 if op=='extra_unrelated':value['not-a-source']={'id':'not-a-source'};return value
 if op=='invalid_member':value[path[0]]=None;return value
 parent=value
 for part in path[:-1]:parent=parent[part]
 old_value=parent[path[-1]] if path else value
 if op=='delete':del parent[path[-1]];return value
 if op=='bool_to_int':updated=int(old_value)
 elif op=='bool_to_float':updated=float(old_value)
 elif op=='toggle_bool':updated=not old_value
 elif op=='numeric_float':updated=float(old_value)
 elif op=='numeric_int':updated=int(old_value)
 elif op=='number_delta':updated=old_value+1
 elif op=='number_string':updated=str(old_value)
 elif op=='number_bool':updated=bool(old_value)
 elif op=='change_string':updated=old_value+'__changed__'
 elif op=='null_to_false':updated=False
 elif op=='extra_key':updated=deepcopy(old_value);updated['__extra__']=True
 elif op=='append_item':updated=deepcopy(old_value);updated.append('__extra__')
 elif op=='reverse_list':updated=list(reversed(old_value))
 elif op=='nan':updated=float('nan')
 elif op=='pos_inf':updated=float('inf')
 elif op=='neg_inf':updated=float('-inf')
 else:raise AssertionError(op)
 if path:parent[path[-1]]=updated
 else:value=updated
 return value
driver_source=(H/'original_inputs'/F/'candidates/tools/build_effect_catalog.py').read_text();driver=ast.parse(driver_source)
emit=next(n for n in driver.body if isinstance(n,ast.FunctionDef) and n.name=='emit')
hook=next(n for n in driver.body if isinstance(n,ast.For) and isinstance(n.iter,ast.Call) and isinstance(n.iter.func,ast.Name) and n.iter.func.id=='sorted' and isinstance(n.iter.args[0],ast.Name) and n.iter.args[0].id=='TITANIC_GUARDIAN_IDS')
pos=driver.body.index(hook);reorder=driver.body[pos+1:pos+3];assert all('TITANIC_GUARDIAN_IDS' in ast.unparse(n) for n in reorder)
fragments=[emit,hook]+reorder
(H/'DRIVER_EXACT_FRAGMENTS.py').write_text('\n\n'.join(ast.get_source_segment(driver_source,n) for n in fragments)+'\n')
code=compile(ast.Module(body=fragments,type_ignores=[]),'reviewed_exact_titanic_hook','exec')
results=[]
for case in json.loads((H/'CASES.json').read_text()):
 identity=case['identity'];cards=deepcopy(module.RAW);card=deepcopy(module.RAW[identity]);regime=case['regime']
 if regime=='detached':card=mutate(card,case)
 elif regime=='coupled':cards[identity]=mutate(cards[identity],case);card=cards[identity]
 elif regime=='companion':
  target=next(i for i in IDS if i!=identity);cards[target]=mutate(cards[target],case);card=cards[identity]
 elif regime=='mapping_root':cards=mutate(cards,case)
 before=frozen([card,cards]);error=None
 try:output=module.compile_card(card,cards)
 except Exception as e:output=None;error=type(e).__name__
 assert frozen([card,cards])==before
 if output is not None:assert frozen(output)==frozen(module.EXPECTED[card['id']])
 calls=[]
 def instrument(c,all_cards):
  calls.append({'row_id':c.get('id') if isinstance(c,dict) else None,'loop_key':ns.get('identity'),'card_is_exact_current_key_value':isinstance(all_cards,dict) and c is all_cards.get(ns.get('identity')),'card_is_one_of_mapping_value_objects':isinstance(all_cards,dict) and any(c is value for value in all_cards.values())})
  return module.compile_card(c,all_cards)
 ns={'cards':cards,'out':{},'ordered_ids':['unrelated']+list(reversed(IDS)),'TITANIC_GUARDIAN_IDS':IDS,'compile_titanic_guardian':instrument,'hashlib':hashlib}
 hook_error=None
 try:exec(code,ns)
 except Exception as e:hook_error=type(e).__name__
 assert frozen([card,cards])==before
 if hook_error is None:
  for ident,out in ns['out'].items():assert frozen(out)==frozen(module.EXPECTED[ident])
 results.append({'label':case['label'],'regime':regime,'op':case['op'],'original_accept':output is not None,'original_error':error,'input_unchanged':True,'exact_hook_accepted_ids':sorted(ns['out']),'exact_hook_error':hook_error,'exact_hook_calls':calls,'all_emitted_outputs_exact':hook_error is None})
canonical={i:module.compile_card(deepcopy(module.RAW[i]),deepcopy(module.RAW)) for i in IDS}
for identity in IDS:
 a=module.compile_card(deepcopy(module.RAW[identity]),deepcopy(module.RAW));b=module.compile_card(deepcopy(module.RAW[identity]),deepcopy(module.RAW));assert a is not b and a['effects'] is not b['effects'];a['effects'][0]['test_extra']=True;assert 'test_extra' not in b['effects'][0] and 'test_extra' not in module.EXPECTED[identity]['effects'][0]
 assert b['default_pool'] is False and b['pool_supported'] is False and b['implementation_status']=='partial_implementation_supported_pending_unified_validation'
(H/'ORIGINAL_OUTPUTS.json').write_text(json.dumps(canonical,ensure_ascii=False,indent=2)+'\n')
report={'case_count':len(results),'original_sha256':hashlib.sha256(source.encode()).hexdigest(),'driver_sha256':hashlib.sha256(driver_source.encode()).hexdigest(),'executed_driver_nodes':[{'kind':type(n).__name__,'first':n.lineno,'last':n.end_lineno} for n in fragments],'full_driver_executed':False,'input_unchanged_all_cases':True,'deepcopy_and_partial_pool_flags_preserved':True,'results':results,'by_regime':{},'max_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
for regime in sorted({r['regime'] for r in results}):
 rows=[r for r in results if r['regime']==regime];report['by_regime'][regime]={'cases':len(rows),'accepts':sum(r['original_accept'] for r in rows),'exceptions':sum(r['original_error'] is not None for r in rows),'hook_exceptions':sum(r['exact_hook_error'] is not None for r in rows)}
(H/'PYTHON_REPORT.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k!='results'},indent=2))
