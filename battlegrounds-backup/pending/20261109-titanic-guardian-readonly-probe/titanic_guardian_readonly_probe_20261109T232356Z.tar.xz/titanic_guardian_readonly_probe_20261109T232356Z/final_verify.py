"""Read-only recheck of named inputs and new diagnostic evidence; no historical execution."""
from pathlib import Path
import hashlib,json,resource
resource.setrlimit(resource.RLIMIT_AS,(128*1024**2,128*1024**2))
H=Path(__file__).resolve().parent;W=H.parent;R=W/'historical_tools_batch14_20261109T191857Z/runtime'
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def read(p):return json.loads(p.read_text())
pins=read(H/'INPUT_PINS.json');baseline=read(R.parent/'SOURCE_MAP.json')
for rel,pin in pins.items():
 assert pin==baseline[rel]
 for p in [R/rel,H/'original_inputs'/rel]:assert p.stat().st_size==pin['bytes'] and sha(p)==pin['sha256'],str(p)
 if rel.startswith('core/'):assert sha(H/'gd_minimal'/rel)==pin['sha256']
for item in read(H/'static_contract/FINAL_RECHECK.json')['checks']:assert sha(W/item['path'])==item['expected_sha256'],item['path']
consistency=read(H/'static_contract/SOURCE_CONSISTENCY.json')
for group in consistency['new_file_checks']:
 for item in group['locations']:
  p=W/item['path']
  if item.get('missing'):assert not p.exists()
  else:assert sha(p)==group['expected_sha256']
assert len(consistency['new_file_checks'])==11 and not consistency['patch_creates_tool']
py=read(H/'PYTHON_REPORT.json');gd=read(H/'GODOT_first.json');cases=read(H/'CASES.json');review=read(H/'review_independent/REVIEW.json')
assert gd==read(H/'GODOT_repeat.json') and not gd['failures']
assert py['case_count']==gd['case_count']==len(cases)==218
assert all(x['input_unchanged'] for x in py['results'])
assert sum(x['original_accept_gd_reject'] for x in gd['counts'].values())==108
assert sum(x['strict_ingress_accept'] for x in gd['counts'].values())==26
assert sum(x['original_exception'] for x in gd['counts'].values())==8
assert len(gd['structural_probes'])==13 and len(gd['effect_probes'])==12
ids=['TB_BaconShop_HERO_39_Buddy','TB_BaconShop_HERO_39_Buddy_G'];unique=set();kept=set();calls=0;closure_calls=0
for c,p,g in zip(cases,py['results'],gd['results']):
 assert c['label']==p['label']==g['label']
 if c['regime']=='detached':assert g['compiled_input_projection']=='hypothetical_detached_card_replacement_not_actual_hook'
 if c['regime'] not in ['coupled','companion'] or not g['original_accept'] or g['strict_ingress_accept']:continue
 assert c['op'] in ['bool_to_int','bool_to_float']
 assert p['exact_hook_error'] is None and p['exact_hook_accepted_ids']==ids
 assert len(p['exact_hook_calls'])==2 and all(v['card_is_exact_current_key_value'] for v in p['exact_hook_calls'])
 affected=c['identity'] if c['regime']=='coupled' else next(i for i in ids if i!=c['identity'])
 key=(affected,tuple(c['path']),c['op']);unique.add(key);calls+=1
 if g['compiled_closure_error']:kept.add(key);closure_calls+=1
assert (calls,len(unique),len(kept),closure_calls)==(56,28,24,48)
assert review['cases_reproduced']==218 and len(review['stale_output_and_order_checks'])==6
for rel,digest in review['reviewed_input_sha256'].items():assert sha(H/rel)==digest,rel
for rel,pin in read(H/'REPLAY_INPUTS.json').items():assert sha(H/rel)==pin['sha256'] and (H/rel).stat().st_size==pin['bytes']
replay=read(H/'FINAL_REPLAY_REPLAY_RESULT.json');D=Path(replay['destination'])
assert not replay['original_source_tree_needed'] and replay['copied_files']==31
assert sha(D/'GODOT_first.json')==sha(H/'GODOT_first.json')
a=read(D/'PYTHON_REPORT.json');b=read(H/'PYTHON_REPORT.json');a.pop('max_rss_kib');b.pop('max_rss_kib');assert a==b
remaining=read(W/'historical_tools_batch15_20261109T195018Z/REMAINING_SCOPE.json')['remaining_targets'];assert len(remaining)==345 and all(not (R/n).exists() for n in remaining)
assert not (R/'evidence/portable_legacy/CardDefs.Bacon_latest.xml').exists()
old_packs={
'remaining_tools_readonly_audit_20261109T215306Z.tar.xz':'9eb4be705ee386167956350de3212845a70b664148f8dddeb3aed540da5c12ba',
'imperial_defender_candidate_review_20261109T220940Z.tar.xz':'19750c8aa7ad3117befab977d8dd338fbb934d5ed5c958cf373a52e71e54bde0',
'imperial_identity_callchain_audit_20261109T222624Z.tar.xz':'f77e2a104017e743ee7c529feeef9bd4137367cacfcee65e2c34252139e9f846',
'old_murkeye_candidate_review_20261109T224622Z.tar.xz':'d88441dae609ab923b743b15fc4d32f37b25996012b7217888e5a99c4babb9ef',
'compiler_pin_contract_audit_20261109T230342Z.tar.xz':'c92e371e0dbb447093d9348f558dc7bfd2b75056eba36a38e99d3a738901be87',
'historical_tools_batch16_dependency_audit_20261109/historical_tools_batch16_xml_original_candidate_20261109.tar.xz':'3d37a9d1a0ee2d61939e88f8ced995622ca22fd84ba7f9dabe8c4f2df6bafa7d'}
for rel,digest in old_packs.items():assert sha(W/rel)==digest,rel
result={'status':'verified_known_difference_evidence_not_installation_acceptance','original_input_files_unchanged':len(pins),'minimal_GD_original_scripts_unchanged':3,'historical_new_file_pins_verified':11,'current_source_data_checks_unchanged':len(read(H/'static_contract/FINAL_RECHECK.json')['checks']),'main_cases':218,'strict_positive_cases':26,'original_accept_GD_diagnostic_reject':108,'coupled_and_companion_discrepant_calls':calls,'unique_bool_alias_mappings':len(unique),'unique_bad_after_overlay':len(kept),'coupled_and_companion_closure_reject_calls':closure_calls,'detached_discrepant_interface_calls':52,'invalid_mapping_exceptions':8,'separate_structural_probes':13,'separate_effect_probes':12,'independent_stale_output_probes':6,'portable_replay_files':31,'replay_same_semantics':True,'remaining_missing_targets':len(remaining),'XML_candidate_not_installed':True,'old_archives_unchanged':old_packs,'new_correction_created':False,'tool_installed':False,'full_compiler_Catalog_Game_host_gameplay_or_saves_run':False,'max_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
(H/'FINAL_VERIFICATION.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps(result,ensure_ascii=False,indent=2))
