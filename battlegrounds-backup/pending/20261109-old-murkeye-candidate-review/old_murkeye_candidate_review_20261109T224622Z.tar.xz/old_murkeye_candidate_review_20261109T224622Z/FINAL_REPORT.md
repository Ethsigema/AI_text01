# 老瞎眼工具：有限数值等价新修正候选

## 结论

已得到一份范围明确、可独立重放的新修正候选。当前有限 JSON 来源域内，候选与实际 GD 数值比较、最终来源校验及 BoardAura 配对校验均通过本轮正反例。历史编译适配器的局部契约也已闭合。它不是历史原样恢复，不是已证明的最新版，没有安装到现有树；完整当前编译器、Catalog 启动、Game、旧存档仍未验收。345 条原工具引用缺口仍为 345。

目标：tools/old_murkeye_aura_patterns.py。

- 历史候选整本 SHA256：7c780b25e3a001d4b961b0c3809170097b952beeb84cf7a5d1cb19a8759588e0。
- 新候选 SHA256：3d376c2af3ef5f13cf8f541199b0b2ac943f84a42715d06fc595132976c0e097，8,222 bytes。
- 新修正补丁 SHA256：a2c2dc1a5506af09b69604ebe9ebafc3c7cb3ccb96c00d1a6ec379d8a4f51009。
- 当前 GD 来源 SHA256：a6a5e40f89f1c91999a7e0b81091e8ea541a2100234cd8f3d831caa9b40d203b。

## 改动及来源

只修改 same()，新增标准库 math.isfinite 导入。相等的有限 int/float 可等价，bool 仍与数值区分，NaN/±INF 拒绝；所有其他函数、SOURCE_IDS、EXPECTED、PROOF_SHA256 和来源文件保持不变。候选读取的两张固定 CANONICAL 行共有 57 个数值叶子，均为整数，范围 2–225000；不声称适用于任意精度整数、任意自定义 Python 对象或所有跨语言数值。

保留历史 manifest、完整创建补丁、历史整本及八份原始 proof 的独立普通副本。历史创建补丁可精确还原整本；新修正补丁正向生成新候选、反向还原历史字节。八份 proof 的当前 hash 均与 Python/GD pin 一致。没有改来源以迎合测试，也未降低 bool、完整行、双源、身份、proof 或配对要求。

历史 manifest 本身标记 candidate_only_no_execution，不能将其 pin 称为当前已发布版本授权。

## 真实阶段及局部编译契约

普通 BG_EX1_062 的 RAW 已等于 CANONICAL。金色 TB_BaconUps_036 的 RAW 攻血为待核实 null；现有 catalog_value_overrides 使用独立金色证据给出 4/8、更新两个 field_status 并加入 value_override_verification，完整结果恰等于 CANONICAL，不是按普通值推导。

Python compile_card 要求两张完整 CANONICAL 行，返回七个编译元数据字段，而不是完整 EXPECTED。历史驱动的 emit 再补 id、supported=true 和 text SHA256，完整输出才等于当前 EXPECTED/catalog overlay。

已精确提取并单独执行已审过的历史 AST 节点：value override 542–549、emit 556、老瞎眼 hook 4157–4163、重排 4164–4165。源驱动 pin 为 e30078a81ad68c5201c7097aeecd80072d479a02854b276aa27a4f8c8de8c5cc。只执行这些节点，没有运行整份驱动。七种夹具包括实际 RAW→override、CANONICAL、全数值转等值 float、bool 替代、非有限值、错配键及缺少配对；前两者旧/新均精确输出，等值 float 仅新候选输出，四类坏结构均拒绝，输入及排序契约保持。

当前 GD 没有 OldMurkEye.apply_overlay 或独立 closure_error。真实路径是 RAW 校验 → 编译 overlay merge → 通用数值 override → source_error → BoardAura.source_closure_error；effect_error 另经 BoardAura 路由。CANONICAL 是固定期望基线，不是转换入口。

## 分层正反例结果

主语料共 4,903 项，不应全部称为编译测试：

- 2,468 项 CANONICAL 编译入口测试：新候选接收 234 项、拒绝 2,234 项；较历史候选多接收 114 个等值 float 情形，没有新增拒绝。GD 侧使用实际 Source.same、CANONICAL 常量和 proof_error 组合成对应谓词；此谓词不是项目中已有的独立入口。
- 1,066 项 RAW 检查：实际 raw_source_error 接收 90 项、拒绝 976 项。
- 1,369 项最终行检查：实际 source_error 接收 133 项、拒绝 1,236 项，包括只允许金色精确 pool_blocker 的阶段边界。RAW/最终行 Python 对照是 same 模型，不是调用 compile_card。
- 三层候选/实际 GD 对照在本语料中无差异。114 个编译准入变化全部来自等值 numeric_float，bool、非等值数值、数值字符串、NaN/±INF、删字段、多字段、顺序变更、错误类型等均按固定来源拒绝。
- 234 组接收后的 normal/golden 复合输出均通过实际 Source.source_error 和 BoardAura.source_closure_error。每次使用实际 Python emit 输出，不以手写替身替代 GD 校验。
- 8 个额外配对结构探针：合法 map 接收；交换两行、双普通、双金色、缺少普通、缺少金色、tier 不一致、supported 数值替代均拒绝。与皇家守护者不同，当前 BoardAura._definition_error 明确检查请求 identity 与行内 id/card_code 一致。
- 12 个实际效果路由探针：普通/金色各自的原效果和等值 float 接收，错误量、bool、INF、错误 source_id 拒绝。Source 和 Aura 两端分别断言，不用合取掩盖单端误收。
- Python 对八份 proof 分别做缺失/字节篡改，共 16 种坏目录，两张来源均拒绝。GD 对八份 proof 逐一改测试副本字节，proof/raw/final/closure 四层均拒绝，随后恢复并核对原 pin。未改历史原件。
- 输出精确性、输入不变性、深复制隔离、partial 状态及 default_pool=false/pool_supported=false 均保留。

实际 Godot 4.6.3 只载入 10 份完整原字节 GD，静态预载闭包 259,248 bytes，不含 Game/Combat/Catalog。最后两轮报告完全一致，无 SCRIPT ERROR/ERROR。50 个白名单文件在全新目录再次重放，完全不需要原源码树；报告与原测试逐字节一致。最终重放峰值 98,868 KiB；Godot 进程限制地址空间 2 GiB、RSS 192 MiB、45 秒超时，并检查系统剩余内存。Python/AST/打包流程保持低资源限制。

## 独立复核与夹具修正

独立审查未发现候选阻断缺陷，另完成 228 个相邻浮点拒绝、28 个标量对称检查；这些补测仅为 Python 侧，不冒充 GD 全数值等价证明。

首轮 GD 夹具合并 EXPECTED 时共享了 const 的嵌套只读对象，导致 42 个负例变异报错。已保留失败报告和日志，改为深复制 EXPECTED 后才测试，并在最终重复及可移植重放中通过。此为夹具修正，新候选字节未变。Python 所有阶段输入不变性断言和效果两端单独断言也已加固并重放。见 HARNESS_CORRECTION.json、REVIEW_RESOLUTIONS.json；初始失败不计作通过证据。

## 仍暂缓的范围

- 98 个历史驱动版本、179 个留存文件都核对了 hash；87 版本/163 份含同一老瞎眼 hook/emit 形式，均按行内 id 建表且先作 value override。但当前 tools/build_effect_catalog.py 仍缺失，不能指定任一历史版为当前权威整本。
- 所选历史驱动在此 hook 前有 428 个接收 cards 的静态调用位置；313 个对应导入模块在当前树缺失，含 recruit_quest_identity、hero_value_overrides。此计数不是实际执行次数，也不是全项目依赖总数。现有 final_source_overrides 的固定目标不含这两张来源。
- 缺失全链不阻止本工具局部适配契约验证，但未证明任意先行别名变更、全编译输出及全部调用域。完整 Catalog、Game、玩法/光环生命周期、旧存档和统一验收均未运行。
- RUNTIME_PATHS 含缺失目标工具，恢复/安装会影响 Catalog 指纹；本轮没有把局部成功当成旧存档兼容性批准。
- XML 36.6.3 候选未安装，四份原核验证据及两个 SOURCE_CONTRACT 的先前缺失边界未改变。本轮没有重启或访问取消的网络操作。

安全下一步：将本包留作可复现待审的新修正候选；取得与当前 core/data 同一权威快照的驱动及必要前置来源后，再单独评估整链与安装。不要弱化现有校验或用猜测版本填补缺口。

## 完整性与导航

末尾复核 23 份完整输入、20 份实际 Catalog 数据文件、关键当前源码及三份此前封包 hash 均未变。未声称重新全树验收。没有网络、凭据/缓存/私聊采集或旧备份修改。

- candidate/：新候选及精确修正补丁。
- original_inputs/：历史整本、创建补丁、manifest、来源及选定完整 GD/驱动。
- FINAL_VERIFICATION.json、INPUT_PINS.json：最终检查与输入哈希。
- PYTHON_REPORT.json、GODOT_first.json、GODOT_repeat.json：分层结果。
- DRIVER_SELECTED_EXACT.py、DRIVER_FRAGMENT_REPORT.json：精确 AST 契约测试。
- callchain_audit/：当前 Catalog 顺序、20 输入、98 版本/179 文件静态证据。
- independent_review/、REVIEW_RESOLUTIONS.json：独立审查和已处理意见。
- replay_to_new.py、REPLAY_INPUTS.json：50 文件独立重放入口；仅接受不存在的新目录。
- PACKAGE_FILES_SHA256.json：归档白名单，不包含缓存、隔离 HOME、测试变异副本或任何私聊/凭据。
