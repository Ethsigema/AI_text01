from pathlib import Path
from copy import deepcopy
import ast,hashlib,json,resource,sys,types
resource.setrlimit(resource.RLIMIT_AS,(128*1024**2,128*1024**2));sys.dont_write_bytecode=True
H=Path(__file__).resolve().parent
ALLOWED={'pathlib','copy','hashlib','json','xml.etree.ElementTree','re','math'}
def load(path):
 s=path.read_text();tree=ast.parse(s)
 for n in tree.body:
  if isinstance(n,ast.Expr):assert isinstance(n.value,ast.Constant) and isinstance(n.value.value,str)
  elif isinstance(n,ast.Assign):ast.literal_eval(n.value)
  elif isinstance(n,ast.ImportFrom):assert n.module in ALLOWED
  elif isinstance(n,ast.Import):assert all(x.name in ALLOWED for x in n.names)
  else:assert isinstance(n,ast.FunctionDef)
 m=types.ModuleType(path.stem);exec(compile(tree,str(path),'exec'),m.__dict__);return m
old=load(H/'original_inputs/research/old_murkeye_aura_native_recovery/candidates/tools/old_murkeye_aura_patterns.py')
new=load(H/'candidate/tools/old_murkeye_aura_patterns.py')
GD=json.loads((H/'GD_CONSTANTS.json').read_text());IDS=new.SOURCE_IDS
POOL_REASON='没有已确认的普通商店随从资格；衍生物、伙伴或时空扭曲内容需由对应机制生成，或显式配置自定义入店参数。'
def frozen(x):return json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':'))
def base(case):
 row=deepcopy(GD['RAW' if case['stage']=='raw' else 'CANONICAL'][case['identity']])
 if case['stage']=='final':row.update(deepcopy(GD['EXPECTED'][case['identity']]))
 return row
def mutate(value,case):
 op=case['op'];path=case['path']
 if op=='canonical':return value
 if op=='swap_rows':return {IDS[0]:value[IDS[1]],IDS[1]:value[IDS[0]]}
 if op=='duplicate_normal':return {IDS[0]:value[IDS[0]],IDS[1]:deepcopy(value[IDS[0]])}
 if op=='duplicate_golden':return {IDS[0]:value[IDS[1]],IDS[1]:deepcopy(value[IDS[1]])}
 if op=='pool_blocker':value['pool_blocker']=POOL_REASON;return value
 if op=='invalid_root':return deepcopy(case['value'])
 if op=='id_only':return {'id':value['id']}
 if op=='extra_unrelated':value['not-a-source']={'id':'not-a-source'};return value
 if op=='invalid_member':value[path[0]]=None;return value
 parent=value
 for part in path[:-1]:parent=parent[part]
 old_value=parent[path[-1]] if path else value
 if op=='delete':del parent[path[-1]];return value
 if op=='bool_to_int':updated=int(old_value)
 elif op=='bool_to_float':updated=float(old_value)
 elif op=='toggle_bool':updated=not old_value
 elif op=='numeric_float':updated=float(old_value)
 elif op=='numeric_int':updated=int(old_value)
 elif op=='number_delta':updated=old_value+1
 elif op=='number_string':updated=str(old_value)
 elif op=='number_bool':updated=bool(old_value)
 elif op=='change_string':updated=old_value+'__changed__'
 elif op=='null_to_false':updated=False
 elif op=='extra_key':updated=deepcopy(old_value);updated['__extra__']=True
 elif op=='append_item':updated=deepcopy(old_value);updated.append('__extra__')
 elif op=='reverse_list':updated=list(reversed(old_value))
 elif op=='nan':updated=float('nan')
 elif op=='pos_inf':updated=float('inf')
 elif op=='neg_inf':updated=float('-inf')
 else:raise AssertionError(op)
 if path:parent[path[-1]]=updated
 else:value=updated
 return value

results=[];cases=json.loads((H/'CASES.json').read_text())
for case in cases:
 identity=case['identity'];card=base(case);cards=deepcopy(GD['CANONICAL'])
 if case['target']=='card':card=mutate(card,case)
 elif case['target']=='mapping':cards[identity]=mutate(cards[identity],case)
 else:cards=mutate(cards,case)
 before=frozen([card,cards]);accepts={};errors={};out=None
 if case['stage']=='canonical':
  for name,module in [('old',old),('new',new)]:
   try:
    result=module.compile_card(card,cards,H/'original_inputs')
    accepts[name]=result is not None
    if name=='new':out=result
   except Exception as e:accepts[name]=False;errors[name]=type(e).__name__
   assert frozen([card,cards])==before
  assert not errors,case
  if out is not None:
   expected={k:v for k,v in GD['EXPECTED'][identity].items() if k not in ('id','supported','coverage_text_sha256')}
   assert frozen(out)==frozen(expected)
 else:
  reference=base(case)
  if case['stage']=='final' and isinstance(card,dict) and 'pool_blocker' in card and identity==IDS[1]:reference['pool_blocker']=POOL_REASON
  for name,module in [('old',old),('new',new)]:accepts[name]=isinstance(card,dict) and module.same(card,reference)
 assert frozen([card,cards])==before,case['label']
 results.append({'label':case['label'],'stage':case['stage'],'old_accept':accepts['old'],'new_accept':accepts['new'],'input_unchanged':True,'new_error':errors.get('new')})
outputs={}
for identity in IDS:
 before=frozen([GD,new.EXPECTED]);card=deepcopy(GD['CANONICAL'][identity]);cards=deepcopy(GD['CANONICAL'])
 a=new.compile_card(card,cards,H/'original_inputs');b=new.compile_card(card,cards,H/'original_inputs')
 assert a is not b and a['effects'] is not b['effects'] and a['effects'] is not new.EXPECTED[identity]['effects']
 a['effects'][0]['test_extra']=True;assert 'test_extra' not in b['effects'][0]
 assert before==frozen([GD,new.EXPECTED])
 assert b['default_pool'] is False and b['pool_supported'] is False and b['implementation_status']=='partial_pending_unified_validation'
 outputs[identity]=b
proofs=[]
for rel,pin in new.PROOF_SHA256.items():
 assert hashlib.sha256((H/'original_inputs'/rel).read_bytes()).hexdigest()==pin
 for op in ['tampered','missing']:
  root=H/'proof_variants'/(Path(rel).name+'_'+op)
  for path in new.PROOF_SHA256:
   if path==rel and op=='missing':continue
   dest=root/path;dest.parent.mkdir(parents=True,exist_ok=True);blob=(H/'original_inputs'/path).read_bytes()
   if path==rel and op=='tampered':blob+=b'\n'
   dest.write_bytes(blob)
  accepted=[new.compile_card(deepcopy(GD['CANONICAL'][i]),deepcopy(GD['CANONICAL']),root) is not None for i in IDS]
  assert accepted==[False,False]
  proofs.append({'path':rel,'operation':op,'accepted':accepted})
report={'case_count':len(cases),'stages':{},'all_input_unchanged':True,'all_accepted_compile_outputs_exact':True,'deepcopy_isolation':True,'proof_negative_checks':proofs,'results':results,'max_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
for stage in ('canonical','raw','final'):
 rows=[r for r in results if r['stage']==stage]
 report['stages'][stage]={'cases':len(rows),'new_accept':sum(r['new_accept'] for r in rows),'old_accept':sum(r['old_accept'] for r in rows),'newly_accepted':sum(r['new_accept'] and not r['old_accept'] for r in rows),'newly_rejected':sum(r['old_accept'] and not r['new_accept'] for r in rows)}
(H/'PYTHON_REPORT.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
(H/'CANDIDATE_OUTPUTS.json').write_text(json.dumps(outputs,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in ('results','proof_negative_checks')},indent=2))
