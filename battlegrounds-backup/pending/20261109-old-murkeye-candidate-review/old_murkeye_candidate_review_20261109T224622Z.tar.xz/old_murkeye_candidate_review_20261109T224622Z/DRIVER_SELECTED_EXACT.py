def emit(c,es,k=(),rule='reviewed_exact',**kw):out[c['id']]={'id':c['id'],'supported':True,'effects':es,'keywords':list(k),'coverage_rule':rule,'coverage_text_sha256':hashlib.sha256(c['text'].encode()).hexdigest(),'default_pool':False,**kw}

if (R/'data/catalog_value_overrides.json').exists():
 for override in json.loads((R/'data/catalog_value_overrides.json').read_text())['overrides']:
  if override.get('verification',{}).get('status')=='confirmed' and override['id'] in cards:
   c=cards[override['id']]
   for field,value in override['fields'].items():
    c[field]=value
    c.setdefault('field_status',{})[field]={'value':value,'status':'known','verification':'confirmed_independent_entity'}
   c['value_override_verification']=override['verification']

for identity in OLD_MURKEYE_AURA_IDS:
 out.pop(identity,None)
 c=cards.get(identity)
 compiled=compile_old_murkeye_aura(c,cards,root=R)
 if compiled is not None:
  metadata={k:v for k,v in compiled.items() if k not in ('effects','keywords','coverage_rule')}
  emit(c,compiled['effects'],compiled['keywords'],rule=compiled['coverage_rule'],**metadata)

ordered_ids=[identity for identity in ordered_ids if identity not in OLD_MURKEYE_AURA_IDS]

ordered_ids.extend(identity for identity in OLD_MURKEYE_AURA_IDS if identity in out)
