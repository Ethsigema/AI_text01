"""Exact native pair only; no global compile, runtime, or effect execution."""
from pathlib import Path
from copy import deepcopy
import hashlib,json,xml.etree.ElementTree as ET,re
SOURCE_IDS=['BG_EX1_062', 'TB_BaconUps_036']
EXPECTED={'BG_EX1_062': {'id': 'BG_EX1_062', 'supported': True, 'effects': [{'type': 'board_aura', 'scope': 'self', 'tribe': '', 'source_id': 'BG_EX1_062', 'attack': 0, 'health': 0, 'attack_per_owner_tier': 0, 'attack_per_other_murloc': 1, 'duration': 'while_source_on_board'}], 'keywords': ['charge'], 'default_pool': False, 'pool_supported': False, 'coverage_rule': 'old_murkeye_other_battlefield_murloc_aura_v1', 'coverage_text_sha256': '9308dc1bf37a884858f1377aa2b11cedb8fc9b61f4e9daf42a7da6d45e7d73d3', 'implementation_status': 'partial_pending_unified_validation', 'conditional_support': {'rule': 'old_murkeye_source_owned_aura_partial_v1', 'reason': 'Independent complete native EX1_062/DBF736 (catalog alias BG_EX1_062, preserved raw DBF0736) and TB_BaconUps_036/DBF58382: normal 2/4 and golden 4/8, tier2, Charge, and +1/+2 Attack for each OTHER battlefield Murloc. Charge is retained as a native source-specific keyword; Battlegrounds combat has no summoning-sickness gate, so it adds no immediate attack, priority, Windfury or summon trigger. Recruit uses only the actual owner board; Combat uses both actual host boards, includes Murloc/ALL once per physical body, and excludes only this exact source instance. Existing additive board-aura lifecycle removes departed contributions, projects actual summons/removals/identity replacements, preserves owner/UID, signed ordinary Attack and existing GoldenRebase/restore contracts. Aura changes are not ordinary Attack gains, Keep rewards or 317 triggers. Existing operation-specific unproved copy/transform/GoldenKeep/death-reader and offboard observation boundaries remain explicit; source attachment/inherited program and source tribe changes remain partial. Native both-board scope is source text; pending-lethal bodies continue counting until actual host removal under the established local aura phase contract. Both default_pool=false and pool_supported=false; no full/core promotion, gameplay or unified validation claim.'}}, 'TB_BaconUps_036': {'id': 'TB_BaconUps_036', 'supported': True, 'effects': [{'type': 'board_aura', 'scope': 'self', 'tribe': '', 'source_id': 'TB_BaconUps_036', 'attack': 0, 'health': 0, 'attack_per_owner_tier': 0, 'attack_per_other_murloc': 2, 'duration': 'while_source_on_board'}], 'keywords': ['charge'], 'default_pool': False, 'pool_supported': False, 'coverage_rule': 'old_murkeye_other_battlefield_murloc_aura_v1', 'coverage_text_sha256': '8653c08c374c6944026db2a1aea678e6c2a34fb8b552d94476b1113f2723af0a', 'implementation_status': 'partial_pending_unified_validation', 'conditional_support': {'rule': 'old_murkeye_source_owned_aura_partial_v1', 'reason': 'Independent complete native EX1_062/DBF736 (catalog alias BG_EX1_062, preserved raw DBF0736) and TB_BaconUps_036/DBF58382: normal 2/4 and golden 4/8, tier2, Charge, and +1/+2 Attack for each OTHER battlefield Murloc. Charge is retained as a native source-specific keyword; Battlegrounds combat has no summoning-sickness gate, so it adds no immediate attack, priority, Windfury or summon trigger. Recruit uses only the actual owner board; Combat uses both actual host boards, includes Murloc/ALL once per physical body, and excludes only this exact source instance. Existing additive board-aura lifecycle removes departed contributions, projects actual summons/removals/identity replacements, preserves owner/UID, signed ordinary Attack and existing GoldenRebase/restore contracts. Aura changes are not ordinary Attack gains, Keep rewards or 317 triggers. Existing operation-specific unproved copy/transform/GoldenKeep/death-reader and offboard observation boundaries remain explicit; source attachment/inherited program and source tribe changes remain partial. Native both-board scope is source text; pending-lethal bodies continue counting until actual host removal under the established local aura phase contract. Both default_pool=false and pool_supported=false; no full/core promotion, gameplay or unified validation claim.'}}}
PROOF_SHA256={'research/old_murkeye_aura_sources/retrieval_receipt.json': 'd7a85027801bcee8d78e14f1573d23ac113bff79c35b32f5a04d8731a05a621d', 'research/old_murkeye_aura_sources/EX1_062.latest.xml': 'a35bd055917d3eb79b61c5e7ac9f171f7ccfffcf7fc7542e8d50f4245017e2b2', 'research/old_murkeye_aura_sources/raw_rows.json': 'd43e69d90f9a990848cac117c5126ab34594966bdaf3b7280e6c5fb59d486946', 'research/old_murkeye_aura_sources/native_contract.json': 'dcb1f6417881691a3bf0e1a99ef48538e9346be58a309b708b61113ddae4afaa', 'research/old_murkeye_aura_sources/expected_compiled.json': '61d42026f4e8473de60712349228bcb4f50aa5ce71e5f09caee97dd77f13403b', 'research/old_murkeye_aura_sources/canonical_rows.json': '3a4cae0a6b754f705b8d1d3cbcda889eb3d05cfb62789796dd2fd357901761fc', 'research/old_murkeye_aura_sources/TB_BaconUps_036.terminal.xml': '4193c8b46426d4ba6f3ec209ec8b9db42679f57b48eed43d8af77abb673039eb', 'research/old_murkeye_aura_sources/EX1_062.terminal.xml': '4ed7479235b36bfd7490b956d39db11f62265adbe0b809657edce5389dae7e03'}
FOLDER='research/old_murkeye_aura_sources'
def same(a,b):
    if type(a) is not type(b):return False
    if isinstance(a,dict):return a.keys()==b.keys() and all(same(a[k],b[k]) for k in a)
    if isinstance(a,list):return len(a)==len(b) and all(same(x,y) for x,y in zip(a,b))
    return a==b
def node(x):return {'tag':x.tag,'attributes':dict(x.attrib),'text':x.text,'children':[node(y) for y in x]}
def verify_sources(root):
    root=Path(root)
    for path,pin in PROOF_SHA256.items():
        if hashlib.sha256((root/path).read_bytes()).hexdigest()!=pin:raise ValueError('old_murkeye_proof_changed:'+path)
    contract=json.loads((root/FOLDER/'native_contract.json').read_text())
    rows=json.loads((root/FOLDER/'canonical_rows.json').read_text())
    raw=json.loads((root/FOLDER/'raw_rows.json').read_text())
    for identity in SOURCE_IDS:
        record=contract['records'][identity];e=ET.fromstring((root/FOLDER/record['entity_file']).read_bytes())
        if not same(node(e),record['all_native_nodes']):raise ValueError('old_murkeye_complete_entity_changed')
        tags={t.get('name'):t for t in e.findall('Tag')};n=record['multiplier']
        clean=lambda s:re.sub('<[^>]+>','',s)
        if clean(tags['CARDTEXT'].findtext('zhCN'))!=raw[identity]['text'] or clean(tags['CARDTEXT'].findtext('enUS'))!=f'Charge. Has +{n} Attack for each other Murloc on the battlefield.':raise ValueError('old_murkeye_native_full_text')
        if any(int(tags[tag].get('value'))!=rows[identity][field] for tag,field in [('ATK','attack'),('HEALTH','health'),('TECH_LEVEL','tier')]):raise ValueError('old_murkeye_independent_native_body')
        if tags['CHARGE'].get('value')!='1' or tags['CARDRACE'].get('value')!='14' or tags['CARDTYPE'].get('value')!='4':raise ValueError('old_murkeye_native_minion_keyword_tribe')
        link='BACON_TRIPLE_UPGRADE_MINION_ID' if identity==SOURCE_IDS[0] else 'BACON_TRIPLED_BASE_MINION_ID'
        if tags[link].get('value')!=('58382' if identity==SOURCE_IDS[0] else '736'):raise ValueError('old_murkeye_native_pair_link')
        if int(e.get('ID'))!=int(raw[identity]['dbf_id']) or e.get('CardID')!=('EX1_062' if identity==SOURCE_IDS[0] else identity):raise ValueError('old_murkeye_native_alias')
    return rows
def compile_card(card,cards,root):
    if not isinstance(card,dict) or card.get('id') not in SOURCE_IDS:return None
    try:
        rows=verify_sources(root)
        if not same(card,rows[card['id']]) or any(not same(cards.get(i),rows[i]) for i in SOURCE_IDS):return None
        return {k:deepcopy(v) for k,v in EXPECTED[card['id']].items() if k not in ('id','supported','coverage_text_sha256')}
    except (OSError,ValueError,KeyError,TypeError,AttributeError,ET.ParseError):return None
