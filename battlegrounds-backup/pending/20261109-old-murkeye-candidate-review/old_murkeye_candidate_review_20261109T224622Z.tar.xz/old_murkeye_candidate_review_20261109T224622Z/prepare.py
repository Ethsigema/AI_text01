from pathlib import Path
import ast,difflib,hashlib,json,re,resource
resource.setrlimit(resource.RLIMIT_AS,(128*1024**2,128*1024**2))
H=Path(__file__).resolve().parent;R=H.parent/'historical_tools_batch14_20261109T191857Z/runtime'
BASE=json.loads((R.parent/'SOURCE_MAP.json').read_text())
historical='research/old_murkeye_aura_native_recovery/candidates/tools/old_murkeye_aura_patterns.py'
s=(R/historical).read_text();assert hashlib.sha256(s.encode()).hexdigest()=='7c780b25e3a001d4b961b0c3809170097b952beeb84cf7a5d1cb19a8759588e0'
constants={n.targets[0].id:ast.literal_eval(n.value) for n in ast.parse(s).body if isinstance(n,ast.Assign)}
inputs=[historical,'research/old_murkeye_aura_native_recovery/manifest.json','research/old_murkeye_aura_native_recovery/candidate.patch','core/old_murkeye_aura_sources.gd','core/pool_identity.gd']+list(constants['PROOF_SHA256'])
pins={}
for rel in inputs:
 b=(R/rel).read_bytes();sha=hashlib.sha256(b).hexdigest();assert sha==BASE[rel]['sha256']
 d=H/'original_inputs'/rel;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(b);assert d.stat().st_ino!=(R/rel).stat().st_ino
 pins[rel]={'sha256':sha,'bytes':len(b)}
 if rel.startswith('core/') or rel in constants['PROOF_SHA256']:
  d=H/'gd_minimal'/rel;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(b)
 if rel in constants['PROOF_SHA256']:assert sha==constants['PROOF_SHA256'][rel]
new=s.replace('import hashlib,json,xml.etree.ElementTree as ET,re\n','import hashlib,json,xml.etree.ElementTree as ET,re\nfrom math import isfinite\n')
old='def same(a,b):\n    if type(a) is not type(b):return False\n'
change='''def same(a,b):
    """Compare this family's fixed JSON schema; bool is not a number."""
    if type(a) in (int,float) and type(b) in (int,float):
        return (type(a) is int or isfinite(a)) and (type(b) is int or isfinite(b)) and a==b
    if type(a) is not type(b):return False
'''
assert new.count(old)==1;new=new.replace(old,change)
p=H/'candidate/tools/old_murkeye_aura_patterns.py';p.parent.mkdir(parents=True);p.write_text(new)
patch=''.join(difflib.unified_diff(s.splitlines(True),new.splitlines(True),fromfile='a/tools/old_murkeye_aura_patterns.py',tofile='b/tools/old_murkeye_aura_patterns.py'))
(H/'candidate/finite_numeric_correction.patch').write_text(patch)
newconstants={n.targets[0].id:ast.literal_eval(n.value) for n in ast.parse(new).body if isinstance(n,ast.Assign)}
assert constants==newconstants
source=(R/'core/old_murkeye_aura_sources.gd').read_text();gd={}
for name in ['RAW','CANONICAL','EXPECTED','PROGRAMS','PROOF_SHA256']:
 m=re.search(r'^const '+name+r': Dictionary=(.*)$',source,re.M);gd[name]=json.loads(m[1])
assert gd['EXPECTED']==constants['EXPECTED'] and gd['PROOF_SHA256']==constants['PROOF_SHA256']
for name,fn in [('RAW','raw_rows.json'),('CANONICAL','canonical_rows.json'),('EXPECTED','expected_compiled.json')]:
 assert json.dumps(gd[name],sort_keys=True)==json.dumps(json.loads((R/'research/old_murkeye_aura_sources'/fn).read_text()),sort_keys=True)
(H/'GD_CONSTANTS.json').write_text(json.dumps(gd,ensure_ascii=False,indent=2)+'\n')
cases=[]
def add(stage,target,identity,path,op,**kw):
 cases.append(dict(label=f'{len(cases):05d}:{stage}:{target}:{identity}:{op}:'+'.'.join(map(str,path)),stage=stage,target=target,identity=identity,path=path,op=op,**kw))
def walk(v,p=[]):
 yield p,v
 if isinstance(v,dict):
  for k,x in v.items():yield from walk(x,p+[k])
 if isinstance(v,list):
  for k,x in enumerate(v):yield from walk(x,p+[k])
for identity in constants['SOURCE_IDS']:
 for stage in ('canonical','raw','final'):
  row=gd[{'canonical':'CANONICAL','raw':'RAW','final':'CANONICAL'}[stage]][identity].copy()
  if stage=='final':row.update(gd['EXPECTED'][identity])
  for target in (('card','mapping') if stage=='canonical' else ('card',)):
   add(stage,target,identity,[],'canonical')
   for path,value in walk(row):
    if path:add(stage,target,identity,path,'delete')
    if type(value) is bool:
     for op in ('bool_to_int','bool_to_float','toggle_bool'):add(stage,target,identity,path,op)
    elif type(value) in (int,float):
     for op in ('numeric_float','numeric_int','number_delta','number_string','number_bool','nan','pos_inf','neg_inf'):add(stage,target,identity,path,op)
    elif isinstance(value,str):add(stage,target,identity,path,'change_string')
    elif value is None:add(stage,target,identity,path,'null_to_false')
    elif isinstance(value,dict):add(stage,target,identity,path,'extra_key')
    elif isinstance(value,list):
     add(stage,target,identity,path,'append_item')
     if len(value)>1:add(stage,target,identity,path,'reverse_list')
  for value in [None,[],0,False,'bad']:add(stage,'card',identity,[],'invalid_root',value=value)
  add(stage,'card',identity,[],'id_only')
 for value in [None,[],0,False,'bad']:add('canonical','cards',identity,[],'invalid_root',value=value)
 add('canonical','cards',identity,[],'extra_unrelated')
 for dep in constants['SOURCE_IDS']:
  add('canonical','cards',identity,[dep],'delete');add('canonical','cards',identity,[dep],'invalid_member')
 for op in ('swap_rows','duplicate_normal','duplicate_golden'):add('canonical','cards',identity,[],op)
 # Current source_error intentionally permits the exact golden pool blocker only after compile.
 add('final','card',identity,[],'pool_blocker')
(H/'CASES.json').write_text(json.dumps(cases,ensure_ascii=False,indent=2)+'\n')
(H/'INPUT_PINS.json').write_text(json.dumps(pins,indent=2)+'\n')
(H/'gd_minimal/project.godot').write_text('[application]\nconfig/name="Old Murkeye independent numeric review"\n[rendering]\nrenderer/rendering_method="gl_compatibility"\n')
nums=[v for row in gd['CANONICAL'].values() for _,v in walk(row) if type(v) in (int,float)]
report={'original_sha256':hashlib.sha256(s.encode()).hexdigest(),'candidate_sha256':hashlib.sha256(new.encode()).hexdigest(),'candidate_bytes':len(new.encode()),'patch_sha256':hashlib.sha256(patch.encode()).hexdigest(),'input_count':len(pins),'proof_file_count':len(constants['PROOF_SHA256']),'case_count':len(cases),'constants_unchanged':True,'new_dependency':'math.isfinite (Python standard library)','numeric_domain':{'count':len(nums),'min':min(nums),'max':max(nums),'all_exact_int':all(type(v) is int for v in nums)},'not_installed':True,'not_original_or_latest':True,'max_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
(H/'PREPARATION.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
