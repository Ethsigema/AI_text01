from pathlib import Path
import ast,hashlib,json,re,resource
resource.setrlimit(resource.RLIMIT_AS,(128*1024**2,128*1024**2))
H=Path(__file__).resolve().parent;R=H.parent/'historical_tools_batch14_20261109T191857Z/runtime'
def patch_sections(b):
 lines=b.decode().splitlines(keepends=True);sections=[];i=0
 while i<len(lines):
  if lines[i].startswith('--- ') and i+1<len(lines) and lines[i+1].startswith('+++ '):
   old=lines[i][4:].strip();new=lines[i+1][4:].strip();j=i+2
   while j<len(lines) and not lines[j].startswith('--- '):j+=1
   sections.append((old,new,lines[i+2:j]));i=j
  else:i+=1
 return sections

def apply(source,body,reverse=False):
 src=source.decode().splitlines(keepends=True);out=[];pos=0;i=0
 while i<len(body):
  line=body[i];m=re.match(r'^@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@',line)
  assert m,line[:80];a,ac,b,bc=int(m[1]),int(m[2] or 1),int(m[3]),int(m[4] or 1)
  if reverse:a,ac,b,bc=b,bc,a,ac
  start=a-1 if ac else a;assert start>=pos
  out.extend(src[pos:start]);old=[];new=[];i+=1
  while i<len(body) and not body[i].startswith('@@ '):
   s=body[i];i+=1
   assert s[0] in ' +-'
   prefix=s[0]
   if reverse:prefix={'-':'+','+':'-',' ':' '}[prefix]
   if prefix in ' -':old.append(s[1:])
   if prefix in ' +':new.append(s[1:])
  assert len(old)==ac and len(new)==bc
  assert src[start:start+ac]==old,'Exact context mismatch'
  out.extend(new);pos=start+ac
 out.extend(src[pos:]);return ''.join(out).encode()
target='tools/old_murkeye_aura_patterns.py'
original=(H/'original_inputs/research/old_murkeye_aura_native_recovery/candidates'/target).read_bytes();candidate=(H/'candidate'/target).read_bytes()
patch=H/'original_inputs/research/old_murkeye_aura_native_recovery/candidate.patch'
section=next(x for x in patch_sections(patch.read_bytes()) if x[1] in ('b/'+target,target))
assert section[0]=='/dev/null' and apply(b'',section[2])==original
sections=patch_sections((H/'candidate/finite_numeric_correction.patch').read_bytes());assert len(sections)==1
assert apply(original,sections[0][2])==candidate and apply(candidate,sections[0][2],True)==original
pins=json.loads((H/'INPUT_PINS.json').read_text())
for rel,pin in pins.items():
 for folder in [R,H/'original_inputs']:
  data=(folder/rel).read_bytes();assert hashlib.sha256(data).hexdigest()==pin['sha256'] and len(data)==pin['bytes']
 if (H/'gd_minimal'/rel).is_file():assert hashlib.sha256((H/'gd_minimal'/rel).read_bytes()).hexdigest()==pin['sha256']
oldtree=ast.parse(original);newtree=ast.parse(candidate)
constants=lambda tree:{n.targets[0].id:ast.literal_eval(n.value) for n in tree.body if isinstance(n,ast.Assign)}
assert constants(oldtree)==constants(newtree)
oldfunc={n.name:ast.dump(n) for n in oldtree.body if isinstance(n,ast.FunctionDef)}
newfunc={n.name:ast.dump(n) for n in newtree.body if isinstance(n,ast.FunctionDef)}
assert [k for k in oldfunc if oldfunc[k]!=newfunc[k]]==['same']
imports=[]
for node in ast.walk(newtree):
 if isinstance(node,ast.ImportFrom):imports.append(node.module)
 elif isinstance(node,ast.Import):imports.extend(x.name for x in node.names)
assert set(imports)=={'pathlib','copy','hashlib','json','xml.etree.ElementTree','re','math'}
remaining=json.loads((R.parent.parent/'historical_tools_batch15_20261109T195018Z/REMAINING_SCOPE.json').read_text())['remaining_targets']
assert len(remaining)==345 and not any((R/x).exists() for x in remaining)
base=json.loads((R.parent/'SOURCE_MAP.json').read_text())
def sha_stream(path):
 h=hashlib.sha256()
 with path.open('rb') as f:
  for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
 return h.hexdigest()
inputs=json.loads((H/'callchain_audit/CURRENT_INPUT_CONTRACT.json').read_text())['files']
for record in inputs:assert sha_stream(R/record['path'])==record['sha256']==base[record['path']]['sha256']
for rel in ['core/catalog.gd','core/game.gd','tools/final_source_overrides.py']:
 assert sha_stream(R/rel)==base[rel]['sha256']
prior={'remaining_tools_readonly_audit_20261109T215306Z.tar.xz':'9eb4be705ee386167956350de3212845a70b664148f8dddeb3aed540da5c12ba','imperial_defender_candidate_review_20261109T220940Z.tar.xz':'19750c8aa7ad3117befab977d8dd338fbb934d5ed5c958cf373a52e71e54bde0','imperial_identity_callchain_audit_20261109T222624Z.tar.xz':'f77e2a104017e743ee7c529feeef9bd4137367cacfcee65e2c34252139e9f846'}
for file,sha in prior.items():assert sha_stream(H.parent/file)==sha
py=json.loads((H/'PYTHON_REPORT.json').read_text());gd=json.loads((H/'GODOT_first.json').read_text());assert gd==json.loads((H/'GODOT_repeat.json').read_text())
assert py['case_count']==gd['case_count']==4903 and not gd['failures']
assert py['stages']['canonical']['newly_accepted']==114 and py['stages']['canonical']['newly_rejected']==0
assert gd['positive_compiled_pair_source_and_closure_checks']==234
for x in gd['effect_route_probes']:
 expected=x['op'] in ['canonical','finite_float'];assert (not x['native_issue'])==expected and (not x['routed_issue'])==expected
assert len(gd['proof_tamper_probes'])==8 and all(x['restored'] for x in gd['proof_tamper_probes'])
report={'status':'BOUNDED_NUMERIC_CORRECTION_VALIDATED_CURRENT_DRIVER_AND_INSTALLATION_DEFERRED','candidate_sha256':hashlib.sha256(candidate).hexdigest(),'candidate_bytes':len(candidate),'original_sha256':hashlib.sha256(original).hexdigest(),'creation_patch_exact':True,'new_patch_forward_reverse_exact':True,'selected_original_inputs_unchanged':len(pins),'current_catalog_inputs_hash_verified':len(inputs),'prior_archives_unchanged':prior,'only_changed_function':'same','only_added_import':'math.isfinite','remaining_reference_gaps':345,'candidate_installed':False,'main_cases':4903,'canonical_compile_cases':2468,'corrected_float_admissions':114,'candidate_vs_current_GD_mismatches_in_corpus':0,'actual_source_and_pair_closure_checks':234,'actual_effect_route_probes':12,'actual_structural_closure_probes':8,'proof_tamper_probes_per_gd_run':8,'godot_repeat_exact':True,'full_driver_catalog_game_or_old_save_executed':False,'arbitrary_all_numeric_domains_equivalence_claimed':False,'current_complete_driver_proven':False,'network_used':False,'whole_runtime_tree_rehashed':False,'max_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
(H/'FINAL_VERIFICATION.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
