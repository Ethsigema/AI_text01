"""Bounded data/AST audit only. No project module imports or execution."""
from pathlib import Path
import ast, gc, hashlib, json, re, resource
from copy import deepcopy
resource.setrlimit(resource.RLIMIT_AS,(128*1024*1024,128*1024*1024))
H=Path(__file__).resolve().parent; W=H.parent; R=W/'historical_tools_batch14_20261109T191857Z/runtime'
IP=W/'historical_tools_batch16_driver_closeout_20261109T205039Z/compiler/CURRENT_VERSIONS.json'
def sha(p):
 h=hashlib.sha256()
 with p.open('rb')as f:
  for b in iter(lambda:f.read(262144),b''):h.update(b)
 return h.hexdigest()
def save(name,x):(H/name).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def rows(p):
 decoder=json.JSONDecoder()
 with p.open(encoding='utf-8')as f:
  buf=f.read(65536);m=re.search(r'"cards"\s*:\s*\[',buf);assert m
  prefix=buf[:m.end()-1];assert json.loads(prefix+'[]}')['cards']==[];pos=m.end()
  while True:
   while pos<len(buf)and buf[pos]in ' \r\t\n,':pos+=1
   if pos>=len(buf):buf=f.read(65536);pos=0;assert buf;continue
   if buf[pos]==']':json.loads(prefix+'[]'+buf[pos+1:]+f.read());break
   try:row,end=decoder.raw_decode(buf,pos)
   except json.JSONDecodeError:
    more=f.read(65536);assert more;buf=buf[pos:]+more;pos=0;assert len(buf)<8*1024*1024;continue
   assert isinstance(row,dict);yield row;pos=end
   if pos>65536:buf=buf[pos:];pos=0

def exact(a,b):
 if type(a)is not type(b):return False
 if isinstance(a,dict):return a.keys()==b.keys()and all(exact(a[k],b[k])for k in a)
 if isinstance(a,list):return len(a)==len(b)and all(exact(x,y)for x,y in zip(a,b))
 return a==b
G=R/'core/old_murkeye_aura_sources.gd';g=G.read_text();const={}
for l in g.splitlines():
 m=re.match(r'^const (RAW|CANONICAL|EXPECTED|PROGRAMS|PROOF_SHA256|RUNTIME_PATHS): (?:Dictionary|Array)=(.*)$',l)
 if m:const[m[1]]=json.loads(m[2])
ids=list(const['RAW']); P=R/'research/old_murkeye_aura_native_recovery/candidates/tools/old_murkeye_aura_patterns.py';pt=ast.parse(P.read_text());pc={}
for n in pt.body:
 if isinstance(n,ast.Assign)and len(n.targets)==1 and isinstance(n.targets[0],ast.Name):
  try:pc[n.targets[0].id]=ast.literal_eval(n.value)
  except ValueError:pass
proofs=[{'path':rel,'exists':(R/rel).is_file(),'sha256':sha(R/rel)if(R/rel).is_file()else None,'expected_sha256':pin}for rel,pin in pc['PROOF_SHA256'].items()]
source_proofs={'gd_sha256':sha(G),'gd_pin_matches':sha(G)=='a6a5e40f89f1c91999a7e0b81091e8ea541a2100234cd8f3d831caa9b40d203b','historical_python_sha256':sha(P),'historical_python_pin_matches':sha(P)=='7c780b25e3a001d4b961b0c3809170097b952beeb84cf7a5d1cb19a8759588e0','proofs':proofs,'all_proofs_match':all(x['sha256']==x['expected_sha256']for x in proofs),'python_gd_expected_equal':exact(pc['EXPECTED'],const['EXPECTED']),'python_gd_proof_pins_equal':exact(pc['PROOF_SHA256'],const['PROOF_SHA256']),'raw_json_gd_equal':exact(json.loads((R/'research/old_murkeye_aura_sources/raw_rows.json').read_text()),const['RAW']),'canonical_json_gd_equal':exact(json.loads((R/'research/old_murkeye_aura_sources/canonical_rows.json').read_text()),const['CANONICAL']),'runtime_path_presence':[{'path':p,'exists':(R/p).exists()}for p in const['RUNTIME_PATHS']],'python_imports':[ast.unparse(n)for n in pt.body if isinstance(n,(ast.Import,ast.ImportFrom))]}
save('SOURCE_PROOFS.json',source_proofs)
catalog=(R/'core/catalog.gd').read_text(); paths=json.loads(re.search(r'^\s*for path in (\["res://data/catalog_raw.json".*\]):$',catalog,re.M)[1]); files=[];hits=[]
for path in paths:
 rel=path.removeprefix('res://');p=R/rel
 if not p.is_file():files.append({'path':rel,'exists':False});continue
 count=0;h=[]
 for count,row in enumerate(rows(p),1):
  if row.get('id')in ids:
   h.append(row['id']);hits.append({'path':rel,'row_index_zero_based':count-1,'id':row['id'],'row':row})
 files.append({'path':rel,'exists':True,'sha256':sha(p),'row_count':count,'target_ids':h})
by_input={i:next(x['row']for x in hits if x['path']=='data/catalog_raw.json'and x['id']==i)for i in ids}
by_overlay={i:next(x['row']for x in hits if x['path']=='data/catalog.json'and x['id']==i)for i in ids}
ov=json.loads((R/'data/catalog_value_overrides.json').read_text());selected=[x for x in ov['overrides']if x['id']in ids]
canon=deepcopy(by_input)
for o in selected:
 assert o['verification']['status']=='confirmed';c=canon[o['id']]
 for k,v in o['fields'].items():c[k]=v;c.setdefault('field_status',{})[k]={'value':v,'status':'known','verification':'confirmed_independent_entity'}
 c['value_override_verification']=deepcopy(o['verification'])
contracts=[]
for identity in ids:
 raw=by_input[identity];ca=canon[identity];expected=deepcopy(const['CANONICAL'][identity]);expected.update(const['EXPECTED'][identity]);actual=deepcopy(ca);actual.update(by_overlay[identity])
 partial={k:deepcopy(v)for k,v in pc['EXPECTED'][identity].items()if k not in ('id','supported','coverage_text_sha256')}
 meta={k:v for k,v in partial.items()if k not in ('effects','keywords','coverage_rule')}
 emitted={'id':ca['id'],'supported':True,'effects':partial['effects'],'keywords':list(partial['keywords']),'coverage_rule':partial['coverage_rule'],'coverage_text_sha256':hashlib.sha256(ca['text'].encode()).hexdigest(),'default_pool':False,**meta}
 contracts.append({'id':identity,'raw_matches_gd_RAW':exact(raw,const['RAW'][identity]),'raw_equals_CANONICAL':exact(raw,const['CANONICAL'][identity]),'current_value_override_derives_CANONICAL':exact(ca,const['CANONICAL'][identity]),'changed_top_level_fields':[k for k in set(raw)|set(ca)if k not in raw or k not in ca or not exact(raw[k],ca[k])],'overlay_matches_EXPECTED':exact(by_overlay[identity],const['EXPECTED'][identity]),'emitted_fragment_matches_current_overlay':exact(emitted,by_overlay[identity]),'canonical_plus_overlay_equals_source_error_expected':exact(actual,expected),'generated_fragment_keys':list(partial),'emitted_keys':list(emitted)})
save('CURRENT_INPUT_CONTRACT.json',{'files':files,'target_rows':hits,'selected_value_overrides':selected,'value_overrides_sha256':sha(R/'data/catalog_value_overrides.json'),'contracts':contracts})
versions=json.loads(IP.read_text());records=[]
for v in versions:
 rel=v['paths'][0]['path'];p=R/rel;assert sha(p)==v['sha256'];s=p.read_text();lines=s.splitlines();tree=ast.parse(s);nodes=list(ast.walk(tree));im={}
 for n in nodes:
  if isinstance(n,ast.ImportFrom):
   for a in n.names:im[a.asname or a.name]={'module':n.module,'name':a.name,'line':n.lineno}
 hooks=[n for n in nodes if isinstance(n,ast.Call)and isinstance(n.func,ast.Name)and n.func.id=='compile_old_murkeye_aura']
 rec={'sha256':v['sha256'],'representative_path':rel,'saved_copies':len(v['paths']),'hook_count':len(hooks)}
 if hooks:
  assert len(hooks)==1;call=hooks[0];before=call.lineno;calls=[];constructors=[];direct_writes=[]
  for n in nodes:
   if getattr(n,'lineno',10**9)>=before:continue
   if isinstance(n,ast.Assign):
    for t in n.targets:
     if isinstance(t,ast.Name)and t.id=='cards':constructors.append({'line':n.lineno,'expression':ast.unparse(n.value)})
     if isinstance(t,ast.Subscript)and isinstance(t.value,ast.Name)and t.value.id=='cards':direct_writes.append({'line':n.lineno,'statement':lines[n.lineno-1]})
   if isinstance(n,ast.Call)and any(isinstance(a,ast.Name)and a.id=='cards'for a in n.args):
    name=ast.unparse(n.func);imp=im.get(name);present=(R/'tools'/(imp['module'].replace('.','/')+'.py')).exists()if imp and imp['module']else None
    calls.append({'line':n.lineno,'callee':name,'import':imp,'module_present':present})
  ev=[]
  for n in tree.body:
   if isinstance(n,(ast.For,ast.If,ast.Assign,ast.Expr))and n.lineno<=call.lineno<=getattr(n,'end_lineno',n.lineno):ev.append({'line':n.lineno,'end':n.end_lineno,'source':ast.get_source_segment(s,n)})
  rec.update({'call_line':call.lineno,'hook_arguments':[ast.unparse(x)for x in call.args],'hook_keywords':{x.arg:ast.unparse(x.value)for x in call.keywords},'preceding_line':lines[call.lineno-2].strip(),'hook_container':ev,'cards_constructors':constructors,'direct_cards_writes_before_hook':direct_writes,'calls_receiving_cards_before_hook_count':len(calls),'missing_imported_modules_receiving_cards_before_hook':sorted({c['import']['module']for c in calls if c['module_present']is False}),'first_mutator_calls':[c for c in calls if c['callee']in ('apply_recruit_quest_identity','apply_hero_value_overrides','apply_final_source_overrides')],'value_override_blocks':[{'line':n.lineno,'end':n.end_lineno,'source':ast.get_source_segment(s,n)}for n in tree.body if isinstance(n,ast.If)and n.lineno<before and 'catalog_value_overrides.json'in ast.get_source_segment(s,n)],'emit_function':[{'line':n.lineno,'source':ast.get_source_segment(s,n)}for n in tree.body if isinstance(n,ast.FunctionDef)and n.name=='emit']})
 records.append(rec);del tree,nodes;gc.collect()
relevant=[x for x in records if x['hook_count']]
summary={'versions_checked':len(records),'versions_with_hook':len(relevant),'saved_copies_with_hook':sum(x['saved_copies']for x in relevant),'all_canonical_calls':all(x['hook_arguments']==['c','cards']and x['hook_keywords']=={'root':'R'}and x['preceding_line']=='c=cards.get(identity)'for x in relevant),'all_construct_from_rows_id':all(x['cards_constructors']==[{'line':x['cards_constructors'][0]['line'],'expression':"{c['id']: c for c in raw}"}]for x in relevant),'distinct_emit_functions':len({x['emit_function'][0]['source']for x in relevant}),'distinct_hook_containers':len({x['hook_container'][0]['source']for x in relevant}),'value_overrides_present_before_all_hooks':all(x['value_override_blocks']for x in relevant),'missing_prior_module_range':[min(len(x['missing_imported_modules_receiving_cards_before_hook'])for x in relevant),max(len(x['missing_imported_modules_receiving_cards_before_hook'])for x in relevant)],'current_driver_exists':(R/'tools/build_effect_catalog.py').exists(),'historical_code_executed':False,'full_compiler_executed':False,'transitive_prior_mutation_proven':False,'max_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'source_index_sha256':sha(IP)}
save('HISTORICAL_DRIVER_TRACE.json',{'summary':summary,'records':records})
save('SUMMARY.json',{'source_proofs':{k:v for k,v in source_proofs.items()if k not in ('proofs','runtime_path_presence')},'current_input_contracts':contracts,'historical_driver_summary':summary})
print(json.dumps({'input_contracts':contracts,'historical':summary},ensure_ascii=False,indent=2))
