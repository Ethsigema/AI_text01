# Old Murk-Eye: static compiler and Catalog contract audit

## Result

The bounded Old Murk-Eye tool contract is statically closed by the current local proof packet, two complete canonical rows, and the historical driver adapter. This is not a full compiler, Catalog startup, Game, or gameplay result. No historical module or project script was executed during this audit. Only new audit programs using stdlib AST/JSON/text processing ran, capped at 128 MiB; observed peak RSS was 78,792 KiB.

The target historical Python SHA256 is `7c780b25e3a001d4b961b0c3809170097b952beeb84cf7a5d1cb19a8759588e0`; current GD SHA256 is `a6a5e40f89f1c91999a7e0b81091e8ea541a2100234cd8f3d831caa9b40d203b`. All eight proof files match both modules' identical pins. RAW/CANONICAL JSON agrees exactly with current GD constants, and both modules' EXPECTED constants agree.

## Current input contract

The current Catalog input list has 20 JSON files. Each target appears once in catalog_raw.json and once in catalog.json, and nowhere else in those inputs. Both raw rows exactly equal GD RAW; both compiled overlays exactly equal EXPECTED. Normal RAW already equals CANONICAL. Golden RAW has unresolved null attack/health. The confirmed independent golden value override supplies attack=4 and health=8, replaces those two field_status records, and adds value_override_verification. Applying that exact data transformation yields the complete CANONICAL row with no other differences.

The historical Python compile_card checks both complete CANONICAL rows, not raw rows and not already merged final rows. It returns only effects, keywords, default_pool, pool_supported, coverage_rule, implementation_status, and conditional_support. The driver emit adapter adds id, supported=true, and the text SHA256. A static data reconstruction of that adapter matches both current overlays exactly. CANONICAL plus overlay equals exactly what GD source_error expects before the allowed golden pool_blocker addition.

## Exact historical adapter

Pinned source: runtime/research/old_murkeye_aura_native_recovery/candidates/tools/build_effect_catalog.py
SHA256: e30078a81ad68c5201c7097aeecd80072d479a02854b276aa27a4f8c8de8c5cc

- Line 528: cards={c['id']:c for c in raw}
- Lines 529, 531, 532: recruit identity, hero value, final source preprocessing.
- Lines 542–549: top-level confirmed catalog_value_overrides transformation.
- Line 556: emit function.
- Lines 4157–4163: Old Murk-Eye loop; pop previous output, cards.get(identity), compile_old_murkeye_aura(c,cards,root=R), separate metadata, emit.
- Lines 4164–4165: remove target IDs from ordered_ids and reappend only successfully emitted IDs.

PINNED_AST_FRAGMENTS.json includes exact source segments, line bounds, and each segment SHA256. No fragment was executed here.

All 98 indexed driver versions and all 179 saved paths were freshly SHA256 checked. 87 versions (163 copies) contain this hook. Across those versions the hook and emit each have one exact source form, calls always use c,cards,root=R, cards is built from row IDs, and value overrides always precede the hook.

Full compiler equivalence remains outside scope: the current tools/build_effect_catalog.py is absent. The exact chosen driver has 428 earlier call sites receiving cards, including two missing named preprocessing modules recruit_quest_identity and hero_value_overrides. There are 313 absent imported modules among those earlier calls (range 313–316 across relevant versions). The direct final_source_overrides implementation is present and its explicit allowed IDs exclude both targets. Absence of hundreds of unrelated modules does not prevent testing this tool's exact canonical-input/emit adapter. It does prevent claiming an unexecuted complete historical pipeline, including all transitive alias mutations, has passed.

## Current GD order and real calls

OldMurkEye has neither apply_overlay nor closure_error. Its CANONICAL constant is an expected row baseline, not a transformation entry point.

- Catalog preloads OldMurkEye at line 720 and BoardAura at 789.
- Lines 1604–1605 hash each OldMurkEye.RUNTIME_PATHS entry into fingerprints. The missing Python path is listed here; it is not one of the eight proof_error hash pins.
- Before compiled catalog input, Catalog applies DamageRegistry metadata, QuestIdentity, FinalSource, then HeroValues (2187–2202).
- For each noncompiled target raw row, raw_source_error is called at 11696–11698. It checks the complete RAW and eight proof hashes.
- Lines 11810–11822 merge the source/overlay and normalize only the five top-level numeric fields tier,attack,health,cost,armor, with common text/eligibility checks.
- Other family apply_overlay methods run afterward; there is no OldMurkEye.apply_overlay call.
- Lines 12131–12140 apply confirmed catalog_value_overrides. This yields the source CANONICAL portion after the overlay has already been merged.
- Pool eligibility subsequently adds PoolIdentity.MINION_REASON to the golden row as pool_blocker. source_error allows exactly that additional field/value for the golden ID.
- Lines 12296–12299 invoke OldMurkEye.source_error on supported targets; failure demotes support/pool flags and records a coverage blocker.
- The supported-card family pass calls _event_family_source_error at 14431. Its BoardAura branch at 19152–19159 builds a dictionary containing the current row plus normal/golden partner obtained by get_card, then calls BoardAura.source_closure_error.
- _validate_effects uses BoardAura.effect_error at 18140–18142. BoardAura.effect_error dispatches OldMurkEye effects to OldMurkEye.effect_error at board_aura_effects.gd:467.

## BoardAura closure

source_closure_error (586–609) -> room_source_error (553–584) -> _definition_error (496–542) -> OldMurkEye.source_error (498). It validates each partner separately and requires consistent tier/custom-shop shape. For the two target rows there are no custom-shop metadata fields, no unreviewed dependencies/conflicts, and all exact source specs, native values, pair links, verification statuses, supported and eligibility flags match. BOARD_AURA_STATIC_CONTRACT.json records these data checks; no GD execution is claimed.

A small isolated project can use the complete byte-identical board_aura_effects.gd and its static preload closure: 10 GD files, 259,248 bytes, every file present, no Game/Combat/Catalog preload. BOARD_AURA_DEPENDENCIES.json contains exact file hashes and edges. For only these targets, source_error reads the eight Old Murk-Eye proof files. Thus copying those ten GD files and eight proof files preserves the real closure entry point without loading the application. Other family proof files are not read by the Old Murk-Eye closure path. This is a viable next test, not a test performed here.

## Bounds and integrity

No runtime, backup, cancelled remote operation, or existing audit file was modified. No network calls were made. Filesystem AGENTS.md discovery returned no files; .agents and .codex exist but contain no skill/instruction files. The relevant available software-engineering skill was read. No private chat, credential, or cache files were read.

New evidence directory: old_murkeye_callchain_audit_20261109T224600Z. Useful entry points: SUMMARY.json, PINNED_AST_FRAGMENTS.json, CURRENT_INPUT_CONTRACT.json, SOURCE_PROOFS.json, BOARD_AURA_DEPENDENCIES.json, CATALOG_EXCERPTS.txt, and HISTORICAL_DRIVER_TRACE.json.
