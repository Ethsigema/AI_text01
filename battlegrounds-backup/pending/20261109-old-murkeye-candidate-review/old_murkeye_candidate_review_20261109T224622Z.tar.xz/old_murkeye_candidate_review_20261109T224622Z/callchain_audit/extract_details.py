from pathlib import Path
import ast,json,re,hashlib,resource
resource.setrlimit(resource.RLIMIT_AS,(128*1024*1024,128*1024*1024))
H=Path(__file__).resolve().parent;R=H.parent/'historical_tools_batch14_20261109T191857Z/runtime'
IP=H.parent/'historical_tools_batch16_driver_closeout_20261109T205039Z/compiler/CURRENT_VERSIONS.json'
def digest(p):
 h=hashlib.sha256()
 with p.open('rb')as f:
  for b in iter(lambda:f.read(262144),b''):h.update(b)
 return h.hexdigest()
def write(n,v):(H/n).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
versions=json.loads(IP.read_text()); paths=[]
for v in versions:
 for p in v['paths']:
  a=digest(R/p['path']);paths.append({'path':p['path'],'sha256':a,'expected':v['sha256'],'matches':a==v['sha256']})
write('DRIVER_COPY_PINS.json',{'paths':paths,'copies_checked':len(paths),'all_match':all(x['matches']for x in paths)})
rel='research/old_murkeye_aura_native_recovery/candidates/tools/build_effect_catalog.py';s=(R/rel).read_text();t=ast.parse(s);selected=[]
for n in t.body:
 keep=(isinstance(n,ast.FunctionDef)and n.name=='emit')or (isinstance(n,ast.If)and 'catalog_value_overrides.json'in ast.get_source_segment(s,n))or (isinstance(n,ast.For)and isinstance(n.iter,ast.Name)and n.iter.id=='OLD_MURKEYE_AURA_IDS')or (n.lineno in [4164,4165])
 if keep:
  seg=ast.get_source_segment(s,n);selected.append({'kind':type(n).__name__,'start_line':n.lineno,'end_line':n.end_lineno,'source':seg,'source_segment_sha256':hashlib.sha256(seg.encode()).hexdigest()})
write('PINNED_AST_FRAGMENTS.json',{'source_path':rel,'source_sha256':digest(R/rel),'nodes':selected,'executed':False})
g=(R/'core/board_aura_effects.gd').read_text();start=g.index('{',g.index('const SOURCE_SPECS:'));specs=json.JSONDecoder().raw_decode(g[start:])[0]
rowdata=json.loads((H/'CURRENT_INPUT_CONTRACT.json').read_text());ids=['BG_EX1_062','TB_BaconUps_036'];final={}
for i in ids:
 raw=next(x['row']for x in rowdata['target_rows']if x['path']=='data/catalog_raw.json'and x['id']==i)
 for ov in rowdata['selected_value_overrides']:
  if ov['id']==i:
   for k,v in ov['fields'].items():raw[k]=v;raw['field_status'][k]={'value':v,'status':'known','verification':'confirmed_independent_entity'}
   raw['value_override_verification']=ov['verification']
 raw.update(next(x['row']for x in rowdata['target_rows']if x['path']=='data/catalog.json'and x['id']==i));final[i]=raw
checks={}
for i in ids:
 c=final[i];spec=specs[i];same_fields=['text','is_golden','normal_id','golden_id','tribes','effects','keywords'];checks[i]={'spec':spec,'exact_spec_fields':all(c.get(k)==spec[k]for k in same_fields),'native_values_match': [c[k]for k in ['tier','attack','health']]==spec['native'],'correct_identity':c['id']==c['card_code']==i and c['dbf_id']==spec['dbf_id']and c['kind']=='minion','supported_bool_true':c.get('supported')is True,'eligibility_flags_clear':all(c.get(k,False)is False for k in ['excluded','duos_exclusive','requires_teammate_effect','stats_conflict']),'solo_eligible':c.get('solo_eligible')is True,'no_dependency_fields':all(not c.get(k)for k in ['source_conflicts','dependencies','dependency_ids','required_card_ids','requires_cards']),'no_custom_shop_fields':not any(k in c for k in ['source_shop_fields','custom_shop_override','custom_shop_derived_from']),'status_values_verified':all(c['field_status'][k].get('status','known')not in ['unverified','conflict','unknown']and c['field_status'][k].get('value',c[k])==c[k]for k in ['tier','attack','health'])}
write('BOARD_AURA_STATIC_CONTRACT.json',{'checks':checks,'pair_tier_equal':final[ids[0]]['tier']==final[ids[1]]['tier'],'note':'Data equality and source text audit only; no GDScript executed.'})
catalog=(R/'core/catalog.gd').read_text().splitlines();spans=[(719,721),(1602,1606),(2187,2202),(11691,11701),(11808,11824),(12125,12144),(12162,12182),(12292,12302),(19148,19160)];out=[]
for a,b in spans:out.append('\n'.join(f'{i}: {catalog[i-1]}'for i in range(a,b+1)))
(H/'CATALOG_EXCERPTS.txt').write_text('\n\n'.join(out)+'\n')
print(json.dumps({'copies_checked':len(paths),'all_copies_match':all(x['matches']for x in paths),'fragments':[(n['start_line'],n['end_line'])for n in selected],'board_aura_checks':checks},ensure_ascii=False,indent=2))
