"""Replay the bounded correction tests in a fresh directory, without the source tree."""
from pathlib import Path
import hashlib,json,subprocess,sys
H=Path(__file__).resolve().parent
assert len(sys.argv)==2,'Provide one new nonexistent destination directory'
D=Path(sys.argv[1]).resolve();assert not D.exists();D.mkdir(parents=True)
manifest=json.loads((H/'REPLAY_INPUTS.json').read_text())
for rel,pin in manifest.items():
 s=H/rel;b=s.read_bytes();assert len(b)==pin['bytes'] and hashlib.sha256(b).hexdigest()==pin['sha256']
 p=D/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b);assert s.stat().st_ino!=p.stat().st_ino
for script in ['test_python.py','test_driver_fragments.py','run_godot.py']:
 subprocess.run([sys.executable,'-B',str(D/script)],check=True)
py=json.loads((D/'PYTHON_REPORT.json').read_text());gd=json.loads((D/'GODOT_first.json').read_text())
assert py['case_count']==4903 and py['stages']['canonical']['newly_accepted']==114
assert not gd['failures'] and gd['positive_compiled_pair_source_and_closure_checks']==234
assert gd==json.loads((D/'GODOT_repeat.json').read_text())
for rel,pin in manifest.items():
 if rel.startswith(('original_inputs/','gd_minimal/core/','gd_minimal/research/','candidate/')):
  assert hashlib.sha256((D/rel).read_bytes()).hexdigest()==pin['sha256']
report={'status':'PASS_BOUNDED_ISOLATED_REPLAY_NOT_INSTALLATION_APPROVAL','destination':str(D),'copied_files':len(manifest),'source_tree_required':False,'source_tree_modified':False,'main_cases':4903,'canonical_compile_cases':2468,'candidate_gd_mismatches':0,'numeric_float_admission_corrections':114,'real_pair_closure_positive_checks':234,'full_compiler_catalog_game_save_run':False,'candidate_installed':False}
(D/'REPLAY_RESULT.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
