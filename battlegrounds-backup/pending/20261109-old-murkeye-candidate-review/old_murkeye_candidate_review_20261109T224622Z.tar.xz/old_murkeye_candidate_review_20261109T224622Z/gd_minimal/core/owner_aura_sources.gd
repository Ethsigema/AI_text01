extends RefCounted
## Exact owner-source program for conditional board admission; unresolved zone observers remain gated.
const TYPE: String = "mechanism_owner_aura"
const STATE_KEY: String = "owner_aura_state"
const MAX_STAT: int = 9223372036854775807
const PREFIX: String = "owner-aura:"
const RAW_PROJECTION: Dictionary = {"BG24_Reward_125":{"id":"BG24_Reward_125","card_code":"BG24_Reward_125","identity_type":"source_card_code","dbf_id":"90865","name":"冒烟的枪","kind":"reward","category":"任务奖励","categories":["任务奖励"],"kinds":["reward"],"source_sheets":["任务"],"source_groups":["mechanisms"],"mechanisms":["任务"],"tier":null,"attack":null,"health":null,"cost":0,"armor":null,"armor_by_mode":{},"text":"你的随从拥有+4攻击力。","tribes":[],"keywords":[],"variant":"普通","is_golden":false,"golden_id":null,"normal_id":null,"image":"res://assets/cards/BG24_Reward_125.jpg","images":[{"path":"res://assets/cards/BG24_Reward_125.jpg","sha256":"5ee7b91e9a297abb62da5daff4c834caeda2fd338f528b294e60351e3a60ec39","xlsx_media_part":"xl/media/image1030.jpg","row":45,"column_zero_based":4,"size_bytes":4573}],"source_url":"https://wiki.ifindhs.com/index.php?title=酒馆战棋/冒烟的枪&oldid=112876","source":"https://wiki.ifindhs.com/index.php?title=酒馆战棋/冒烟的枪&oldid=112876","source_urls":["https://wiki.ifindhs.com/index.php?title=酒馆战棋/冒烟的枪&oldid=112876"],"verification_source_urls":[],"image_source_url":"http://search.ifindhs.com/pics/latest/BG24_Reward_125.png","fields":{"tier":null,"attack":null,"health":null,"cost":0,"armor":null,"race":"","variant":"普通","status":"机制池","text":"你的随从拥有+4攻击力。","acquisition":"完成任务获得奖励\n仅对应机制或明确的特殊生成来源","restrictions":"完成任务获得奖励\n仅对应机制或明确的特殊生成来源","pool_tag":"奖励","related_content":"","notes":"","updated_at":"2023-09-13 Patch27.4.0.185749","prize_tier":null,"cost_currency":null,"timewarped":null,"applicable_modes":null},"raw_fields":{"名称":"冒烟的枪","类别":"任务奖励","任务要求 / 奖励效果":"你的随从拥有+4攻击力。","获取方式 / 限定条件":"完成任务获得奖励\n仅对应机制或明确的特殊生成来源","图像":"","费用":0,"版本":"普通","状态":"机制池","选择池 / 等级标记":"奖励","获取来源 / 关联英雄":"","衍生物 / 关联内容":"","最终更新":"2023-09-13 Patch27.4.0.185749","卡牌代码 / ID":"BG24_Reward_125\n90865","核实备注":"","来源":"https://wiki.ifindhs.com/index.php?title=酒馆战棋/冒烟的枪&oldid=112876","获取 / 核验来源链接":"","图片来源":"http://search.ifindhs.com/pics/latest/BG24_Reward_125.png"},"field_status":{"tier":{"raw":"","value":null,"status":"blank_or_not_applicable","verification":null,"value_source":null},"attack":{"raw":"","value":null,"status":"blank_or_not_applicable","verification":null,"value_source":null},"health":{"raw":"","value":null,"status":"blank_or_not_applicable","verification":null,"value_source":null},"cost":{"raw":0,"value":0,"status":"known","verification":null,"value_source":null},"armor":{"raw":"","value":null,"status":"blank_or_not_applicable","verification":null,"value_source":null}},"quality_flags":[],"historical_abilities":[],"provenance":{"workbook":"限时机制.xlsx","library_file_id":"libfile_80439ad8142c8191a11c1a8ee066d07c","version":1,"sheet":"任务","row":45,"source_catalog_file":"res://data/source_catalog/mechanisms.json"},"occurrences":[{"provenance":{"workbook":"限时机制.xlsx","library_file_id":"libfile_80439ad8142c8191a11c1a8ee066d07c","version":1,"sheet":"任务","row":45,"source_catalog_file":"res://data/source_catalog/mechanisms.json"},"raw_fields":{"名称":"冒烟的枪","类别":"任务奖励","任务要求 / 奖励效果":"你的随从拥有+4攻击力。","获取方式 / 限定条件":"完成任务获得奖励\n仅对应机制或明确的特殊生成来源","图像":"","费用":0,"版本":"普通","状态":"机制池","选择池 / 等级标记":"奖励","获取来源 / 关联英雄":"","衍生物 / 关联内容":"","最终更新":"2023-09-13 Patch27.4.0.185749","卡牌代码 / ID":"BG24_Reward_125\n90865","核实备注":"","来源":"https://wiki.ifindhs.com/index.php?title=酒馆战棋/冒烟的枪&oldid=112876","获取 / 核验来源链接":"","图片来源":"http://search.ifindhs.com/pics/latest/BG24_Reward_125.png"},"images":[{"path":"res://assets/cards/BG24_Reward_125.jpg","sha256":"5ee7b91e9a297abb62da5daff4c834caeda2fd338f528b294e60351e3a60ec39","xlsx_media_part":"xl/media/image1030.jpg","row":45,"column_zero_based":4,"size_bytes":4573}]}],"source_conflicts":[],"supplemental_evidence_key":null,"status":"机制池","notes":"","solo_eligible":true,"duos_exclusive":false,"requires_teammate_effect":false,"mode_evidence":{"latest_client":{"card_code":"BG24_Reward_125","dbf_id":"90865","duos_exclusive":false,"tag_3166":null,"source_url":"https://raw.githubusercontent.com/HearthSim/hsdata/27fbd2323aec20cab1c6ecc7d5f55cf12729f956/CardDefs.Bacon.xml"},"workbook_applicable_modes":null,"effect_requires_team_mechanism":false,"basis":"Current exclusivity flag and explicit source mode/effect text. No duo-to-solo rewrite."}},"BG30_MagicItem_843t":{"id":"BG30_MagicItem_843t","card_code":"BG30_MagicItem_843t","identity_type":"source_card_code","dbf_id":"115251","name":"部落钥匙链","kind":"trinket","category":"大型饰品","categories":["大型饰品"],"kinds":["trinket"],"source_sheets":["酒馆饰品"],"source_groups":["mechanisms"],"mechanisms":["酒馆饰品"],"tier":null,"attack":null,"health":null,"cost":2,"armor":null,"armor_by_mode":{},"text":"你的等级3或更低的随从拥有+7/+5。","tribes":[],"keywords":[],"variant":"普通","is_golden":false,"golden_id":null,"normal_id":null,"image":"res://assets/cards/BG30_MagicItem_843t.jpg","images":[{"path":"res://assets/cards/BG30_MagicItem_843t.jpg","sha256":"b27ffc2202fe3aab1deb3a080cc644a55da09d5a9e26ea366498d6fef69d4030","xlsx_media_part":"xl/media/image767.jpg","row":353,"column_zero_based":6,"size_bytes":5335}],"source_url":"https://wiki.ifindhs.com/index.php?title=酒馆战棋/部落钥匙链&oldid=155287","source":"https://wiki.ifindhs.com/index.php?title=酒馆战棋/部落钥匙链&oldid=155287","source_urls":["https://wiki.ifindhs.com/index.php?title=酒馆战棋/部落钥匙链&oldid=155287"],"verification_source_urls":[],"image_source_url":"http://search.ifindhs.com/pics/latest/BG30_MagicItem_843t.png","fields":{"tier":null,"attack":null,"health":null,"cost":2,"armor":null,"race":"","variant":"普通","status":"机制池","text":"你的等级3或更低的随从拥有+7/+5。","acquisition":"饰品选择\n仅对应机制或明确的特殊生成来源","restrictions":"饰品选择\n仅对应机制或明确的特殊生成来源","pool_tag":"野兽, 亡灵","related_content":"","notes":"","updated_at":"2024-08-30 Patch30.2.2.206433","prize_tier":null,"cost_currency":null,"timewarped":null,"applicable_modes":null},"raw_fields":{"名称":"部落钥匙链","类别":"大型饰品","饰品种族标签":"","费用":2,"效果":"你的等级3或更低的随从拥有+7/+5。","获取方式 / 限定条件":"饰品选择\n仅对应机制或明确的特殊生成来源","图像":"","版本":"普通","状态":"机制池","选择池 / 等级标记":"野兽, 亡灵","获取来源 / 关联英雄":"","衍生物 / 关联内容":"","最终更新":"2024-08-30 Patch30.2.2.206433","卡牌代码 / ID":"BG30_MagicItem_843t\n115251","核实备注":"","来源":"https://wiki.ifindhs.com/index.php?title=酒馆战棋/部落钥匙链&oldid=155287","获取 / 核验来源链接":"","图片来源":"http://search.ifindhs.com/pics/latest/BG30_MagicItem_843t.png"},"field_status":{"tier":{"raw":"","value":null,"status":"blank_or_not_applicable","verification":null,"value_source":null},"attack":{"raw":"","value":null,"status":"blank_or_not_applicable","verification":null,"value_source":null},"health":{"raw":"","value":null,"status":"blank_or_not_applicable","verification":null,"value_source":null},"cost":{"raw":2,"value":2,"status":"known","verification":null,"value_source":null},"armor":{"raw":"","value":null,"status":"blank_or_not_applicable","verification":null,"value_source":null}},"quality_flags":[],"historical_abilities":[],"provenance":{"workbook":"限时机制.xlsx","library_file_id":"libfile_80439ad8142c8191a11c1a8ee066d07c","version":1,"sheet":"酒馆饰品","row":353,"source_catalog_file":"res://data/source_catalog/mechanisms.json"},"occurrences":[{"provenance":{"workbook":"限时机制.xlsx","library_file_id":"libfile_80439ad8142c8191a11c1a8ee066d07c","version":1,"sheet":"酒馆饰品","row":353,"source_catalog_file":"res://data/source_catalog/mechanisms.json"},"raw_fields":{"名称":"部落钥匙链","类别":"大型饰品","饰品种族标签":"","费用":2,"效果":"你的等级3或更低的随从拥有+7/+5。","获取方式 / 限定条件":"饰品选择\n仅对应机制或明确的特殊生成来源","图像":"","版本":"普通","状态":"机制池","选择池 / 等级标记":"野兽, 亡灵","获取来源 / 关联英雄":"","衍生物 / 关联内容":"","最终更新":"2024-08-30 Patch30.2.2.206433","卡牌代码 / ID":"BG30_MagicItem_843t\n115251","核实备注":"","来源":"https://wiki.ifindhs.com/index.php?title=酒馆战棋/部落钥匙链&oldid=155287","获取 / 核验来源链接":"","图片来源":"http://search.ifindhs.com/pics/latest/BG30_MagicItem_843t.png"},"images":[{"path":"res://assets/cards/BG30_MagicItem_843t.jpg","sha256":"b27ffc2202fe3aab1deb3a080cc644a55da09d5a9e26ea366498d6fef69d4030","xlsx_media_part":"xl/media/image767.jpg","row":353,"column_zero_based":6,"size_bytes":5335}]}],"source_conflicts":[],"supplemental_evidence_key":null,"status":"机制池","notes":"","solo_eligible":true,"duos_exclusive":false,"requires_teammate_effect":false,"mode_evidence":{"latest_client":{"card_code":"BG30_MagicItem_843t","dbf_id":"115251","duos_exclusive":false,"tag_3166":null,"source_url":"https://raw.githubusercontent.com/HearthSim/hsdata/27fbd2323aec20cab1c6ecc7d5f55cf12729f956/CardDefs.Bacon.xml"},"workbook_applicable_modes":null,"effect_requires_team_mechanism":false,"basis":"Current exclusivity flag and explicit source mode/effect text. No duo-to-solo rewrite."}},"BG30_MagicItem_880":{"id":"BG30_MagicItem_880","card_code":"BG30_MagicItem_880","identity_type":"source_card_code","dbf_id":"111211","name":"野性护身符","kind":"trinket","category":"小型饰品","categories":["小型饰品"],"kinds":["trinket"],"source_sheets":["酒馆饰品"],"source_groups":["mechanisms"],"mechanisms":["酒馆饰品"],"tier":null,"attack":null,"health":null,"cost":2,"armor":null,"armor_by_mode":{},"text":"你的随从拥有+2/+1。","tribes":[],"keywords":[],"variant":"普通","is_golden":false,"golden_id":null,"normal_id":null,"image":"res://assets/cards/BG30_MagicItem_880.jpg","images":[{"path":"res://assets/cards/BG30_MagicItem_880.jpg","sha256":"b9be4294d500d219cb3a489f0a42a597445ebdf52098a7ae2cc6ee3e56feebb0","xlsx_media_part":"xl/media/image629.jpg","row":215,"column_zero_based":6,"size_bytes":5095}],"source_url":"https://wiki.ifindhs.com/index.php?title=酒馆战棋/野性护身符&oldid=165685","source":"https://wiki.ifindhs.com/index.php?title=酒馆战棋/野性护身符&oldid=165685","source_urls":["https://wiki.ifindhs.com/index.php?title=酒馆战棋/野性护身符&oldid=165685"],"verification_source_urls":[],"image_source_url":"http://search.ifindhs.com/pics/latest/BG30_MagicItem_880.png","fields":{"tier":null,"attack":null,"health":null,"cost":2,"armor":null,"race":"","variant":"普通","status":"机制池","text":"你的随从拥有+2/+1。","acquisition":"饰品选择\n仅对应机制或明确的特殊生成来源","restrictions":"饰品选择\n仅对应机制或明确的特殊生成来源","pool_tag":"野兽, 亡灵","related_content":"","notes":"","updated_at":"2024-08-30 Patch30.2.2.206433","prize_tier":null,"cost_currency":null,"timewarped":null,"applicable_modes":null},"raw_fields":{"名称":"野性护身符","类别":"小型饰品","饰品种族标签":"","费用":2,"效果":"你的随从拥有+2/+1。","获取方式 / 限定条件":"饰品选择\n仅对应机制或明确的特殊生成来源","图像":"","版本":"普通","状态":"机制池","选择池 / 等级标记":"野兽, 亡灵","获取来源 / 关联英雄":"","衍生物 / 关联内容":"","最终更新":"2024-08-30 Patch30.2.2.206433","卡牌代码 / ID":"BG30_MagicItem_880\n111211","核实备注":"","来源":"https://wiki.ifindhs.com/index.php?title=酒馆战棋/野性护身符&oldid=165685","获取 / 核验来源链接":"","图片来源":"http://search.ifindhs.com/pics/latest/BG30_MagicItem_880.png"},"field_status":{"tier":{"raw":"","value":null,"status":"blank_or_not_applicable","verification":null,"value_source":null},"attack":{"raw":"","value":null,"status":"blank_or_not_applicable","verification":null,"value_source":null},"health":{"raw":"","value":null,"status":"blank_or_not_applicable","verification":null,"value_source":null},"cost":{"raw":2,"value":2,"status":"known","verification":null,"value_source":null},"armor":{"raw":"","value":null,"status":"blank_or_not_applicable","verification":null,"value_source":null}},"quality_flags":[],"historical_abilities":[],"provenance":{"workbook":"限时机制.xlsx","library_file_id":"libfile_80439ad8142c8191a11c1a8ee066d07c","version":1,"sheet":"酒馆饰品","row":215,"source_catalog_file":"res://data/source_catalog/mechanisms.json"},"occurrences":[{"provenance":{"workbook":"限时机制.xlsx","library_file_id":"libfile_80439ad8142c8191a11c1a8ee066d07c","version":1,"sheet":"酒馆饰品","row":215,"source_catalog_file":"res://data/source_catalog/mechanisms.json"},"raw_fields":{"名称":"野性护身符","类别":"小型饰品","饰品种族标签":"","费用":2,"效果":"你的随从拥有+2/+1。","获取方式 / 限定条件":"饰品选择\n仅对应机制或明确的特殊生成来源","图像":"","版本":"普通","状态":"机制池","选择池 / 等级标记":"野兽, 亡灵","获取来源 / 关联英雄":"","衍生物 / 关联内容":"","最终更新":"2024-08-30 Patch30.2.2.206433","卡牌代码 / ID":"BG30_MagicItem_880\n111211","核实备注":"","来源":"https://wiki.ifindhs.com/index.php?title=酒馆战棋/野性护身符&oldid=165685","获取 / 核验来源链接":"","图片来源":"http://search.ifindhs.com/pics/latest/BG30_MagicItem_880.png"},"images":[{"path":"res://assets/cards/BG30_MagicItem_880.jpg","sha256":"b9be4294d500d219cb3a489f0a42a597445ebdf52098a7ae2cc6ee3e56feebb0","xlsx_media_part":"xl/media/image629.jpg","row":215,"column_zero_based":6,"size_bytes":5095}]}],"source_conflicts":[],"supplemental_evidence_key":null,"status":"机制池","notes":"","solo_eligible":true,"duos_exclusive":false,"requires_teammate_effect":false,"mode_evidence":{"latest_client":{"card_code":"BG30_MagicItem_880","dbf_id":"111211","duos_exclusive":false,"tag_3166":null,"source_url":"https://raw.githubusercontent.com/HearthSim/hsdata/27fbd2323aec20cab1c6ecc7d5f55cf12729f956/CardDefs.Bacon.xml"},"workbook_applicable_modes":null,"effect_requires_team_mechanism":false,"basis":"Current exclusivity flag and explicit source mode/effect text. No duo-to-solo rewrite."}},"BG30_MagicItem_880t":{"id":"BG30_MagicItem_880t","card_code":"BG30_MagicItem_880t","identity_type":"source_card_code","dbf_id":"111250","name":"野性护身符","kind":"trinket","category":"大型饰品","categories":["大型饰品"],"kinds":["trinket"],"source_sheets":["酒馆饰品"],"source_groups":["mechanisms"],"mechanisms":["酒馆饰品"],"tier":null,"attack":null,"health":null,"cost":1,"armor":null,"armor_by_mode":{},"text":"你的随从拥有+8/+5。","tribes":[],"keywords":[],"variant":"普通","is_golden":false,"golden_id":null,"normal_id":null,"image":"res://assets/cards/BG30_MagicItem_880t.jpg","images":[{"path":"res://assets/cards/BG30_MagicItem_880t.jpg","sha256":"73582fe788affc5a46f8ceafb38bb0f329a9e85f6c4b901cd23eb79bc9d069a6","xlsx_media_part":"xl/media/image741.jpg","row":327,"column_zero_based":6,"size_bytes":5121}],"source_url":"https://wiki.ifindhs.com/index.php?title=酒馆战棋/野性护身符（大型饰品）&oldid=165636","source":"https://wiki.ifindhs.com/index.php?title=酒馆战棋/野性护身符（大型饰品）&oldid=165636","source_urls":["https://wiki.ifindhs.com/index.php?title=酒馆战棋/野性护身符（大型饰品）&oldid=165636"],"verification_source_urls":[],"image_source_url":"http://search.ifindhs.com/pics/latest/BG30_MagicItem_880t.png","fields":{"tier":null,"attack":null,"health":null,"cost":1,"armor":null,"race":"","variant":"普通","status":"机制池","text":"你的随从拥有+8/+5。","acquisition":"饰品选择\n仅对应机制或明确的特殊生成来源","restrictions":"饰品选择\n仅对应机制或明确的特殊生成来源","pool_tag":"野兽, 亡灵","related_content":"","notes":"","updated_at":"2025-05-14 Patch32.2.2.221175","prize_tier":null,"cost_currency":null,"timewarped":null,"applicable_modes":null},"raw_fields":{"名称":"野性护身符","类别":"大型饰品","饰品种族标签":"","费用":1,"效果":"你的随从拥有+8/+5。","获取方式 / 限定条件":"饰品选择\n仅对应机制或明确的特殊生成来源","图像":"","版本":"普通\n大型饰品","状态":"机制池","选择池 / 等级标记":"野兽, 亡灵","获取来源 / 关联英雄":"","衍生物 / 关联内容":"","最终更新":"2025-05-14 Patch32.2.2.221175","卡牌代码 / ID":"BG30_MagicItem_880t\n111250","核实备注":"","来源":"https://wiki.ifindhs.com/index.php?title=酒馆战棋/野性护身符（大型饰品）&oldid=165636","获取 / 核验来源链接":"","图片来源":"http://search.ifindhs.com/pics/latest/BG30_MagicItem_880t.png"},"field_status":{"tier":{"raw":"","value":null,"status":"blank_or_not_applicable","verification":null,"value_source":null},"attack":{"raw":"","value":null,"status":"blank_or_not_applicable","verification":null,"value_source":null},"health":{"raw":"","value":null,"status":"blank_or_not_applicable","verification":null,"value_source":null},"cost":{"raw":1,"value":1,"status":"known","verification":null,"value_source":null},"armor":{"raw":"","value":null,"status":"blank_or_not_applicable","verification":null,"value_source":null}},"quality_flags":[],"historical_abilities":[],"provenance":{"workbook":"限时机制.xlsx","library_file_id":"libfile_80439ad8142c8191a11c1a8ee066d07c","version":1,"sheet":"酒馆饰品","row":327,"source_catalog_file":"res://data/source_catalog/mechanisms.json"},"occurrences":[{"provenance":{"workbook":"限时机制.xlsx","library_file_id":"libfile_80439ad8142c8191a11c1a8ee066d07c","version":1,"sheet":"酒馆饰品","row":327,"source_catalog_file":"res://data/source_catalog/mechanisms.json"},"raw_fields":{"名称":"野性护身符","类别":"大型饰品","饰品种族标签":"","费用":1,"效果":"你的随从拥有+8/+5。","获取方式 / 限定条件":"饰品选择\n仅对应机制或明确的特殊生成来源","图像":"","版本":"普通\n大型饰品","状态":"机制池","选择池 / 等级标记":"野兽, 亡灵","获取来源 / 关联英雄":"","衍生物 / 关联内容":"","最终更新":"2025-05-14 Patch32.2.2.221175","卡牌代码 / ID":"BG30_MagicItem_880t\n111250","核实备注":"","来源":"https://wiki.ifindhs.com/index.php?title=酒馆战棋/野性护身符（大型饰品）&oldid=165636","获取 / 核验来源链接":"","图片来源":"http://search.ifindhs.com/pics/latest/BG30_MagicItem_880t.png"},"images":[{"path":"res://assets/cards/BG30_MagicItem_880t.jpg","sha256":"73582fe788affc5a46f8ceafb38bb0f329a9e85f6c4b901cd23eb79bc9d069a6","xlsx_media_part":"xl/media/image741.jpg","row":327,"column_zero_based":6,"size_bytes":5121}]}],"source_conflicts":[],"supplemental_evidence_key":null,"status":"机制池","notes":"","solo_eligible":true,"duos_exclusive":false,"requires_teammate_effect":false,"mode_evidence":{"latest_client":{"card_code":"BG30_MagicItem_880t","dbf_id":"111250","duos_exclusive":false,"tag_3166":null,"source_url":"https://raw.githubusercontent.com/HearthSim/hsdata/27fbd2323aec20cab1c6ecc7d5f55cf12729f956/CardDefs.Bacon.xml"},"workbook_applicable_modes":null,"effect_requires_team_mechanism":false,"basis":"Current exclusivity flag and explicit source mode/effect text. No duo-to-solo rewrite."}},"BG30_MagicItem_989":{"id":"BG30_MagicItem_989","card_code":"BG30_MagicItem_989","identity_type":"source_card_code","dbf_id":"112014","name":"艺匠之瓮","kind":"trinket","category":"小型饰品","categories":["小型饰品"],"kinds":["trinket"],"source_sheets":["酒馆饰品"],"source_groups":["mechanisms"],"mechanisms":["酒馆饰品"],"tier":null,"attack":null,"health":null,"cost":1,"armor":null,"armor_by_mode":{},"text":"你的亡灵拥有+3攻击力。","tribes":[],"keywords":[],"variant":"普通","is_golden":false,"golden_id":null,"normal_id":null,"image":"res://assets/cards/BG30_MagicItem_989.jpg","images":[{"path":"res://assets/cards/BG30_MagicItem_989.jpg","sha256":"f50bc1aa67ab2bbb20c7f1ade7b2ab3a691237786315dfca0b679e843df6b306","xlsx_media_part":"xl/media/image598.jpg","row":184,"column_zero_based":6,"size_bytes":5173}],"source_url":"https://wiki.ifindhs.com/index.php?title=酒馆战棋/艺匠之瓮&oldid=155245","source":"https://wiki.ifindhs.com/index.php?title=酒馆战棋/艺匠之瓮&oldid=155245","source_urls":["https://wiki.ifindhs.com/index.php?title=酒馆战棋/艺匠之瓮&oldid=155245"],"verification_source_urls":[],"image_source_url":"http://search.ifindhs.com/pics/latest/BG30_MagicItem_989.png","fields":{"tier":null,"attack":null,"health":null,"cost":1,"armor":null,"race":"","variant":"普通","status":"机制池","text":"你的亡灵拥有+3攻击力。","acquisition":"饰品选择\n仅对应机制或明确的特殊生成来源","restrictions":"饰品选择\n仅对应机制或明确的特殊生成来源","pool_tag":"亡灵","related_content":"","notes":"","updated_at":"2025-08-06 Patch33.2.0.225406","prize_tier":null,"cost_currency":null,"timewarped":null,"applicable_modes":null},"raw_fields":{"名称":"艺匠之瓮","类别":"小型饰品","饰品种族标签":"","费用":1,"效果":"你的亡灵拥有+3攻击力。","获取方式 / 限定条件":"饰品选择\n仅对应机制或明确的特殊生成来源","图像":"","版本":"普通","状态":"机制池","选择池 / 等级标记":"亡灵","获取来源 / 关联英雄":"","衍生物 / 关联内容":"","最终更新":"2025-08-06 Patch33.2.0.225406","卡牌代码 / ID":"BG30_MagicItem_989\n112014","核实备注":"","来源":"https://wiki.ifindhs.com/index.php?title=酒馆战棋/艺匠之瓮&oldid=155245","获取 / 核验来源链接":"","图片来源":"http://search.ifindhs.com/pics/latest/BG30_MagicItem_989.png"},"field_status":{"tier":{"raw":"","value":null,"status":"blank_or_not_applicable","verification":null,"value_source":null},"attack":{"raw":"","value":null,"status":"blank_or_not_applicable","verification":null,"value_source":null},"health":{"raw":"","value":null,"status":"blank_or_not_applicable","verification":null,"value_source":null},"cost":{"raw":1,"value":1,"status":"known","verification":null,"value_source":null},"armor":{"raw":"","value":null,"status":"blank_or_not_applicable","verification":null,"value_source":null}},"quality_flags":[],"historical_abilities":[],"provenance":{"workbook":"限时机制.xlsx","library_file_id":"libfile_80439ad8142c8191a11c1a8ee066d07c","version":1,"sheet":"酒馆饰品","row":184,"source_catalog_file":"res://data/source_catalog/mechanisms.json"},"occurrences":[{"provenance":{"workbook":"限时机制.xlsx","library_file_id":"libfile_80439ad8142c8191a11c1a8ee066d07c","version":1,"sheet":"酒馆饰品","row":184,"source_catalog_file":"res://data/source_catalog/mechanisms.json"},"raw_fields":{"名称":"艺匠之瓮","类别":"小型饰品","饰品种族标签":"","费用":1,"效果":"你的亡灵拥有+3攻击力。","获取方式 / 限定条件":"饰品选择\n仅对应机制或明确的特殊生成来源","图像":"","版本":"普通","状态":"机制池","选择池 / 等级标记":"亡灵","获取来源 / 关联英雄":"","衍生物 / 关联内容":"","最终更新":"2025-08-06 Patch33.2.0.225406","卡牌代码 / ID":"BG30_MagicItem_989\n112014","核实备注":"","来源":"https://wiki.ifindhs.com/index.php?title=酒馆战棋/艺匠之瓮&oldid=155245","获取 / 核验来源链接":"","图片来源":"http://search.ifindhs.com/pics/latest/BG30_MagicItem_989.png"},"images":[{"path":"res://assets/cards/BG30_MagicItem_989.jpg","sha256":"f50bc1aa67ab2bbb20c7f1ade7b2ab3a691237786315dfca0b679e843df6b306","xlsx_media_part":"xl/media/image598.jpg","row":184,"column_zero_based":6,"size_bytes":5173}]}],"source_conflicts":[],"supplemental_evidence_key":null,"status":"机制池","notes":"","solo_eligible":true,"duos_exclusive":false,"requires_teammate_effect":false,"mode_evidence":{"latest_client":{"card_code":"BG30_MagicItem_989","dbf_id":"112014","duos_exclusive":false,"tag_3166":null,"source_url":"https://raw.githubusercontent.com/HearthSim/hsdata/27fbd2323aec20cab1c6ecc7d5f55cf12729f956/CardDefs.Bacon.xml"},"workbook_applicable_modes":null,"effect_requires_team_mechanism":false,"basis":"Current exclusivity flag and explicit source mode/effect text. No duo-to-solo rewrite."}},"BG30_MagicItem_989t":{"id":"BG30_MagicItem_989t","card_code":"BG30_MagicItem_989t","identity_type":"source_card_code","dbf_id":"117157","name":"艺匠之瓮","kind":"trinket","category":"大型饰品","categories":["大型饰品"],"kinds":["trinket"],"source_sheets":["酒馆饰品"],"source_groups":["mechanisms"],"mechanisms":["酒馆饰品"],"tier":null,"attack":null,"health":null,"cost":0,"armor":null,"armor_by_mode":{},"text":"你的亡灵拥有+20攻击力。","tribes":[],"keywords":[],"variant":"普通","is_golden":false,"golden_id":null,"normal_id":null,"image":"res://assets/cards/BG30_MagicItem_989t.jpg","images":[{"path":"res://assets/cards/BG30_MagicItem_989t.jpg","sha256":"e94d7daeb320b236e7d9b6bfa847a39094b8d3d24a587e71bd184217cb120af4","xlsx_media_part":"xl/media/image723.jpg","row":309,"column_zero_based":6,"size_bytes":5233}],"source_url":"https://wiki.ifindhs.com/index.php?title=酒馆战棋/艺匠之瓮（大型饰品）&oldid=172614","source":"https://wiki.ifindhs.com/index.php?title=酒馆战棋/艺匠之瓮（大型饰品）&oldid=172614","source_urls":["https://wiki.ifindhs.com/index.php?title=酒馆战棋/艺匠之瓮（大型饰品）&oldid=172614"],"verification_source_urls":[],"image_source_url":"http://search.ifindhs.com/pics/latest/BG30_MagicItem_989t.png","fields":{"tier":null,"attack":null,"health":null,"cost":0,"armor":null,"race":"","variant":"普通","status":"机制池","text":"你的亡灵拥有+20攻击力。","acquisition":"饰品选择\n仅对应机制或明确的特殊生成来源","restrictions":"饰品选择\n仅对应机制或明确的特殊生成来源","pool_tag":"亡灵","related_content":"","notes":"","updated_at":"2026-10-01 Patch36.6.3.253932","prize_tier":null,"cost_currency":null,"timewarped":null,"applicable_modes":null},"raw_fields":{"名称":"艺匠之瓮","类别":"大型饰品","饰品种族标签":"","费用":0,"效果":"你的亡灵拥有+20攻击力。","获取方式 / 限定条件":"饰品选择\n仅对应机制或明确的特殊生成来源","图像":"","版本":"普通\n大型饰品","状态":"机制池","选择池 / 等级标记":"亡灵","获取来源 / 关联英雄":"","衍生物 / 关联内容":"","最终更新":"2026-10-01 Patch36.6.3.253932","卡牌代码 / ID":"BG30_MagicItem_989t\n117157","核实备注":"","来源":"https://wiki.ifindhs.com/index.php?title=酒馆战棋/艺匠之瓮（大型饰品）&oldid=172614","获取 / 核验来源链接":"","图片来源":"http://search.ifindhs.com/pics/latest/BG30_MagicItem_989t.png"},"field_status":{"tier":{"raw":"","value":null,"status":"blank_or_not_applicable","verification":null,"value_source":null},"attack":{"raw":"","value":null,"status":"blank_or_not_applicable","verification":null,"value_source":null},"health":{"raw":"","value":null,"status":"blank_or_not_applicable","verification":null,"value_source":null},"cost":{"raw":0,"value":0,"status":"known","verification":null,"value_source":null},"armor":{"raw":"","value":null,"status":"blank_or_not_applicable","verification":null,"value_source":null}},"quality_flags":[],"historical_abilities":[],"provenance":{"workbook":"限时机制.xlsx","library_file_id":"libfile_80439ad8142c8191a11c1a8ee066d07c","version":1,"sheet":"酒馆饰品","row":309,"source_catalog_file":"res://data/source_catalog/mechanisms.json"},"occurrences":[{"provenance":{"workbook":"限时机制.xlsx","library_file_id":"libfile_80439ad8142c8191a11c1a8ee066d07c","version":1,"sheet":"酒馆饰品","row":309,"source_catalog_file":"res://data/source_catalog/mechanisms.json"},"raw_fields":{"名称":"艺匠之瓮","类别":"大型饰品","饰品种族标签":"","费用":0,"效果":"你的亡灵拥有+20攻击力。","获取方式 / 限定条件":"饰品选择\n仅对应机制或明确的特殊生成来源","图像":"","版本":"普通\n大型饰品","状态":"机制池","选择池 / 等级标记":"亡灵","获取来源 / 关联英雄":"","衍生物 / 关联内容":"","最终更新":"2026-10-01 Patch36.6.3.253932","卡牌代码 / ID":"BG30_MagicItem_989t\n117157","核实备注":"","来源":"https://wiki.ifindhs.com/index.php?title=酒馆战棋/艺匠之瓮（大型饰品）&oldid=172614","获取 / 核验来源链接":"","图片来源":"http://search.ifindhs.com/pics/latest/BG30_MagicItem_989t.png"},"images":[{"path":"res://assets/cards/BG30_MagicItem_989t.jpg","sha256":"e94d7daeb320b236e7d9b6bfa847a39094b8d3d24a587e71bd184217cb120af4","xlsx_media_part":"xl/media/image723.jpg","row":309,"column_zero_based":6,"size_bytes":5233}]}],"source_conflicts":[],"supplemental_evidence_key":null,"status":"机制池","notes":"","solo_eligible":true,"duos_exclusive":false,"requires_teammate_effect":false,"mode_evidence":{"latest_client":{"card_code":"BG30_MagicItem_989t","dbf_id":"117157","duos_exclusive":false,"tag_3166":null,"source_url":"https://raw.githubusercontent.com/HearthSim/hsdata/27fbd2323aec20cab1c6ecc7d5f55cf12729f956/CardDefs.Bacon.xml"},"workbook_applicable_modes":null,"effect_requires_team_mechanism":false,"basis":"Current exclusivity flag and explicit source mode/effect text. No duo-to-solo rewrite."}},"BG30_MagicItem_997":{"id":"BG30_MagicItem_997","card_code":"BG30_MagicItem_997","identity_type":"source_card_code","dbf_id":"112408","name":"风行者的项链","kind":"trinket","category":"小型饰品","categories":["小型饰品"],"kinds":["trinket"],"source_sheets":["酒馆饰品"],"source_groups":["mechanisms"],"mechanisms":["酒馆饰品"],"tier":null,"attack":null,"health":null,"cost":3,"armor":null,"armor_by_mode":{},"text":"在战斗中，你最左边的随从拥有+8攻击力。","tribes":[],"keywords":[],"variant":"普通","is_golden":false,"golden_id":null,"normal_id":null,"image":"res://assets/cards/BG30_MagicItem_997.jpg","images":[{"path":"res://assets/cards/BG30_MagicItem_997.jpg","sha256":"cf096bc26a5329c223df463b510d2e0177dc2f80739f784893fa7865cdcdce5d","xlsx_media_part":"xl/media/image650.jpg","row":236,"column_zero_based":6,"size_bytes":6221}],"source_url":"https://wiki.ifindhs.com/index.php?title=酒馆战棋/风行者的项链&oldid=127964","source":"https://wiki.ifindhs.com/index.php?title=酒馆战棋/风行者的项链&oldid=127964","source_urls":["https://wiki.ifindhs.com/index.php?title=酒馆战棋/风行者的项链&oldid=127964"],"verification_source_urls":[],"image_source_url":"http://search.ifindhs.com/pics/latest/BG30_MagicItem_997.png","fields":{"tier":null,"attack":null,"health":null,"cost":3,"armor":null,"race":"","variant":"普通","status":"机制池","text":"在战斗中，你最左边的随从拥有+8攻击力。","acquisition":"饰品选择\n仅对应机制或明确的特殊生成来源","restrictions":"饰品选择\n仅对应机制或明确的特殊生成来源","pool_tag":"酒馆饰品","related_content":"","notes":"","updated_at":"2024-08-21 Patch30.2.0.205267","prize_tier":null,"cost_currency":null,"timewarped":null,"applicable_modes":null},"raw_fields":{"名称":"风行者的项链","类别":"小型饰品","饰品种族标签":"","费用":3,"效果":"在战斗中，你最左边的随从拥有+8攻击力。","获取方式 / 限定条件":"饰品选择\n仅对应机制或明确的特殊生成来源","图像":"","版本":"普通","状态":"机制池","选择池 / 等级标记":"酒馆饰品","获取来源 / 关联英雄":"","衍生物 / 关联内容":"","最终更新":"2024-08-21 Patch30.2.0.205267","卡牌代码 / ID":"BG30_MagicItem_997\n112408","核实备注":"","来源":"https://wiki.ifindhs.com/index.php?title=酒馆战棋/风行者的项链&oldid=127964","获取 / 核验来源链接":"","图片来源":"http://search.ifindhs.com/pics/latest/BG30_MagicItem_997.png"},"field_status":{"tier":{"raw":"","value":null,"status":"blank_or_not_applicable","verification":null,"value_source":null},"attack":{"raw":"","value":null,"status":"blank_or_not_applicable","verification":null,"value_source":null},"health":{"raw":"","value":null,"status":"blank_or_not_applicable","verification":null,"value_source":null},"cost":{"raw":3,"value":3,"status":"known","verification":null,"value_source":null},"armor":{"raw":"","value":null,"status":"blank_or_not_applicable","verification":null,"value_source":null}},"quality_flags":[],"historical_abilities":[],"provenance":{"workbook":"限时机制.xlsx","library_file_id":"libfile_80439ad8142c8191a11c1a8ee066d07c","version":1,"sheet":"酒馆饰品","row":236,"source_catalog_file":"res://data/source_catalog/mechanisms.json"},"occurrences":[{"provenance":{"workbook":"限时机制.xlsx","library_file_id":"libfile_80439ad8142c8191a11c1a8ee066d07c","version":1,"sheet":"酒馆饰品","row":236,"source_catalog_file":"res://data/source_catalog/mechanisms.json"},"raw_fields":{"名称":"风行者的项链","类别":"小型饰品","饰品种族标签":"","费用":3,"效果":"在战斗中，你最左边的随从拥有+8攻击力。","获取方式 / 限定条件":"饰品选择\n仅对应机制或明确的特殊生成来源","图像":"","版本":"普通","状态":"机制池","选择池 / 等级标记":"酒馆饰品","获取来源 / 关联英雄":"","衍生物 / 关联内容":"","最终更新":"2024-08-21 Patch30.2.0.205267","卡牌代码 / ID":"BG30_MagicItem_997\n112408","核实备注":"","来源":"https://wiki.ifindhs.com/index.php?title=酒馆战棋/风行者的项链&oldid=127964","获取 / 核验来源链接":"","图片来源":"http://search.ifindhs.com/pics/latest/BG30_MagicItem_997.png"},"images":[{"path":"res://assets/cards/BG30_MagicItem_997.jpg","sha256":"cf096bc26a5329c223df463b510d2e0177dc2f80739f784893fa7865cdcdce5d","xlsx_media_part":"xl/media/image650.jpg","row":236,"column_zero_based":6,"size_bytes":6221}]}],"source_conflicts":[],"supplemental_evidence_key":null,"status":"机制池","notes":"","solo_eligible":true,"duos_exclusive":false,"requires_teammate_effect":false,"mode_evidence":{"latest_client":null,"workbook_applicable_modes":null,"effect_requires_team_mechanism":false,"basis":"Current exclusivity flag and explicit source mode/effect text. No duo-to-solo rewrite."}},"BG30_MagicItem_997t":{"id":"BG30_MagicItem_997t","card_code":"BG30_MagicItem_997t","identity_type":"source_card_code","dbf_id":"115228","name":"风行者的项链","kind":"trinket","category":"大型饰品","categories":["大型饰品"],"kinds":["trinket"],"source_sheets":["酒馆饰品"],"source_groups":["mechanisms"],"mechanisms":["酒馆饰品"],"tier":null,"attack":null,"health":null,"cost":3,"armor":null,"armor_by_mode":{},"text":"在战斗中，你最左边的随从拥有+15攻击力。","tribes":[],"keywords":[],"variant":"普通","is_golden":false,"golden_id":null,"normal_id":null,"image":"res://assets/cards/BG30_MagicItem_997t.jpg","images":[{"path":"res://assets/cards/BG30_MagicItem_997t.jpg","sha256":"5c1e3386f60601078be8929bcd154c10c448b7ea45a479ad985ee7ebad248cb7","xlsx_media_part":"xl/media/image675.jpg","row":261,"column_zero_based":6,"size_bytes":6230}],"source_url":"https://wiki.ifindhs.com/index.php?title=酒馆战棋/风行者的项链（大型饰品）&oldid=130254","source":"https://wiki.ifindhs.com/index.php?title=酒馆战棋/风行者的项链（大型饰品）&oldid=130254","source_urls":["https://wiki.ifindhs.com/index.php?title=酒馆战棋/风行者的项链（大型饰品）&oldid=130254"],"verification_source_urls":[],"image_source_url":"http://search.ifindhs.com/pics/latest/BG30_MagicItem_997t.png","fields":{"tier":null,"attack":null,"health":null,"cost":3,"armor":null,"race":"","variant":"普通","status":"机制池","text":"在战斗中，你最左边的随从拥有+15攻击力。","acquisition":"饰品选择\n仅对应机制或明确的特殊生成来源","restrictions":"饰品选择\n仅对应机制或明确的特殊生成来源","pool_tag":"酒馆饰品","related_content":"","notes":"","updated_at":"2024-09-27 Patch30.4.3.208182","prize_tier":null,"cost_currency":null,"timewarped":null,"applicable_modes":null},"raw_fields":{"名称":"风行者的项链","类别":"大型饰品","饰品种族标签":"","费用":3,"效果":"在战斗中，你最左边的随从拥有+15攻击力。","获取方式 / 限定条件":"饰品选择\n仅对应机制或明确的特殊生成来源","图像":"","版本":"普通\n大型饰品","状态":"机制池","选择池 / 等级标记":"酒馆饰品","获取来源 / 关联英雄":"","衍生物 / 关联内容":"","最终更新":"2024-09-27 Patch30.4.3.208182","卡牌代码 / ID":"BG30_MagicItem_997t\n115228","核实备注":"","来源":"https://wiki.ifindhs.com/index.php?title=酒馆战棋/风行者的项链（大型饰品）&oldid=130254","获取 / 核验来源链接":"","图片来源":"http://search.ifindhs.com/pics/latest/BG30_MagicItem_997t.png"},"field_status":{"tier":{"raw":"","value":null,"status":"blank_or_not_applicable","verification":null,"value_source":null},"attack":{"raw":"","value":null,"status":"blank_or_not_applicable","verification":null,"value_source":null},"health":{"raw":"","value":null,"status":"blank_or_not_applicable","verification":null,"value_source":null},"cost":{"raw":3,"value":3,"status":"known","verification":null,"value_source":null},"armor":{"raw":"","value":null,"status":"blank_or_not_applicable","verification":null,"value_source":null}},"quality_flags":[],"historical_abilities":[],"provenance":{"workbook":"限时机制.xlsx","library_file_id":"libfile_80439ad8142c8191a11c1a8ee066d07c","version":1,"sheet":"酒馆饰品","row":261,"source_catalog_file":"res://data/source_catalog/mechanisms.json"},"occurrences":[{"provenance":{"workbook":"限时机制.xlsx","library_file_id":"libfile_80439ad8142c8191a11c1a8ee066d07c","version":1,"sheet":"酒馆饰品","row":261,"source_catalog_file":"res://data/source_catalog/mechanisms.json"},"raw_fields":{"名称":"风行者的项链","类别":"大型饰品","饰品种族标签":"","费用":3,"效果":"在战斗中，你最左边的随从拥有+15攻击力。","获取方式 / 限定条件":"饰品选择\n仅对应机制或明确的特殊生成来源","图像":"","版本":"普通\n大型饰品","状态":"机制池","选择池 / 等级标记":"酒馆饰品","获取来源 / 关联英雄":"","衍生物 / 关联内容":"","最终更新":"2024-09-27 Patch30.4.3.208182","卡牌代码 / ID":"BG30_MagicItem_997t\n115228","核实备注":"","来源":"https://wiki.ifindhs.com/index.php?title=酒馆战棋/风行者的项链（大型饰品）&oldid=130254","获取 / 核验来源链接":"","图片来源":"http://search.ifindhs.com/pics/latest/BG30_MagicItem_997t.png"},"images":[{"path":"res://assets/cards/BG30_MagicItem_997t.jpg","sha256":"5c1e3386f60601078be8929bcd154c10c448b7ea45a479ad985ee7ebad248cb7","xlsx_media_part":"xl/media/image675.jpg","row":261,"column_zero_based":6,"size_bytes":6230}]}],"source_conflicts":[],"supplemental_evidence_key":null,"status":"机制池","notes":"","solo_eligible":true,"duos_exclusive":false,"requires_teammate_effect":false,"mode_evidence":{"latest_client":null,"workbook_applicable_modes":null,"effect_requires_team_mechanism":false,"basis":"Current exclusivity flag and explicit source mode/effect text. No duo-to-solo rewrite."}}}
const SPECS: Dictionary = {
  "BG24_Reward_125": {
    "id": "BG24_Reward_125",
    "card_code": "BG24_Reward_125",
    "dbf_id": "90865",
    "kind": "reward",
    "text": "你的随从拥有+4攻击力。",
    "category": "任务奖励",
    "cost": 0,
    "tier": null,
    "attack": null,
    "health": null,
    "is_golden": false,
    "normal_id": null,
    "golden_id": null,
    "tribes": [],
    "keywords": [],
    "variant": "普通",
    "effects": [
      {
        "type": "mechanism_owner_aura",
        "source_id": "BG24_Reward_125",
        "scope": "friendly_board",
        "attack": 4,
        "health": 0,
        "tribe": "",
        "max_tier": null,
        "duration": "while_mechanism_active"
      }
    ]
  },
  "BG30_MagicItem_880": {
    "id": "BG30_MagicItem_880",
    "card_code": "BG30_MagicItem_880",
    "dbf_id": "111211",
    "kind": "trinket",
    "text": "你的随从拥有+2/+1。",
    "category": "小型饰品",
    "cost": 2,
    "tier": null,
    "attack": null,
    "health": null,
    "is_golden": false,
    "normal_id": null,
    "golden_id": null,
    "tribes": [],
    "keywords": [],
    "variant": "普通",
    "effects": [
      {
        "type": "mechanism_owner_aura",
        "source_id": "BG30_MagicItem_880",
        "scope": "friendly_board",
        "attack": 2,
        "health": 1,
        "tribe": "",
        "max_tier": null,
        "duration": "while_mechanism_active"
      }
    ]
  },
  "BG30_MagicItem_880t": {
    "id": "BG30_MagicItem_880t",
    "card_code": "BG30_MagicItem_880t",
    "dbf_id": "111250",
    "kind": "trinket",
    "text": "你的随从拥有+8/+5。",
    "category": "大型饰品",
    "cost": 1,
    "tier": null,
    "attack": null,
    "health": null,
    "is_golden": false,
    "normal_id": null,
    "golden_id": null,
    "tribes": [],
    "keywords": [],
    "variant": "普通",
    "effects": [
      {
        "type": "mechanism_owner_aura",
        "source_id": "BG30_MagicItem_880t",
        "scope": "friendly_board",
        "attack": 8,
        "health": 5,
        "tribe": "",
        "max_tier": null,
        "duration": "while_mechanism_active"
      }
    ]
  },
  "BG30_MagicItem_989": {
    "id": "BG30_MagicItem_989",
    "card_code": "BG30_MagicItem_989",
    "dbf_id": "112014",
    "kind": "trinket",
    "text": "你的亡灵拥有+3攻击力。",
    "category": "小型饰品",
    "cost": 1,
    "tier": null,
    "attack": null,
    "health": null,
    "is_golden": false,
    "normal_id": null,
    "golden_id": null,
    "tribes": [],
    "keywords": [],
    "variant": "普通",
    "effects": [
      {
        "type": "mechanism_owner_aura",
        "source_id": "BG30_MagicItem_989",
        "scope": "friendly_board",
        "attack": 3,
        "health": 0,
        "tribe": "亡灵",
        "max_tier": null,
        "duration": "while_mechanism_active"
      }
    ]
  },
  "BG30_MagicItem_989t": {
    "id": "BG30_MagicItem_989t",
    "card_code": "BG30_MagicItem_989t",
    "dbf_id": "117157",
    "kind": "trinket",
    "text": "你的亡灵拥有+20攻击力。",
    "category": "大型饰品",
    "cost": 0,
    "tier": null,
    "attack": null,
    "health": null,
    "is_golden": false,
    "normal_id": null,
    "golden_id": null,
    "tribes": [],
    "keywords": [],
    "variant": "普通",
    "effects": [
      {
        "type": "mechanism_owner_aura",
        "source_id": "BG30_MagicItem_989t",
        "scope": "friendly_board",
        "attack": 20,
        "health": 0,
        "tribe": "亡灵",
        "max_tier": null,
        "duration": "while_mechanism_active"
      }
    ]
  },
  "BG30_MagicItem_843t": {
    "id": "BG30_MagicItem_843t",
    "card_code": "BG30_MagicItem_843t",
    "dbf_id": "115251",
    "kind": "trinket",
    "text": "你的等级3或更低的随从拥有+7/+5。",
    "category": "大型饰品",
    "cost": 2,
    "tier": null,
    "attack": null,
    "health": null,
    "is_golden": false,
    "normal_id": null,
    "golden_id": null,
    "tribes": [],
    "keywords": [],
    "variant": "普通",
    "effects": [
      {
        "type": "mechanism_owner_aura",
        "source_id": "BG30_MagicItem_843t",
        "scope": "friendly_board",
        "attack": 7,
        "health": 5,
        "tribe": "",
        "max_tier": 3,
        "duration": "while_mechanism_active"
      }
    ]
  },
  "BG30_MagicItem_997": {
    "id": "BG30_MagicItem_997",
    "card_code": "BG30_MagicItem_997",
    "dbf_id": "112408",
    "kind": "trinket",
    "text": "在战斗中，你最左边的随从拥有+8攻击力。",
    "category": "小型饰品",
    "cost": 3,
    "tier": null,
    "attack": null,
    "health": null,
    "is_golden": false,
    "normal_id": null,
    "golden_id": null,
    "tribes": [],
    "keywords": [],
    "variant": "普通",
    "effects": [
      {
        "type": "mechanism_owner_aura",
        "source_id": "BG30_MagicItem_997",
        "scope": "combat_leftmost",
        "attack": 8,
        "health": 0,
        "tribe": "",
        "max_tier": null,
        "duration": "while_mechanism_active"
      }
    ]
  },
  "BG30_MagicItem_997t": {
    "id": "BG30_MagicItem_997t",
    "card_code": "BG30_MagicItem_997t",
    "dbf_id": "115228",
    "kind": "trinket",
    "text": "在战斗中，你最左边的随从拥有+15攻击力。",
    "category": "大型饰品",
    "cost": 3,
    "tier": null,
    "attack": null,
    "health": null,
    "is_golden": false,
    "normal_id": null,
    "golden_id": null,
    "tribes": [],
    "keywords": [],
    "variant": "普通",
    "effects": [
      {
        "type": "mechanism_owner_aura",
        "source_id": "BG30_MagicItem_997t",
        "scope": "combat_leftmost",
        "attack": 15,
        "health": 0,
        "tribe": "",
        "max_tier": null,
        "duration": "while_mechanism_active"
      }
    ]
  }
}

static func integer(value: Variant, minimum: int = 0) -> bool:
	return (value is int and value >= minimum) or (value is float and is_finite(value) and value >= minimum and value < 9223372036854775808.0 and value == floor(value))

static func same(left: Variant, right: Variant) -> bool:
	if integer(left) and integer(right): return int(left) == int(right)
	if typeof(left) != typeof(right): return false
	if left is Dictionary:
		if left.size() != right.size(): return false
		for key in left:
			if not right.has(key) or not same(left[key],right[key]): return false
		return true
	if left is Array:
		if left.size() != right.size(): return false
		for index in range(left.size()):
			if not same(left[index],right[index]): return false
		return true
	return left == right

static func keys(value: Variant, expected: Array) -> bool:
	if not value is Dictionary or value.size() != expected.size(): return false
	for key in expected:
		if not value.has(key): return false
	return true

static func card(catalog: Variant, identity: String) -> Dictionary:
	var found: Variant = catalog.get(identity,{}) if catalog is Dictionary else catalog.get_card(identity)
	return found if found is Dictionary else {}

static func effect_error(effect: Variant) -> String:
	if not effect is Dictionary or not effect.get("source_id") is String or not SPECS.has(effect.source_id): return "Unreviewed owner aura identity"
	return "" if same(effect,SPECS[effect.source_id].effects[0]) else "Owner aura must be the exact complete source program"

static func source_error(source: Dictionary) -> String:
	var identity: Variant = source.get("id")
	if not identity is String or not SPECS.has(identity): return "Unreviewed owner aura source"
	for key in RAW_PROJECTION[identity]:
		if not source.has(key) or not same(source[key],RAW_PROJECTION[identity][key]): return "Owner aura raw source projection differs: "+identity+"."+key
	for key in SPECS[identity]:
		if not source.has(key) or not same(source[key],SPECS[identity][key]): return "Whole owner aura source differs: "+identity+"."+key
	if not same(source.get("supported"),true): return "Owner aura source not explicitly supported"
	for key in ["excluded","duos_exclusive","requires_teammate_effect","stats_conflict"]:
		if not source.get(key,false) is bool or source.get(key,false): return "Owner aura source gate: "+key
	if not source.get("solo_eligible",true) is bool or source.get("solo_eligible",true) != true: return "Owner aura requires solo-eligible source"
	for key in ["source_conflicts","dependencies","dependency_ids","required_card_ids","requires_cards","custom_shop_override","custom_shop_derived_from","source_shop_fields"]:
		if source.get(key): return "Owner aura source has unreviewed dependency/override: "+key
	var statuses: Variant = source.get("field_status",{})
	var validation: Variant = source.get("latest_validation",{})
	if not statuses is Dictionary or not validation is Dictionary or validation.get("data_gate",false): return "Owner aura source validation metadata blocked"
	if not statuses.get("cost") is Dictionary or statuses.cost.get("status") != "known" or not same(statuses.cost.get("value"),source.cost): return "Owner aura independent cost is not verified"
	return ""

static func canonical_catalog(catalog: Variant) -> Variant:
	if catalog is Dictionary: return catalog
	for property in catalog.get_property_list():
		if property.name == "source_catalog" and catalog.get("source_catalog") != null: return catalog.get("source_catalog")
	return catalog

static func catalog_error(catalog: Variant, identity: String) -> String:
	var native: Dictionary = card(canonical_catalog(catalog),identity)
	var issue: String = source_error(native)
	if not issue.is_empty(): return issue
	return "" if same(card(catalog,identity),native) else "Effective owner aura source differs from canonical source"

static func slot(kind: String, index: int, identity: String) -> String:
	return "%s:%d:%s:0" % [kind,index,identity]

static func token(owner: int, occurrence: int, kind: String) -> String:
	return PREFIX+"%d:%d:%s:0" % [owner,occurrence,kind]

static func has_sources(player: Dictionary, catalog: Variant = null) -> bool:
	if player.has(STATE_KEY): return true
	for field in ["trinkets","reward_active"]:
		if not player.get(field,[]) is Array: return true
		for identity in player.get(field,[]):
			if not identity is String or identity.is_empty() or SPECS.has(identity): return true
			if catalog != null and contains_owner_type(card(catalog,identity).get("effects",[])): return true
	return false

static func contains_owner_type(value: Variant, depth: int = 0) -> bool:
	if depth > 32: return true # Invalid nesting is an active claim that must fail closed.
	if value is Dictionary:
		if value.get("type") == TYPE: return true
		for child in value.values():
			if (child is Array or child is Dictionary) and contains_owner_type(child,depth+1): return true
	elif value is Array:
		for child in value:
			if contains_owner_type(child,depth+1): return true
	return false

static func empty_state(owner: int) -> Dictionary:
	return {"version":1,"owner":owner,"next_occurrence":1,"instances":[]}

static func collect(player: Dictionary, catalog: Variant) -> Dictionary:
	if not integer(player.get("id")): return {"error":"Owner aura requires a real owner"}
	var owner: int = int(player.id)
	var expected: Array = []
	# Validate EVERY active candidate source before producing any contribution.
	# Existing general mechanism/DSL validators still own noncandidate cards.
	for group in [{"kind":"trinket","field":"trinkets"},{"kind":"reward","field":"reward_active"}]:
		if not player.get(group.field,[]) is Array: return {"error":"Acquired mechanism list must be an Array"}
		for index in range(player.get(group.field,[]).size()):
			var identity: Variant = player[group.field][index]
			if not identity is String or identity.is_empty(): return {"error":"Malformed active mechanism identity"}
			var source: Dictionary = card(catalog,identity)
			if source.get("id") != identity or source.get("kind") != group.kind or not same(source.get("supported"),true) or not source.get("effects") is Array: return {"error":"Active mechanism has no complete supported catalog definition: "+identity}
			if not SPECS.has(identity):
				for effect in source.effects:
					if not effect is Dictionary or contains_owner_type(effect): return {"error":"Owner aura cannot hide on another source"}
				continue
			var issue: String = catalog_error(catalog,identity)
			if not issue.is_empty(): return {"error":issue}
			expected.append({"kind":group.kind,"index":index,"card_id":identity})
	var state: Variant = player.get(STATE_KEY,empty_state(owner))
	if not keys(state,["version","owner","next_occurrence","instances"]) or not same(state.version,1) or not integer(state.owner) or int(state.owner) != owner or not integer(state.next_occurrence,1) or not state.instances is Array: return {"error":"Malformed or foreign owner aura occurrence state"}
	if state.instances.size() != expected.size(): return {"error":"Acquired sources need exact persisted occurrences; never migrate by guessing"}
	var occurrences: Dictionary = {}
	var sources: Array = []
	for index in range(expected.size()):
		var entry: Variant = state.instances[index]
		if not keys(entry,["kind","index","card_id","occurrence"]) or not integer(entry.occurrence,1) or int(entry.occurrence) >= int(state.next_occurrence): return {"error":"Malformed acquisition occurrence"}
		for key in ["kind","index","card_id"]:
			if not same(entry[key],expected[index][key]): return {"error":"Occurrence does not match actual active source slot"}
		if occurrences.has(int(entry.occurrence)): return {"error":"Duplicate acquisition occurrence"}
		occurrences[int(entry.occurrence)] = true
		var effect: Dictionary = SPECS[entry.card_id].effects[0]
		sources.append({"uid":token(owner,int(entry.occurrence),entry.kind),"card_id":entry.card_id,"tribe":effect.tribe,"max_tier":effect.max_tier,"attack":effect.attack,"health":effect.health,"source_kind":entry.kind,"source_slot":slot(entry.kind,int(entry.index),entry.card_id),"occurrence":int(entry.occurrence),"effect_index":0})
	return {"error":"","sources":sources,"state":state.duplicate(true)}

static func recipient_tier(unit: Dictionary, catalog: Variant) -> Dictionary:
	var identity: Variant = unit.get("card_id",unit.get("id"))
	if not identity is String: return {"error":"Horde recipient needs exact identity"}
	var effective: Dictionary = card(catalog,identity)
	if effective.get("id") != identity or effective.get("kind") != "minion" or not same(effective.get("supported"),true): return {"error":"Horde recipient has no supported effective record"}
	var value: Variant = effective.get("tier")
	if not integer(value,1) or int(value) > 7 or not same(unit.get("tier"),value): return {"error":"Horde runtime tier must equal validated effective catalog tier 1–7"}
	var native_value: Variant = value
	if effective.has("source_shop_fields"):
		var original: Variant = effective.source_shop_fields
		if not keys(original,["tier","cost","pool_supported"]) or not original.pool_supported is bool: return {"error":"Malformed independent native shop snapshot"}
		native_value = original.tier
		var normal: Dictionary = card(catalog,str(effective.get("normal_id",""))) if effective.get("is_golden",false) else effective
		var override: Variant = normal.get("custom_shop_override")
		if not keys(override,["tier","cost","copies"]) or not integer(override.tier,1) or int(override.tier)>6 or not integer(override.cost) or int(override.cost)>99 or not integer(override.copies,1) or int(override.copies)>99 or not same(value,override.tier): return {"error":"Horde custom tier needs exact validated room override"}
		if effective.get("is_golden",false):
			if effective.get("custom_shop_derived_from") != normal.get("id") or effective.has("custom_shop_override"): return {"error":"Horde golden tier needs independent derived identity"}
		elif effective.has("custom_shop_derived_from") or not same(effective.get("cost"),override.cost): return {"error":"Horde effective normal shop fields differ from explicit override"}
	elif effective.has("custom_shop_override") or effective.has("custom_shop_derived_from"): return {"error":"Horde custom tier is missing native provenance"}
	if not integer(native_value,1) or int(native_value)>7: return {"error":"Horde independent source tier is unknown"}
	var independent: Dictionary = card(canonical_catalog(catalog),identity)
	var independent_tier: Variant = independent.get("tier")
	if independent.has("source_shop_fields"):
		if not keys(independent.source_shop_fields,["tier","cost","pool_supported"]): return {"error":"Horde canonical source shop provenance malformed"}
		independent_tier = independent.source_shop_fields.tier
	if independent.get("id") != identity or independent.get("kind") != "minion" or not same(independent.get("supported"),true) or not same(independent_tier,native_value): return {"error":"Horde native provenance differs from canonical source"}
	var statuses: Variant = effective.get("field_status",{})
	if not statuses is Dictionary: return {"error":"Horde recipient tier metadata malformed"}
	var status: Variant = statuses.get("tier",{})
	if not status is Dictionary or status.get("status") != "known" or not same(status.get("value"),native_value): return {"error":"Horde independent source tier is unverified"}
	# CUSTOM_SHOP.md explicitly makes configured tier govern tier predicates.
	# Source-game evidence uses native cards; this is the existing sandbox contract.
	return {"error":"","tier":int(value)}

static func recipient_match(unit: Dictionary, source: Dictionary, catalog: Variant) -> Dictionary:
	if unit.get("kind","minion") != "minion": return {"error":"","matches":false}
	var matches: bool = source.tribe.is_empty()
	for tribe in unit.get("tribes",[]):
		if tribe == source.tribe or tribe == "全部" or str(tribe).to_lower() == "all": matches=true
	if not matches: return {"error":"","matches":false}
	if source.get("max_tier") != null:
		var tier: Dictionary = recipient_tier(unit,catalog)
		if not tier.error.is_empty(): return tier
		matches = tier.tier <= int(source.max_tier)
	return {"error":"","matches":matches}

static func marker_entry_error(key: Variant, entry: Variant, owner: int, unit: Dictionary) -> String:
	if not keys(entry,["card_id","attack","health","source_kind","source_slot","occurrence","effect_index"]): return "Owner aura marker requires exact source provenance"
	if not entry.card_id is String or not SPECS.has(entry.card_id) or not integer(entry.occurrence,1) or not same(entry.effect_index,0): return "Unreviewed or malformed owner aura marker"
	var spec: Dictionary = SPECS[entry.card_id]
	if entry.source_kind != spec.kind or key != token(owner,int(entry.occurrence),spec.kind): return "Owner aura marker token/owner differs"
	if not entry.source_slot is String: return "Owner aura marker slot must be a String"
	var pieces: PackedStringArray = entry.source_slot.split(":")
	if pieces.size()!=4 or not pieces[1].is_valid_int() or int(pieces[1])<0 or entry.source_slot != slot(spec.kind,int(pieces[1]),entry.card_id): return "Owner aura marker slot differs"
	var effect: Dictionary = spec.effects[0]
	if not same(entry.attack,effect.attack) or not same(entry.health,effect.health): return "Owner aura marker amount differs from source"
	var compatible: bool=effect.tribe.is_empty()
	for tribe in unit.get("tribes",[]):
		if tribe==effect.tribe or tribe=="全部" or str(tribe).to_lower()=="all": compatible=true
	if not compatible: return "Owner aura marker recipient type differs"
	return ""

static func marker_entry(source: Dictionary) -> Dictionary:
	var entry: Dictionary = {}
	for key in ["card_id","attack","health","source_kind","source_slot","occurrence","effect_index"]: entry[key]=source[key]
	return entry

static func build_change(player: Dictionary, catalog: Variant, kind: String, index: int, new_id: Variant = null) -> Dictionary:
	var old: Dictionary = collect(player,catalog)
	if not old.error.is_empty(): return old
	if kind not in ["trinket","reward"]: return {"error":"Unsupported acquired source kind"}
	var field: String = "trinkets" if kind=="trinket" else "reward_active"
	var ids: Array = player.get(field,[]).duplicate()
	if index<0 or index>ids.size() or (new_id==null and index==ids.size()): return {"error":"Invalid source mutation slot"}
	if new_id!=null:
		if not new_id is String or new_id.is_empty(): return {"error":"Source mutation identity must be String"}
		var definition: Dictionary = card(catalog,new_id)
		if definition.get("kind")!=kind or not same(definition.get("supported"),true): return {"error":"Source mutation requires supported exact kind"}
	var state: Dictionary = old.state.duplicate(true)
	var kept: Array = []
	for occurrence in state.instances:
		if occurrence.kind==kind and int(occurrence.index)==index: continue
		var shifted: Dictionary = occurrence.duplicate(true)
		if new_id==null and shifted.kind==kind and int(shifted.index)>index: shifted.index=int(shifted.index)-1
		kept.append(shifted)
	if new_id==null: ids.remove_at(index)
	elif index==ids.size(): ids.append(new_id)
	else: ids[index]=new_id
	if new_id is String and SPECS.has(new_id):
		if int(state.next_occurrence)==MAX_STAT: return {"error":"Owner aura occurrence sequence exhausted"}
		kept.append({"kind":kind,"index":index,"card_id":new_id,"occurrence":int(state.next_occurrence)})
		state.next_occurrence=int(state.next_occurrence)+1
	kept.sort_custom(func(a,b): return int(a.index)<int(b.index) if a.kind==b.kind else a.kind=="trinket")
	state.instances=kept
	var after: Dictionary = player.duplicate(true)
	after[field]=ids
	after[STATE_KEY]=state
	var fresh: Dictionary = collect(after,catalog)
	if not fresh.error.is_empty(): return fresh
	return {"error":"","kind":kind,"index":index,"new_id":new_id,"before":player.duplicate(true),"after":after}

static func effects_provenance_error(player: Dictionary, catalog: Variant, resolved: Array) -> String:
	# The host passes Mechanisms._effects(engine,player), not hand-authored
	# rows. Confirm the existing authoritative slot enumeration agrees.
	var owned: Dictionary=collect(player,catalog)
	if not str(owned.error).is_empty(): return str(owned.error)
	var expected: Dictionary={}
	for source in owned.sources: expected[source.source_slot]=source
	var found: Dictionary={}
	for effect in resolved:
		if not effect is Dictionary: return "Malformed resolved mechanism effect"
		if effect.get("type")!=TYPE: continue
		var key: Variant=effect.get("source_slot")
		if not key is String or not expected.has(key) or found.has(key): return "Resolved owner aura has missing/duplicate source slot"
		var source: Dictionary=expected[key]
		if effect.get("source_id")!=source.card_id or effect.get("source_kind")!=source.source_kind or not effect.get("latest_instance") is bool: return "Resolved owner aura provenance differs from acquired source"
		var field: String="trinkets" if source.source_kind=="trinket" else "reward_active"
		var source_index: int=int(str(source.source_slot).split(":")[1])
		if effect.latest_instance!=(source_index==player[field].rfind(source.card_id)): return "Resolved latest-instance flag differs"
		var plain: Dictionary=effect.duplicate(true)
		for metadata in ["source_id","source_kind","source_slot","latest_instance"]: plain.erase(metadata)
		# source_id belongs to the exact canonical program as well as metadata.
		plain.source_id=source.card_id
		if not same(plain,SPECS[source.card_id].effects[0]): return "Resolved owner aura program differs from complete source"
		found[key]=true
	return "" if found.size()==expected.size() else "Resolved effects omitted an active owner aura"

static func imported_marker_error(player: Dictionary, catalog: Variant) -> String:
	var owned: Dictionary=collect(player,catalog)
	if not str(owned.error).is_empty(): return str(owned.error)
	var sources: Dictionary={}
	for source in owned.sources: sources[source.uid]=source
	for unit in player.get("board",[]):
		if not unit is Dictionary: return "Owner aura combat board needs units"
		var marker: Variant=unit.get("board_aura_applied",{})
		if not marker is Dictionary or not marker.get("sources",{}) is Dictionary: return "Malformed imported aura marker"
		for key in marker.get("sources",{}):
			if not key is String or not key.begins_with(PREFIX): continue
			if not sources.has(key) or not same(marker.sources[key],marker_entry(sources[key])): return "Imported owner contribution has stale or foreign acquisition occurrence"
			var target: Dictionary=recipient_match(unit,sources[key],catalog)
			if not str(target.error).is_empty(): return str(target.error)
			if not target.matches: return "Imported owner contribution has an ineligible recipient"
	return ""
