extends RefCounted
## Complete independent Cyberdrake pair; bounded current-Shield selector only.
const PoolIdentity = preload("res://core/pool_identity.gd")
const FOLDER: String = "res://research/cyberdrake_aura_sources/"
const IDS: Array = ["BG25_043","BG25_043_G"]
const PROGRAMS: Dictionary = {"BG25_043":[{"type":"board_aura","scope":"all_friendly","keyword":"divine_shield","attack":6,"health":0,"attack_per_owner_tier":0,"duration":"while_source_on_board"}],"BG25_043_G":[{"type":"board_aura","scope":"all_friendly","keyword":"divine_shield","attack":12,"health":0,"attack_per_owner_tier":0,"duration":"while_source_on_board"}]}
const FILE_SHA256: Dictionary = {"expected_compiled.json":"e13586881ef70268986a99a5b09f04ec789e2b30896ed813efe59017e1fc28f1","expected_programs.json":"1442ee3b8f4ef1e0f7d15c2bb75c89baafdc9db1c880cb9bce5bafacad23ecba","grant_existing_overlay.json":"b02a503d14c0f3a26c9ecbbd773b77e2fab55174838564e2f02bf5e180ec8cc5","implementation_boundary.json":"7204e18f921476d798bcb1fbd9ea9f81379be205fe2490b010c7a644538af401","native/BG25_043.xml":"eb42e3c9565c96e9afea599ac7d73bec636ec2c34cfd61a9ea3cdcefd97de103","native/BG25_043_G.xml":"a6736bfdb83512c3a597ccdb2ebd9a84726d59c1b9bd3d6fb96d7dbcc53ebdd9","native/BG28_507.xml":"f84b4ec674633f05c4b41e79088fd6a03d4b2a03ed84a05cd61a750b0141edc3","raw49/BG25_043.json":"c47ef7e363ed0216a4108d1d9281771d31c5afb38dda2e96841e88d456b6c35a","raw49/BG25_043_G.json":"0f7564e9c36b48155d404609fe82db79a196fb9b7c680963c51608297ee45d2e","raw49/BG28_507.json":"3c604abd4b7fab681cdbc4c4d0dac3cfa47dd371723a42e57d04dcefa5c95d98","source_contract.json":"63ae612fc95d861bdfac8f31d181422905520fd1551032608eb017a3e099e1c8"}
const GRANT_PROGRAM: Array = [{"type":"spell_keyword","scope":"target","keyword":"divine_shield","allow_shop":true,"temporary":false}]
static func same(left: Variant, right: Variant) -> bool:
	# Source literals use bounded numbers, with strict booleans and Strings.
	if (left is int or left is float) and (right is int or right is float):
		return is_finite(left) and is_finite(right) and left == right
	if typeof(left) != typeof(right): return false
	if left is Dictionary:
		if left.size() != right.size(): return false
		for key in right:
			if not left.has(key) or not same(left[key], right[key]): return false
		return true
	if left is Array:
		if left.size() != right.size(): return false
		for index in range(left.size()):
			if not same(left[index], right[index]): return false
		return true
	return left == right

static func accepts_id(identity: Variant) -> bool:
	return identity is String and identity in IDS

static func effect_error(effect: Variant) -> String:
	if not effect is Dictionary: return "cyberdrake_effect_not_dictionary"
	for key in ["type", "scope", "keyword", "duration"]:
		if not effect.get(key) is String: return "cyberdrake_effect_invalid_string:" + key
	for identity in IDS:
		if same(effect, PROGRAMS[identity][0]): return ""
	return "cyberdrake_complete_effect_changed"

static func player_has_source(player: Dictionary) -> bool:
	for unit in player.get("board", []):
		if unit is Dictionary and accepts_id(unit.get("card_id")): return true
	return false

static func validation_evidence() -> Dictionary:
	for path in FILE_SHA256:
		if FileAccess.get_sha256(FOLDER+path) != FILE_SHA256[path]: return {"error":"cyberdrake_evidence_changed:"+path}
	var contract: Variant = JSON.parse_string(FileAccess.get_file_as_string(FOLDER+"source_contract.json"))
	var expected: Variant = JSON.parse_string(FileAccess.get_file_as_string(FOLDER+"expected_compiled.json"))
	if not contract is Dictionary or not contract.get("records") is Dictionary or not expected is Dictionary or expected.size() != 2: return {"error":"cyberdrake_evidence_shape_changed"}
	var rows: Dictionary = {}
	for identity in IDS:
		var row: Variant = JSON.parse_string(FileAccess.get_file_as_string(FOLDER+contract.records[identity].raw49_file))
		if not row is Dictionary or row.size() != 49 or not same(row,contract.records[identity].raw49) or not same(expected.get(identity,{}).get("effects"),PROGRAMS[identity]): return {"error":"cyberdrake_complete_evidence_changed"}
		rows[identity] = row
	return {"error":"","rows":rows,"expected":expected}

static func raw_source_error(card: Variant, evidence: Dictionary = {}) -> String:
	if not card is Dictionary or not accepts_id(card.get("id")): return "cyberdrake_unknown_raw_source"
	if evidence.is_empty(): evidence = validation_evidence()
	if not str(evidence.get("error","cyberdrake_missing_evidence")).is_empty(): return str(evidence.error)
	return "" if same(card,evidence.rows[card.id]) else "cyberdrake_complete_raw_source_changed"

static func _expected(identity: String, evidence: Dictionary) -> Dictionary:
	var result: Dictionary = evidence.rows[identity].duplicate(true)
	result.merge(evidence.expected[identity],true)

	return result

static func source_error(card: Variant, custom_projection: bool = false, evidence: Dictionary = {}) -> String:
	if not card is Dictionary or not accepts_id(card.get("id")) or card.has("card_id"): return "cyberdrake_unknown_effective_source"
	if evidence.is_empty(): evidence = validation_evidence()
	if not str(evidence.get("error","cyberdrake_missing_evidence")).is_empty(): return str(evidence.error)
	var expected: Dictionary = _expected(card.id,evidence)
	var actual: Dictionary = card.duplicate(true)
	if actual.has("pool_blocker") and card.id == IDS[1]: expected.pool_blocker = PoolIdentity.MINION_REASON
	if actual.has("source_shop_fields"):
		if not custom_projection or not same(actual.source_shop_fields,{"tier":expected.tier,"cost":expected.cost,"pool_supported":false}): return "cyberdrake_custom_source_changed"
		if card.id == IDS[0]:
			var entry: Variant = actual.get("custom_shop_override")
			if not entry is Dictionary or entry.size() != 3: return "cyberdrake_custom_parameters_changed"
			for key in ["tier","cost","copies"]:
				if not entry.get(key) is int and not entry.get(key) is float: return "cyberdrake_custom_parameters_changed"
				if not is_finite(entry[key]) or entry[key] != floor(entry[key]): return "cyberdrake_custom_parameters_changed"
			if entry.tier < 1 or entry.tier > 6 or entry.cost < 0 or entry.cost > 99 or entry.copies < 1 or entry.copies > 99: return "cyberdrake_custom_parameters_changed"
			if not same(actual.get("tier"),entry.tier) or not same(actual.get("cost"),entry.cost) or not same(actual.get("pool_supported"),true): return "cyberdrake_custom_projection_changed"
			actual.cost = expected.cost; actual.pool_supported = false; actual.erase("custom_shop_override")
		else:
			if not same(actual.get("custom_shop_derived_from"),IDS[0]): return "cyberdrake_custom_golden_projection_changed"
			actual.erase("custom_shop_derived_from")
		actual.tier = expected.tier; actual.erase("source_shop_fields")
	return "" if same(actual,expected) else "cyberdrake_complete_source_changed"

static func closure_error(catalog) -> String:
	var canonical = catalog
	if catalog is Object:
		if catalog.get("source_catalog") != null: canonical = catalog.source_catalog
		if not canonical is Object or canonical.get("source_catalog") != null: return "cyberdrake_invalid_canonical_catalog"
	elif not catalog is Dictionary: return "cyberdrake_missing_catalog"
	var evidence: Dictionary = validation_evidence()
	if not str(evidence.error).is_empty(): return str(evidence.error)
	for identity in IDS:
		var original: Dictionary = canonical.get(identity,{}) if canonical is Dictionary else canonical.get_card(identity)
		var issue: String = source_error(original,canonical is Dictionary and original.has("source_shop_fields"),evidence)
		if not issue.is_empty(): return issue
		if catalog != canonical:
			issue = source_error(catalog.get_card(identity),true,evidence)
			if not issue.is_empty(): return issue
	return ""

static func boards_have_source(boards: Array) -> bool:
	for board in boards:
		if board is Array and player_has_source({"board":board}): return true
	return false

static func runtime_source_error(unit: Dictionary) -> String:
	if not accepts_id(unit.get("card_id", unit.get("id"))): return "cyberdrake_unknown_runtime_source"
	var identity: String = unit.get("card_id", unit.get("id"))
	if not same(unit.get("effects"),PROGRAMS[identity]): return "cyberdrake_complete_runtime_program_changed"
	for flag in ["silenced", "abilities_disabled", "disabled"]:
		if not same(unit.get(flag,false),false): return "cyberdrake_disabled_source_unverified"
	return ""

static func grant_source_error(source: Dictionary, catalog) -> String:
	if source.get("card_id",source.get("id")) != "BG28_507" or not same(source.get("effects"),GRANT_PROGRAM) or not same(source.get("temporary",false),false) or source.get("kind") != "spell": return "cyberdrake_grant_source_unverified"
	var evidence: Dictionary = validation_evidence()
	if not str(evidence.error).is_empty(): return str(evidence.error)
	var contract: Dictionary = JSON.parse_string(FileAccess.get_file_as_string(FOLDER+"source_contract.json"))
	var record: Dictionary = contract.grant_evidence_only.BG28_507
	var expected: Dictionary = record.raw49.duplicate(true)
	expected.merge(record.existing_overlay,true)
	var canonical = catalog
	if catalog is Object and catalog.get("source_catalog") != null: canonical = catalog.source_catalog
	if not canonical is Dictionary and not canonical is Object: return "cyberdrake_grant_catalog_missing"
	var original: Dictionary = canonical.get("BG28_507",{}) if canonical is Dictionary else canonical.get_card("BG28_507")
	if original.has("pool_blocker"): expected.pool_blocker = PoolIdentity.SPELL_REASON
	if not same(original,expected): return "cyberdrake_complete_grant_source_changed"
	if catalog is Object and catalog != canonical and not same(catalog.get_card("BG28_507"),expected): return "cyberdrake_effective_grant_source_changed"
	if source.get("text") != expected.text: return "cyberdrake_grant_runtime_text_changed"
	return ""
