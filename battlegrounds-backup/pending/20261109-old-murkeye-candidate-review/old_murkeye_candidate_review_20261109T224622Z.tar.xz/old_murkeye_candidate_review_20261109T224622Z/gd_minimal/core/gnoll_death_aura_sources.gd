extends RefCounted
## Exact normal/golden current-combat self aura. No global or imported authority.
const PoolIdentity = preload("res://core/pool_identity.gd")
const FOLDER: String = "res://research/gnoll_death_aura_sources/"
const TYPE: String = "self_attack_per_friendly_death_this_combat"
const PREFIX: String = "@gnoll:"
const APPLIED_KEY: String = "board_aura_applied"
const MAX_STAT: int = 9223372036854775807
const IDS: Array = ["BG25_013","BG25_013_G"]
const PROGRAMS: Dictionary = {"BG25_013":[{"type":"self_attack_per_friendly_death_this_combat","source_id":"BG25_013","attack_per_death":1}],"BG25_013_G":[{"type":"self_attack_per_friendly_death_this_combat","source_id":"BG25_013_G","attack_per_death":2}]}
const SOURCES: Dictionary = {"BG25_013":{"name":"腐皮豺狼人","dbf_id":"95271","kind":"minion","category":"随从","tier":1,"attack":1,"health":4,"cost":null,"tribes":["亡灵"],"is_golden":false,"text":"在本场战斗中，每有一个友方随从死亡，便拥有+1攻击力。","normal_id":null,"golden_id":"BG25_013_G"},"BG25_013_G":{"name":"腐皮豺狼人","dbf_id":"95272","kind":"minion","category":"随从","tier":1,"attack":2,"health":8,"cost":null,"tribes":["亡灵"],"is_golden":true,"text":"在本场战斗中，每有一个友方随从死亡，便拥有+2攻击力。","normal_id":"BG25_013","golden_id":null}}
const RAW49: Dictionary = {"BG25_013":{"id":"BG25_013","card_code":"BG25_013","identity_type":"source_card_code","dbf_id":"95271","name":"腐皮豺狼人","kind":"minion","category":"随从","categories":["随从"],"kinds":["minion"],"source_sheets":["sheet1"],"source_groups":["minions"],"mechanisms":[],"tier":1,"attack":1,"health":4,"cost":null,"armor":null,"armor_by_mode":{},"text":"在本场战斗中，每有一个友方随从死亡，便拥有+1攻击力。","tribes":["亡灵"],"keywords":[],"supported":false,"effects":[],"variant":"普通","is_golden":false,"golden_id":"BG25_013_G","normal_id":null,"image":"res://assets/cards/BG25_013.jpg","images":[{"path":"res://assets/cards/BG25_013.jpg","sha256":"3c8cd06130df5eb00aa53ebc5b1d5a102e232f1fe6d116dfce84052926d5ac99","xlsx_media_part":"xl/media/image1662.jpg","row":1663,"column_zero_based":7,"size_bytes":5226}],"source_url":"https://wiki.ifindhs.com/index.php?title=%E9%85%92%E9%A6%86%E6%88%98%E6%A3%8B/%E8%85%90%E7%9A%AE%E8%B1%BA%E7%8B%BC%E4%BA%BA&oldid=166774","source":"https://wiki.ifindhs.com/index.php?title=%E9%85%92%E9%A6%86%E6%88%98%E6%A3%8B/%E8%85%90%E7%9A%AE%E8%B1%BA%E7%8B%BC%E4%BA%BA&oldid=166774","source_urls":["https://wiki.ifindhs.com/index.php?title=%E9%85%92%E9%A6%86%E6%88%98%E6%A3%8B/%E8%85%90%E7%9A%AE%E8%B1%BA%E7%8B%BC%E4%BA%BA&oldid=166774"],"verification_source_urls":[],"image_source_url":"http://search.ifindhs.com/pics/latest/BG25_013.png","fields":{"tier":1,"attack":1,"health":4,"cost":null,"armor":null,"race":"亡灵","variant":"普通","status":"在池","text":"在本场战斗中，每有一个友方随从死亡，便拥有+1攻击力。","acquisition":null,"restrictions":null,"pool_tag":null,"related_content":"","notes":"按来源及最新可核对补丁整理","updated_at":"2025-08-06 Patch33.2.0.225406","prize_tier":null,"cost_currency":null,"timewarped":"否","applicable_modes":null},"raw_fields":{"随从名称":"腐皮豺狼人","种族":"亡灵","星级":1,"攻击力":1,"血量":4,"效果(包括关键词)":"在本场战斗中，每有一个友方随从死亡，便拥有+1攻击力。","衍生物":"","图像":"","类别":"随从","版本":"普通","时空扭曲":"否","状态":"在池","最终更新":"2025-08-06 Patch33.2.0.225406","卡牌ID":"BG25_013","来源":"https://wiki.ifindhs.com/index.php?title=%E9%85%92%E9%A6%86%E6%88%98%E6%A3%8B/%E8%85%90%E7%9A%AE%E8%B1%BA%E7%8B%BC%E4%BA%BA&oldid=166774","图片来源":"http://search.ifindhs.com/pics/latest/BG25_013.png","数据核实备注":"按来源及最新可核对补丁整理","其他关联卡牌":"","官方交叉核验来源":""},"field_status":{"tier":{"raw":1,"value":1,"status":"known","verification":"已核实","value_source":"基本信息"},"attack":{"raw":1,"value":1,"status":"known","verification":"已核实","value_source":"源图"},"health":{"raw":4,"value":4,"status":"known","verification":"已核实","value_source":"源图"},"cost":{"raw":"","value":null,"status":"blank_or_not_applicable","verification":null,"value_source":null},"armor":{"raw":"","value":null,"status":"blank_or_not_applicable","verification":null,"value_source":null}},"quality_flags":[],"historical_abilities":[],"provenance":{"workbook":"炉石传说酒馆战棋随从.xlsx","library_file_id":"libfile_c01b853efd5081919631aaa927d2c916","version":3,"sheet":"sheet1","row":1663,"source_catalog_file":"res://data/source_catalog/minions.json"},"occurrences":[{"provenance":{"workbook":"炉石传说酒馆战棋随从.xlsx","library_file_id":"libfile_c01b853efd5081919631aaa927d2c916","version":3,"sheet":"sheet1","row":1663,"source_catalog_file":"res://data/source_catalog/minions.json"},"raw_fields":{"随从名称":"腐皮豺狼人","种族":"亡灵","星级":1,"攻击力":1,"血量":4,"效果(包括关键词)":"在本场战斗中，每有一个友方随从死亡，便拥有+1攻击力。","衍生物":"","图像":"","类别":"随从","版本":"普通","时空扭曲":"否","状态":"在池","最终更新":"2025-08-06 Patch33.2.0.225406","卡牌ID":"BG25_013","来源":"https://wiki.ifindhs.com/index.php?title=%E9%85%92%E9%A6%86%E6%88%98%E6%A3%8B/%E8%85%90%E7%9A%AE%E8%B1%BA%E7%8B%BC%E4%BA%BA&oldid=166774","图片来源":"http://search.ifindhs.com/pics/latest/BG25_013.png","数据核实备注":"按来源及最新可核对补丁整理","其他关联卡牌":"","官方交叉核验来源":""},"images":[{"path":"res://assets/cards/BG25_013.jpg","sha256":"3c8cd06130df5eb00aa53ebc5b1d5a102e232f1fe6d116dfce84052926d5ac99","xlsx_media_part":"xl/media/image1662.jpg","row":1663,"column_zero_based":7,"size_bytes":5226}]}],"source_conflicts":[],"supplemental_evidence_key":"BG25_013","status":"在池","notes":"按来源及最新可核对补丁整理","solo_eligible":true,"duos_exclusive":false,"requires_teammate_effect":false,"mode_evidence":{"latest_client":{"card_code":"BG25_013","dbf_id":"95271","duos_exclusive":false,"tag_3166":null,"source_url":"https://raw.githubusercontent.com/HearthSim/hsdata/27fbd2323aec20cab1c6ecc7d5f55cf12729f956/CardDefs.Bacon.xml"},"workbook_applicable_modes":null,"effect_requires_team_mechanism":false,"basis":"Current exclusivity flag and explicit source mode/effect text. No duo-to-solo rewrite."}},"BG25_013_G":{"id":"BG25_013_G","card_code":"BG25_013_G","identity_type":"source_card_code","dbf_id":"95272","name":"腐皮豺狼人","kind":"minion","category":"随从","categories":["随从"],"kinds":["minion"],"source_sheets":["sheet1"],"source_groups":["minions"],"mechanisms":[],"tier":1,"attack":2,"health":8,"cost":null,"armor":null,"armor_by_mode":{},"text":"在本场战斗中，每有一个友方随从死亡，便拥有+2攻击力。","tribes":["亡灵"],"keywords":[],"supported":false,"effects":[],"variant":"金色","is_golden":true,"golden_id":null,"normal_id":"BG25_013","image":"res://assets/cards/BG25_013_G.jpg","images":[{"path":"res://assets/cards/BG25_013_G.jpg","sha256":"5b07cf0a433c72e3e686e8ada976504727e3b36e8074e2d33c5f2aeedae86244","xlsx_media_part":"xl/media/image1663.jpg","row":1664,"column_zero_based":7,"size_bytes":5899}],"source_url":"https://wiki.ifindhs.com/index.php?title=%E9%85%92%E9%A6%86%E6%88%98%E6%A3%8B/%E8%85%90%E7%9A%AE%E8%B1%BA%E7%8B%BC%E4%BA%BA&oldid=166774","source":"https://wiki.ifindhs.com/index.php?title=%E9%85%92%E9%A6%86%E6%88%98%E6%A3%8B/%E8%85%90%E7%9A%AE%E8%B1%BA%E7%8B%BC%E4%BA%BA&oldid=166774","source_urls":["https://wiki.ifindhs.com/index.php?title=%E9%85%92%E9%A6%86%E6%88%98%E6%A3%8B/%E8%85%90%E7%9A%AE%E8%B1%BA%E7%8B%BC%E4%BA%BA&oldid=166774"],"verification_source_urls":[],"image_source_url":"http://search.ifindhs.com/pics/latest/BG25_013_G.png","fields":{"tier":1,"attack":2,"health":8,"cost":null,"armor":null,"race":"亡灵","variant":"金色","status":"在池","text":"在本场战斗中，每有一个友方随从死亡，便拥有+2攻击力。","acquisition":null,"restrictions":null,"pool_tag":null,"related_content":"","notes":"按来源及最新可核对补丁整理","updated_at":"2025-08-06 Patch33.2.0.225406","prize_tier":null,"cost_currency":null,"timewarped":"否","applicable_modes":null},"raw_fields":{"随从名称":"腐皮豺狼人","种族":"亡灵","星级":1,"攻击力":2,"血量":8,"效果(包括关键词)":"在本场战斗中，每有一个友方随从死亡，便拥有+2攻击力。","衍生物":"","图像":"","类别":"随从","版本":"金色","时空扭曲":"否","状态":"在池","最终更新":"2025-08-06 Patch33.2.0.225406","卡牌ID":"BG25_013_G","来源":"https://wiki.ifindhs.com/index.php?title=%E9%85%92%E9%A6%86%E6%88%98%E6%A3%8B/%E8%85%90%E7%9A%AE%E8%B1%BA%E7%8B%BC%E4%BA%BA&oldid=166774","图片来源":"http://search.ifindhs.com/pics/latest/BG25_013_G.png","数据核实备注":"按来源及最新可核对补丁整理","其他关联卡牌":"","官方交叉核验来源":""},"field_status":{"tier":{"raw":1,"value":1,"status":"known","verification":"已核实","value_source":"基本信息"},"attack":{"raw":2,"value":2,"status":"known","verification":"已核实","value_source":"源图"},"health":{"raw":8,"value":8,"status":"known","verification":"已核实","value_source":"源图"},"cost":{"raw":"","value":null,"status":"blank_or_not_applicable","verification":null,"value_source":null},"armor":{"raw":"","value":null,"status":"blank_or_not_applicable","verification":null,"value_source":null}},"quality_flags":[],"historical_abilities":[],"provenance":{"workbook":"炉石传说酒馆战棋随从.xlsx","library_file_id":"libfile_c01b853efd5081919631aaa927d2c916","version":3,"sheet":"sheet1","row":1664,"source_catalog_file":"res://data/source_catalog/minions.json"},"occurrences":[{"provenance":{"workbook":"炉石传说酒馆战棋随从.xlsx","library_file_id":"libfile_c01b853efd5081919631aaa927d2c916","version":3,"sheet":"sheet1","row":1664,"source_catalog_file":"res://data/source_catalog/minions.json"},"raw_fields":{"随从名称":"腐皮豺狼人","种族":"亡灵","星级":1,"攻击力":2,"血量":8,"效果(包括关键词)":"在本场战斗中，每有一个友方随从死亡，便拥有+2攻击力。","衍生物":"","图像":"","类别":"随从","版本":"金色","时空扭曲":"否","状态":"在池","最终更新":"2025-08-06 Patch33.2.0.225406","卡牌ID":"BG25_013_G","来源":"https://wiki.ifindhs.com/index.php?title=%E9%85%92%E9%A6%86%E6%88%98%E6%A3%8B/%E8%85%90%E7%9A%AE%E8%B1%BA%E7%8B%BC%E4%BA%BA&oldid=166774","图片来源":"http://search.ifindhs.com/pics/latest/BG25_013_G.png","数据核实备注":"按来源及最新可核对补丁整理","其他关联卡牌":"","官方交叉核验来源":""},"images":[{"path":"res://assets/cards/BG25_013_G.jpg","sha256":"5b07cf0a433c72e3e686e8ada976504727e3b36e8074e2d33c5f2aeedae86244","xlsx_media_part":"xl/media/image1663.jpg","row":1664,"column_zero_based":7,"size_bytes":5899}]}],"source_conflicts":[],"supplemental_evidence_key":"BG25_013_G","status":"在池","notes":"按来源及最新可核对补丁整理","solo_eligible":true,"duos_exclusive":false,"requires_teammate_effect":false,"mode_evidence":{"latest_client":{"card_code":"BG25_013_G","dbf_id":"95272","duos_exclusive":false,"tag_3166":null,"source_url":"https://raw.githubusercontent.com/HearthSim/hsdata/27fbd2323aec20cab1c6ecc7d5f55cf12729f956/CardDefs.Bacon.xml"},"workbook_applicable_modes":null,"effect_requires_team_mechanism":false,"basis":"Current exclusivity flag and explicit source mode/effect text. No duo-to-solo rewrite."}}}
const FILE_SHA256: Dictionary = {"expected_compiled.json":"7e4db77b7c4fe83f11d500dc673fc35eef247f4bde566838b5c49f280b565ae4","implementation_boundary.json":"d239330d5949fd6951af841ae842216e02004490c407c40954eadcf7f950d4b5","native_entities/BG25_013.xml":"e61adb0f15e1996d7a25cc497fb7144ac7f18e76366286e66097a7e64de6387f","native_entities/BG25_013_G.xml":"990d8644ee0b108417ad94fc355a823ec8749bafc06d5f98367afdb0e73cd3e7","raw49/BG25_013.json":"eeb54ec62749a008c42033f3c9e3995169ccf830f1a365ea44e4c39ac6d1ff69","raw49/BG25_013_G.json":"ae1d63c503b1c0ecfd4dde1cc04cf48348d9f05df97dad416a58dcf2a82ea9e6","source_contract.json":"81f880719b7533f937145a6ce82c754c4f60276d811c6fc00825387fa65020ea"}
const EXPECTED: Dictionary = {"BG25_013":{"id":"BG25_013","supported":true,"effects":[{"type":"self_attack_per_friendly_death_this_combat","source_id":"BG25_013","attack_per_death":1}],"keywords":[],"coverage_rule":"gnoll_death_aura_complete_native_v1","coverage_text_sha256":"396feed6b14ef04e25163437cc070a2a1dc3979243c8768bce7456403f5d4bf6","default_pool":false,"coverage_source_text_sha256":{"BG25_013":"396feed6b14ef04e25163437cc070a2a1dc3979243c8768bce7456403f5d4bf6","BG25_013_G":"f678287b2c441e44962a3ae8c64ed459bdb55663da136aee4ca449b82c8a8940"},"coverage_native_entity_sha256":{"BG25_013":"e61adb0f15e1996d7a25cc497fb7144ac7f18e76366286e66097a7e64de6387f","BG25_013_G":"990d8644ee0b108417ad94fc355a823ec8749bafc06d5f98367afdb0e73cd3e7"},"conditional_support":{"rule":"gnoll_death_aura_source_layer_v1","reason":"Exact independently sourced Rot Hide Gnoll normal/golden programs only. Combat-owned self Attack derives from the complete same-side genuine death history and stays in the independent source-aura layer. Ordinary additive buffs, supported literal SET and incoming Attack transfers preserve that layer. Existing other source-aura admission boundaries remain unchanged; no copied or inherited Gnoll program, stale imported combat layer, custom shop rewrite, or transient stat writeback."},"pool_supported":true},"BG25_013_G":{"id":"BG25_013_G","supported":true,"effects":[{"type":"self_attack_per_friendly_death_this_combat","source_id":"BG25_013_G","attack_per_death":2}],"keywords":[],"coverage_rule":"gnoll_death_aura_complete_native_v1","coverage_text_sha256":"f678287b2c441e44962a3ae8c64ed459bdb55663da136aee4ca449b82c8a8940","default_pool":false,"coverage_source_text_sha256":{"BG25_013":"396feed6b14ef04e25163437cc070a2a1dc3979243c8768bce7456403f5d4bf6","BG25_013_G":"f678287b2c441e44962a3ae8c64ed459bdb55663da136aee4ca449b82c8a8940"},"coverage_native_entity_sha256":{"BG25_013":"e61adb0f15e1996d7a25cc497fb7144ac7f18e76366286e66097a7e64de6387f","BG25_013_G":"990d8644ee0b108417ad94fc355a823ec8749bafc06d5f98367afdb0e73cd3e7"},"conditional_support":{"rule":"gnoll_death_aura_source_layer_v1","reason":"Exact independently sourced Rot Hide Gnoll normal/golden programs only. Combat-owned self Attack derives from the complete same-side genuine death history and stays in the independent source-aura layer. Ordinary additive buffs, supported literal SET and incoming Attack transfers preserve that layer. Existing other source-aura admission boundaries remain unchanged; no copied or inherited Gnoll program, stale imported combat layer, custom shop rewrite, or transient stat writeback."},"pool_supported":false}}

static func integer(value: Variant, low: int = 0, high: int = MAX_STAT) -> bool:
	if value is int: return value>=low and value<=high
	if not value is float or not is_finite(value): return false
	return value>=low and value<9223372036854775808.0 and value<=high and value==floor(value)

static func same(left: Variant, right: Variant) -> bool:
	if integer(left,-MAX_STAT) and integer(right,-MAX_STAT): return int(left)==int(right)
	if typeof(left)!=typeof(right): return false
	if left is Dictionary:
		if left.size()!=right.size(): return false
		for key in left:
			if not right.has(key) or not same(left[key],right[key]): return false
		return true
	if left is Array:
		if left.size()!=right.size(): return false
		for index in range(left.size()):
			if not same(left[index],right[index]): return false
		return true
	return left==right

static func accepts_id(identity: Variant) -> bool:
	return identity is String and identity in IDS

static func effect_claimed(effect: Variant) -> bool:
	return effect is Dictionary and (same(effect.get("type"),TYPE) or accepts_id(effect.get("source_id")))

static func effect_error(effect: Variant) -> String:
	if not effect_claimed(effect): return ""
	if not accepts_id(effect.get("source_id")): return "gnoll_death_aura_unbound_effect"
	return "" if same(effect,PROGRAMS[effect.source_id][0]) else "gnoll_death_aura_incomplete_reserved_effect"

static func program_for(identity: Variant) -> Array:
	return PROGRAMS[identity].duplicate(true) if accepts_id(identity) else []

static func _marker(value: Variant, depth: int = 0, embedded: bool = false) -> bool:
	if depth>32: return true
	if value is Dictionary:
		for key in ["id","card_id","card_code","source_id"]:
			if accepts_id(value.get(key)): return true
		if effect_claimed(value): return true
		for key in value:
			if same(key,"unit") and not embedded: continue
			if (value[key] is Dictionary or value[key] is Array) and _marker(value[key],depth+1,embedded): return true
	elif value is Array:
		for child in value:
			if _marker(child,depth+1,embedded): return true
	return false

static func _program_marker(value: Variant, depth: int = 0) -> bool:
	if depth>32: return true
	if value is Dictionary:
		if effect_claimed(value): return true
		for key in value:
			if key in ["unit","base_unit","_base"]: continue
			if (value[key] is Dictionary or value[key] is Array) and _program_marker(value[key],depth+1): return true
	elif value is Array:
		for child in value:
			if _program_marker(child,depth+1): return true
	return false

static func claimed(source: Variant) -> bool:
	return source is Dictionary and (accepts_id(source.get("id")) or accepts_id(source.get("card_id")) or _program_marker(source.get("effects",[])) or _marker(source.get("base_unit",{})) or _marker(source.get("_base",{})) or _marker(source.get("attachments",[])))

static func tree_claimed(value: Variant) -> bool:
	return _marker(value,0,true)

static func has_dynamic_layer(value: Variant, depth: int = 0) -> bool:
	if depth>32: return true
	if value is Dictionary:
		for key in value:
			if key is String and key.begins_with(PREFIX): return true
			if (value[key] is Dictionary or value[key] is Array) and has_dynamic_layer(value[key],depth+1): return true
	elif value is Array:
		for child in value:
			if has_dynamic_layer(child,depth+1): return true
	return false

static func validation_evidence() -> Dictionary:
	for path in FILE_SHA256:
		if FileAccess.get_sha256(FOLDER+path)!=FILE_SHA256[path]: return {"error":"gnoll_death_aura_evidence_changed:"+path}
	var contract: Variant=JSON.parse_string(FileAccess.get_file_as_string(FOLDER+"source_contract.json"))
	var expected: Variant=JSON.parse_string(FileAccess.get_file_as_string(FOLDER+"expected_compiled.json"))
	if not contract is Dictionary or not same(contract.get("source_ids"),IDS) or not same(contract.get("programs"),PROGRAMS) or not contract.get("records") is Dictionary: return {"error":"gnoll_death_aura_source_closure_changed"}
	if not same(expected,EXPECTED): return {"error":"gnoll_death_aura_expected_changed"}
	var rows: Dictionary={}
	for identity in IDS:
		var row: Variant=JSON.parse_string(FileAccess.get_file_as_string(FOLDER+"raw49/"+identity+".json"))
		if not row is Dictionary or row.size()!=49 or not contract.records.get(identity) is Dictionary or not same(row,contract.records[identity].get("source_row")): return {"error":"gnoll_death_aura_raw49_changed"}
		rows[identity]=row
	return {"error":"","rows":rows,"expected":expected}

static func _evidence_error(evidence: Dictionary) -> String:
	if not evidence.get("error") is String: return "gnoll_death_aura_missing_evidence"
	if not evidence.error.is_empty(): return evidence.error
	if not same(evidence.get("rows"),RAW49) or not same(evidence.get("expected"),EXPECTED): return "gnoll_death_aura_unverified_evidence_snapshot"
	return ""

static func raw_source_error(card: Variant, evidence: Dictionary = {}) -> String:
	if not card is Dictionary or not accepts_id(card.get("id")): return "gnoll_death_aura_unknown_raw_source"
	if evidence.is_empty(): evidence=validation_evidence()
	if not _evidence_error(evidence).is_empty(): return _evidence_error(evidence)
	return "" if same(card,evidence.rows[card.id]) else "gnoll_death_aura_complete_raw49_changed"

static func source_error(card: Variant, evidence: Dictionary = {}) -> String:
	if not card is Dictionary: return "gnoll_death_aura_invalid_source"
	if not claimed(card): return ""
	if not accepts_id(card.get("id")) or card.has("card_id"): return "gnoll_death_aura_unbound_source"
	if evidence.is_empty(): evidence=validation_evidence()
	if not _evidence_error(evidence).is_empty(): return _evidence_error(evidence)
	var expected: Dictionary=evidence.rows[card.id].duplicate(true)
	expected.merge(evidence.expected[card.id],true)
	if card.has("pool_blocker") and card.id==IDS[1]: expected.pool_blocker=PoolIdentity.MINION_REASON
	return "" if same(card,expected) else "gnoll_death_aura_complete_source_changed"

static func _card(catalog: Variant, identity: String) -> Dictionary:
	var value: Variant=catalog.get(identity,{}) if catalog is Dictionary else catalog.get_card(identity)
	return value if value is Dictionary else {}

static func closure_error(catalog: Variant, identity: Variant, evidence: Dictionary = {}) -> String:
	if catalog==null or not accepts_id(identity): return "gnoll_death_aura_unknown_source_or_catalog"
	if evidence.is_empty(): evidence=validation_evidence()
	if not _evidence_error(evidence).is_empty(): return _evidence_error(evidence)
	var catalogs: Array=[catalog]
	if catalog is Object and catalog.source_catalog!=null: catalogs.push_front(catalog.source_catalog)
	for current in catalogs:
		for source_id in IDS:
			var source: Dictionary=_card(current,source_id)
			if not same(source.get("id"),source_id): return "gnoll_death_aura_missing_pair_source"
			var issue: String=source_error(source,evidence)
			if not issue.is_empty(): return issue
	return ""

static func native_template(identity: String) -> Dictionary:
	var source: Dictionary=SOURCES[identity]
	return {"card_id":identity,"kind":"minion","name":source.name,"tier":source.tier,"attack":source.attack,"health":source.health,"max_health":source.health,"keywords":[],"tribes":source.tribes.duplicate(),"effects":program_for(identity),"golden":source.is_golden}

static func unit_error(unit: Variant, templates: Dictionary = {}, is_base: bool = false, evidence: Dictionary = {}) -> String:
	if not unit is Dictionary: return "gnoll_death_aura_invalid_unit"
	if not claimed(unit): return ""
	if unit.has("id") and not unit.has("card_id"): return source_error(unit,evidence)
	if not accepts_id(unit.get("card_id")): return "gnoll_death_aura_marker_on_wrong_source"
	var identity: String=unit.card_id
	if evidence.is_empty(): evidence=validation_evidence()
	if not _evidence_error(evidence).is_empty(): return _evidence_error(evidence)
	for source_id in IDS:
		if not templates.is_empty() and (not templates.has(source_id) or not same(templates[source_id],native_template(source_id))): return "gnoll_death_aura_native_template_changed"
	if not same(unit.get("effects"),PROGRAMS[identity]): return "gnoll_death_aura_complete_program_changed"
	for key in ["id","card_code"]:
		if unit.has(key) and not same(unit[key],identity): return "gnoll_death_aura_conflicting_identity"
	for key in ["name","tier","tribes"]:
		if not same(unit.get(key),SOURCES[identity][key]): return "gnoll_death_aura_native_identity_changed:"+key
	if not same(unit.get("kind","minion"),"minion") or not same(unit.get("golden"),SOURCES[identity].is_golden): return "gnoll_death_aura_native_variant_changed"
	for key in ["dbf_id","text","category","is_golden","normal_id","golden_id"]:
		if unit.has(key) and not same(unit[key],SOURCES[identity][key]): return "gnoll_death_aura_native_identity_changed:"+key
	for key in ["temporary","is_spellcraft","excluded","stats_conflict","duos_exclusive","requires_teammate_effect"]:
		if not same(unit.get(key,false),false): return "gnoll_death_aura_source_flag_changed:"+key
	for key in ["silenced","abilities_disabled","_pending_destroy"]:
		if unit.has(key) and not unit[key] is bool: return "gnoll_death_aura_invalid_activity_flag"
	for key in ["attachments","quality_flags","source_conflicts"]:
		if not same(unit.get(key,[]),[]): return "gnoll_death_aura_unverified_attachment_or_flag"
	for key in ["gnoll_death_aura_receipt","gnoll_death_aura_context","gnoll_death_aura_ticket","_gnoll_aura_state"]:
		if unit.has(key): return "gnoll_death_aura_imported_authority"
	if not integer(unit.get("attack"),0) or not integer(unit.get("health"),-MAX_STAT) or not integer(unit.get("max_health",unit.get("health")),1): return "gnoll_death_aura_invalid_live_stats"
	if unit.health>unit.get("max_health",unit.health): return "gnoll_death_aura_health_exceeds_maximum"
	if not unit.get("keywords",[]) is Array: return "gnoll_death_aura_invalid_keywords"
	for keyword in unit.get("keywords",[]):
		if not keyword is String: return "gnoll_death_aura_invalid_keywords"
	if unit.has("uid") and (not unit.uid is String or unit.uid.is_empty()): return "gnoll_death_aura_invalid_uid"
	if not is_base and not unit.has("uid") and not same(unit,native_template(identity)): return "gnoll_death_aura_missing_uid"
	if is_base and has_dynamic_layer(unit): return "gnoll_death_aura_transient_base_layer"
	for key in ["base_unit","_base"]:
		if unit.has(key):
			if is_base or not unit[key] is Dictionary or not same(unit[key].get("card_id"),identity) or has_dynamic_layer(unit[key]): return "gnoll_death_aura_invalid_base"
			var issue: String=unit_error(unit[key],templates,true,evidence)
			if not issue.is_empty(): return issue
	return ""

static func _references(value: Variant, result: Array, depth: int = 0) -> void:
	if depth>32: return
	if value is Dictionary:
		for key in ["id","card_id","source_id","normal_id","golden_id"]:
			if value.get(key) is String and not value[key].is_empty(): result.append(value[key])
		for key in value:
			if key in ["card_ids","ids"] and value[key] is Array:
				for identity in value[key]:
					if identity is String: result.append(identity)
			if value[key] is Dictionary or value[key] is Array: _references(value[key],result,depth+1)
	elif value is Array:
		for child in value: _references(child,result,depth+1)

static func _reachable(roots: Array, templates: Dictionary) -> Array:
	var result: Array=roots.duplicate()
	var queue: Array=[]
	_references(roots,queue)
	var seen: Dictionary={}
	while not queue.is_empty():
		var identity: String=queue.pop_front()
		if seen.has(identity): continue
		seen[identity]=true
		if not templates.has(identity): continue
		result.append(templates[identity])
		_references(templates[identity],queue)
	return result

static func _tree_error(value: Variant, templates: Dictionary, evidence: Dictionary, depth: int = 0) -> String:
	if depth>32: return "gnoll_death_aura_dependency_depth"
	if value is Dictionary:
		if claimed(value) and not value.has("type"):
			var issue: String=unit_error(value,templates,false,evidence)
			if not issue.is_empty(): return issue
		if effect_claimed(value):
			var issue: String=effect_error(value)
			if not issue.is_empty(): return issue
		for key in value:
			if key in ["base_unit","_base"] and claimed(value): continue
			if value[key] is Dictionary or value[key] is Array:
				var issue: String=_tree_error(value[key],templates,evidence,depth+1)
				if not issue.is_empty(): return issue
	elif value is Array:
		for child in value:
			var issue: String=_tree_error(child,templates,evidence,depth+1)
			if not issue.is_empty(): return issue
	return ""

static func roots_error(roots: Array, templates: Dictionary = {}) -> String:
	if has_dynamic_layer(roots): return "gnoll_death_aura_imported_combat_layer"
	var graph: Array=_reachable(roots,templates)
	if not tree_claimed(graph): return ""
	var evidence: Dictionary=validation_evidence()
	if not str(evidence.error).is_empty(): return str(evidence.error)
	return _tree_error(graph,templates,evidence)

static func domain_error(left: Array, right: Array, options: Dictionary = {}) -> String:
	var roots: Array=left+right
	for key in ["left_hand","right_hand","left_sources","right_sources","left_combat_hero","right_combat_hero","left_owner_aura_context","right_owner_aura_context"]:
		if options.get(key) is Array: roots.append_array(options[key])
		elif options.get(key) is Dictionary: roots.append(options[key])
	if not options.get("hand_card_templates",{}) is Dictionary: return "gnoll_death_aura_invalid_template_registry" if tree_claimed(roots) else ""
	var issue: String=roots_error(roots,options.get("hand_card_templates",{}))
	if not issue.is_empty(): return issue
	if tree_claimed(_reachable(roots,options.get("hand_card_templates",{}))):
		if not options.get("board_aura_catalog") is Dictionary: return "gnoll_death_aura_requires_pair_catalog"
		return closure_error(options.board_aura_catalog,IDS[0])
	return ""

static func room_error(roots: Array, catalog) -> String:
	var issue: String=roots_error(roots,catalog.hand_card_templates)
	if not issue.is_empty(): return issue
	return closure_error(catalog,IDS[0]) if tree_claimed(roots) else ""

static func saved_error(state: Dictionary, catalog) -> String:
	var roots: Array=[]
	for key in ["players","ghosts"]:
		if state.get(key,[]) is Array: roots.append_array(state.get(key,[]))
	if catalog==null: return "gnoll_death_aura_missing_catalog" if tree_claimed(roots) else ""
	var issue: String=roots_error(roots,catalog.hand_card_templates)
	if not issue.is_empty(): return issue
	return closure_error(catalog,IDS[0]) if tree_claimed(_reachable(roots,catalog.hand_card_templates)) else ""

static func play_error(engine, _player: Dictionary, source: Dictionary) -> String:
	var issue: String=saved_error(engine.state,engine.catalog)
	if not issue.is_empty(): return issue
	return unit_error(source,engine.catalog.hand_card_templates)

static func entry_key(unit: Dictionary) -> String:
	return PREFIX+str(unit.get("_combat_id",0))

static func marker_entry_error(key: Variant, entry: Variant, unit: Dictionary) -> String:
	if not key is String or not key.begins_with(PREFIX) or not entry is Dictionary or entry.size()!=7: return "gnoll_death_aura_invalid_marker_shape"
	for field in ["card_id","attack","health","side","combat_id","count","uid"]:
		if not entry.has(field): return "gnoll_death_aura_invalid_marker_shape"
	if not accepts_id(unit.get("card_id")) or not same(entry.card_id,unit.card_id) or not same(entry.uid,unit.get("uid")): return "gnoll_death_aura_foreign_marker"
	if not integer(entry.side,0,1) or not integer(entry.combat_id,1) or not same(entry.side,unit.get("_side")) or not same(entry.combat_id,unit.get("_combat_id")) or key!=entry_key(unit): return "gnoll_death_aura_foreign_combat_instance"
	var coefficient: int=int(PROGRAMS[unit.card_id][0].attack_per_death)
	if not integer(entry.count,1) or int(entry.count)>MAX_STAT/coefficient or not integer(entry.attack,1) or not same(entry.health,0) or int(entry.attack)!=int(entry.count)*coefficient: return "gnoll_death_aura_invalid_count_projection"
	return ""

static func _entry(unit: Dictionary) -> Dictionary:
	var marker: Variant=unit.get(APPLIED_KEY,{})
	if not marker is Dictionary or not marker.get("sources",{}) is Dictionary: return {}
	var value: Variant=marker.get("sources",{}).get(entry_key(unit),{})
	return value if value is Dictionary else {}

static func combat_source(engine, unit: Dictionary, side: int, owner: int) -> Dictionary:
	if not engine is Object or not engine.has_method("_find_unit") or not integer(side,0,1) or not integer(owner): return {"error":"gnoll_death_aura_requires_actual_combat"}
	var issue: String=unit_error(unit,engine._options.get("hand_card_templates",{}))
	if not issue.is_empty(): return {"error":issue}
	if not accepts_id(unit.get("card_id")) or not integer(unit.get("_combat_id"),1) or not same(unit.get("_side"),side): return {"error":"gnoll_death_aura_foreign_combat_instance"}
	if not is_same(engine._find_unit(side,int(unit._combat_id)),unit): return {"error":"gnoll_death_aura_foreign_live_reference"}
	var prefix: String="left" if side==0 else "right"
	if not same(engine._options.get(prefix+"_board_aura_owner"),owner): return {"error":"gnoll_death_aura_foreign_owner"}
	if not engine._death_history is Array or engine._death_history.size()!=2 or not engine._death_history[side] is Array or not engine._gnoll_aura_state is Dictionary: return {"error":"gnoll_death_aura_invalid_host_history"}
	var previous: Variant=engine._gnoll_aura_state.get(unit._combat_id)
	if previous==null:
		if has_dynamic_layer(unit): return {"error":"gnoll_death_aura_unrecorded_dynamic_layer"}
	elif not previous is Dictionary or not is_same(previous.get("unit"),unit) or not same(previous.get("entry"),_entry(unit)):
		return {"error":"gnoll_death_aura_changed_host_projection"}
	var count: int=engine._death_history[side].size()
	if previous is Dictionary and int(previous.entry.get("count",0))>count: return {"error":"gnoll_death_aura_history_went_backwards"}
	var coefficient: int=int(PROGRAMS[unit.card_id][0].attack_per_death)
	if count>MAX_STAT/coefficient: return {"error":"gnoll_death_aura_history_multiplication_overflow"}
	if unit.get("silenced",false) or unit.get("abilities_disabled",false): count=0
	if count==0: return {"error":"","source":{}}
	var entry: Dictionary={"card_id":unit.card_id,"attack":count*coefficient,"health":0,"side":side,"combat_id":unit._combat_id,"count":count,"uid":unit.uid}
	return {"error":"","source":{"uid":entry_key(unit),"card_id":unit.card_id,"attack":entry.attack,"health":0,"gnoll_entry":entry,"recipient_uid":unit.uid}}

static func commit_projection(engine) -> void:
	# Called only after the complete fresh two-side aura group commits.
	# Keep removed bodies' references untouched; re-entry has a new serial.
	for side in range(2):
		for unit in engine._boards[side]:
			if accepts_id(unit.get("card_id")): engine._gnoll_aura_state[unit._combat_id]={"unit":unit,"entry":_entry(unit).duplicate(true)}
