extends RefCounted
const Exact=preload("res://core/phase_undead_army_sources.gd")
const LIONFISH=["BG36_201","BG36_201_G"]
const BAIT=["BG36_205","BG36_205_G"]
const PORTRAIT="BG36_MagicItem_201"
const ACTIVATE="activate_replace_tavern_attack_bait"
const IMMUNITY="native_stat_gain_immunity"
const DEATH="deathrattle_buff_actual_killer"
const PROGRAMS={"BG36_201": [{"type": "activate_replace_tavern_attack_bait", "source_id": "BG36_201", "cost": 2, "bait_id": "BG36_205"}], "BG36_201_G": [{"type": "activate_replace_tavern_attack_bait", "source_id": "BG36_201_G", "cost": 2, "bait_id": "BG36_205_G"}], "BG36_205": [{"type": "native_stat_gain_immunity", "source_id": "BG36_205"}, {"type": "deathrattle_buff_actual_killer", "source_id": "BG36_205", "attack": 5, "health": 5}], "BG36_205_G": [{"type": "native_stat_gain_immunity", "source_id": "BG36_205_G"}, {"type": "deathrattle_buff_actual_killer", "source_id": "BG36_205_G", "attack": 10, "health": 10}], "BG36_MagicItem_201": [{"type": "mechanism_trigger", "event": "mechanic_acquired", "action": "add_native_minion", "source_id": "BG36_MagicItem_201", "card_id": "BG36_201", "count": 1}, {"type": "mechanism_native_friendly_attack", "source_id": "BG36_MagicItem_201", "action": "buff", "tribe": "野兽", "attack": 4, "health": 2}]}
const SOURCE={"BG36_201": {"id": "BG36_201", "card_code": "BG36_201", "dbf_id": "132794", "name": "深潜狮子鱼", "kind": "minion", "category": "随从", "tier": 2, "attack": 3, "health": 4, "cost": null, "tribes": ["野兽"], "is_golden": false, "normal_id": null, "golden_id": "BG36_201_G", "text": "发动（2）：选择酒馆中的一张牌，将其替换为鱼饵并使你最左边的野兽攻击该鱼饵。", "supported": true, "effects": [{"type": "activate_replace_tavern_attack_bait", "source_id": "BG36_201", "cost": 2, "bait_id": "BG36_205"}], "keywords": []}, "BG36_201_G": {"id": "BG36_201_G", "card_code": "BG36_201_G", "dbf_id": "132795", "name": "深潜狮子鱼", "kind": "minion", "category": "随从", "tier": 2, "attack": 6, "health": 8, "cost": null, "tribes": ["野兽"], "is_golden": true, "normal_id": "BG36_201", "golden_id": null, "text": "发动（2）：选择酒馆中的一张牌，将其替换为金色鱼饵并使你最左边的野兽攻击该鱼饵。", "supported": true, "effects": [{"type": "activate_replace_tavern_attack_bait", "source_id": "BG36_201_G", "cost": 2, "bait_id": "BG36_205_G"}], "keywords": []}, "BG36_205": {"id": "BG36_205", "card_code": "BG36_205", "dbf_id": "132802", "name": "鱼饵", "kind": "minion", "category": "关联特殊随从", "tier": 2, "attack": 0, "health": 1, "cost": null, "tribes": ["野兽"], "is_golden": false, "normal_id": null, "golden_id": "BG36_205_G", "text": "本随从无法获得属性值。亡语：使击杀本随从的随从获得+5/+5。", "supported": true, "effects": [{"type": "native_stat_gain_immunity", "source_id": "BG36_205"}, {"type": "deathrattle_buff_actual_killer", "source_id": "BG36_205", "attack": 5, "health": 5}], "keywords": []}, "BG36_205_G": {"id": "BG36_205_G", "card_code": "BG36_205_G", "dbf_id": "132803", "name": "鱼饵", "kind": "minion", "category": "关联特殊随从", "tier": 2, "attack": 0, "health": 2, "cost": null, "tribes": ["野兽"], "is_golden": true, "normal_id": "BG36_205", "golden_id": null, "text": "本随从无法获得属性值。亡语：使击杀本随从的随从获得+10/+10。", "supported": true, "effects": [{"type": "native_stat_gain_immunity", "source_id": "BG36_205_G"}, {"type": "deathrattle_buff_actual_killer", "source_id": "BG36_205_G", "attack": 10, "health": 10}], "keywords": []}, "BG36_MagicItem_201": {"id": "BG36_MagicItem_201", "card_code": "BG36_MagicItem_201", "dbf_id": "133388", "name": "狮子鱼肖像", "kind": "trinket", "category": "小型饰品", "tier": null, "attack": null, "health": null, "cost": 1, "tribes": [], "is_golden": false, "normal_id": null, "golden_id": null, "text": "获取一张深潜狮子鱼。每当一只友方野兽攻击，使其获得+4/+2。", "supported": true, "effects": [{"type": "mechanism_trigger", "event": "mechanic_acquired", "action": "add_native_minion", "source_id": "BG36_MagicItem_201", "card_id": "BG36_201", "count": 1}, {"type": "mechanism_native_friendly_attack", "source_id": "BG36_MagicItem_201", "action": "buff", "tribe": "野兽", "attack": 4, "health": 2}], "keywords": []}}
static func same(a: Variant,b: Variant) -> bool: return Exact.same(a,b)
static func claimed(unit: Dictionary) -> bool: return SOURCE.has(unit.get("card_id",unit.get("id")))
static func source_error(card: Dictionary) -> String:
 var id: String=str(card.get("id",""))
 if not SOURCE.has(id): return "lionfish_unbound_native_identity"
 for key in SOURCE[id]:
  if not same(card.get(key),SOURCE[id][key]): return "lionfish_changed_native_source:"+key
 return ""
static func unit_error(unit: Dictionary) -> String:
 if not claimed(unit): return ""
 if unit.has("id") and not unit.has("card_id"): return source_error(unit)
 var id: String=str(unit.get("card_id",""))
 if id==PORTRAIT: return "lionfish_portrait_is_not_owned_minion"
 for key in ["name","tier","tribes"]:
  if not same(unit.get(key),SOURCE[id][key]): return "lionfish_changed_native_body:"+key
 if unit.get("kind")!="minion" or not same(unit.get("golden"),SOURCE[id].is_golden) or not same(unit.get("effects"),PROGRAMS[id]): return "lionfish_changed_native_program"
 return ""
static func bait(unit: Dictionary) -> bool: return unit.get("card_id",unit.get("id")) in BAIT
static func enabled_bait(unit: Dictionary) -> bool:
 return bait(unit) and not unit.get("silenced",false) and not unit.get("abilities_disabled",false)
static func gain_plan(unit: Dictionary,attack: int,health: int) -> Dictionary:
 var result: Dictionary={"error":"","handled":false,"attack":attack,"health":health}
 if not bait(unit): return result
 result.error=unit_error(unit)
 if not str(result.error).is_empty() or not enabled_bait(unit): return result
 # Native positive gains are suppressed BEFORE stat mutation or gain readers.
 # Mixed negative/SET/transform semantics are not guessed from this helper.
 if attack<0 or health<0:
  result.error="fish_bait_mixed_negative_stat_transition_partial";return result
 result.handled=true;result.attack=0;result.health=0
 return result
static func effect_error(effect: Dictionary) -> String:
 var clean: Dictionary=effect.duplicate(true)
 for key in ["source_kind","source_slot","latest_instance"]: clean.erase(key)
 var id: String=str(clean.get("source_id",""))
 return "" if PROGRAMS.has(id) and PROGRAMS[id].any(func(native):return same(native,clean)) else "lionfish_changed_native_effect"
static func closure_error(catalog) -> String:
 if catalog==null: return "lionfish_missing_catalog"
 for current in [catalog.source_catalog if catalog.source_catalog!=null else catalog,catalog]:
  for id in LIONFISH+BAIT:
   var issue: String=source_error(current.get_card(id))
   if not issue.is_empty(): return issue
 return ""
static func stat_history_error(unit: Dictionary) -> String:
 if not enabled_bait(unit): return ""
 var issue: String=unit_error(unit)
 if not issue.is_empty(): return issue
 var native: Dictionary=SOURCE[unit.card_id]
 if unit.get("attack")!=native.attack or unit.get("max_health")!=native.health: return "fish_bait_unadapted_stat_producer_partial"
 # These ledgers can subtract or transfer a gain later. Reject an unadapted
 # producer in the complete-command shadow before payment, never roll it back.
 for key in ["temporary_buffs","blood_gem_buffs","board_aura_applied","permanent_tribe_applied","bulk_global_card_applied","beast_owner_layer_applied","recruit_shop_bonus_applied"]:
  if unit.has(key):
   if not (unit[key] is Array or unit[key] is Dictionary) or not unit[key].is_empty(): return "fish_bait_unadapted_stat_history_partial:"+key
 for key in ["recruit_shop_aura_attack","recruit_shop_aura_health"]:
  if int(unit.get(key,0))!=0: return "fish_bait_unadapted_stat_history_partial:"+key
 return ""
