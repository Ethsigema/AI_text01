extends RefCounted
## Complete independent Phalanx normal/golden source boundary only.
## Selectors/lifecycle remain owned by the existing board aura host.
const PoolIdentity = preload("res://core/pool_identity.gd")
const FOLDER: String = "res://research/phalanx_aura_sources/"
const IDS: Array = ["BG_ULD_179","TB_BaconUps_038"]
const PROGRAMS: Dictionary = {"BG_ULD_179":[{"type":"board_aura","scope":"all_friendly","keyword":"taunt","attack":2,"health":0,"attack_per_owner_tier":0,"duration":"while_source_on_board"}],"TB_BaconUps_038":[{"type":"board_aura","scope":"all_friendly","keyword":"taunt","attack":4,"health":0,"attack_per_owner_tier":0,"duration":"while_source_on_board"}]}
const FILE_SHA256: Dictionary = {"expected_compiled.json":"7dae870f2bd297b03be10affa43a38de045cbc835151611eda356b20b7da4318","expected_programs.json":"679d3c036c54edcb5b76616a9a17d86a2260a48add807fb387c54fd118282864","golden_value_override.json":"f0e0c330a7b881dd1695e990bd71afe563252e2f73f938c50124292746fb03b5","implementation_boundary.json":"77b4a9447ec692806826690dc0089c34bba59965e2a2962d412ac3a50d89d085","latest_bacon_absence.json":"493d806a07b85b244c8ccd22d5ea5f4976acaac2d5d7bed657929acc543797ed","native/BG_ULD_179.xml":"6c9080ee6eb2431a31fa0300f060293491e4b6f2f0d7acdc6a25016bd2f4e8d6","native/TB_BaconUps_038.xml":"b0527d766d6b88c646f681235e8d4f2e7dea6a2f7f6a34ed21204944f60d6600","native/TB_BaconUps_038e.xml":"6406cad2fdadc2972d5c3bd46a81e414ce75e3235408c83dcb50f3faf587fc8a","native/ULD_179e.xml":"08ccece4cdf3ebec4ed787c2f235e19c9b2a282af497febed56873338a4d6a9d","raw49/BG_ULD_179_raw49.json":"c10214d0ee68800d142b21f5595f96dc2140da4efe1296a27f4ee48b495cbcb0","raw49/TB_BaconUps_038_raw49.json":"8acc2b34cced035127dcf990bcaebd8e17535b940cb5adc82b1634921e64d952","source_contract.json":"7bfff72a1c89c3e7220352fbe16b8ba6a8c21c417e5c740dfa09fc4e3392f95b"}
const OVERRIDE: Dictionary = {"id":"TB_BaconUps_038","fields":{"attack":8,"health":10},"verification":{"status":"confirmed","method":"direct_independent_battlegrounds_golden_entity_tags","source_status":"verified_terminal_no_longer_defined","source_build":225000,"source_patch":"33.0.3.225000","derived_from_normal":false,"per_field_sources":{"attack":{"value":8,"verification":"verified_direct_independent_entity_tag","source_build":225000,"source_patch":"33.0.3.225000","source_url":"https://raw.githubusercontent.com/HearthSim/hsdata/f7e80e44cf0d02b5c6e6de2817d4d920cdcb9cb2/CardDefs.xml","source_revision_url":"https://github.com/HearthSim/hsdata/blob/f7e80e44cf0d02b5c6e6de2817d4d920cdcb9cb2/CardDefs.xml","source_selector":"Entity[@CardID=\"TB_BaconUps_038\"][@ID=\"58385\"]/Tag[@enumID=\"47\"]","explicit_tag":{"enumID":47,"name":"ATK","type":"Int","value":8},"derived_from_normal":false},"health":{"value":10,"verification":"verified_direct_independent_entity_tag","source_build":225000,"source_patch":"33.0.3.225000","source_url":"https://raw.githubusercontent.com/HearthSim/hsdata/f7e80e44cf0d02b5c6e6de2817d4d920cdcb9cb2/CardDefs.xml","source_revision_url":"https://github.com/HearthSim/hsdata/blob/f7e80e44cf0d02b5c6e6de2817d4d920cdcb9cb2/CardDefs.xml","source_selector":"Entity[@CardID=\"TB_BaconUps_038\"][@ID=\"58385\"]/Tag[@enumID=\"45\"]","explicit_tag":{"enumID":45,"name":"HEALTH","type":"Int","value":10},"derived_from_normal":false}}},"source_urls":["https://raw.githubusercontent.com/HearthSim/hsdata/f7e80e44cf0d02b5c6e6de2817d4d920cdcb9cb2/CardDefs.xml","https://github.com/HearthSim/hsdata/blob/f7e80e44cf0d02b5c6e6de2817d4d920cdcb9cb2/CardDefs.xml"],"original_field_status":{"attack":{"raw":"16\n源图值·待核实","value":null,"status":"unverified","verification":"待核实","value_source":"源图"},"health":{"raw":"20\n源图值·待核实","value":null,"status":"unverified","verification":"待核实","value_source":"源图"}},"conflicts_vs_original":[{"field":"attack","original_raw":"16\n源图值·待核实","original_numeric_claim":16,"verified_value":8,"conflict":"original_image_or_patch_claim_differs_from_independently_recorded_golden_value"},{"field":"health","original_raw":"20\n源图值·待核实","original_numeric_claim":20,"verified_value":10,"conflict":"original_image_or_patch_claim_differs_from_independently_recorded_golden_value"}],"confirmed_original_claims":[],"notes":["Attack/Health read directly from the requested golden CardID, not multiplied or copied from its normal counterpart.","The original raw image/patch claim is retained in conflicts or confirmations; source pixels were not altered."]}
const TOGGLE_PROGRAM: Array = [{"type":"spell_buff","attack":1,"health":2,"scope":"target","allow_shop":true},{"type":"spell_toggle_taunt","scope":"target","allow_shop":true}]

static func same(left: Variant, right: Variant) -> bool:
	# Source literals use bounded numbers, with strict booleans and Strings.
	if (left is int or left is float) and (right is int or right is float):
		return is_finite(left) and is_finite(right) and left == right
	if typeof(left) != typeof(right): return false
	if left is Dictionary:
		if left.size() != right.size(): return false
		for key in right:
			if not left.has(key) or not same(left[key], right[key]): return false
		return true
	if left is Array:
		if left.size() != right.size(): return false
		for index in range(left.size()):
			if not same(left[index], right[index]): return false
		return true
	return left == right

static func accepts_id(identity: Variant) -> bool:
	return identity is String and identity in IDS

static func effect_error(effect: Variant) -> String:
	if not effect is Dictionary: return "phalanx_effect_not_dictionary"
	for key in ["type", "scope", "keyword", "duration"]:
		if not effect.get(key) is String: return "phalanx_effect_invalid_string:" + key
	for identity in IDS:
		if same(effect, PROGRAMS[identity][0]): return ""
	return "phalanx_complete_effect_changed"

static func player_has_source(player: Dictionary) -> bool:
	for unit in player.get("board", []):
		if unit is Dictionary and accepts_id(unit.get("card_id")): return true
	return false

static func validation_evidence() -> Dictionary:
	for path in FILE_SHA256:
		if FileAccess.get_sha256(FOLDER+path) != FILE_SHA256[path]: return {"error":"phalanx_evidence_changed:"+path}
	var contract: Variant = JSON.parse_string(FileAccess.get_file_as_string(FOLDER+"source_contract.json"))
	var expected: Variant = JSON.parse_string(FileAccess.get_file_as_string(FOLDER+"expected_compiled.json"))
	var overrides: Variant = JSON.parse_string(FileAccess.get_file_as_string("res://data/catalog_value_overrides.json"))
	if not contract is Dictionary or not contract.get("records") is Dictionary or not expected is Dictionary or expected.size() != 2 or not overrides is Dictionary or not overrides.get("overrides") is Array: return {"error":"phalanx_evidence_shape_changed"}
	var matches: int = 0
	for entry in overrides.overrides:
		if entry is Dictionary and entry.get("id") is String and entry.id == IDS[1]:
			if not same(entry,OVERRIDE): return {"error":"phalanx_independent_override_changed"}
			matches += 1
	if matches != 1: return {"error":"phalanx_independent_override_missing_or_duplicate"}
	var rows: Dictionary = {}
	for identity in IDS:
		var row: Variant = JSON.parse_string(FileAccess.get_file_as_string(FOLDER+contract.records[identity].raw49_file))
		if not row is Dictionary or row.size() != 49 or not same(row,contract.records[identity].raw49) or not same(expected.get(identity,{}).get("effects"),PROGRAMS[identity]): return {"error":"phalanx_complete_evidence_changed"}
		rows[identity] = row
	return {"error":"","rows":rows,"expected":expected}

static func raw_source_error(card: Variant, evidence: Dictionary = {}) -> String:
	if not card is Dictionary or not accepts_id(card.get("id")): return "phalanx_unknown_raw_source"
	if evidence.is_empty(): evidence = validation_evidence()
	if not str(evidence.get("error","phalanx_missing_evidence")).is_empty(): return str(evidence.error)
	return "" if same(card,evidence.rows[card.id]) else "phalanx_complete_raw_source_changed"

static func _expected(identity: String, evidence: Dictionary) -> Dictionary:
	var result: Dictionary = evidence.rows[identity].duplicate(true)
	result.merge(evidence.expected[identity],true)
	if identity == IDS[1]:
		for field in OVERRIDE.fields:
			result[field] = OVERRIDE.fields[field]
			result.field_status[field] = {"status":"known","verification":"confirmed_independent_entity","value":OVERRIDE.fields[field]}
		result.value_override_verification = OVERRIDE.verification.duplicate(true)
	return result

static func source_error(card: Variant, custom_projection: bool = false, evidence: Dictionary = {}) -> String:
	if not card is Dictionary or not accepts_id(card.get("id")) or card.has("card_id"): return "phalanx_unknown_effective_source"
	if evidence.is_empty(): evidence = validation_evidence()
	if not str(evidence.get("error","phalanx_missing_evidence")).is_empty(): return str(evidence.error)
	var expected: Dictionary = _expected(card.id,evidence)
	var actual: Dictionary = card.duplicate(true)
	if actual.has("pool_blocker") and card.id == IDS[1]: expected.pool_blocker = PoolIdentity.MINION_REASON
	if actual.has("source_shop_fields"):
		if not custom_projection or not same(actual.source_shop_fields,{"tier":expected.tier,"cost":expected.cost,"pool_supported":false}): return "phalanx_custom_source_changed"
		if card.id == IDS[0]:
			var entry: Variant = actual.get("custom_shop_override")
			if not entry is Dictionary or entry.size() != 3: return "phalanx_custom_parameters_changed"
			for key in ["tier","cost","copies"]:
				if not entry.get(key) is int and not entry.get(key) is float: return "phalanx_custom_parameters_changed"
				if not is_finite(entry[key]) or entry[key] != floor(entry[key]): return "phalanx_custom_parameters_changed"
			if entry.tier < 1 or entry.tier > 6 or entry.cost < 0 or entry.cost > 99 or entry.copies < 1 or entry.copies > 99: return "phalanx_custom_parameters_changed"
			if not same(actual.get("tier"),entry.tier) or not same(actual.get("cost"),entry.cost) or not same(actual.get("pool_supported"),true): return "phalanx_custom_projection_changed"
			actual.cost = expected.cost; actual.pool_supported = false; actual.erase("custom_shop_override")
		else:
			if not same(actual.get("custom_shop_derived_from"),IDS[0]): return "phalanx_custom_golden_projection_changed"
			actual.erase("custom_shop_derived_from")
		actual.tier = expected.tier; actual.erase("source_shop_fields")
	return "" if same(actual,expected) else "phalanx_complete_source_changed"

static func closure_error(catalog) -> String:
	var canonical = catalog
	if catalog is Object:
		if catalog.get("source_catalog") != null: canonical = catalog.source_catalog
		if not canonical is Object or canonical.get("source_catalog") != null: return "phalanx_invalid_canonical_catalog"
	elif not catalog is Dictionary: return "phalanx_missing_catalog"
	var evidence: Dictionary = validation_evidence()
	if not str(evidence.error).is_empty(): return str(evidence.error)
	for identity in IDS:
		var original: Dictionary = canonical.get(identity,{}) if canonical is Dictionary else canonical.get_card(identity)
		var issue: String = source_error(original,canonical is Dictionary and original.has("source_shop_fields"),evidence)
		if not issue.is_empty(): return issue
		if catalog != canonical:
			issue = source_error(catalog.get_card(identity),true,evidence)
			if not issue.is_empty(): return issue
	return ""
