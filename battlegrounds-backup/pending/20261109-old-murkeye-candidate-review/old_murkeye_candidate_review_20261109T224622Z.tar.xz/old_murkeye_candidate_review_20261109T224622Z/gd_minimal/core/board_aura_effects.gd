extends RefCounted
const OldMurkEye=preload("res://core/old_murkeye_aura_sources.gd")
const LionfishSources=preload("res://core/lionfish_sources.gd")
const HolyVanguard=preload("res://core/holy_vanguard_sources.gd")
const Gnoll = preload("res://core/gnoll_death_aura_sources.gd")
## Pure, source-closed board-aura candidate. No Game/Combat/Catalog registration.
## Call only at a stable living-board boundary; the host retains dead receipts.
const OwnerSources = preload("res://core/owner_aura_sources.gd")
const Phalanx = preload("res://core/phalanx_aura_sources.gd")
const Cyberdrake = preload("res://core/cyberdrake_aura_sources.gd")
const MAX_STAT: int = 9223372036854775807
const MIN_STAT: int = -9223372036854775807 - 1
const ORDINARY_ATTACK_KEY: String = "board_aura_non_aura_attack"
const MAX_UID_LENGTH: int = 256
const APPLIED_KEY: String = "board_aura_applied"
const EFFECT_TYPE: String = "board_aura"
const OWNED_ZONES: Array = ["board", "hand", "shop"]
const TRIBES: Array = ["野兽", "恶魔", "龙", "元素", "机械", "鱼人", "纳迦", "海盗", "野猪人", "亡灵", "德莱尼", "畸变怪"]
const CARD_GATE: String = "Source-owned layer requires the closed production host and operation admission contract."
# Full independently recorded normal/golden definitions; generated literally from
# board_aura_patterns.SOURCE_FIXTURES, not from normal-to-golden multiplication.
const SOURCE_SPECS: Dictionary = {
	"BG_EX1_062":{"text":"冲锋，在战场上每有一个其他鱼人便拥有+1攻击力。","native":[2,2,4],"is_golden":false,"dbf_id":"0736","normal_id":null,"golden_id":"TB_BaconUps_036","tribes":["鱼人"],"effects":[{"type":"board_aura","scope":"self","tribe":"","source_id":"BG_EX1_062","attack":0,"health":0,"attack_per_owner_tier":0,"attack_per_other_murloc":1,"duration":"while_source_on_board"}],"keywords":["charge"]},
	"TB_BaconUps_036":{"text":"冲锋，在战场上每有一个其他鱼人便拥有+2攻击力。","native":[2,4,8],"is_golden":true,"dbf_id":"58382","normal_id":"BG_EX1_062","golden_id":null,"tribes":["鱼人"],"effects":[{"type":"board_aura","scope":"self","tribe":"","source_id":"TB_BaconUps_036","attack":0,"health":0,"attack_per_owner_tier":0,"attack_per_other_murloc":2,"duration":"while_source_on_board"}],"keywords":["charge"]},

	"EX1_162":{"text":"相邻的随从拥有+1攻击力。","is_golden":false,"dbf_id":"985","normal_id":null,"golden_id":"TB_BaconUps_088","tribes":["野兽"],"keywords":[],"native":[1,2,2],"effects":[{"type":"board_aura","scope":"adjacent","tribe":"","attack":1,"health":0,"attack_per_owner_tier":0,"duration":"while_source_on_board"}]},
	"TB_BaconUps_088":{"text":"相邻的随从拥有+2攻击力。","is_golden":true,"dbf_id":"60025","normal_id":"EX1_162","golden_id":null,"tribes":["野兽"],"keywords":[],"native":[1,4,4],"effects":[{"type":"board_aura","scope":"adjacent","tribe":"","attack":2,"health":0,"attack_per_owner_tier":0,"duration":"while_source_on_board"}]},
	"BG36_372":{"text":"圣盾。如果你的生命值小于或等于15点，拥有+30/+30。","native":[4,10,10],"is_golden":false,"dbf_id":"134409","normal_id":null,"golden_id":"BG36_372_G","tribes":[],"effects":[{"type":"board_aura","scope":"self","tribe":"","source_id":"BG36_372","owner_health_max":15,"attack":30,"health":30,"attack_per_owner_tier":0,"duration":"while_source_on_board"}],"keywords":["divine_shield"]},
	"BG36_372_G":{"text":"圣盾。如果你的生命值小于或等于15点，拥有+60/+60。","native":[4,20,20],"is_golden":true,"dbf_id":"134410","normal_id":"BG36_372","golden_id":null,"tribes":[],"effects":[{"type":"board_aura","scope":"self","tribe":"","source_id":"BG36_372_G","owner_health_max":15,"attack":60,"health":60,"attack_per_owner_tier":0,"duration":"while_source_on_board"}],"keywords":["divine_shield"]},
  "BG25_043": {"text":"圣盾。你的圣盾随从拥有+6攻击力。","native":[5,3,10],"is_golden":false,"dbf_id":"97557","normal_id":null,"golden_id":"BG25_043_G","tribes":["机械","龙"],"effects":[{"type":"board_aura","scope":"all_friendly","keyword":"divine_shield","attack":6,"health":0,"attack_per_owner_tier":0,"duration":"while_source_on_board"}],"keywords":["divine_shield"]},
  "BG25_043_G": {"text":"圣盾。你的圣盾随从拥有+12攻击力。","native":[5,6,20],"is_golden":true,"dbf_id":"97558","normal_id":"BG25_043","golden_id":null,"tribes":["机械","龙"],"effects":[{"type":"board_aura","scope":"all_friendly","keyword":"divine_shield","attack":12,"health":0,"attack_per_owner_tier":0,"duration":"while_source_on_board"}],"keywords":["divine_shield"]},
  "BG_ULD_179": {"text":"你的嘲讽随从拥有+2攻击力。","native":[3,4,5],"is_golden":false,"dbf_id":"54153","normal_id":null,"golden_id":"TB_BaconUps_038","tribes":[],"effects":[{"type":"board_aura","scope":"all_friendly","keyword":"taunt","attack":2,"health":0,"attack_per_owner_tier":0,"duration":"while_source_on_board"}],"keywords":[]},
  "TB_BaconUps_038": {"text":"你的嘲讽随从拥有+4攻击力。","native":[3,8,10],"is_golden":true,"dbf_id":"58385","normal_id":"BG_ULD_179","golden_id":null,"tribes":[],"effects":[{"type":"board_aura","scope":"all_friendly","keyword":"taunt","attack":4,"health":0,"attack_per_owner_tier":0,"duration":"while_source_on_board"}],"keywords":[]},
  "BG_EX1_507": {
    "text": "你的其他鱼人拥有+2攻击力。",
    "native": [
      2,
      3,
      3
    ],
    "is_golden": false,
    "dbf_id": "96768",
    "normal_id": null,
    "golden_id": "TB_BaconUps_008",
    "tribes": [
      "鱼人"
    ],
    "effects": [
      {
        "type": "board_aura",
        "scope": "other_friendly",
        "tribe": "鱼人",
        "attack": 2,
        "health": 0,
        "attack_per_owner_tier": 0,
        "duration": "while_source_on_board"
      }
    ],
    "keywords": []
  },
  "TB_BaconUps_008": {
    "text": "你的其他鱼人拥有+4攻击力。",
    "native": [
      2,
      6,
      6
    ],
    "is_golden": true,
    "dbf_id": "57403",
    "normal_id": "BG_EX1_507",
    "golden_id": null,
    "tribes": [
      "鱼人"
    ],
    "effects": [
      {
        "type": "board_aura",
        "scope": "other_friendly",
        "tribe": "鱼人",
        "attack": 4,
        "health": 0,
        "attack_per_owner_tier": 0,
        "duration": "while_source_on_board"
      }
    ],
    "keywords": []
  },
  "BG33_115": {
    "text": "复生。你的其他亡灵拥有+1攻击力。",
    "native": [
      2,
      3,
      2
    ],
    "is_golden": false,
    "dbf_id": "122485",
    "normal_id": null,
    "golden_id": "BG33_115_G",
    "tribes": [
      "亡灵"
    ],
    "effects": [
      {
        "type": "board_aura",
        "scope": "other_friendly",
        "tribe": "亡灵",
        "attack": 1,
        "health": 0,
        "attack_per_owner_tier": 0,
        "duration": "while_source_on_board"
      }
    ],
    "keywords": [
      "reborn"
    ]
  },
  "BG33_115_G": {
    "text": "复生。你的其他亡灵拥有+2攻击力。",
    "native": [
      2,
      6,
      4
    ],
    "is_golden": true,
    "dbf_id": "122486",
    "normal_id": "BG33_115",
    "golden_id": null,
    "tribes": [
      "亡灵"
    ],
    "effects": [
      {
        "type": "board_aura",
        "scope": "other_friendly",
        "tribe": "亡灵",
        "attack": 2,
        "health": 0,
        "attack_per_owner_tier": 0,
        "duration": "while_source_on_board"
      }
    ],
    "keywords": [
      "reborn"
    ]
  },
  "BG27_030": {
    "text": "你的其他亡灵额外拥有等同于你当前等级的攻击力。",
    "native": [
      3,
      2,
      4
    ],
    "is_golden": false,
    "dbf_id": "103726",
    "normal_id": null,
    "golden_id": "BG27_030_G",
    "tribes": [
      "亡灵"
    ],
    "effects": [
      {
        "type": "board_aura",
        "scope": "other_friendly",
        "tribe": "亡灵",
        "attack": 0,
        "health": 0,
        "attack_per_owner_tier": 1,
        "duration": "while_source_on_board"
      }
    ],
    "keywords": []
  },
  "BG27_030_G": {
    "text": "你的其他亡灵额外拥有等同于你当前等级两倍的攻击力。",
    "native": [
      3,
      4,
      8
    ],
    "is_golden": true,
    "dbf_id": "103727",
    "normal_id": "BG27_030",
    "golden_id": null,
    "tribes": [
      "亡灵"
    ],
    "effects": [
      {
        "type": "board_aura",
        "scope": "other_friendly",
        "tribe": "亡灵",
        "attack": 0,
        "health": 0,
        "attack_per_owner_tier": 2,
        "duration": "while_source_on_board"
      }
    ],
    "keywords": []
  },
  "BG_EX1_185": {
    "text": "嘲讽你的其他恶魔拥有+1攻击力。",
    "native": [
      4,
      5,
      8
    ],
    "is_golden": false,
    "dbf_id": "54835",
    "normal_id": null,
    "golden_id": "TB_BaconUps_053",
    "tribes": [
      "恶魔"
    ],
    "effects": [
      {
        "type": "board_aura",
        "scope": "other_friendly",
        "tribe": "恶魔",
        "attack": 1,
        "health": 0,
        "attack_per_owner_tier": 0,
        "duration": "while_source_on_board"
      }
    ],
    "keywords": [
      "taunt"
    ]
  },
  "TB_BaconUps_053": {
    "text": "嘲讽你的其他恶魔拥有+2攻击力。",
    "native": [
      4,
      10,
      16
    ],
    "is_golden": true,
    "dbf_id": "58418",
    "normal_id": "BG_EX1_185",
    "golden_id": null,
    "tribes": [
      "恶魔"
    ],
    "effects": [
      {
        "type": "board_aura",
        "scope": "other_friendly",
        "tribe": "恶魔",
        "attack": 2,
        "health": 0,
        "attack_per_owner_tier": 0,
        "duration": "while_source_on_board"
      }
    ],
    "keywords": [
      "taunt"
    ]
  },
  "BG_NEW1_027": {
    "text": "你的其他海盗拥有+1/+1。",
    "native": [
      2,
      3,
      3
    ],
    "is_golden": false,
    "dbf_id": "96771",
    "normal_id": null,
    "golden_id": "TB_BaconUps_136",
    "tribes": [
      "海盗"
    ],
    "effects": [
      {
        "type": "board_aura",
        "scope": "other_friendly",
        "tribe": "海盗",
        "attack": 1,
        "health": 1,
        "attack_per_owner_tier": 0,
        "duration": "while_source_on_board"
      }
    ],
    "keywords": []
  },
  "TB_BaconUps_136": {
    "text": "你的其他海盗拥有+2/+2。",
    "native": [
      2,
      6,
      6
    ],
    "is_golden": true,
    "dbf_id": "62237",
    "normal_id": "BG_NEW1_027",
    "golden_id": null,
    "tribes": [
      "海盗"
    ],
    "effects": [
      {
        "type": "board_aura",
        "scope": "other_friendly",
        "tribe": "海盗",
        "attack": 2,
        "health": 2,
        "attack_per_owner_tier": 0,
        "duration": "while_source_on_board"
      }
    ],
    "keywords": []
  },
  "BG21_039": {
    "text": "你的其他恶魔拥有+2攻击力。你的英雄免疫。",
    "native": [
      3,
      5,
      4
    ],
    "is_golden": false,
    "dbf_id": "76566",
    "normal_id": null,
    "golden_id": "BG21_039_G",
    "tribes": [
      "恶魔"
    ],
    "effects": [
      {
        "type": "board_aura",
        "scope": "other_friendly",
        "tribe": "恶魔",
        "attack": 2,
        "health": 0,
        "attack_per_owner_tier": 0,
        "duration": "while_source_on_board"
      },
      {
        "type": "hero_immune_while_on_board"
      }
    ],
    "keywords": []
  },
  "BG21_039_G": {
    "text": "你的其他恶魔拥有+4攻击力。你的英雄免疫。",
    "native": [
      3,
      10,
      8
    ],
    "is_golden": true,
    "dbf_id": "76569",
    "normal_id": "BG21_039",
    "golden_id": null,
    "tribes": [
      "恶魔"
    ],
    "effects": [
      {
        "type": "board_aura",
        "scope": "other_friendly",
        "tribe": "恶魔",
        "attack": 4,
        "health": 0,
        "attack_per_owner_tier": 0,
        "duration": "while_source_on_board"
      },
      {
        "type": "hero_immune_while_on_board"
      }
    ],
    "keywords": []
  },
  "BG_GVG_021": {
    "text": "你的英雄免疫。你的其他恶魔拥有+2/+2。",
    "native": [
      5,
      9,
      7
    ],
    "is_golden": false,
    "dbf_id": "1986",
    "normal_id": null,
    "golden_id": "TB_BaconUps_060",
    "tribes": [
      "恶魔"
    ],
    "effects": [
      {
        "type": "board_aura",
        "scope": "other_friendly",
        "tribe": "恶魔",
        "attack": 2,
        "health": 2,
        "attack_per_owner_tier": 0,
        "duration": "while_source_on_board"
      },
      {
        "type": "hero_immune_while_on_board"
      }
    ],
    "keywords": []
  },
  "TB_BaconUps_060": {
    "text": "你的其他恶魔拥有+4/+4。你的英雄免疫。",
    "native": [
      5,
      18,
      14
    ],
    "is_golden": true,
    "dbf_id": "58428",
    "normal_id": "BG_GVG_021",
    "golden_id": null,
    "tribes": [
      "恶魔"
    ],
    "effects": [
      {
        "type": "board_aura",
        "scope": "other_friendly",
        "tribe": "恶魔",
        "attack": 4,
        "health": 4,
        "attack_per_owner_tier": 0,
        "duration": "while_source_on_board"
      },
      {
        "type": "hero_immune_while_on_board"
      }
    ],
    "keywords": []
  }
}

static func integer(value: Variant, minimum: int = 0) -> bool:
	return (value is int and value >= minimum) or (value is float and is_finite(value) and value >= minimum and value < 9223372036854775808.0 and value == floor(value))

static func signed_integer(value: Variant) -> bool:
	return value is int or (value is float and is_finite(value) and value >= -9223372036854775808.0 and value < 9223372036854775808.0 and value == floor(value))

static func same(left: Variant, right: Variant) -> bool:
	# Godot container equality distinguishes JSON floats from integer literals.
	# Normalize only exact bounded integer values, never booleans or lossy bounds.
	if signed_integer(left) and signed_integer(right):
		return int(left) == int(right)
	if typeof(left) != typeof(right):
		return false
	if left is Dictionary:
		if left.size() != right.size():
			return false
		for key in left:
			if not right.has(key) or not same(left[key], right[key]):
				return false
		return true
	if left is Array:
		if left.size() != right.size():
			return false
		for index in range(left.size()):
			if not same(left[index], right[index]):
				return false
		return true
	return left == right

static func _sum_error(left: int, right: int) -> bool:
	return (right > 0 and left > MAX_STAT - right) or (right < 0 and left < MIN_STAT - right)

static func effect_error(effect: Variant) -> String:
	if effect is Dictionary and (effect.has("attack_per_other_murloc") or OldMurkEye.accepts_id(effect.get("source_id"))): return OldMurkEye.effect_error(effect)
	if effect is Dictionary and (effect.has("owner_health_max") or HolyVanguard.accepts_id(effect.get("source_id"))): return HolyVanguard.effect_error(effect)
	if effect is Dictionary and effect.has("keyword"):
		if effect.get("keyword") is String and effect.keyword == "divine_shield": return Cyberdrake.effect_error(effect)
		return Phalanx.effect_error(effect)
	if not effect is Dictionary or effect.size() != 7:
		return "Board aura requires exactly type, scope, tribe, attack, health, attack_per_owner_tier and duration"
	if effect.get("type") != EFFECT_TYPE or effect.get("scope") not in ["other_friendly","adjacent"] or effect.get("duration") != "while_source_on_board":
		return "Unsupported board aura trigger, scope or duration"
	if not effect.get("tribe") is String or (effect["tribe"] not in TRIBES and not (effect.get("scope")=="adjacent" and effect["tribe"]=="")):
		return "Board aura requires one supported named tribe"
	if effect.get("scope")=="adjacent" and (effect.get("attack") not in [1,2] or effect.get("health")!=0 or effect.get("attack_per_owner_tier")!=0): return "Adjacent aura requires exact native Dire Wolf amounts"
	for key in ["attack", "health", "attack_per_owner_tier"]:
		if not integer(effect.get(key)):
			return "Board aura amounts must be non-negative safe integers"
	if int(effect["attack_per_owner_tier"]) > 0 and (int(effect["attack"]) != 0 or int(effect["health"]) != 0):
		return "Owner-tier aura cannot mix fixed amounts"
	if int(effect["attack"]) == 0 and int(effect["health"]) == 0 and int(effect["attack_per_owner_tier"]) == 0:
		return "Empty aura is not an effect"
	return ""

static func _card(catalog: Variant, identity: String) -> Dictionary:
	var card: Variant = {}
	if catalog is Dictionary:
		card = catalog.get(identity, {})
	elif catalog is Object and catalog.has_method("get_card"):
		card = catalog.get_card(identity)
	return card if card is Dictionary else {}

static func _definition_error(card: Dictionary, identity: String) -> String:
	if OldMurkEye.accepts_id(identity):
		var murkeye_issue: String=OldMurkEye.source_error(card)
		if not murkeye_issue.is_empty(): return murkeye_issue
	if HolyVanguard.accepts_id(identity):
		var holy_issue: String=HolyVanguard.source_error(card)
		if not holy_issue.is_empty(): return holy_issue
	if Cyberdrake.accepts_id(identity):
		var cyberdrake_issue: String = Cyberdrake.source_error(card)
		if not cyberdrake_issue.is_empty(): return cyberdrake_issue
	if Phalanx.accepts_id(identity):
		var phalanx_issue: String = Phalanx.source_error(card)
		if not phalanx_issue.is_empty(): return phalanx_issue
	if not SOURCE_SPECS.has(identity):
		return "Aura source identity has no complete reviewed definition: " + identity
	var spec: Dictionary = SOURCE_SPECS[identity]
	if card.get("id") != identity or card.get("card_code") != identity or card.get("dbf_id") != spec["dbf_id"] or card.get("kind") != "minion":
		return "Aura source identity, DBF or kind differs from its exact source"
	for key in ["text", "is_golden", "normal_id", "golden_id", "tribes", "effects", "keywords"]:
		if not same(card.get(key), spec[key]):
			return "Aura source is not a complete exact definition: " + key
	if not card.get("is_golden") is bool or card.get("supported") != true or not card.get("supported") is bool:
		return "Aura source and independent counterpart must be explicitly supported in the supplied catalog"
	for flag in ["excluded", "duos_exclusive", "requires_teammate_effect", "stats_conflict"]:
		if not card.get(flag, false) is bool or card.get(flag, false):
			return "Aura source eligibility gate: " + flag
	if card.get("solo_eligible", true) != true or not card.get("solo_eligible", true) is bool:
		return "Aura source is not solo eligible"
	for key in ["source_conflicts", "dependencies", "dependency_ids", "required_card_ids", "requires_cards"]:
		if card.get(key):
			return "Aura source has unreviewed conflicts or dependencies"
	for key in ["source_shop_fields", "custom_shop_override", "custom_shop_derived_from"]:
		if card.has(key):
			return "Custom shop metadata must pass complete room-source validation"
	var statuses: Variant = card.get("field_status", {})
	var validation: Variant = card.get("latest_validation", {})
	if not statuses is Dictionary or not validation is Dictionary or validation.get("data_gate", false):
		return "Aura source has malformed or blocked verification metadata"
	for index in range(3):
		var key: String = ["tier", "attack", "health"][index]
		# A sanctioned custom shop tier is a host concern; it must not affect owner tier.
		var value: Variant = card.get(key)
		if not integer(value, 1) or int(value) != spec["native"][index]:
			return "Aura source native value differs from its independent record: " + key
		var status: Variant = statuses.get(key, {})
		if not status is Dictionary or status.get("status", "known") in ["unverified", "conflict", "unknown"] or (status.has("value") and not same(status["value"], value)):
			return "Aura source value is unverified: " + key
	return ""

static func _keys(value: Dictionary, keys: Array) -> bool:
	if value.size() != keys.size():
		return false
	for key in keys:
		if not value.has(key):
			return false
	return true

static func room_source_error(catalog: Variant, identity: String) -> String:
	var card: Dictionary = _card(catalog, identity)
	if not card.has("custom_shop_override") and not card.has("source_shop_fields") and not card.has("custom_shop_derived_from"):
		return _definition_error(card, identity)
	if not SOURCE_SPECS.has(identity):
		return "Unreviewed custom aura source identity"
	var spec: Dictionary = SOURCE_SPECS[identity]
	var original: Variant = card.get("source_shop_fields")
	if not original is Dictionary or not _keys(original, ["tier", "cost", "pool_supported"]) or not original.get("pool_supported") is bool:
		return "Custom aura requires the complete original shop snapshot"
	if not integer(original.get("tier"), 1) or int(original["tier"]) != int(spec["native"][0]) or original.get("cost") != null:
		return "Custom aura original tier/cost differs from the native source"
	var normal: Dictionary = _card(catalog, str(spec["normal_id"])) if spec["is_golden"] else card
	var override: Variant = normal.get("custom_shop_override")
	if not override is Dictionary or not _keys(override, ["tier", "cost", "copies"]):
		return "Custom aura requires exactly tier, cost and copies"
	if not integer(override.get("tier"), 1) or int(override["tier"]) > 6 or not integer(override.get("cost")) or int(override["cost"]) > 99 or not integer(override.get("copies"), 1) or int(override["copies"]) > 99:
		return "Custom aura shop parameters are out of range"
	if not same(card.get("tier"), override["tier"]):
		return "Custom aura room tier differs from its explicit override"
	if spec["is_golden"]:
		if card.has("custom_shop_override") or card.get("custom_shop_derived_from") != spec["normal_id"] or not same(card.get("cost"), original["cost"]) or not same(card.get("pool_supported"), original["pool_supported"]):
			return "Custom aura golden must be the exact derived identity and preserve cost/pool fields"
	else:
		if card.has("custom_shop_derived_from") or not same(card.get("cost"), override["cost"]) or card.get("pool_supported") != true or not card.get("pool_supported") is bool:
			return "Custom aura normal room values disagree with its explicit override"
	var canonical: Dictionary = card.duplicate(true)
	for key in ["tier", "cost", "pool_supported"]:
		canonical[key] = original[key]
	for key in ["custom_shop_override", "source_shop_fields", "custom_shop_derived_from"]:
		canonical.erase(key)
	return _definition_error(canonical, identity)

static func source_closure_error(catalog: Variant, identity: String) -> String:
	if HolyVanguard.accepts_id(identity):
		var holy_issue: String=HolyVanguard.closure_error(catalog)
		if not holy_issue.is_empty(): return holy_issue
	if Cyberdrake.accepts_id(identity):
		var cyberdrake_issue: String = Cyberdrake.closure_error(catalog)
		if not cyberdrake_issue.is_empty(): return cyberdrake_issue
	if Phalanx.accepts_id(identity):
		var phalanx_issue: String = Phalanx.closure_error(catalog)
		if not phalanx_issue.is_empty(): return phalanx_issue
	var issue: String = room_source_error(catalog, identity)
	if not issue.is_empty():
		return issue
	var spec: Dictionary = SOURCE_SPECS[identity]
	var partner: String = str(spec["normal_id"] if spec["is_golden"] else spec["golden_id"])
	issue = room_source_error(catalog, partner)
	if not issue.is_empty():
		return issue
	var card: Dictionary = _card(catalog, identity)
	var other: Dictionary = _card(catalog, partner)
	if card.has("source_shop_fields") != other.has("source_shop_fields") or not same(card.get("tier"), other.get("tier")):
		return "Custom aura normal/golden pair must share one complete explicit tier override"
	return ""

static func matches(unit: Dictionary, tribe: String) -> bool:
	if unit.get("kind", "minion") != "minion" or not unit.get("tribes", []) is Array:
		return false
	for value in unit.get("tribes", []):
		if value is String and (value == tribe or value == "全部" or value.to_lower() == "all"):
			return true
	return false

static func _nested_layer(value: Variant) -> bool:
	if value is Dictionary:
		if value.has(APPLIED_KEY) or value.has(ORDINARY_ATTACK_KEY):
			return true
		for nested in value.values():
			if _nested_layer(nested):
				return true
	elif value is Array:
		for nested in value:
			if _nested_layer(nested):
				return true
	return false

static func marker_error(unit: Dictionary, owner: Variant) -> String:
	if not integer(owner):
		return "Aura owner must be a non-negative safe integer player ID"
	for key in unit:
		if key not in [APPLIED_KEY, ORDINARY_ATTACK_KEY] and _nested_layer(unit[key]):
			return "Source aura markers must not enter templates, attachments or ordinary layers"
	if unit.has(ORDINARY_ATTACK_KEY) and not signed_integer(unit[ORDINARY_ATTACK_KEY]):
		return "Non-aura attack must retain a signed int64 value"
	if not unit.has(APPLIED_KEY):
		return ""
	if not unit.has(ORDINARY_ATTACK_KEY):
		return "Materialized aura marker requires its signed non-aura attack field"
	var marker: Variant = unit[APPLIED_KEY]
	if not marker is Dictionary or marker.size() != 4 or not integer(marker.get("owner")) or int(marker["owner"]) != int(owner):
		return "Aura marker requires this exact owner, attack, health and source map"
	if not integer(marker.get("attack")) or not integer(marker.get("health")) or not marker.get("sources") is Dictionary or marker["sources"].is_empty():
		return "Aura marker must contain bounded amounts and nonempty sources"
	var attack: int = 0
	var health: int = 0
	for uid in marker["sources"]:
		var entry: Variant = marker["sources"][uid]
		if uid is String and uid.begins_with(Gnoll.PREFIX):
			var gnoll_issue: String = Gnoll.marker_entry_error(uid,entry,unit)
			if not gnoll_issue.is_empty(): return gnoll_issue
			if int(entry.attack)>MAX_STAT-attack: return "Gnoll combined aura marker overflows"
			attack+=int(entry.attack)
			continue
		if uid is String and uid.begins_with(OwnerSources.PREFIX):
			var owner_issue: String = OwnerSources.marker_entry_error(uid,entry,int(owner),unit)
			if not owner_issue.is_empty(): return owner_issue
			if int(entry.attack)>MAX_STAT-attack or int(entry.health)>MAX_STAT-health: return "Combined owner/minion aura marker overflows"
			attack+=int(entry.attack)
			health+=int(entry.health)
			continue
		if not uid is String or uid.is_empty() or uid.length() > MAX_UID_LENGTH or not entry is Dictionary or entry.size() != 3:
			return "Aura marker requires distinct real other-source UIDs and exact entries"
		if not entry.get("card_id") is String or not SOURCE_SPECS.has(entry["card_id"]) or not integer(entry.get("attack")) or not integer(entry.get("health")):
			return "Aura marker source identity or amount is invalid"
		var effect: Dictionary = SOURCE_SPECS[entry["card_id"]]["effects"][0]
		if OldMurkEye.accepts_id(entry["card_id"]):
			var coefficient: int=int(effect.attack_per_other_murloc)
			if uid!=unit.get("uid") or unit.get("card_id")!=entry.card_id or int(entry.health)!=0 or int(entry.attack)<coefficient or int(entry.attack)>13*coefficient or int(entry.attack)%coefficient!=0: return "old_murkeye_self_count_marker_invalid"
			if int(entry.attack)>MAX_STAT-attack: return "old_murkeye_combined_marker_overflow"
			attack+=int(entry.attack)
			continue
		if HolyVanguard.accepts_id(entry["card_id"]):
			if uid!=unit.get("uid") or unit.get("card_id")!=entry.card_id or int(entry.health)!=int(effect.health): return "holy_vanguard_foreign_self_marker"
		elif Cyberdrake.accepts_id(entry["card_id"]):
			# Provenance survives a real shield loss until this exact layer is revoked.
			# Stable require_synced validation still rejects stale imported layers.
			if uid == unit.get("uid") and unit.get("card_id") != entry["card_id"]:
				return "Self-inclusive shield marker must name the actual source identity"
			if unit.get("kind", "minion") != "minion" or int(entry["health"]) != 0:
				return "Shield aura marker requires a minion and zero source health"
		elif Phalanx.accepts_id(entry["card_id"]):
			# A just-removed Taunt still owns its previous materialized layer.
			# Only this exact selector can transition it away; require_synced
			# validation below still rejects a saved stale marker.
			if uid == unit.get("uid") and unit.get("card_id") != entry["card_id"]:
				return "Self-inclusive aura marker must name the actual source identity"
			if unit.get("kind", "minion") != "minion" or int(entry["health"]) != 0:
				return "Taunt aura marker requires a minion and zero source health"
		elif effect.get("scope")=="adjacent":
			if uid==unit.get("uid") or unit.get("kind","minion")!="minion" or int(entry["health"])!=0: return "Adjacent aura marker requires another real minion"
		elif uid == unit.get("uid") or not matches(unit, effect["tribe"]) or int(entry["health"]) != int(effect["health"]):
			return "Aura marker does not match the other recipient tribe or source health"
		var factor: int = int(effect["attack_per_owner_tier"])
		if factor == 0 and int(entry["attack"]) != int(effect["attack"]):
			return "Aura marker fixed attack differs from source"
		if factor > 0 and (int(entry["attack"]) < factor or int(entry["attack"]) > factor * 7 or int(entry["attack"]) % factor != 0):
			return "Aura marker owner-tier contribution is outside reviewed tiers 1 through 7"
		if int(entry["attack"]) > MAX_STAT - attack or int(entry["health"]) > MAX_STAT - health:
			return "Aura marker source sum overflows"
		attack += int(entry["attack"])
		health += int(entry["health"])
	if attack != int(marker["attack"]) or health != int(marker["health"]) or (attack == 0 and health == 0):
		return "Aura marker totals disagree with its exact source contributions"
	if not integer(unit.get("attack")) or not integer(unit.get("max_health"), 1) or int(unit["max_health"]) <= health:
		return "Aura marker exceeds its materialized ordinary stat layer"
	return ""

static func marker_shape_error(unit: Dictionary) -> String:
	# Shape only: a caller without player context cannot establish ownership.
	# player_error/build_group_plan still require and enforce the real owner.
	var owner: Variant = unit.get(APPLIED_KEY, {}).get("owner", 0) if unit.get(APPLIED_KEY, {}) is Dictionary else null
	return marker_error(unit, owner)

static func _unit_error(unit: Dictionary, owner: int, on_board: bool, combat_pending: bool = false) -> String:
	if not unit.get("uid") is String or str(unit["uid"]).is_empty() or str(unit["uid"]).length() > MAX_UID_LENGTH or not unit.get("card_id") is String or str(unit["card_id"]).is_empty():
		return "Owned cards require real nonempty UIDs and card IDs"
	if not unit.get("kind", "minion") is String or unit.get("kind", "minion") not in ["minion", "spell"]:
		return "Owned card kind must be minion or spell"
	if not unit.get("tribes", []) is Array or not unit.get("effects", []) is Array or not unit.get("keywords", []) is Array:
		return "Owned tribes, effects and keywords must be Arrays"
	for tribe in unit.get("tribes", []):
		if not tribe is String or (tribe not in TRIBES and tribe != "全部" and tribe.to_lower() != "all"):
			return "Owned tribe is outside the preserved thirteen-type vocabulary"
	for keyword in unit.get("keywords", []):
		if not keyword is String:
			return "Owned keywords must be Strings"
	for effect in unit.get("effects", []):
		if not effect is Dictionary or not effect.get("type") is String:
			return "Owned effects require a typed Dictionary"
	var issue: String = marker_error(unit, owner)
	if not issue.is_empty():
		return issue
	if not on_board and unit.has(APPLIED_KEY):
		return "Board aura cannot persist on hand or shop cards; use leave before moving"
	if unit.get("kind", "minion") != "minion":
		return "Non-minion cannot carry a board aura stat layer" if on_board or unit.has(ORDINARY_ATTACK_KEY) else ""
	for key in ["attack", "health", "max_health"]:
		if key == "health" and on_board and combat_pending:
			# Only an actual, still-present combat instance can be pending lethal.
			# Removal remains entirely the host's responsibility; stable owned/save
			# validators below never opt into this transient current-health view.
			if not signed_integer(unit.get(key)) or not integer(unit.get("_combat_id"),1) or not integer(unit.get("_side")) or int(unit._side) not in [0,1]:
				return "Transient aura board requires an actual bounded combat instance"
		elif not integer(unit.get(key), 0 if key == "attack" else 1):
			return "Stable board requires living bounded stats; dead receipts belong to the host: " + key
	if combat_pending and unit.has("_pending_destroy") and not unit["_pending_destroy"] is bool:
		return "Transient destruction marker must be a boolean"
	if unit.has(ORDINARY_ATTACK_KEY):
		var ordinary_attack: int = int(unit[ORDINARY_ATTACK_KEY])
		var aura_attack: int = int(unit.get(APPLIED_KEY, {}).get("attack", 0))
		if _sum_error(ordinary_attack, aura_attack) or int(unit["attack"]) != maxi(0, ordinary_attack + aura_attack):
			return "Panel attack disagrees with authoritative signed ordinary plus aura layers"
	if int(unit["health"]) > int(unit["max_health"]):
		return "Current health exceeds max health"
	# Preserve an independently materialized Undead Army layer, without owning it.
	if unit.has("permanent_tribe_applied"):
		var army: Variant = unit["permanent_tribe_applied"]
		if not army is Dictionary or army.size() != 2 or not integer(army.get("owner")) or int(army["owner"]) != owner or not integer(army.get("attack"), 1) or not matches(unit, "亡灵"):
			return "Malformed or foreign permanent tribe layer"
	return ""

static func _stats(unit: Dictionary) -> Dictionary:
	return {"ordinary_attack": unit.get(ORDINARY_ATTACK_KEY), "attack": unit["attack"], "health": unit["health"], "max_health": unit["max_health"], "marker": unit.get(APPLIED_KEY, null).duplicate(true) if unit.get(APPLIED_KEY) is Dictionary else null}

static func _transition(unit: Dictionary, target: Dictionary) -> Dictionary:
	if LionfishSources.enabled_bait(unit):
		var bait_issue: String=LionfishSources.stat_history_error(unit)
		if not bait_issue.is_empty(): return {"error":bait_issue}
		# Do not materialize an unearned provider layer. Existing valid providers
		# still remain in the complete player proof for every other recipient.
		target={}
	var previous: Dictionary = unit.get(APPLIED_KEY, {})
	var old_attack: int = int(previous.get("attack", 0))
	var old_health: int = int(previous.get("health", 0))
	var ordinary_attack: int = int(unit[ORDINARY_ATTACK_KEY]) if unit.has(ORDINARY_ATTACK_KEY) else int(unit["attack"]) - old_attack
	var ordinary_max: int = int(unit["max_health"]) - old_health
	var attack: int = int(target.get("attack", 0))
	var health: int = int(target.get("health", 0))
	if _sum_error(ordinary_attack, attack) or health > MAX_STAT - ordinary_max:
		return {"error": "Board aura final stats overflow; entire group unchanged"}
	var maximum: int = ordinary_max + health
	var current: int = int(unit["health"])
	if health > old_health:
		var increase: int = health - old_health
		if _sum_error(current,increase):
			return {"error": "Board aura current health overflow; entire group unchanged"}
		# Explicit destroy/poison is not ordinary damage. It cannot be healed
		# out of the queued destruction by a newly arriving HP source.
		if not bool(unit.get("_pending_destroy",false)): current += increase
	elif health < old_health:
		current = mini(current, maximum)
	return {"error": "", "stats": {"ordinary_attack": ordinary_attack if unit.has(ORDINARY_ATTACK_KEY) or not target.is_empty() else null, "attack": maxi(0, ordinary_attack + attack), "health": current, "max_health": maximum, "marker": target.duplicate(true) if not target.is_empty() else null}}

static func _has_board_aura(value: Variant) -> bool:
	if value is Dictionary:
		if value.get("type") is String and "board_aura" in value["type"]:
			return true
		for nested in value.values():
			if _has_board_aura(nested):
				return true
	elif value is Array:
		for nested in value:
			if _has_board_aura(nested):
				return true
	return false

static func _runtime_effect_error(unit: Dictionary, spec: Dictionary) -> String:
	if OldMurkEye.accepts_id(unit.get("card_id")): return OldMurkEye.runtime_error(unit)
	if HolyVanguard.accepts_id(unit.get("card_id")): return HolyVanguard.runtime_error(unit)
	if Cyberdrake.accepts_id(unit.get("card_id")):
		var cyberdrake_issue: String = Cyberdrake.runtime_source_error(unit)
		if not cyberdrake_issue.is_empty(): return cyberdrake_issue
	# Native catalog effects remain exact and complete. Runtime may additionally
	# carry host-validated Magnetic/transferred non-aura DSL, which we do not own.
	var count: int = 0
	for effect in unit.get("effects", []):
		if effect.get("type") == EFFECT_TYPE:
			count += 1
			if not same(effect, spec["effects"][0]):
				return "Runtime aura differs from the source's one exact effect"
		elif _has_board_aura(effect):
			return "Additional or nested board aura payload is not supported"
	if count != 1:
		return "Runtime source must contain exactly one complete native board aura"
	for native in spec["effects"].slice(1):
		var matches_count: int = 0
		for actual in unit.get("effects",[]):
			if same(actual,native): matches_count += 1
		if matches_count != 1: return "Runtime aura source is missing its complete native secondary effect"
	return ""

static func _player_plan(player: Dictionary, catalog: Variant, tier: Variant, combat_pending: bool = false, combat = null, side: int = -1, keyword_overrides: Dictionary = {}) -> Dictionary:
	if not integer(player.get("id")) or not integer(tier, 1) or int(tier) > 7:
		return {"error": "Aura requires a real owner ID and current owner tier 1 through 7"}
	var owner: int = int(player["id"])
	var seen: Dictionary = {}
	for zone in OWNED_ZONES:
		if not player.get(zone, []) is Array:
			return {"error": "Owned zone must be an Array: " + zone}
		for unit in player.get(zone, []):
			if not unit is Dictionary:
				return {"error": "Owned zone entry must be a Dictionary"}
			var issue: String = _unit_error(unit, owner, zone == "board",combat_pending)
			if not issue.is_empty():
				return {"error": zone + ": " + issue}
			if seen.has(unit["uid"]):
				return {"error": "Owned cards must have distinct real UIDs across zones"}
			seen[unit["uid"]] = true
	var owned: Dictionary = OwnerSources.collect(player,catalog)
	if not str(owned.error).is_empty(): return owned
	var sources: Array = owned.sources.duplicate(true)
	for unit in player.get("board", []):
		if Gnoll.claimed(unit):
			var gnoll_issue: String = Gnoll.unit_error(unit)
			if not gnoll_issue.is_empty(): return {"error":gnoll_issue}
			gnoll_issue = Gnoll.closure_error(catalog,unit.card_id)
			if not gnoll_issue.is_empty(): return {"error":gnoll_issue}
			if combat_pending:
				var dynamic: Dictionary = Gnoll.combat_source(combat,unit,side,owner)
				if not str(dynamic.error).is_empty(): return dynamic
				if not dynamic.source.is_empty(): sources.append(dynamic.source)
			elif Gnoll.has_dynamic_layer(unit): return {"error":"gnoll_death_aura_outside_combat"}
		var has_aura: bool = SOURCE_SPECS.has(unit["card_id"])
		for effect in unit.get("effects", []):
			if _has_board_aura(effect):
				has_aura = true
		if not has_aura:
			continue
		var issue: String = source_closure_error(catalog, unit["card_id"])
		if not issue.is_empty():
			return {"error": issue}
		var spec: Dictionary = SOURCE_SPECS[unit["card_id"]]
		issue = _runtime_effect_error(unit, spec)
		if not issue.is_empty():
			return {"error": issue}
		if unit.get("text") != spec["text"] or unit.get("tribes") != spec["tribes"] or unit.get("golden") != spec["is_golden"] or not unit.get("golden") is bool:
			return {"error": "Aura runtime source differs from its complete supported definition"}
		var effect: Dictionary = spec["effects"][0]
		if HolyVanguard.accepts_id(unit.card_id):
			var health_issue: String=HolyVanguard.health_context_error(player)
			if not health_issue.is_empty(): return {"error":health_issue}
			if not HolyVanguard.enabled(unit) or int(player.health)>int(effect.owner_health_max): continue
		if OldMurkEye.accepts_id(unit.card_id):
			if not OldMurkEye.enabled(unit): continue
			var counted: Dictionary=OldMurkEye.count_others(player,unit,combat_pending,combat,side)
			if not str(counted.error).is_empty(): return counted
			if int(counted.count)>0:
				sources.append({"uid":unit.uid,"card_id":unit.card_id,"tribe":"","scope":"self","attack":int(counted.count)*int(effect.attack_per_other_murloc),"health":0})
			continue
		var factor: int = int(effect["attack_per_owner_tier"])
		if factor > MAX_STAT / int(tier):
			return {"error": "Aura owner-tier multiplication overflows"}
		sources.append({"uid": unit["uid"], "card_id": unit["card_id"], "tribe": effect.get("tribe", ""), "scope":effect.get("scope","other_friendly"), "attack": int(effect["attack"]) + factor * int(tier), "health": int(effect["health"])})
	var updates: Array = []
	for unit in player.get("board", []):
		var target: Dictionary = {"owner": owner, "attack": 0, "health": 0, "sources": {}}
		for source in sources:
			var is_owner_source: bool = source.has("occurrence")
			if source.has("gnoll_entry"):
				if source.recipient_uid != unit.uid: continue
			elif is_owner_source:
				# Necklace is a moving combat-only layer, not a permanent start buff.
				if OwnerSources.SPECS[source.card_id].effects[0].scope == "combat_leftmost":
					if not combat_pending or player.board.is_empty() or unit.uid != player.board.front().uid: continue
				var recipient: Dictionary = OwnerSources.recipient_match(unit,source,catalog)
				if not str(recipient.error).is_empty(): return recipient
				if not recipient.matches: continue
			elif OldMurkEye.accepts_id(source["card_id"]):
				if source.uid!=unit.uid or source.card_id!=unit.card_id: continue
			elif HolyVanguard.accepts_id(source["card_id"]):
				if source.uid!=unit.uid or source.card_id!=unit.card_id: continue
			elif Cyberdrake.accepts_id(source["card_id"]):
				if "divine_shield" not in keyword_overrides.get(unit.uid,unit.get("keywords", [])): continue
			elif Phalanx.accepts_id(source["card_id"]):
				if "taunt" not in keyword_overrides.get(unit.uid,unit.get("keywords", [])): continue
			elif source.get("scope")=="adjacent":
				# Occupied board order is authoritative. Summon/removal/reorder
				# boundaries already invoke this same atomic aura synchronization.
				var source_index: int = -1
				var target_index: int = -1
				for index in range(player.board.size()):
					if player.board[index].uid==source.uid: source_index=index
					if player.board[index].uid==unit.uid: target_index=index
				if source_index<0 or target_index<0 or absi(source_index-target_index)!=1: continue
			elif source["uid"] == unit["uid"] or not matches(unit, source["tribe"]):
				continue
			for key in ["attack", "health"]:
				if int(source[key]) > MAX_STAT - int(target[key]):
					return {"error": "Combined board aura sources overflow; entire group unchanged"}
				target[key] += int(source[key])
			if source.has("gnoll_entry"):
				target["sources"][source["uid"]] = source.gnoll_entry.duplicate(true)
			else:
				target["sources"][source["uid"]] = OwnerSources.marker_entry(source) if is_owner_source else {"card_id": source["card_id"], "attack": source["attack"], "health": source["health"]}
		if target["sources"].is_empty():
			target = {}
		var change: Dictionary = _transition(unit, target)
		if not str(change["error"]).is_empty():
			return change
		updates.append({"uid": unit["uid"], "before": _stats(unit), "after": change["stats"]})
	return {"error": "", "kind": "board_aura_sync", "owner": owner, "tier": int(tier), "before": player.duplicate(true), "updates": updates}

static func build_sync_plan(player: Dictionary, catalog: Variant, owner_tier: Variant) -> Dictionary:
	return _player_plan(player, catalog, owner_tier)

static func build_group_plan(players: Array, catalog: Variant, owner_tiers: Array) -> Dictionary:
	return _group_plan(players,catalog,owner_tiers,false)

static func build_combat_group_plan(players: Array, catalog: Variant, owner_tiers: Array, combat = null, sides: Array = []) -> Dictionary:
	# All bodies still in the host board remain sources/recipients, including
	# lethal bodies waiting for the NEXT death batch. Never floor their health
	# or remove them early; an actual positive HP aura delta may save them.
	return _group_plan(players,catalog,owner_tiers,true,combat,sides)

static func _group_plan(players: Array, catalog: Variant, owner_tiers: Array, combat_pending: bool, combat = null, sides: Array = []) -> Dictionary:
	if players.is_empty() or players.size() != owner_tiers.size():
		return {"error": "Aura group requires nonempty players and one owner tier each"}
	var plans: Array = []
	var owners: Dictionary = {}
	var uids: Dictionary = {}
	for index in range(players.size()):
		if not players[index] is Dictionary:
			return {"error": "Aura group player must be a Dictionary"}
		var plan: Dictionary = _player_plan(players[index], catalog, owner_tiers[index],combat_pending,combat,int(sides[index]) if sides.size()==players.size() and integer(sides[index]) else -1)
		if not str(plan["error"]).is_empty():
			return plan
		if owners.has(plan["owner"]):
			return {"error": "Aura group owners must be distinct"}
		owners[plan["owner"]] = true
		for zone in OWNED_ZONES:
			for unit in players[index].get(zone, []):
				if uids.has(unit["uid"]):
					return {"error": "Aura group real UIDs must be globally distinct"}
				uids[unit["uid"]] = true
		plans.append(plan)
	return {"error": "", "kind": "board_aura_combat_group" if combat_pending else "board_aura_group", "plans": plans}

static func _write_stats(unit: Dictionary, stats: Dictionary) -> void:
	for key in ["attack", "health", "max_health"]:
		unit[key] = int(stats[key])
	if stats["ordinary_attack"] == null:
		unit.erase(ORDINARY_ATTACK_KEY)
	else:
		unit[ORDINARY_ATTACK_KEY] = int(stats["ordinary_attack"])
	if stats["marker"] == null:
		unit.erase(APPLIED_KEY)
	else:
		unit[APPLIED_KEY] = stats["marker"].duplicate(true)

static func _apply(player: Dictionary, plan: Dictionary) -> void:
	var by_uid: Dictionary = {}
	for unit in player.get("board", []):
		by_uid[unit["uid"]] = unit
	for update in plan["updates"]:
		_write_stats(by_uid[update["uid"]], update["after"])

static func commit_sync_plan(player: Dictionary, catalog: Variant, owner_tier: Variant, plan: Dictionary) -> String:
	var fresh: Dictionary = build_sync_plan(player, catalog, owner_tier)
	if not str(fresh["error"]).is_empty():
		return str(fresh["error"])
	if not same(plan, fresh):
		return "Stale or modified board aura plan; no writes committed"
	_apply(player, fresh)
	return ""

static func commit_group_plan(players: Array, catalog: Variant, owner_tiers: Array, plan: Dictionary) -> String:
	var fresh: Dictionary = build_group_plan(players, catalog, owner_tiers)
	if not str(fresh["error"]).is_empty():
		return str(fresh["error"])
	if not same(plan, fresh):
		return "Stale or modified board aura group; no writes committed"
	for index in range(players.size()):
		_apply(players[index], fresh["plans"][index])
	return ""

static func commit_combat_group_plan(players: Array, catalog: Variant, owner_tiers: Array, plan: Dictionary, combat = null, sides: Array = []) -> String:
	var fresh: Dictionary = build_combat_group_plan(players,catalog,owner_tiers,combat,sides)
	if not str(fresh.error).is_empty(): return str(fresh.error)
	if not same(plan,fresh): return "Stale or modified transient aura group; no writes committed"
	for index in range(players.size()): _apply(players[index],fresh.plans[index])
	return ""

static func player_error(player: Dictionary, catalog: Variant, owner_tier: Variant, require_synced: bool = true) -> String:
	var plan: Dictionary = build_sync_plan(player, catalog, owner_tier)
	if not str(plan["error"]).is_empty():
		return str(plan["error"])
	if require_synced:
		for update in plan["updates"]:
			if not same(update["before"], update["after"]):
				return "Saved board aura materialization is not synchronized with exact live sources"
	return ""

static func build_leave_plan(unit: Dictionary, owner: Variant) -> Dictionary:
	if not integer(owner):
		return {"error": "Leave requires a real owner ID"}
	var issue: String = _unit_error(unit, int(owner), true)
	if not issue.is_empty():
		return {"error": issue}
	var change: Dictionary = _transition(unit, {})
	if not str(change["error"]).is_empty():
		return change
	return {"error": "", "kind": "board_aura_leave", "owner": int(owner), "uid": unit["uid"], "before": unit.duplicate(true), "after": change["stats"]}

static func build_rebase_plan(unit: Dictionary, owner: Variant, ordinary: Dictionary) -> Dictionary:
	if not integer(owner):
		return {"error": "Rebase requires a real owner ID"}
	var issue: String = _unit_error(unit, int(owner), true)
	if not issue.is_empty():
		return {"error": issue}
	if ordinary.is_empty() or ordinary.has("health") != ordinary.has("max_health"):
		return {"error": "Rebase requires ordinary attack and/or both current and max health"}
	for key in ordinary:
		if key not in ["attack", "health", "max_health"] or (not signed_integer(ordinary[key]) if key == "attack" else not integer(ordinary[key], 1)):
			return {"error": "Rebase accepts only bounded explicit ordinary stats"}
	if ordinary.has("health") and int(ordinary["health"]) > int(ordinary["max_health"]):
		return {"error": "Rebase current health exceeds ordinary max health"}
	var stats: Dictionary = _stats(unit)
	var layer: Dictionary = unit.get(APPLIED_KEY, {})
	stats["ordinary_attack"] = int(unit[ORDINARY_ATTACK_KEY]) if unit.has(ORDINARY_ATTACK_KEY) else int(unit["attack"]) - int(layer.get("attack", 0))
	for key in ordinary:
		var aura: int = int(layer.get("attack" if key == "attack" else "health", 0))
		if _sum_error(int(ordinary[key]), aura):
			return {"error": "Rebase plus unchanged source aura overflows"}
		stats[key] = maxi(0, int(ordinary[key]) + aura) if key == "attack" else int(ordinary[key]) + aura
		if key == "attack":
			stats["ordinary_attack"] = int(ordinary[key])
	return {"error": "", "kind": "board_aura_rebase", "owner": int(owner), "uid": unit["uid"], "ordinary": ordinary.duplicate(true), "before": unit.duplicate(true), "after": stats}

static func build_adjust_plan(unit: Dictionary, owner: Variant, attack_delta: Variant, health_delta: Variant = 0, combat_pending: bool = false) -> Dictionary:
	if not integer(owner) or not signed_integer(attack_delta) or not signed_integer(health_delta):
		return {"error": "Adjust requires a real owner and signed int64 ordinary deltas"}
	var issue: String = _unit_error(unit, int(owner), true, combat_pending)
	if not issue.is_empty():
		return {"error": issue}
	var bait_gain: Dictionary=LionfishSources.gain_plan(unit,int(attack_delta),int(health_delta))
	if not str(bait_gain.error).is_empty(): return {"error":str(bait_gain.error)}
	if bait_gain.handled:
		attack_delta=0;health_delta=0
	var layer: Dictionary = unit.get(APPLIED_KEY, {})
	var previous: int = int(unit[ORDINARY_ATTACK_KEY]) if unit.has(ORDINARY_ATTACK_KEY) else int(unit["attack"]) - int(layer.get("attack", 0))
	if _sum_error(previous, int(attack_delta)):
		return {"error": "Ordinary attack delta overflows signed int64"}
	var ordinary: int = previous + int(attack_delta)
	var aura_attack: int = int(layer.get("attack", 0))
	if _sum_error(ordinary, aura_attack):
		return {"error": "Ordinary attack plus source aura overflows int64"}
	var after: Dictionary = _stats(unit)
	after["ordinary_attack"] = ordinary if unit.has(ORDINARY_ATTACK_KEY) or not layer.is_empty() or ordinary < 0 else null
	after["attack"] = maxi(0, ordinary + aura_attack)
	# This is the host's ordinary _buff arithmetic, not source-aura removal.
	# HP source removal alone uses _transition's clamp-to-new-max contract.
	for key in ["health", "max_health"]:
		if _sum_error(int(unit[key]), int(health_delta)) or (not (combat_pending and key=="health") and int(unit[key]) + int(health_delta) < 1):
			return {"error": "Ordinary health delta overflows or leaves the stable living domain"}
		after[key] = int(unit[key]) + int(health_delta)
	if int(after["max_health"]) <= int(layer.get("health", 0)):
		return {"error": "Ordinary max health must remain positive beneath the source layer"}
	return {"error": "", "kind": "board_aura_adjust", "combat_pending": combat_pending, "owner": int(owner), "uid": unit["uid"], "attack_delta": int(attack_delta), "health_delta": int(health_delta), "before": unit.duplicate(true), "after": after}

static func commit_unit_plan(unit: Dictionary, owner: Variant, plan: Dictionary) -> String:
	var fresh: Dictionary
	if plan.get("kind") == "board_aura_leave":
		fresh = build_leave_plan(unit, owner)
	elif plan.get("kind") == "board_aura_adjust":
		fresh = build_adjust_plan(unit, owner, plan.get("attack_delta"), plan.get("health_delta"),plan.get("combat_pending",false))
	elif plan.get("kind") == "board_aura_rebase" and plan.get("ordinary") is Dictionary:
		fresh = build_rebase_plan(unit, owner, plan["ordinary"])
	else:
		return "Unsupported aura unit operation"
	if not str(fresh["error"]).is_empty():
		return str(fresh["error"])
	if not same(plan, fresh):
		return "Stale or modified board aura unit plan; no writes committed"
	_write_stats(unit, fresh["after"])
	return ""
