extends SceneTree
const Source=preload("res://core/old_murkeye_aura_sources.gd")
const Aura=preload("res://core/board_aura_effects.gd")
const Pool=preload("res://core/pool_identity.gd")
func _init(): call_deferred("_run")

func _key(container: Variant,key: Variant)->Variant:
	return int(key) if container is Array else key

func _mutate(value: Variant,entry: Dictionary)->Variant:
	var op: String=entry.op
	var path: Array=entry.path
	if op=="canonical": return value
	if op=="swap_rows": return {Source.IDS[0]:value[Source.IDS[1]],Source.IDS[1]:value[Source.IDS[0]]}
	if op=="duplicate_normal": return {Source.IDS[0]:value[Source.IDS[0]],Source.IDS[1]:value[Source.IDS[0]].duplicate(true)}
	if op=="duplicate_golden": return {Source.IDS[0]:value[Source.IDS[1]],Source.IDS[1]:value[Source.IDS[1]].duplicate(true)}
	if op=="pool_blocker":
		value.pool_blocker=Pool.MINION_REASON
		return value
	if op=="invalid_root": return entry.value.duplicate(true) if entry.value is Array or entry.value is Dictionary else entry.value
	if op=="id_only": return {"id":value.id}
	if op=="extra_unrelated":
		value["not-a-source"]={"id":"not-a-source"}
		return value
	if op=="invalid_member":
		value[path[0]]=null
		return value
	var parent: Variant=value
	for at in range(path.size()-1): parent=parent[_key(parent,path[at])]
	var key: Variant=_key(parent,path[-1]) if not path.is_empty() else null
	var prior: Variant=parent[key] if not path.is_empty() else value
	if op=="delete":
		if parent is Array: parent.remove_at(int(key))
		else: parent.erase(key)
		return value
	var changed: Variant=null
	match op:
		"bool_to_int": changed=int(prior)
		"bool_to_float": changed=float(prior)
		"toggle_bool": changed=not prior
		"numeric_float": changed=float(prior)
		"numeric_int": changed=int(prior)
		"number_delta": changed=prior+1
		"number_string": changed=str(prior)
		"number_bool": changed=bool(prior)
		"change_string": changed=prior+"__changed__"
		"null_to_false": changed=false
		"extra_key":
			changed=prior.duplicate(true)
			changed["__extra__"]=true
		"append_item":
			changed=prior.duplicate(true)
			changed.append("__extra__")
		"reverse_list":
			changed=prior.duplicate(true)
			changed.reverse()
		"nan": changed=NAN
		"pos_inf": changed=INF
		"neg_inf": changed=-INF
		_: assert(false,"Unknown mutation: "+op)
	if not path.is_empty(): parent[key]=changed
	else: value=changed
	return value

func _canonical_admitted(card: Variant,cards: Variant)->bool:
	# Source has no standalone canonical ingress. This is the real same() primitive
	# against its pinned CANONICAL constants, followed by its real proof gate.
	if not card is Dictionary or not cards is Dictionary or not Source.accepts_id(card.get("id")): return false
	if not Source.same(card,Source.CANONICAL[card.id]): return false
	for identity in Source.IDS:
		if not Source.same(cards.get(identity),Source.CANONICAL[identity]): return false
	return Source.proof_error().is_empty()

func _base(entry: Dictionary)->Dictionary:
	var row: Dictionary=Source.RAW[entry.identity].duplicate(true) if entry.stage=="raw" else Source.CANONICAL[entry.identity].duplicate(true)
	if entry.stage=="final": row.merge(Source.EXPECTED[entry.identity].duplicate(true),true)
	return row

func _full_cards(outputs: Dictionary)->Dictionary:
	var cards: Dictionary=Source.CANONICAL.duplicate(true)
	for identity in Source.IDS: cards[identity].merge(outputs[identity],true)
	return cards

func _run():
	var folder: String=ProjectSettings.globalize_path("res://").path_join("..").simplify_path()
	var cases: Array=JSON.parse_string(FileAccess.get_file_as_string(folder.path_join("CASES.json")))
	var py: Dictionary=JSON.parse_string(FileAccess.get_file_as_string(folder.path_join("PYTHON_REPORT.json")))
	var emitted: Dictionary=JSON.parse_string(FileAccess.get_file_as_string(folder.path_join("EMITTED_OUTPUTS.json")))
	var failures: Array=[]
	var results: Array=[]
	var positive_pairs: int=0
	var stages: Dictionary={}
	for identity in Source.IDS:
		if not Source.same(emitted[identity],Source.EXPECTED[identity]): failures.append({"kind":"emit_output_mismatch","identity":identity})
	for index in range(cases.size()):
		var entry: Dictionary=cases[index]
		var identity: String=entry.identity
		var card: Variant=_base(entry)
		var cards: Variant=Source.CANONICAL.duplicate(true)
		if entry.target=="card": card=_mutate(card,entry)
		elif entry.target=="mapping": cards[identity]=_mutate(cards[identity],entry)
		else: cards=_mutate(cards,entry)
		var before: PackedByteArray=var_to_bytes([card,cards])
		var accepted: bool=false
		if entry.stage=="canonical": accepted=_canonical_admitted(card,cards)
		elif entry.stage=="raw": accepted=card is Dictionary and Source.raw_source_error(card).is_empty()
		else: accepted=card is Dictionary and Source.source_error(card).is_empty()
		if before!=var_to_bytes([card,cards]): failures.append({"kind":"input_mutated","label":entry.label})
		if py.results[index].label!=entry.label or py.results[index].new_accept!=accepted: failures.append({"kind":"python_gd_disagreement","label":entry.label,"gd":accepted,"python":py.results[index].new_accept})
		if not stages.has(entry.stage): stages[entry.stage]={"cases":0,"accepted":0,"old_disagreements":0}
		stages[entry.stage].cases+=1
		if accepted: stages[entry.stage].accepted+=1
		if py.results[index].old_accept!=accepted: stages[entry.stage].old_disagreements+=1
		if accepted and entry.stage=="canonical":
			var full: Dictionary=cards.duplicate(true)
			full[identity]=card.duplicate(true)
			for source_id in Source.IDS:
				full[source_id].merge(emitted[source_id],true)
				var issue: String=Source.source_error(full[source_id])
				if not issue.is_empty(): failures.append({"kind":"compiled_source_rejected","label":entry.label,"identity":source_id,"error":issue})
			for source_id in Source.IDS:
				var issue: String=Aura.source_closure_error(full,source_id)
				if not issue.is_empty(): failures.append({"kind":"actual_aura_closure_rejected","label":entry.label,"identity":source_id,"error":issue})
			positive_pairs+=1
		results.append({"label":entry.label,"accepted":accepted,"stage":entry.stage})
	var structural: Array=[]
	for op in ["canonical","swap_rows","duplicate_normal","duplicate_golden","remove_normal","remove_golden","tier_mismatch","bool_supported"]:
		var cards: Dictionary=_full_cards(emitted)
		if op in ["swap_rows","duplicate_normal","duplicate_golden"]: cards=_mutate(cards,{"op":op,"path":[]})
		elif op=="remove_normal": cards.erase(Source.IDS[0])
		elif op=="remove_golden": cards.erase(Source.IDS[1])
		elif op=="tier_mismatch": cards[Source.IDS[1]].tier=3
		elif op=="bool_supported": cards[Source.IDS[0]].supported=1
		var issues: Array=[]
		for identity in Source.IDS: issues.append(Aura.source_closure_error(cards,identity))
		var accepts: bool=issues[0].is_empty() and issues[1].is_empty()
		if accepts!=(op=="canonical"): failures.append({"kind":"closure_structural_result","op":op,"issues":issues})
		structural.append({"case":op,"accepted":accepts,"issues":issues})
	var effect_probes: Array=[]
	for identity in Source.IDS:
		for op in ["canonical","finite_float","wrong_amount","bool_amount","nonfinite","wrong_source"]:
			var effect: Dictionary=emitted[identity].effects[0].duplicate(true)
			if op=="finite_float": effect.attack_per_other_murloc=float(effect.attack_per_other_murloc)
			elif op=="wrong_amount": effect.attack_per_other_murloc=99
			elif op=="bool_amount": effect.attack_per_other_murloc=true
			elif op=="nonfinite": effect.attack_per_other_murloc=INF
			elif op=="wrong_source": effect.source_id="unknown"
			var native_issue: String=Source.effect_error(effect)
			var routed_issue: String=Aura.effect_error(effect)
			var accepted: bool=native_issue.is_empty() and routed_issue.is_empty()
			if native_issue.is_empty()!=(op in ["canonical","finite_float"]) or routed_issue.is_empty()!=(op in ["canonical","finite_float"]): failures.append({"kind":"effect_route_result","identity":identity,"op":op})
			effect_probes.append({"identity":identity,"op":op,"accepted":accepted,"native_issue":native_issue,"routed_issue":routed_issue})
	var proof_checks: Array=[]
	for path in Source.PROOF_SHA256:
		var absolute: String=ProjectSettings.globalize_path("res://"+path)
		var original: PackedByteArray=FileAccess.get_file_as_bytes(absolute)
		var writer=FileAccess.open(absolute,FileAccess.WRITE)
		writer.store_buffer(original)
		writer.store_8(10)
		writer.close()
		var issue: String=Source.proof_error()
		var raw_rejected: bool=not Source.raw_source_error(Source.RAW[Source.IDS[0]]).is_empty()
		var full: Dictionary=_full_cards(emitted)
		var final_rejected: bool=not Source.source_error(full[Source.IDS[0]]).is_empty()
		var closure_rejected: bool=not Aura.source_closure_error(full,Source.IDS[0]).is_empty()
		writer=FileAccess.open(absolute,FileAccess.WRITE)
		writer.store_buffer(original)
		writer.close()
		var restored: bool=FileAccess.get_sha256(absolute)==Source.PROOF_SHA256[path] and Source.proof_error().is_empty()
		if issue.is_empty() or not raw_rejected or not final_rejected or not closure_rejected or not restored: failures.append({"kind":"proof_gate_failure","path":path})
		proof_checks.append({"path":path,"tamper_rejected":not issue.is_empty(),"raw_rejected":raw_rejected,"final_rejected":final_rejected,"closure_rejected":closure_rejected,"restored":restored})
	var report: Dictionary={"case_count":cases.size(),"stages":stages,"positive_compiled_pair_source_and_closure_checks":positive_pairs,"structural_closure_probes":structural,"proof_tamper_probes":proof_checks,"effect_route_probes":effect_probes,"failures":failures,"results":results,"godot_version":Engine.get_version_info(),"full_catalog_game_compiler_save_run":false,"canonical_comparison_is_composed_primitive_not_independent_GD_entry":true}
	var args: PackedStringArray=OS.get_cmdline_user_args()
	var output: String=args[0] if args.size()>0 else folder.path_join("GODOT_REPORT.json")
	var writer=FileAccess.open(output,FileAccess.WRITE)
	writer.store_string(JSON.stringify(report,"\t")+"\n")
	writer.close()
	print("Cases ",cases.size(),"; pairs ",positive_pairs,"; failures ",failures.size())
	quit(0 if failures.is_empty() else 1)
