from pathlib import Path
from copy import deepcopy
import ast,hashlib,json,math,resource,sys,types
resource.setrlimit(resource.RLIMIT_AS,(128*1024**2,128*1024**2));sys.dont_write_bytecode=True
H=Path(__file__).resolve().parent;R=H/'original_inputs'
relative='research/old_murkeye_aura_native_recovery/candidates/tools/build_effect_catalog.py'
pins=json.loads((H/'INPUT_PINS.json').read_text())
for rel in [relative,'data/catalog_value_overrides.json']:
 b=(R/rel).read_bytes();assert hashlib.sha256(b).hexdigest()==pins[rel]['sha256'] and len(b)==pins[rel]['bytes']
assert pins[relative]['sha256']=='e30078a81ad68c5201c7097aeecd80072d479a02854b276aa27a4f8c8de8c5cc'
s=(R/relative).read_text();tree=ast.parse(s)
emit=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='emit')
override=next(n for n in tree.body if isinstance(n,ast.If) and 'catalog_value_overrides.json' in ast.unparse(n.test))
hook=next(n for n in tree.body if isinstance(n,ast.For) and isinstance(n.iter,ast.Name) and n.iter.id=='OLD_MURKEYE_AURA_IDS')
i=tree.body.index(hook);reorder=tree.body[i+1:i+3]
assert all('OLD_MURKEYE_AURA_IDS' in ast.unparse(x) and 'ordered_ids' in ast.unparse(x) for x in reorder)
chosen=[emit,override,hook]+reorder
(H/'DRIVER_SELECTED_EXACT.py').write_text('\n\n'.join(ast.get_source_segment(s,n) for n in chosen)+'\n')
def code(nodes):return compile(ast.Module(body=nodes,type_ignores=[]),str(R/relative),'exec')
ns={};exec(compile((H/'candidate/tools/old_murkeye_aura_patterns.py').read_text(),'candidate','exec'),ns)
old={};exec(compile((H/'original_inputs/research/old_murkeye_aura_native_recovery/candidates/tools/old_murkeye_aura_patterns.py').read_text(),'historical candidate','exec'),old)
G=json.loads((H/'GD_CONSTANTS.json').read_text());IDS=ns['SOURCE_IDS']
def frozen(v):return json.dumps(v,sort_keys=True,ensure_ascii=False)
def floats(v):
 if type(v) is int:return float(v)
 if type(v) is dict:return {k:floats(x) for k,x in v.items()}
 if type(v) is list:return [floats(x) for x in v]
 return v
rows=[];outputs={}
for name in ['raw_with_actual_overrides','canonical','all_numbers_float','bool_to_int','infinite_attack','swapped_rows','missing_companion']:
 cards=deepcopy(G['RAW' if name=='raw_with_actual_overrides' else 'CANONICAL'])
 if name=='all_numbers_float':cards=floats(cards)
 elif name=='bool_to_int':cards[IDS[0]]['is_golden']=0
 elif name=='infinite_attack':cards[IDS[0]]['attack']=math.inf
 elif name=='swapped_rows':cards={IDS[0]:cards[IDS[1]],IDS[1]:cards[IDS[0]]}
 elif name=='missing_companion':del cards[IDS[1]]
 results={}
 for label,module in [('old',old),('new',ns)]:
  namespace={'R':H/'original_inputs','cards':deepcopy(cards),'json':json,'hashlib':hashlib,'out':{i:{'stale':True} for i in IDS},'ordered_ids':['unrelated']+list(reversed(IDS)),'OLD_MURKEYE_AURA_IDS':IDS,'compile_old_murkeye_aura':module['compile_card']}
  exec(code([emit]),namespace)
  if name=='raw_with_actual_overrides':exec(code([override]),namespace);assert frozen(namespace['cards'])==frozen(G['CANONICAL'])
  before=frozen(namespace['cards']);exec(code([hook]+reorder),namespace);assert before==frozen(namespace['cards'])
  emitted=namespace['out'];assert set(emitted).issubset(IDS)
  for identity,value in emitted.items():assert frozen(value)==frozen(G['EXPECTED'][identity])
  results[label]={'emitted_ids':sorted(emitted),'outputs_exact':True,'ordered_ids':namespace['ordered_ids']}
  if label=='new' and name=='raw_with_actual_overrides':outputs=deepcopy(emitted)
 rows.append({'fixture':name,'results':results})
assert rows[0]['results']['new']['emitted_ids']==sorted(IDS)
assert rows[2]['results']['old']['emitted_ids']==[] and rows[2]['results']['new']['emitted_ids']==sorted(IDS)
assert all(row['results']['new']['emitted_ids']==[] for row in rows[3:])
(H/'INPUT_PINS.json').write_text(json.dumps(pins,indent=2)+'\n')
(H/'EMITTED_OUTPUTS.json').write_text(json.dumps(outputs,ensure_ascii=False,indent=2)+'\n')
report={'historical_driver_sha256':pins[relative]['sha256'],'extracted_node_lines':[{'type':type(n).__name__,'first':n.lineno,'last':n.end_lineno} for n in chosen],'full_driver_executed':False,'only_reviewed_exact_ast_fragments_executed':True,'raw_to_canonical_exact':True,'fixtures':rows,'max_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
(H/'DRIVER_FRAGMENT_REPORT.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps(report,ensure_ascii=False,indent=2))
