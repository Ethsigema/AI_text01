from pathlib import Path
import hashlib,json,resource,tarfile
resource.setrlimit(resource.RLIMIT_AS,(128*1024**2,128*1024**2))
H=Path(__file__).resolve().parent
# Only technical deliverables. Explicitly exclude temporary mutation roots, engine
# HOME/cache/data/config directories and any unrecognized directory.
roots=['candidate','original_inputs','gd_minimal/core','gd_minimal/research','callchain_audit','independent_review','harness_initial_failure']
files=set()
for root in roots:
 for path in (H/root).rglob('*'):
  if path.is_file():
   assert not path.is_symlink();files.add(path)
for path in H.iterdir():
 if path.is_file() and path.suffix in ['.json','.py','.md','.log'] and path.name not in ['PACKAGE_FILES_SHA256.json','PACKAGE_VERIFIED.json','REPLAY.stdout.log']:
  files.add(path)
for rel in ['gd_minimal/gate.gd','gd_minimal/project.godot']:files.add(H/rel)
manifest={}
for path in sorted(files):
 rel=str(path.relative_to(H));assert not any(x in path.parts for x in ['.godot','__pycache__','isolated_home','isolated_cache','isolated_data','isolated_config','proof_variants'])
 data=path.read_bytes();manifest[rel]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
mp=H/'PACKAGE_FILES_SHA256.json';mp.write_text(json.dumps(manifest,indent=2)+'\n');files.add(mp)
archive=H.with_suffix('.tar.xz');assert not archive.exists()
with tarfile.open(archive,'w:xz',preset=3) as tf:
 for path in sorted(files):tf.add(path,arcname=H.name+'/'+str(path.relative_to(H)),recursive=False)
checked=0
with tarfile.open(archive,'r:xz') as tf:
 members=tf.getmembers();assert len(members)==len(files)
 seen=set()
 for m in members:
  assert m.isfile() and m.name not in seen;seen.add(m.name)
  rel=str(Path(m.name).relative_to(H.name));stream=tf.extractfile(m);h=hashlib.sha256();n=0
  for block in iter(lambda:stream.read(1024*1024),b''):h.update(block);n+=len(block)
  if rel=='PACKAGE_FILES_SHA256.json':assert h.hexdigest()==hashlib.sha256(mp.read_bytes()).hexdigest()
  else:assert n==manifest[rel]['bytes'] and h.hexdigest()==manifest[rel]['sha256']
  checked+=1
h=hashlib.sha256()
with archive.open('rb') as f:
 for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
report={'archive':str(archive),'archive_bytes':archive.stat().st_size,'archive_sha256':h.hexdigest(),'verified_members':checked,'all_members_stream_read_and_hash_verified':True,'whitelist_only':True,'includes_source_or_backup_modifications':False,'max_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
(H/'PACKAGE_VERIFIED.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
