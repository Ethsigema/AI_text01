"""Synthetic failure counts and unknown-success refusal only, no Game or package."""
import copy,json
from render_verified_slice import render_slice,runner
labels=[row[0] for row in runner.TESTS];commit='a'*40
s={'source_commit':commit,'runtime_mode':runner.RUNTIME_MODE,'two_runtime_copies':False,'status':'FAILED_OR_INCOMPLETE_ATTEMPT','error':'synthetic failure','validated_tests':[]}
a={'source_commit':commit,'runtime_mode':runner.RUNTIME_MODE,'two_runtime_copies':False,'runner_suite_accepted':False,'status':'FAIL_POST_ATTEMPT_AUDIT','tests':{key:{'classification':'omitted','process_started':False} for key in labels}}
a['tests'][labels[0]]={'classification':'process_failed','process_started':True}
assert '11 份纯合同全部未运行' in render_slice(s,a,None,None,commit);checks=['first_full_failure_eleven_pures_omitted']
p=copy.deepcopy(a);p['tests'][labels[0]]={'classification':'executed_validated','process_started':True,'revalidated_checks':123};p['tests'][labels[1]]={'classification':'process_failed','process_started':True}
text=render_slice(s,p,None,None,commit);assert '明确未启动 10 项' in text and '11 份纯合同全部未运行' not in text;checks.append('later_failure_ten_omitted')
u=copy.deepcopy(a);u['tests'][labels[0]]={'classification':'launch_or_execution_without_completion_receipt','process_started':None}
assert '结果待确认 1 项' in render_slice(s,u,None,None,commit);checks.append('unknown_outcome_is_not_omitted_or_pass')
success={**s,'status':'TESTS_VALIDATED_SOURCE_INTEGRITY_PASS','error':None,'validated_tests':labels}
accepted={**a,'status':'PASS_POST_ATTEMPT_SOURCE_AND_EVIDENCE_AUDIT','runner_suite_accepted':True,'tests':{key:{'classification':'executed_validated'} for key in labels}}
f={'source_commit':commit,'status':runner.FINAL_STATUS,'tests':{key:{} for key in labels},'full_game_processes':1,'full_game_acceptance':False,'default_pool_promoted':False,'old_full_matrices_repeated':False}
try:render_slice(success,accepted,f,{},commit)
except ValueError:checks.append('UNKNOWN_success_schema_refuses_acceptance')
else:raise AssertionError('unknown renderer accepted')
print(json.dumps({'status':'PASS_SYNTHETIC_PENDING_RENDERER_ONLY','passed':len(checks),'checks':checks,'game_started':False,'package_created':False}))
