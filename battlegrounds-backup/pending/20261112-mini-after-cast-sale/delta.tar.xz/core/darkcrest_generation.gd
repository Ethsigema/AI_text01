extends RefCounted
## Reconstructed implementation, not a byte-for-byte recovery of the lost candidate.
## Observes the native draw/factory/add_hand; never writes live RNG, stock or units.
const Sources=preload("res://core/darkcrest_sources.gd")
const IDS: Array=["BG23_008","BG31_920","BG31_925","BG32_111","BG32_820","BG32_835"]
const TIER6_IDS: Array=["BG31_035","BG32_837","BG36_622","BG36_640"]
# Pure content domains, not provenance or authorization for a draw.
static func domain_ids(tier: Variant) -> Array:
	if not tier is int: return []
	if tier==5: return IDS.duplicate()
	if tier==6: return TIER6_IDS.duplicate()
	return []
static func tier_receipts_match(record: Dictionary,grant: Dictionary,parent_record: Dictionary) -> bool:
	var tier: Variant=record.get("tier")
	return not domain_ids(tier).is_empty() and grant.get("tier") is int and parent_record.get("tier") is int and grant.tier==tier and parent_record.tier==tier
var _active: Dictionary={}
var _origins: Dictionary={}
var _host: WeakRef
var _game: WeakRef

static func _integer(v: Variant,lo: int,hi: int) -> bool:
	return v is int and v>=lo and v<=hi
func _actual(host,game,p: Dictionary) -> String:
	if not host is RefCounted or not game is RefCounted: return "darkcrest_generation_actual_objects_required"
	var hs: Variant=host.get_script()
	var gs: Variant=game.get_script()
	if not hs is Script or hs.resource_path!="res://core/darkcrest_host.gd" or not gs is Script or gs.resource_path!="res://core/game.gd": return "darkcrest_generation_actual_scripts_required"
	if host._projection_only: return "darkcrest_projection_issuance_held"
	if not is_same(game._darkcrest_host,host) or not is_same(host._generation,self): return "darkcrest_generation_actual_host_required"
	if _host!=null and (not is_same(_host.get_ref(),host) or not is_same(_game.get_ref(),game)): return "darkcrest_generation_bound_engine_required"
	if not game.state.get("players") is Array or not _integer(p.get("id"),0,game.state.players.size()-1) or not is_same(game.state.players[int(p.id)],p): return "darkcrest_generation_actual_owner_required"
	return ""
func _cast_error(host,game,p: Dictionary) -> String:
	var issue: String=_actual(host,game,p)
	if not issue.is_empty(): return issue
	if game.state.get("phase")!="recruit": return "darkcrest_generation_recruit_required"
	var c: Dictionary=host._cast
	var u: Dictionary=c.get("unit",{})
	var r: Dictionary=c.get("record",{})
	if c.is_empty() or not is_same(c.get("owner"),p) or c.get("consumed")!=true or not is_same(host._spells.get(u.get("uid")),r) or not is_same(r.get("unit"),u): return "darkcrest_generation_consumed_issued_token_required"
	if u.get("card_id")!="BG31_920t" or r.get("id")!="BG31_920t" or domain_ids(r.get("tier")).is_empty() or r.get("owner")!=p.id or r.get("round")!=game.state.get("round") or r.get("used")!=true: return "darkcrest_generation_original_tier5_or_tier6_token_required"
	if not Sources.unit_error(u).is_empty() or u.get("is_spellcraft")!=true or u.get("expires_at_end_turn")!=true: return "darkcrest_generation_changed_token"
	var source_uid: Variant=r.get("source_uid")
	var grant: Dictionary=host._grants.get(source_uid,{})
	if not source_uid is String or source_uid.is_empty() or grant.get("owner")!=p.id or grant.get("round")!=r.round or grant.get("tier")!=r.get("tier") or grant.get("delivered")!=true or grant.get("blocked",false): return "darkcrest_generation_original_grant_required"
	var source: Dictionary=host._parents.get(source_uid,{})
	if grant.get("id")!="BG31_920" or source.get("id")!="BG31_920" or not is_same(grant.get("unit"),source.get("unit")) or source.is_empty(): return "darkcrest_generation_original_source_required"
	if not tier_receipts_match(r,grant,source): return "darkcrest_generation_cross_tier_receipts"
	issue=host.parent_error(source.unit)
	if not issue.is_empty(): return issue
	if not _active.is_empty():
		if r.tier!=_active.cast_tier or not is_same(source,_active.source_record): return "darkcrest_generation_cast_tier_changed"
		if not is_same(grant,_active.grant): return "darkcrest_generation_grant_replaced"
		if not is_same(c,_active.cast) or not is_same(r,_active.record) or not is_same(u,_active.token) or not is_same(p,_active.owner) or game.state.round!=_active.round or game.state.command_sequence!=_active.sequence: return "darkcrest_generation_cast_changed"
	return ""
static func _same_objects(actual: Array,before: Array) -> bool:
	if actual.size()!=before.size(): return false
	for i in range(before.size()):
		if not is_same(actual[i],before[i]): return false
	return true
static func _occurrences(game,u: Dictionary) -> int:
	var n: int=0
	for p in game.state.players+game.state.get("ghosts",[]):
		for zone in ["board","hand","shop"]:
			for v in p.get(zone,[]):
				if is_same(v,u) or (v is Dictionary and v.get("uid")==u.get("uid")): n+=1
	return n
func _body_error(host,game,u: Dictionary,cast_tier: Variant=5) -> String:
	# Pure observation only; fake catalog fixtures cannot establish provenance.
	var id: Variant=u.get("card_id")
	if not id is String or id not in domain_ids(cast_tier): return "darkcrest_generation_unknown_body"
	if u.get("pool_id")!=id or u.get("pool_kind")!="minion" or not u.get("pool_count") is int or u.pool_count!=1: return "darkcrest_generation_invalid_pool_stamp"
	return host.hand_state_error(u,game.catalog.get_card(id),game.Rider.UNIT_FIELDS)
func _pool_error(game,id: String) -> String:
	# Whole-pool equality with native integer types, not numeric coercion.
	var before: Dictionary=_active.get("pool",{})
	if not before.has(id) or not _integer(before[id],1,2147483647) or game.pool.size()!=before.size(): return "darkcrest_generation_unique_pool_debit_required"
	for key in before:
		if not game.pool.has(key) or not _integer(before[key],0,2147483647) or not _integer(game.pool[key],0,2147483647): return "darkcrest_generation_invalid_pool_stock_type"
		var expected: int=int(before[key])-(1 if key==id else 0)
		if game.pool[key]!=expected: return "darkcrest_generation_unique_pool_debit_required"
	return ""
static func _draw_events(game,start: int) -> Array:
	var found: Array=[]
	if game.events.size()<start: return [{"error":"event_history_truncated"}]
	for event in game.events.slice(start):
		if event is Dictionary and event.get("type")=="rng" and event.get("reason")=="random_generated_minion": found.append(event.duplicate(true))
	return found
func _parents_error(host,u: Dictionary) -> String:
	var expected_size: int=_active.parents_before.size()+(1 if u.get("card_id")=="BG31_920" else 0)
	if host._parents.size()!=expected_size: return "darkcrest_generation_unique_parent_registration_required"
	for uid in _active.parents_before:
		if not is_same(host._parents.get(uid),_active.parents_before[uid]) or not Sources.same(host._parents.get(uid),_active.parent_values[uid]): return "darkcrest_generation_existing_parent_changed"
	if u.get("card_id")=="BG31_920" and (_active.parents_before.has(u.get("uid")) or host._grants.has(u.get("uid"))): return "darkcrest_generation_new_parent_has_prior_history"
	return ""
func begin(host,game,p: Dictionary) -> String:
	if not _active.is_empty(): return "darkcrest_generation_reentrant_draw"
	var issue: String=_cast_error(host,game,p)
	if not issue.is_empty(): return issue
	if host._cast.get("generation_started",false): return "darkcrest_generation_already_started"
	issue=host.owner_error(game,p)
	if not issue.is_empty(): return issue
	if _occurrences(game,host._cast.unit)!=0: return "darkcrest_generation_token_not_consumed_from_hand"
	if p.hand.size()>=10 or not _integer(game.next_uid,1,2147483646): return "darkcrest_generation_capacity_or_uid_held"
	var cast_tier: int=host._cast.record.tier
	var allowed: Array=domain_ids(cast_tier)
	var choices: Array=[]
	var total: int=0
	var ids: Array=game.pool.keys();ids.sort()
	for id in ids:
		if id not in game._enabled("minions"): continue
		var card: Dictionary=game.catalog.get_card(str(id))
		if card.is_empty(): return "darkcrest_generation_unknown_enabled_card"
		if card.get("kind")!="minion" or card.get("tier")!=cast_tier or card.get("is_golden",false): continue
		var tribes: Array=card.get("tribes",[])
		if "纳迦" not in tribes and "全部" not in tribes and "all" not in tribes: continue
		if not _integer(game.pool[id],0,2147483647): return "darkcrest_generation_invalid_stock"
		if game.pool[id]==0: continue
		if id not in allowed: return "darkcrest_generation_unreviewed_complete_domain"
		issue=host.candidate_source_error(str(id),card)
		if not issue.is_empty(): return issue
		if card.get("supported")!=true: return "darkcrest_generation_unsupported_domain_member"
		if host.count(p,str(id))>=2: return "darkcrest_generation_random_output_triple_held"
		choices.append({"id":id,"stock":int(game.pool[id])})
		total+=int(game.pool[id])
		if total>2147483647: return "darkcrest_generation_weight_overflow"
	if total<=0: return "darkcrest_generation_empty_complete_domain"
	# Independently enumerate the actual native domain, never pass a reduced list.
	var domain: Dictionary=game.BulkResourceHost.domain(game)
	var native_choices: Array=game.BulkResourceHost.candidates(domain,domain.stock,{"kind":"minion","tier":cast_tier,"tribe":"纳迦"})
	if not Sources.same(choices,native_choices): return "darkcrest_generation_native_domain_mismatch"
	_host=weakref(host);_game=weakref(game)
	_active={"cast_tier":cast_tier,"source_record":host._parents[host._cast.record.source_uid],"grant":host._grants[host._cast.record.source_uid],"cast":host._cast,"record":host._cast.record,"token":host._cast.unit,"owner":p,"round":game.state.round,"sequence":game.state.command_sequence,"choices":choices,"total":total,"pool":game.pool.duplicate(true),"uid":game.next_uid,"seed":game.rng.seed,"rng_before":game.rng.state,"event_count":game.events.size(),"hand":p.hand.duplicate(),"hand_values":p.hand.duplicate(true),"board":p.board.duplicate(),"board_values":p.board.duplicate(true),"parents_before":host._parents.duplicate(),"parent_values":host._parents.duplicate(true),"stage":"prepared"}
	host._cast.generation_started=true
	return ""
func drawn(host,game,p: Dictionary,u: Dictionary) -> String:
	var issue: String=_cast_error(host,game,p)
	if not issue.is_empty(): return issue
	if _active.is_empty() or _active.stage!="prepared": return "darkcrest_generation_original_draw_required"
	if u.is_empty() or u.get("card_id") not in domain_ids(_active.get("cast_tier")) or u.get("uid")!="u"+str(_active.uid) or game.next_uid!=_active.uid+1 or _occurrences(game,u)!=0: return "darkcrest_generation_original_factory_uid_required"
	if not _same_objects(p.hand,_active.hand) or not _same_objects(p.board,_active.board) or not Sources.same(p.hand,_active.hand_values) or not Sources.same(p.board,_active.board_values): return "darkcrest_generation_draw_changed_owner_zones"
	var replay: RandomNumberGenerator=RandomNumberGenerator.new()
	replay.seed=_active.seed;replay.state=_active.rng_before
	var ticket: int=0
	var expected_events: Array=[]
	if _active.total>1:
		ticket=replay.randi_range(0,int(_active.total)-1)
		expected_events.append({"type":"rng","reason":"random_generated_minion","range":_active.total,"value":ticket})
	if game.rng.seed!=_active.seed or game.rng.state!=replay.state or not Sources.same(_draw_events(game,int(_active.event_count)),expected_events): return "darkcrest_generation_single_native_rng_required"
	var selected: String=""
	for choice in _active.choices:
		ticket-=int(choice.stock)
		if ticket<0: selected=str(choice.id);break
	if selected!=u.get("card_id") or u.get("pool_id")!=selected or u.get("pool_kind")!="minion" or u.get("pool_count")!=1: return "darkcrest_generation_selected_factory_mismatch"
	var expected_pool: Dictionary=_active.pool.duplicate(true);expected_pool[selected]-=1
	issue=_pool_error(game,selected)
	if not issue.is_empty(): return issue
	issue=_body_error(host,game,u,_active.get("cast_tier"))
	if not issue.is_empty(): return issue
	issue=_parents_error(host,u)
	if not issue.is_empty(): return issue
	if selected=="BG31_920":
		var r: Dictionary=host._parents.get(u.uid,{})
		if not is_same(r.get("unit"),u) or r.get("id")!=selected or r.get("shop_origin")!=false or r.get("tier")!=1 or r.get("last_eot")!=-1 or _origins.has(u.uid): return "darkcrest_generation_original_fresh_parent_required"
		_active.parent_record=r
		issue=Sources.unit_error(u)
	else:
		issue=host.hand_error(game,u,p)
	if not issue.is_empty(): return issue
	_active.unit=u;_active.snapshot=u.duplicate(true);_active.pool_after=expected_pool;_active.rng_after=game.rng.state;_active.stage="drawn"
	return ""
func received(host,game,p: Dictionary,u: Dictionary) -> String:
	var issue: String=_cast_error(host,game,p)
	if not issue.is_empty(): return issue
	if _active.is_empty() or _active.stage!="drawn" or not is_same(_active.get("unit"),u): return "darkcrest_generation_original_received_unit_required"
	issue=_body_error(host,game,u,_active.get("cast_tier"))
	if issue.is_empty(): issue=_pool_error(game,str(u.get("card_id","")))
	if not issue.is_empty(): return issue
	var expected: Array=_active.hand.duplicate();expected.append(u)
	if not _same_objects(p.hand,expected) or not _same_objects(p.board,_active.board) or _occurrences(game,u)!=1 or not Sources.same(u,_active.snapshot): return "darkcrest_generation_native_unique_hand_append_required"
	if not Sources.same(p.hand.slice(0,_active.hand.size()),_active.hand_values) or not Sources.same(p.board,_active.board_values): return "darkcrest_generation_existing_zone_values_changed"
	issue=_parents_error(host,u)
	if not issue.is_empty(): return issue
	if game.next_uid!=_active.uid+1 or game.rng.seed!=_active.seed or game.rng.state!=_active.rng_after or not Sources.same(game.pool,_active.pool_after): return "darkcrest_generation_hand_side_effect_held"
	if u.card_id=="BG31_920":
		var r: Dictionary=host._parents.get(u.uid,{})
		if not is_same(r,_active.get("parent_record")) or not is_same(r.get("unit"),u) or r.get("id")!=u.card_id or r.get("shop_origin")!=false or r.get("tier")!=1 or r.get("last_eot")!=-1 or _origins.has(u.uid): return "darkcrest_generation_fresh_parent_changed"
		_origins[u.uid]={"unit":u,"parent_record":r,"owner":p,"owner_id":p.id,"id":u.card_id,"token":_active.token,"token_record":_active.record,"source_uid":_active.record.source_uid,"token_uid":_active.token.uid,"birth_round":_active.round,"birth_tier":1,"cast_tier":5}
	_active.stage="committed"
	return ""
func completion_error(host,game,p: Dictionary) -> String:
	var issue: String=_cast_error(host,game,p)
	if not issue.is_empty(): return issue
	if _active.is_empty() or _active.stage!="committed": return "darkcrest_generation_incomplete_native_delivery"
	return ""
func claimed(u: Dictionary) -> bool:
	return _origins.has(u.get("uid",""))
func parent_error(host,u: Dictionary) -> String:
	var r: Dictionary=_origins.get(u.get("uid",""),{})
	if r.is_empty() or not is_same(r.get("unit"),u) or u.get("card_id")!="BG31_920": return "darkcrest_generation_unowned_or_copied_parent"
	if _host==null or _game==null or not is_instance_valid(_host.get_ref()) or not is_instance_valid(_game.get_ref()): return "darkcrest_generation_expired_host"
	var issue: String=_actual(host,_game.get_ref(),r.owner)
	if not issue.is_empty(): return issue
	var parent_record: Dictionary=host._parents.get(u.uid,{})
	if not is_same(parent_record,r.parent_record) or not is_same(parent_record.get("unit"),u) or parent_record.get("shop_origin")!=false or parent_record.get("id")!=r.id: return "darkcrest_generation_changed_parent_record"
	return ""
func owner_error(host,u: Dictionary,p: Dictionary) -> String:
	if not claimed(u): return ""
	var issue: String=parent_error(host,u)
	if not issue.is_empty(): return issue
	var r: Dictionary=_origins[u.uid]
	if not is_same(r.owner,p) or r.owner_id!=p.get("id"): return "darkcrest_generation_wrong_owner"
	return _actual(host,_game.get_ref(),p)
func cancel() -> void:
	# Successful birth receipts survive source sale, phase changes and future casts.
	_active={}
