extends RefCounted
## Pinned Cursed Crystal revision. Partial holds and previous proof boundaries remain.
const REVISION: String="partial-37.0.2-timewarp_mythrax_golden-rebuilt-20261107"
const ID: String="BG34_Giant_684_G"
const OVERLAY: String="data/patch_3702_timewarp_mythrax_golden_overlay.json"
const FILE_SHA256: Dictionary={"data/patch_3702_timewarp_mythrax_golden_overlay.json":"ea621fbe6888a5f20186e57b6a4be17a75ad39bb18ea2d9151ddf02c3ac9e3cd","research/patch_3702_timewarp_mythrax_golden/BG34_Giant_684_G.native.xml":"6723bd35f6994e013a6561ac16092683b9523e17c1e72a85037716cc91ac5193","research/patch_3702_timewarp_mythrax_golden/evidence.json":"ee59ae9351c294ac59b57480280f588666d545e4433e947f54db7b30968c94ca","core/timewarp_mythrax_host.gd":"5720ca7826b450e12da601c5a2b7c4f38827bbccdda47888128a88f31cb42615","core/game.gd":"8ed244d2cc9b96aff98bbd5ec785ad641d138f90acf8d9b89fb87d7f44b2b44b","core/combat.gd":"d341b6c2afd08018822ffbdb1399382c95c072916269425fdf8b50b8484683ca","core/start_combat_effects.gd":"67aa7309b928a29e1e9a775e7615a5056b26266bdda55389e31ea76eb494f03d"}
const RUNTIME_PATHS: Array=["core/patch_3702_timewarp_mythrax_golden_sources.gd","core/catalog.gd","data/patch_3702_timewarp_mythrax_golden_overlay.json","research/patch_3702_timewarp_mythrax_golden/BG34_Giant_684_G.native.xml","research/patch_3702_timewarp_mythrax_golden/evidence.json","core/timewarp_mythrax_host.gd","core/game.gd","core/combat.gd","core/start_combat_effects.gd"]
const EXPECTED_RAW: Dictionary={}
const EXPECTED_COMPILED: Dictionary={}
const EXPECTED_BASELINE: Dictionary={}
const EFFECTIVE_FIELDS: Dictionary={"attack":16,"health":18,"text":"战斗开始时：获得不同类型的3个友方随从的双倍属性值（时空扭曲米斯拉克斯除外）。","supported":true,"effects":[{"type":"start_combat_stats","mode":"timewarp_mythrax_three_types","source_id":"BG34_Giant_684_G","scope":"self","multiplier":2}],"keywords":[],"pool_supported":false,"default_pool":false,"coverage_text_sha256":"da7091e8fdcb19bc94769e3da11f2471c653f43771855453b51842c3abba6089","implementation_status":"partial_start_combat_factory_fixture","conditional_support":{"rule":"timewarp_mythrax_three_types_rebuilt_20261107","reason":"Combat-only gain of up to three distinct friendly type representatives excluding both Timewarped Mythrax IDs. Uses existing local randomized maximum matching; official RNG equivalence, natural acquisition and broad combinations unvalidated."},"pool_blocker":"没有已确认的普通商店随从资格；衍生物、伙伴或时空扭曲内容需由对应机制生成，或显式配置自定义入店参数。","id":"BG34_Giant_684_G","card_code":"BG34_Giant_684_G","dbf_id":"129129","name":"时空扭曲米斯拉克斯","kind":"minion","category":"随从","categories":["随从","时空扭曲"],"mechanisms":["时空扭曲"],"tier":5,"cost":null,"tribes":["全部"],"is_golden":true,"normal_id":"BG34_Giant_684","golden_id":null,"image":"","solo_eligible":true,"source_url":"https://github.com/HearthSim/hsdata","native_source_build":"37.0.2.256589"}
const EXPECTED_CURRENT: Dictionary={"attack":16,"health":18,"text":"战斗开始时：获得不同类型的3个友方随从的双倍属性值（时空扭曲米斯拉克斯除外）。","supported":true,"effects":[{"type":"start_combat_stats","mode":"timewarp_mythrax_three_types","source_id":"BG34_Giant_684_G","scope":"self","multiplier":2}],"keywords":[],"pool_supported":false,"default_pool":false,"coverage_text_sha256":"da7091e8fdcb19bc94769e3da11f2471c653f43771855453b51842c3abba6089","implementation_status":"partial_start_combat_factory_fixture","conditional_support":{"rule":"timewarp_mythrax_three_types_rebuilt_20261107","reason":"Combat-only gain of up to three distinct friendly type representatives excluding both Timewarped Mythrax IDs. Uses existing local randomized maximum matching; official RNG equivalence, natural acquisition and broad combinations unvalidated."},"pool_blocker":"没有已确认的普通商店随从资格；衍生物、伙伴或时空扭曲内容需由对应机制生成，或显式配置自定义入店参数。","id":"BG34_Giant_684_G","card_code":"BG34_Giant_684_G","dbf_id":"129129","name":"时空扭曲米斯拉克斯","kind":"minion","category":"随从","categories":["随从","时空扭曲"],"mechanisms":["时空扭曲"],"tier":5,"cost":null,"tribes":["全部"],"is_golden":true,"normal_id":"BG34_Giant_684","golden_id":null,"image":"","solo_eligible":true,"source_url":"https://github.com/HearthSim/hsdata","native_source_build":"37.0.2.256589"}

static func accepts_id(value: Variant) -> bool:
	return value is String and value==ID

static func same(actual: Variant,expected: Variant) -> bool:
	# JSON integral floats are admissible. Booleans/strings/fractions/nonfinite values are not numbers.
	if expected is int or expected is float:
		return (actual is int or actual is float) and not actual is bool and is_finite(float(actual)) and is_finite(float(expected)) and actual==floor(actual) and expected==floor(expected) and actual==expected
	if typeof(actual)!=typeof(expected): return false
	if expected is Dictionary:
		if actual.size()!=expected.size(): return false
		for key in expected:
			if not actual.has(key) or not same(actual[key],expected[key]): return false
		return true
	if expected is Array:
		if actual.size()!=expected.size(): return false
		for index in range(expected.size()):
			if not same(actual[index],expected[index]): return false
		return true
	return actual==expected

static func proof_error() -> String:
	# Startup-only disk proof. Hot source_error/program/get_card never calls this.
	for path in FILE_SHA256:
		if not FileAccess.file_exists("res://"+path) or FileAccess.get_sha256("res://"+path)!=FILE_SHA256[path]: return "partial_3702_timewarp_mythrax_golden_evidence_changed:"+str(path)
	var packet: Variant=JSON.parse_string(FileAccess.get_file_as_string("res://"+OVERLAY))
	var expected_packet: Dictionary={"revision":REVISION,"cards":[{"id":ID,"expected_raw":EXPECTED_RAW,"expected_compiled":EXPECTED_COMPILED,"expected_baseline":EXPECTED_BASELINE,"effective_fields":EFFECTIVE_FIELDS}]}
	if not same(packet,expected_packet): return "partial_3702_timewarp_mythrax_golden_changed_packet"
	var baseline: Dictionary=EXPECTED_RAW.duplicate(true);baseline.merge(EXPECTED_COMPILED,true)
	if not same(baseline,EXPECTED_BASELINE): return "partial_3702_timewarp_mythrax_golden_invalid_baseline_derivation"
	baseline.merge(EFFECTIVE_FIELDS,true)
	if not same(baseline,EXPECTED_CURRENT) or str(EXPECTED_CURRENT.text).sha256_text()!=EXPECTED_CURRENT.coverage_text_sha256: return "partial_3702_timewarp_mythrax_golden_invalid_current_derivation"
	return ""

static func input_error(decoded: Variant,path: String) -> String:
	# Called before generic numeric normalization. Historical input is authenticated in full.
	var expected: Dictionary={}
	if path=="res://data/catalog_raw.json": expected=EXPECTED_RAW
	elif path=="res://data/catalog.json": expected=EXPECTED_COMPILED
	if not decoded is Dictionary or not decoded.get("cards") is Array:
		return "partial_3702_timewarp_mythrax_golden_missing_input:"+path if not expected.is_empty() else ""
	var matches: Array=[]
	for card in decoded.cards:
		if card is Dictionary and accepts_id(card.get("id")): matches.append(card)
	if expected.is_empty(): return "" if matches.is_empty() else "partial_3702_timewarp_mythrax_golden_unexpected_input:"+path
	if matches.size()!=1: return "partial_3702_timewarp_mythrax_golden_missing_or_duplicate_input:"+path
	return "" if same(matches[0],expected) else "partial_3702_timewarp_mythrax_golden_changed_whole_input:"+path

static func apply_overlay(cards: Dictionary) -> String:
	if cards.has(ID): return "timewarp_mythrax_golden_unexpected_existing_source"
	cards[ID]=EXPECTED_CURRENT.duplicate(true)
	return ""

static func source_error(card: Dictionary) -> String:
	# Small in-memory, typed, exact whole-current-row guard. No file access or hashing.
	if not accepts_id(card.get("id")): return "partial_3702_timewarp_mythrax_golden_unknown_source"
	return "" if same(card,EXPECTED_CURRENT) else "partial_3702_timewarp_mythrax_golden_changed_whole_effective_source"
