extends RefCounted
## Selected lesser 914 source revision. Not a pool or cross-family admission grant.
const REVISION: String="partial-37.0.2-lesser-nerglish-phrasebook-v1"
const ID: String="BG30_MagicItem_914"
const OVERLAY: String="data/patch_3702_murloc_phrasebook_overlay.json"
const FILE_SHA256: Dictionary={"data/patch_3702_murloc_phrasebook_overlay.json":"c674d8181c8e099046b88d32791e9191e038d03fe5a5ae806e335e975ed756fe","research/patch_3702_murloc_phrasebook/source_evidence.json":"78412cf332c597654fff9f09b7362fa6fcdf4908c7760a7910f5eee4e613a855","research/patch_3702_murloc_phrasebook/official_lesser_phrasebook_excerpt.html":"af1b7001e9b86cd4b6e19218a2173caf7390962f1768eb24199092ff1a927456","research/patch_3702_murloc_phrasebook/native/BG30_MagicItem_914.xml":"37afe471689acc6d18a3cf996d2af63cf5255c19b623630e432d641c03ab9c67","core/game.gd":"8ed244d2cc9b96aff98bbd5ec785ad641d138f90acf8d9b89fb87d7f44b2b44b","core/mechanism_effects.gd":"2bf8270878cbac39508ddbc588607340a3686f650547d7d5e4260b8ec25c7496","core/room_config.gd":"5ad842f365651173c745f4210fb5c69e2f93b67893959c75f0931cacc0b1382d","core/current_scope.gd":"a1e8c5d0b2e434aa3c95cf61ce5b8734027c3df0666a63c8d07d8b24e9d94e64","core/trinket_offer_schedule.gd":"a0820faab3bc89c7e6deaf85916f8bb1af3eb09bbbf5ca3d00a94c07409f31ec","core/damage_listener_room.gd":"cd3c7d104698f51b8ddf6b627d1a753f442778d00adc0ddb9e3c5287b2ac8287","core/lobby_tribes.gd":"96b74fb21b8876353defb8e457d6ee0f3e888fea59c2f810eaf9a552adceea6a","core/patch_3702_membership_sources.gd":"8b4a4f4981553125213b1d3a0cc80f66d7f54b229dcb74329430e6e4a5654842","data/current_scope_manifest.json":"60ba04da35d3db6933f5177207f70e713da5efa2ebc0707c863a24248de2fcff","data/patch_3702_membership.json":"8c72c5c371d4566afce4839cc5f2f95ead1c133fda9324f72bd054b004fc3e9c","data/tribe_pool_requirements.json":"cfcb116ed73f38ab77679ee9bb6ccb2c241f0e813b3f16a6fae3577cd956fde1"}
const RUNTIME_PATHS: Array=["core/patch_3702_murloc_phrasebook_sources.gd","data/patch_3702_murloc_phrasebook_overlay.json","research/patch_3702_murloc_phrasebook/source_evidence.json","research/patch_3702_murloc_phrasebook/official_lesser_phrasebook_excerpt.html","research/patch_3702_murloc_phrasebook/native/BG30_MagicItem_914.xml","core/game.gd","core/mechanism_effects.gd","core/room_config.gd","core/current_scope.gd","core/trinket_offer_schedule.gd","core/damage_listener_room.gd","core/lobby_tribes.gd","core/patch_3702_membership_sources.gd","data/current_scope_manifest.json","data/patch_3702_membership.json","data/tribe_pool_requirements.json"]

static func accepts_id(phrasebook_identity: Variant) -> bool:
	return phrasebook_identity is String and phrasebook_identity==ID

static func same(phrasebook_actual: Variant,phrasebook_expected: Variant) -> bool:
	# JSON parses numbers as floats; accept only finite integral numeric equality.
	# In particular, booleans, fractional values and strings are never numbers.
	if phrasebook_expected is int or phrasebook_expected is float:
		return (phrasebook_actual is int or phrasebook_actual is float) and not phrasebook_actual is bool and is_finite(float(phrasebook_actual)) and is_finite(float(phrasebook_expected)) and phrasebook_actual==floor(phrasebook_actual) and phrasebook_expected==floor(phrasebook_expected) and phrasebook_actual==phrasebook_expected
	if typeof(phrasebook_actual)!=typeof(phrasebook_expected): return false
	if phrasebook_expected is Dictionary:
		if phrasebook_actual.size()!=phrasebook_expected.size(): return false
		for phrasebook_key in phrasebook_expected:
			if not phrasebook_actual.has(phrasebook_key) or not same(phrasebook_actual[phrasebook_key],phrasebook_expected[phrasebook_key]): return false
		return true
	if phrasebook_expected is Array:
		if phrasebook_actual.size()!=phrasebook_expected.size(): return false
		for phrasebook_index in range(phrasebook_expected.size()):
			if not same(phrasebook_actual[phrasebook_index],phrasebook_expected[phrasebook_index]): return false
		return true
	return phrasebook_actual==phrasebook_expected

static func normalize(phrasebook_value: Variant) -> Variant:
	if phrasebook_value is float and is_finite(phrasebook_value) and phrasebook_value==floor(phrasebook_value) and phrasebook_value>=-9007199254740991 and phrasebook_value<=9007199254740991: return int(phrasebook_value)
	if phrasebook_value is Array:
		var phrasebook_items: Array=[]
		for phrasebook_item in phrasebook_value: phrasebook_items.append(normalize(phrasebook_item))
		return phrasebook_items
	if phrasebook_value is Dictionary:
		var phrasebook_fields: Dictionary={}
		for phrasebook_key in phrasebook_value: phrasebook_fields[phrasebook_key]=normalize(phrasebook_value[phrasebook_key])
		return phrasebook_fields
	return phrasebook_value

static func proof_error() -> String:
	for phrasebook_path in FILE_SHA256:
		if not FileAccess.file_exists("res://"+phrasebook_path) or FileAccess.get_sha256("res://"+phrasebook_path)!=FILE_SHA256[phrasebook_path]: return "partial_3702_murloc_phrasebook_evidence_changed:"+str(phrasebook_path)
	return ""

static func packet() -> Dictionary:
	if not proof_error().is_empty(): return {}
	var phrasebook_packet: Variant=JSON.parse_string(FileAccess.get_file_as_string("res://"+OVERLAY))
	if not phrasebook_packet is Dictionary or phrasebook_packet.get("revision")!=REVISION or not phrasebook_packet.get("cards") is Array or phrasebook_packet.cards.size()!=1: return {}
	var phrasebook_row: Variant=phrasebook_packet.cards[0]
	if not phrasebook_row is Dictionary or not accepts_id(phrasebook_row.get("id")): return {}
	for phrasebook_field in ["expected_raw","expected_compiled","expected_baseline","effective_fields"]:
		if not phrasebook_row.get(phrasebook_field) is Dictionary: return {}
	return normalize(phrasebook_row)

static func input_error(phrasebook_input: Variant,phrasebook_path: String) -> String:
	var phrasebook_field: String=""
	if phrasebook_path=="res://data/catalog_raw.json": phrasebook_field="expected_raw"
	elif phrasebook_path=="res://data/catalog.json": phrasebook_field="expected_compiled"
	if not phrasebook_input is Dictionary or not phrasebook_input.get("cards") is Array:
		return "partial_3702_murloc_phrasebook_missing_input:"+phrasebook_path if not phrasebook_field.is_empty() else ""
	var phrasebook_matches: Array=[]
	for phrasebook_card in phrasebook_input.cards:
		if phrasebook_card is Dictionary and accepts_id(phrasebook_card.get("id")): phrasebook_matches.append(phrasebook_card)
	if phrasebook_field.is_empty():
		return "partial_3702_murloc_phrasebook_unexpected_input:"+phrasebook_path if not phrasebook_matches.is_empty() else ""
	if phrasebook_matches.size()!=1: return "partial_3702_murloc_phrasebook_missing_or_duplicate_input:"+phrasebook_path
	var phrasebook_row: Dictionary=packet()
	if phrasebook_row.is_empty(): return "partial_3702_murloc_phrasebook_missing_or_changed_packet"
	return "" if same(phrasebook_matches[0],phrasebook_row[phrasebook_field]) else "partial_3702_murloc_phrasebook_changed_whole_input:"+phrasebook_path

static func apply_overlay(phrasebook_cards: Dictionary) -> String:
	var phrasebook_row: Dictionary=packet()
	if phrasebook_row.is_empty(): return "partial_3702_murloc_phrasebook_missing_or_changed_packet"
	if not phrasebook_cards.has(ID) or not same(phrasebook_cards[ID],phrasebook_row.expected_baseline): return "partial_3702_murloc_phrasebook_changed_whole_baseline"
	var phrasebook_merged: Dictionary=phrasebook_cards[ID].duplicate(true)
	phrasebook_merged.merge(phrasebook_row.effective_fields,true)
	if str(phrasebook_merged.text).sha256_text()!=phrasebook_merged.coverage_text_sha256: return "partial_3702_murloc_phrasebook_changed_text_digest"
	phrasebook_cards[ID]=phrasebook_merged
	return ""

static func source_error(phrasebook_card: Dictionary) -> String:
	if not accepts_id(phrasebook_card.get("id")): return "partial_3702_murloc_phrasebook_unknown_source"
	var phrasebook_row: Dictionary=packet()
	if phrasebook_row.is_empty(): return "partial_3702_murloc_phrasebook_missing_or_changed_packet"
	var phrasebook_expected: Dictionary=phrasebook_row.expected_baseline.duplicate(true)
	phrasebook_expected.merge(phrasebook_row.effective_fields,true)
	# Preserve the entire source, including original flags, category and provenance.
	# This check never promotes support and continues through Catalog's old gates.
	return "" if same(phrasebook_card,phrasebook_expected) else "partial_3702_murloc_phrasebook_changed_whole_effective_source"
