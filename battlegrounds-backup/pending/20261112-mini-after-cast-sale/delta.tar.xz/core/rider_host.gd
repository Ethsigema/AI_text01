extends RefCounted
## Cumulative candidate: no local stat writer and no new persistent spell counter.
const Sources=preload("res://core/rider_sources.gd")
const IDS: Array=["BG31_925","BG31_925_G"]
const DOMAIN: Array=["BG31_925","BG31_925_G","BG23_000","BG23_000_G","BG23_007","BG23_007_G","BG31_035","BG31_035_G","BG25_354","BG25_354_G"]
const LIMIT: int=9007199254740991
const CAST_EVENT: String="native_player_tavern_spell_committed"
var _authority: Dictionary={}
var _origins: Array=[{},{}]
var _deaths: Dictionary={}
static func fail(issue: String) -> Dictionary: return {"ok":false,"error":issue}
static func integer(v: Variant,maximum: int=LIMIT) -> bool:
	return (v is int or v is float) and not v is bool and is_finite(float(v)) and v>=0 and v<=maximum and v==floor(v)
static func has(units: Array) -> bool: return units.any(func(u):return u is Dictionary and u.get("card_id",u.get("id")) in IDS)
static func amount(id: String,count: Variant) -> Dictionary:
	if id not in IDS or not integer(count): return fail("rider_invalid_source_or_count")
	@warning_ignore("integer_division")
	var steps: int=int(count)/3
	var m: int=1 if id==IDS[0] else 2
	return {"ok":true,"error":"","attack":2*m*(1+steps),"health":m*(1+steps)}
static func body_flags_error(u: Dictionary) -> String:
	return "" if u.get("temporary")==false and u.get("is_spellcraft")==false else "rider_temporary_or_spellcraft_body_partial"
static func body_error(game,u: Dictionary) -> String:
	var flag_issue: String=body_flags_error(u)
	if not flag_issue.is_empty(): return flag_issue
	if u.get("kind")!="minion" or u.get("card_id") not in DOMAIN: return "rider_other_native_body_partial"
	var card: Dictionary=game.catalog.get_card(str(u.card_id))
	if card.is_empty() or card.get("supported")!=true or card.get("effects")!=u.get("effects") or card.get("tribes")!=u.get("tribes") or card.get("is_golden",false)!=u.get("golden",false): return "rider_complete_native_body_required"
	if u.get("card_id") in IDS:
		var issue: String=Sources.source_error(card)
		if not issue.is_empty(): return issue
		issue=Sources.unit_error(u)
		if not issue.is_empty(): return issue
	for k in ["attack","health","max_health"]:
		if not integer(u.get(k),1000000000) or (k!="attack" and u[k]<1): return "rider_initial_stat_range_partial"
	if u.health>u.max_health or u.get("golden_rebase_state")!="additive_v1": return "rider_native_health_or_rebase_required"
	if not u.get("uid") is String or u.uid.is_empty(): return "rider_original_uid_required"
	if u.get("silenced",false) or u.get("abilities_disabled",false) or u.get("_pending_destroy",false): return "rider_disabled_source_partial"
	if u.get("keywords")!=card.get("keywords",[]) or u.get("permanent_keywords")!=card.get("keywords",[]) or "reborn" in u.get("keywords",[]): return "rider_reborn_or_granted_keyword_partial"
	for k in ["attachments","temporary_buffs"]:
		if not u.get(k,[]).is_empty(): return "rider_attachment_or_temporary_layer_partial"
	for k in ["recruit_shop_aura_attack","recruit_shop_aura_health"]:
		if u.get(k,0)!=0: return "rider_shop_aura_partial"
	var expected: Dictionary={"card_id":card.id,"name":card.get("name",str(card.id)),"tier":int(card.get("tier",1)),"attack":int(card.attack),"health":int(card.health),"max_health":int(card.health),"keywords":card.get("keywords",[]),"tribes":card.tribes,"effects":card.effects,"golden":card.get("is_golden",false)}
	if not Sources.same(u.get("base_unit"),expected): return "rider_copied_transformed_base_partial"
	for k in u:
		if k not in UNIT_FIELDS: return "rider_unknown_body_layer_partial:"+str(k)
	return ""
const UNIT_FIELDS: Array=["uid","card_id","name","kind","tier","attack","health","max_health","keywords","tribes","effects","golden","cost","temporary","is_spellcraft","temporary_buffs","permanent_keywords","text","image","pool_count","spellcraft_kept","spell_triggers","attachments","pool_components","magnetic_tribes","individually_frozen","blood_gems_received_turn","recruit_shop_bonus_applied","recruit_shop_aura_attack","recruit_shop_aura_health","base_unit","golden_rebase_state","pool_id","pool_kind","silenced","abilities_disabled","_pending_destroy"]
static func fields(v: Variant,keys: Array) -> bool:
	return v is Dictionary and v.size()==keys.size() and keys.all(func(k):return v.has(k))
# Pure finite-domain queue admission; inactive valid historical containers are
# allowed. Nonempty terminal coin history is conservatively outside this slice.
static func queue_error(p: Dictionary) -> String:
	if not p.get("mechanism_reward_queue",[]) is Array or not p.get("mechanism_reward_queue",[]).is_empty(): return "rider_mechanism_reward_queue_partial"
	if p.has("native_timed_spell_queue"):
		var q: Variant=p.native_timed_spell_queue
		if not fields(q,["version","owner","serial","pending"]) or not integer(q.version,1) or q.version!=1 or not integer(q.owner) or q.owner!=p.get("id") or not integer(q.serial) or not q.pending is Array: return "rider_invalid_timed_owner_queue"
		if not q.pending.is_empty(): return "rider_timed_owner_spell_pending_partial"
	if p.has("timed_dragon_buff_state"):
		var q: Variant=p.timed_dragon_buff_state
		if not q is Dictionary or not integer(q.get("schema_version"),2) or q.schema_version not in [1,2] or not integer(q.get("owner")) or q.owner!=p.get("id"): return "rider_invalid_timed_dragon_queue"
		if q.schema_version==1:
			if not fields(q,["schema_version","owner","entry"]) or not q.entry is Dictionary or not q.entry.is_empty(): return "rider_timed_dragon_pending_partial"
		else:
			if not fields(q,["schema_version","owner","entries"]) or not q.entries is Array or not q.entries.is_empty(): return "rider_timed_dragon_pending_partial"
	for key in ["prize_returning_coin_state","turn_repeat_spell_state"]:
		if not p.has(key): continue
		var q: Variant=p[key];var version: int=2 if key=="prize_returning_coin_state" else 1
		if not fields(q,["schema_version","owner","entries"]) or not integer(q.schema_version,version) or q.schema_version!=version or not integer(q.owner) or q.owner!=p.get("id") or not q.entries is Dictionary: return "rider_invalid_independent_owner_queue:"+key
		if not q.entries.is_empty(): return "rider_independent_owner_queue_partial:"+key
	return ""
static func owner_error(game,p: Dictionary) -> String:
	var queue_issue: String=queue_error(p)
	if not queue_issue.is_empty(): return queue_issue
	if p.get("hero_id")!="TB_BaconShop_HERO_01": return "rider_hero_program_partial"
	if not integer(p.get("stats",{}).get("spells"),1000000): return "rider_initial_spell_count_partial"
	for key in ["hero_identity_id","hero_identity_portrait","hero_power_replacement_history","native_denathrius_initial_quest","native_shady_aristocrat_quests","native_elemental_given_attack","native_elemental_given_health","native_ditch_guardian_given_stats","native_enhanced_spawn_given_stats"]:
		if p.has(key): return "rider_other_owner_layer_partial:"+key
	for key in ["active_quest","reward_active","trinkets","permanent_tribe_bonuses","discover","discover_queue","next_combat_spell_queue"]:
		if p.get(key,{}) not in [{},[],"",null]: return "rider_owned_mechanism_partial:"+key
	if not game._mechanic_effects(p).is_empty(): return "rider_owned_mechanism_effects_partial"
	for u in p.get("board",[])+p.get("hand",[]):
		if u.get("kind")=="spell" and p.get("hand",[]).any(func(h):return is_same(h,u)): continue
		var issue: String=body_error(game,u)
		if not issue.is_empty(): return issue
	return ""
static func recipient_error(target: Dictionary,attack: int,health: int) -> String:
	if target.get("_pending_destroy",false): return "rider_pending_destroy_recipient_partial"
	if attack<0 or health<0 or attack>LIMIT or health>LIMIT: return "rider_recipient_delta_invalid"
	for key in ["attack","health","max_health"]:
		var delta: int=attack if key=="attack" else health
		if not integer(target.get(key),LIMIT-delta): return "rider_recipient_overflow"
	if target.health<1 or target.max_health<target.health: return "rider_recipient_health_invalid"
	return ""
static func round_error(game) -> String:
	var owners: Array=game.state.get("players",[])+game.state.get("ghosts",[])
	if not owners.any(func(p):return has(p.get("board",[]))): return ""
	# Before original EOT, pairing, RNG and combat state transitions. Reject
	# unknown EOT/copy/cast mechanics rather than finding them at a death.
	if not game.state.get("ghosts",[]).is_empty(): return "rider_ghost_snapshot_partial"
	if not game._enabled("anomalies").is_empty(): return "rider_anomaly_intersection_partial"
	for p in owners:
		var issue: String=owner_error(game,p)
		if not issue.is_empty(): return issue
	return ""
static func attach(game,combat,left: Dictionary,right: Dictionary,l: Array,r: Array,options: Dictionary,ghost: bool) -> String:
	combat._rider_authority={}
	if not has(l+r): return ""
	if game.get_script().resource_path!="res://core/game.gd" or combat.get_script().resource_path!="res://core/combat.gd" or game.state.phase!="combat": return "rider_actual_game_and_combat_required"
	if not integer(left.get("id"),game.state.players.size()-1) or not integer(right.get("id"),game.state.players.size()-1) or left.id==right.id or not is_same(game.state.players[int(left.id)],left) or not is_same(game.state.players[int(right.id)],right): return "rider_actual_distinct_owners_required"
	if not Sources.same(l,left.board) or not Sources.same(r,right.board): return "rider_complete_prepared_boards_required"
	var tx: Dictionary=options.get("delayed_gold_context",{})
	if tx.get("round")!=game.state.round or tx.get("owners")!=[left.id,right.id] or not tx.get("transaction_id") is String or tx.transaction_id.is_empty(): return "rider_actual_transaction_required"
	if ghost: return "rider_ghost_snapshot_partial"
	for p in [left,right]:
		var issue: String=owner_error(game,p)
		if not issue.is_empty(): return issue
	var seen: Dictionary={}
	for side in range(2):
		var owner: Dictionary=left if side==0 else right
		for unit in (l if side==0 else r):
			var matches: Array=owner.board.filter(func(u):return u.get("uid")==unit.get("uid"))
			if matches.size()!=1 or unit.get("card_id")!=matches[0].get("card_id") or unit.get("effects")!=matches[0].get("effects") or seen.has(unit.get("uid")): return "rider_original_prepared_identity_required"
			seen[unit.uid]=true
	var authority: Dictionary={"issuer":weakref(game),"combat":weakref(combat),"owners":[left,right],"ids":[left.id,right.id],"counts":[int(left.stats.spells),int(right.stats.spells)],"left":l,"right":r,"options":options,"round":game.state.round,"sequence":game.state.command_sequence,"used":false,"snapshots":[l.duplicate(true),r.duplicate(true)],"transaction":tx.duplicate(true)}
	game._rider_combat_authority=authority;combat._rider_authority=authority
	return ""
func bind_inputs(combat,left: Array,right: Array,options: Dictionary) -> String:
	var a: Dictionary=combat._rider_authority
	combat._rider_authority={}
	if not has(left+right): return "" if a.is_empty() else "rider_changed_issued_sources"
	if a.is_empty() or a.get("used")!=false or not a.get("combat") is WeakRef or not is_same(a.combat.get_ref(),combat) or not is_same(a.get("left"),left) or not is_same(a.get("right"),right) or not is_same(a.get("options"),options) or not a.get("issuer") is WeakRef: return "rider_actual_owner_authority_required"
	var game=a.issuer.get_ref()
	if game==null or game.get_script().resource_path!="res://core/game.gd" or game.state.phase!="combat" or not is_same(game._rider_combat_authority,a) or a.round!=game.state.round or a.sequence!=game.state.command_sequence: return "rider_stale_actual_game_authority"
	for side in range(2):
		var owner: Dictionary=a.owners[side]
		if not is_same(game.state.players[int(a.ids[side])],owner) or owner.id!=a.ids[side] or owner.stats.spells!=a.counts[side] or not Sources.same(owner.board,a.snapshots[side]) or not Sources.same(left if side==0 else right,a.snapshots[side]): return "rider_changed_bound_owner_or_board"
	if not Sources.same(options.get("delayed_gold_context"),a.transaction): return "rider_changed_transaction"
	a.used=true;_authority=a
	return ""
func initialize(combat) -> String:
	if _authority.is_empty(): return ""
	for side in range(2):
		for unit in combat._boards[side]:
			if unit.get("card_id") in IDS:
				_origins[side][unit.uid]={"unit":unit,"combat_id":unit._combat_id,"id":unit.card_id}
	return ""
func source_error(combat,entry: Dictionary) -> String:
	var side: int=int(entry.get("side",-1));var u: Dictionary=entry.get("unit",{})
	if _authority.is_empty() or side not in [0,1]: return "rider_private_owner_required"
	var origin: Dictionary=_origins[side].get(u.get("uid"),{})
	if origin.is_empty() or not is_same(origin.get("unit"),u) or origin.get("combat_id")!=u.get("_combat_id") or origin.get("id")!=u.get("card_id"): return "rider_original_combat_identity_required"
	return Sources.unit_error(u)
func removed(combat,entry: Dictionary) -> String:
	var issue: String=source_error(combat,entry)
	if not issue.is_empty(): return issue
	var u: Dictionary=entry.unit;var side: int=int(entry.side)
	if not is_same(combat._rider_removal_context.get("entry"),entry) or not is_same(combat._rider_removal_context.get("queue"),combat._pending_deaths) or not combat._pending_deaths.any(func(e):return is_same(e,entry)): return "rider_actual_removed_entry_required"
	if combat._boards[side].any(func(body):return is_same(body,u)) or (int(u.health)>0 and not u.get("_pending_destroy",false)): return "rider_not_dead_and_removed"
	var n: int=int(entry.get("milestone_death_sequence",-1))
	if n<0 or n>=combat._log.size(): return "rider_missing_death_receipt"
	var row: Dictionary=combat._log[n]
	if row.get("event")!="death" or row.get("side")!=side or row.get("unit")!=u.uid or _deaths.has(u._combat_id): return "rider_changed_death_receipt"
	_deaths[u._combat_id]={"entry":entry,"receipt":row,"sequence":n,"next":1}
	return ""
# Existing private owner-cast journal is checked, but nonempty journals are held.
# No live player-cast source belongs to the admitted finite domain.
# No log-only events and no spell counters are written by this host.
func current_count(combat,side: int) -> Dictionary:
	if _authority.is_empty() or side not in [0,1]: return fail("rider_missing_count_authority")
	var history=combat._combat_ring_cast_host.player_history
	var rows: Array=combat._log.filter(func(e):return e.get("event")==CAST_EVENT)
	if rows!=history._events or (not rows.is_empty() and not is_same(history._engine,combat)): return fail("rider_unissued_player_cast_history")
	if not rows.is_empty(): return fail("rider_combat_player_cast_intersection_partial")
	var n: int=int(_authority.counts[side])
	for e in rows:
		if e.get("side")!=side: continue
		if e.get("owner")!=_authority.ids[side]: return fail("rider_player_cast_owner_changed")
		n+=1
	if not integer(n): return fail("rider_count_overflow")
	return {"ok":true,"error":"","count":n}
func project(combat,entry: Dictionary,effect: Dictionary,repetition: int,trigger: String) -> Dictionary:
	var issue: String=source_error(combat,entry)
	if not issue.is_empty(): return fail(issue)
	var gate: Dictionary=combat._rider_dispatch_context
	if not is_same(gate.get("entry"),entry) or not is_same(gate.get("effect"),effect) or gate.get("repetition")!=repetition or gate.get("trigger")!=trigger or gate.get("group")!=0: return fail("rider_private_native_dispatch_required")
	if trigger!="deathrattle" or entry.get("live_source",false) or effect!=Sources.program(str(entry.unit.card_id))[0]: return fail("rider_living_or_changed_program_partial")
	var ticket: Dictionary=_deaths.get(entry.unit._combat_id,{})
	if ticket.is_empty() or not is_same(ticket.get("entry"),entry) or ticket.get("next")!=repetition or repetition>int(entry.get("repeats",1)) or not is_same(combat._log[ticket.sequence],ticket.receipt): return fail("rider_missing_or_replayed_death")
	var count: Dictionary=current_count(combat,int(entry.side))
	if not count.ok: return count
	var v: Dictionary=amount(str(entry.unit.card_id),count.count)
	if not v.ok: return v
	# Preflight all recipients before the unchanged generic branch writes any.
	for target in combat._boards[int(entry.side)]:
		if int(target.get("health",0))<=0 or not combat._tribe_matches(target,"纳迦"): continue
		issue=recipient_error(target,int(v.attack),int(v.health))
		if not issue.is_empty(): return fail(issue)
	ticket.next=repetition+1
	return {"ok":true,"error":"","effect":{"type":"deathrattle_buff","scope":"all_friendly","tribe":"纳迦","attack":v.attack,"health":v.health},"count":count.count}
