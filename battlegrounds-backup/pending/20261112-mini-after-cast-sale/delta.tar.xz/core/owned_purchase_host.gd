extends RefCounted
const Sources=preload("res://core/owned_purchase_sources.gd")
const CopyFactory=preload("res://core/recruit_instance_copy.gd")
const Prefix=preload("res://core/recruit_prefix_cursor.gd")
const POLICY: String="whole_turn_pirate_buy_and_lifetime_slot_current_copy_v1"
static func _fail(issue: String) -> Dictionary: return {"ok":false,"error":issue,"cost":-1}
## Ordinary Gold purchases keep the original actual debit, spend callbacks,
## shop transfer and source-listener order. Run that same complete command on
## the existing disposable Game before touching live payment state. In
## particular, a spend reward can fill the hand before the bought offer is
## delivered; any existing successful-transfer failure must precede live debit.
## This is not a refund or an invented purchase receipt. Successful overflow
## behavior remains the original command's behavior, and no shadow state is
## copied back. Existing unknown-order and alternative-currency holds remain.
static func command_preflight(engine,player_id: int,command: Dictionary) -> String:
	if engine._ordinary_purchase_projecting or engine.state.get("phase")!="recruit" or player_id<0 or player_id>=engine.state.get("players",[]).size(): return ""
	if command.get("type",command.get("action",""))!="buy": return ""
	var player: Dictionary=engine.state.players[player_id]
	var index: int=int(command.get("index",-1))
	if index<0 or index>=player.get("shop",[]).size() or not player.get("alive",false) or player.get("ready",false): return ""
	var quoted: Dictionary=engine._buy_cost_quote(player,player.shop[index])
	# An invalid quote already fails before the original debit. Health/armor
	# currency programs retain their own exact transaction and partial domains.
	if not quoted.get("ok",false) or quoted.get("currency","gold")!="gold" or quoted.get("health_buy",false) or quoted.has("health_cost") or quoted.has("armor_cost"): return ""
	var cursor: Dictionary={"player":player.duplicate(true),"totals":engine._attack_gain_health_totals.duplicate(true),"next_uid":engine.next_uid,"rng_seed":engine.rng.seed,"rng_state":engine.rng.state,"pool":engine.pool.duplicate(true),"spell_pool":engine.spell_pool.duplicate(true)}
	var detached: Dictionary=Prefix.create(engine,cursor)
	if not detached.ok: return str(detached.error)
	var shadow=detached.engine
	shadow._ordinary_purchase_projecting=true
	var darkcrest_projection_issue: String=engine._darkcrest_host.bind_purchase_projection(engine,shadow,player_id,command)
	if not darkcrest_projection_issue.is_empty(): return darkcrest_projection_issue
	var result: Dictionary=shadow.apply_command(player_id,command.duplicate(true))
	shadow._darkcrest_host.release_purchase_projection()
	if not result.get("ok",false): return str(result.get("error","ordinary_purchase_complete_command_failed"))
	if shadow.state.get("phase")=="error": return "ordinary_purchase_complete_command_stopped"
	return ""

static func zero(player: Dictionary,round_number: int) -> Dictionary: return {"owner":player.id,"round":round_number,"pirates":0}
static func begin_turn(player: Dictionary,round_number: int) -> String:
	var issue: String=Sources.history_error(player,round_number)
	if not issue.is_empty(): return issue
	player[Sources.HISTORY]=zero(player,round_number)
	return ""
static func acquisition_error(engine,player: Dictionary,card: Dictionary) -> String:
	var id: String=str(card.get("id",""))
	if id not in Sources.IDS: return ""
	var issue: String=Sources.player_error(player,int(engine.state.round),engine.catalog)
	if issue.is_empty(): issue=Sources.closure_error(engine.catalog,id)
	if issue.is_empty() and id==Sources.PORTRAIT: issue=Sources.history_error(player,int(engine.state.round),true)
	return issue
static func acquired(engine,player: Dictionary,context: Dictionary) -> String:
	if context.get("source_kind")!="trinket" or context.get("source_id") not in Sources.IDS: return ""
	if not engine.state.players.any(func(owner):return is_same(owner,player)): return "owned_purchase_actual_acquired_owner_required"
	var id: String=str(context.source_id)
	var issue: String=Sources.closure_error(engine.catalog,id)
	if not issue.is_empty(): return issue
	if id==Sources.PORTRAIT: return Sources.history_error(player,int(engine.state.round),true)
	var slot: int=player.get("trinkets",[]).rfind(id)
	if slot<0: return "owned_purchase_actual_acquired_slot_missing"
	if not player.has(Sources.STATE): player[Sources.STATE]={"owner":player.id,"slots":{}}
	var key: String=Sources.slot_key(slot,id)
	if player[Sources.STATE].get("owner")!=player.id or not player[Sources.STATE].get("slots") is Dictionary: return "owned_purchase_acquired_state_changed"
	if player[Sources.STATE].slots.has(key): return "owned_purchase_same_slot_reacquisition_partial"
	player[Sources.STATE].slots[key]={"id":id,"slot":slot,"remaining":int(Sources.PROGRAMS[id][0].limit)}
	engine._log("owned_purchase_copy_acquired",{"player":player.id,"source_id":id,"source_slot":slot,"remaining":int(Sources.PROGRAMS[id][0].limit),"policy":POLICY})
	return ""
static func quote(engine,player: Dictionary,unit: Dictionary,base: Dictionary) -> Dictionary:
	if not base.get("ok",false) or Sources.PORTRAIT not in player.get("trinkets",[]) or unit.get("kind")!="minion" or not engine._tribe_match(unit,"海盗"): return base
	var issue: String=Sources.player_error(player,int(engine.state.round),engine.catalog)
	if not issue.is_empty(): return _fail(issue)
	if int(player[Sources.HISTORY].pirates)>0: return base
	if not Sources.integer(base.get("cost")) or not player.get("shop",[]).any(func(card):return is_same(card,unit)): return _fail("owned_purchase_quote_requires_actual_shop")
	# Existing pricing computes first. An unproved second consumed-price plan is
	# held before payment rather than discarded or silently consumed at zero.
	if base.has("native_purchase_quota") or base.has("attack_unlock_plan") or player.has(engine.PrizePrice.STATE_KEY) or unit.has(engine.FilteredOfferPrice.KEY): return _fail("owned_purchase_consumed_price_intersection_partial")
	if int(base.cost)>0:
		issue=engine.PurchaseQuotas._old_price_error(engine,player,unit,base)
		if not issue.is_empty(): return _fail(issue)
	var slots: Array=[]
	for slot in range(player.trinkets.size()):
		if player.trinkets[slot]==Sources.PORTRAIT: slots.append(slot)
	var result: Dictionary=base.duplicate(true)
	result.cost=0
	result.native_owned_purchase_free={"history":player[Sources.HISTORY].duplicate(true),"slots":slots,"base_cost":int(base.cost)}
	return result
static func prepare(engine,player: Dictionary,unit: Dictionary,quoted: Dictionary) -> Dictionary:
	var active: bool=player.has(Sources.HISTORY) or player.get("trinkets",[]).any(func(id):return id in Sources.IDS)
	if not active: return {"ok":true,"error":"","active":false}
	if not engine._owned_purchase_context.is_empty(): return _fail("owned_purchase_reentrant_buy")
	var issue: String=Sources.player_error(player,int(engine.state.round),engine.catalog)
	if not issue.is_empty(): return _fail(issue)
	var command: Dictionary=engine._bounty_spend_command
	if engine.state.phase!="recruit" or not player.get("alive",false) or not engine.state.players.any(func(owner):return is_same(owner,player)) or not is_same(command.get("owner"),player) or command.get("action")!="buy" or command.get("round")!=engine.state.round or command.get("sequence")!=engine.state.command_sequence or command.get("used",false): return _fail("owned_purchase_actual_buy_command_required")
	if not unit.get("uid") is String or unit.uid.is_empty() or player.get("shop",[]).filter(func(card):return card.get("uid")==unit.uid).size()!=1 or not player.shop.any(func(card):return is_same(card,unit)): return _fail("owned_purchase_actual_shop_identity_required")
	var fresh: Dictionary=engine._buy_cost_quote(player,unit)
	if not fresh.get("ok",false): return fresh
	if fresh.cost!=quoted.cost or not Sources.same(fresh.get("native_owned_purchase_free",{}),quoted.get("native_owned_purchase_free",{})): return _fail("owned_purchase_quote_changed")
	var history: Dictionary=player.get(Sources.HISTORY,{}).duplicate(true)
	var pirate: bool=unit.get("kind")=="minion" and engine._tribe_match(unit,"海盗")
	if pirate and not history.is_empty() and int(history.round)==int(engine.state.round) and int(history.pirates)>=Sources.MAX: return _fail("owned_purchase_pirate_history_overflow")
	var records: Array=[]
	if unit.get("kind")=="minion":
		for slot in range(player.get("trinkets",[]).size()):
			var id: String=str(player.trinkets[slot])
			if id not in Sources.COPIERS: continue
			var entry: Dictionary=player[Sources.STATE].slots[Sources.slot_key(slot,id)]
			if int(entry.remaining)>0: records.append({"id":id,"slot":slot,"before":entry.duplicate(true)})
	if not records.is_empty():
		# Reject unknown current-entity inheritance before paying. A fresh exact
		# current template is taken at the documented successful-transfer window.
		var copy: Dictionary=CopyFactory.current_copy_plan(engine,player,unit)
		if not copy.ok: return copy
	return {"ok":true,"error":"","active":true,"owner":player,"unit":unit,"uid":unit.uid,"card_id":unit.card_id,"command":command,"round":int(engine.state.round),"sequence":engine.state.command_sequence,"cost":int(quoted.cost),"gold_before":int(player.gold),"bought_before":int(player.stats.bought),"history_before":history,"pirate":pirate,"records":records,"trinkets":player.get("trinkets",[]).duplicate(true),"paid":false,"used":false}
static func mark_paid(engine,player: Dictionary,unit: Dictionary,cost: int) -> String:
	var ticket: Dictionary=engine._owned_purchase_context
	if ticket.is_empty(): return ""
	if ticket.paid or ticket.used or not is_same(ticket.owner,player) or not is_same(ticket.unit,unit) or not is_same(ticket.command,engine._bounty_spend_command) or ticket.cost!=cost or player.gold!=int(ticket.gold_before)-cost: return "owned_purchase_exact_debit_required"
	ticket.paid=true
	return ""
static func commit(engine,player: Dictionary,unit: Dictionary) -> String:
	var ticket: Dictionary=engine._owned_purchase_context
	if ticket.is_empty(): return ""
	if not ticket.paid or ticket.used or not is_same(ticket.owner,player) or not is_same(ticket.unit,unit) or ticket.uid!=unit.get("uid") or ticket.card_id!=unit.get("card_id") or ticket.round!=engine.state.round or ticket.sequence!=engine.state.command_sequence or not is_same(ticket.command,engine._bounty_spend_command) or int(player.stats.bought)!=ticket.bought_before or engine.state.phase!="recruit" or player.shop.any(func(card):return is_same(card,unit)) or not player.hand.any(func(card):return is_same(card,unit)): return "owned_purchase_successful_shop_transfer_required"
	if not Sources.same(player.get(Sources.HISTORY,{}),ticket.history_before) or not Sources.same(player.get("trinkets",[]),ticket.trinkets): return "owned_purchase_owner_state_changed"
	for record in ticket.records:
		if not Sources.same(player.get(Sources.STATE,{}).get("slots",{}).get(Sources.slot_key(int(record.slot),str(record.id))),record.before): return "owned_purchase_copy_quota_changed"
	var template: Dictionary={}
	if not ticket.records.is_empty():
		var copy: Dictionary=CopyFactory.current_copy_plan(engine,player,unit)
		if not copy.ok: return str(copy.error)
		template=copy.template
	# One committed transfer advances history, even when it was already free.
	# Slots consume their lifetime purchase entitlement before acquisition hooks.
	ticket.used=true
	if ticket.pirate and not ticket.history_before.is_empty() and int(ticket.history_before.round)==int(engine.state.round): player[Sources.HISTORY].pirates=int(ticket.history_before.pirates)+1
	for record in ticket.records:
		player[Sources.STATE].slots[Sources.slot_key(int(record.slot),str(record.id))].remaining=int(record.before.remaining)-1
	for record in ticket.records:
		var allocated: Dictionary=engine._unit(engine.catalog.get_card(str(template.card_id)))
		if allocated.is_empty(): return "owned_purchase_copy_factory_failed"
		var copy: Dictionary=template.duplicate(true)
		copy.uid=allocated.uid;copy.pool_count=0;copy.pool_id="";copy.pool_components=[]
		var incubation_copy_issue: String=engine.IncubationMutation.rebind_copy(engine,player,unit,copy)
		if not incubation_copy_issue.is_empty(): return incubation_copy_issue
		engine._add_hand(player,copy)
		if engine.state.phase=="error": return "owned_purchase_current_copy_acquisition_failed"
		engine._log("owned_purchase_current_copy",{"player":player.id,"source_id":record.id,"source_slot":record.slot,"bought_uid":unit.uid,"copy_uid":copy.uid,"card_id":copy.card_id,"remaining":int(record.before.remaining)-1,"accepted":player.hand.any(func(card):return is_same(card,copy)),"policy":POLICY})
	engine._owned_purchase_context={}
	return ""
