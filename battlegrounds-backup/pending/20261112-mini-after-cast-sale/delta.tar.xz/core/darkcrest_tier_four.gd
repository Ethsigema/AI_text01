extends RefCounted
## Finite native hand-state admission only. No live unit/stat/UID/pool writer.
const Sources=preload("res://core/darkcrest_sources.gd")
const IDS: Array=["BG26_505","BG33_319","BG34_925","BG35_921","BG36_508"]
static func history_error(game,player: Dictionary) -> String:
	var issue: String=game.GlobalCards.state_error(player)
	if not issue.is_empty(): return issue
	# The complete native BG35_921 program is fixed at +2/+1 per Tavern spell.
	# Match game.GlobalCards.projection's own numeric admission before the weighted draw.
	@warning_ignore("integer_division")
	var maximum: int=game.GlobalCards.MAX_COUNTER/2
	return "bulk_global_card_amount_overflow" if int(player[game.GlobalCards.STATE].tavern_spells)>maximum else ""
static func candidate_error(game,player: Dictionary,id: String) -> String:
	if id not in IDS: return ""
	var issue: String=""
	match id:
		"BG26_505": issue=game.Zesty.Sources.closure_error(game.catalog)
		"BG33_319": issue=game.StatSpellResources.Sources.closure_error(game.catalog)
		"BG34_925": issue=game.SeafloorCast.Sources.closure_error(game.catalog)
		"BG35_921":
			issue=game.GlobalCards.closure_error(game.catalog,id)
			if issue.is_empty(): issue=history_error(game,player)
		"BG36_508": issue=game.CageyCast.Sources.closure_error(game.catalog)
	return issue
static func comparison_view(game,player: Dictionary,unit: Dictionary) -> Dictionary:
	# A detached comparison view is not a minted actor or proof of acquisition.
	# The caller separately checks its complete source and original native shape.
	var id: String=str(unit.get("card_id",""))
	if id not in IDS: return {"ok":false,"error":"darkcrest_unknown_tier4_hand_identity"}
	if not player.get("id") is int or player.id<0 or player.id>=game.state.players.size() or not is_same(game.state.players[player.id],player): return {"ok":false,"error":"darkcrest_actual_tier4_hand_owner_required"}
	if not unit.get("uid") is String or unit.uid.is_empty(): return {"ok":false,"error":"darkcrest_hand_uid_required"}
	var copy: Dictionary=unit.duplicate(true)
	if id=="BG26_505":
		var issue: String=game.Zesty.Sources.unit_error(unit,int(game.state.round))
		if not issue.is_empty(): return {"ok":false,"error":issue}
		if unit[game.Zesty.Sources.STATE].used_round!=0: return {"ok":false,"error":"darkcrest_used_zesty_hand_held"}
		copy.erase(game.Zesty.Sources.STATE)
	if id=="BG35_921":
		var issue: String=history_error(game,player)
		if issue.is_empty(): issue=game.GlobalCards.unit_error(unit)
		if not issue.is_empty(): return {"ok":false,"error":issue}
		if not unit.has(game.GlobalCards.MARKER): return {"ok":false,"error":"darkcrest_abyssal_native_owner_layer_required"}
		var projected: Dictionary=game.GlobalCards.projection(player,unit,"hand")
		if not projected.ok: return projected
		if not Sources.same(projected.unit,unit): return {"ok":false,"error":"darkcrest_abyssal_owner_layer_not_current"}
		issue=game.GlobalCards.strip(copy)
		if not issue.is_empty(): return {"ok":false,"error":issue}
	return {"ok":true,"error":"","unit":copy}
