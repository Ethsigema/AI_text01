extends "res://tests/darkcrest_tier6_20261112/real_matrix.gd"
# New mixed-board tests only. No inherited Tier6 eight-case initializer is run.
const LAVA="BG23_009"
const CURRENT_TIER2=["BG23_002","BG23_009","BG31_924"]
var lava_cases=[]
var damage_records=[]
func live_snapshot() -> Dictionary:
 var result=super.live_snapshot()
 result.lava_pending=game._darkcrest_host._lava_play._pending.duplicate(true)
 result.lava_board=game._darkcrest_host._lava_play._board.duplicate(true)
 return result
func original_lava(lava: Dictionary,label: String) -> bool:
 var p=game.state.players[0]
 return must(p.board.any(func(u):return is_same(u,lava)) and lava.card_id==LAVA and lava.attack==2 and lava.health==5 and lava.max_health==5 and lava.spellcraft_kept==0 and not lava.golden and lava.temporary_buffs.is_empty(),label)
func public_lava_play(lava: Dictionary,position: int) -> bool:
 var p=game.state.players[0];var uid=game.next_uid;var pool=game.pool.duplicate(true);var rng=game.rng.state
 var host=game._darkcrest_host;var helper=host._lava_play;var before=live_snapshot()
 if not must(helper.preflight(host,game,p,lava).is_empty(),"actual_original_lava_preflight"):return false
 if not must(not helper.preflight(host,game,p,lava.duplicate(true)).is_empty(),"copied_lava_preflight_rejected"):return false
 if not must(not helper.preflight(host,game,game.state.players[1],lava).is_empty(),"wrong_owner_preflight_rejected"):return false
 if not must(not helper.begin(host,game,p,p.hand.find(lava),{}).is_empty(),"fabricated_live_play_context_rejected"):return false
 if not must(not helper.complete(host,game,p,{}).is_empty(),"no_live_completion_without_native_context"):return false
 if not must(game.Darkcrest.Sources.same(before,live_snapshot()),"preplay_rejections_preserve_all_live_state"):return false
 if not must(command(0,{"type":"play","index":p.hand.find(lava),"target":-1,"position":position}).get("ok",false),"public_original_lava_play_position_"+str(position)):return false
 if not original_lava(lava,"original_lava_object_unchanged_after_play"):return false
 before=live_snapshot()
 if not must(helper.board_error(host,game,p,lava).is_empty(),"actual_completed_original_lava_board_custody"):return false
 if not must(not helper.board_error(host,game,p,lava.duplicate(true)).is_empty(),"copied_board_lava_rejected"):return false
 if not must(not helper.board_error(host,game,game.state.players[1],lava).is_empty(),"wrong_owner_board_lava_rejected"):return false
 if not must(not helper.complete(host,game,p,{}).is_empty(),"completed_transaction_replay_rejected"):return false
 if not must(helper._pending.is_empty() and game.Darkcrest.Sources.same(before,live_snapshot()),"postplay_rejections_clear_and_preserve_live_state"):return false
 return must(not p.hand.any(func(u):return is_same(u,lava)) and is_same(p.board[position],lava) and game.next_uid==uid and game.rng.state==rng and game.Darkcrest.Sources.same(pool,game.pool),"lava_play_is_only_original_hand_to_board_no_birth_rng_or_stock")
func prepare_real_opponents() -> bool:
 # Done only AFTER the known original Tier2 draw; no pre-draw RNG alteration.
 for opponent in game.state.players:
  if opponent.id==0:continue
  var candidates=opponent.shop.filter(func(u):return u.get("tier")==1 and u.get("kind")=="minion")
  if not must(not candidates.is_empty() and opponent.gold>=3,"native_opponent_tier1_offer_and_gold_"+str(opponent.id)):return false
  var unit=candidates[0]
  if not must(command(opponent.id,{"type":"buy","index":opponent.shop.find(unit)}).get("ok",false),"opponent_public_buy_"+str(opponent.id)):return false
  if not must(command(opponent.id,{"type":"play","index":opponent.hand.find(unit),"target":-1,"position":-1}).get("ok",false) and opponent.board.has(unit),"opponent_public_nonempty_board_"+str(opponent.id)):return false
 return true
func inspect_lava_combat(lava: Dictionary) -> bool:
 var matches=game.last_combats.filter(func(r):return r.get("left_player")==0 or r.get("right_player")==0)
 if not must(matches.size()==1,"one_actual_player_combat"):return false
 var result=matches[0];var side="left" if result.left_player==0 else "right";var enemy="right" if side=="left" else "left"
 var starts=result.log.filter(func(e):return e.get("event")=="combat_start")
 if not must(result.get("error","")=="" and starts.size()==1 and not starts[0][enemy].is_empty(),"actual_nonempty_enemy_combat"):return false
 var copies=starts[0][side].filter(func(u):return u.get("uid")==lava.uid)
 if not must(copies.size()==1 and copies[0].attack==2 and copies[0].health==5,"combat_copy_starts_original_lava_stats"):return false
 var hits=result.log.filter(func(e):return e.get("event")=="damage" and e.get("target")==lava.uid and e.get("amount",0)>0)
 for hit in hits:damage_records.append({"round":game.state.round-1,"uid":lava.uid,"event":hit.duplicate(true)})
 return original_lava(lava,"next_recruit_original_lava_2_5_kept0_after_combat")
func obtain_generated_lava() -> Dictionary:
 if not setup_room(20261120):return {}
 var p=game.state.players[0];var parent=quick_parent()
 if parent.is_empty() or not source_play(parent) or not cast_level(parent,1) or not next_round(parent,2):return {}
 var domain=game.BulkResourceHost.domain(game)
 var choices=game.BulkResourceHost.candidates(domain,domain.stock,{"kind":"minion","tier":2,"tribe":"纳迦"})
 if not must(choices.map(func(c):return c.id)==CURRENT_TIER2 and choices.all(func(c):return c.stock>0),"complete_current_three_tier2_candidates_no_legacy"):return {}
 var hand_before=p.hand.map(func(u):return u.uid)
 if not cast_level(parent,2):return {}
 var added=p.hand.filter(func(u):return u.uid not in hand_before)
 if not must(added.size()==1 and added[0].card_id==LAVA,"actual_full_domain_tier2_draw_is_lava_known_seed"):return {}
 return {"parent":parent,"lava":added[0],"choices":choices}
func generated_case(front: bool) -> bool:
 var data=obtain_generated_lava()
 if data.is_empty():return false
 var parent=data.parent;var lava=data.lava;var p=game.state.players[0];var start_damage=damage_records.size()
 if not public_lava_play(lava,0 if front else 1):return false
 if not front:
  if not must(command(0,{"type":"move","from":p.board.find(lava),"to":0}).get("ok",false) and p.board.find(lava)==0 and p.board.find(parent)==1,"public_move_updates_real_source_index"):return false
 if not prepare_real_opponents():return false
 var index_before=p.board.find(parent)
 if not next_round(parent,3) or not inspect_lava_combat(lava):return false
 if not must(index_before==1 and p.board.find(parent)==1 and game._darkcrest_host._parents[parent.uid].tier==3,"eot_uses_dynamic_nonzero_darkcrest_index"):return false
 if front:
  for tier in [3,4,5]:
   if tier<5:
    if not cast_level(parent,tier):return false
   elif cast_tier5(parent,20261120).is_empty():return false
   if not next_round(parent,tier+1) or not inspect_lava_combat(lava):return false
  if not prepare_native_weights():return false
  if cast_tier6(parent,20261120).is_empty():return false
  var before=held_snapshot();var held=game.apply_command(0,{"type":"end_turn"})
  if not must(not held.get("ok",true) and held.error=="darkcrest_next_tier_outside_finite_candidate" and game.Darkcrest.Sources.same(before,held_snapshot()),"mixed_post6_eot_remains_held"):return false
  if not must(damage_records.size()>start_damage,"actual_lava_combat_damage_observed_without_recruit_mutation"):return false
 else:
  if not must(command(0,{"type":"move","from":p.board.find(parent),"to":0}).get("ok",false) and p.board.find(parent)==0,"public_move_back_updates_source_index_again"):return false
  if not next_round(parent,4) or not inspect_lava_combat(lava):return false
 var row={"kind":"generated_front_to6" if front else "generated_back_then_moves","seed":20261120,"source_uid":parent.uid,"lava_uid":lava.uid,"final_round":game.state.round,"source_tier":game._darkcrest_host._parents[parent.uid].tier,"final_board_uids":p.board.map(func(u):return u.uid),"lava_damage_events":damage_records.size()-start_damage,"tier2_choices":data.choices}
 lava_cases.append(row);print("DARKCREST_LAVA_CASE_PASS ",JSON.stringify(row));return true
func shop_lava_two_sources() -> bool:
 if not setup_room(20261220):return false
 var p=game.state.players[0];var lava={}
 for attempt in range(100):
  var offers=p.shop.filter(func(u):return u.card_id==LAVA)
  if not offers.is_empty():
   if not fund(10):return false
   lava=offers[0]
   if not must(command(0,{"type":"buy","index":p.shop.find(lava)}).get("ok",false),"original_shop_lava_purchase"):return false
   break
  if not fund(10) or not command(0,{"type":"roll"}).get("ok",false):return false
 if not must(not lava.is_empty(),"native_shop_lava_found_before_darkcrest_owned"):return false
 var parents=buy_two_parents()
 if not must(parents.size()==2,"two_native_shop_sources_with_unplayed_lava"):return false
 if not source_play(parents[0]) or not next_round(parents[0],2):return false
 if not public_lava_play(lava,1) or not source_play(parents[1]):return false
 if not must(p.board.map(func(u):return u.uid)==[parents[0].uid,lava.uid,parents[1].uid],"two_sources_straddle_lava_at_real_indices_0_2"):return false
 var round_before=game.state.round
 if not next_round(parents[0],3):return false
 var second_events=game.events.filter(func(e):return e.get("type")=="darkcrest_tier_upgraded" and e.get("source_uid")==parents[1].uid and e.get("round")==round_before)
 if not must(second_events.size()==1 and second_events[0].before==1 and second_events[0].after==2,"second_source_actual_eot_one_to_two"):return false
 for index in range(2):
  var source=parents[index];var expected=3 if index==0 else 2
  var tokens=p.hand.filter(func(u):return u.card_id=="BG31_920t" and game._darkcrest_host._spells[u.uid].source_uid==source.uid)
  if not must(tokens.size()==1 and game._darkcrest_host._spells[tokens[0].uid].tier==expected,"each_real_source_has_own_new_grant_"+str(index)):return false
 if not original_lava(lava,"two_source_eot_preserves_original_lava"):return false
 var row={"kind":"shop_lava_two_sources","seed":20261220,"lava_uid":lava.uid,"source_uids":parents.map(func(u):return u.uid),"source_tiers":[3,2],"actual_board_indices":[0,2],"final_round":game.state.round}
 lava_cases.append(row);print("DARKCREST_LAVA_CASE_PASS ",JSON.stringify(row));return true
func _initialize():
 print("DARKCREST_LAVA_MATRIX_LOAD_BEGIN")
 var Game=load("res://core/game.gd")
 if not must(Game!=null and Game.can_instantiate(),"complete_game_script"):return
 cat=load("res://core/catalog.gd").new();cat.load_catalog()
 if not must(cat.load_errors.is_empty(),"complete_catalog"):return
 if not generated_case(true) or not generated_case(false) or not shop_lava_two_sources():return
 var result={"scope":"ordinary Darkcrest plus one untouched ordinary Lava hand-to-board and real EOT index compatibility only","checks":checks,"cases":lava_cases,"combat_damage":damage_records,"tier6_casts":tier6_records,"old_tier6_eight_case_matrix_repeated":false,"permanent_enchantment_opened":false,"no_live_state_injection":true}
 var file=FileAccess.open(get_script().resource_path.get_base_dir()+"/DARKCREST_LAVA_MATRIX_RESULT.json",FileAccess.WRITE)
 if not must(file!=null,"matrix_result_file"):return
 file.store_string(JSON.stringify(result,"  ")+"\n");file.close()
 print("DARKCREST_LAVA_REAL_MATRIX_PASS cases=",lava_cases.size()," checks=",checks)
 quit(0)
