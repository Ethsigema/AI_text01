extends "res://tests/darkcrest_20261112/hand_shape_contract.gd"
# Detached shape/custody rejection fixtures only, not actual play or birth proof.
const LavaPlay=preload("res://core/darkcrest_lava_play.gd")
const LimitedTurn=preload("res://core/limited_turn_state.gd")
class FakeCatalog:
 extends RefCounted
 var card: Dictionary={}
 func get_card(id: String) -> Dictionary:
  return card if id=="BG23_009" else {}
class PretendHost:
 extends RefCounted
 var _lava_play
 static func actual(_game) -> bool:
  return true
class PretendGame:
 extends RefCounted
 var _darkcrest_host
 var state: Dictionary={"players":[],"ghosts":[],"round":2,"phase":"recruit","command_sequence":7}
 var _darkcrest_lava_play_context: Dictionary={}
 var _darkcrest_lava_play_nonce: RefCounted
func _initialize() -> void:
 check(Sources.proof_error().is_empty(),"complete_new_source_and_runtime_proof")
 var host=Host.new();var helper=LavaPlay.new();var catalog=FakeCatalog.new()
 catalog.card=Sources.EXPECTED_HAND["BG23_009"].duplicate(true)
 var unit=fixture(catalog.card,true)
 var game_fixture={"catalog":catalog,"Rider":{"UNIT_FIELDS":Rider.UNIT_FIELDS},"LimitedTurn":LimitedTurn,"state":{"round":2,"phase":"recruit","players":[],"ghosts":[]}}
 check(LavaPlay.ID=="BG23_009","ordinary_lava_only_identity")
 check(LavaPlay.shape_error(host,game_fixture,unit).is_empty(),"pure_original_2_5_kept0_shape")
 check(unit.attack==2 and unit.health==5 and unit.max_health==5 and unit.spellcraft_kept==0,"shape_has_no_enchantment")
 var shop_shape=fixture(catalog.card,false)
 check(LavaPlay.shape_error(host,game_fixture,shop_shape).is_empty(),"ordinary_shop_shape_without_pool_kind_allowed")
 for field in unit:
  if field=="pool_kind":continue
  var bad=unit.duplicate(true);bad.erase(field)
  check(not LavaPlay.shape_error(host,game_fixture,bad).is_empty(),"missing_native_field_"+field)
 for field in ["attack","health","max_health","spellcraft_kept"]:
  for value in [0,1,9,2.0,5.0,"2",null]:
   if value is int and value==unit[field]:continue
   var bad=unit.duplicate(true);bad[field]=value;var before=bad.duplicate(true)
   check(not LavaPlay.shape_error(host,game_fixture,bad).is_empty(),"changed_strict_field_"+field+str(value))
   check(Sources.same(before,bad),"shape_check_read_only")
 for field in ["effects","keywords","tribes","temporary_buffs","attachments","pool_components"]:
  for value in [null,7,{},[{}]]:
   var bad=unit.duplicate(true);bad[field]=value
   check(not LavaPlay.shape_error(host,game_fixture,bad).is_empty(),"changed_array_"+field+str(value))
 for field in ["golden","temporary","is_spellcraft","silenced","abilities_disabled","_pending_destroy"]:
  var bad=unit.duplicate(true);bad[field]=true
  check(not LavaPlay.shape_error(host,game_fixture,bad).is_empty(),"forbidden_true_flag_"+field)
 for field in ["silenced","abilities_disabled","_pending_destroy"]:
  var valid=unit.duplicate(true);valid[field]=false
  check(LavaPlay.shape_error(host,game_fixture,valid).is_empty(),"native_false_disable_field_allowed_"+field)
 for field in ["bulk_global_card_applied","limited_turn_merge_blocked_round","native_fixed_dark_gift_receipt","source_uid","kept_spellcraft","turn_history","native_play_receipt"]:
  var bad=unit.duplicate(true);bad[field]={"forged":true}
  check(not LavaPlay.shape_error(host,game_fixture,bad).is_empty(),"foreign_marker_"+field)
 var bad=unit.duplicate(true);bad.base_unit.attack+=1
 check(not LavaPlay.shape_error(host,game_fixture,bad).is_empty(),"changed_native_base")
 bad=unit.duplicate(true);bad.effects.append({"type":"end_turn","effects":[]})
 check(not LavaPlay.shape_error(host,game_fixture,bad).is_empty(),"lava_cannot_add_eot_program")
 bad=unit.duplicate(true);bad.card_id="BG23_009_G"
 check(not LavaPlay.shape_error(host,game_fixture,bad).is_empty(),"golden_lava_identity_held")
 var owner={"id":0,"board":[],"hand":[unit],"shop":[]};game_fixture.state.players=[owner]
 check(LavaPlay._unique(game_fixture,unit),"detached_single_original_occurrence")
 owner.board.append(unit.duplicate(true))
 check(not LavaPlay._unique(game_fixture,unit),"equal_uid_copy_in_another_zone_rejected")
 owner.board=[];game_fixture.state.ghosts=[{"board":[unit],"hand":[],"shop":[]}]
 check(not LavaPlay._unique(game_fixture,unit),"ghost_duplicate_counted")
 game_fixture.state.ghosts=[]
 var before=[owner.duplicate(true),game_fixture.state.duplicate(true)]
 check(not helper.preflight(host,game_fixture,owner,unit).is_empty(),"dictionary_fixture_never_authorizes_original_play")
 check(not helper.begin(host,game_fixture,owner,0,{}).is_empty(),"no_fabricated_context_authority")
 check(not helper.complete(host,game_fixture,owner,{}).is_empty(),"completion_without_issued_window_rejected")
 check(not helper.board_error(host,game_fixture,owner,unit).is_empty(),"shape_does_not_grant_board_custody")
 check(Sources.same(before,[owner,game_fixture.state]),"all_authority_rejections_read_only")
 check(helper._pending.is_empty() and helper._board.is_empty(),"rejections_create_no_receipt_or_custody")
 helper._pending={"fixture":"untrusted"};helper.cancel()
 check(helper._pending.is_empty() and helper._board.is_empty(),"cancel_only_clears_transient_fixture")
 check(not helper.complete(host,game_fixture,owner,{}).is_empty(),"cancel_does_not_grant_completion")
 # The pure predicate observes eight fields but grants no actual play authority.
 var nonce=RefCounted.new()
 var context={"origin":"actual_hand_play","owner":owner,"unit":unit,"index":0,"position":-1,"round":2,"sequence":7,"nonce":nonce}
 check(LavaPlay._context_matches(context,owner,unit,0,-1,2,7,nonce),"pure_exact_eight_field_context")
 check(LavaPlay._context_matches(context.duplicate(false),owner,unit,0,-1,2,7,nonce),"pure_shallow_shape_is_not_context_identity_authority")
 for field in context:
  var missing=context.duplicate(false);missing.erase(field)
  check(not LavaPlay._context_matches(missing,owner,unit,0,-1,2,7,nonce),"missing_context_field_"+field)
 for field in ["receipt","position_normalized","used"]:
  var added=context.duplicate(false);added[field]=false
  check(not LavaPlay._context_matches(added,owner,unit,0,-1,2,7,nonce),"extra_context_field_"+field)
 for field in ["index","position","round","sequence"]:
  var original=context[field]
  for value in [float(original),str(original),null,true,int(original)+1]:
   # Mutate this detached same dictionary, never an actual Game context.
   context[field]=value
   check(not LavaPlay._context_matches(context,owner,unit,0,-1,2,7,nonce),"same_detached_context_changed_"+field+str(value))
   context[field]=original
  check(LavaPlay._context_matches(context,owner,unit,0,-1,2,7,nonce),"restored_detached_context_"+field)
 for value in ["forged","",0,null]:
  context.origin=value
  check(not LavaPlay._context_matches(context,owner,unit,0,-1,2,7,nonce),"changed_context_origin_"+str(value))
 context.origin="actual_hand_play"
 context.owner=owner.duplicate(true)
 check(not LavaPlay._context_matches(context,owner,unit,0,-1,2,7,nonce),"copied_context_owner_not_original")
 context.owner=owner;context.unit=unit.duplicate(true)
 check(not LavaPlay._context_matches(context,owner,unit,0,-1,2,7,nonce),"copied_context_unit_not_original")
 context.unit=unit;context.nonce=RefCounted.new()
 check(not LavaPlay._context_matches(context,owner,unit,0,-1,2,7,nonce),"replaced_context_nonce")
 context.nonce=nonce
 check(not LavaPlay._context_matches(context,owner,unit,0,0,2,7,nonce),"raw_requested_position_not_normalized_position")
 var pretend_host=PretendHost.new();pretend_host._lava_play=helper
 var pretend_game=PretendGame.new();pretend_game._darkcrest_host=pretend_host;pretend_game.state.players=[owner]
 pretend_game._darkcrest_lava_play_nonce=nonce;pretend_game._darkcrest_lava_play_context=context
 var dictionary_game={"state":pretend_game.state,"_darkcrest_host":pretend_host,"_darkcrest_lava_play_nonce":nonce,"_darkcrest_lava_play_context":context}
 check(PretendHost.actual(pretend_game),"pretend_host_deliberately_claims_actual_true")
 for counterfeit in [pretend_game,dictionary_game]:
  check(not helper._actual(pretend_host,counterfeit,owner),"fake_script_or_dictionary_never_actual")
  check(not helper.preflight(pretend_host,counterfeit,owner,unit).is_empty(),"fake_actual_true_cannot_preflight")
  check(not helper.begin(pretend_host,counterfeit,owner,0,context).is_empty(),"fake_actual_true_cannot_issue_transaction")
  check(helper._pending.is_empty() and helper._board.is_empty(),"fake_begin_leaves_no_custody")
  helper._pending={"detached_untrusted":true}
  check(not helper.complete(pretend_host,counterfeit,owner,context).is_empty(),"fake_actual_true_cannot_complete")
  check(helper._pending=={"detached_untrusted":true} and helper._board.is_empty(),"fake_complete_no_state_write")
  helper.cancel()
  check(not helper.board_error(pretend_host,counterfeit,owner,unit).is_empty(),"fake_actual_true_cannot_claim_board")
 check(not helper.complete(host,game_fixture,owner,context).is_empty(),"pure_matching_context_never_grants_completion")
 # Pure identity observations; actual EOT program-index behavior is exercised by real matrix.
 var first={"uid":"a"};var lava={"uid":"l"};var second={"uid":"b"}
 check(Host.Generation._same_objects([first,lava,second],[first,lava,second]),"same_full_board_object_order")
 check(not Host.Generation._same_objects([first,lava,second],[first,second,lava]),"full_board_reorder_not_same_snapshot")
 check(not Host.Generation._same_objects([first,lava,second],[first,second]),"omitted_lava_not_same_snapshot")
 check(not Host.Generation._same_objects([first,lava,second],[first,lava,second.duplicate(true)]),"copied_source_not_original_object")
 print("DARKCREST_LAVA_CONTENT_CONTRACT ",JSON.stringify({"passed":passed,"failed":failed,"failures":failures,"real_game_run":false,"scope":"detached untouched Lava shape and custody rejection contracts, not native play or birth provenance"}))
 quit(0 if failed==0 else 1)
