extends SceneTree
const Host=preload("res://core/shatterer_host.gd")
var passed=0
var failed=0
func check(value: bool,label: String) -> void:
 if value: passed+=1
 else: failed+=1
 print("PASS " if value else "FAIL ",label)
func body(layers: Variant) -> Dictionary:
 return {"attack":20,"health":16,"max_health":16,"temporary_buffs":layers}
func _initialize() -> void:
 check(Host.temporary_layer_error(body([])).is_empty(),"empty_native_layers")
 check(Host.temporary_layer_error(body([{"attack":2,"health":0,"keywords":[]}])).is_empty(),"native_trident_layer")
 check(Host.temporary_layer_error(body([{"attack":2,"health":3,"keywords":[]},{"attack":4,"health":2,"keywords":[]}])).is_empty(),"additive_layer_sum")
 for layers in [null,{},false,1,[null],[{}],[{"attack":2,"health":0}],[{"attack":2,"health":0,"keywords":[],"marker":true}],[{"attack":-1,"health":0,"keywords":[]}],[{"attack":2,"health":-1,"keywords":[]}],[{"attack":2.0,"health":0,"keywords":[]}],[{"attack":true,"health":0,"keywords":[]}],[{"attack":2,"health":0,"keywords":""}],[{"attack":2,"health":0,"keywords":["windfury"]}],[{"attack":21,"health":0,"keywords":[]}],[{"attack":0,"health":16,"keywords":[]}],[{"attack":9223372036854775807,"health":0,"keywords":[]},{"attack":1,"health":0,"keywords":[]}]]:
  check(not Host.temporary_layer_error(body(layers)).is_empty(),"reject_malformed_"+str(passed+failed))
 for key in ["attack","health","max_health"]:
  var unit=body([{"attack":2,"health":0,"keywords":[]}]);unit[key]=1.5
  check(not Host.temporary_layer_error(unit).is_empty(),"reject_noninteger_body_"+key)
 var invalid=body([{"attack":2,"health":0,"keywords":[]}]);invalid.health=17
 check(not Host.temporary_layer_error(invalid).is_empty(),"reject_health_above_max")
 check(Host.temporary_layer_error(body([{"attack":9223372036854775807,"health":0,"keywords":[]},{"attack":1,"health":0,"keywords":[]}]))=="shatterer_temporary_layer_overflow","attack_sum_overflow_exact_error")
 check(Host.temporary_layer_error(body([{"attack":0,"health":9223372036854775807,"keywords":[]},{"attack":0,"health":1,"keywords":[]}]))=="shatterer_temporary_layer_overflow","health_sum_overflow_exact_error")
 var boundary={"attack":9223372036854775807,"health":9223372036854775807,"max_health":9223372036854775807,"temporary_buffs":[{"attack":9223372036854775807,"health":9223372036854775806,"keywords":[]}]}
 check(Host.temporary_layer_error(boundary).is_empty(),"max_safe_native_expiry_boundary")
 boundary.temporary_buffs[0].health=9223372036854775807
 check(Host.temporary_layer_error(boundary)=="shatterer_invalid_temporary_base","positive_health_remaining_required")
 print("RESULT passed=",passed," failed=",failed)
 quit(0 if failed==0 else 1)
