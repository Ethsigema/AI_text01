# Shatterer isolated candidate regression tests

Run with Godot 4.6.3 from the restored project. The full test loads the original Game/Catalog, starts a restricted Edwin room, obtains fixture cards through the original factory and hand-delivery function, and uses public commands for every play, cast, sale and turn end. It does not seed the spell counter, replace _buff, or modify the board directly. Random shop acquisition, goldens via triples, unrestricted rooms, all combinations and old saves remain unverified.

    godot --headless --path /path/to/project --script /path/to/project/tests/shatterer_20261112/temporary_contract.gd
    godot --headless --path /path/to/project --script /path/to/project/tests/shatterer_20261112/threshold_and_expiry.gd

For bounded resource use, extract the accompanying evidence archive and run its monitor.py with the corresponding test name, a 240 second timeout, and the restored project path. The recorded full test took 159.29 seconds and sampled approximately 3.02 GB process-group RSS. The monitor's RSS limit is sampled, not a hard operating-system cap.

Threshold assertions use actual casts of six Tavern Coins. Mini-Myrmidon grants a Mini-Trident through native spellcraft delivery; its actual cast supplies the temporary +2 Attack layer. The normal and golden Shatterers receive permanent +3/+3 and +6/+6 when the next Naga is played. End Turn executes one real combat round and returns to recruit round 2. The native temporary-layer expiry removes only the +2 Attack, retaining permanent growth.

The companion contract test checks malformed, noninteger, keyword-bearing, extra-field and overflowing layers. Accepted layers are bounded additive nonnegative integer stat layers without keywords or extra metadata. This intentionally excludes broader temporary mechanisms and float-coerced legacy state.
