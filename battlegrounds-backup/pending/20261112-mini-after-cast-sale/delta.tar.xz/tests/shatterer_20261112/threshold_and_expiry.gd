extends SceneTree
var game
var cat
var p
var normal
var golden
func ensure(condition: bool, label: String) -> bool:
 if not condition:
  print("FAIL ",label," phase=",game.state.get("phase","") if game!=null else "")
  quit(1)
  return false
 print("PASS ",label)
 return true
func native(id: String) -> Dictionary:
 var card=cat.get_card(id)
 if card.is_empty():
  print("NO_CARD ",id)
  return {}
 var u=game._unit(card)
 game._add_hand(p,u)
 return u
func play(u: Dictionary,target: int=-1) -> Dictionary:
 if u.is_empty(): return {"ok":false,"error":"empty_fixture"}
 var c={"type":"play","index":p.hand.find(u),"target":target,"position":-1}
 var outcome=game.apply_command(0,c)
 print("COMMAND ",u.card_id," ",JSON.stringify(outcome)," spells=",p.stats.spells)
 return outcome
func stats(n: int,g: int,label: String) -> bool:
 print("STATS ",JSON.stringify([normal.attack,normal.health,normal.max_health,golden.attack,golden.health,golden.max_health]))
 return ensure(normal.attack==n and normal.health==n-2 and normal.max_health==n-2 and golden.attack==g and golden.health==g-4 and golden.max_health==g-4,label)
func _initialize() -> void:
 print("LOAD_BEGIN")
 game=load("res://core/game.gd").new()
 cat=load("res://core/catalog.gd").new()
 cat.load_catalog()
 if not ensure(cat.load_errors.is_empty(),"catalog"): return
 var room=load("res://core/room_config.gd").new()
 room.reset(cat)
 room.data.enabled_minions=["BG31_035","BG23_000","BG23_007"]
 room.data.enabled_spells=["BG28_810"]
 room.data.selected_hero="TB_BaconShop_HERO_01"
 room.data.enabled_heroes=["TB_BaconShop_HERO_01"]
 for key in ["enabled_anomalies","enabled_quests","enabled_rewards","enabled_trinkets"]: room.data[key]=[]
 var start=game.start(room.data,cat)
 print("START ",JSON.stringify(start))
 if not ensure(start.get("ok",false),"start"): return
 p=game.state.players[0]
 normal=native("BG31_035")
 if not ensure(play(normal).get("ok",false),"normal_play"): return
 golden=native("BG31_035_G")
 if not ensure(play(golden).get("ok",false),"golden_play"): return
 if not stats(7,12,"initial_no_self_trigger"): return
 var expected_normal=7
 var expected_golden=12
 for number in range(1,7):
  var coin=native("BG28_810")
  var old_normal=normal.duplicate(true)
  var old_golden=golden.duplicate(true)
  if not ensure(play(coin).get("ok",false),"cast_coin_"+str(number)): return
  if not ensure(p.stats.spells==number,"real_counter_"+str(number)): return
  if not ensure(normal==old_normal and golden==old_golden,"spell_does_not_directly_buff_shatterer_"+str(number)): return
  if number in [2,3,5,6]:
   var mini=native("BG23_000")
   if not ensure(play(mini).get("ok",false),"naga_after_"+str(number)): return
   var amount=1+int(number/3)
   expected_normal+=amount
   expected_golden+=2*amount
   if not stats(expected_normal,expected_golden,"threshold_"+str(number)): return
   var sold=game.apply_command(0,{"type":"sell","index":p.board.find(mini)})
   print("SELL ",JSON.stringify(sold))
   if not ensure(sold.get("ok",false),"sell_fixture_without_mutating_board"): return
 var spells=p.hand.filter(func(u):return u.card_id=="BG23_000t")
 if not ensure(not spells.is_empty(),"native_spellcraft_delivered"): return
 var cast=play(spells[0],p.board.find(normal))
 if not ensure(cast.get("ok",false) and p.stats.spells==7,"actual_spellcraft_cast"): return
 print("TEMPORARY_AFTER_CAST ",JSON.stringify(normal.temporary_buffs))
 var mini=native("BG23_000")
 var before=JSON.stringify(p)
 var after_temp=play(mini)
 print("AFTER_TEMPORARY_LAYER ",JSON.stringify(after_temp))
 if not ensure(after_temp.get("ok",false),"play_after_native_spellcraft_layer"): return
 if not ensure(normal.attack==20 and normal.health==16 and normal.max_health==16 and golden.attack==34 and golden.health==30,"temporary_layer_and_permanent_growth_coexist"): return
 if not ensure(normal.temporary_buffs==[{"attack":2,"health":0,"keywords":[]}],"permanent_growth_not_folded_into_temporary_layer"): return
 var round_before=game.state.round
 var end=game.apply_command(0,{"type":"end_turn"})
 print("END_TURN ",JSON.stringify(end)," round=",game.state.round," phase=",game.state.phase)
 if not ensure(end.get("ok",false),"real_end_turn"): return
 if not ensure(game.state.round==round_before+1 and game.state.phase=="recruit","real_combat_and_next_recruit"): return
 if not ensure(normal.attack==18 and normal.health==16 and normal.max_health==16 and normal.temporary_buffs.is_empty(),"native_expiry_preserves_permanent_growth"): return
 if not ensure(golden.attack==34 and golden.health==30 and golden.max_health==30,"golden_growth_survives_round"): return
 print("PASS_THRESHOLD_MATRIX_WITH_ACTUAL_CASTS_AND_NATIVE_EXPIRY")
 quit(0)
