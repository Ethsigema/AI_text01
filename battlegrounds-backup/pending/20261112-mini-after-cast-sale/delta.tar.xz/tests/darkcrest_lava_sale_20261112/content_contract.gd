extends "res://tests/darkcrest_lava_20261112/content_contract.gd"
# Detached observations only. Never forge a successful live sale transaction.
func _initialize() -> void:
 check(Sources.proof_error().is_empty(),"complete_new_source_and_runtime_proof")
 var host=Host.new();var helper=LavaPlay.new()
 var p={"id":0,"board":[],"hand":[],"shop":[]}
 var u={"uid":"u23","card_id":"BG23_009"}
 var plan={"ok":true,"error":"","active":false};var plan_values=plan.duplicate(true)
 var context={"owner":p,"sold":u,"sold_uid":"u23","index":1,"sales_before":3,"round":4,"sequence":17,"generated_tier7_plan":plan}
 check(LavaPlay._sale_context_matches(context,p,u,"u23",1,3,4,17,plan,plan_values),"detached_exact_eight_field_sale_shape")
 check(LavaPlay._sale_context_matches(context.duplicate(false),p,u,"u23",1,3,4,17,plan,plan_values),"shallow_same_refs_shape_is_not_authority")
 for field in context.keys():
  var missing=context.duplicate(false);missing.erase(field)
  check(not LavaPlay._sale_context_matches(missing,p,u,"u23",1,3,4,17,plan,plan_values),"missing_"+field)
 for field in ["nonce","origin","retired","receipt"]:
  var extra=context.duplicate(false);extra[field]=true
  check(not LavaPlay._sale_context_matches(extra,p,u,"u23",1,3,4,17,plan,plan_values),"extra_"+field)
 for field in ["index","sales_before","round","sequence"]:
  var original=context[field]
  for value in [null,true,str(original),float(original),original+1,-1]:
   context[field]=value
   check(not LavaPlay._sale_context_matches(context,p,u,"u23",1,3,4,17,plan,plan_values),"same_context_strict_integer_"+field+str(value))
  context[field]=original
 for value in [null,23,true,"u24"]:
  context.sold_uid=value
  check(not LavaPlay._sale_context_matches(context,p,u,"u23",1,3,4,17,plan,plan_values),"changed_captured_uid_"+str(value))
 context.sold_uid="u23"
 for field in ["owner","sold","generated_tier7_plan"]:
  var original=context[field];context[field]=original.duplicate(true)
  check(not LavaPlay._sale_context_matches(context,p,u,"u23",1,3,4,17,plan,plan_values),"equal_copy_reference_rejected_"+field)
  context[field]=original
 for field in plan.keys():
  var original=plan[field];plan[field]="corrupt"
  check(not LavaPlay._sale_context_matches(context,p,u,"u23",1,3,4,17,plan,plan_values),"same_plan_ref_deep_mutation_"+field)
  plan[field]=original
 plan["injected"]=true
 check(not LavaPlay._sale_context_matches(context,p,u,"u23",1,3,4,17,plan,plan_values),"plan_extra_deep_value_rejected")
 plan.erase("injected")
 check(LavaPlay._sale_context_matches(context,p,u,"u23",1,3,4,17,plan,plan_values),"detached_restored_shape_only")
 # Strict inventory content predicates: no native receipt or authority issuance.
 var stock={"BG23_009":4,"other":7};var expected=stock.duplicate(true);expected["BG23_009"]+=1
 check(LavaPlay._sale_inventory_valid(stock),"strict_nonnegative_integer_inventory")
 check(LavaPlay._sale_inventory_valid({}),"empty_spell_inventory_content_valid")
 check(LavaPlay._sale_inventory_valid({"zero":0}),"zero_stock_content_valid")
 check(LavaPlay._sale_inventory_matches(expected,expected.duplicate(true)),"same_exact_inventory_content")
 check(not LavaPlay._sale_inventory_matches(stock,expected),"unchanged_stock_not_expected_lava_plus_one")
 for invalid in [null,[],0,1.0,true,"stock"]:
  check(not LavaPlay._sale_inventory_valid(invalid),"non_dictionary_inventory_rejected_"+str(invalid))
  check(not LavaPlay._sale_inventory_matches(invalid,stock),"invalid_actual_inventory_rejected")
  check(not LavaPlay._sale_inventory_matches(stock,invalid),"invalid_expected_inventory_rejected")
 for value in [4.0,5.0,true,false,-1,-1.0,"4",null,{},[]]:
  var corrupt=stock.duplicate(true);corrupt["BG23_009"]=value
  check(not LavaPlay._sale_inventory_valid(corrupt),"invalid_strict_stock_value_"+str(value))
  check(not LavaPlay._sale_inventory_matches(corrupt,stock),"invalid_actual_stock_value")
  check(not LavaPlay._sale_inventory_matches(stock,corrupt),"invalid_expected_stock_value")
 for key in [1,1.0,true,null]:
  var corrupt=stock.duplicate(true);corrupt[key]=1
  check(not LavaPlay._sale_inventory_valid(corrupt),"non_string_inventory_key_rejected_"+str(key))
  check(not LavaPlay._sale_inventory_matches(corrupt,corrupt),"invalid_matching_key_types_still_rejected")
 var missing=expected.duplicate(true);missing.erase("other")
 var extra=expected.duplicate(true);extra["extra"]=0
 var renamed={"BG23_009":5,"renamed":7}
 for corrupt in [missing,extra,renamed]:
  check(not LavaPlay._sale_inventory_matches(corrupt,expected),"different_key_set_rejected")
  check(not LavaPlay._sale_inventory_matches(expected,corrupt),"different_expected_key_set_rejected")
 for delta in [-1,0,2]:
  var corrupt=stock.duplicate(true);corrupt["BG23_009"]+=delta
  check(not LavaPlay._sale_inventory_matches(corrupt,expected),"only_exact_lava_plus_one_matches_"+str(delta))
 var other_change=expected.duplicate(true);other_change.other+=1
 check(not LavaPlay._sale_inventory_matches(other_change,expected),"other_stock_cannot_change_alongside_lava")
 var spell_pool={"spell":3}
 check(LavaPlay._sale_inventory_matches(spell_pool,spell_pool.duplicate(true)),"spell_stock_must_remain_exact")
 check(not LavaPlay._sale_inventory_matches({"spell":4},spell_pool),"spell_stock_increment_rejected")
 check(not LavaPlay._sale_inventory_matches({"spell":3.0},spell_pool),"spell_stock_equal_float_rejected")
 check(Sources.same(stock,{"BG23_009":4,"other":7}) and Sources.same(expected,{"BG23_009":5,"other":7}),"inventory_predicates_do_not_write_fixture")
 check(LavaPlay.RETIRED_LIMIT==128,"declared_retired_bound_128_not_live_capacity_proof")
 var pretend_host=PretendHost.new();pretend_host._lava_play=helper
 var pretend_game=PretendGame.new();pretend_game._darkcrest_host=pretend_host
 var fake_dict={"_darkcrest_host":pretend_host,"state":{"players":[p],"phase":"recruit","round":4,"command_sequence":17},"_native_sale_operation_context":context}
 for fake_game in [pretend_game,fake_dict]:
  var before=[p.duplicate(true),u.duplicate(true),context.duplicate(true)]
  check(not helper.sale_preflight(pretend_host,fake_game,p,u).is_empty(),"fake_actual_true_sale_preflight_denied")
  check(not helper.begin_sale(pretend_host,fake_game,p,0,context).is_empty(),"fake_actual_true_sale_begin_denied")
  check(not helper.finish_sale(pretend_host,fake_game,p,context,{"ok":true}).is_empty(),"fake_actual_true_unbound_completion_denied")
  check(Sources.same(before,[p.duplicate(true),u.duplicate(true),context.duplicate(true)]),"fake_calls_no_fixture_writes")
  check(helper._sale_pending.is_empty() and helper._pending.is_empty() and helper._retired.is_empty() and helper._board.is_empty(),"fake_calls_issue_no_authority_or_retirement")
 # Retired records below are detached pure fixtures, not live capacity or cleanup proof.
 for i in range(128):helper._retired["detached"+str(i)]={"owner":0,"round":4,"sequence":i}
 var records=helper._retired.duplicate(true)
 check(not helper.sale_preflight(host,fake_dict,p,u).is_empty(),"fake_capacity_fixture_still_has_no_authority")
 check(not helper.finish_sale(host,fake_dict,p,context,{"ok":false,"error":"fixture"}).is_empty(),"fake_native_error_no_retirement_authority")
 check(Sources.same(records,helper._retired) and helper._retired.size()==128,"detached_failed_calls_do_not_evict_records")
 print("DARKCREST_LAVA_SALE_CONTENT_CONTRACT ",JSON.stringify({"passed":passed,"failed":failed,"failures":failures,"real_game_run":false,"live_capacity_tested":false,"partial_failure_live_injection":false,"scope":"detached sale context and authority rejection observations only"}))
 quit(0 if failed==0 else 1)
