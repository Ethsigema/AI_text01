extends "res://tests/darkcrest_lava_20261112/real_matrix.gd"
# New sale cases only. No inherited initializer runs.
# Never invoke inherited three-case initializer.
var sale_cases=[]
var sale_effects=[]
func absent_from_all_zones(unit: Dictionary) -> bool:
 for owner in game.state.players+game.state.ghosts:
  for zone in ["board","hand","shop"]:
   for entry in owner.get(zone,[]):
    if is_same(entry,unit) or entry.get("uid")==unit.uid:return false
 return true
func live_snapshot() -> Dictionary:
 var result=super.live_snapshot()
 result.lava_sale_pending=game._darkcrest_host._lava_play._sale_pending.duplicate(true)
 result.lava_retired=game._darkcrest_host._lava_play._retired.duplicate(true)
 return result
func sale_authority_rejections(unit: Dictionary) -> bool:
 var p=game.state.players[0];var host=game._darkcrest_host;var helper=host._lava_play;var before=live_snapshot()
 if not must(helper.sale_preflight(host,game,p,unit).is_empty(),"original_completed_lava_sale_preflight"):return false
 if not must(not helper.sale_preflight(host,game,p,unit.duplicate(true)).is_empty(),"copied_sale_unit_rejected"):return false
 if not must(not helper.sale_preflight(host,game,game.state.players[1],unit).is_empty(),"wrong_sale_owner_rejected"):return false
 if not must(not helper.begin_sale(host,game,p,p.board.find(unit),{}).is_empty(),"unbound_sale_context_rejected"):return false
 if not must(not helper.finish_sale(host,game,p,{}, {"ok":true}).is_empty(),"unbound_sale_completion_rejected"):return false
 return must(game.Darkcrest.Sources.same(before,live_snapshot()),"sale_rejections_preserve_full_live_state")
func sale_retirement_check(unit: Dictionary) -> bool:
 var p=game.state.players[0];var host=game._darkcrest_host;var helper=host._lava_play;var before=live_snapshot()
 if not must(not helper._board.has(unit.uid) and helper._retired.has(unit.uid) and helper._retired[unit.uid].owner==0 and helper._retired[unit.uid].round==game.state.round,"exact_original_play_record_retired"):return false
 if not must(helper._pending.is_empty() and helper._sale_pending.is_empty(),"all_lava_transactions_clear_after_sale"):return false
 if not must(not helper.sale_preflight(host,game,p,unit).is_empty() and not helper.preflight(host,game,p,unit).is_empty(),"retired_reference_cannot_authorize_sale_or_play"):return false
 if not must(not helper.finish_sale(host,game,p,{}, {"ok":true}).is_empty(),"sale_completion_replay_rejected"):return false
 return must(game.Darkcrest.Sources.same(before,live_snapshot()),"retired_rejections_preserve_full_live_state")
func public_sale(unit: Dictionary) -> bool:
 var p=game.state.players[0];var host=game._darkcrest_host
 if not original_lava(unit,"pre_sale_original_2_5_kept0"):return false
 if not sale_authority_rejections(unit):return false
 var board=p.board.duplicate();var values=p.board.duplicate(true);var hand=p.hand.duplicate();var hand_values=p.hand.duplicate(true)
 var gold=p.gold;var sold=p.stats.sold;var pool=game.pool.duplicate(true);var uid=game.next_uid;var rng=game.rng.state;var seed=game.rng.seed;var spell_pool=game.spell_pool.duplicate(true)
 var old_records=host._lava_play._board.duplicate();var prior_retired=host._lava_play._retired.duplicate(true)
 var round_before=game.state.round;var sequence_before=game.state.command_sequence
 var index=p.board.find(unit)
 if not must(command(0,{"type":"sell","index":index}).get("ok",false),"public_native_lava_sell"):return false
 board.remove_at(index);values.remove_at(index);pool[LAVA]+=1
 if not must(host.Generation._same_objects(board,p.board) and game.Darkcrest.Sources.same(values,p.board),"sale_only_original_board_departure"):return false
 if not must(host.Generation._same_objects(hand,p.hand) and game.Darkcrest.Sources.same(hand_values,p.hand),"sale_hand_identity_and_values_unchanged"):return false
 if not must(p.gold==gold+1 and p.stats.sold==sold+1 and game.Darkcrest.Sources.same(pool,game.pool),"native_sale_gold_stock_sold_exact_deltas"):return false
 if not must(game.next_uid==uid and game.rng.state==rng and game.rng.seed==seed and game.Darkcrest.Sources.same(spell_pool,game.spell_pool) and absent_from_all_zones(unit),"sale_no_uid_rng_change_old_object_absent"):return false
 if not must(not host._lava_play.board_error(host,game,p,unit).is_empty(),"departed_original_has_no_board_authority"):return false
 old_records.erase(unit.uid)
 if not must(host._lava_play._board.size()==old_records.size(),"sale_retires_only_one_play_record"):return false
 for key in old_records:
  if not must(is_same(old_records[key],host._lava_play._board.get(key)),"other_play_record_reference_preserved"):return false
 if not must(host._lava_play._retired.size()==prior_retired.size()+1,"retirement_added_once"):return false
 for key in prior_retired:
  if not must(game.Darkcrest.Sources.same(prior_retired[key],host._lava_play._retired.get(key)),"prior_retirement_preserved"):return false
 if not must(game.Darkcrest.Sources.same(host._lava_play._retired.get(unit.uid),{"owner":p.id,"round":round_before,"sequence":sequence_before}),"exact_retirement_owner_round_native_sequence"):return false
 sale_effects.append({"uid":unit.uid,"index":index,"gold_before":gold,"gold_after":p.gold,"stock_before":pool[LAVA]-1,"stock_after":game.pool[LAVA],"sold_before":sold,"sold_after":p.stats.sold,"uid_before":uid,"uid_after":game.next_uid,"rng_before":rng,"rng_after":game.rng.state,"retirement":host._lava_play._retired[unit.uid].duplicate(true)})
 return sale_retirement_check(unit)
func generated_sale_case() -> bool:
 var data=obtain_generated_lava()
 if data.is_empty():return false
 var parent=data.parent;var lava=data.lava;var p=game.state.players[0]
 if not public_lava_play(lava,0) or not prepare_real_opponents():return false
 if not next_round(parent,3) or not inspect_lava_combat(lava):return false
 if not must(command(0,{"type":"move","from":p.board.find(lava),"to":1}).get("ok",false),"public_move_before_sale"):return false
 if not public_sale(lava) or not next_round(parent,4):return false
 var domain=game.BulkResourceHost.domain(game)
 var choices=game.BulkResourceHost.candidates(domain,domain.stock,{"kind":"minion","tier":4,"tribe":"纳迦"})
 if not must(not choices.is_empty() and choices.all(func(c):return c.stock>0),"post_sale_complete_current_tier4_domain"):return false
 if not cast_level(parent,4):return false
 sale_cases.append({"kind":"generated_lava_combat_move_sale","seed":20261120,"source_uid":parent.uid,"departed_uid":lava.uid,"tier2_choices":data.choices,"post_sale_tier4_choices":choices,"retirement":game._darkcrest_host._lava_play._retired[lava.uid].duplicate(true),"source_tier":4})
 return true
func shop_two_sources_sale_case() -> bool:
 # Reuse the old acquisition sequence only; do not call its old EOT case.
 if not setup_room(20261220):return false
 var p=game.state.players[0];var lava={}
 for attempt in range(100):
  var offers=p.shop.filter(func(u):return u.card_id==LAVA)
  if not offers.is_empty():
   if not fund(10):return false
   lava=offers[0]
   if not must(command(0,{"type":"buy","index":p.shop.find(lava)}).get("ok",false),"shop_lava_before_sources"):return false
   break
  if not fund(10) or not command(0,{"type":"roll"}).get("ok",false):return false
 if not must(not lava.is_empty(),"bounded_native_shop_lava_found"):return false
 var parents=buy_two_parents()
 if not must(parents.size()==2,"two_native_parents"):return false
 if not source_play(parents[0]) or not next_round(parents[0],2):return false
 if not public_lava_play(lava,1) or not source_play(parents[1]):return false
 if not must(p.board.map(func(u):return u.uid)==[parents[0].uid,lava.uid,parents[1].uid],"pre_sale_sources_at_0_2"):return false
 if not public_sale(lava):return false
 if not must(p.board.map(func(u):return u.uid)==parents.map(func(u):return u.uid),"post_sale_sources_at_0_1"):return false
 if not next_round(parents[0],3):return false
 for index in range(2):
  var source=parents[index];var expected=3 if index==0 else 2
  var tokens=p.hand.filter(func(u):return u.card_id=="BG31_920t" and game._darkcrest_host._spells[u.uid].source_uid==source.uid)
  if not must(tokens.size()==1 and game._darkcrest_host._spells[tokens[0].uid].tier==expected and game._darkcrest_host._parents[source.uid].tier==expected,"post_sale_independent_source_grant_"+str(index)):return false
 sale_cases.append({"kind":"two_sources_sale_reindex","seed":20261220,"source_uids":parents.map(func(u):return u.uid),"departed_uid":lava.uid,"actual_board_indices":[0,1],"source_tiers":[3,2],"retirement":game._darkcrest_host._lava_play._retired[lava.uid].duplicate(true)})
 return true
func _initialize():
 print("DARKCREST_LAVA_SALE_MATRIX_LOAD_BEGIN")
 var Game=load("res://core/game.gd")
 if not must(Game!=null and Game.can_instantiate(),"complete_game_script"):return
 cat=load("res://core/catalog.gd").new();cat.load_catalog()
 if not must(cat.load_errors.is_empty(),"complete_catalog"):return
 if not generated_sale_case() or not shop_two_sources_sale_case():return
 for row in sale_cases:print("DARKCREST_LAVA_SALE_CASE_PASS ",JSON.stringify(row))
 var result={"scope":"ordinary authenticated untouched Lava native sale and retirement only","checks":checks,"cases":sale_cases,"sale_effects":sale_effects,"combat_damage":damage_records,"old_lava_three_cases_repeated":false,"coin_pre_source_fixture":true,"entirely_natural_game":false,"partial_failure_live_injection":false,"active_rebuy_opened":false,"no_live_state_injection":true}
 var file=FileAccess.open(get_script().resource_path.get_base_dir()+"/DARKCREST_LAVA_SALE_MATRIX_RESULT.json",FileAccess.WRITE)
 if not must(file!=null,"matrix_result_file"):return
 file.store_string(JSON.stringify(result,"  ")+"\n");file.close()
 print("DARKCREST_LAVA_SALE_REAL_MATRIX_PASS cases=",sale_cases.size()," checks=",checks)
 quit(0)
