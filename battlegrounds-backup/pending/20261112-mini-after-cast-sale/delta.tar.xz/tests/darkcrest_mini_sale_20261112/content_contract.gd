extends "res://tests/darkcrest_lava_permanent_20261112/content_contract.gd"
# Detached content predicates and negative authority only; no native Game instantiated.
func context_ok(host,c,p,u,plan,values) -> bool:
 return MiniHost.sale_context_matches(host,c,p,u,"u55",1,2,3,4,plan,values)
func _initialize():
 check(Sources.proof_error().is_empty(),"complete_mini_sale_source_runtime_proof")
 var host=Host.new();var p={"id":0};var u={"uid":"u55","card_id":"BG23_000"};var plan={"items":[{"amount":1}]};var values=plan.duplicate(true)
 var c={"owner":p,"sold":u,"sold_uid":"u55","index":1,"sales_before":2,"round":3,"sequence":4,"generated_tier7_plan":plan}
 check(context_ok(host,c,p,u,plan,values),"detached_sale_context_shape_not_authority")
 check(context_ok(host,c.duplicate(false),p,u,plan,values),"equal_reference_copy_shape_not_authority")
 for key in c:
  var bad=c.duplicate(false);bad.erase(key)
  check(not context_ok(host,bad,p,u,plan,values),"missing_sale_context_"+key)
 var extra=c.duplicate(false);extra.foreign=true
 check(not context_ok(host,extra,p,u,plan,values),"extra_sale_context_rejected")
 for key in ["owner","sold","generated_tier7_plan"]:
  var bad=c.duplicate(false);bad[key]=c[key].duplicate(true)
  check(not context_ok(host,bad,p,u,plan,values),"copied_sale_context_ref_"+key)
 for key in ["index","sales_before","round","sequence"]:
  for value in [null,true,float(c[key]),str(c[key]),-1,c[key]+1]:
   var bad=c.duplicate(false);bad[key]=value
   check(not context_ok(host,bad,p,u,plan,values),"strict_sale_context_integer_"+key+str(value))
 for value in [null,55,true,"u56",StringName("u55")]:
  var bad=c.duplicate(false);bad.sold_uid=value
  check(not context_ok(host,bad,p,u,plan,values),"strict_sale_context_uid_"+str(value))
 plan.items[0].amount=2
 check(not context_ok(host,c,p,u,plan,values),"same_plan_ref_deep_mutation_rejected")
 plan.items[0].amount=1.0
 check(not context_ok(host,c,p,u,plan,values),"same_plan_ref_float_equal_value_rejected")
 plan.items[0].amount=1
 check(context_ok(host,c,p,u,plan,values),"restored_detached_plan_shape_only")
 var original={"owner":p,"unit":u,"source_uid":"u55","ready":true,"used":false,"round":3,"snapshot":{"uid":"u60","effects":[{"attack":2}]}}
 var facts=MiniHost.token_facts(original)
 check(not facts.has("owner") and not facts.has("unit") and facts.size()==original.size()-2,"token_facts_exclude_only_identity_fields")
 check(host.purchase_value_same(facts, {"source_uid":"u55","ready":true,"used":false,"round":3,"snapshot":{"uid":"u60","effects":[{"attack":2}]}}),"token_facts_preserve_all_history")
 facts.snapshot.effects[0].attack=99
 check(original.snapshot.effects[0].attack==2,"token_facts_are_detached_deep_copy")
 var helper=MiniHost.new();var pretend=PretendMiniHost.new();pretend._mini=helper
 for game_fixture in [{"state":{"players":[p],"phase":"recruit"}},PretendMiniGame.new()]:
  check(not helper.sale_preflight(pretend,game_fixture,p,u).is_empty(),"fake_actual_cannot_authorize_mini_sale")
  check(not helper.begin_sale(pretend,game_fixture,p,0,c).is_empty(),"fake_context_cannot_bind_mini_sale")
  check(not helper.finish_sale(pretend,game_fixture,p,c,{"ok":true}).is_empty(),"unbound_mini_sale_cannot_complete")
 check(helper._sale.is_empty() and helper._board.is_empty() and helper._tokens.is_empty() and helper._poison.is_empty(),"fake_sale_calls_create_no_receipts_or_poison")
 # A detached retired-looking fixture is not native retirement provenance.
 helper._board={"owner":p,"unit":u,"snapshot":u.duplicate(true),"retired":true,"retired_uid":"u55","retired_round":3,"retired_sequence":4}
 var before=helper._board.duplicate(true)
 check(not helper.board_error(pretend,{},p,u).is_empty(),"fake_retired_record_never_grants_board_authority")
 check(not helper.sale_preflight(pretend,{},p,u).is_empty(),"fake_retired_record_never_grants_sale_authority")
 check(host.purchase_value_same(helper._board,before) and helper._sale.is_empty(),"fake_retired_checks_do_not_consume_record")
 # These fake cases stop at actual-authority refusal; they do NOT execute deep custody branches.
 for retirement in [{},{"retired":true,"retired_complete":false},{"retired":true,"retired_complete":true}]:
  var isolated=MiniHost.new();var fake_host=PretendMiniHost.new();fake_host._mini=isolated
  isolated._board=retirement.duplicate(true)
  var before_record=isolated._board.duplicate(true)
  check(not isolated.cast_source_error(fake_host,{},p,{"uid":"u60"}).is_empty(),"fake_source_custody_cannot_authorize_cast")
  check(host.purchase_value_same(before_record,isolated._board) and isolated._tokens.is_empty() and isolated._poison.is_empty(),"fake_source_custody_refusal_no_mutation")
 # Pure custody content: does not authenticate Game/engine/issued token.
 var source={"card_id":"BG23_000","uid":"u70","attack":1};var owner={"id":0,"board":[source]}
 var live={"owner":owner,"unit":source,"snapshot":source.duplicate(true)}
 check(MiniHost.source_presence_error(host,live,owner,"u70",3,10,[owner.board]).is_empty(),"detached_live_source_presence_content_only")
 owner.board=[]
 check(not MiniHost.source_presence_error(host,live,owner,"u70",3,10,[owner.board]).is_empty(),"lost_source_without_retirement_rejected")
 owner.board=[source.duplicate(true)]
 check(not MiniHost.source_presence_error(host,live,owner,"u70",3,10,[owner.board]).is_empty(),"copied_live_source_not_original_ref")
 owner.board=[]
 check(not MiniHost.source_presence_error(host,live,owner.duplicate(true),"u70",3,10,[]).is_empty(),"wrong_source_owner_reference_rejected")
 check(not MiniHost.source_presence_error(host,live,owner,"u71",3,10,[]).is_empty(),"wrong_issued_source_uid_rejected")
 var retired=live.duplicate(false);retired.retired=true;retired.retired_complete=true;retired.retired_uid="u70";retired.retired_round=3;retired.retired_sequence=9
 check(MiniHost.source_presence_error(host,retired,owner,"u70",3,10,[[],[]]).is_empty(),"detached_completed_retirement_content_only")
 for key in ["retired_complete","retired_uid","retired_round","retired_sequence","snapshot"]:
  var bad=retired.duplicate(false);bad.erase(key)
  check(not MiniHost.source_presence_error(host,bad,owner,"u70",3,10,[]).is_empty(),"missing_retirement_fact_"+key)
 for value in [null,false,1,"true"]:
  var bad=retired.duplicate(false);bad.retired=value
  check(not MiniHost.source_presence_error(host,bad,owner,"u70",3,10,[]).is_empty(),"invalid_retirement_flag_"+str(value))
 for value in [null,false,1,"true"]:
  var bad=retired.duplicate(false);bad.retired_complete=value
  check(not MiniHost.source_presence_error(host,bad,owner,"u70",3,10,[]).is_empty(),"partial_or_nonbool_completion_rejected_"+str(value))
 for value in [null,3.0,"3",2,4]:
  var bad=retired.duplicate(false);bad.retired_round=value
  check(not MiniHost.source_presence_error(host,bad,owner,"u70",3,10,[]).is_empty(),"wrong_retirement_round_"+str(value))
 for value in [null,9.0,"9",-1,10,11]:
  var bad=retired.duplicate(false);bad.retired_sequence=value
  check(not MiniHost.source_presence_error(host,bad,owner,"u70",3,10,[]).is_empty(),"wrong_retirement_sequence_"+str(value))
 var changed=retired.duplicate(false);changed.snapshot={"card_id":"BG23_000","uid":"u70","attack":2}
 check(not MiniHost.source_presence_error(host,changed,owner,"u70",3,10,[]).is_empty(),"changed_retired_source_snapshot_rejected")
 for zones in [[source],[[source]],[[source.duplicate(true)]],[[{"uid":"u70"}]],[[null]]]:
  check(not MiniHost.source_presence_error(host,retired,owner,"u70",3,10,zones).is_empty(),"retired_source_reinsert_or_invalid_zone_rejected")
 print("DARKCREST_MINI_SALE_CONTENT_CONTRACT ",JSON.stringify({"passed":passed,"failed":failed,"failures":failures,"real_game_run":false,"actual_provenance_proven":false,"scope":"detached Mini sale context and refusal only"}))
 quit(0 if failed==0 else 1)
