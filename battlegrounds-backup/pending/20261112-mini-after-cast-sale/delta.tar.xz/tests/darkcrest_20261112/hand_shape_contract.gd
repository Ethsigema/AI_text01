extends SceneTree
## PURE CONTRACT ONLY. Fixtures are derived from complete frozen EXPECTED_HAND
## catalog records. They are not factory output, purchase receipts, or proof of
## actual origin. No Game instance, RNG, pool, UID allocator, or hand writer runs.
## Run later with --path pointing at game_candidate, --script this absolute file.
const Host=preload("res://core/darkcrest_host.gd")
const Sources=preload("res://core/darkcrest_sources.gd")
const Rider=preload("res://core/rider_host.gd")
const STRICT_IDS: Array=["BG23_009","BG23_002","BG31_924","BG23_007","BG23_004"]
var passed: int=0
var failed: int=0
var failures: Array=[]

func check(ok: bool,label: String,detail: String="") -> void:
	if ok:
		passed+=1
		print("PASS "+label)
	else:
		failed+=1
		failures.append({"label":label,"detail":detail})
		printerr("FAIL "+label+" "+detail)

func fixture(card: Dictionary,bulk_shape: bool=false) -> Dictionary:
	# Explicitly mirrors Game._factory_unit's ordinary minion fields plus the
	# real source-specific reservation fields. It DOES NOT call that factory.
	var u: Dictionary={
		"uid":"contract_fixture_"+str(card.id),"card_id":card.id,
		"name":card.get("name",card.id),"kind":"minion","tier":int(card.tier),
		"attack":int(card.attack),"health":int(card.health),"max_health":int(card.health),
		"keywords":card.get("keywords",[]).duplicate(true),
		"tribes":card.get("tribes",[]).duplicate(true),
		"effects":card.get("effects",[]).duplicate(true),"golden":false,
		"cost":int(card.get("cost",0) if card.get("cost")!=null else 0),
		"temporary":false,"is_spellcraft":false,"temporary_buffs":[],
		"permanent_keywords":card.get("keywords",[]).duplicate(true),
		"text":card.get("text",""),"image":card.get("image",""),
		"pool_count":1,"spellcraft_kept":0,"spell_triggers":0,"attachments":[],
		"pool_components":[],"magnetic_tribes":card.get("magnetic_tribes",[]).duplicate(true),
		"individually_frozen":false,"blood_gems_received_turn":0,
		"recruit_shop_bonus_applied":{},"recruit_shop_aura_attack":0,
		"recruit_shop_aura_health":0,"golden_rebase_state":"additive_v1","pool_id":card.id
	}
	u.base_unit={
		"card_id":u.card_id,"name":u.name,"tier":u.tier,"attack":u.attack,
		"health":u.health,"max_health":u.health,"keywords":u.keywords.duplicate(true),
		"tribes":u.tribes.duplicate(true),"effects":u.effects.duplicate(true),"golden":false
	}
	if bulk_shape: u.pool_kind="minion"
	return u

func expect_issue(card: Dictionary,u: Dictionary,label: String,expected: String) -> void:
	var original_unit: Dictionary=u.duplicate(true)
	var original_card: Dictionary=card.duplicate(true)
	var actual: String=Host.hand_state_error(u,card,Rider.UNIT_FIELDS)
	check(actual==expected,label,"expected="+expected+" actual="+actual)
	check(Sources.same(u,original_unit) and Sources.same(card,original_card),label+"_read_only")

func _initialize() -> void:
	check(Sources.same(Host.STRICT_HAND_BODIES,STRICT_IDS),"exact_five_strict_id_contract")
	for id in STRICT_IDS:
		var card: Dictionary=Sources.EXPECTED_HAND[id].duplicate(true)
		var shop: Dictionary=fixture(card)
		var bulk: Dictionary=fixture(card,true)
		check(not shop.has("pool_kind") and bulk.get("pool_kind")=="minion",id+"_two_exact_factory_compatible_shapes")
		expect_issue(card,shop,id+"_accept_shop_shape","")
		expect_issue(card,bulk,id+"_accept_bulk_shape","")
		for bad_kind in [null,"","spell"]:
			var bad: Dictionary=bulk.duplicate(true)
			bad.pool_kind=bad_kind
			expect_issue(card,bad,id+"_reject_pool_kind_"+str(bad_kind),"darkcrest_hand_native_field_held:pool_kind")
		var changed: Dictionary=shop.duplicate(true)
		changed.contract_extra=true
		expect_issue(card,changed,id+"_reject_extra_body_field","darkcrest_unknown_hand_field:contract_extra")
		changed=shop.duplicate(true);changed.pool_count=0
		expect_issue(card,changed,id+"_reject_changed_pool_count","darkcrest_hand_native_field_held:pool_count")
		changed=shop.duplicate(true);changed.pool_id="foreign"
		expect_issue(card,changed,id+"_reject_changed_pool_identity","darkcrest_hand_native_field_held:pool_id")
		changed=shop.duplicate(true);changed.base_unit.attack+=1
		expect_issue(card,changed,id+"_reject_changed_base_attack","darkcrest_hand_native_base_held")
		changed=shop.duplicate(true);changed.base_unit.tier+=1
		expect_issue(card,changed,id+"_reject_changed_base_tier","darkcrest_hand_native_base_held")
		changed=shop.duplicate(true);changed.base_unit.kind="minion"
		expect_issue(card,changed,id+"_reject_extra_base_field","darkcrest_hand_native_base_held")
		changed=shop.duplicate(true);changed.base_unit.erase("max_health")
		expect_issue(card,changed,id+"_reject_missing_base_field","darkcrest_hand_native_base_held")
		changed=shop.duplicate(true);changed.base_unit.effects=[{"type":"contract_fake_leaf"}]
		expect_issue(card,changed,id+"_reject_changed_base_effect_type","darkcrest_hand_native_base_held")
		changed=shop.duplicate(true);changed.effects=[{"type":"contract_fake_leaf"}]
		expect_issue(card,changed,id+"_reject_changed_live_effect_type","darkcrest_hand_native_field_held:effects")
		changed=shop.duplicate(true);changed.base_unit=null
		expect_issue(card,changed,id+"_reject_non_dictionary_base","darkcrest_hand_native_base_held")
		var changed_source: Dictionary=card.duplicate(true)
		changed_source.text=str(changed_source.text)+" changed"
		expect_issue(changed_source,shop,id+"_reject_changed_whole_source","darkcrest_complete_random_candidate_held:"+id)
	print(JSON.stringify({
		"suite":"darkcrest_five_strict_hand_shapes","passed":passed,"failed":failed,
		"failures":failures,"ids":STRICT_IDS,
		"scope":"pure shape/source contract; not actual factory, purchase, issuance, or origin proof",
		"host_sha256":FileAccess.get_sha256("res://core/darkcrest_host.gd"),
		"sources_sha256":FileAccess.get_sha256("res://core/darkcrest_sources.gd")
	}))
	quit(0 if failed==0 else 1)
