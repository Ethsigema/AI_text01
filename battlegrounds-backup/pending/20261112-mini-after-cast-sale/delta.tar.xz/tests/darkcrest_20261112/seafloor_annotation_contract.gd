extends SceneTree
## Independent source-contract test. Does not load Game/Catalog or write files.
## Run with --path <game_candidate> --script <absolute path to this file>.
const Sources=preload("res://core/seafloor_cast_sources.gd")
const CurrentStock=preload("res://core/current_two_spell_stock_sources.gd")
const Scope=preload("res://core/current_scope.gd")
const SOURCE_PATH: String="res://core/seafloor_cast_sources.gd"
const DEPENDENCY_LINE: String='const CurrentStock=preload("res://core/current_two_spell_stock_sources.gd")'
const DENIED: String="contract_probe_membership_denied"
var checks: int=0
var failures: int=0

func check(ok: bool,label: String) -> void:
	checks+=1
	print("PASS " if ok else "FAIL ",label)
	if not ok: failures+=1

func accepted(card: Dictionary,label: String) -> void:
	var before: Dictionary=card.duplicate(true)
	check(Sources.spell_error(card).is_empty(),label)
	check(Sources.same(card,before),label+"_input_unchanged")

func rejected(card: Dictionary,label: String) -> void:
	var before: Dictionary=card.duplicate(true)
	check(Sources.spell_error(card)=="seafloor_exact_child_changed",label)
	check(Sources.same(card,before),label+"_input_unchanged")

func _initialize() -> void:
	var original: Dictionary=Sources.SPELL_RAW.duplicate(true)
	original.merge(Sources.SPELL_EXPECTED,true)
	var annotated: Dictionary=original.duplicate(true)
	annotated.pool_supported=true
	annotated.native_current_spell_stock=CurrentStock.TAG
	accepted(original,"original_exact_snapshot")
	accepted(annotated,"exact_current_two_field_annotation")
	var changed: Array=[]
	for key in annotated:
		if not original.has(key) or not Sources.same(original[key],annotated[key]): changed.append(key)
	changed.sort()
	check(changed.size()==2 and "native_current_spell_stock" in changed and "pool_supported" in changed,"only_two_allowed_fields_differ")
	check(Sources.same(original.effects,annotated.effects) and Sources.same(original.cost,annotated.cost),"program_and_price_unchanged")

	var bad: Dictionary=annotated.duplicate(true)
	bad.effects[0].count=int(bad.effects[0].count)+1
	rejected(bad,"changed_effect_count_rejected")
	bad=annotated.duplicate(true)
	bad.cost=99
	rejected(bad,"changed_cost_rejected")
	bad=annotated.duplicate(true)
	bad.native_current_spell_stock="forged_current_stock_tag"
	rejected(bad,"forged_tag_rejected")
	bad=annotated.duplicate(true)
	bad.native_current_spell_stock=true
	rejected(bad,"non_string_tag_rejected")
	bad=original.duplicate(true)
	bad.pool_supported=true
	rejected(bad,"eligibility_without_tag_rejected")
	bad=original.duplicate(true)
	bad.native_current_spell_stock=CurrentStock.TAG
	rejected(bad,"tag_without_eligibility_rejected")
	bad=annotated.duplicate(true)
	bad.unexpected_annotation=true
	rejected(bad,"extra_top_level_field_rejected")
	bad=annotated.duplicate(true)
	bad.effects[0].unexpected_annotation=true
	rejected(bad,"extra_nested_field_rejected")
	bad=annotated.duplicate(true)
	bad.cost=99
	bad.effects[0].count=99
	bad.unexpected_annotation=true
	rejected(bad,"multiple_unauthorized_changes_rejected")
	# Every existing top-level field remains exact, including provenance and
	# partial-closure declarations. This is not an effects-only comparison.
	for key in annotated:
		bad=annotated.duplicate(true)
		bad[key]={"contract_probe_unexpected_value":true}
		rejected(bad,"whole_row_field_rejected:"+str(key))
		bad=annotated.duplicate(true)
		bad.erase(key)
		rejected(bad,"missing_row_field_rejected:"+str(key))

	var manifest: Dictionary=Scope.manifest()
	check(Scope.manifest_error(manifest).is_empty(),"real_current_manifest_valid")
	check(CurrentStock.membership_error(Sources.SPELL).is_empty(),"real_current_membership_accepts_chef")
	check(Sources.SPELL in manifest.get("official",{}).get("spell_ids",[]),"chef_in_official_spell_membership")
	check(Sources.SPELL in Scope.main_ids("spell",manifest),"chef_in_effective_current_spell_membership")
	check(not CurrentStock.membership_error("not_an_authorized_stock_source").is_empty(),"membership_rejects_unknown_source")
	var invalid_manifest: Dictionary=manifest.duplicate(true)
	invalid_manifest.erase("official")
	check(not Scope.manifest_error(invalid_manifest).is_empty(),"invalid_manifest_rejected_without_changing_real_manifest")

	# Isolated negative dependency probe, compiled in memory only. Replace the
	# one dependency declaration, not spell_error or the actual on-disk manifest.
	# This proves the annotated branch propagates membership refusal. It does
	# not claim a full Game test or simulate an official membership change.
	var source_text: String=FileAccess.get_file_as_string(SOURCE_PATH)
	var one_dependency: bool=source_text.count(DEPENDENCY_LINE)==1
	check(one_dependency,"exact_membership_dependency_declared_once")
	if one_dependency:
		var stub: String="class CurrentStock:\n\tconst TAG: String="+JSON.stringify(CurrentStock.TAG)+"\n\tstatic func membership_error(identity: String) -> String:\n\t\treturn "+JSON.stringify(DENIED)+" if identity == "+JSON.stringify(Sources.SPELL)+" else \"contract_probe_wrong_identity\""
		var probe=GDScript.new()
		probe.source_code=source_text.replace(DEPENDENCY_LINE,stub)
		var error: int=probe.reload()
		check(error==OK,"isolated_membership_probe_compiles")
		if error==OK:
			var before: Dictionary=annotated.duplicate(true)
			check(probe.spell_error(annotated)==DENIED,"annotated_branch_propagates_membership_denial")
			check(Sources.same(annotated,before),"membership_denial_does_not_mutate_input")
			check(probe.spell_error(original).is_empty(),"original_snapshot_retains_original_contract")
	print("SEAFLOOR_ANNOTATION_CONTRACT ",JSON.stringify({"checks":checks,"failures":failures,"scope":"source_contract_only_no_Game_or_Catalog"}))
	quit(0 if failures==0 else 1)
