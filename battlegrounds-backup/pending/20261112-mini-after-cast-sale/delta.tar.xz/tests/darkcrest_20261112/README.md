# 暗潮真实回合结束片段测试

Godot 4.6.3。逐个执行，不要并行加载完整 Game。real_matrix.gd 需要约3GB运行内存，建议900秒软时限；其它合同只加载相关模块。

    godot --headless --path <恢复工程> --script <恢复工程>/tests/darkcrest_20261112/real_matrix.gd
    godot --headless --path <恢复工程> --script <恢复工程>/tests/darkcrest_20261112/source_eot_contract.gd
    godot --headless --path <恢复工程> --script <恢复工程>/tests/darkcrest_20261112/hand_shape_contract.gd
    godot --headless --path <恢复工程> --script <恢复工程>/tests/darkcrest_20261112/seafloor_annotation_contract.gd

source_eot_contract.gd须与darkcrest_sources_archived.gd一起保留。后者只用于历史来源比较，不是运行时实现。矩阵通过真实酒馆币筹资、公开升级/刷新/购买/出牌/结束回合完成两个受限房间；不直接写金币、成长等级、随机数、库存或手牌。预演负例只改独立副本，前后核验原状态不变。纯合同fixture不证明实体真实来源。

仅普通初始商店来源、1/2/3级生成、原生回合结束/塑造等待/到期片段；4级及以后、金色/三连/复制、出牌后再购买、混合战队、饰品/其他英雄、完整对局和存档仍未验收。旧失败与最终成功保存在包内evidence，不累加为最终覆盖数。

## 后续版本说明

本目录real_matrix.gd保留上一批历史断言，其中“4级必须拒绝”已被新Tier4受限实现取代。当前版本请运行tests/darkcrest_tier4_20261112/real_matrix.gd；它继承本文件的原生准备/等待测试，并覆盖1至4级生成及原生等待回归，不执行旧4级拒绝断言。其它纯合同仍有效。历史日志不是本版验收。

Current rebuilt Tier5 candidate entry: tests/darkcrest_tier5_20261112/real_matrix.gd. Old Tier4 refusal assertions are historical, not current acceptance.
