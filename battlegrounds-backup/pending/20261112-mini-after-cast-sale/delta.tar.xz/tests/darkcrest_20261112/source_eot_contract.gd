extends SceneTree
const S=preload("res://core/darkcrest_sources.gd")
const H=preload("res://core/darkcrest_host.gd")
const P=preload("res://core/pool_identity.gd")
var passed=0
var failed=0
func check(ok: bool,label: String):
 if ok:passed+=1
 else:failed+=1
 print("PASS " if ok else "FAIL ",label)
func _initialize():
 var old=load(get_script().resource_path.get_base_dir()+"/darkcrest_sources_archived.gd")
 if old==null:print("MISSING_ARCHIVE_FIXTURE");quit(1);return
 var old_golden=old.EXPECTED_CURRENT[S.PARENTS[1]].duplicate(true)
 check(old.source_error(old_golden).is_empty(),"old_canonical_source")
 old_golden.pool_blocker=P.MINION_REASON
 check(old.source_error(old_golden).is_empty(),"archived_source_already_accepts_native_golden_annotation")
 for id in S.PARENTS:
  var card=S.EXPECTED_CURRENT[id].duplicate(true)
  check(S.source_error(card).is_empty(),"complete_current_source_"+id)
  if id==S.PARENTS[1]:
   card.pool_blocker=P.MINION_REASON
   check(S.source_error(card).is_empty(),"exact_golden_annotation")
   card.pool_blocker="invalid"
   check(not S.source_error(card).is_empty(),"reject_wrong_golden_annotation")
   card=S.EXPECTED_CURRENT[id].duplicate(true)
  check(S.program(id).size()==2 and S.program(id)[0].type=="spellcraft" and S.program(id)[1]==S.eot_effect(id),"spellcraft_then_native_eot_"+id)
  for effect in S.program(id):check(S.eot_wrapper_error(card,effect).is_empty(),"scheduler_complete_source_each_leaf_"+id+"_"+effect.type)
  var changed=S.eot_effect(id);changed.source_id="foreign"
  check(not S.eot_wrapper_error(card,changed).is_empty(),"reject_rebound_eot_"+id)
  changed=S.eot_effect(id);changed.extra=true
  check(not S.eot_wrapper_error(card,changed).is_empty(),"reject_extra_eot_field_"+id)
  var base={"card_id":id,"name":card.name,"tier":card.tier,"attack":card.attack,"health":card.health,"max_health":card.health,"keywords":card.keywords.duplicate(),"tribes":card.tribes.duplicate(),"effects":S.program(id),"golden":card.is_golden}
  check(S.eot_combat_unit_error(base,true).is_empty(),"exact_native_base_"+id)
  check(not S.eot_combat_unit_error(base).is_empty(),"base_not_accepted_as_live_body_"+id)
  var live=base.duplicate(true);live.kind="minion"
  check(S.eot_combat_unit_error(live).is_empty(),"live_program_identity_"+id)
  for field in base:
   var bad=base.duplicate(true);bad.erase(field)
   check(not S.eot_combat_unit_error(bad,true).is_empty(),"reject_missing_base_"+id+"_"+field)
  var bad=base.duplicate(true);bad.attack+=1
  check(not S.eot_combat_unit_error(bad,true).is_empty(),"reject_changed_base_attack_"+id)
  bad=base.duplicate(true);bad.kind="minion"
  check(not S.eot_combat_unit_error(bad,true).is_empty(),"reject_extra_base_field_"+id)
  bad=base.duplicate(true);bad.effects[1].type="end_turn_forged"
  check(not S.eot_combat_unit_error(bad,true).is_empty(),"reject_changed_base_eot_type_"+id)
  bad=live.duplicate(true);bad.effects[1].type="end_turn_forged"
  check(not S.eot_combat_unit_error(bad).is_empty(),"reject_changed_live_eot_type_"+id)
  for malformed in [null,true,7,"invalid",{}]:
   bad=live.duplicate(true);bad.effects=malformed
   check(not S.eot_combat_unit_error(bad).is_empty(),"reject_malformed_effects_"+id+"_"+str(malformed))
 for id in S.SPELLS:
  var card=S.EXPECTED_CURRENT[id].duplicate(true)
  check(S.program(id).size()==1 and S.program(id)[0].type==S.TYPE,"token_has_no_growth_program_"+id)
  check(not S.eot_wrapper_error(card,{"type":S.EOT,"source_id":id}).is_empty(),"token_cannot_be_eot_source_"+id)
 var foreign={"card_id":"BG23_000","kind":"minion","effects":[S.eot_effect(S.PARENTS[0])]}
 check(not S.eot_combat_unit_error(foreign).is_empty(),"foreign_source_cannot_claim_eot")
 var host=H.new()
 check(host.advance(null,{})=="darkcrest_original_complete_eot_callback_required","old_boardwide_writer_refuses")
 check(not host.execute_eot(null,{}, {},0,0).is_empty(),"no_unissued_growth_callback")
 check(S.proof_error().is_empty(),"complete_source_and_runtime_fingerprints")
 print("DARKCREST_SOURCE_EOT_CONTRACT passed=",passed," failed=",failed)
 quit(0 if failed==0 else 1)
