# 暗潮4级完整随机域与原生手牌验证

Godot 4.6.3，完整Game进程串行运行，建议1800秒软时限与至少4GiB可用内存。

    godot --headless --path <工程> --script <工程>/tests/darkcrest_tier4_20261112/real_matrix.gd

矩阵继承上一批真实准备/等待方法，不能只拷本文件而遗漏旧脚本。通过房间初始seed进行独立真实对局，不改运行中RNG、库存、UID、等级、手牌或候选。启用当前完整5名4级娜迦；重复真实来源购买、出牌、原生EOT与战斗，直到观察5种原始加权结果。每次核对完整域、随机票、库存、UID、消耗、原生历史层和下回合保留。酒馆币筹资是实际工厂/入手/公开施法的测试准备，不冒充普通商店取得币。

负例只修改脱离真实状态的深副本。异常数组、属性类型、UID、原生base、ownership、Zesty次数历史、Abyssal全局历史层、额外buff与未知字段均必须安全拒绝，并确认真实状态不变。先验证常规形状，再在原对象上只读调用原生历史投影，最后对副本剥层并复核印刷体。数值边界是纯合同，不冒充游戏自然累积极值。

覆盖1/2/3级受影响回归与满手双来源等待。4→5明确继续拒绝；与其他随从混合出牌、金色/三连/复制、存档和全游戏未验收。5名生成随从自身全部能力不属于本测试验收。

Current rebuilt Tier5 candidate entry: tests/darkcrest_tier5_20261112/real_matrix.gd. Old Tier4 refusal assertions are historical, not current acceptance.
