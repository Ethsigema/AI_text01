extends "res://tests/darkcrest_lava_rebuy_20261112/content_contract.gd"
const MiniHost=preload("res://core/darkcrest_mini.gd")
class MiniCatalog:
 extends RefCounted
 var card={}
 var child={}
 func get_card(id: String) -> Dictionary:
  return card if id=="BG23_000" else child if id=="BG23_000t" else {}
class PretendMiniHost:
 extends RefCounted
 var _mini
 var _projection_only=false
 static func actual(_game) -> bool:return true
class PretendMiniGame:
 extends RefCounted
 var _darkcrest_host
 var state={"players":[],"phase":"recruit","round":1,"command_sequence":2}
func child_fixture() -> Dictionary:
 # Explicit native-shape content fixture, not a factory receipt or live hand unit.
 var child=MiniHost.CHILD_SOURCE
 var result={"uid":"pure-child","card_id":"BG23_000t","name":child.name,"kind":"spell","tier":1,"attack":0,"health":1,"keywords":[],"tribes":[],"effects":MiniHost.EFFECT.duplicate(true),"golden":false,"cost":0,"temporary":true,"is_spellcraft":true,"temporary_buffs":[],"permanent_keywords":[],"text":child.text,"image":child.image,"pool_count":0,"spellcraft_kept":0,"spell_triggers":0,"attachments":[],"pool_components":[],"magnetic_tribes":[],"individually_frozen":false,"blood_gems_received_turn":0,"recruit_shop_bonus_applied":{},"recruit_shop_aura_attack":0,"recruit_shop_aura_health":0}
 result.max_health=1
 result.expires_at_end_turn=true
 result.base_unit={"card_id":"BG23_000t","name":child.name,"tier":1,"attack":0,"health":1,"max_health":1,"keywords":[],"tribes":[],"effects":MiniHost.EFFECT.duplicate(true),"golden":false}
 return result
func _initialize() -> void:
 check(Sources.proof_error().is_empty(),"complete_new_source_and_runtime_proof")
 var host=Host.new();var helper=MiniHost.new();var catalog=MiniCatalog.new()
 catalog.card=Sources.EXPECTED_HAND["BG23_000"].duplicate(true)
 var mini=fixture(catalog.card,false);var game_fixture={"catalog":catalog,"Rider":{"UNIT_FIELDS":Rider.UNIT_FIELDS}}
 check(MiniHost.ID=="BG23_000" and MiniHost.SPELL=="BG23_000t","ordinary_native_mini_pair")
 check(MiniHost.EFFECT==[{"type":"spell_buff","scope":"target","attack":2,"health":0,"allow_shop":true,"temporary":true}],"original_mini_child_complete_payload")
 check(helper.shape_error(host,game_fixture,mini).is_empty(),"detached_untouched_1_4_mini_shape_only")
 for field in mini:
  if field=="pool_kind":continue
  var bad=mini.duplicate(true);bad.erase(field)
  check(not helper.shape_error(host,game_fixture,bad).is_empty(),"missing_native_mini_field_"+field)
 for field in ["attack","health","max_health","spellcraft_kept"]:
  for value in [null,true,"0",-1,0.5,99]:
   var bad=mini.duplicate(true);bad[field]=value
   check(not helper.shape_error(host,game_fixture,bad).is_empty(),"corrupt_mini_body_"+field+str(value))
 for field in ["attack","health","max_health","spellcraft_kept"]:
  var bad=mini.duplicate(true);bad[field]=float(mini[field])
  check(not helper.shape_error(host,game_fixture,bad).is_empty(),"equal_float_not_native_int_"+field)
 for field in ["golden","temporary","is_spellcraft"]:
  var bad=mini.duplicate(true);bad[field]=true
  check(not helper.shape_error(host,game_fixture,bad).is_empty(),"foreign_mini_flag_"+field)
 catalog.child=MiniHost.CHILD_SOURCE.duplicate(true)
 var child=child_fixture();var pristine_child=child.duplicate(true);var pristine_source=catalog.child.duplicate(true)
 check(MiniHost.token_shape_error(host,game_fixture,child).is_empty(),"complete_detached_native_child_shape_not_provenance")
 for field in ["max_health","expires_at_end_turn"]:
  var actual_keys=child.keys().filter(func(key):return str(key)==field)
  check(actual_keys.size()==1 and typeof(actual_keys[0])==TYPE_STRING_NAME,"native_added_key_is_stringname_"+field)
  var wrong=child.duplicate(true);var value=wrong[field];wrong.erase(field);wrong[String(field)]=value
  check(not MiniHost.token_shape_error(host,game_fixture,wrong).is_empty(),"wrong_string_key_type_refused_"+field)

 for field in child:
  var bad=child.duplicate(true);bad.erase(field)
  check(not MiniHost.token_shape_error(host,game_fixture,bad).is_empty(),"missing_native_child_field_"+field)
 for field in child.base_unit:
  var bad=child.duplicate(true);bad.base_unit.erase(field)
  check(not MiniHost.token_shape_error(host,game_fixture,bad).is_empty(),"missing_child_base_field_"+field)
 for field in ["tier","attack","health","max_health","cost","pool_count","spellcraft_kept","spell_triggers","blood_gems_received_turn","recruit_shop_aura_attack","recruit_shop_aura_health"]:
  for value in [null,true,float(child[field]),str(child[field]),child[field]+1]:
   var bad=child.duplicate(true);bad[field]=value
   check(not MiniHost.token_shape_error(host,game_fixture,bad).is_empty(),"strict_child_integer_"+field+str(value))
 for field in ["golden","temporary","is_spellcraft","individually_frozen","expires_at_end_turn"]:
  for value in [null,0,"false",not child[field]]:
   var bad=child.duplicate(true);bad[field]=value
   check(not MiniHost.token_shape_error(host,game_fixture,bad).is_empty(),"strict_child_boolean_"+field+str(value))
 for value in [null,0,true,""]:
  var bad=child.duplicate(true);bad.uid=value
  check(not MiniHost.token_shape_error(host,game_fixture,bad).is_empty(),"invalid_child_uid_"+str(value))
 for field in ["source_uid","native_receipt","triple_reward","golden_rebase_state","pool_id"]:
  var bad=child.duplicate(true);bad[field]="forged"
  check(not MiniHost.token_shape_error(host,game_fixture,bad).is_empty(),"foreign_child_field_"+field)
 for field in ["attack","health","temporary","allow_shop","scope","type"]:
  var bad=child.duplicate(true);bad.effects[0].erase(field)
  check(not MiniHost.token_shape_error(host,game_fixture,bad).is_empty(),"incomplete_child_payload_"+field)
 for field in MiniHost.CHILD_SOURCE:
  catalog.child=MiniHost.CHILD_SOURCE.duplicate(true);catalog.child.erase(field)
  check(not MiniHost.token_shape_error(host,game_fixture,child).is_empty(),"missing_explicit_child_source_key_"+field)
  catalog.child=MiniHost.CHILD_SOURCE.duplicate(true)
  catalog.child[field]="source-mutated" if not catalog.child[field] is String else "not-original"
  check(not MiniHost.token_shape_error(host,game_fixture,child).is_empty(),"changed_child_source_contract_"+field)
 catalog.child=MiniHost.CHILD_SOURCE.duplicate(true)
 check(host.purchase_value_same(child,pristine_child) and host.purchase_value_same(catalog.child,pristine_source),"child_shape_checks_do_not_write_fixtures")
 var owner={"id":0,"board":[],"hand":[mini],"shop":[]};var target={"uid":"detached-lava"};var nonce=RefCounted.new()
 var context={"owner":owner,"unit":mini,"target":target,"nonce":nonce,"index":0,"position":1,"round":2,"sequence":7,"kind":"cast"}
 var receipt=context.duplicate(false)
 check(MiniHost.context_matches(context,receipt),"detached_nine_field_context_content_only")
 check(MiniHost.context_matches(context.duplicate(false),receipt),"shallow_equal_refs_shape_does_not_authorize")
 for field in context:
  var bad=context.duplicate(false);bad.erase(field)
  check(not MiniHost.context_matches(bad,receipt),"missing_context_field_"+field)
 var extra=context.duplicate(false);extra.extra=true
 check(not MiniHost.context_matches(extra,receipt),"extra_context_field_rejected")
 for field in ["owner","unit","target"]:
  var bad=context.duplicate(false);bad[field]=context[field].duplicate(true)
  check(not MiniHost.context_matches(bad,receipt),"copied_context_reference_"+field)
 var wrong_nonce=context.duplicate(false);wrong_nonce.nonce=RefCounted.new()
 check(not MiniHost.context_matches(wrong_nonce,receipt),"wrong_nonce_reference")
 for field in ["index","position","round","sequence"]:
  var original=context[field]
  for value in [null,true,float(original),str(original),original+1]:
   context[field]=value
   check(not MiniHost.context_matches(context,receipt),"same_context_mutation_strict_integer_"+field+str(value))
  context[field]=original
 for value in [null,0,true,"reset","play","expiry"]:
  context.kind=value
  check(not MiniHost.context_matches(context,receipt),"wrong_context_kind_"+str(value))
 context.kind="cast"
 var flush=RefCounted.new();var guard="detached:0";var active={guard:flush}
 check(MiniHost.flush_matches(active,guard,flush),"same_guard_reference_content_not_live_flush_provenance")
 check(not MiniHost.flush_matches({},guard,null),"missing_guard_null_flush_never_matches")
 check(not MiniHost.flush_matches({},guard,flush),"missing_guard_real_ref_refused")
 check(not MiniHost.flush_matches({guard:null},guard,null),"explicit_null_guard_null_flush_refused")
 check(not MiniHost.flush_matches(active,guard,RefCounted.new()),"wrong_flush_ref_refused")
 check(not MiniHost.flush_matches(active,"other",flush),"wrong_guard_refused")
 for invalid in [null,{},[],0,"flush"]:
  check(not MiniHost.flush_matches(active,guard,invalid),"non_refcounted_requested_flush_refused")
  check(not MiniHost.flush_matches({guard:invalid},guard,flush),"non_refcounted_active_flush_refused")
 var pretend= PretendMiniHost.new();pretend._mini=helper
 var fake= PretendMiniGame.new();fake._darkcrest_host=pretend;fake.state.players=[owner]
 var fake_dict={"_darkcrest_host":pretend,"state":fake.state}
 for counterfeit in [fake,fake_dict]:
  check(not helper.actual(pretend,counterfeit,owner),"fake_actual_true_does_not_authorize")
  check(not helper.preflight(pretend,counterfeit,owner,mini).is_empty(),"fake_mini_play_preflight_refused")
  check(not helper.begin(pretend,counterfeit,owner,0,context).is_empty(),"fake_context_cannot_begin_native_operation")
  check(not helper.inserted(pretend,counterfeit,owner,mini).is_empty(),"unbound_insert_refused")
  check(not helper.board_error(pretend,counterfeit,owner,mini).is_empty(),"unissued_mini_board_refused")
  check(not helper.token_error(pretend,counterfeit,owner,{}).is_empty(),"unissued_token_refused")
  check(not helper.delivery_begin(pretend,counterfeit,owner,{},nonce).is_empty(),"fake_waiting_ticket_refused")
  check(not helper.delivery_factory(pretend,counterfeit,owner,{}).is_empty(),"fake_child_factory_refused")
  check(not helper.delivery_complete(pretend,counterfeit,owner,{}).is_empty(),"unbound_child_receive_refused")
  check(not helper.delivery_close(pretend,counterfeit,owner,nonce,"").is_empty(),"fake_empty_flush_close_cannot_self_sign_ready")
  check(not helper.cast_preflight(pretend,counterfeit,owner,{},target).is_empty(),"unissued_cast_refused")
  check(not helper.reset_begin(pretend,counterfeit,owner,target).is_empty(),"unbound_reset_begin_refused")
  check(not helper.expiry_begin(pretend,counterfeit,owner).is_empty(),"unbound_expiry_begin_refused")
 check(helper._play.is_empty() and helper._board.is_empty() and helper._delivery.is_empty() and helper._tokens.is_empty() and helper._cast.is_empty() and helper._reset.is_empty() and helper._expiry.is_empty(),"fake_calls_create_no_success_authority")
 # Unbound completion intentionally poisons its detached helper; not a rollback.
 var unbound=MiniHost.new()
 check(not unbound.complete(pretend,fake,owner,{"ok":true}).is_empty() and not unbound._poison.is_empty(),"unbound_completion_fails_closed")
 unbound=MiniHost.new()
 check(not unbound.reset_complete(pretend,fake,owner,target).is_empty() and not unbound._poison.is_empty(),"unbound_reset_completion_fails_closed")
 unbound=MiniHost.new()
 check(not unbound.expiry_complete(pretend,fake,owner).is_empty() and not unbound._poison.is_empty(),"unbound_expiry_completion_fails_closed")
 print("DARKCREST_LAVA_PERMANENT_CONTENT_CONTRACT ",JSON.stringify({"passed":passed,"failed":failed,"failures":failures,"real_game_run":false,"scope":"detached Mini context shape and unbound authority refusal only","actual_provenance_proven":false}))
 quit(0 if failed==0 else 1)
