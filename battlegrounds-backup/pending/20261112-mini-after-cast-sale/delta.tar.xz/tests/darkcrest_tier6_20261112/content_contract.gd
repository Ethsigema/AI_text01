extends "res://tests/darkcrest_20261112/hand_shape_contract.gd"
# Pure observations of detached fixtures. Not a native acquisition or authority.
const Generation=preload("res://core/darkcrest_generation.gd")
const T6=["BG31_035","BG32_837","BG36_622","BG36_640"]
const GlobalCards=preload("res://core/bulk_global_card_stats.gd")
class FakeCatalog:
 extends RefCounted
 var cards: Dictionary={}
 func get_card(id: String) -> Dictionary:
  return cards.get(id,{})
func _initialize() -> void:
 var host=Host.new();var gen=Generation.new();var catalog=FakeCatalog.new()
 for id in T6:catalog.cards[id]=Sources.EXPECTED_HAND.get(id,{}).duplicate(true)
 var fake_game={"catalog":catalog,"Rider":{"UNIT_FIELDS":Rider.UNIT_FIELDS},"pool":{}}
 check(Generation.TIER6_IDS==T6,"exact_four_tier6_receipt_domain")
 check(Sources.proof_error().is_empty(),"complete_source_and_runtime_proof")
 for id in T6:
  var card: Dictionary=catalog.cards[id]
  check(not card.is_empty() and card.get("tier")==6,"complete_frozen_tier6_card_"+id)
  if card.is_empty():continue
  var unit=fixture(card,true)
  check(Host.candidate_source_error(id,card).is_empty(),"complete_candidate_source_"+id)
  check(Host.hand_state_error(unit,card,Rider.UNIT_FIELDS).is_empty(),"exact_unplayed_hand_shape_"+id)
  check(gen._body_error(host,fake_game,unit,6).is_empty(),"owned_stamp_shape_observation_"+id)
  for field in card:
   var bad=card.duplicate(true);bad.erase(field)
   check(not Host.candidate_source_error(id,bad).is_empty(),"missing_complete_source_field_"+id+"_"+str(field))
  for field in unit:
   var bad=unit.duplicate(true);bad.erase(field)
   check(not gen._body_error(host,fake_game,bad,6).is_empty(),"missing_owned_body_field_"+id+"_"+str(field))
  for field in ["effects","tribes","keywords"]:
   for bad_value in [null,7,"invalid",{}]:
    var bad=unit.duplicate(true);bad[field]=bad_value
    var before=bad.duplicate(true)
    check(not gen._body_error(host,fake_game,bad,6).is_empty(),"malformed_body_"+id+"_"+field+"_"+str(bad_value))
    check(Sources.same(before,bad),"malformed_check_read_only_"+id+"_"+field+"_"+str(bad_value))
  for bad_value in [null,[],7,"invalid"]:
   var bad=unit.duplicate(true);bad.base_unit=bad_value
   check(not gen._body_error(host,fake_game,bad,6).is_empty(),"malformed_base_"+id+"_"+str(bad_value))
  var bad=unit.duplicate(true);bad.extra_unregistered_state=true
  check(not gen._body_error(host,fake_game,bad,6).is_empty(),"unknown_body_field_"+id)
  bad=unit.duplicate(true);bad.pool_kind="spell"
  check(not gen._body_error(host,fake_game,bad,6).is_empty(),"foreign_pool_stamp_"+id)
  check(not gen.claimed(unit),"shape_does_not_grant_origin_"+id)
  check(not gen.begin(host,fake_game,{"id":0}).is_empty(),"dictionary_game_cannot_open_real_window_"+id)
  check(not gen.drawn(host,fake_game,{"id":0},unit).is_empty(),"dictionary_game_cannot_claim_draw_"+id)
  check(not gen.received(host,fake_game,{"id":0},unit).is_empty(),"dictionary_game_cannot_claim_delivery_"+id)
  check(not gen.completion_error(host,fake_game,{"id":0}).is_empty(),"dictionary_game_cannot_claim_completion_"+id)
  check(gen._active.is_empty() and gen._origins.is_empty(),"all_fixture_probes_leave_no_authority_"+id)
 check(Generation.domain_ids(6)==T6,"exact_four_domain_function")
 check(Generation.domain_ids(5)==Generation.IDS,"old_six_tier5_domain_preserved")
 for value in [null,0,4,7,5.0,6.0,"6",true]:
  check(Generation.domain_ids(value).is_empty(),"strict_domain_tier_"+str(value))
 var detached_ids=Generation.domain_ids(6);detached_ids.erase(T6[0]);detached_ids.append("extra")
 check(Generation.domain_ids(6)==T6,"returned_domain_copy_cannot_change_frozen_domain")
 for rt in [5,6,5.0,6.0,"6",null]:
  for gt in [5,6,6.0,"6",null]:
   for pt in [5,6,6.0,"6",null]:
    var record={"tier":rt};var grant={"tier":gt};var parent={"tier":pt}
    var before=[record.duplicate(true),grant.duplicate(true),parent.duplicate(true)]
    var valid=rt is int and gt is int and pt is int and rt in [5,6] and rt==gt and rt==pt
    check(Generation.tier_receipts_match(record,grant,parent)==valid,"tier_receipts_"+str(rt)+"_"+str(gt)+"_"+str(pt))
    check(Sources.same(before,[record,grant,parent]),"tier_receipts_read_only")
 for missing in range(3):
  var receipts=[{"tier":6},{"tier":6},{"tier":6}];receipts[missing].erase("tier")
  check(not Generation.tier_receipts_match(receipts[0],receipts[1],receipts[2]),"missing_tier_receipt_"+str(missing))
 var player={"id":0,GlobalCards.STATE:GlobalCards.zero_state()};var history_game={"GlobalCards":GlobalCards}
 check(Host.tier6_history_error(history_game,player).is_empty(),"zero_beast_history_allowed")
 for field in GlobalCards.Beasts.FIELDS:
  for value in [1,-1,1.0,"1",null]:
   var bad=player.duplicate(true);bad[GlobalCards.STATE][field]=value;var before=bad.duplicate(true)
   check(not Host.tier6_history_error(history_game,bad).is_empty(),"beast_history_held_"+field+str(value))
   check(Sources.same(before,bad),"history_check_read_only")
 player[GlobalCards.STATE].tavern_spells=4
 check(Host.tier6_history_error(history_game,player).is_empty(),"legitimate_coin_tavern_history_not_rejected")
 for id in T6:
  var ordinary=fixture(catalog.cards[id],true);var golden=ordinary.duplicate(true);golden.golden=true
  check(not gen._body_error(host,fake_game,golden,6).is_empty(),"golden_output_shape_held_"+id)
  check(not gen._body_error(host,fake_game,ordinary,5).is_empty(),"tier6_body_cannot_use_tier5_cast_"+id)
  for field in ["bulk_global_card_applied","native_fixed_dark_gift_receipt","turn_history","source_uid","birth_tier"]:
   var bad=ordinary.duplicate(true);bad[field]={"forged":true}
   check(not gen._body_error(host,fake_game,bad,6).is_empty(),"foreign_history_field_"+id+field)
 check(catalog.cards["BG36_640"].tribes.has("全部") or catalog.cards["BG36_640"].tribes.has("all"),"gatekeeper_all_tribe_retained")
 # Detached host-only mismatch fixtures never open an actual Game/cast window.
 for rt in [5,6]:
  for gt in [5,6]:
   for pt in [5,6]:
    if rt==gt and rt==pt:continue
    var h=Host.new();var token={"uid":"fixture_token"};var parent_unit={"uid":"fixture_parent"}
    h._spells[token.uid]={"unit":token,"id":"BG31_920t","tier":rt,"owner":0,"round":6,"used":false,"source_uid":parent_unit.uid}
    h._grants[parent_unit.uid]={"unit":parent_unit,"id":"BG31_920","tier":gt,"owner":0,"round":6,"delivered":true,"blocked":false}
    h._parents[parent_unit.uid]={"unit":parent_unit,"id":"BG31_920","tier":pt}
    var player_fixture={"id":0,"hand":[token]};var game_fixture={"state":{"round":6},"pool":{"a":7},"next_uid":42,"rng_state":"detached-sentinel"}
    var before=[h._spells.duplicate(true),h._grants.duplicate(true),h._parents.duplicate(true),player_fixture.duplicate(true),game_fixture.duplicate(true)]
    check(h.generation_preconsume_error(game_fixture,player_fixture,token)=="darkcrest_generation_cross_tier_receipts","preconsume_cross_tier_rejected_"+str(rt)+str(gt)+str(pt))
    check(Sources.same(before,[h._spells,h._grants,h._parents,player_fixture,game_fixture]),"preconsume_cross_tier_no_fixture_mutation")
 check(not Host.candidate_source_error("UNREVIEWED_ENABLED_NAGA",catalog.cards[T6[0]]).is_empty(),"unknown_enabled_source_cannot_be_silently_filtered")
 for id in T6:
  check(not Host.candidate_source_error(id,{}).is_empty(),"missing_enabled_positive_source_rejected_"+id)
 var first={"uid":"same-value"};var second={"uid":"second"}
 check(Generation._same_objects([first,second],[first,second]),"same_original_ordered_objects")
 check(not Generation._same_objects([first,second],[second,first]),"reordered_objects_rejected")
 check(not Generation._same_objects([first],[first.duplicate(true)]),"equal_deep_copy_is_not_identity")
 check(not Generation._same_objects([first],[]),"missing_object_rejected")
 # Pure numeric admission and detached identity/stock observations only.
 for sample in [{"value":0,"valid":true},{"value":1,"valid":true},{"value":2147483647,"valid":true},{"value":2147483648,"valid":false},{"value":-1,"valid":false},{"value":2.0,"valid":false},{"value":2.5,"valid":false},{"value":"2","valid":false},{"value":true,"valid":false},{"value":null,"valid":false}]:
  check(Generation._integer(sample.value,0,2147483647)==sample.valid,"bounded_integral_stock_scalar_"+str(sample.value))
 var seen={"uid":"observed_u","card_id":"BG31_920"}
 var zones={"state":{"players":[{"hand":[seen],"board":[],"shop":[]}],"ghosts":[]}}
 var before_zones=zones.duplicate(true)
 check(Generation._occurrences(zones,seen)==1,"one_original_hand_occurrence")
 check(Sources.same(before_zones,zones),"occurrence_observation_read_only")
 zones.state.players[0].board.append(seen.duplicate(true))
 check(Generation._occurrences(zones,seen)==2,"same_uid_copy_counts_as_duplicate")
 zones.state.ghosts.append({"hand":[],"board":[seen],"shop":[]})
 check(Generation._occurrences(zones,seen)==3,"ghost_occurrence_not_ignored")
 gen._active={"pool":{"a":3,"b":2}}
 for pool in [{"a":2,"b":2},{"a":3,"b":2},{"a":1,"b":2},{"a":2,"b":1},{"a":2},{"a":2,"b":2,"extra":1},{"a":"2","b":2},{"a":2.0,"b":2},{"a":-1,"b":2}]:
  var original=pool.duplicate(true);var active=gen._active.duplicate(true)
  var issue=gen._pool_error({"pool":pool},"a")
  var valid=pool.get("a") is int and pool.get("b") is int and Sources.same(pool,{"a":2,"b":2})
  check(issue.is_empty() if valid else not issue.is_empty(),"exact_whole_stock_observation_"+JSON.stringify(pool))
  check(Sources.same(original,pool) and Sources.same(active,gen._active),"stock_observation_read_only_"+JSON.stringify(pool))
 gen.cancel()
 check(gen._active.is_empty() and gen._origins.is_empty(),"cancel_without_origin_never_creates_one")
 print("DARKCREST_TIER6_CONTENT_CONTRACT ",JSON.stringify({"passed":passed,"failed":failed,"failures":failures,"ids":T6,"real_game_run":false,"scope":"pure fixture content and identity observations only, not actual acquisition or provenance"}))
 quit(0 if failed==0 else 1)
