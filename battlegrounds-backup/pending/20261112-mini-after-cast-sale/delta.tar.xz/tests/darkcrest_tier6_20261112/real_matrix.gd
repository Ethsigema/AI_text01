extends "res://tests/darkcrest_tier5_20261112/real_matrix.gd"
# New boundary test; does not execute old Tier5 _initialize or its 5→6-held assertion.
const T6=["BG31_035","BG32_837","BG36_622","BG36_640"]
const ROOM6=["BG36_921","BG31_330","BG23_000","BG23_009","BG23_002","BG31_924","BG23_007","BG23_004","BG26_505","BG34_925","BG33_319","BG36_508","BG35_921","BG23_008","BG31_920","BG31_925","BG32_111","BG32_820","BG32_835","BG31_035","BG32_837","BG36_622","BG36_640"]
const SEEDS6=[20261120,20261121,20261122,20261123,20261124,20261125,20261126,20261127,20261128,20261129,20261130,20261131,20261132,20261133,20261134,20261135]
var tier6_records=[]
var tier6_coverage={}
func fund(target: int) -> bool:
 var p=game.state.players[0]
 if not must(not (p.board+p.hand).any(func(u):return u.get("card_id")=="BG31_920"),"coin_fixture_only_before_darkcrest_owned"):return false
 return super.fund(target)
func setup_room(seed_value: int) -> bool:
 game=load("res://core/game.gd").new()
 var room=load("res://core/room_config.gd").new();room.reset(cat)
 room.data.enabled_minions=ROOM6.duplicate();room.data.enabled_spells=["BG28_810"]
 room.data.selected_hero="TB_BaconShop_HERO_01";room.data.enabled_heroes=["TB_BaconShop_HERO_01"];room.data.bot_count=3;room.data.seed=seed_value
 for key in ["enabled_anomalies","enabled_quests","enabled_rewards","enabled_trinkets"]:room.data[key]=[]
 if not must(game.start(room.data,cat).get("ok",false) and game.state.players.size()==4,"native_four_player_tier6_room_"+str(seed_value)):return false
 var p=game.state.players[0]
 for tier in [2,3,4,5,6]:
  if not must(fund(int(p.upgrade_cost)+3),"pre_source_coin_funding_"+str(tier)):return false
  if not must(command(0,{"type":"upgrade"}).get("ok",false) and p.tier==tier,"pre_source_native_tavern_upgrade_"+str(tier)):return false
 return fund(10)
func nonuniform(choices: Array) -> bool:
 if choices.is_empty():return false
 return choices.any(func(c):return c.stock!=choices[0].stock)
func prepare_native_weights() -> bool:
 var p=game.state.players[0]
 for attempt in range(9):
  var domain=game.BulkResourceHost.domain(game)
  var choices=game.BulkResourceHost.candidates(domain,domain.stock,{"kind":"minion","tier":6,"tribe":"纳迦"})
  if choices.map(func(c):return c.id)==T6 and choices.all(func(c):return c.stock>0) and nonuniform(choices):
   print("TIER6_NATIVE_WEIGHTS ",JSON.stringify({"refreshes":attempt,"choices":choices,"gold":p.gold}));return true
  if attempt==8 or p.gold<1:break
  if not must(command(0,{"type":"roll"}).get("ok",false),"public_refresh_only_no_coin_after_source_"+str(attempt)):return false
 return must(false,"complete_positive_nonuniform_domain_not_reached_with_native_gold_budget")
func cast_tier6(parent: Dictionary,seed_value: int) -> Dictionary:
 var p=game.state.players[0];var host=game._darkcrest_host
 var tokens=p.hand.filter(func(u):return u.card_id=="BG31_920t")
 if not must(tokens.size()==1 and host._spells[tokens[0].uid].tier==6 and host._spells[tokens[0].uid].source_uid==parent.uid,"actual_tier6_issued_source_snapshot"):return {}
 var token=tokens[0];var before_preconsume=live_snapshot()
 if not must(host.generation_preconsume_error(game,p,token).is_empty(),"actual_tier6_preconsume_original_receipts"):return {}
 if not must(not host.generation_preconsume_error(game,p,token.duplicate(true)).is_empty(),"copied_token_rejected_before_consumption"):return {}
 if not must(game.Darkcrest.Sources.same(before_preconsume,live_snapshot()),"preconsume_checks_leave_rng_pool_uid_hand_unchanged"):return {}
 var domain=game.BulkResourceHost.domain(game)
 var choices=game.BulkResourceHost.candidates(domain,domain.stock,{"kind":"minion","tier":6,"tribe":"纳迦"})
 if not must(choices.map(func(c):return c.id)==T6 and choices.all(func(c):return c.stock>0) and nonuniform(choices),"complete_four_positive_nonuniform_native_candidates"):return {}
 var total=0
 for choice in choices:total+=choice.stock
 var old_hand=p.hand.duplicate();var before_uids=p.hand.map(func(u):return u.uid);var before_pool=game.pool.duplicate(true);var uid_before=game.next_uid;var event_before=game.events.size();var spell_before=p.stats.spells;var history=p[game.GlobalCards.STATE].tavern_spells
 # Observe one native RNG step using an isolated generator, never the live RNG.
 var probe=RandomNumberGenerator.new();probe.seed=game.rng.seed;probe.state=game.rng.state
 var predicted_ticket=probe.randi_range(0,total-1)
 if not must(command(0,{"type":"play","index":p.hand.find(token),"target":-1,"position":-1}).get("ok",false),"native_tier6_public_cast"):return {}
 var added=p.hand.filter(func(u):return u.uid not in before_uids)
 if not must(added.size()==1,"single_original_tier6_delivery"):return {}
 var unit=added[0]
 if not must(unit.card_id in T6 and unit.tier==6 and unit.uid=="u"+str(uid_before) and game.next_uid==uid_before+1 and unit.pool_kind=="minion" and unit.pool_id==unit.card_id and unit.pool_count==1,"native_owned_factory_uid_and_stamp"):return {}
 var changed=[]
 for id in before_pool:
  if before_pool[id]!=game.pool.get(id):changed.append(id)
 if not must(game.pool.size()==before_pool.size() and changed==[unit.card_id] and game.pool[unit.card_id]==before_pool[unit.card_id]-1,"single_exact_native_stock_debit"):return {}
 var random_events=game.events.slice(event_before).filter(func(e):return e.get("type")=="rng" and e.get("reason")=="random_generated_minion")
 if not must(random_events.size()==1 and random_events[0].range==total,"original_full_weight_random_draw"):return {}
 if not must(game.rng.state==probe.state and random_events[0].value==predicted_ticket,"one_exact_native_rng_state_step"):return {}
 var ticket=random_events[0].value;var expected=""
 for choice in choices:
  if ticket<choice.stock:expected=choice.id;break
  ticket-=choice.stock
 if not must(expected==unit.card_id,"actual_ticket_selects_actual_output"):return {}
 if not must(not p.hand.has(token) and p.stats.spells==spell_before+1 and p[game.GlobalCards.STATE].tavern_spells==history,"single_consumption_not_tavern_spell_history"):return {}
 if not must(host._cast.is_empty() and host._generation._active.is_empty(),"public_play_clears_transient_generation_window"):return {}
 if not must(host.owner_error(game,p).is_empty() and host.hand_state_error(unit,cat.get_card(unit.card_id),game.Rider.UNIT_FIELDS).is_empty(),"actual_tier6_owner_and_native_hand_shape_valid"):return {}
 for old in old_hand:
  if is_same(old,token):continue
  if not must(p.hand.any(func(u):return is_same(u,old)),"existing_hand_original_object_retained"):return {}
 if not must(not host._generation.claimed(unit),"tier6_output_never_receives_parent_origin"):return {}
 if not rejection_contracts(unit) or not generation_rejections(unit):return {}
 tier6_records.append({"seed":seed_value,"id":unit.card_id,"uid":unit.uid,"source_uid":parent.uid,"token_uid":token.uid,"choices":choices,"rng":random_events[0],"tavern_history":history})
 return unit

func tier6_case(seed_value: int,lower_regression: bool) -> bool:
 if not setup_room(seed_value):return false
 var p=game.state.players[0];var parent=quick_parent()
 if parent.is_empty() or not source_play(parent):return false
 for tier in [1,2,3,4,5]:
  var old=p.hand.filter(func(u):return u.card_id=="BG31_920t")
  if lower_regression:
   if tier<5:
    if not cast_level(parent,tier):return false
   elif cast_tier5(parent,seed_value).is_empty():return false
  if not next_round(parent,tier+1):return false
  if not lower_regression and not must(not p.hand.any(func(u):return u.uid==old[0].uid),"native_uncast_expiry_tier"+str(tier)):return false
 if not must(game._darkcrest_host._parents[parent.uid].tier==6 and game.state.round==6,"five_actual_eot_growths_to_tier6"):return false
 if not prepare_native_weights():return false
 var unit=cast_tier6(parent,seed_value)
 if unit.is_empty():return false
 tier6_coverage[unit.card_id]=int(tier6_coverage.get(unit.card_id,0))+1
 var before=held_snapshot();var held=game.apply_command(0,{"type":"end_turn"})
 if not must(not held.get("ok",true) and held.error=="darkcrest_next_tier_outside_finite_candidate" and game.Darkcrest.Sources.same(before,held_snapshot()),"post_tier6_eot_held_without_mutation"):return false
 before=held_snapshot();held=game.apply_command(0,{"type":"play","index":p.hand.find(unit),"target":-1,"position":-1})
 if not must(not held.get("ok",true) and held.error=="darkcrest_other_play_held" and game.Darkcrest.Sources.same(before,held_snapshot()),"tier6_output_gameplay_not_opened"):return false
 print("TIER6_CASE_PASS ",JSON.stringify(tier6_records.back()))
 return true
func _initialize():
 print("TIER6_REAL_MATRIX_LOAD_BEGIN")
 var Game=load("res://core/game.gd")
 if not must(Game!=null and Game.can_instantiate(),"complete_game_script"):return
 cat=load("res://core/catalog.gd").new();cat.load_catalog()
 if not must(cat.load_errors.is_empty(),"complete_catalog"):return
 for index in range(SEEDS6.size()):
  if not tier6_case(SEEDS6[index],index==0):return
  if tier6_coverage.size()==4:break
 if not must(tier6_coverage.size()==4,"all_four_full_domain_native_outputs_observed"):return
 # Existing Tier5 triple boundary remains applicable, unlike its obsolete 5→6 held check.
 if not triple_boundary_case():return
 var result={"scope":"ordinary Darkcrest tier6 native hand acquisition only","checks":checks,"coverage":tier6_coverage,"cases":tier6_records,"lower_tier_records":records,"four_player_rooms":true,"five_actual_eots":true,"old_tier5_full_matrix_repeated":false,"tier5_triple_boundary_reused":true,"golden_gameplay_tested":false,"other_output_abilities_opened":false,"no_live_state_injection":true,"seed_plan":SEEDS6}
 var file=FileAccess.open(get_script().resource_path.get_base_dir()+"/TIER6_MATRIX_RESULT.json",FileAccess.WRITE)
 if not must(file!=null,"matrix_result_file"):return
 file.store_string(JSON.stringify(result,"  ")+"\n");file.close()
 print("DARKCREST_TIER6_REAL_MATRIX_PASS cases=",tier6_records.size()," checks=",checks," coverage=",JSON.stringify(tier6_coverage))
 quit(0)
