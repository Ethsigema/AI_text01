extends SceneTree
var Game
var cat
var game
var checks=0
var cases=0
func must(ok: bool,label: String) -> bool:
 checks+=1
 print("PASS " if ok else "FAIL ",label)
 if not ok: quit(1)
 return ok
func give_play(player: int,id: String) -> Dictionary:
 var card=cat.get_card(id)
 if card.is_empty():return {}
 var unit=game._unit(card)
 var p=game.state.players[player]
 game._add_hand(p,unit)
 var result=game.apply_command(player,{"type":"play","index":p.hand.find(unit),"target":-1,"position":-1})
 return unit if result.get("ok",false) else {}
func run_case(id: String, count: int, titus_id: String="",enemy_count: int=0) -> bool:
 cases+=1
 var label=id+"_spells"+str(count)+"_titus"+titus_id+"_enemy"+str(enemy_count)
 print("CASE_BEGIN ",label)
 game=Game.new()
 var room=load("res://core/room_config.gd").new()
 room.reset(cat)
 room.data.enabled_minions=["BG31_925","BG31_035","BG23_000","BG23_007","BG25_354"]
 room.data.enabled_spells=["BG28_810"]
 room.data.selected_hero="TB_BaconShop_HERO_01"
 room.data.enabled_heroes=["TB_BaconShop_HERO_01"]
 room.data.bot_count=1
 room.data.seed=2026
 for key in ["enabled_anomalies","enabled_quests","enabled_rewards","enabled_trinkets"]:room.data[key]=[]
 if not must(game.start(room.data,cat).get("ok",false),label+"_real_limited_room"):return false
 var rider=give_play(0,id)
 var mini=give_play(0,"BG23_000")
 var wave=give_play(0,"BG23_007")
 var titus={}
 if not titus_id.is_empty():titus=give_play(0,titus_id)
 var enemy=give_play(1,"BG31_035_G")
 if not must(not rider.is_empty() and not mini.is_empty() and not wave.is_empty() and not enemy.is_empty() and (titus_id.is_empty() or not titus.is_empty()),label+"_native_factory_public_plays"):return false
 for side in [0,1]:
  for i in range(count if side==0 else enemy_count):
   if not must(not give_play(side,"BG28_810").is_empty(),label+"_actual_coin_side"+str(side)+"_"+str(i+1)):return false
 var p=game.state.players[0]
 if not must(p.stats.spells==count and game.state.players[1].stats.spells==enemy_count,label+"_actual_owner_spell_counts"):return false
 var before=p.board.duplicate(true)
 if not must(game.Rider.round_error(game).is_empty(),label+"_preflight"):return false
 if not must(game.apply_command(1,{"type":"end_turn"}).get("ok",false) and game.state.players[1].ready,label+"_public_opponent_ready"):return false
 var ended=game.apply_command(0,{"type":"end_turn"})
 if not ended.get("ok",false):print("END_FAILURE ",JSON.stringify(ended)," events=",JSON.stringify(game.events.slice(-3)))
 if not must(ended.get("ok",false) and game.last_combats.size()==1,label+"_real_end_turn_combat"):return false
 var result=game.last_combats[0]
 if not must(str(result.get("error","")).is_empty(),label+"_original_combat_success"):return false
 var deaths=result.log.filter(func(e):return e.get("event")=="death" and e.get("unit")==rider.uid)
 var buffs=result.log.filter(func(e):return e.get("event")=="buff" and e.get("source")==rider.uid)
 print("RIDER_EVIDENCE ",label," ",JSON.stringify({"deaths":deaths,"buffs":buffs}))
 if not must(deaths.size()==1 and not buffs.is_empty(),label+"_natural_death_and_native_commits"):return false
 var multiplier=2 if id.ends_with("_G") else 1
 var attack=2*multiplier*(1+count/3)
 var health=multiplier*(1+count/3)
 var repeat_count=1 if titus_id.is_empty() else (3 if titus_id.ends_with("_G") else 2)
 var target_hits={}
 for buff in buffs:
  if not must(buff.attack_delta==attack and buff.health_delta==health,label+"_native_buff_amount"):return false
  var target=before.filter(func(u):return u.uid==buff.target)
  if not must(target.size()==1 and "纳迦" in target[0].tribes and buff.target!=rider.uid,label+"_living_friendly_naga_only"):return false
  target_hits[buff.target]=int(target_hits.get(buff.target,0))+1
  if not must(buff.attack==target[0].attack+attack*target_hits[buff.target],label+"_cumulative_native_stat_commit"):return false
 for target in target_hits:
  if not must(target_hits[target]==repeat_count,label+"_native_deathrattle_repetition"):return false
 for unit in p.board:
  var original=before.filter(func(u):return u.uid==unit.uid)
  if not original.is_empty():
   if not must(unit.attack==original[0].attack and unit.health==original[0].health,label+"_no_combat_buff_recruit_writeback"):return false
 if not must(game._rider_combat_authority.is_empty(),label+"_game_authority_released"):return false
 if not must(game.state.phase=="recruit" and game.state.round==2,label+"_next_recruit_round"):return false
 print("CASE_PASS ",label)
 game=null
 return true
func _initialize():
 print("LOAD_BEGIN")
 Game=load("res://core/game.gd")
 cat=load("res://core/catalog.gd").new()
 cat.load_catalog()
 if not must(cat.load_errors.is_empty(),"real_catalog_with_rider_overlay"):return
 for id in ["BG31_925","BG31_925_G"]:
  if not must(not cat.get_card(id).is_empty(),"native_card_"+id):return
  for count in [0,2,3,6]:
   if not run_case(id,count):return
 if not run_case("BG31_925",3,"BG25_354"):return
 if not run_case("BG31_925_G",6,"BG25_354_G"):return
 if not run_case("BG31_925",0,"",6):return
 print("RIDER_MATRIX_PASS cases=",cases," checks=",checks)
 quit(0)
