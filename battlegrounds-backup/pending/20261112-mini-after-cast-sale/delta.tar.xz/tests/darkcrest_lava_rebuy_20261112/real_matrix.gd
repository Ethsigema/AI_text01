extends "res://tests/darkcrest_lava_sale_20261112/real_matrix.gd"
# One new closed lifecycle only. All older initializers are overridden.
var purchases=[]
var public_holds=[]
func live_snapshot() -> Dictionary:
 var result=super.live_snapshot();var h=game._darkcrest_host
 for key in ["_purchase_projection","_cast","_delivery","_delivery_receipts","_eot"]:result[key]=h.get(key).duplicate(true)
 return result
func receipt_refs() -> Dictionary:
 var h=game._darkcrest_host;var out={}
 for key in ["_parents","_grants","_spells"]:out[key]=h.get(key).duplicate(false)
 return out
func same_receipt_refs(before: Dictionary) -> bool:
 for key in before:
  var now=game._darkcrest_host.get(key)
  if now.size()!=before[key].size():return false
  for uid in before[key]:
   if not is_same(now.get(uid),before[key][uid]):return false
 return true
func held_buy(offer: Dictionary,label: String) -> bool:
 var p=game.state.players[0];var cmd={"type":"buy","index":p.shop.find(offer)}
 var before=live_snapshot();var refs=receipt_refs()
 var issue=game._darkcrest_host.command_error(game,p,cmd)
 if not must(not issue.is_empty(),label+"_preflight_held"):return false
 if not must(game.Darkcrest.Sources.same(before,live_snapshot()) and same_receipt_refs(refs),label+"_preflight_read_only"):return false
 # Original _fail returns an error and clears temporary contexts, not phase=error.
 # All windows are empty here; complete state equality still must be observed.
 var result=game.apply_command(0,cmd)
 if not must(not result.get("ok",true),label+"_public_buy_held"):return false
 if not must(game.Darkcrest.Sources.same(before,live_snapshot()) and same_receipt_refs(refs) and is_same(p.shop[cmd.index],offer),label+"_public_rejection_no_consumption"):return false
 public_holds.append({"kind":label,"error":result.get("error"),"uid":offer.uid,"round":game.state.round})
 return true
func aliased_shadow_refusals(offer: Dictionary) -> bool:
 var p=game.state.players[0];var before=live_snapshot();var refs=receipt_refs();var cmd={"type":"buy","index":p.shop.find(offer)}
 for field in ["stats","effects"]:
  var detached=game.OwnedPurchases.Prefix.create(game,projection_cursor(p))
  if not must(detached.get("ok",false),"native_detached_alias_fixture_"+field):return false
  var shadow=detached.engine;var owner=shadow.state.players[0];var h=shadow._darkcrest_host
  # Only detached shadow references are changed; no live nested value is edited.
  if field=="stats":owner.stats=p.stats
  else:owner.board[0].effects=p.board[0].effects
  var issue=game._darkcrest_host.bind_purchase_projection(game,shadow,0,cmd)
  if not must(not issue.is_empty() and h._parents.is_empty() and h._purchase_projection.is_empty() and not h._projection_only,"shared_nested_shadow_bind_refused_before_install_"+field):return false
  if not must(game.Darkcrest.Sources.same(before,live_snapshot()) and same_receipt_refs(refs),"shared_nested_refusal_preserves_live_originals_"+field):return false
 return true
func bound_projection_refusals(offer: Dictionary) -> bool:
 var p=game.state.players[0];var before=live_snapshot();var refs=receipt_refs();var cmd={"type":"buy","index":p.shop.find(offer)}
 var detached=game.OwnedPurchases.Prefix.create(game,projection_cursor(p))
 if not must(detached.get("ok",false),"native_detached_purchase_cursor"):return false
 var shadow=detached.engine;var h=shadow._darkcrest_host;var owner=shadow.state.players[0]
 var issue=game._darkcrest_host.bind_purchase_projection(game,shadow,0,cmd)
 if not must(issue.is_empty(),"actual_lava_projection_bound_for_refusal_checks"):print("PROJECTION_ISSUE ",issue);return false
 if not must(h._projection_only and h._grants.is_empty() and h._spells.is_empty() and h._lava_play._board.is_empty() and h._lava_play._retired.is_empty(),"shadow_does_not_copy_live_issuance_or_retirement"):return false
 var parent_copy=owner.board[0]
 if not must(not h.queue_error(shadow,owner,[parent_copy]).is_empty() and not h.register_grants(shadow,owner,[parent_copy]).is_empty(),"bound_shadow_direct_grant_refused"):return false
 if not must(not h.begin_cast(shadow,owner,0).is_empty() and not h.consume(owner,{},{}).get("ok",true),"bound_shadow_direct_cast_refused"):return false
 if not must(not h.end_error(shadow,owner).is_empty() and not h.begin_eot(shadow,owner,{}).is_empty(),"bound_shadow_direct_eot_refused"):return false
 if not must(not h._lava_play._actual(h,shadow,owner),"bound_shadow_cannot_authorize_lava_play_or_sale"):return false
 if not must(not h._generation.begin(h,shadow,owner).is_empty(),"bound_shadow_direct_generation_refused"):return false
 if not must(h._grants.is_empty() and h._spells.is_empty() and h._cast.is_empty() and h._eot.is_empty() and h._generation._active.is_empty(),"bound_shadow_negative_calls_issue_no_receipts"):return false
 var sale_refusal=shadow._native_sale_operation_begin(owner,0)
 if not must(not sale_refusal.get("ok",true) and sale_refusal.get("error")=="darkcrest_projection_sale_held" and shadow._native_sale_operation_context.is_empty(),"bound_shadow_low_level_native_sale_refused"):return false
 h.release_purchase_projection()
 if not must(h._projection_only and h._parents.is_empty() and h._purchase_projection.is_empty() and not h.command_error(shadow,owner,cmd).is_empty(),"released_shadow_never_becomes_live_authority"):return false
 return must(game.Darkcrest.Sources.same(before,live_snapshot()) and same_receipt_refs(refs),"all_bound_shadow_checks_leave_live_originals_unchanged")
func buy_active_lava(offer: Dictionary,parent: Dictionary) -> bool:
 var p=game.state.players[0];var h=game._darkcrest_host;var cmd={"type":"buy","index":p.shop.find(offer)}
 if not must(p.board.any(func(u):return is_same(u,parent)) and h._parents[parent.uid].tier>=2 and h._parents[parent.uid].shop_origin,"mature_original_shop_source_active"):return false
 if not must(not (p.hand+p.board).any(func(u):return u.card_id==LAVA) and not p.hand.any(func(u):return u.card_id=="BG31_920t"),"zero_owned_lava_no_current_token"):return false
 var before=live_snapshot();var refs=receipt_refs()
 var issue=game.OwnedPurchases.command_preflight(game,0,cmd)
 if not must(issue.is_empty(),"actual_full_ownedpurchase_shadow_passes"):print("PROJECTION_ISSUE ",issue);return false
 if not must(game.Darkcrest.Sources.same(before,live_snapshot()) and same_receipt_refs(refs),"purchase_projection_preserves_live_state_and_receipt_refs"):return false
 var hand=p.hand.duplicate();var hand_values=p.hand.duplicate(true);var board=p.board.duplicate();var board_values=p.board.duplicate(true)
 var offer_values=offer.duplicate(true);var shop=p.shop.duplicate();var shop_values=p.shop.duplicate(true);shop.remove_at(cmd.index);shop_values.remove_at(cmd.index)
 var gold=p.gold;var bought=p.stats.bought;var minions=p.stats.bought_minions;var uid=game.next_uid;var rng=game.rng.state;var seed=game.rng.seed;var pool=game.pool.duplicate(true);var spells=game.spell_pool.duplicate(true)
 if not must(gold>=3,"natural_gold_available_for_native_lava_purchase"):return false
 if not must(command(0,cmd).get("ok",false),"public_active_original_lava_buy"):return false
 hand.append(offer);hand_values.append(offer_values)
 if not must(h.Generation._same_objects(p.hand,hand) and game.Darkcrest.Sources.same(p.hand,hand_values) and h.Generation._same_objects(p.board,board) and game.Darkcrest.Sources.same(p.board,board_values) and h.Generation._same_objects(p.shop,shop) and game.Darkcrest.Sources.same(p.shop,shop_values),"purchase_only_original_offer_hand_transfer"):return false
 if not must(p.gold==gold-3 and p.stats.bought==bought+1 and p.stats.bought_minions==minions+1,"native_purchase_exact_gold_and_counters"):return false
 if not must(game.next_uid==uid and game.rng.state==rng and game.rng.seed==seed and game.Darkcrest.Sources.same(pool,game.pool) and game.Darkcrest.Sources.same(spells,game.spell_pool),"purchase_no_second_stock_uid_rng_change"):return false
 if not must(same_receipt_refs(refs) and h._purchase_projection.is_empty(),"live_historical_receipts_preserved_projection_released"):return false
 purchases.append({"uid":offer.uid,"source_uid":parent.uid,"source_tier":h._parents[parent.uid].tier,"round":game.state.round,"gold_before":gold,"gold_after":p.gold,"bought_before":bought,"bought_after":p.stats.bought,"next_uid_before":uid,"next_uid_after":game.next_uid,"rng_before":rng,"rng_after":game.rng.state})
 return true
func rebuy_case() -> bool:
 if not setup_room(20261120):return false
 var p=game.state.players[0];var parent={};var first={};var second={};var first_rolls=0;var cooffer_rolls=0
 for attempt in range(101):
  var available=p.shop.filter(func(u):return u.card_id==LAVA and not u.golden)
  if not available.is_empty():first=available[0];break
  if attempt==100:break
  if not fund(4) or not command(0,{"type":"roll"}).get("ok",false):return false
  first_rolls+=1
 if not must(not first.is_empty(),"bounded_native_first_lava_before_source_found"):return false
 if not fund(6):return false
 var first_gold=p.gold;var first_bought=p.stats.bought;var first_uid=game.next_uid;var first_rng=game.rng.state;var first_pool=game.pool.duplicate(true)
 if not must(command(0,{"type":"buy","index":p.shop.find(first)}).get("ok",false) and p.hand.any(func(u):return is_same(u,first)),"first_original_lava_buy_before_source"):return false
 if not must(p.gold==first_gold-3 and p.stats.bought==first_bought+1 and game.next_uid==first_uid and game.rng.state==first_rng and game.Darkcrest.Sources.same(first_pool,game.pool),"first_pre_source_buy_native_deltas"):return false
 var first_buy={"uid":first.uid,"gold_before":first_gold,"gold_after":p.gold,"source_owned":false,"active_purchase":false}
 for attempt in range(241):
  var sources=p.shop.filter(func(u):return u.card_id=="BG31_920" and not u.golden)
  var lavas=p.shop.filter(func(u):return u.card_id==LAVA and not u.golden)
  if not sources.is_empty() and not lavas.is_empty():parent=sources[0];second=lavas[0];break
  if attempt==240:break
  if not fund(4) or not command(0,{"type":"roll"}).get("ok",false):return false
  cooffer_rolls+=1
 if not must(not parent.is_empty() and not second.is_empty(),"bounded_native_same_shop_source_single_lava_found"):return false
 if not must(first.uid!=second.uid and not is_same(first,second),"two_original_lava_objects_distinct_before_source"):return false
 var original_offer_uids=[first.uid,second.uid]
 if not fund(6):return false
 if not must(command(0,{"type":"buy","index":p.shop.find(parent)}).get("ok",false),"original_shop_darkcrest_purchase"):return false
 if not source_play(parent):return false
 for tier in [2,3]:
  if not p.frozen:
   if not must(command(0,{"type":"freeze"}).get("ok",false),"public_preserve_shop_before_eot_"+str(tier)):return false
  if not next_round(parent,tier):return false
  if not must(p.shop.any(func(v):return is_same(second,v)) and p.hand.any(func(v):return is_same(first,v)),"original_lava_hand_and_shop_survive_real_recruit_"+str(tier)):return false
 # Owned-Lava guard precedes token guard, so prove each on its actual applicable state.
 if not held_buy(second,"already_owned_lava_purchase"):return false
 if not public_lava_play(first,0) or not public_sale(first):return false
 var retired=game._darkcrest_host._lava_play._retired[first.uid].duplicate(true)
 if not held_buy(second,"current_token_purchase"):return false
 if not cast_level(parent,3):return false
 if not must(p.gold>=3,"natural_gold_covers_single_active_rebuy"):return false
 if not aliased_shadow_refusals(second) or not bound_projection_refusals(second):return false
 if not buy_active_lava(second,parent) or not public_lava_play(second,0):return false
 if not must(game.Darkcrest.Sources.same(retired,game._darkcrest_host._lava_play._retired[first.uid]) and not game._darkcrest_host._lava_play._board.has(first.uid) and game._darkcrest_host._lava_play._board.has(second.uid),"distinct_uid_new_play_record_old_retirement_preserved"):return false
 if not sale_retirement_check(first):return false
 if not prepare_real_opponents() or not next_round(parent,4) or not inspect_lava_combat(second):return false
 var row={"kind":"pre_source_lava_sale_mature_source_different_uid_rebuy","seed":20261120,"pre_source_first_lava_rolls":first_rolls,"pre_source_cooffer_rolls":cooffer_rolls,"offer_uids":original_offer_uids,"source_uid":parent.uid,"source_tier":4,"final_round":game.state.round,"first_buy_before_source":true,"active_purchase_count":1,"first_purchase":first_buy,"offer_created_after_first_sale":false,"second_offer_created_before_source":true,"post_sale_new_offer_generation_tested":false,"retirement":retired,"purchases":purchases,"sale_effects":sale_effects,"holds":public_holds}
 sale_cases.append(row);print("DARKCREST_LAVA_REBUY_CASE_PASS ",JSON.stringify(row));return true
func _initialize():
 print("DARKCREST_LAVA_REBUY_MATRIX_LOAD_BEGIN")
 var Game=load("res://core/game.gd")
 if not must(Game!=null and Game.can_instantiate(),"complete_game_script"):return
 cat=load("res://core/catalog.gd").new();cat.load_catalog()
 if not must(cat.load_errors.is_empty(),"complete_catalog"):return
 if not rebuy_case():return
 var result={"scope":"ordinary mature shop-origin Darkcrest no-token Lava purchase sale different-original-UID rebuy only","checks":checks,"cases":sale_cases,"coin_pre_source_fixture":true,"entirely_natural_game":false,"old_matrices_repeated":false,"post_sale_new_offer_generation_tested":false,"no_live_state_injection":true}
 var file=FileAccess.open(get_script().resource_path.get_base_dir()+"/DARKCREST_LAVA_REBUY_MATRIX_RESULT.json",FileAccess.WRITE)
 if not must(file!=null,"matrix_result_file"):return
 file.store_string(JSON.stringify(result,"  ")+"\n");file.close()
 print("DARKCREST_LAVA_REBUY_REAL_MATRIX_PASS cases=",sale_cases.size()," checks=",checks)
 quit(0)
