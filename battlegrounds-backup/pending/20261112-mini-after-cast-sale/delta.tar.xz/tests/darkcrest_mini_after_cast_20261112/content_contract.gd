extends "res://tests/darkcrest_mini_sale_20261112/content_contract.gd"
# Consumed-history content only. No real Game, no issued authority fabricated.
func consumed_ok(host,r,p,zones=[]) -> bool:
 return MiniHost.consumed_sale_record_error(host,r,p,"u20",3,6,zones).is_empty()
func _initialize():
 check(Sources.proof_error().is_empty(),"complete_after_cast_source_runtime_proof")
 var host=Host.new();var owner={"id":0};var token=child_fixture()
 var record={"owner":owner,"unit":token,"source_uid":"u20","round":3,"ready":true,"used":true,"cast_sequence":5,"cast_target_uid":"u30","snapshot":token.duplicate(true)}
 check(consumed_ok(host,record,owner),"detached_consumed_history_content_not_authority")
 var explicit=record.duplicate(false);explicit.expired=false
 check(consumed_ok(host,explicit,owner),"explicit_unexpired_consumed_content")
 for key in record:
  var bad=record.duplicate(false);bad.erase(key)
  check(not consumed_ok(host,bad,owner),"missing_consumed_history_"+key)
 check(not consumed_ok(host,record,owner.duplicate(true)),"copied_history_owner_refused")
 for value in [null,1,true,"u21",StringName("u20")]:
  var bad=record.duplicate(false);bad.source_uid=value
  check(not consumed_ok(host,bad,owner),"wrong_consumed_source_"+str(value))
 for value in [null,true,3.0,"3",2,4]:
  var bad=record.duplicate(false);bad.round=value
  check(not consumed_ok(host,bad,owner),"wrong_consumed_round_"+str(value))
 for key in ["ready","used"]:
  for value in [null,false,0,1,"true"]:
   var bad=record.duplicate(false);bad[key]=value
   check(not consumed_ok(host,bad,owner),"incomplete_consumed_flag_"+key+str(value))
 for value in [null,true,0,1,"false"]:
  var bad=record.duplicate(false);bad.expired=value
  check(not consumed_ok(host,bad,owner),"expired_or_wrongtype_history_"+str(value))
 for value in [null,true,5.0,"5",-1,6,7]:
  var bad=record.duplicate(false);bad.cast_sequence=value
  check(not consumed_ok(host,bad,owner),"invalid_prior_cast_sequence_"+str(value))
 for value in [null,0,true,"",StringName("u30")]:
  var bad=record.duplicate(false);bad.cast_target_uid=value
  check(not consumed_ok(host,bad,owner),"invalid_cast_target_uid_"+str(value))
 for value in [null,[],{},true,{"uid":"changed"}]:
  var bad=record.duplicate(false);bad.snapshot=value
  check(not consumed_ok(host,bad,owner),"invalid_consumed_snapshot_"+str(value))
 for value in [null,[],{}, {"uid":"other","card_id":"wrong"}]:
  var bad=record.duplicate(false);bad.unit=value
  check(not consumed_ok(host,bad,owner),"invalid_consumed_unit_"+str(value))
 for key in ["uid","card_id"]:
  for value in [null,0,true,[],StringName("BG23_000t")]:
   var bad=record.duplicate(false);bad.unit=token.duplicate(true);bad.unit[key]=value;bad.snapshot=bad.unit.duplicate(true)
   check(not consumed_ok(host,bad,owner),"invalid_consumed_token_identity_"+key+str(value))
 for zones in [[null],[{}],[[token]],[[token.duplicate(true)]],[[{"uid":token.uid}]],[[null]],[[{}]],[[{"uid":1}]]]:
  check(not consumed_ok(host,record,owner,zones),"consumed_token_reappeared_or_invalid_zone")
 check(record.used==true and record.ready==true and not record.has("expired") and host.purchase_value_same(token,record.snapshot),"content_checks_leave_original_fixtures_unchanged")
 var copy_record=record.duplicate(false);copy_record.unit=token.duplicate(true)
 check(consumed_ok(host,copy_record,owner),"equal_detached_token_content_does_not_prove_issued_identity")
 var helper=MiniHost.new();var fake_host=PretendMiniHost.new();fake_host._mini=helper
 for fake_game in [{},PretendMiniGame.new()]:
  check(not helper.consumed_sale_error(fake_host,fake_game,owner,{"uid":"u20"}).is_empty(),"fake_actual_consumed_sale_refused")
  check(not helper.sale_preflight(fake_host,fake_game,owner,{"uid":"u20"}).is_empty(),"unissued_consumed_sale_preflight_refused")
 check(helper._sale.is_empty() and helper._tokens.is_empty() and helper._board.is_empty() and helper._poison.is_empty(),"fake_consumed_history_cannot_install_receipts")
 print("DARKCREST_MINI_AFTER_CAST_CONTENT_CONTRACT ",JSON.stringify({"passed":passed,"failed":failed,"failures":failures,"real_game_run":false,"actual_provenance_proven":false,"scope":"detached consumed Mini token history and unbound refusal only"}))
 quit(0 if failed==0 else 1)
