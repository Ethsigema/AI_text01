# Original Mini cast, then same-turn native sale

New isolated draft. Canonical tests/darkcrest_mini_after_cast_20261112 paths. Inherits immutable Mini-sale helper methods but overrides its initializer; no old full matrix runs. One actual seed20261120 four-player room, same Game/Catalog and unchanged random domain. Native preview is factory-shape diagnostic only; authentic original Mini publicplay/Waiting and original Trident publiccast remain mandatory.

Sequence: pre-source original public Mini/Lava purchase with explicit native factory/add_hand/publicCoin funding fixture; source play, Lava play, Mini play; original first Trident cast permanently2/5→4/5 kept1; token consumed and used original record retained. PublicsellMini with zero ready hand token checks exact gold/pool/sold+1, UID/RNG/spellpool and all remaining hand/board unchanged, source original receipt fully retired, used token record/source/owner/unit refs and history unchanged, no new token. One real nonemptycombat/recruit preserves4/5, resetskept0, source2, no Mini regrant.

Negative public-path/read-only calls reject copiedMini, wrongowner, unboundnative sale context and retired replay without live mutations. Pure tests will bind final producer consumed-history interface; positive detached shapes cannot authorize actual Game. No missing-history creation, private live receipt manipulation or artificial token reappearance.

Not tested/opened: same-turn secondcast, secondMini, golden, Mini rebuy, other targets, buffedLava sale/rebuy, sold-source UNUSED expiry, native partial failure injection, wholegame/default-pool/save/UI. Existing Lava permanence algorithm is unchanged. Old full results are historical, not rerun here. New pure count awaits final interface and actual execution; no pass claimed at drafting time.

## Producer API-aligned draft

New consumed_sale_record_error is a pure content predicate; consumed_sale_error authenticates actual Game/source registry and Lava receipt before sale. Successful original cast now records cast_sequence and cast_target_uid. New pure static expected85 checks includes complete and malformed source/round/ready/used/expired/cast metadata, snapshot and full-zone absence; copied equal token content may pass pure shape but cannot provide actual original identity. The outer fake/unbound calls must refuse and install no state. Real matrix requires actual consumed_sale_error after original publiccast before sale, not a forged ledger.

New result is a single JSON object DARKCREST_MINI_AFTER_CAST_MATRIX_RESULT.json; fields inherit finite sale facts plus cast_before_sale:true, ready_token_at_sale:false. Marker DARKCREST_MINI_AFTER_CAST_REAL_MATRIX_PASS cases=1 casts=1 combats=1 checks=N, JSON checks=N-1. New pure marker DARKCREST_MINI_AFTER_CAST_CONTENT_CONTRACT with actual_provenance_proven:false. Static count is not an actual pass receipt.
