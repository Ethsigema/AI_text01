from pathlib import Path,PurePosixPath
import json,hashlib,subprocess,tarfile,datetime
P=Path(__file__).resolve().parent;sha=lambda b:hashlib.sha256(b).hexdigest();read=lambda p:json.loads(p.read_text());pub=read(P/'PRE_CLEANUP_PUBLICATION.json');meta=read(P/'PRE_CLEANUP_UPLOAD_METADATA.json');commit=pub['commit'];assert commit=='86a6e787a212ffc9ae6464d6a1bbfd42fc8e5d6f';folder=meta['remote_folder'];out=P/'pre_cleanup_remote_86a6e78';out.mkdir(exist_ok=False);records=[]
for row in meta['records']:
 n=row['name'];assert n==PurePosixPath(n).name;url=f'https://raw.githubusercontent.com/Ethsigema/AI_text01/{commit}/{folder}/{n}';p=out/n;subprocess.run(['curl','-fsSL','--retry','3','--connect-timeout','30','--max-time','120',url,'-o',str(p)],check=True);b=p.read_bytes();assert len(b)==row['bytes'] and sha(b)==row['sha256'] and hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==row['git_sha'];records.append({**row,'url':url})
assert len(records)==4 and {x.name for x in out.iterdir()}=={x['name'] for x in records};seen=set()
for line in (out/'SHA256SUMS.txt').read_text().splitlines():
 h,n=line.split('  ',1);assert n not in seen and n==PurePosixPath(n).name and n!='SHA256SUMS.txt' and sha((out/n).read_bytes())==h;seen.add(n)
assert seen=={x['name'] for x in records}-{'SHA256SUMS.txt'};m=read(out/'LATE_EVIDENCE_MANIFEST.json');assert sha((out/'LATE_EVIDENCE.tar.xz').read_bytes())==m['archive_sha256'];actual={}
with tarfile.open(out/'LATE_EVIDENCE.tar.xz') as t:
 for x in t:
  assert x.isfile() and not PurePosixPath(x.name).is_absolute() and '..' not in PurePosixPath(x.name).parts and '\\' not in x.name and x.name not in actual;b=t.extractfile(x).read();actual[x.name]={'bytes':len(b),'sha256':sha(b)}
assert actual==m['members'] and len(actual)==14
report={'status':'PASS_FRESH_PRE_CLEANUP_PUBLICATION_EVERY_FILE_AND_MEMBER','commit':commit,'remote_folder':folder,'download_directory':str(out),'files':4,'bytes':sum(x['bytes'] for x in records),'records':records,'members':14,'every_member_rehashed':True,'deleted':[],'game_started':False,'verified_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()};(P/'PRE_CLEANUP_PUBLICATION_VERIFIED.json').write_text(json.dumps(report,indent=2)+'\n');print('PASS_FRESH4_MEMBERS14',flush=True)
