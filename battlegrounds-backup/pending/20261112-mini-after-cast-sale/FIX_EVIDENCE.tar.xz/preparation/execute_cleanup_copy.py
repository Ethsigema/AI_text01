"""Prepared only. Execute after exact two-target authorization and fresh pre-cleanup audit success."""
from pathlib import Path
import json,gzip,hashlib,fcntl,shutil,datetime,argparse,tarfile
R=Path.cwd();P=Path(__file__).resolve().parent;sha=lambda b:hashlib.sha256(b).hexdigest();read=lambda p:json.loads(p.read_text())
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--execute',action='store_true',required=True);ap.parse_args()
 ns={};exec((R/'develop_lava_next_20261112/preparation/cleanup_preflight.py').read_text().split('specs=')[0],ns);scan=ns['scan'];sums=ns['sums']
 pre=read(P/'CLEANUP_PREFLIGHT.json');publication=read(P/'PRE_CLEANUP_PUBLICATION_VERIFIED.json');assert publication['status']=='PASS_FRESH_PRE_CLEANUP_PUBLICATION_EVERY_FILE_AND_MEMBER'
 for row in publication['records']:
  b=(Path(publication['download_directory'])/row['name']).read_bytes();assert len(b)==row['bytes'] and sha(b)==row['sha256']
 with tarfile.open(Path(publication['download_directory'])/'LATE_EVIDENCE.tar.xz') as tar:assert tar.extractfile('develop_mini_after_cast_20261112/preparation/CLEANUP_PREFLIGHT.json').read()==(P/'CLEANUP_PREFLIGHT.json').read_bytes()
 allowed=[R/'develop_lava_next_20261112/candidate',R/'develop_darkcrest_lava_20261112/fresh_remote/restored_base'];assert [Path(x['target']) for x in pre['targets']]==allowed
 with Path(pre['common_lock']).open('r') as lock:
  fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);before=shutil.disk_usage(R)._asdict();checks=[];preserved=[]
  for row in pre['targets']:
   target=Path(row['target']);restore=Path(row['equivalent_preserved_tree']);pkg=Path(row['source_package']);raw=gzip.decompress((pkg/'SOURCE_MAP.json.gz').read_bytes());assert sha(raw)==row['source_map_sha256'];expected=json.loads(raw)
   for n,h in row['receipts'].items():assert sha(Path(n).read_bytes())==h
   a=scan(target,expected,row['full_target']['aggregate_sha256']);b=scan(restore,expected,row['full_equivalent']['aggregate_sha256']);assert a==row['full_target'] and b==row['full_equivalent'];sums(pkg)
   if 'manifest_sha256' in row:assert sha((pkg/'MANIFEST.json').read_bytes())==row['manifest_sha256']
   for p in map(Path,row['preserved_paths']):
    assert p.exists();preserved.append(p)
    if p.is_dir() and (p/'SHA256SUMS.txt').exists():sums(p)
   checks.append({'target':str(target),'equivalent':str(restore),'target_verified':a,'equivalent_verified':b})
  for p in allowed:shutil.rmtree(p)
  assert all(not p.exists() for p in allowed) and all(p.exists() for p in preserved)
  after=shutil.disk_usage(R)._asdict();report={'status':'AUTHORIZED_EXACT_TWO_NON_BACKUP_DUPLICATES_REMOVED','deleted_paths':list(map(str,allowed)),'checks':checks,'preserved_paths':list(map(str,preserved)),'before_disk':before,'after_disk':after,'available_bytes_increase':after['free']-before['free'],'backups_deleted':False,'old_scripts_unchanged':True,'old_base_replacement':str(R/'recover_tier5_after_environment_change_20261112/restored_base'),'game_started':False};(P/'CLEANUP_EXECUTED.json').write_text(json.dumps(report,indent=2)+'\n');print('CLEANUP_DONE',report['available_bytes_increase'],flush=True)
  source=R/'develop_lava_next_20261112/remote_snapshot_a96a033/single_tree_restore/restored_snapshot';pkg=source.parent.parent/'package';raw=gzip.decompress((pkg/'SOURCE_MAP.json.gz').read_bytes());expected=json.loads(raw);m=read(pkg/'MANIFEST.json');first=scan(source,expected,m['aggregate_sha256']);second=scan(source,expected,m['aggregate_sha256']);assert first==second
  dest=P.parent/'candidate';assert not dest.exists();shutil.copytree(source,dest);copied=scan(dest,expected,m['aggregate_sha256']);assert {k:v for k,v in first.items() if k!='allocated_file_bytes'}=={k:v for k,v in copied.items() if k!='allocated_file_bytes'}
  (P/'CANDIDATE_PREIMAGE_SOURCE_MAP.json').write_bytes(raw);(P/'CANDIDATE_PREIMAGE_SOURCE_SHA256.json').write_text(json.dumps({n:x['sha256'] for n,x in expected.items()},indent=2,sort_keys=True)+'\n');result={'status':'PASS_A96_ACCEPTED_SOURCE_DOUBLE_READ_AND_INDEPENDENT_COPY','source_commit':'a96a03307c43c5641793663b99e864877543d1b5','final_commit':'d914d66999536eb4250841488d09ae7ba3f82ccf','source':str(source),'candidate':str(dest),'source_map_sha256':sha(raw),'source_first_read':first,'source_second_read':second,'candidate_verified':copied,'no_hardlinks':True,'game_started':False,'disk':shutil.disk_usage(R)._asdict()};(P/'CANDIDATE_PREIMAGE_VERIFIED.json').write_text(json.dumps(result,indent=2)+'\n');print('CANDIDATE_READY',result['disk'],flush=True)
if __name__=='__main__':main()
