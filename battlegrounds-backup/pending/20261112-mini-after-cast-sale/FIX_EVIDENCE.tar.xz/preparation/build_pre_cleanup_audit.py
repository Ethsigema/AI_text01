from pathlib import Path
import json,hashlib,tarfile,io,ast
R=Path.cwd();P=Path(__file__).resolve().parent;sha=lambda b:hashlib.sha256(b).hexdigest();enc=lambda d:(json.dumps(d,indent=2,sort_keys=True)+'\n').encode();files={}
for x in json.loads((P/'LOCAL_ONLY_SMALL_EVIDENCE.json').read_text())['records']:
 p=R/x['path'];b=p.read_bytes();assert sha(b)==x['sha256'];files[x['path']]=b
for name in ['readonly_cleanup_preflight.py','CLEANUP_PREFLIGHT.json','CLEANUP_PREFLIGHT.log','CLEANUP_PREFLIGHT_INITIAL_ALLOCATION_ASSERT.log','LOCAL_ONLY_SMALL_EVIDENCE.json','execute_cleanup_copy.py','build_pre_cleanup_audit.py']:
 p=P/name;b=p.read_bytes();files[p.relative_to(R).as_posix()]=b
 if p.suffix=='.py':ast.parse(b)
p=R/'develop_lava_next_20261112/preparation/cleanup_preflight.py';files[p.relative_to(R).as_posix()]=p.read_bytes()
out=P/'pre_cleanup_evidence_package';out.mkdir(exist_ok=False)
with tarfile.open(out/'LATE_EVIDENCE.tar.xz','w:xz') as t:
 for n,b in sorted(files.items()):
  info=tarfile.TarInfo(n);info.size=len(b);info.mode=0o644;info.mtime=0;t.addfile(info,io.BytesIO(b))
mem={n:{'bytes':len(b),'sha256':sha(b)} for n,b in files.items()}
with tarfile.open(out/'LATE_EVIDENCE.tar.xz') as t:assert {x.name:{'bytes':x.size,'sha256':sha(t.extractfile(x).read())} for x in t if x.isfile()}==mem
(out/'LATE_EVIDENCE_MANIFEST.json').write_bytes(enc({'archive_sha256':sha((out/'LATE_EVIDENCE.tar.xz').read_bytes()),'members':mem}))
(out/'README.md').write_text('''# 下一批清理前只读证据

本包不是工程全量备份，也不是删除授权或执行记录。保留上一批最终审计回读与验证器等6项迟到证据，以及本轮两对象全文件SHA/aggregate预检、执行前重核/清理/copy准备脚本。

候选：develop_lava_next_20261112/candidate，等价保留remote_snapshot_a96a033/single_tree_restore/restored_snapshot。中间基线：develop_darkcrest_lava_20261112/fresh_remote/restored_base，等价保留recover_tier5_after_environment_change_20261112/restored_base。均非唯一备份，全部final restore、包、input、日志、失败候选、审计目录保留；尚未删除。历史脚本若引用未来获准清理的中间基线路径，须显式指向等价保留base，旧脚本本身不暗改。

首轮预检内容SHA已相等，但候选与恢复树物理块数相差4096字节，过严比较触发assert；原日志保留。之后按相同路径/内容/长度/SHA/aggregate严格比对，并分别记录真实allocated blocks，再次全核通过。预计两对象释放fileblocks 3,237,134,336字节；新增candidate+fresh55+单一restore后约1.046GB余量，估算不是实际释放承诺。

校验SHA256SUMS.txt，再按LATE_EVIDENCE_MANIFEST逐regular成员长度/SHA校验；只解到新空目录，不覆盖旧证据或源工程。源码固定a96a03307c43c5641793663b99e864877543d1b5，最终有限回执d914d66999536eb4250841488d09ae7ba3f82ccf，最终小审计fe0c37566b75e82ffdc1ab5619e0018962a7e73b均仍保留，不因本包扩展玩法验收。
''')
(out/'SHA256SUMS.txt').write_text(''.join(sha(p.read_bytes())+'  '+p.name+'\n' for p in sorted(out.iterdir()) if p.name!='SHA256SUMS.txt'))
folder='battlegrounds-backup/audits/20261112T1600Z-pre-after-cast-cleanup';rows=[]
for p in sorted(out.iterdir()):
 b=p.read_bytes();rows.append({'name':p.name,'path':folder+'/'+p.name,'bytes':len(b),'sha256':sha(b),'git_sha':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()})
d={'status':'FROZEN_PRE_CLEANUP_EVIDENCE_NOT_UPLOADED_NO_DELETION','remote_folder':folder,'files':len(rows),'bytes':sum(x['bytes'] for x in rows),'members':len(mem),'records':rows};(P/'PRE_CLEANUP_UPLOAD_METADATA.json').write_bytes(enc(d));print(json.dumps({k:v for k,v in d.items() if k!='records'},indent=2))
