# Mini先cast后出售：独立最小边界审查

只读基线a96a033固定恢复树。未改源、未运行Game；等待新helper冻结diff。此次仅同轮首次原token作用于原Lava后出售普通Mini，之后一次非空combat观察保留；不扩大第二Mini、golden、rebuy、第二cast或其它目标。

## 凭据应何时产生

原Mini.complete的cast分支已依次核原Game窗口、body成功、recruit、无poison、完整board/hand对象与expected值、stats.spells+1及同Lava私有record。新增cast_sequence/targetUID应只在这些检查之后，与used=true一同写入原tokenledger；payload已产生+2但后suffix失败不得得到完成凭据。只把值写进原record，不重新构造可被复制冒用的token记录，不把内容谓词当实际发证入口。

## 售前两个互斥分支

旧1child仍走原ready/unconsumed原票分支。新0child必须找到唯一该owner/原source同轮已完成cast记录：原_tokens键与unit.uid一致、原record.unit/owner引用、token完整snapshot未变、ready/used严格true、expired严格false或确实无expiry、cast_sequence为整数且小于当前公开命令序号、cast_target_uid为真实原Lava身份。不得从任意旧轮历史used记录推导本轮权限，也不得0child无记录时按默认值通过。

原token既已消费，应全玩家/ghost board/hand/shop中不存在该原对象或UID。source仍须原board_error认证；target应实际在owner.board且Lava helper原record认证，不仅找同ID/UID；kept1、mini_round当前、精确永久expected值。纯source/receipt内容谓词只供合同负例，实际入口必须先actual owned Game/helper、原source/token记录及owner检查。

## 原sale事务不变

复用当前begin/finish原8字段operation（本身无nonce）、原plan引用与值及完整会计。旧source仍必须活着且未retired，新增cast事实需纳入原token_facts快照；finish验证全部tokens记录引用/事实未变，不应售中补写used/cast事实。真实离场先retired=true/complete=false撤权，原body或会计失败poison且保留已生效值、不rollback；仅全部成功后retired_complete=true。

当前Game公开命令在成功尾部command_sequence+=1，因此前次完整publiccast记录的序号应严格早于后续publicsale，正常顺序可达；同一次cast过程中重入sale不能过。旧持票sale后cast路径不应因本新增字段要求而被误拒，需仅在0child新分支要求cast事实。

## 必须纯负例/有限实战证据

错owner/source/tokenrefs/UID、复制record、缺/未来/同序号cast事实、已expired或旧轮、已消耗token仍在任一zone、假target/仅UID相同、kept0、mini_round旧轮、partialcast和partialsale均拒。整数/bool/String先检查类型再跨类型比较，避免重演旧SCRIPT ERROR。

唯一新实战应先原cast成功再publicsale，观察金+1/池Mini+1/sold+1/hand为空child/原tokenfacts不变、无重发、原Lava永久值及一次非空combat后招募保留。不得用手工置used/target/sequence替代原cast，也不重复旧完整矩阵凑成果。本报告不是实现通过或玩法验收。
