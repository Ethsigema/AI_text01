# Mini after-cast sale: unaccepted V1 overlay

Base: a96a03307c43c5641793663b99e864877543d1b5. Only core/darkcrest_mini.gd changed. Immutable base is untouched; no complete tree copied, repin, upload, or Game run.

The native permanent-spell and native sale algorithms already existed. This change admits one additional authenticated order of operations: original Mini grants its original Trident, complete native first cast on original Lava, then public same-round sale of original Mini with no Trident in hand. Existing ready-child sale remains unchanged.

Successful full cast completion now records cast_sequence and cast_target_uid on the original issued token ledger, only after existing full hand/board/stat/Lava receipt checks. No native stats or economy are written. Zero-child sale requires exactly one issued ledger for original source/current round, original token/owner identity and frozen body, strict ready=true/used=true/not expired, earlier same-round command sequence, token absent by identity and UID from every player/ghost board/hand/shop, live certified original source, and existing owned Lava receipt with current mini_round and kept=1. The new consumed_sale_record_error is content-only; actual helper/source/registry/Lava checks remain in consumed_sale_error and sale_preflight.

Original sale operation context, complete native sale body, full accounting receipts, partial-failure revocation/poison, retained token registry and completed source retirement are unchanged. No second Mini, golden, rebuy, alternate target, repeated same-turn cast, arbitrary source disappearance, expired/save-restored ledger, or post-tier6 continuation is enabled. New code does not retrospectively certify prior casts lacking completion fields.

Validation: isolated HOME/all XDG helper check-only exit 0. No pure execution or Game acceptance yet. Proposed actual acceptance: one ordinary room, grant -> first cast -> public sale -> nonempty combat/next recruit, Lava4/5 kept0, source level2, no new Mini ticket/token. Pure tests must describe content predicates as non-authorizing.
