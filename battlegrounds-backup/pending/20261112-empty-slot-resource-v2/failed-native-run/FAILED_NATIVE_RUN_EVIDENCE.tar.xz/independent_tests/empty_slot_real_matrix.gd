extends "res://tests/empty_combat_slot_20261112/real_matrix.gd"
