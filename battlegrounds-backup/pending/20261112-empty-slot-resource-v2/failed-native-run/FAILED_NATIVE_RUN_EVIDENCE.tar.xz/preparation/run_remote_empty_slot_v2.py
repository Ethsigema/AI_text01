"""One explicit, serial execution of the fixed remote empty-slot candidate.

Preparation is read-only without --execute. Never downloads, uploads, or changes
source inputs. Full Game runs once; only the four listed contracts follow it. v1 failed and remains unchanged.
"""
from pathlib import Path, PurePosixPath
import argparse
import datetime
import fcntl
import gzip
import hashlib
import json
import os
import re
import shutil
import signal
import subprocess
import time

V1_FAILURE = {'source_commit': 'e38175e91e58cad77cff3f234230d96beb20f872', 'error': 'hopebringer_combat_failed:dark_gift_resource_invalid_owner', 'full_game_passed': False, 'log_sha256': 'f9792aaf9efd155d19a357cc16d7ebc931ff387e637c3737f075c7f41bce786d'}
PINNED_TESTS = {
    'tests/empty_combat_slot_20261112/real_matrix.gd': '9100f0aed3067a37cac6fb623e3a82111c4b4feb24fee9341522afb52f6e8a46',
    'tests/empty_combat_slot_20261112/content_contract.gd': '7fb9ef1947e994123545103836eb5d8cefe765349ae7f682d4c87dee97ff946c',
    'tests/empty_slot_resource_v2_20261112/dark_gift_empty_contract.gd': '1bb9374282adfc0cbe6fc4f7643640fafa08469a54e3283175c35fc77302715d',
}
TESTS = [
    ('empty_slot_real_matrix', 'tests/empty_combat_slot_20261112/real_matrix.gd', 3600, None),
    ('dark_gift_empty_contract', 'tests/empty_slot_resource_v2_20261112/dark_gift_empty_contract.gd', 180, None),
    ('empty_slot_content_contract', 'tests/empty_combat_slot_20261112/content_contract.gd', 180, 1231),
    ('source_eot_contract', 'tests/darkcrest_20261112/source_eot_contract.gd', 180, 68),
    ('hand_shape_contract', 'tests/darkcrest_20261112/hand_shape_contract.gd', 180, 166),
]
FIXTURE = 'tests/darkcrest_20261112/darkcrest_sources_archived.gd'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def dump(value):
    return (json.dumps(value, sort_keys=True, indent=2) + '\n').encode()


def write_new(path, value):
    with path.open('xb') as stream:
        stream.write(dump(value))


def read_json(path):
    return json.loads(path.read_text())


def safe(name):
    return bool(name) and not PurePosixPath(name).is_absolute() and '..' not in PurePosixPath(name).parts and '\\' not in name


def verify_tree(tree, expected, aggregate):
    assert tree.is_dir() and not tree.is_symlink(), str(tree)
    actual = {}
    combined = hashlib.sha256()
    paths = list(tree.rglob('*'))
    assert all(not path.is_symlink() for path in paths), 'Source symlink forbidden'
    for path in sorted((path for path in paths if path.is_file()), key=lambda path: path.relative_to(tree).as_posix()):
        name = path.relative_to(tree).as_posix()
        assert safe(name), name
        data = path.read_bytes()
        actual[name] = {'bytes': len(data), 'sha256': sha(data)}
        combined.update(name.encode() + b'\0' + str(len(data)).encode() + b'\0' + data)
    missing = sorted(set(expected) - set(actual))
    extra = sorted(set(actual) - set(expected))
    mismatched = sorted(name for name in actual.keys() & expected.keys() if actual[name] != expected[name])
    result = {'files': len(actual), 'bytes': sum(row['bytes'] for row in actual.values()),
              'aggregate_sha256': combined.hexdigest(), 'missing': missing, 'extra': extra, 'mismatched': mismatched}
    assert not missing and not extra and not mismatched and combined.hexdigest() == aggregate, result
    return result, {name: row['sha256'] for name, row in actual.items()}


def stop(process):
    if process.poll() is not None:
        return
    os.killpg(process.pid, signal.SIGTERM)
    try:
        process.wait(timeout=2)
    except subprocess.TimeoutExpired:
        os.killpg(process.pid, signal.SIGKILL)
        process.wait()


def rss_for_group(group):
    rss = 0
    for proc in Path('/proc').iterdir():
        if not proc.name.isdigit():
            continue
        try:
            fields = (proc / 'stat').read_text().rsplit(')', 1)[1].split()
            if int(fields[2]) == group:
                rss += int((proc / 'statm').read_text().split()[1]) * os.sysconf('SC_PAGE_SIZE')
        except (OSError, ValueError, IndexError):
            pass
    return rss


def run_test(label, source_name, budget, commit, run_tree, evidence, expected, aggregate, env, prepared):
    # Re-read the complete run tree, not merely its test entry point.
    tree, hashes = verify_tree(run_tree, expected, aggregate)
    write_new(evidence / (label + '_hashes.json'), hashes)
    for name, meta in prepared.items():
        data = (evidence / name).read_bytes()
        assert len(data) == meta['bytes'] and sha(data) == meta['sha256'], name
    available = int(next(line.split()[1] for line in Path('/proc/meminfo').read_text().splitlines()
                         if line.startswith('MemAvailable:'))) * 1024
    limit = min(4 * 1024**3, available // 2)
    assert limit >= (3 * 1024**3 if label == 'empty_slot_real_matrix' else 512 * 1024**2), 'Insufficient memory for guarded test'
    wrapper = evidence / (label + '.gd')
    cmd = ['godot', '--headless', '--path', str(run_tree), '--script', str(wrapper)]
    started = utc()
    t = time.monotonic()
    peak = 0
    reason = 'exited'
    with (evidence / (label + '.log')).open('x') as log:
        process = subprocess.Popen(cmd, stdout=log, stderr=subprocess.STDOUT, env=env, start_new_session=True)
        try:
            while process.poll() is None:
                rss = rss_for_group(process.pid)
                peak = max(peak, rss)
                if rss > limit or time.monotonic() - t > budget:
                    reason = 'rss_soft_limit' if rss > limit else 'timeout'
                    stop(process)
                    break
                time.sleep(.1)
        except BaseException:
            reason = 'runner_interrupted'
            raise
        finally:
            stop(process)
            data = (evidence / (label + '.log')).read_bytes()
            result = {'source_commit': commit, 'source': source_name, 'command': cmd,
                      'source_sha256': expected[source_name]['sha256'], 'wrapper_sha256': prepared[wrapper.name]['sha256'],
                      'log_sha256': sha(data), 'started_at_utc': started, 'finished_at_utc': utc(),
                      'exit': process.wait(), 'reason': reason, 'elapsed': time.monotonic() - t,
                      'sampled_process_group_peak_rss': peak, 'rss_soft_limit': limit, 'available_start': available,
                      'timeout_seconds': budget, 'memory_enforcement': 'sampled process-group soft limit, not a cgroup hard cap',
                      'source_snapshot_matches': True, 'start_tree': tree}
            write_new(evidence / (label + '_result.json'), result)
    print(label, json.dumps(result), flush=True)
    text = data.decode()
    failures = [line for line in text.splitlines() if re.search(r'^\s*FAIL(?:\s|$)', line)
                or any(marker in line for marker in ['SCRIPT ERROR:', 'Parse Error:', 'COMMAND_FAILURE', 'WARNING:', 'ERROR:'])]
    assert result['exit'] == 0 and reason == 'exited' and not failures, (label, result, failures)
    return result, text


def validate(label, log, expected_checks, evidence):
    scenario = None
    if label == 'empty_slot_real_matrix':
        rows = re.findall(r'^EMPTY_SLOT_REAL_MATRIX_PASS cases=4 checks=(\d+)$', log, re.M)
        assert len(rows) == 1, 'Missing or duplicated full Game success marker'
        count = int(rows[0])
        scenario = read_json(evidence / 'EMPTY_SLOT_MATRIX_RESULT.json')
        assert scenario['checks'] + 1 == count and len(scenario['cases']) == 4
        assert scenario['odd_player_counts'] == [3, 5, 7] and scenario['even_control'] == 4
        assert scenario['actual_minus_one_pair_in_each_odd_room'] is True
        assert scenario['no_live_state_injection'] is True
        assert scenario['native_dead_owner_snapshot_exercised'] is False
        assert scenario['tier5_six_output_matrix_repeated'] is False
        cases = scenario['cases']
        assert [row['players'] for row in cases] == [3, 5, 7, 4]
        assert [row['seed'] for row in cases] == [20261120, 20261121, 20261122, 20261123]
        logged = [json.loads(line.removeprefix('EMPTY_SLOT_CASE_PASS ')) for line in log.splitlines()
                  if line.startswith('EMPTY_SLOT_CASE_PASS ')]
        assert logged == cases
        for row in cases:
            n = row['players']
            assert row['round_before'] == 1 and row['round_after'] == 2
            assert row['native_dead_owner_snapshot_exercised'] is False
            assert len(row['pairs']) == (n + 1) // 2 and len(row['empty_pairs']) == n % 2
            ids = []
            observed_empty = []
            for pair in row['pairs']:
                left, right = pair['pair']
                assert 0 <= left < n and pair['error'] == ''
                ids.append(left)
                if right == -1:
                    assert pair['ghost'] is True and pair['start_right_count'] == 0 and pair['start_right_hand_count'] == 0
                    observed_empty.append([left, right])
                else:
                    assert 0 <= right < n and pair['ghost'] is False
                    ids.append(right)
            assert sorted(ids) == list(range(n)) and observed_empty == row['empty_pairs']
            assert row['darkcrest_was_empty_slot_left'] == any(pair[0] == 0 for pair in observed_empty)
    elif label == 'dark_gift_empty_contract':
        rows = [json.loads(line.removeprefix('DARK_GIFT_EMPTY_CONTRACT ')) for line in log.splitlines()
                if line.startswith('DARK_GIFT_EMPTY_CONTRACT ')]
        assert len(rows) == 1
        summary = rows[0]
        count = summary['passed']
        assert count == expected_checks and summary['failed'] == 0 and summary['failures'] == []
        assert summary['real_game_run'] is False and summary['native_dead_owner_snapshot_exercised'] is False
        assert summary['scope'] == 'pure detached zero-resource chain and fail-closed shape checks; not native provenance'
    elif label == 'empty_slot_content_contract':
        rows = [json.loads(line.removeprefix('EMPTY_SLOT_CONTENT_CONTRACT ')) for line in log.splitlines()
                if line.startswith('EMPTY_SLOT_CONTENT_CONTRACT ')]
        assert len(rows) == 1
        summary = rows[0]
        count = summary['passed']
        assert count == expected_checks and summary['failed'] == 0 and summary['failures'] == []
        assert summary['real_game_run'] is False
        assert summary['scope'] == 'pure detached zero-source shape checks, not native provenance or gameplay'
    elif label == 'source_eot_contract':
        count = expected_checks
        assert log.splitlines().count('DARKCREST_SOURCE_EOT_CONTRACT passed=68 failed=0') == 1
    else:
        rows = [json.loads(line) for line in log.splitlines() if line.startswith('{') and 'darkcrest_five_strict_hand_shapes' in line]
        assert len(rows) == 1
        summary = rows[0]
        count = summary['passed']
        assert count == expected_checks and summary['failed'] == 0 and summary['failures'] == []
    assert sum(line.startswith('PASS ') for line in log.splitlines()) == count, (label, 'PASS count does not match summary')
    return count, scenario


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--commit', required=True, help='Fixed remote source commit, 40 lowercase hex characters')
    parser.add_argument('--restored-snapshot', required=True, type=Path)
    parser.add_argument('--package', type=Path, help='Fixed remote downloaded package; default restored_snapshot sibling package')
    parser.add_argument('--restore-report', type=Path, help='Default sibling INDEPENDENT_RESTORE_VERIFIED.json')
    parser.add_argument('--output', type=Path, help='Default restored snapshot parent; run_tree and independent_tests must not exist')
    parser.add_argument('--source-map-sha256', required=True, help='Parent-verified frozen v2 uncompressed source-map SHA256')
    parser.add_argument('--aggregate-sha256', required=True, help='Parent-verified frozen v2 aggregate SHA256')
    parser.add_argument('--dark-gift-checks', required=True, type=int, help='Actual frozen-source pure-contract check count, not an estimate')
    parser.add_argument('--execute', action='store_true', help='Required to create copies or run any process')
    args = parser.parse_args()
    assert re.fullmatch(r'[0-9a-f]{40}', args.commit), 'Use a fixed full source commit'
    for value in [args.source_map_sha256, args.aggregate_sha256]:
        assert re.fullmatch(r'[0-9a-f]{64}', value), 'Require explicit frozen v2 SHA256 values'
    assert args.dark_gift_checks > 0
    assert args.commit != V1_FAILURE['source_commit'], 'v1 is failed, not a v2 candidate'
    frozen_map_sha = args.source_map_sha256
    frozen_aggregate = args.aggregate_sha256
    source = args.restored_snapshot.resolve()
    tranche_root = Path(__file__).resolve().parent.parent
    assert tranche_root in source.parents, 'Use the separate v2 remote snapshot, never v1'
    package = (args.package or source.parent / 'package').resolve()
    restore_report = (args.restore_report or source.parent / 'INDEPENDENT_RESTORE_VERIFIED.json').resolve()
    output = (args.output or source.parent).resolve()
    assert output != source and source not in output.parents, 'Never place generated artifacts inside source tree'
    assert tranche_root in output.parents or output == tranche_root, 'Keep output in the v2 tranche'
    manifest = read_json(package / 'MANIFEST.json')
    map_bytes = gzip.decompress((package / 'SOURCE_MAP.json.gz').read_bytes())
    assert sha(map_bytes) == manifest['source_map_sha256'] == frozen_map_sha
    assert manifest['aggregate_sha256'] == frozen_aggregate
    expected = json.loads(map_bytes)
    assert all(safe(name) for name in expected)
    assert len(expected) == manifest['source_files']
    assert sum(row['bytes'] for row in expected.values()) == manifest['source_bytes']
    for name, checksum in PINNED_TESTS.items():
        assert expected[name]['sha256'] == checksum, ('Frozen test changed', name)
    report = read_json(restore_report)
    assert report['source_commit'] == args.commit and report['source_map_sha256'] == frozen_map_sha
    assert report.get('status', '').startswith('PASS_'), 'Prior fixed-commit remote restore verification required'
    restored_report = report['restored']
    assert restored_report['aggregate_sha256'] == frozen_aggregate
    assert restored_report['files'] == manifest['source_files'] and restored_report['bytes'] == manifest['source_bytes']
    assert all(not restored_report[key] for key in ['missing', 'extra', 'mismatched'])
    for _, name, _, _ in TESTS:
        assert name in expected, name
    assert FIXTURE in expected
    if not args.execute:
        print(json.dumps({'status': 'CONFIGURATION_ONLY_NOT_EXECUTED', 'source_commit': args.commit,
                          'source_map_sha256': frozen_map_sha, 'tests': TESTS, 'game_started': False}, indent=2))
        return
    output.mkdir(parents=True, exist_ok=True)
    lock_path = tranche_root.parent / 'develop_empty_ghost_20261112' / '.independent_full_game.lock'
    lock = lock_path.open('a')
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    run_tree = output / 'run_tree'
    evidence = output / 'independent_tests'
    assert not run_tree.exists() and not evidence.exists(), 'Never overwrite an earlier run'
    initial_source, _ = verify_tree(source, expected, frozen_aggregate)
    shutil.copytree(source, run_tree)
    initial_run, _ = verify_tree(run_tree, expected, frozen_aggregate)
    evidence.mkdir()
    prepared = {}
    for label, name, _, _ in TESTS:
        data = ('extends "res://' + name + '"\n').encode()
        path = evidence / (label + '.gd')
        path.write_bytes(data)
        prepared[path.name] = {'bytes': len(data), 'sha256': sha(data), 'source': name,
                               'source_sha256': expected[name]['sha256'], 'kind': 'external_wrapper'}
    fixture_data = (source / FIXTURE).read_bytes()
    assert {'bytes': len(fixture_data), 'sha256': sha(fixture_data)} == expected[FIXTURE]
    fixture_path = evidence / 'darkcrest_sources_archived.gd'
    fixture_path.write_bytes(fixture_data)
    prepared[fixture_path.name] = {**expected[FIXTURE], 'source': FIXTURE, 'kind': 'remote_fixture_copy'}
    write_new(evidence / 'PREPARED_FROM_REMOTE.json', {'source_commit': args.commit, 'source_map_sha256': frozen_map_sha,
              'prepared_at_utc': utc(), 'v1_failure_preserved': V1_FAILURE, 'entries': prepared, 'initial_trees': {'restored_snapshot': initial_source, 'run_tree': initial_run}})
    env = os.environ.copy()
    for key, folder in [('HOME', 'home'), ('XDG_CACHE_HOME', 'cache'), ('XDG_CONFIG_HOME', 'config'), ('XDG_DATA_HOME', 'data')]:
        destination = evidence / folder
        destination.mkdir()
        env[key] = str(destination)
    runs = {}
    prior_end = None
    for label, name, budget, count in TESTS:
        if label == 'dark_gift_empty_contract':
            count = args.dark_gift_checks
        result, log = run_test(label, name, budget, args.commit, run_tree, evidence, expected, frozen_aggregate, env, prepared)
        assert prior_end is None or result['started_at_utc'] >= prior_end
        prior_end = result['finished_at_utc']
        count, scenario = validate(label, log, count, evidence)
        runs[label] = {'source': name, 'passed_checks': count, 'log_sha256': result['log_sha256'],
                       'test_sha256': expected[name]['sha256'], 'source_snapshot_matches': True, 'failures': [], 'result': result}
        if scenario is not None:
            runs[label]['verified_scenario_fields'] = scenario
            runs[label]['scenario_sha256'] = sha((evidence / 'EMPTY_SLOT_MATRIX_RESULT.json').read_bytes())
        write_new(evidence / (label + '_VALIDATED.json'), runs[label])
    # Reject all changes and extras, including generated source-tree caches.
    trees = {'restored_snapshot': verify_tree(source, expected, frozen_aggregate)[0],
             'run_tree': verify_tree(run_tree, expected, frozen_aggregate)[0]}
    for name, meta in prepared.items():
        data = (evidence / name).read_bytes()
        assert len(data) == meta['bytes'] and sha(data) == meta['sha256'], name
    final = {'status': 'PASS_FIXED_REMOTE_EMPTY_SLOT_V2_MATRIX_AND_CONTRACTS_POST_TEST_DOUBLE_REHASH',
             'verified_at_utc': utc(), 'source_commit': args.commit, 'source_map_sha256': frozen_map_sha,
             'v1_failure_preserved': V1_FAILURE, 'trees': trees, 'tests': runs, 'fixtures': prepared, 'sequential_game_execution': True,
             'full_game_processes': 1, 'tier5_six_output_matrix_repeated': False,
             'native_dead_owner_snapshot_exercised': False, 'full_game_acceptance': False,
             'default_pool_promoted': False, 'scope': 'empty-slot adapters and zero-resource Dark Gift compatibility only'}
    write_new(output / 'INDEPENDENT_GAME_VERIFICATION.json', final)
    print('EMPTY_SLOT_V2_REMOTE_MATRIX_CONTRACTS_AND_DOUBLE_REHASH_PASS', flush=True)


if __name__ == '__main__':
    main()
