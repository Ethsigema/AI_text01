extends "res://tests/darkcrest_tier5_20261112/real_matrix.gd"
# Narrow native empty-slot regression. Does not rerun Tier5 random-output suite.
var native_player_count: int=3
var empty_slot_cases: Array=[]
func setup_room(seed_value: int) -> bool:
 game=load("res://core/game.gd").new()
 var room=load("res://core/room_config.gd").new();room.reset(cat)
 room.data.enabled_minions=ROOM_IDS.duplicate();room.data.enabled_spells=["BG28_810"]
 room.data.selected_hero="TB_BaconShop_HERO_01";room.data.enabled_heroes=["TB_BaconShop_HERO_01"]
 room.data.bot_count=native_player_count-1;room.data.seed=seed_value
 for key in ["enabled_anomalies","enabled_quests","enabled_rewards","enabled_trinkets"]:room.data[key]=[]
 if not must(game.start(room.data,cat).get("ok",false) and game.state.players.size()==native_player_count,"native_room_"+str(native_player_count)+"_seed_"+str(seed_value)):return false
 var p=game.state.players[0]
 for tier in [2,3,4,5]:
  if not must(fund(int(p.upgrade_cost)+3),"native_coin_fixture_funding_"+str(tier)):return false
  if not must(command(0,{"type":"upgrade"}).get("ok",false) and p.tier==tier,"native_tavern_upgrade_"+str(tier)):return false
 return must(game.state.ghosts.is_empty() and game.state.players.all(func(owner):return owner.alive),"initial_room_has_no_dead_snapshot")
func ready_opponents() -> bool:
 for opponent in game.state.players:
  if opponent.id==0 or not opponent.alive:continue
  if not must(command(opponent.id,{"type":"end_turn"}).get("ok",false),"native_opponent_ready_"+str(opponent.id)):return false
 return true
func empty_slot_case(count: int,seed_value: int) -> bool:
 native_player_count=count
 if not setup_room(seed_value):return false
 var parent=quick_parent();var p=game.state.players[0]
 if parent.is_empty() or not source_play(parent):return false
 var old_tokens=p.hand.filter(func(unit):return unit.card_id=="BG31_920t")
 if not must(old_tokens.size()==1 and game._darkcrest_host._spells[old_tokens[0].uid].tier==1,"original_shop_source_issued_tier1"):return false
 var old_uid=old_tokens[0].uid;var old_round=game.state.round
 if not next_round(parent,2):return false
 if not must(game.state.phase=="recruit" and game.state.round==old_round+1 and game.state.players.all(func(owner):return owner.alive) and game.state.ghosts.is_empty(),"native_combat_returns_to_recruit_without_death"):return false
 var tokens=p.hand.filter(func(unit):return unit.card_id=="BG31_920t")
 if not must(tokens.size()==1 and tokens[0].uid!=old_uid and game._darkcrest_host._spells[tokens[0].uid].tier==2 and game._darkcrest_host._spells[tokens[0].uid].source_uid==parent.uid and game._darkcrest_host._parents[parent.uid].tier==2,"native_darkcrest_independent_eot_and_next_recruit_tier2"):return false
 if not must(game.last_combats.size()==game.state.last_pairs.size() and game.last_combats.size()==((count+1)>>1),"native_complete_pair_and_combat_count"):return false
 var observed=[];var empty_pairs=[];var real_ids=[]
 for index in range(game.last_combats.size()):
  var result=game.last_combats[index];var pair=game.state.last_pairs[index]
  if not must(pair==[result.left_player,result.right_player] and result.left_player>=0 and result.left_player<count,"native_result_pair_identity_"+str(index)):return false
  real_ids.append(result.left_player)
  if result.right_player>=0:real_ids.append(result.right_player)
  var starts=result.log.filter(func(event):return event.get("event")=="combat_start")
  if not must(result.get("error","").is_empty() and starts.size()==1 and result.log[-1].get("event")=="combat_end","native_combat_success_receipt_"+str(index)):return false
  if result.right_player==-1:
   if not must(count%2==1 and result.get("ghost")==true and starts[0].right.is_empty() and starts[0].right_hand_count==0,"actual_negative_one_empty_pair_"+str(index)):return false
   empty_pairs.append(pair)
  else:
   if not must(result.right_player<count and result.get("ghost")==false,"actual_living_pair_not_empty_exception_"+str(index)):return false
  observed.append({"pair":pair,"ghost":result.ghost,"start_left_count":starts[0].left.size(),"start_right_count":starts[0].right.size(),"start_right_hand_count":starts[0].right_hand_count,"error":result.get("error","")})
 real_ids.sort()
 if not must(real_ids==range(count),"all_native_players_paired_once"):return false
 if not must(empty_pairs.size()==count%2,"exact_native_odd_empty_slot_even_control"):return false
 var row={"players":count,"seed":seed_value,"round_before":old_round,"round_after":game.state.round,"source_uid":parent.uid,"issued_tier2_uid":tokens[0].uid,"pairs":observed,"empty_pairs":empty_pairs,"darkcrest_was_empty_slot_left":empty_pairs.any(func(pair):return pair[0]==0),"native_dead_owner_snapshot_exercised":false}
 empty_slot_cases.append(row)
 print("EMPTY_SLOT_CASE_PASS ",JSON.stringify(row))
 return true
func _initialize():
 print("EMPTY_SLOT_REAL_MATRIX_LOAD_BEGIN")
 var Game=load("res://core/game.gd")
 if not must(Game!=null and Game.can_instantiate(),"complete_game_script"):return
 cat=load("res://core/catalog.gd").new();cat.load_catalog()
 if not must(cat.load_errors.is_empty(),"complete_catalog"):print(JSON.stringify(cat.load_errors));return
 for spec in [{"players":3,"seed":20261120},{"players":5,"seed":20261121},{"players":7,"seed":20261122},{"players":4,"seed":20261123}]:
  if not empty_slot_case(spec.players,spec.seed):return
 var result={"scope":"native empty right slot adapter regression with ordinary Darkcrest EOT1->2; not full game or trinket ability acceptance","checks":checks,"cases":empty_slot_cases,"odd_player_counts":[3,5,7],"even_control":4,"actual_minus_one_pair_in_each_odd_room":true,"native_dead_owner_snapshot_exercised":false,"tier5_six_output_matrix_repeated":false,"no_live_state_injection":true}
 var file=FileAccess.open(get_script().resource_path.get_base_dir()+"/EMPTY_SLOT_MATRIX_RESULT.json",FileAccess.WRITE)
 if not must(file!=null,"empty_slot_result_file"):return
 file.store_string(JSON.stringify(result,"  ")+"\n");file.close()
 print("EMPTY_SLOT_REAL_MATRIX_PASS cases=",empty_slot_cases.size()," checks=",checks)
 quit(0)
