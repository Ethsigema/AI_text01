extends SceneTree
# Detached data fixtures only: exact shape is not private native provenance.
const Slot=preload("res://core/empty_combat_slot.gd")
const Pen=preload("res://core/waterlogged_pen_host.gd")
const Observer=preload("res://core/owned_observer_resources.gd")
var passed=0
var failed=0
var failures=[]
class FakeEngine:
 extends RefCounted
 var _options: Dictionary={}
 var _boards: Array=[[],[]]
func check(ok: bool,label: String) -> void:
 if ok:passed+=1;print("PASS ",label)
 else:failed+=1;failures.append(label);printerr("FAIL ",label)
func empty_owner() -> Dictionary:
 return {"id":-1,"name":"空位幽灵","board":[],"hand":[],"tier":1}
func normal_owner(id: int) -> Dictionary:
 return {"id":id,"name":"fixture","board":[],"hand":[],"tier":1,"trinkets":[]}
func pen_context(id: int) -> Dictionary:
 return {"owner":id,"trinkets":[],"ledger":{"owner":id,"slots":{}},"id":""}
func observer_context(id: int) -> Dictionary:
 return {"error":"","owner_id":id,"trinkets":[],"entries":[]}
func options_fixture(left_id: int=0) -> Dictionary:
 return {"right_tier":1,"right_hand":[],"right_hand_count":0,"right_is_ghost":false,"left_is_ghost":false,"maximum_history_context":{"owners":[left_id,-1],"round":1},"delayed_gold_context":{"owners":[left_id,-1],"round":1,"transaction_id":"fixture-not-a-receipt"},Pen.CONTEXT:[pen_context(left_id),pen_context(-1)],Observer.CONTEXT:[observer_context(left_id),observer_context(-1)]}
func normal_options_fixture() -> Dictionary:
 var options=options_fixture()
 options.maximum_history_context.owners=[0,1]
 options.delayed_gold_context.owners=[0,1]
 options[Pen.CONTEXT]=[pen_context(0),pen_context(1)]
 options[Observer.CONTEXT]=[observer_context(0),observer_context(1)]
 return options
func reject_options(options: Dictionary,label: String,right_input: Variant=[]) -> void:
 var before=options.duplicate(true)
 check(not Slot.combat_is_empty(1,-1,right_input,options),label+"_helper_rejects")
 check(not Pen.combat_domain([],right_input if right_input is Array else [],options).is_empty(),label+"_pen_rejects")
 var engine=FakeEngine.new();engine._options=options
 check(not Observer.new().initialize(engine,right_input).is_empty(),label+"_observer_rejects")
 check(Pen.Sources.same(before,options),label+"_read_only")
func reject_owner(owner: Dictionary,label: String,side: int=1) -> void:
 var before=owner.duplicate(true);var left=normal_owner(0);var right=owner
 if side==0:left=owner;right=normal_owner(1)
 check(not Slot.owner_is_empty(side,owner),label+"_helper_rejects")
 check(not Pen.attach({"state":{"round":1},"catalog":null},{},left,right).is_empty(),label+"_pen_attach_rejects")
 check(not Observer.attach({},left,right,null).is_empty(),label+"_observer_attach_rejects")
 check(Pen.Sources.same(before,owner),label+"_owner_read_only")
func _initialize() -> void:
 var owner=empty_owner();var before=owner.duplicate(true);var options=options_fixture()
 check(Slot.owner_is_empty(1,owner),"exact_five_key_native_owner_shape")
 check(Slot.owner_is_empty(1,owner.duplicate(true)),"identical_detached_shape_is_not_distinguished_as_private_authority")
 check(Slot.claimed(options) and Slot.combat_is_empty(1,-1,[],options),"complete_dual_context_shape")
 check(Pen.combat_domain([],[],options).is_empty(),"pen_accepts_complete_empty_slot")
 var engine=FakeEngine.new();engine._options=options
 var observer=Observer.new()
 check(observer.initialize(engine,[]).is_empty(),"observer_accepts_complete_empty_slot")
 check(not observer.initialize(engine).is_empty(),"reused_observer_cannot_inherit_previous_raw_right_argument")
 check(not Slot.combat_is_empty(1,-1,null,options),"helper_missing_raw_right_is_not_empty")
 check(Pen.Sources.same(before,owner),"pure_owner_observation_read_only")
 var attached={}
 check(Pen.attach({"state":{"round":1},"catalog":null},attached,normal_owner(0),owner).is_empty(),"pen_attach_exact_empty_owner")
 check(Observer.attach(attached,normal_owner(0),owner,null).is_empty(),"observer_attach_exact_empty_owner")
 check(Pen.Sources.same(attached[Pen.CONTEXT],options[Pen.CONTEXT]) and Pen.Sources.same(attached[Observer.CONTEXT],options[Observer.CONTEXT]),"native_shape_attach_produces_exact_contexts")
 for key in owner:
  var bad=owner.duplicate(true);bad.erase(key);reject_owner(bad,"owner_missing_"+key)
 for key in ["trinkets","effects","hero_id","reward_active","ledger"]:
  var bad=owner.duplicate(true);bad[key]=[];reject_owner(bad,"owner_extra_"+key)
 for value in [-2,8,"-1",-1.0,true,null]:
  var bad=owner.duplicate(true);bad.id=value;reject_owner(bad,"owner_wrong_id_"+str(value))
 for key in ["board","hand"]:
  for value in [[{"uid":"injected"}],null,{},false]:
   var bad=owner.duplicate(true);bad[key]=value;reject_owner(bad,"owner_wrong_"+key+"_"+str(value))
 for value in [0,2,1.0,"1",true,null]:
  var bad=owner.duplicate(true);bad.tier=value;reject_owner(bad,"owner_wrong_tier_"+str(value))
 for value in ["", "dead player",7,null]:
  var bad=owner.duplicate(true);bad.name=value;reject_owner(bad,"owner_wrong_name_"+str(value))
 reject_owner(owner,"left_negative_owner",0)
 for bad_side in [-1,0,2]:check(not Slot.combat_is_empty(bad_side,-1,[],options),"empty_slot_wrong_side_"+str(bad_side))
 for bad_id in [-2,8,"-1",-1.0,true,null]:check(not Slot.combat_is_empty(1,bad_id,[],options),"empty_slot_wrong_id_"+str(bad_id))
 # Both real adapters reject a nonempty original right even when _boards is empty.
 reject_options(options_fixture(),"nonempty_raw_right_with_empty_engine_boards",[{"uid":"not_an_empty_slot"}])
 var missing=FakeEngine.new();missing._options=options_fixture()
 check(not Observer.new().initialize(missing).is_empty(),"observer_omitted_raw_right_default_null")
 check(not Observer.new().initialize(missing,null).is_empty(),"observer_explicit_null_raw_right")
 for key in ["right_tier","right_hand","right_hand_count","right_is_ghost","left_is_ghost","maximum_history_context","delayed_gold_context",Pen.CONTEXT,Observer.CONTEXT]:
  var bad=options_fixture();bad.erase(key);reject_options(bad,"missing_option_"+key)
 for spec in [{"key":"right_tier","values":[0,2,1.0,"1",null]},{"key":"right_hand","values":[[{}],{},null,false]},{"key":"right_hand_count","values":[1,-1,0.0,"0",null]},{"key":"right_is_ghost","values":[true,0,"false",null]},{"key":"left_is_ghost","values":[true,0,"false",null]}]:
  for value in spec["values"]:
   var bad=options_fixture();bad[spec.key]=value;reject_options(bad,"bad_option_"+spec.key+"_"+str(value))
 for context_key in [Pen.CONTEXT,Observer.CONTEXT]:
  for value in [[],[{}],{},null,[{},{}]]:
   var bad=options_fixture();bad[context_key]=value;reject_options(bad,"bad_context_carrier_"+context_key+"_"+str(value))
  var right=options_fixture()[context_key][1]
  for key in right:
   var bad=options_fixture();bad[context_key][1].erase(key);reject_options(bad,"missing_right_context_field_"+context_key+"_"+key)
  var bad=options_fixture();bad[context_key][1].extra=true;reject_options(bad,"extra_right_context_field_"+context_key)
  for value in [["unrelated_source"],[Pen.Sources.IDS[0]],null,{}]:
   bad=options_fixture();bad[context_key][1].trinkets=value;reject_options(bad,"right_context_trinkets_"+context_key+"_"+str(value))
  var owner_key="owner" if context_key==Pen.CONTEXT else "owner_id"
  for value in [0,-2,8,"-1",-1.0,null]:
   bad=options_fixture();bad[context_key][1][owner_key]=value;reject_options(bad,"right_context_owner_"+context_key+"_"+str(value))
  bad=options_fixture();bad[context_key][0][owner_key]=1;reject_options(bad,"left_context_owner_mismatch_"+context_key)
 for value in [{},[],null,{"owner":0,"slots":{}},{"owner":-1,"slots":{"0":{"id":"source"}}},{"owner":-1,"slots":{},"extra":true},{"owner":-1.0,"slots":{}}]:
  var bad=options_fixture();bad[Pen.CONTEXT][1].ledger=value;reject_options(bad,"right_pen_ledger_"+str(value))
 for value in ["source",null,7]:
  var bad=options_fixture();bad[Pen.CONTEXT][1].id=value;reject_options(bad,"right_pen_source_id_"+str(value))
 for value in [[{"source_id":Observer.Sources.SHIELD}],{},null]:
  var bad=options_fixture();bad[Observer.CONTEXT][1].entries=value;reject_options(bad,"right_observer_entries_"+str(value))
 for value in ["error",null,7]:
  var bad=options_fixture();bad[Observer.CONTEXT][1].error=value;reject_options(bad,"right_observer_error_"+str(value))
 for carrier in ["maximum_history_context","delayed_gold_context"]:
  for value in [{},[],null,{"owners":[0,1]},{"owners":[-1,0]},{"owners":[1,-1]},{"owners":[0]},{"owners":[0,-1,2]},{"owners":[0.0,-1]},{"owners":[0,-1.0]}]:
   var bad=options_fixture();bad[carrier]=value;reject_options(bad,"owner_carrier_"+carrier+"_"+str(value))
 # No other -1 field may conceal a missed negative claim: start entirely normal.
 var wholly_normal=normal_options_fixture();var wholly_normal_engine=FakeEngine.new();wholly_normal_engine._options=wholly_normal
 check(not Slot.claimed(wholly_normal),"complete_normal_contexts_do_not_claim_empty")
 check(Pen.combat_domain([],[],wholly_normal).is_empty() and Observer.new().initialize(wholly_normal_engine).is_empty(),"complete_normal_contexts_keep_old_route")
 for suspicious in [-1,-1.0,-2,-2.0,-0.5,"-1","-2","-2.0"," -1 ","-0.5"]:
  for carrier in ["maximum_history_context","delayed_gold_context"]:
   for side in range(2):
    var bad=normal_options_fixture();bad[carrier].owners[side]=suspicious
    var label="isolated_negative_carrier_"+carrier+"_side"+str(side)+"_type"+str(typeof(suspicious))+"_"+str(suspicious)
    check(Slot.claimed(bad),label+"_detected")
    reject_options(bad,label)
   var scalar=normal_options_fixture();scalar[carrier].owners=suspicious
   var scalar_label="isolated_negative_scalar_owners_"+carrier+"_type"+str(typeof(suspicious))+"_"+str(suspicious)
   check(Slot.claimed(scalar),scalar_label+"_detected")
   reject_options(scalar,scalar_label)
  for context_key in [Pen.CONTEXT,Observer.CONTEXT]:
   var owner_key="owner" if context_key==Pen.CONTEXT else "owner_id"
   for side in range(2):
    var bad=normal_options_fixture();bad[context_key][side][owner_key]=suspicious
    var label="isolated_negative_context_"+context_key+"_side"+str(side)+"_type"+str(typeof(suspicious))+"_"+str(suspicious)
    check(Slot.claimed(bad),label+"_detected")
    reject_options(bad,label)
  for side in range(2):
   var bad=normal_options_fixture();bad[Pen.CONTEXT][side].ledger.owner=suspicious
   var label="isolated_negative_ledger_side"+str(side)+"_type"+str(typeof(suspicious))+"_"+str(suspicious)
   check(Slot.claimed(bad),label+"_detected")
   reject_options(bad,label)
 # Every native owner ID keeps the independent legacy context paths.
 for id in range(8):
  var normal={Pen.CONTEXT:[pen_context(0),pen_context(id)],Observer.CONTEXT:[observer_context(0),observer_context(id)],"right_is_ghost":true}
  var normal_engine=FakeEngine.new();normal_engine._options=normal
  check(not Slot.claimed(normal) and not Slot.combat_is_empty(1,id,[],normal),"normal_or_dead_owner_not_empty_exception_"+str(id))
  check(Pen.combat_domain([],[],normal).is_empty(),"normal_pen_legacy_shape_"+str(id))
  check(Observer.new().initialize(normal_engine).is_empty(),"normal_observer_legacy_default_argument_"+str(id))
 var forged={Pen.CONTEXT:[pen_context(0),pen_context(1)]};forged[Pen.CONTEXT][1].trinkets=[Pen.Sources.IDS[0]];forged[Pen.CONTEXT][1].id=Pen.Sources.IDS[0]
 check(not Pen.combat_domain([],[],forged).is_empty(),"normal_pen_source_without_acquisition_ledger_stays_rejected")
 var forged_engine=FakeEngine.new();forged_engine._options={Observer.CONTEXT:[observer_context(0),observer_context(1)]};forged_engine._options[Observer.CONTEXT][1].trinkets=[Observer.Sources.SHIELD]
 check(not Observer.new().initialize(forged_engine).is_empty(),"normal_shield_missing_ordered_entry_stays_rejected")
 check(Slot.combat_is_empty(1,-1,[],options_fixture()),"helper_remains_stateless_after_rejection_matrix")
 print("EMPTY_SLOT_CONTENT_CONTRACT ",JSON.stringify({"passed":passed,"failed":failed,"failures":failures,"scope":"pure detached zero-source shape checks, not native provenance or gameplay","real_game_run":false}))
 quit(0 if failed==0 else 1)
