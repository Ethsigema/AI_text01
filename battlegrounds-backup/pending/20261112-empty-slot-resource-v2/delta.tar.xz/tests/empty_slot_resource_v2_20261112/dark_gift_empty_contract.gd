extends SceneTree
# Pure detached fixtures only. No Game, live injection, or native provenance claim.
const Base=preload("res://tests/empty_combat_slot_20261112/content_contract.gd")
const Gift=preload("res://core/dark_gift_resource_host.gd")
var passed=0
var failed=0
var failures=[]
class EngineFixture:
 extends RefCounted
 var _seed: int=20261120
 var _options: Dictionary={}
 var _boards: Array=[[],[]]
 var _log: Array=[{"event":"combat_start"},{"event":"combat_end","error":""}]
func check(ok: bool,label: String) -> void:
 if ok:passed+=1;print("PASS ",label)
 else:failed+=1;failures.append(label);printerr("FAIL ",label)
func left_owner() -> Dictionary:
 return {"id":0,"name":"detached fixture","board":[],"hand":[],"tier":1,"trinkets":[]}
func right_owner() -> Dictionary:
 return {"id":-1,"name":"空位幽灵","board":[],"hand":[],"tier":1}
func zero(owner_id: int) -> Dictionary:
 return {"error":"","owner":owner_id,"bindings":[],"cards":{}}
func options_fixture() -> Dictionary:
 return {"left_hand":[],"right_tier":1,"right_hand":[],"right_hand_count":0,"right_is_ghost":false,"left_is_ghost":false,"maximum_history_context":{"owners":[0,-1],"round":1},"delayed_gold_context":{"owners":[0,-1],"round":1,"transaction_id":"detached-shape-only"}}
func complete_options() -> Dictionary:
 var options=options_fixture()
 # Use actual attachment adapters, never invoke Base._initialize or Game.
 var left=left_owner();var right=right_owner()
 var issue=Base.Pen.attach({"state":{"round":1},"catalog":null},options,left,right)
 check(issue.is_empty(),"fixture_pen_attach")
 check(Base.Observer.attach(options,left,right,null).is_empty(),"fixture_observer_attach")
 check(Gift.attach(options,left,right,null).is_empty(),"fixture_gift_attach")
 return options
func result_for(engine) -> Dictionary:
 return {"seed":engine._seed,"log":engine._log.duplicate(true),"error":""}
func ready(label: String,seal: bool=true) -> Dictionary:
 var engine=EngineFixture.new();engine._options=complete_options()
 var host=Gift.new();var left=left_owner();var right=right_owner()
 check(host.initialize(engine,[],[]).is_empty(),label+"_initialize")
 check(host.bind_prepared(engine).is_empty(),label+"_bind_zero_resources")
 if seal:host.complete(engine)
 return {"engine":engine,"host":host,"left":left,"right":right,"result":result_for(engine)}
func reject_init(options: Dictionary,label: String,left: Array=[],right: Array=[]) -> void:
 var engine=EngineFixture.new();engine._options=options
 var before=options.duplicate(true);var host=Gift.new()
 check(not host.initialize(engine,left,right).is_empty(),label+"_init_rejected")
 check(not host.bind_prepared(engine).is_empty(),label+"_failed_init_no_bind")
 host.complete(engine)
 check(not host.authenticate(result_for(engine),left_owner(),right_owner(),true).is_empty(),label+"_failed_init_no_auth")
 check(not host.prepare_settlement(left_owner(),right_owner(),true).is_empty(),label+"_failed_init_no_plan")
 check(Gift.Sources.same(before,options),label+"_input_read_only")
func reject_auth(data: Dictionary,label: String,ghost: bool=true) -> void:
 check(not data.host.authenticate(data.result,data.left,data.right,ghost).is_empty(),label+"_auth_rejected")
 check(not data.host.prepare_settlement(data.left,data.right,true).is_empty(),label+"_no_plan_after_auth_rejected")
func gift_claim() -> Dictionary:
 return {"uid":"detached-malformed-active-claim","card_id":"fixture","effects":[],Gift.Sources.MARKER:{"gift_id":Gift.Sources.REFRESH_GIFT}}
func _initialize() -> void:
 var data=ready("zero_chain")
 var owners_before=[data.left.duplicate(true),data.right.duplicate(true)]
 check(not data.host.prepare_settlement(data.left,data.right,true).is_empty(),"prepare_before_auth_rejected")
 check(data.host.authenticate(data.result,data.left,data.right,true).is_empty(),"pairing_ghost_true_auth_with_context_ghost_false")
 check(not data.host.authenticate(data.result,data.left,data.right,true).is_empty(),"auth_replay_rejected")
 check(data.host.prepare_settlement(data.left,data.right,true).is_empty(),"zero_resource_settlement_noop")
 check(not data.host.prepare_settlement(data.left,data.right,true).is_empty(),"prepare_replay_rejected")
 check(Gift.Sources.same(owners_before,[data.left,data.right]),"noop_preserves_both_owners")
 check(not data.host._ghost and data.host._receipts.is_empty() and data.host._bound.is_empty(),"noop_does_not_create_ghost_resources")
 check(not data.host.commit_free(data.left,{"event":Gift.FREE_EVENT,"owner":0,"side":0,"sequence":0}).is_empty(),"noop_cannot_mint_free_refresh")
 for side in range(2):
  for key in ["error","owner","bindings","cards"]:
   var options=complete_options();options[Gift.CONTEXT][side].erase(key)
   reject_init(options,"context_missing_"+str(side)+"_"+key)
  for key in ["receipts","source","ledger"]:
   var options=complete_options();options[Gift.CONTEXT][side][key]={}
   reject_init(options,"context_extra_"+str(side)+"_"+key)
  for value in [[{}],{},null,0]:
   var options=complete_options();options[Gift.CONTEXT][side].bindings=value
   reject_init(options,"bindings_injected_"+str(side)+"_"+str(value))
  for value in [{"injected":{}},[],null,0]:
   var options=complete_options();options[Gift.CONTEXT][side].cards=value
   reject_init(options,"cards_injected_"+str(side)+"_"+str(value))
  for value in [-2,-1.0,"-1",8,null]:
   var options=complete_options();options[Gift.CONTEXT][side].owner=value
   reject_init(options,"wrong_context_owner_"+str(side)+"_"+str(value))
  var options=complete_options();options[Gift.CONTEXT][side]={}
  reject_init(options,"missing_zero_context_"+str(side))
 var options=complete_options();options[Gift.CONTEXT][0].owner=1
 reject_init(options,"left_context_carrier_mismatch")
 options=complete_options();options[Gift.CONTEXT][1].owner=0
 reject_init(options,"right_context_not_empty_owner")
 reject_init(complete_options(),"raw_right_nonempty_with_engine_boards_empty",[],[{"uid":"ordinary"}])
 check(Gift.Sources.group_active(gift_claim()),"negative_fixture_is_classified_as_active_resource_claim")
 reject_init(complete_options(),"active_left_claim_rejected",[gift_claim()],[])
 reject_init(complete_options(),"active_right_claim_rejected",[],[gift_claim()])
 for side in ["left","right"]:
  options=complete_options();options[side+"_hand"]=[gift_claim()]
  reject_init(options,side+"_hand_active_claim")
 for field in ["right_hand","right_hand_count","right_tier","right_is_ghost","left_is_ghost"]:
  options=complete_options();options.erase(field);reject_init(options,"missing_"+field)
 for value in [true,0,"false",null]:
  for field in ["right_is_ghost","left_is_ghost"]:
   options=complete_options();options[field]=value;reject_init(options,"wrong_"+field+str(value))
 options=complete_options();options.right_hand=[{"uid":"ordinary"}];reject_init(options,"ordinary_right_hand_not_empty")
 for field in ["right_hand_count","right_tier"]:
  options=complete_options();options[field]=2;reject_init(options,"wrong_"+field)
 for field in ["maximum_history_context","delayed_gold_context"]:
  options=complete_options();options[field].owners=[0,1];reject_init(options,"carrier_mismatch_"+field)
 # Complete/authentication failures are detached result fixtures, not native logs.
 reject_auth(ready("no_complete",false),"missing_complete")
 reject_auth(ready("wrong_pairing_ghost"),"pairing_ghost_false",false)
 for field in ["id","name","tier","hand","board"]:
  data=ready("right_missing_"+field);data.right.erase(field);reject_auth(data,"right_missing_"+field)
 for value in [-2,0,8,-1.0,"-1"]:
  data=ready("right_owner_value");data.right.id=value;reject_auth(data,"right_wrong_owner_"+str(value))
 for value in [1,0.0,"0",-1]:
  data=ready("left_owner_value");data.left.id=value;reject_auth(data,"left_wrong_owner_"+str(value))
 for field in ["hand","board"]:
  data=ready("settlement_right_"+field);data.right[field]=[{"uid":"injected"}];reject_auth(data,"settlement_right_"+field)
 data=ready("result_receipt");data.result.log.insert(0,{"event":Gift.FREE_EVENT,"sequence":0});reject_auth(data,"injected_result_receipt")
 data=ready("seed_changed");data.result.seed+=1;reject_auth(data,"seed_changed")
 data=ready("error_changed");data.result.error="fixture";reject_auth(data,"result_error")
 data=ready("log_changed");data.result.log[0].extra=true;reject_auth(data,"log_changed")
 for tail in [{"event":"combat_start"},{"event":"combat_end","error":"fixture"},{}]:
  data=ready("bad_sealed_tail",false);data.engine._log=[tail];data.host.complete(data.engine);data.result=result_for(data.engine);reject_auth(data,"bad_sealed_tail_"+str(tail))
 data=ready("sealed_receipt",false);data.engine._log.insert(0,{"event":Gift.FREE_EVENT});data.host.complete(data.engine);data.result=result_for(data.engine);reject_auth(data,"claimed_sealed_receipt")
 # White-box corruption cases only: prove no resource state can ride the exception.
 for field in ["_bound","_invocations","_calls","_receipts","_committed","_random_grants","_hand_calls","_fodder_window"]:
  data=ready("state_injection_"+field);data.host.set(field,{"injected":{}});reject_auth(data,"state_injection_"+field)
 data=ready("next_injection");data.host._next=1;reject_auth(data,"nonzero_next")
 for side in range(2):
  data=ready("context_state_injection");data.host._contexts[side].cards={"injected":{}};reject_auth(data,"context_state_injection_"+str(side))
 for side in range(2):
  data=ready("owner_copy_plan");check(data.host.authenticate(data.result,data.left,data.right,true).is_empty(),"owner_copy_plan_auth")
  var copied_left=data.left.duplicate(true) if side==0 else data.left
  var copied_right=data.right.duplicate(true) if side==1 else data.right
  check(not data.host.prepare_settlement(copied_left,copied_right,true).is_empty(),"plan_owner_identity_"+str(side))
 data=ready("plan_ghost");check(data.host.authenticate(data.result,data.left,data.right,true).is_empty(),"plan_ghost_auth")
 check(not data.host.prepare_settlement(data.left,data.right,false).is_empty(),"plan_wrong_ghost")
 data=ready("plan_mutation");check(data.host.authenticate(data.result,data.left,data.right,true).is_empty(),"plan_mutation_auth")
 data.right.hand.append({"uid":"injected"});check(not data.host.prepare_settlement(data.left,data.right,true).is_empty(),"plan_right_shape_changed")
 data=ready("reinitialize");check(data.host.authenticate(data.result,data.left,data.right,true).is_empty(),"reinitialize_auth")
 options=complete_options();options.right_hand=[{}];data.engine._options=options
 check(not data.host.initialize(data.engine,[],[]).is_empty(),"reused_host_bad_init")
 check(not data.host.authenticate(data.result,data.left,data.right,true).is_empty(),"reused_host_loses_previous_authority")
 check(not data.host.prepare_settlement(data.left,data.right,true).is_empty(),"reused_host_loses_previous_plan")
 # Attachment canonical owner boundary is separate from combat context shape.
 for key in ["id","name","board","hand","tier"]:
  var bad=right_owner();bad.erase(key)
  check(not Gift.attach({},left_owner(),bad,null).is_empty(),"attach_missing_empty_owner_"+key)
 for key in ["trinkets","receipts","ledger"]:
  var bad=right_owner();bad[key]=[]
  check(not Gift.attach({},left_owner(),bad,null).is_empty(),"attach_extra_empty_owner_"+key)
 check(not Gift.attach({},right_owner(),left_owner(),null).is_empty(),"attach_left_empty_owner_rejected")
 for value in ["false",null,0,1]:
  check(not Gift.attach({"right_is_ghost":value},left_owner(),right_owner(),null).is_empty(),"attach_malformed_right_is_ghost_"+str(value))
 # A negative Gift-only claim cannot borrow all-normal contexts in other hosts.
 for value in [-1,-1.0,-2,-2.0,"-1"," -2 "]:
  options=complete_options()
  options.maximum_history_context.owners=[0,1];options.delayed_gold_context.owners=[0,1]
  options[Base.Pen.CONTEXT][1].owner=1;options[Base.Pen.CONTEXT][1].ledger.owner=1
  options[Base.Observer.CONTEXT][1].owner_id=1
  options[Gift.CONTEXT][1].owner=value
  reject_init(options,"gift_only_negative_claim_"+str(value))
 data=ready("empty_sealed_log",false);data.engine._log=[];data.host.complete(data.engine);data.result=result_for(data.engine)
 reject_auth(data,"empty_sealed_log")
 # Normal owner paths remain distinct; true dead-player gameplay is not exercised.
 for ghost in [false,true]:
  var engine=EngineFixture.new();engine._options={"right_is_ghost":ghost,Gift.CONTEXT:[zero(0),zero(1)]}
  var host=Gift.new();var left=left_owner();var right=left_owner();right.id=1
  check(host.initialize(engine,[],[]).is_empty(),"normal_owner_initialize_"+str(ghost))
  check(host.bind_prepared(engine).is_empty(),"normal_owner_bind_"+str(ghost));host.complete(engine)
  check(host.authenticate(result_for(engine),left,right,ghost).is_empty(),"normal_owner_auth_"+str(ghost))
  check(host.prepare_settlement(left,right,ghost).is_empty(),"normal_owner_plan_"+str(ghost))
 print("DARK_GIFT_EMPTY_CONTRACT ",JSON.stringify({"passed":passed,"failed":failed,"failures":failures,"real_game_run":false,"scope":"pure detached zero-resource chain and fail-closed shape checks; not native provenance","native_dead_owner_snapshot_exercised":false}))
 quit(0 if failed==0 else 1)
