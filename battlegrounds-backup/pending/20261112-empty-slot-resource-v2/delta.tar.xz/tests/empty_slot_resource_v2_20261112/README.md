# Empty native combat slot v2 tests

The v1 `content_contract.gd` (1231 checks in its prior actual run) and `real_matrix.gd` are byte-identical copies. Their earlier results are not a current v2 pass. The real matrix still uses 3/5/7-player odd rooms and a 4-player control with actual public commands, Darkcrest shop acquisition, play and EOT 1→2. It must run only after source freeze, upload and independent remote restore, once serially under the parent-approved runner.

`dark_gift_empty_contract.gd` adds detached pure fixtures for the existing Dark Gift resource host's zero-resource compatibility path. It runs no Game. The fake engine and logs test shape, sealing and state-machine behavior only, not native provenance or native completed combat. Internal state corruption and malformed active Gift claims are expressly negative fixtures, not valid actual resource sources or live state edits.

Coverage: canonical five-field empty owner; full initialize → bind_prepared → complete → authenticate → prepare_settlement no-op; pairing ghost=true with options right_is_ghost=false; complete log sealing; seed/error/end constraints; both zero resource contexts; binding/card/source/receipt injections; missing/extra/wrong owner context and Gift-only negative claim; nonempty raw right despite empty engine boards; right hand/tier/count and explicit ghost flags; failed initialize invalidation, owner identity between authentication and preparation, replay and host reuse; normal owner 0/1 with ghost false/true retained as pure legacy-shape controls.

Natural dead-player snapshot gameplay remains untested. The v1 real matrix is NOT a six-output Tier5 rerun or full content acceptance. No production files changed by this test task.

New summary marker: `DARK_GIFT_EMPTY_CONTRACT` with actual `passed`, `failed`, `failures`, `real_game_run=false` and scope. Do not predeclare its count before execution. Execute test wrappers and logs outside the immutable source tree.
