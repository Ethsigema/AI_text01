extends RefCounted
## Complete pinned Greater Miniature Ship source revision; no native acceptance grant.
const REVISION: String="partial-37.0.2-greater-miniature-ship-source-only-v2"
const ID: String="BG35_MagicItem_710"
const OVERLAY: String="data/patch_3702_miniature_ship_overlay.json"
const FILE_SHA256: Dictionary={"data/patch_3702_miniature_ship_overlay.json":"76ae4d2d911a42a4aa00d83f2c4ba40649b5efe81efeaf13468be3564404db2a","research/patch_3702_miniature_ship/BG35_MagicItem_710.native.xml":"3ebc710d39eeba8367d6918b7f610ae5f98d14b307d510f24baa2d68c67bf67d","research/patch_3702_miniature_ship/official_greater_section_through_ship.html":"d8990f6ba363d2332eb26acdf18925dde5270ea4274efaaca055a52cf4b239e1","research/patch_3702_miniature_ship/official_miniature_ship_excerpt.html":"49ce9393e9ec2ce7e35d73883cff8cb67db5809dc4c3f017cd696c4a25255ba9","research/patch_3702_miniature_ship/source_evidence.json":"b5fd1bdc8887fe69e4decc22f8f7e00fe756d3109664f006219fe287167020d8","core/game.gd":"2d89d4ff7a3ae41bef8da397c2595d0d3cb302b4c849c87ff44fff86f67b9aa8","core/mechanism_effects.gd":"2bf8270878cbac39508ddbc588607340a3686f650547d7d5e4260b8ec25c7496","core/room_config.gd":"5ad842f365651173c745f4210fb5c69e2f93b67893959c75f0931cacc0b1382d","core/damage_listener_room.gd":"cd3c7d104698f51b8ddf6b627d1a753f442778d00adc0ddb9e3c5287b2ac8287","core/current_scope.gd":"a1e8c5d0b2e434aa3c95cf61ce5b8734027c3df0666a63c8d07d8b24e9d94e64","core/patch_3702_membership_sources.gd":"8b4a4f4981553125213b1d3a0cc80f66d7f54b229dcb74329430e6e4a5654842","core/trinket_offer_schedule.gd":"a0820faab3bc89c7e6deaf85916f8bb1af3eb09bbbf5ca3d00a94c07409f31ec","core/lobby_tribes.gd":"96b74fb21b8876353defb8e457d6ee0f3e888fea59c2f810eaf9a552adceea6a","data/current_scope_manifest.json":"60ba04da35d3db6933f5177207f70e713da5efa2ebc0707c863a24248de2fcff","data/patch_3702_membership.json":"8c72c5c371d4566afce4839cc5f2f95ead1c133fda9324f72bd054b004fc3e9c","data/tribe_pool_requirements.json":"cfcb116ed73f38ab77679ee9bb6ccb2c241f0e813b3f16a6fae3577cd956fde1"}
const PACKET_SHA256: Dictionary={"data/patch_3702_miniature_ship_overlay.json":"76ae4d2d911a42a4aa00d83f2c4ba40649b5efe81efeaf13468be3564404db2a","research/patch_3702_miniature_ship/BG35_MagicItem_710.native.xml":"3ebc710d39eeba8367d6918b7f610ae5f98d14b307d510f24baa2d68c67bf67d","research/patch_3702_miniature_ship/official_greater_section_through_ship.html":"d8990f6ba363d2332eb26acdf18925dde5270ea4274efaaca055a52cf4b239e1","research/patch_3702_miniature_ship/official_miniature_ship_excerpt.html":"49ce9393e9ec2ce7e35d73883cff8cb67db5809dc4c3f017cd696c4a25255ba9","research/patch_3702_miniature_ship/source_evidence.json":"b5fd1bdc8887fe69e4decc22f8f7e00fe756d3109664f006219fe287167020d8"}
const RUNTIME_PATHS: Array=["core/patch_3702_miniature_ship_sources.gd","core/catalog.gd","data/patch_3702_miniature_ship_overlay.json","research/patch_3702_miniature_ship/BG35_MagicItem_710.native.xml","research/patch_3702_miniature_ship/official_greater_section_through_ship.html","research/patch_3702_miniature_ship/official_miniature_ship_excerpt.html","research/patch_3702_miniature_ship/source_evidence.json","core/game.gd","core/mechanism_effects.gd","core/room_config.gd","core/damage_listener_room.gd","core/current_scope.gd","core/patch_3702_membership_sources.gd","core/trinket_offer_schedule.gd","core/lobby_tribes.gd","data/current_scope_manifest.json","data/patch_3702_membership.json","data/tribe_pool_requirements.json"]

static func accepts_id(miniature_ship_identity: Variant) -> bool:
	return miniature_ship_identity is String and miniature_ship_identity==ID

static func same(miniature_ship_actual: Variant,miniature_ship_expected: Variant) -> bool:
	# JSON parses numbers as floats; accept only finite integral numeric equality.
	# In particular, booleans, fractional values and strings are never numbers.
	if miniature_ship_expected is int or miniature_ship_expected is float:
		return (miniature_ship_actual is int or miniature_ship_actual is float) and not miniature_ship_actual is bool and is_finite(float(miniature_ship_actual)) and is_finite(float(miniature_ship_expected)) and miniature_ship_actual==floor(miniature_ship_actual) and miniature_ship_expected==floor(miniature_ship_expected) and miniature_ship_actual==miniature_ship_expected
	if typeof(miniature_ship_actual)!=typeof(miniature_ship_expected): return false
	if miniature_ship_expected is Dictionary:
		if miniature_ship_actual.size()!=miniature_ship_expected.size(): return false
		for miniature_ship_key in miniature_ship_expected:
			if not miniature_ship_actual.has(miniature_ship_key) or not same(miniature_ship_actual[miniature_ship_key],miniature_ship_expected[miniature_ship_key]): return false
		return true
	if miniature_ship_expected is Array:
		if miniature_ship_actual.size()!=miniature_ship_expected.size(): return false
		for miniature_ship_index in range(miniature_ship_expected.size()):
			if not same(miniature_ship_actual[miniature_ship_index],miniature_ship_expected[miniature_ship_index]): return false
		return true
	return miniature_ship_actual==miniature_ship_expected

static func normalize(miniature_ship_value: Variant) -> Variant:
	if miniature_ship_value is float and is_finite(miniature_ship_value) and miniature_ship_value==floor(miniature_ship_value) and miniature_ship_value>=-9007199254740991 and miniature_ship_value<=9007199254740991: return int(miniature_ship_value)
	if miniature_ship_value is Array:
		var miniature_ship_items: Array=[]
		for miniature_ship_item in miniature_ship_value: miniature_ship_items.append(normalize(miniature_ship_item))
		return miniature_ship_items
	if miniature_ship_value is Dictionary:
		var miniature_ship_fields: Dictionary={}
		for miniature_ship_key in miniature_ship_value: miniature_ship_fields[miniature_ship_key]=normalize(miniature_ship_value[miniature_ship_key])
		return miniature_ship_fields
	return miniature_ship_value

static func proof_error() -> String:
	for miniature_ship_path in FILE_SHA256:
		if not FileAccess.file_exists("res://"+miniature_ship_path) or FileAccess.get_sha256("res://"+miniature_ship_path)!=FILE_SHA256[miniature_ship_path]: return "partial_3702_miniature_ship_evidence_changed:"+str(miniature_ship_path)
	return ""

static func packet_error() -> String:
	for path in PACKET_SHA256:
		if not FileAccess.file_exists("res://"+path) or FileAccess.get_sha256("res://"+path)!=PACKET_SHA256[path]: return "partial_3702_miniature_ship_packet_changed:"+str(path)
	return ""

static func packet() -> Dictionary:
	if not packet_error().is_empty(): return {}
	var miniature_ship_packet: Variant=JSON.parse_string(FileAccess.get_file_as_string("res://"+OVERLAY))
	if not miniature_ship_packet is Dictionary or miniature_ship_packet.size()!=2 or miniature_ship_packet.get("revision")!=REVISION or not miniature_ship_packet.get("cards") is Array or miniature_ship_packet.cards.size()!=1: return {}
	var miniature_ship_row: Variant=miniature_ship_packet.cards[0]
	if not miniature_ship_row is Dictionary or miniature_ship_row.size()!=5 or not accepts_id(miniature_ship_row.get("id")): return {}
	for miniature_ship_field in ["expected_raw","expected_compiled","expected_baseline","effective_fields"]:
		if not miniature_ship_row.get(miniature_ship_field) is Dictionary: return {}
	var merged: Dictionary=miniature_ship_row.expected_raw.duplicate(true)
	merged.merge(miniature_ship_row.expected_compiled,true)
	if not same(merged,miniature_ship_row.expected_baseline): return {}
	return normalize(miniature_ship_row)

static func input_error(miniature_ship_input: Variant,miniature_ship_path: String) -> String:
	var startup_issue: String=proof_error()
	if not startup_issue.is_empty(): return startup_issue
	var miniature_ship_field: String=""
	if miniature_ship_path=="res://data/catalog_raw.json": miniature_ship_field="expected_raw"
	elif miniature_ship_path=="res://data/catalog.json": miniature_ship_field="expected_compiled"
	if not miniature_ship_input is Dictionary or not miniature_ship_input.get("cards") is Array:
		return "partial_3702_miniature_ship_missing_input:"+miniature_ship_path if not miniature_ship_field.is_empty() else ""
	var miniature_ship_matches: Array=[]
	for miniature_ship_card in miniature_ship_input.cards:
		if miniature_ship_card is Dictionary and accepts_id(miniature_ship_card.get("id")): miniature_ship_matches.append(miniature_ship_card)
	if miniature_ship_field.is_empty():
		return "partial_3702_miniature_ship_unexpected_input:"+miniature_ship_path if not miniature_ship_matches.is_empty() else ""
	if miniature_ship_matches.size()!=1: return "partial_3702_miniature_ship_missing_or_duplicate_input:"+miniature_ship_path
	var miniature_ship_row: Dictionary=packet()
	if miniature_ship_row.is_empty(): return "partial_3702_miniature_ship_missing_or_changed_packet"
	return "" if same(miniature_ship_matches[0],miniature_ship_row[miniature_ship_field]) else "partial_3702_miniature_ship_changed_whole_input:"+miniature_ship_path

static func apply_overlay(miniature_ship_cards: Dictionary) -> String:
	var startup_issue: String=proof_error()
	if not startup_issue.is_empty(): return startup_issue
	var miniature_ship_row: Dictionary=packet()
	if miniature_ship_row.is_empty(): return "partial_3702_miniature_ship_missing_or_changed_packet"
	if not miniature_ship_cards.has(ID) or not same(miniature_ship_cards[ID],miniature_ship_row.expected_baseline): return "partial_3702_miniature_ship_changed_whole_baseline"
	var miniature_ship_merged: Dictionary=miniature_ship_cards[ID].duplicate(true)
	miniature_ship_merged.merge(miniature_ship_row.effective_fields,true)
	if str(miniature_ship_merged.text).sha256_text()!=miniature_ship_merged.coverage_text_sha256: return "partial_3702_miniature_ship_changed_text_digest"
	miniature_ship_cards[ID]=miniature_ship_merged
	return ""

static func source_error(miniature_ship_card: Dictionary) -> String:
	if not accepts_id(miniature_ship_card.get("id")): return "partial_3702_miniature_ship_unknown_source"
	var miniature_ship_row: Dictionary=packet()
	if miniature_ship_row.is_empty(): return "partial_3702_miniature_ship_missing_or_changed_packet"
	var miniature_ship_expected: Dictionary=miniature_ship_row.expected_baseline.duplicate(true)
	miniature_ship_expected.merge(miniature_ship_row.effective_fields,true)
	# Preserve the entire source, including original flags, category and provenance.
	# This check never promotes support and continues through Catalog's old gates.
	return "" if same(miniature_ship_card,miniature_ship_expected) else "partial_3702_miniature_ship_changed_whole_effective_source"
