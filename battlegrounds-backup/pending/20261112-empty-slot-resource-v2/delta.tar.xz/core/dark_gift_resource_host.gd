extends RefCounted
const EmptySlot=preload("res://core/empty_combat_slot.gd")
const Sources=preload("res://core/dark_gift_sources.gd")
const Fodder=preload("res://core/dark_gift_fodder_host.gd")
const Random=preload("res://core/dark_gift_random_resources.gd")
const HandStats=preload("res://core/combat_accepted_hand_stats.gd")
const Sacrifice=preload("res://core/dark_gift_sacrifice_host.gd")
const CONTEXT: String="native_dark_gift_resource_context"
const FAMILY: String="actual_dark_gift_resources_v1"
const FREE_EVENT: String="dark_gift_free_refreshes"
const MAX: int=9007199254740991
const DR_TYPES: Array=["deathrattle_summon","deathrattle_damage","deathrattle_buff","deathrattle_keyword","deathrattle_add_card","deathrattle_hand_buff","deathrattle_shop_bonus",Sources.REFRESH_GRANT,Sources.SPELL_GRANT,Sources.TRANSFER_GRANT]
# Local no-resource shape memory only, never a resource execution capability.
var _initialized: bool=false
var _empty_slot_left: int=-1
var _empty_settlement_owners: Array=[]
var _fodder_window: Dictionary={}
var _contexts: Array=[{},{}]
var _bound: Dictionary={}
var _invocations: Dictionary={}
var _calls: Dictionary={}
var _receipts: Dictionary={}
var _sealed: Array=[]
var _next: int=0
var _seed: int=0
var _ghost: bool=false
var _completed: bool=false
var _authorized: bool=false
var _settlement_ready: bool=false
var _committed: Dictionary={}
var _random_grants: Dictionary={}
var _hand_calls: Dictionary={}
var _sacrifice=Sacrifice.new()
static func _zero_context(context: Variant, owner_id: int) -> bool:
	return Sources.fields(context,["error","owner","bindings","cards"]) and context.error is String and context.error=="" and context.owner is int and context.owner==owner_id and context.bindings is Array and context.bindings.is_empty() and context.cards is Dictionary and context.cards.is_empty()
static func _empty_inputs(options: Dictionary, right: Array) -> bool:
	if not EmptySlot.combat_is_empty(1,-1,right,options): return false
	var contexts: Variant=options.get(CONTEXT)
	if not contexts is Array or contexts.size()!=2: return false
	var owner_id: int=options.delayed_gold_context.owners[0]
	return _zero_context(contexts[0],owner_id) and _zero_context(contexts[1],-1)
func _empty_settlement_error(left: Dictionary,right: Dictionary,ghost: bool) -> String:
	if _empty_slot_left<0 or not ghost or _ghost or not EmptySlot.owner_is_empty(1,right) or not left.get("id") is int or left.id!=_empty_slot_left: return "dark_gift_resource_changed_empty_slot"
	if _contexts.size()!=2 or not _zero_context(_contexts[0],_empty_slot_left) or not _zero_context(_contexts[1],-1): return "dark_gift_resource_changed_empty_contexts"
	for state in [_bound,_invocations,_calls,_receipts,_committed,_random_grants,_hand_calls,_fodder_window]:
		if not state.is_empty(): return "dark_gift_resource_empty_slot_has_resources"
	if _next!=0 or _sealed.any(func(event):return event is Dictionary and record_claimed(event)): return "dark_gift_resource_empty_slot_has_receipts"
	return ""
static func record_claimed(event: Dictionary) -> bool:
	return event.has("dark_gift_resource_family") or event.get("event")==FREE_EVENT or event.get("effect")==Sources.REFRESH_GRANT
static func result_claimed(log: Array) -> bool:
	return log.any(func(event):return event is Dictionary and record_claimed(event))
static func context_for(owner: Dictionary,catalog,ghost: bool=false) -> Dictionary:
	var result: Dictionary={"error":"","owner":owner.get("id",-1),"bindings":[],"cards":{}}
	for unit in owner.get("hand",[]):
		if unit is Dictionary and Sources.group_gift(unit): result.error="dark_gift_resource_hand_origin_partial";return result
	for unit in owner.get("board",[]):
		if not unit is Dictionary: result.error="dark_gift_resource_invalid_board";return result
		if not Sources.group_gift(unit): continue
		var issue: String=Sources.unit_error(unit)
		if issue.is_empty(): issue=Sources.closure_error(catalog)
		if issue.is_empty() and not ghost and unit[Sources.MARKER].owner!=result.owner: issue="dark_gift_resource_foreign_owner"
		if issue.is_empty() and Sources.gem_gift(unit): issue=Sources.resource_child_error(catalog)
		if issue.is_empty() and Sources.fodder_gift(unit): issue=Fodder.Sources.closure_error(catalog)
		if not issue.is_empty(): result.error=issue;return result
		result.bindings.append({"uid":unit.uid,"card_id":unit.card_id,"receipt":unit[Sources.MARKER].duplicate(true),"effects":unit.effects.duplicate(true)})
		var id: String=str(unit[Sources.MARKER].gift_id)
		result.cards[id]=catalog.get_card(id).duplicate(true)
	return result
static func attach(options: Dictionary,left: Dictionary,right: Dictionary,catalog) -> String:
	var right_ghost: Variant=options.get("right_is_ghost",false)
	if not right_ghost is bool: return "dark_gift_resource_invalid_ghost_flag"
	for side in range(2):
		var owner: Dictionary=[left,right][side]
		if not Sources.integer(owner.get("id"),0,7) and not EmptySlot.owner_is_empty(side,owner): return "dark_gift_resource_invalid_owner"
	var contexts: Array=[context_for(left,catalog),context_for(right,catalog,right_ghost)]
	for context in contexts:
		if not str(context.error).is_empty(): return str(context.error)
	options[CONTEXT]=contexts
	return ""
func initialize(engine,left: Array,right: Array) -> String:
	_initialized=false;_empty_slot_left=-1;_empty_settlement_owners=[]
	_fodder_window={};_contexts=[{},{}];_bound={};_invocations={};_calls={};_receipts={};_sealed=[];_next=0;_seed=engine._seed;_completed=false;_authorized=false;_settlement_ready=false;_committed={};_random_grants={};_hand_calls={};_sacrifice=Sacrifice.new()
	_ghost=false
	var right_ghost: Variant=engine._options.get("right_is_ghost",false)
	if not right_ghost is bool: return "dark_gift_resource_invalid_ghost_flag"
	_ghost=right_ghost
	var empty_claim: bool=EmptySlot.claimed(engine._options) or EmptySlot._context_claims(engine._options.get(CONTEXT),"owner")
	if empty_claim and not _empty_inputs(engine._options,right): return "dark_gift_resource_invalid_empty_slot"
	var contexts: Variant=engine._options.get(CONTEXT,[{},{}])
	if not contexts is Array or contexts.size()!=2: return "dark_gift_resource_invalid_contexts"
	for side in range(2):
		var inputs: Array=left if side==0 else right
		var bindings: Array=[]
		for unit in inputs:
			if not unit is Dictionary: return "dark_gift_resource_invalid_combat_body"
			if not Sources.group_gift(unit): continue
			var issue: String=Sources.unit_error(unit)
			if not issue.is_empty(): return issue
			bindings.append({"uid":unit.uid,"card_id":unit.card_id,"receipt":unit[Sources.MARKER].duplicate(true),"effects":unit.effects.duplicate(true)})
		for unit in engine._options.get("left_hand" if side==0 else "right_hand",[]):
			if unit is Dictionary and Sources.group_gift(unit): return "dark_gift_resource_hand_origin_partial"
		var context: Variant=contexts[side]
		if context is Dictionary and context.is_empty() and bindings.is_empty(): continue
		if not Sources.fields(context,["error","owner","bindings","cards"]) or context.error!="" or not context.cards is Dictionary or not Sources.same(context.bindings,bindings): return "dark_gift_resource_missing_or_changed_context"
		if not Sources.integer(context.owner,-1,7) or (context.owner==-1 and not (empty_claim and side==1)): return "dark_gift_resource_invalid_owner"
		var ids: Array=[]
		for binding in bindings:
			if not (_ghost and side==1) and binding.receipt.owner!=context.owner: return "dark_gift_resource_foreign_owner"
			var id: String=str(binding.receipt.gift_id)
			if id not in ids: ids.append(id)
			var issue: String=Sources.source_error(context.cards.get(id,{}))
			if not issue.is_empty(): return issue
		if ids.size()!=context.cards.size(): return "dark_gift_resource_extra_context_source"
		_contexts[side]=context.duplicate(true)
	if empty_claim: _empty_slot_left=engine._options.delayed_gold_context.owners[0]
	_initialized=true
	return ""
func bind_prepared(engine) -> String:
	if not _initialized: return "dark_gift_resource_uninitialized_host"
	for side in range(2):
		for binding in _contexts[side].get("bindings",[]):
			var found: Array=engine._boards[side].filter(func(body):return body.get("uid")==binding.uid)
			if found.size()!=1 or (engine._boards[0]+engine._boards[1]).filter(func(body):return body.get("uid")==binding.uid).size()!=1: return "dark_gift_resource_original_uid_ambiguous"
			var unit: Dictionary=found[0]
			if unit.get("card_id")!=binding.card_id or not Sources.same(unit.get(Sources.MARKER),binding.receipt) or not Sources.same(unit.effects,binding.effects): return "dark_gift_resource_prepared_identity_changed"
			_bound[str(side)+":"+str(unit._combat_id)]={"unit":unit,"receipt":binding.receipt.duplicate(true),"effects":unit.effects.duplicate(true),"base":unit._base.duplicate(true)}
			if "reborn" in unit.get("keywords",[]): return "dark_gift_resource_reborn_inheritance_partial"
			var issue: String=_whole_error(engine,side,unit)
			if not issue.is_empty(): return issue
	return ""
func source_error(side: int,unit: Dictionary) -> String:
	var issue: String=Sources.unit_error(unit)
	if not issue.is_empty(): return issue
	var binding: Dictionary=_bound.get(str(side)+":"+str(unit.get("_combat_id",-1)),{})
	if binding.is_empty() or not is_same(binding.get("unit"),unit) or not Sources.same(binding.receipt,unit.get(Sources.MARKER)) or not Sources.same(binding.effects,unit.get("effects")) or not Sources.same(binding.base,unit.get("_base")): return "dark_gift_resource_unbound_or_transformed_source_partial"
	return ""
func _whole_error(engine,side: int,unit: Dictionary) -> String:
	var issue: String=source_error(side,unit)
	if not issue.is_empty(): return issue
	if not Sources.group_active(unit): return ""
	if Sources.random_resource_gift(unit):
		var random_plan: Dictionary=Random.combat_plan(engine,side,unit)
		if not random_plan.ok: return str(random_plan.error)
	if Sources.transfer_gift(unit):
		issue=Sacrifice.admission(engine,side,unit)
		if not issue.is_empty(): return issue
	if Sources.death_group_gift(unit):
		var grouped: Dictionary=engine.Saurolisk.deathrattle_groups(unit,engine._options.get("hand_card_templates",{}))
		if not str(grouped.error).is_empty(): return str(grouped.error)
		for group in grouped.groups:
			for leaf in group:
				if leaf.get("type") not in DR_TYPES or leaf.has("count_from") or leaf.get("scope")=="adjacent_friendly": return "dark_gift_resource_unproved_combined_deathrattle_partial"
		# A copied Gift needs a new provenance contract, not just its resource DSL.
		if engine._boards[side].any(func(body):return not is_same(body,unit) and engine.FishAcquisition.Sources.accepts_id(body.get("card_id")) and engine.FishAcquisition.Sources.active(body)): return "dark_gift_resource_fish_inheritance_partial"
	else:
		if Sources.gem_gift(unit):
			if not engine._combat_hand.available[side]: return "dark_gift_resource_actual_combat_hand_required"
			if not Sources.same(engine._options.get("hand_card_templates",{}).get(Sources.GEM_ID),Sources.GEM_TEMPLATE): return "dark_gift_resource_changed_gem_template"
			issue=engine.NativeRecruit.Crystal.combat_reward_error(unit,Sources.GEM_ID,2,engine._options.get("hand_card_templates",{}))
			var accepted: int=mini(2,maxi(0,10-int(engine._hand_counts[side])))
			if issue.is_empty(): issue=engine.HandAcquisition.combat_acquisition_error(engine,side,Sources.GEM_ID,accepted)
			if issue.is_empty(): issue=engine.TradeQuotas.combat_acquisition_error(engine,side,Sources.GEM_ID,accepted)
			if not issue.is_empty(): return issue
			var hand_plan: Dictionary=HandStats.plan(engine,side,unit,Sources.GEM_ID,2)
			if not hand_plan.ok: return str(hand_plan.error)
		for effect in unit.get("effects",[]):
			if effect.get("type")!="rally": continue
			issue=engine._validate_rally(effect,0,unit,engine._options.get("hand_card_templates",{}))
			if not issue.is_empty(): return issue
			if effect.get("effect",{}).get("type") not in ["buff","keyword","add_card"]: return "dark_gift_resource_unproved_combined_rally_partial"
	return ""
func queued(engine,side: int,source: Dictionary,existing: Array) -> Dictionary:
	var result: Dictionary={"error":"","groups":[]}
	if not Sources.rally_resource_gift(source): return result
	result.error=_whole_error(engine,side,source)
	if not str(result.error).is_empty() or not Sources.group_active(source): return result
	for activation in existing:
		if activation.has("stoneshell_group"): result.error="dark_gift_resource_copied_rally_order_partial";return result
		if activation.get("effect",{}).get("effect",{}).get("type") not in ["buff","keyword","add_card"]: result.error="dark_gift_resource_unproved_combined_rally_partial";return result
	var times: int=engine._owner_rally_multiplier(side)
	if times<1 or times>512 or engine._steps>engine._max_steps-times: result.error="dark_gift_resource_rally_iteration_budget";return result
	result.groups=[{"index":"dark_gift_t66" if Sources.fodder_gift(source) else ("dark_gift_t3" if Sources.majority_gift(source) else "dark_gift_t80"),"effect":Sources.rally_wrapper(source),"dark_gift_resource":true}]
	return result
func rally(engine,side: int,source: Dictionary,action: Dictionary,wrapper: Dictionary) -> void:
	var issue: String=_whole_error(engine,side,source)
	if issue.is_empty() and (not Sources.rally_resource_gift(source) or not Sources.group_active(source) or not Sources.same(wrapper,Sources.rally_wrapper(source)) or not Sources.same(action,wrapper.effect) or not is_same(engine._find_unit(side,int(source._combat_id)),source)): issue="dark_gift_resource_changed_rally_invocation"
	var sequence: int=engine._log.size()-1
	var receipt: Dictionary=engine._log.back() if not engine._log.is_empty() else {}
	if issue.is_empty() and (receipt.get("event")!="rally" or receipt.get("side")!=side or receipt.get("source")!=source.uid or receipt.get("action")!=action.get("type") or _calls.has("rally:"+str(sequence))): issue="dark_gift_resource_actual_unconsumed_rally_required"
	if not issue.is_empty(): engine._fail(issue);return
	_calls["rally:"+str(sequence)]=true
	if Sources.fodder_gift(source):
		if not _fodder_window.is_empty(): engine._fail("demonology_nested_rally_capability");return
		_fodder_window={"side":side,"source":source,"action":action,"wrapper":wrapper,"sequence":sequence,"used":false}
		var fodder_issue: String=engine._fodder_refresh_host.rally_gift(engine,side,source,action,wrapper)
		if fodder_issue.is_empty() and not _fodder_window.get("used",false): fodder_issue="demonology_unconsumed_rally_capability"
		_fodder_window={}
		if not fodder_issue.is_empty(): engine._fail(fodder_issue);return
		var fodder_record: Dictionary=engine._log.back()
		_receipts[fodder_record.sequence]=fodder_record.duplicate(true)
		return
	if Sources.majority_gift(source):
		_random_reward(engine,side,source,{"kind":"rally","sequence":sequence})
		return
	var start: int=engine._log.size()
	queue_spell(engine,side,source,Sources.GEM_ID,2,{"dark_gift_resource_family":FAMILY,"gift_id":Sources.GEM_GIFT,"gift_receipt":source[Sources.MARKER].duplicate(true),"rally_sequence":sequence})
	if not engine._error.is_empty(): return
	var found: Array=[]
	for index in range(start,engine._log.size()):
		var event: Dictionary=engine._log[index]
		if not record_claimed(event): continue
		if event.get("event")!="recruit_add_card" or event.get("card_id")!=Sources.GEM_ID or event.get("count")!=2 or event.get("source")!=source.uid or event.get("rally_sequence")!=sequence: engine._fail("dark_gift_resource_changed_gem_reward");return
		found.append(event);_receipts[index]=event.duplicate(true)
	if found.size()!=1: engine._fail("dark_gift_resource_missing_actual_gem_reward")
# Only authenticated Gift callers use this finite spell composer. It adds no
# parallel execution or synthetic receipt; the existing queue performs all work.
func queue_spell(engine,side: int,source: Dictionary,card_id: String,count: int,metadata: Dictionary) -> void:
	var issue: String=source_error(side,source)
	if issue.is_empty() and (not Sources.gem_gift(source) and not Sources.spell_gift(source)): issue="dark_gift_hand_stats_wrong_resource_source"
	if issue.is_empty() and (metadata.get("dark_gift_resource_family")!=FAMILY or metadata.get("gift_id")!=source[Sources.MARKER].gift_id or not Sources.same(metadata.get("gift_receipt"),source[Sources.MARKER])): issue="dark_gift_hand_stats_changed_source_receipt"
	var key: String=""
	if issue.is_empty() and Sources.gem_gift(source):
		var sequence: int=int(metadata.get("rally_sequence",-1))
		key="gem:"+str(sequence)
		if card_id!=Sources.GEM_ID or count!=2 or sequence<0 or sequence>=engine._log.size() or not _calls.has("rally:"+str(sequence)): issue="dark_gift_hand_stats_missing_actual_rally"
		elif engine._log[sequence].get("event")!="rally" or engine._log[sequence].get("side")!=side or engine._log[sequence].get("source")!=source.uid: issue="dark_gift_hand_stats_changed_actual_rally"
	elif issue.is_empty():
		var token: int=int(metadata.get("dark_gift_random_token",-1))
		key="spell:"+str(token)
		var grant: Dictionary=_random_grants.get(token,{})
		if count!=1 or grant.is_empty() or not grant.used or not is_same(grant.get("engine"),engine) or grant.side!=side or not is_same(grant.get("source"),source) or not Sources.same(grant.origin,metadata.get("gift_origin")): issue="dark_gift_hand_stats_missing_actual_random_grant"
	if issue.is_empty() and _hand_calls.has(key): issue="dark_gift_hand_stats_replayed_queue"
	if not issue.is_empty(): engine._fail(issue);return
	var plan: Dictionary=HandStats.plan(engine,side,source,card_id,count)
	if not plan.ok: engine._fail(str(plan.error));return
	issue=HandStats.before_error(engine,plan)
	if not issue.is_empty(): engine._fail(issue);return
	_hand_calls[key]=true
	engine._queue_card_reward(side,source,card_id,count,metadata)
	if not engine._error.is_empty(): return
	issue=HandStats.after_error(engine,plan)
	if not issue.is_empty(): engine._fail(issue)
func bind_invocation(engine,entry: Dictionary,trigger: String) -> bool:
	if not Sources.death_group_gift(entry.unit) or not Sources.group_active(entry.unit): return true
	var source: Dictionary=entry.unit;var side: int=int(entry.side)
	var issue: String=_whole_error(engine,side,source)
	if issue.is_empty() and (trigger not in ["deathrattle","rally_deathrattle","triggered_deathrattle"] or not Sources.integer(entry.get("repeats",1),1,512) or entry.has("_dark_gift_resource_invocation")): issue="dark_gift_resource_invalid_whole_invocation"
	if issue.is_empty() and trigger=="deathrattle" and not entry.get("live_source",false):
		var sequence: int=int(entry.get("milestone_death_sequence",-1))
		if sequence<0 or sequence>=engine._log.size() or engine._boards[side].any(func(body):return is_same(body,source)): issue="dark_gift_resource_actual_death_required"
		elif engine._log[sequence].get("event")!="death" or engine._log[sequence].get("unit")!=source.uid or engine._log[sequence].get("side")!=side: issue="dark_gift_resource_changed_death_receipt"
	elif issue.is_empty() and (not entry.get("live_source",false) or not is_same(engine._find_unit(side,int(source._combat_id)),source) or int(source.health)<=0): issue="dark_gift_resource_actual_living_source_required"
	if issue.is_empty():
		var grouped: Dictionary=engine.Saurolisk.deathrattle_groups(source,engine._options.get("hand_card_templates",{}))
		var repeats: int=int(entry.get("repeats",1));var work: int=0
		for group in grouped.groups: work+=group.size()
		if work>512/repeats or work*repeats>engine._max_steps-engine._steps: issue="dark_gift_resource_whole_deathrattle_budget"
		var context_key: String="left_global_card_state" if side==0 else "right_global_card_state"
		if issue.is_empty() and engine._options.has(context_key):
			var context: Dictionary=engine._options[context_key]
			var owner: Dictionary={"id":context.id,engine.GlobalCards.STATE:context[engine.GlobalCards.STATE],"board":engine._boards[side].filter(func(body):return int(body.get("health",0))>0 and not body.get("_pending_destroy",false)),"hand":engine._combat_hand.hands[side],"shop":[],"beast_round":context.get("beast_round",0),"beast_offboard_present":context.get("beast_offboard_present",false)}
			var counter: Dictionary=engine.GlobalCards.counter_plan(owner,{"deathrattles":grouped.groups.size()*repeats},true)
			if not counter.ok: issue=str(counter.error)
	if not issue.is_empty(): engine._fail(issue);return false
	_next+=1;entry._dark_gift_resource_invocation=_next
	_invocations[_next]={"entry":entry,"source":source,"trigger":trigger,"side":side,"repeats":int(entry.get("repeats",1))}
	if Sources.transfer_gift(source):
		issue=_sacrifice.prepare(engine,entry,trigger,_next)
		if not issue.is_empty(): engine._fail(issue);return false
	return true
func deathrattle(engine,entry: Dictionary,effect: Dictionary,repetition: int,trigger: String) -> void:
	var token: int=int(entry.get("_dark_gift_resource_invocation",-1));var invocation: Dictionary=_invocations.get(token,{})
	var source: Dictionary=entry.unit;var side: int=int(entry.side)
	var issue: String=source_error(side,source)
	if issue.is_empty(): issue=Sources.resource_call_error(source,effect)
	var key: String=str(token)+":"+str(repetition)
	if issue.is_empty() and (invocation.is_empty() or not is_same(invocation.get("entry"),entry) or not is_same(invocation.get("source"),source) or invocation.side!=side or invocation.trigger!=trigger or repetition<1 or repetition>int(invocation.repeats) or _calls.has(key)): issue="dark_gift_resource_unissued_or_replayed_deathrattle"
	if not issue.is_empty(): engine._fail(issue);return
	_calls[key]=true
	if Sources.transfer_gift(source):
		_sacrifice.payload(engine,entry,effect,repetition)
		return
	if Sources.spell_gift(source):
		_random_reward(engine,side,source,{"kind":"deathrattle","invocation":token,"repetition":repetition,"trigger":trigger})
		return
	var sequence: int=engine._log.size()
	engine._emit(FREE_EVENT,{"type":FREE_EVENT,"side":side,"owner":_contexts[side].owner,"source":source.uid,"gift_id":Sources.REFRESH_GIFT,"gift_receipt":source[Sources.MARKER].duplicate(true),"amount":2,"invocation":token,"repetition":repetition,"trigger":trigger,"dark_gift_resource_family":FAMILY})
	if engine._log.size()>sequence: _receipts[sequence]=engine._log[sequence].duplicate(true)
func capture_deaths(engine,queue: Array) -> bool:
	for entry in queue:
		if not Sources.group_gift(entry.unit) or not Sources.group_active(entry.unit): continue
		if "reborn" in entry.unit.get("keywords",[]): engine._fail("dark_gift_resource_reborn_inheritance_partial");return false
		if not Sources.death_group_gift(entry.unit): continue
		var issue: String=_whole_error(engine,int(entry.side),entry.unit)
		if not issue.is_empty(): engine._fail(issue);return false
	return true
func complete(engine) -> void:
	if not _initialized or _authorized: return
	_sealed=engine._log.duplicate(true);_seed=engine._seed;_completed=true
func authenticate(result: Dictionary,left: Dictionary,right: Dictionary,ghost: bool) -> String:
	if not _initialized: return "dark_gift_resource_uninitialized_host"
	if _authorized: return "dark_gift_resource_replayed_settlement"
	var log: Array=result.get("log",[])
	if _empty_slot_left>=0:
		var empty_issue: String=_empty_settlement_error(left,right,ghost)
		if not empty_issue.is_empty(): return empty_issue
		if not _completed or not Sources.same(log,_sealed) or result.get("seed")!=_seed or not result.get("error","").is_empty() or log.is_empty() or not log.back() is Dictionary or log.back().get("event")!="combat_end" or log.back().get("error")!="": return "dark_gift_resource_unbound_empty_completed_combat"
	var receipts: Array=log.filter(func(event):return event is Dictionary and record_claimed(event))
	if receipts.size()!=_receipts.size(): return "dark_gift_resource_receipt_count_changed"
	for receipt in receipts:
		if not _receipts.has(receipt.get("sequence")) or not Sources.same(receipt,_receipts[receipt.sequence]): return "dark_gift_resource_actual_receipt_changed"
	if not _bound.is_empty():
		if not _completed or not Sources.same(log,_sealed) or result.get("seed")!=_seed or not result.get("error","").is_empty() or log.is_empty() or log.back().get("event")!="combat_end" or log.back().get("error")!="" or ghost!=_ghost: return "dark_gift_resource_unbound_completed_combat"
		for side in range(2):
			if _contexts[side].get("bindings",[]).is_empty() or (side==1 and ghost): continue
			var owner: Dictionary=left if side==0 else right
			if owner.get("id")!=_contexts[side].owner: return "dark_gift_resource_changed_settlement_owner"
	if _empty_slot_left>=0: _empty_settlement_owners=[left,right]
	_authorized=true
	return ""
func prepare_settlement(left: Dictionary,right: Dictionary,ghost: bool) -> String:
	if not _authorized or _settlement_ready: return "dark_gift_resource_unbound_settlement_plan"
	if _empty_slot_left>=0:
		var empty_issue: String=_empty_settlement_error(left,right,ghost)
		if not empty_issue.is_empty(): return empty_issue
		if _empty_settlement_owners.size()!=2 or not is_same(_empty_settlement_owners[0],left) or not is_same(_empty_settlement_owners[1],right): return "dark_gift_resource_changed_empty_settlement_owners"
	elif ghost!=_ghost: return "dark_gift_resource_unbound_settlement_plan"
	for side in range(2):
		if side==1 and ghost: continue
		var total: int=0
		for event in _receipts.values():
			if event.get("event")==FREE_EVENT and event.side==side:
				if total>MAX-2: return "dark_gift_resource_free_refresh_overflow"
				total+=2
		if total==0: continue
		var owner: Dictionary=left if side==0 else right
		if not Sources.integer(owner.get("free_rolls")) or int(owner.free_rolls)>MAX-total: return "dark_gift_resource_free_refresh_overflow"
	_settlement_ready=true
	return ""
func commit_free(owner: Dictionary,event: Dictionary) -> String:
	var sequence: Variant=event.get("sequence")
	if not _settlement_ready or not _receipts.has(sequence) or _committed.has(sequence) or not Sources.same(_receipts[sequence],event) or event.get("event")!=FREE_EVENT or owner.get("id")!=event.get("owner") or (_ghost and event.get("side")==1): return "dark_gift_resource_invalid_free_refresh_commit"
	if not Sources.integer(owner.get("free_rolls"),0,MAX-2): return "dark_gift_resource_free_refresh_overflow"
	owner.free_rolls=int(owner.free_rolls)+2;_committed[sequence]=true
	return ""
static func recruit_group_error(engine,player: Dictionary,source: Dictionary,groups: Array,repeats: int) -> String:
	if not Sources.death_resource_gift(source): return ""
	var issue: String=Sources.unit_error(source)
	if issue.is_empty(): issue=Sources.closure_error(engine.catalog)
	if not issue.is_empty(): return issue
	if "reborn" in source.get("keywords",[]): return "dark_gift_resource_recruit_reborn_inheritance_partial"
	if source[Sources.MARKER].owner!=player.get("id") or not Sources.integer(repeats,1,512): return "dark_gift_resource_invalid_recruit_owner_or_repeat"
	var count: int=0
	for group in groups:
		for leaf in group:
			if leaf.get("type") in [Sources.REFRESH_GRANT,Sources.SPELL_GRANT]:
				issue=Sources.resource_call_error(source,leaf)
				if not issue.is_empty(): return issue
				count+=1
	if count==0: return ""
	if count!=1: return "dark_gift_resource_recruit_duplicate_attached_group"
	if Sources.spell_gift(source):
		issue=engine.RecruitDeath.ScrapsmithRecruit.GiftHand.source_error(engine,source,groups)
		if not issue.is_empty(): return issue
		var random_plan: Dictionary=Random.recruit_plan(engine,player)
		return "" if random_plan.ok else str(random_plan.error)
	if not Sources.integer(player.get("free_rolls"),0,MAX-2*repeats): return "dark_gift_resource_recruit_free_refresh_overflow"
	return ""
static func bind_recruit(engine,player: Dictionary,source: Dictionary,groups: Array,repeats: int,insertion: Dictionary) -> String:
	if not Sources.death_resource_gift(source): return ""
	var issue: String=recruit_group_error(engine,player,source,groups,repeats)
	if not issue.is_empty(): return issue
	if insertion.has("dark_gift_plan"): return "dark_gift_resource_replayed_recruit_invocation"
	var gift_hand_projection: Dictionary={}
	if Sources.spell_gift(source):
		gift_hand_projection=engine.RecruitDeath.ScrapsmithRecruit.GiftHand.groups_plan(engine,player,source,groups,repeats)
		if not gift_hand_projection.ok: return str(gift_hand_projection.error)
	insertion.dark_gift_plan={"owner":player,"source":source,"receipt":insertion.get("gem_receipt"),"groups":groups.duplicate(true),"repeats":repeats,"used":{}}
	insertion.dark_gift_plan.hand_projection=gift_hand_projection
	return ""
static func recruit(engine,player: Dictionary,source: Dictionary,effect: Dictionary,insertion: Dictionary) -> String:
	var issue: String=Sources.resource_call_error(source,effect)
	if issue.is_empty(): issue=Sources.closure_error(engine.catalog)
	if not issue.is_empty(): return issue
	var receipt: Dictionary=insertion.get("gem_receipt",{})
	var plan: Dictionary=insertion.get("dark_gift_plan",{})
	var position: Dictionary=insertion.get("dark_gift_position",{})
	var repetition: int=int(position.get("repetition",-1));var group: int=int(position.get("group",-1))
	var key: String=str(repetition)+":"+str(group)
	if plan.is_empty() or not is_same(plan.get("owner"),player) or not is_same(plan.get("source"),source) or not is_same(plan.get("receipt"),receipt) or repetition<1 or repetition>int(plan.get("repeats",0)) or group<0 or group>=plan.get("groups",[]).size() or not Sources.same(plan.groups[group],[effect]) or plan.used.has(key): return "dark_gift_resource_unissued_or_replayed_recruit_group"
	if not engine.state.players.any(func(owner):return is_same(owner,player)) or source[Sources.MARKER].owner!=player.get("id") or receipt.get("player")!=player.id or not engine.events.any(func(event):return is_same(event,receipt)) or engine.state.phase not in ["recruit","end_turn"]: return "dark_gift_resource_actual_recruit_origin_required"
	if insertion.get("gem_live_source",false):
		if receipt.get("type")!="recruit_living_deathrattle_activation" or receipt.get("target_uid")!=source.uid or not player.board.any(func(body):return is_same(body,source)): return "dark_gift_resource_actual_recruit_living_group_required"
	else:
		if receipt.get("type")!="recruit_death" or receipt.get("uid")!=source.uid or player.board.any(func(body):return is_same(body,source)): return "dark_gift_resource_actual_recruit_death_required"
	if Sources.spell_gift(source):
		var projection: Dictionary=plan.get("hand_projection",{})
		var cursor: int=int(projection.get("cursor",-1))
		if cursor<0 or cursor>=projection.get("records",[]).size(): return "dark_gift_recruit_missing_private_hand_projection"
		var expected: Dictionary=projection.records[cursor]
		if expected.source_uid!=source.uid or expected.source_id!=source.card_id or expected.repetition!=repetition or expected.group!=group: return "dark_gift_recruit_changed_private_group_order"
		issue=engine.RecruitDeath.ScrapsmithRecruit.GiftHand.before_record(engine,player,expected)
		if not issue.is_empty(): return issue
		plan.used[key]=true
		issue=Random.recruit(engine,player,source,receipt,repetition,expected)
		if not issue.is_empty(): return issue
		projection.cursor=cursor+1
		return ""
	if not Sources.integer(player.get("free_rolls"),0,MAX-2): return "dark_gift_resource_recruit_free_refresh_overflow"
	plan.used[key]=true
	player.free_rolls=int(player.free_rolls)+2
	engine._log("dark_gift_recruit_free_refreshes",{"player":player.id,"source":source.uid,"gift_id":Sources.REFRESH_GIFT,"amount":2,"gift_receipt":source[Sources.MARKER].duplicate(true),"origin_event_index":engine.events.find(receipt),"live":insertion.get("gem_live_source",false)})
	return ""

func _random_reward(engine,side: int,source: Dictionary,origin: Dictionary) -> void:
	var plan: Dictionary=Random.combat_plan(engine,side,source)
	if not plan.ok: engine._fail(str(plan.error));return
	_next+=1
	var token: int=_next
	_random_grants[token]={"engine":engine,"side":side,"source":source,"plan":plan,"origin":origin.duplicate(true),"used":false}
	var start: int=engine._log.size()
	engine._bulk_resource_host.activate_dark_gift(engine,side,source,token)
	if not engine._error.is_empty(): return
	var found: int=0
	for index in range(start,engine._log.size()):
		var event: Dictionary=engine._log[index]
		if not event.has("dark_gift_random_token"): continue
		if event.get("dark_gift_random_token")!=token or event.get("dark_gift_resource_family")!=FAMILY or event.get("source")!=source.uid or event.get("gift_id")!=source[Sources.MARKER].gift_id or not Sources.same(event.get("gift_receipt"),source[Sources.MARKER]) or not Sources.same(event.get("gift_origin"),origin): engine._fail("dark_gift_random_changed_actual_reward");return
		found+=1;_receipts[index]=event.duplicate(true)
	if found!=1: engine._fail("dark_gift_random_missing_actual_reward_or_empty_receipt")
func take_random_grant(engine,side: int,source: Dictionary,token: int) -> Dictionary:
	var grant: Dictionary=_random_grants.get(token,{})
	if grant.is_empty() or grant.used or not is_same(grant.engine,engine) or grant.side!=side or not is_same(grant.source,source): return {"error":"dark_gift_random_unissued_or_replayed_capability"}
	var issue: String=source_error(side,source)
	if not issue.is_empty(): return {"error":issue}
	var plan: Dictionary=grant.plan
	var stock: Dictionary=engine._bulk_resource_host._ghost_stock if side==1 and _ghost else engine._bulk_resource_host._stock
	if not Sources.same(plan.stock,stock) or not Sources.same(plan.board,engine._boards[side]) or plan.hand_count!=engine._hand_counts[side] or plan.seed!=engine._rng.seed or plan.rng!=engine._rng.state: return {"error":"dark_gift_random_stale_capability"}
	grant.used=true
	return {"error":"","plan":plan,"origin":grant.origin,"gift_id":source[Sources.MARKER].gift_id,"receipt":source[Sources.MARKER].duplicate(true),"family":FAMILY,"policy":Random.POLICY}
