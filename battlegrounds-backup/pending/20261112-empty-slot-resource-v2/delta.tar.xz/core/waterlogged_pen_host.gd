extends RefCounted
## Actual owned-slot Elemental giver modifier, never a recipient tribal buff.
const EmptySlot=preload("res://core/empty_combat_slot.gd")
const Sources=preload("res://core/waterlogged_pen_sources.gd")
const Giver=preload("res://core/seaside_gain_host.gd")
const Prefix=preload("res://core/recruit_prefix_cursor.gd")
const CONTEXT: String="waterlogged_pen_combat_context"
const EVENT: String="waterlogged_pen_actual_acquired"
const POLICY: String="actual_single_owned_pen_positive_elemental_giver_before_received_vector_v1"
static func fail(issue: String) -> Dictionary: return {"ok":false,"error":issue}
static func has_source(p: Dictionary) -> bool: return p.get("trinkets",[]).any(func(id):return id in Sources.IDS)
static func elemental(source: Dictionary) -> bool: return source.get("kind","minion")=="minion" and ["元素","全部","all"].any(func(tribe):return tribe in source.get("tribes",[]))
static func player_error(p: Dictionary,round_number: int,catalog=null,allow_new: int=-1) -> String:
	var ledger: Variant=p.get(Sources.STATE,{"owner":p.get("id"),"slots":{}})
	if not ledger is Dictionary or ledger.size()!=2 or ledger.get("owner")!=p.get("id") or not ledger.get("slots") is Dictionary: return "waterlogged_pen_owner_ledger_changed"
	for key in ledger.slots:
		var entry: Variant=ledger.slots[key]
		if not entry is Dictionary or entry.size()!=4 or entry.get("id") not in Sources.IDS or not Sources.integer(entry.get("slot"),0,7) or str(entry.slot)!=key or not Sources.integer(entry.get("round"),1,round_number) or not Sources.integer(entry.get("sequence"),1): return "waterlogged_pen_acquired_slot_changed"
	var found: int=0
	for slot in range(p.get("trinkets",[]).size()):
		var id: String=str(p.trinkets[slot])
		if id not in Sources.IDS: continue
		found+=1
		if slot==allow_new: continue
		if ledger.slots.get(str(slot),{}).get("id")!=id: return "waterlogged_pen_missing_actual_acquisition"
	if found>1: return "waterlogged_pen_multiple_modifier_order_partial"
	return Sources.closure_error(catalog) if found>0 and catalog!=null else ""
static func source_domain(board: Array,hand: Array,accepted_recruit: bool=false) -> String:
	for source in board+hand:
		if Giver.Sources.claimed(source): return "waterlogged_pen_seaside_order_partial"
		for key in ["attachments","dark_gift_attachments","granted_deathrattle_groups","dynamic_spell_enchantments","temporary_native_deathrattles","megasaur_adapt_grants","_piggy_bank_combat_grants"]:
			if source.get(key,[]) not in [[],{}]: return "waterlogged_pen_inherited_producer_partial:"+key
		for effect in source.get("effects",[]):
			var issue: String=preload("res://core/accepted_single_giver_bridge.gd").source_error(source,effect) if accepted_recruit and effect.get("type") in preload("res://core/hand_acquisition_sources.gd").TYPES else Giver.effect_domain(effect,source)
			if not issue.is_empty(): return "waterlogged_pen_whole_producer_domain:"+issue
	return ""
static func owner_error(engine,p: Dictionary,force: bool=false) -> String:
	var issue: String=player_error(p,int(engine.state.round),engine.catalog)
	if not issue.is_empty() or not force and not has_source(p): return issue
	if int(p.get("native_elemental_given_attack",{}).get("attack",0))>0 or int(p.get("native_elemental_given_health",{}).get("health",0))>0: return "waterlogged_pen_owner_giver_modifier_order_partial"
	for key in ["native_ditch_guardian_given_stats","native_enhanced_spawn_given_stats"]:
		if int(p.get(key,{}).get("attack",0))>0 or int(p.get(key,{}).get("health",0))>0: return "waterlogged_pen_other_owner_giver_order_partial"
	issue=source_domain(p.get("board",[]),p.get("hand",[]),engine.state.get("phase") in ["recruit","end_turn"])
	if not issue.is_empty(): return issue
	for effect in engine.Mechanisms._effects(engine,p)+engine.catalog.get_card(str(p.get("hero_id",""))).get("effects",[]):
		if effect.get("type")==Sources.TYPE: continue
		if effect.get("type") not in ["economy","hero_start_free_rolls","hero_upgrade_gold","hero_buy_gold"]: return "waterlogged_pen_owned_or_hero_producer_partial"
	return ""
static func acquisition_error(engine,p: Dictionary,card: Dictionary) -> String:
	if card.get("id") not in Sources.IDS: return ""
	if engine.state.phase!="recruit" or not engine.state.players.any(func(owner):return is_same(owner,p)) or card.get("choice_kind")!="trinket" or not p.discover.any(func(choice):return is_same(choice,card)): return "waterlogged_pen_actual_trinket_offer_required"
	if has_source(p) or p.get("trinkets",[]).size()>=8: return "waterlogged_pen_single_owned_slot_domain"
	var native: Dictionary=card.duplicate(true);native.erase("choice_kind")
	var issue: String=Sources.source_error(native)
	if issue.is_empty(): issue=Sources.closure_error(engine.catalog)
	if issue.is_empty(): issue=owner_error(engine,p,true)
	return issue
static func acquired(engine,p: Dictionary,context: Dictionary) -> String:
	if context.get("source_kind")!="trinket" or context.get("source_id") not in Sources.IDS: return ""
	var ticket: Dictionary=engine._owned_timed_event_context
	if engine.state.phase!="recruit" or not p.get("alive",false) or not engine.state.players.any(func(owner):return is_same(owner,p)) or not is_same(ticket.get("owner"),p) or not is_same(ticket.get("context"),context) or ticket.get("event")!="mechanic_acquired" or ticket.get("round")!=engine.state.round or ticket.get("sequence")!=engine.state.command_sequence or "waterlogged_pen_acquisition" in ticket.get("used",[]): return "waterlogged_pen_actual_acquisition_capability_required"
	var slot: int=p.trinkets.size()-1
	if slot<0 or p.trinkets[slot]!=context.source_id: return "waterlogged_pen_actual_appended_slot_required"
	var issue: String=player_error(p,int(engine.state.round),engine.catalog,slot)
	if not issue.is_empty(): return issue
	if not p.has(Sources.STATE): p[Sources.STATE]={"owner":p.id,"slots":{}}
	if p[Sources.STATE].slots.has(str(slot)): return "waterlogged_pen_reused_acquisition_slot"
	var entry: Dictionary={"id":context.source_id,"slot":slot,"round":engine.state.round,"sequence":engine.state.command_sequence}
	p[Sources.STATE].slots[str(slot)]=entry
	ticket.used.append("waterlogged_pen_acquisition")
	engine._log(EVENT,{"player":p.id,"entry":entry.duplicate(true),"policy":POLICY})
	return owner_error(engine,p)
static func saved_error(state: Dictionary,catalog,events: Array) -> String:
	for p in state.get("players",[])+state.get("ghosts",[]):
		var issue: String=player_error(p,int(state.get("round",0)),catalog)
		if not issue.is_empty(): return issue
		for entry in p.get(Sources.STATE,{}).get("slots",{}).values():
			if int(entry.sequence)>int(state.get("command_sequence",0)): return "waterlogged_pen_future_acquisition"
			var matches: Array=events.filter(func(event):return event.get("type")==EVENT and event.get("player")==p.id and event.get("entry",{}).get("slot")==entry.slot)
			if matches.size()!=1 or matches[0].get("round")!=entry.round or matches[0].get("policy")!=POLICY or not Sources.same(matches[0].get("entry"),entry): return "waterlogged_pen_missing_source_exact_receipt"
	for event in events:
		if event.get("type")!=EVENT: continue
		var owners: Array=state.get("players",[]).filter(func(p):return p.get("id")==event.get("player"))
		if owners.size()!=1 or not event.get("entry") is Dictionary or not Sources.same(owners[0].get(Sources.STATE,{}).get("slots",{}).get(str(event.entry.get("slot"))),event.entry): return "waterlogged_pen_actual_owner_history_removed"
	return ""
static func vector(id: String,source: Dictionary,recipient: Dictionary,attack: int,health: int) -> Dictionary:
	var result: Dictionary={"ok":true,"error":"","attack":attack,"health":health}
	if attack<0 and health<=0 or health<0 and attack<=0: return result
	if source.is_empty(): return fail("waterlogged_pen_unattributed_giver_partial")
	if not elemental(source): return result
	if attack<0 or health<0 or attack==0 and health==0: return fail("waterlogged_pen_nonpositive_or_mixed_gift_partial")
	if source.get("silenced",false) or source.get("abilities_disabled",false): return fail("waterlogged_pen_disabled_giver")
	var effect: Dictionary=Sources.PROGRAMS[id][0]
	if not Sources.integer(attack,0,9007199254740991-int(effect.attack)) or not Sources.integer(health,0,9007199254740991-int(effect.health)): return fail("waterlogged_pen_vector_overflow")
	result.attack=attack+int(effect.attack);result.health=health+int(effect.health)
	for axis in ["attack","health","max_health"]:
		if not Sources.integer(recipient.get(axis),0,9007199254740991-int(result.attack if axis=="attack" else result.health)): return fail("waterlogged_pen_recipient_overflow")
	return result
static func recruit_vector(engine,recipient: Dictionary,attack: int,health: int,source: Dictionary) -> Dictionary:
	var unchanged: Dictionary={"ok":true,"error":"","attack":attack,"health":health}
	if engine.state.phase not in ["recruit","end_turn"]: return unchanged
	var p: Dictionary=Giver.owner(engine,recipient)
	if p.is_empty() or not has_source(p): return unchanged
	var issue: String=owner_error(engine,p)
	if not issue.is_empty(): return fail(issue)
	if not source.is_empty() and elemental(source) and not Giver.present(p.board+p.hand,source): return fail("waterlogged_pen_actual_owned_giver_required")
	var ids: Array=p.trinkets.filter(func(id):return id in Sources.IDS)
	return vector(str(ids[0]),source,recipient,attack,health)
static func attach(engine,options: Dictionary,left: Dictionary,right: Dictionary) -> String:
	for side in range(2):
		var owner: Dictionary=[left,right][side]
		if not Sources.integer(owner.get("id"),0,7) and not EmptySlot.owner_is_empty(side,owner): return "waterlogged_pen_combat_owner_snapshot"
	var contexts: Array=[]
	for p in [left,right]:
		var issue: String=owner_error(engine,p)
		if not issue.is_empty(): return issue
		var ids: Array=p.get("trinkets",[]).filter(func(id):return id in Sources.IDS)
		contexts.append({"owner":p.id,"trinkets":p.get("trinkets",[]).duplicate(true),"ledger":p.get(Sources.STATE,{"owner":p.id,"slots":{}}).duplicate(true),"id":"" if ids.is_empty() else ids[0]})
	options[CONTEXT]=contexts
	return ""
static func combat_domain(left: Array,right: Array,options: Dictionary) -> String:
	if EmptySlot.claimed(options) and not EmptySlot.combat_is_empty(1,-1,right,options): return "waterlogged_pen_combat_owner_snapshot"
	var contexts: Variant=options.get(CONTEXT,[])
	if contexts==[]: return ""
	if not contexts is Array or contexts.size()!=2: return "waterlogged_pen_combat_context_shape"
	for side in range(2):
		var context: Variant=contexts[side]
		if not context is Dictionary or context.size()!=4 or not (Sources.integer(context.get("owner"),0,7) or EmptySlot.combat_is_empty(side,context.get("owner"),right,options) and EmptySlot.pen_is_empty(context)) or not context.get("trinkets") is Array or not context.get("ledger") is Dictionary: return "waterlogged_pen_combat_owner_snapshot"
		var p: Dictionary={"id":context.owner,"trinkets":context.trinkets,Sources.STATE:context.ledger}
		var issue: String=player_error(p,9007199254740991)
		var ids: Array=context.trinkets.filter(func(id):return id in Sources.IDS)
		if not issue.is_empty(): return issue
		if context.get("id")!=("" if ids.is_empty() else ids[0]): return "waterlogged_pen_combat_source_changed"
		if ids.is_empty(): continue
		issue=source_domain([left,right][side],options.get("left_hand" if side==0 else "right_hand",[]))
		if not issue.is_empty(): return issue
	return ""
static func combat_vector(engine,recipient: Dictionary,attack: int,health: int,source: Dictionary,side: int=-1) -> Dictionary:
	var unchanged: Dictionary={"ok":true,"error":"","attack":attack,"health":health}
	var contexts: Array=engine._options.get(CONTEXT,[])
	if side<0: side=int(recipient.get("_side",-1))
	if contexts.is_empty() or side not in [0,1] or contexts[side].get("id","")=="": return unchanged
	if not source.is_empty() and not Giver.combat_source(engine,side,source): return fail("waterlogged_pen_actual_combat_giver_required")
	var hand: Array=engine._combat_hand.hands[side] if engine._combat_hand!=null else []
	var issue: String=source_domain(engine._boards[side],hand)
	if issue.is_empty() and not source.is_empty(): issue=source_domain([source],[])
	if not issue.is_empty(): return fail(issue)
	if not Giver.present(engine._boards[side]+hand,recipient): return fail("waterlogged_pen_actual_combat_recipient_required")
	if Giver.present(engine._boards[side],recipient) and engine._keep_gains_host!=null and engine._keep_gains_host._multiplier(engine,recipient)!=0: return fail("waterlogged_pen_keep_order_partial")
	return vector(str(contexts[side].id),source,recipient,attack,health)
static func command_preflight(engine,player_id: int,command: Dictionary) -> String:
	if engine._waterlogged_pen_projecting or engine.state.phase!="recruit" or player_id<0 or player_id>=engine.state.players.size(): return ""
	var needed: bool=engine.state.players.any(func(p):return has_source(p))
	var p: Dictionary=engine.state.players[player_id]
	needed=needed or p.get("discover",[]).any(func(card):return card.get("id") in Sources.IDS)
	if not needed: return ""
	for owner in engine.state.players:
		var issue: String=owner_error(engine,owner)
		if not issue.is_empty(): return issue
	var cursor: Dictionary={"player":p.duplicate(true),"totals":engine._attack_gain_health_totals.duplicate(true),"next_uid":engine.next_uid,"rng_seed":engine.rng.seed,"rng_state":engine.rng.state,"pool":engine.pool.duplicate(true),"spell_pool":engine.spell_pool.duplicate(true)}
	var detached: Dictionary=Prefix.create(engine,cursor)
	if not detached.ok: return str(detached.error)
	var shadow=detached.engine
	shadow._waterlogged_pen_projecting=true
	shadow._seaside_gain_projecting=true;shadow._loc_prince_projecting=true;shadow._hand_murloc_gain_projecting=true;shadow._master_realities_projecting=true;shadow._mishmash_transition_projecting=true
	shadow._war_drum_projecting=true;shadow._coral_spear_projecting=true;shadow._ice_block_projecting=true;shadow._vashj_old_projecting=true
	shadow._kerrigan_zerg_projecting=true;shadow._lionfish_attack_projecting=true;shadow._owned_rally_eot_projecting=true
	var result: Dictionary=shadow.apply_command(player_id,command.duplicate(true))
	if not result.get("ok",false) or shadow.state.phase=="error": return "waterlogged_pen_complete_command_prefix:"+str(result.get("error",shadow.state.get("error","unknown")))
	for owner in shadow.state.players:
		var issue: String=owner_error(shadow,owner)
		if not issue.is_empty(): return issue
	return saved_error(shadow.state,shadow.catalog,shadow.events)
