extends RefCounted
## Pure zero-source slot shape checks, not proof of Game issuance or authority.
const PEN_CONTEXT: String="waterlogged_pen_combat_context"
const OBSERVER_CONTEXT: String="owned_shield_resource_contexts"
static func _int(value: Variant, expected: int) -> bool:
	return value is int and value==expected
static func _negative_owner(value: Variant) -> bool:
	# Detection is deliberately broader than acceptance: malformed negative
	# representations must enter the strict int -1 shape gate, not evade it.
	if value is int or value is float: return value<0
	if value is String:
		var number: String=value.strip_edges()
		return number.is_valid_float() and number.to_float()<0
	return false
static func _empty(value: Variant) -> bool:
	return value is Array and value.is_empty()
static func _keys(value: Variant, keys: Array) -> bool:
	if not value is Dictionary or value.size()!=keys.size(): return false
	for key in keys:
		if not value.has(key): return false
	return true
static func owner_is_empty(side: int, owner: Variant) -> bool:
	return side==1 and _keys(owner,["id","name","board","hand","tier"]) and _int(owner.id,-1) and owner.name is String and owner.name=="空位幽灵" and _empty(owner.board) and _empty(owner.hand) and _int(owner.tier,1)
static func _context_claims(value: Variant, key: String) -> bool:
	if _negative_owner(value): return true
	if value is Dictionary:
		if _negative_owner(value.get(key)): return true
		var ledger: Variant=value.get("ledger")
		return ledger is Dictionary and _negative_owner(ledger.get("owner"))
	if value is Array:
		for row in value:
			if _negative_owner(row): return true
			if row is Dictionary:
				if _negative_owner(row.get(key)): return true
				var ledger: Variant=row.get("ledger")
				if ledger is Dictionary and _negative_owner(ledger.get("owner")): return true
	return false
static func claimed(options: Dictionary) -> bool:
	if _context_claims(options.get(PEN_CONTEXT),"owner") or _context_claims(options.get(OBSERVER_CONTEXT),"owner_id"): return true
	for key in ["delayed_gold_context","maximum_history_context"]:
		var carrier: Variant=options.get(key)
		if not carrier is Dictionary: continue
		var owners: Variant=carrier.get("owners")
		if _negative_owner(owners): return true
		if owners is Array:
			for owner in owners:
				if _negative_owner(owner): return true
	return false
static func pen_is_empty(context: Variant) -> bool:
	return _keys(context,["owner","trinkets","ledger","id"]) and _int(context.owner,-1) and _empty(context.trinkets) and context.id is String and context.id=="" and _keys(context.ledger,["owner","slots"]) and _int(context.ledger.owner,-1) and context.ledger.slots is Dictionary and context.ledger.slots.is_empty()
static func observer_is_empty(context: Variant) -> bool:
	return _keys(context,["error","owner_id","trinkets","entries"]) and context.error is String and context.error=="" and _int(context.owner_id,-1) and _empty(context.trinkets) and _empty(context.entries)
static func combat_is_empty(side: int, owner_id: Variant, right_input: Variant, options: Dictionary) -> bool:
	if side!=1 or not _int(owner_id,-1) or not _empty(right_input): return false
	if not _int(options.get("right_tier"),1) or not _empty(options.get("right_hand")) or not _int(options.get("right_hand_count"),0): return false
	if not options.get("right_is_ghost") is bool or options.right_is_ghost!=false: return false
	if not options.get("left_is_ghost") is bool or options.left_is_ghost!=false: return false
	var gold: Variant=options.get("delayed_gold_context")
	var maximum: Variant=options.get("maximum_history_context")
	if not gold is Dictionary or not maximum is Dictionary: return false
	var owners: Variant=gold.get("owners")
	var others: Variant=maximum.get("owners")
	if not owners is Array or owners.size()!=2 or not others is Array or others.size()!=2: return false
	if not owners[0] is int or owners[0]<0 or owners[0]>7 or not _int(owners[1],-1): return false
	if not _int(others[0],owners[0]) or not _int(others[1],-1): return false
	var pen: Variant=options.get(PEN_CONTEXT)
	var observer: Variant=options.get(OBSERVER_CONTEXT)
	if not pen is Array or pen.size()!=2 or not observer is Array or observer.size()!=2: return false
	if not pen[0] is Dictionary or not observer[0] is Dictionary: return false
	if not _int(pen[0].get("owner"),owners[0]) or not _int(observer[0].get("owner_id"),owners[0]): return false
	return pen_is_empty(pen[1]) and observer_is_empty(observer[1])
