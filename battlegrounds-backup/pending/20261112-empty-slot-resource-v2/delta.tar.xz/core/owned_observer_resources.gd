extends RefCounted
## Actual Discover completion and actual shield-loss batches; no synthetic hand play.
const EmptySlot=preload("res://core/empty_combat_slot.gd")
const Sources=preload("res://core/owned_observer_resource_sources.gd")
const CONTEXT: String="owned_shield_resource_contexts"
const FAMILY: String="actual-owned-slot-shield-resource-v1"
const PROGRESS: String="owned_shield_resource_progress"
const DISCOVER_EVENT: String="native_minion_discovered"
const POLICY: String="actual_discover_after_native_payoffs_then_owned_slot_order_v1"
var _contexts: Array=[{},{}]
var _counts: Array=[{},{}]
var _seen: Dictionary={}
var _pending: Dictionary={}
var _sealed: Array=[]
var _completed: bool=false
var _authenticated: bool=false
var _seed: int=0

static func _fail(issue: String) -> Dictionary: return {"ok":false,"error":issue}
static func _owns(player: Dictionary,id: String) -> bool: return id in player.get("trinkets",[])
static func prepare_discover(engine,player: Dictionary,index: int) -> Dictionary:
	if not _owns(player,Sources.DISCOVER): return {"ok":true,"error":"","ticket":{}}
	var issue: String=Sources.closure_error(engine.catalog)
	if issue.is_empty(): issue=Sources.Cyclic.player_error(engine.catalog,player)
	if not issue.is_empty(): return _fail(issue)
	if index<0 or index>=player.discover.size(): return _fail("owned_discover_invalid_choice")
	var choice: Dictionary=player.discover[index]
	if choice.get("kind")!="minion": return {"ok":true,"error":"","ticket":{}}
	if engine.state.phase not in ["recruit","end_turn"] or not player.get("alive",false) or not engine.state.players.any(func(owner):return is_same(owner,player)): return _fail("owned_discover_actual_owner_required")
	# The existing native offer verifier admits only real minion selection routes.
	issue=engine.BulkDiscover.NativePayoffs._offers_error(engine,player)
	if not issue.is_empty(): return _fail(issue)
	return {"ok":true,"error":"","ticket":{"owner":player,"owner_id":player.id,"selected_id":choice.id,"offers":player.discover.duplicate(true),"trinkets":player.trinkets.duplicate(true),"round":engine.state.round,"sequence":engine.state.command_sequence,"used":false,"dispatching":false}}
static func _discover_error(engine,player: Dictionary,ticket: Dictionary) -> String:
	if ticket.is_empty() or not is_same(ticket,engine._owned_observer_discover_context) or not is_same(ticket.get("owner"),player) or ticket.owner_id!=player.id or ticket.round!=engine.state.round or ticket.sequence!=engine.state.command_sequence or not Sources.same(ticket.offers,player.discover) or ticket.trinkets!=player.trinkets: return "owned_discover_stale_actual_choice"
	return Sources.closure_error(engine.catalog)
static func complete_discover(engine,player: Dictionary,selected_id: String) -> String:
	var ticket: Dictionary=engine._owned_observer_discover_context
	if ticket.is_empty(): return ""
	var issue: String=_discover_error(engine,player,ticket)
	if not issue.is_empty(): return issue
	if ticket.used or ticket.selected_id!=selected_id or engine.catalog.get_card(selected_id).get("kind")!="minion": return "owned_discover_replayed_or_nonminion_choice"
	ticket.used=true;ticket.dispatching=true
	engine._log("owned_minion_discover_completed",{"player":player.id,"selected_id":selected_id,"policy":POLICY})
	engine.Mechanisms.on_event(engine,player,DISCOVER_EVENT,{"actual_discover_ticket":ticket})
	ticket.dispatching=false
	return "owned_discover_actual_reward_failed" if engine.state.phase=="error" else ""
static func event_error(engine,player: Dictionary,context: Dictionary) -> String:
	var ticket: Variant=context.get("actual_discover_ticket")
	if context.size()!=1 or not ticket is Dictionary: return "owned_discover_missing_private_completion"
	var issue: String=_discover_error(engine,player,ticket)
	if not issue.is_empty(): return issue
	return "" if ticket.get("used")==true and ticket.get("dispatching")==true else "owned_discover_not_actual_completion_dispatch"

static func context_for(owner: Dictionary,catalog) -> Dictionary:
	if not owner.get("trinkets",[]) is Array: return {"error":"shield_resource_invalid_owned_slots"}
	var entries: Array=[]
	for index in range(owner.get("trinkets",[]).size()):
		if owner.trinkets[index]!=Sources.SHIELD: continue
		var issue: String=Sources.source_error(catalog.get_card(Sources.SHIELD))
		if not issue.is_empty(): return {"error":issue}
		entries.append({"source_id":Sources.SHIELD,"source_slot":"trinket:%d:%s:0" % [index,Sources.SHIELD]})
	return {"error":"","owner_id":owner.get("id",-1),"trinkets":owner.get("trinkets",[]).duplicate(true),"entries":entries}
static func attach(options: Dictionary,left: Dictionary,right: Dictionary,catalog) -> String:
	for side in range(2):
		var owner: Dictionary=[left,right][side]
		if not Sources.integer(owner.get("id"),0,7) and not EmptySlot.owner_is_empty(side,owner): return "shield_resource_changed_context"
	var contexts: Array=[context_for(left,catalog),context_for(right,catalog)]
	for context in contexts:
		if not str(context.error).is_empty(): return str(context.error)
	options[CONTEXT]=contexts
	return ""
func initialize(engine,right_input: Variant=null) -> String:
	if EmptySlot.claimed(engine._options) and not EmptySlot.combat_is_empty(1,-1,right_input,engine._options): return "shield_resource_changed_context"
	var contexts: Variant=engine._options.get(CONTEXT,[{},{}])
	if not contexts is Array or contexts.size()!=2: return "shield_resource_invalid_contexts"
	for side in range(2):
		var context: Variant=contexts[side]
		if not context is Dictionary: return "shield_resource_invalid_context"
		if context.is_empty(): continue
		if context.size()!=4 or context.get("error")!="" or not context.get("trinkets") is Array or not context.get("entries") is Array or not (Sources.integer(context.get("owner_id"),0,7) or EmptySlot.combat_is_empty(side,context.get("owner_id"),right_input,engine._options) and EmptySlot.observer_is_empty(context)): return "shield_resource_changed_context"
		var expected: Array=[]
		for index in range(context.trinkets.size()):
			if context.trinkets[index]!=Sources.SHIELD: continue
			var slot: String="trinket:%d:%s:0" % [index,Sources.SHIELD]
			expected.append({"source_id":Sources.SHIELD,"source_slot":slot})
			_counts[side][slot]=0
		if not Sources.same(expected,context.entries): return "shield_resource_changed_slot_order"
		_contexts[side]=context.duplicate(true)
	return ""
func shield_loss(engine,loss: Dictionary) -> bool:
	if _contexts.all(func(context):return context.is_empty() or context.entries.is_empty()): return true
	if _completed: engine._fail("shield_resource_closed_combat");return false
	var unit: Variant=loss.get("unit")
	var attacker: Variant=loss.get("source")
	if not unit is Dictionary or not attacker is Dictionary or not Sources.integer(unit.get("_side"),0,1) or not Sources.integer(loss.get("sequence"),0,engine._log.size()-1): engine._fail("shield_resource_missing_real_loss");return false
	var side: int=int(unit._side)
	var sequence: int=int(loss.sequence)
	var event: Dictionary=engine._log[sequence]
	if event.get("event")!="shield_lost" or event.get("target")!=unit.get("uid") or event.get("source")!=attacker.get("uid") or not Sources.integer(event.get("blocked"),1,9223372036854775807): engine._fail("shield_resource_unproved_actual_loss");return false
	if _seen.has(sequence): engine._fail("shield_resource_replayed_loss");return false
	_seen[sequence]=true
	if _contexts[side].is_empty(): return true
	# Per real loss, board listeners precede owned slot effects (public local order).
	for entry in _contexts[side].entries:
		var before: int=int(_counts[side][entry.source_slot])
		if before>=4: continue
		_counts[side][entry.source_slot]=before+1
		var progress: int=engine._log.size()
		engine._emit(PROGRESS,{"owned_shield_resource_family":FAMILY,"side":side,"source_id":entry.source_id,"source_slot":entry.source_slot,"target":unit.uid,"loss_sequence":sequence,"before":before,"after":before+1})
		if engine._bulk_resource_host==null: engine._fail("shield_resource_missing_actual_resource_host");return false
		_pending[progress]={"side":side,"source_slot":entry.source_slot}
		engine._bulk_resource_host.activate_owned_shield_trinket(engine,side,str(entry.source_slot),progress)
		if not engine._error.is_empty(): return false
	return true
func consume_grant(side: int,slot: String,progress: int) -> bool:
	if _completed or not _pending.has(progress) or _pending[progress].side!=side or _pending[progress].source_slot!=slot: return false
	_pending.erase(progress)
	return true
func complete(engine) -> void:
	_completed=true;_seed=engine._seed;_sealed=engine._log.duplicate(true)
static func result_claimed(events: Array) -> bool:
	return events.any(func(event):return event is Dictionary and (event.has("owned_shield_resource_family") or event.get("event")==PROGRESS))
func authenticate(result: Dictionary,left: Dictionary,right: Dictionary,ghost: bool) -> String:
	if _authenticated or not _completed or result.get("seed")!=_seed or not Sources.same(result.get("log"),_sealed) or result.get("error")!="" or _sealed.is_empty() or _sealed[-1].get("event")!="combat_end": return "shield_resource_not_actual_successful_result"
	var owners: Array=[left,right]
	for side in range(2):
		if _contexts[side].is_empty() or ghost and side==1: continue
		if owners[side].get("id")!=_contexts[side].owner_id or owners[side].get("trinkets",[])!=_contexts[side].trinkets: return "shield_resource_changed_actual_owned_slots"
	_authenticated=true
	return ""
