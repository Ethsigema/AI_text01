extends "res://tests/empty_slot_resource_v2_20261112/dark_gift_empty_contract.gd"
