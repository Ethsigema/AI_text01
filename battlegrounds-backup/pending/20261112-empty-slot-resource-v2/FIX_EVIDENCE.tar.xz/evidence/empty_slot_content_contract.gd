extends "res://tests/empty_combat_slot_20261112/content_contract.gd"
