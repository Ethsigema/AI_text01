from pathlib import Path
import re,hashlib,json
r=Path(__file__).resolve().parent;p=r/'game_candidate';old=r/'research_old_candidate/extracted/rider_gameplay_review_20261110T043010Z/candidate';pre=json.loads((r/'PREIMAGE_HASHES.json').read_text());pat=re.compile(r'("((?:res://)?[^"\n]+\.[a-z0-9]+)"\s*:\s*")([0-9a-f]{64})(")');updates=[];prior=json.loads((r/'evidence/PIN_UPDATES.json').read_text())['updates'];before=json.loads((r/'evidence/BEFORE_FINAL_METADATA_HASHES.json').read_text())
h=lambda x:hashlib.sha256(x.read_bytes()).hexdigest()
for iteration in range(20):
 changed=False
 for file in sorted(p.glob('core/*.gd')):
  original=file.read_text();replacements=[]
  for m in pat.finditer(original):
   name=m[2].removeprefix('res://');target=p/name
   if not target.is_file():continue
   actual=h(target)
   if m[3]==actual:continue
   allowed={pre.get(name),before.get(name)}
   if (old/name).is_file():allowed.add(h(old/name))
   allowed.update(x['new'] for x in prior+updates if x['target']==name)
   # Dependent sources can have been repinned in an earlier pass; their
   # original fingerprints are still rooted in the verified preimage.
   if m[3] not in allowed:raise ValueError(('unexpected stale pin',file,name,m[3],actual))
   replacements.append((m.start(3),m.end(3),actual));updates.append({'source':file.relative_to(p).as_posix(),'target':name,'old':m[3],'new':actual})
  if replacements:
   for a,b,new in reversed(replacements):original=original[:a]+new+original[b:]
   file.write_text(original);changed=True
 if not changed:break
else:raise ValueError('hash dependency cycle')
checks=0
for file in sorted(p.glob('core/*.gd')):
 for m in pat.finditer(file.read_text()):
  target=p/m[2].removeprefix('res://')
  if target.is_file():assert h(target)==m[3],(file,target);checks+=1
(r/'evidence/PIN_UPDATES.json').write_text(json.dumps({'existing_pins_matched':checks,'updates':updates},indent=2)+'\n');print('updated',len(updates),'pins;',checks,'existing pins match')
