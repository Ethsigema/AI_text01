from pathlib import Path
import hashlib,json,re,shutil,subprocess
root=Path(__file__).resolve().parent;project=root/'game_candidate';old=root/'research_old_candidate/extracted/rider_gameplay_review_20261110T043010Z/candidate'
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
pre={p.relative_to(project).as_posix():h(p) for p in project.rglob('*') if p.is_file()}
assert not (root/'PREIMAGE_HASHES.json').exists()
(root/'PREIMAGE_HASHES.json').write_text(json.dumps(pre,indent=2,sort_keys=True)+'\n')
for n in ['core/rider_sources.gd','core/rider_host.gd','data/rider_overlay.json']+[p.relative_to(old).as_posix() for p in (old/'research/rider').rglob('*') if p.is_file()]:
 dst=project/n;assert not dst.exists();dst.parent.mkdir(exist_ok=True,parents=True);shutil.copyfile(old/n,dst)
for name in ['game','combat','catalog']:
 result=subprocess.run(['patch','--batch','--fuzz=0','-p1','-i',str(old/'patches'/f'{name}.patch')],cwd=project,capture_output=True,text=True)
 (root/'evidence'/f'{name}_patch.log').write_text(result.stdout+result.stderr);assert result.returncode==0,(name,result.stdout,result.stderr)
# Preserve the old candidate's rejection as an isolated source-contract test.
shutil.copyfile(project/'core/rider_sources.gd',root/'evidence/rider_sources_before_pool_fix.gd')
p=project/'core/rider_sources.gd';s=p.read_text();needle='\treturn "" if same(card,EXPECTED_CURRENT[card.id]) else "rider_changed_whole_source"'
assert s.count(needle)==1
s=s.replace(needle,'''\t# Catalog annotates golden minions after overlay application. Preserve the
\t# complete canonical source, accepting only this exact native annotation.
\tvar expected: Dictionary=EXPECTED_CURRENT[card.id].duplicate(true)
\tif card.id==IDS[1] and card.has("pool_blocker"):
\t\texpected.pool_blocker=preload("res://core/pool_identity.gd").MINION_REASON
\treturn "" if same(card,expected) else "rider_changed_whole_source"''');p.write_text(s)
p=project/'core/game.gd';s=p.read_text();needle='\t_finish_round_owned(combat_owners)';assert s.count(needle)==1;s=s.replace(needle,needle+'\n\t_rider_combat_authority={}');p.write_text(s)
p=project/'core/combat.gd';s=p.read_text();needle='func release_owned_references() -> void:';assert s.count(needle)==1;s=s.replace(needle,needle+'\n\t_rider_host=null;_rider_authority={};_rider_dispatch_context={};_rider_removal_context={}');p.write_text(s)
print('Applied exact old integration patches plus golden source and lifecycle fixes.')
