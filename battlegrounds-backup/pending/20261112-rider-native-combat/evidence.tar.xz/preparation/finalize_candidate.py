from pathlib import Path
import json,hashlib,shutil
r=Path(__file__).resolve().parent;p=r/'game_candidate';e=r/'evidence'
h=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
(e/'BEFORE_FINAL_METADATA_HASHES.json').write_text(json.dumps({f.relative_to(p).as_posix():h(f) for f in p.rglob('*') if f.is_file() and '.godot' not in f.parts},indent=2)+'\n')
changes={
'rider-native-death-candidate-20261110':'rider-native-death-verified-slice-20261112',
'partial_rider_native_death_candidate_uninstalled':'partial_rider_native_death_verified_slice',
'rider_gameplay_candidate_20261110':'rider_gameplay_verified_slice_20261112',
'Cumulative uninstalled candidate. Natural original death only, finite native board domain, original Combat deathrattle repeats and stat writer. Full engine not executed.':'Isolated verified slice. Real Game/Combat natural original death, 0/2/3/6 owner spells, ordinary/golden Titus repeats and native stat writer. Finite original board domain only; nonempty combat cast journals and other intersections remain held.'}
for name in ['core/rider_sources.gd','data/rider_overlay.json']:
 f=p/name;s=f.read_text()
 for a,b in changes.items():assert a in s;s=s.replace(a,b)
 f.write_text(s)
f=r/'repin_candidate.py';s=f.read_text().replace("before=json.loads((r/'evidence/BEFORE_BASE_FIX_HASHES.json').read_text())","before=json.loads((r/'evidence/BEFORE_FINAL_METADATA_HASHES.json').read_text())");f.write_text(s)
s=(e/'rider_source_base_contract.gd').read_text()
s=s.replace(' check(before.source_error(golden)==', ' var old_golden=before.EXPECTED_CURRENT["BG31_925_G"].duplicate(true)\n check(before.source_error(old_golden).is_empty(),"old_canonical_before_native_annotation")\n old_golden.pool_blocker=P.MINION_REASON\n check(before.source_error(old_golden)==')
needle=' check(S.proof_error()'
insert=''' for id in S.IDS:
  var card=S.EXPECTED_CURRENT[id]
  var base={"card_id":id,"name":card.name,"tier":card.tier,"attack":card.attack,"health":card.health,"max_health":card.health,"keywords":card.keywords.duplicate(),"tribes":card.tribes.duplicate(),"effects":S.program(id),"golden":card.is_golden}
  for key in ["keywords","effects","golden"]:
   var changed=base.duplicate(true)
   changed[key]=["taunt"] if key=="keywords" else ([{"type":"deathrattle_buff","attack":999}] if key=="effects" else not base.golden)
   check(not S.unit_error(changed,true).is_empty(),"reject_changed_base_"+key+"_"+id)
  var live=base.duplicate(true);live.kind="minion"
  check(S.unit_error(live).is_empty(),"live_identity_with_kind_"+id)
  live.erase("kind")
  check(S.unit_error(live)=="rider_changed_unit_identity","live_missing_kind_still_rejected_"+id)
'''
assert s.count(needle)==1;s=s.replace(needle,insert+needle);(e/'rider_source_base_contract_final.gd').write_text(s)
t=p/'tests/rider_20261112';t.mkdir(exist_ok=False)
for a,b in [('rider_real_combat_matrix.gd','real_combat_matrix.gd'),('rider_source_base_contract_final.gd','source_base_contract.gd'),('rider_sources_before_pool_fix.gd','rider_sources_before_pool_fix.gd')]:shutil.copyfile(e/a,t/b)
(t/'README.md').write_text('''# 显眼的骑手：真实战斗限定验证

在完整 Godot 4.6.3 工程运行：

    godot --headless --path . --script tests/rider_20261112/real_combat_matrix.gd
    godot --headless --path . --script tests/rider_20261112/source_base_contract.gd

第一项加载完整 Game/Catalog，通过原生工厂及入手创建测试牌，之后所有出牌、酒馆币施法及双方结束回合均走公开 apply_command。11 个独立受限房间用例，291 项检查。覆盖普通/金色骑手施法 0/2/3/6 次、普通/金色瑞文戴尔男爵的原生重复、对手施法计数隔离、自然死亡、真实属性提交、战斗加成不写回招募、进入第 2 回合及清理 Game 权限引用。未伪造法术计数，未直接改战队或替代战斗属性写入器。测试牌不代表随机商店获取或三连获取。

第二项是来源/原生 base_unit 结构的局部合同测试，不是完整对局。保留旧来源文件用于复现原金色池注记及 base_unit 误拒。

本次仅验收原艾德温、普通/金色骑手、迷你侍从、乘波骑士、碎地者、瑞文戴尔男爵组成的有限原生战队；只测试真实酒馆铸币计数。暂不支持骑手与临时层、复生、复制/变形、非空战斗玩家施法历史、幽灵、其他英雄/任务/饰品等组合。不是全卡池、整局、旧存档或完整饰品验收。该增量包含已验证碎地者修复，不覆盖原始工作树。
''')
