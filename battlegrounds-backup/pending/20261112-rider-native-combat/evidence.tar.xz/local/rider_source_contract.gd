extends SceneTree
const S=preload("res://core/rider_sources.gd")
const P=preload("res://core/pool_identity.gd")
var passed=0
var failed=0
func check(ok: bool,label: String):
 if ok:passed+=1
 else:failed+=1
 print("PASS " if ok else "FAIL ",label)
func _initialize():
 var before=load(get_script().resource_path.get_base_dir()+"/rider_sources_before_pool_fix.gd")
 var golden=S.EXPECTED_CURRENT["BG31_925_G"].duplicate(true)
 golden.pool_blocker=P.MINION_REASON
 check(before.source_error(golden)=="rider_changed_whole_source","reproduce_old_golden_pool_annotation_rejection")
 check(S.source_error(golden).is_empty(),"accept_exact_native_golden_annotation")
 for id in S.IDS:
  var source=S.EXPECTED_CURRENT[id].duplicate(true)
  check(S.source_error(source).is_empty(),"canonical_"+id)
  source.attack+=1
  check(S.source_error(source)=="rider_changed_whole_source","changed_attack_"+id)
  source=S.EXPECTED_CURRENT[id].duplicate(true);source.unexpected=true
  check(S.source_error(source)=="rider_changed_whole_source","unknown_metadata_"+id)
 var normal=S.EXPECTED_CURRENT["BG31_925"].duplicate(true);normal.pool_blocker=P.MINION_REASON
 check(S.source_error(normal)=="rider_changed_whole_source","normal_annotation_not_permitted")
 for invalid in ["",true,0,[],{},"another_reason"]:
  var changed=golden.duplicate(true);changed.pool_blocker=invalid
  check(S.source_error(changed)=="rider_changed_whole_source","wrong_annotation_"+str(invalid))
 check(S.proof_error().is_empty(),"complete_current_source_fingerprints")
 print("SOURCE_CONTRACT passed=",passed," failed=",failed)
 quit(0 if failed==0 else 1)
