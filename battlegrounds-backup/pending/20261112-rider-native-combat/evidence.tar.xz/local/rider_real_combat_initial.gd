extends SceneTree
var game
var cat
var checks=0
func must(ok: bool,label: String) -> bool:
 checks+=1
 print("PASS " if ok else "FAIL ",label)
 if not ok: quit(1)
 return ok
func give_play(player: int,id: String) -> Dictionary:
 var card=cat.get_card(id)
 if card.is_empty():print("EMPTY_CARD ",id);return {}
 var unit=game._unit(card)
 var p=game.state.players[player]
 game._add_hand(p,unit)
 var result=game.apply_command(player,{"type":"play","index":p.hand.find(unit),"target":-1,"position":-1})
 print("PLAY ",player," ",id," ",JSON.stringify(result))
 return unit if result.get("ok",false) else {}
func _initialize() -> void:
 print("LOAD_BEGIN")
 var Game=load("res://core/game.gd")
 cat=load("res://core/catalog.gd").new()
 cat.load_catalog()
 print("CATALOG_ERRORS ",JSON.stringify(cat.load_errors))
 if not must(cat.load_errors.is_empty(),"real_catalog"):return
 for id in ["BG31_925","BG31_925_G"]:
  if not must(not cat.get_card(id).is_empty(),"complete_source_"+id):return
 game=Game.new()
 var room=load("res://core/room_config.gd").new()
 room.reset(cat)
 room.data.enabled_minions=["BG31_925","BG31_035","BG23_000","BG23_007","BG25_354"]
 room.data.enabled_spells=["BG28_810"]
 room.data.selected_hero="TB_BaconShop_HERO_01"
 room.data.enabled_heroes=["TB_BaconShop_HERO_01"]
 room.data.bot_count=1
 room.data.seed=2026
 for key in ["enabled_anomalies","enabled_quests","enabled_rewards","enabled_trinkets"]:room.data[key]=[]
 var start=game.start(room.data,cat)
 print("START ",JSON.stringify(start))
 if not must(start.get("ok",false),"real_limited_room"):return
 var rider=give_play(0,"BG31_925")
 var mini=give_play(0,"BG23_000")
 var wave=give_play(0,"BG23_007")
 var enemy=give_play(1,"BG31_035_G")
 if not must(not rider.is_empty() and not mini.is_empty() and not wave.is_empty() and not enemy.is_empty(),"real_native_units_and_public_plays"):return
 for i in range(3):
  if not must(not give_play(0,"BG28_810").is_empty(),"actual_coin_"+str(i+1)):return
 var p=game.state.players[0]
 if not must(p.stats.spells==3,"real_player_counter_three"):return
 var before=p.board.duplicate(true)
 var ready=game.apply_command(1,{"type":"end_turn"})
 if not must(ready.get("ok",false) and game.state.players[1].ready,"opponent_public_ready"):return
 var ended=game.apply_command(0,{"type":"end_turn"})
 print("END ",JSON.stringify(ended)," phase=",game.state.phase," round=",game.state.round)
 if not must(ended.get("ok",false),"actual_game_end_turn"):return
 if not must(game.last_combats.size()==1,"actual_combat_result"):return
 var result=game.last_combats[0]
 print("COMBAT_ERROR ",result.get("error",""))
 if not must(str(result.get("error","")).is_empty(),"actual_combat_success"):return
 var deaths=result.log.filter(func(e):return e.get("event")=="death" and e.get("unit")==rider.uid)
 var buffs=result.log.filter(func(e):return e.get("event")=="buff" and e.get("source")==rider.uid)
 print("RIDER_DEATHS ",JSON.stringify(deaths))
 print("RIDER_BUFFS ",JSON.stringify(buffs))
 if not must(deaths.size()==1 and not buffs.is_empty(),"natural_death_and_native_stat_commits"):return
 for buff in buffs:
  if not must(buff.attack_delta==4 and buff.health_delta==2,"actual_three_spell_buff_"+str(buff.target)):return
  var target=before.filter(func(u):return u.uid==buff.target)
  if not must(target.size()==1 and "纳迦" in target[0].tribes and buff.attack==target[0].attack+4,"real_naga_recipient_attack_committed"):return
 for unit in p.board:
  var original=before.filter(func(u):return u.uid==unit.uid)
  if not original.is_empty():
   if not must(unit.attack==original[0].attack and unit.health==original[0].health,"combat_only_buff_not_written_to_recruit"):return
 if not must(game._rider_combat_authority.is_empty(),"released_game_authority"):return
 if not must(game.state.phase=="recruit" and game.state.round==2,"returned_to_next_recruit"):return
 print("RIDER_REAL_COMBAT_PASS checks=",checks)
 quit(0)
