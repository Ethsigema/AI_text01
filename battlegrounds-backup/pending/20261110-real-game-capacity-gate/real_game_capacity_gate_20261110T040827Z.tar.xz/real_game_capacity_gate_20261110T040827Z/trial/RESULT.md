# 唯一真实 Game 加载/实例预算试验

结果：FAILED_OR_CONTROLLED_STOP / controlled_RSS_stop。仅做一次，未提高预算、未重试。

- 候选覆盖优先的完整原字节闭包：2072脚本，42,844,718B，其中61份来自冻结候选，其余来自原runtime。额外3处extends边的真实父脚本均已经在闭包中。
- 约束：768MiB RSS软停止、2GiB AS硬限制、两CPU亲和、45秒、5ms轮询；Python软128MiB/hard2GiB，使child能够设置已批准的AS。单Godot隔离HOME/XDG，无整局、无Catalog.load_catalog、无_buff、无compiler driver。
- 启动MemAvailable：9389244416B；退出后：9369714688B。启动门槛6GiB，运行余量4GiB。
- 时长：2.338648334000027秒。exit=-15。
- exact PID os.wait4峰值：788432KiB。采样峰值：807444480B。768MiB阈值805,306,368B，采样超过阈值2,138,112B（软阈值的采样/终止延迟，不是内核RSS硬限）。
- 日志只有Godot版本及REAL_GAME_LOAD_BEGIN；REAL_GAME_LOAD_OK与REAL_GAME_INSTANCE_NATIVE_HOSTS_OK均未出现，无SCRIPT ERROR记录。尚未完成原Game加载，未到.new和真实host检查，不能声称初始化或玩法通过。
- 拷贝输入hash全部不变：True。
- 被选中原runtime/候选源输入hash全部不变：True。
- 原runtime及候选两者core全体.gd树hash均不变：True。这项核对范围是明确的源代码技术树，不读取缓存/凭据/旧存档；未宣称对整个大runtime资源树逐字hash。
- 启动前其他Godot：[]；结束后：[]。

证据：INPUT_MANIFEST.json（各文件来源/SHA256/依赖边），SOURCE_TREE_PINS.json，INITIALIZER_AUDIT.json，INITIALIZATION_REVIEW.md，result/LAUNCH.json，result/PROCESS.json，result/samples.jsonl，result/native.log。run.py通过result目录exist_ok=False阻止重复运行。

结论：本次768MiB预算仍未完成原类加载。真实属性提交/修饰器/完整Shatterer玩法验收仍然空缺。停止这条运行路线，不借成功的host请求测试替代、不自动升限或另试。
