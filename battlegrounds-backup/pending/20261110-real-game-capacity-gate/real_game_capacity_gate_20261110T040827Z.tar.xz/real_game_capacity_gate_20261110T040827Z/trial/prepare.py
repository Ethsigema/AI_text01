from pathlib import Path
import re,json,hashlib,resource
resource.setrlimit(resource.RLIMIT_AS,(128*1024**2,2*1024**3))
root=Path(__file__).resolve().parent; base=root.parent/'historical_tools_batch14_20261109T191857Z/runtime'; cand=root.parent/'shatterer_gameplay_candidate_20261110'; project=root/'project';project.mkdir()
files={};todo=['core/game.gd'];audit=[];flags=[]
def digest(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
while todo:
 rel=todo.pop()
 if rel in files:continue
 src=cand/rel if (cand/rel).is_file() else base/rel
 data=src.read_bytes();s=data.decode();deps=re.findall(r'preload\(\s*[\"\']res://([^\"\']+)',s)
 assert all(d.startswith('core/') and d.endswith('.gd') for d in deps),(rel,deps)
 out=project/rel;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(data)
 files[rel]={'source':str(src),'sha256':digest(src),'bytes':len(data),'deps':deps}
 for n,l in enumerate(s.splitlines(),1):
  if re.match(r'(static var |static func _static_init|func _init\(|var .*\.new\()',l):audit.append([rel,n,l])
  if re.match(r'static func _static_init',l):flags.append([rel,n,l])
 todo.extend(deps)
# Audit exact constructors reachable from Game.new, without instantiating Combat.
for rel in ['core/game.gd','core/kerrigan_zerg_recruit.gd','core/loc_prince_host.gd','core/master_realities_host.gd']:
 s=(project/rel).read_text()
 (root/(Path(rel).stem+'_initialization.txt')).write_text('\n'.join(f'{i}: {l}' for i,l in enumerate(s.splitlines(),1) if re.match(r'^(var |static var |func _init|static func _static_init)',l)))
(root/'INITIALIZER_AUDIT.json').write_text(json.dumps(audit,indent=2))
sourcepins={str(p):digest(p) for d in [base/'core',cand/'core'] for p in d.rglob('*.gd')}
(root/'SOURCE_TREE_PINS.json').write_text(json.dumps(sourcepins,indent=2))
manifest={'source_runtime':str(base),'candidate':str(cand),'files':files,'file_count':len(files),'total_source_bytes':sum(x['bytes'] for x in files.values()),'candidate_count':sum(x['source'].startswith(str(cand)) for x in files.values()),'flags':flags}
(root/'INPUT_MANIFEST.json').write_text(json.dumps(manifest,indent=2))
(project/'project.godot').write_text('config_version=5\n[application]\nconfig/name="Bounded real Game preload only"\n[rendering]\nrenderer/rendering_method="gl_compatibility"\n')
(project/'probe.gd').write_text('''extends SceneTree
func _init() -> void:
 print("REAL_GAME_LOAD_BEGIN")
 var script = load("res://core/game.gd")
 if script == null or not script.can_instantiate():
  push_error("REAL_GAME_LOAD_FAILED")
  quit(2)
  return
 print("REAL_GAME_LOAD_OK")
 var instance = script.new()
 if instance == null or instance._loc_prince_host == null or instance._master_realities_host == null or instance._kerrigan_zerg_recruit_host == null or instance.rng == null:
  push_error("REAL_GAME_INSTANCE_FAILED")
  quit(3)
  return
 if instance._loc_prince_host.get_script() != script.LocPrince or instance._master_realities_host.get_script() != script.MasterRealities or instance._kerrigan_zerg_recruit_host.get_script() != script.KerriganRecruit:
  push_error("REAL_GAME_NATIVE_HOST_IDENTITY_FAILED")
  quit(4)
  return
 print("REAL_GAME_INSTANCE_NATIVE_HOSTS_OK")
 instance = null
 quit(0)
''')
print({k:v for k,v in manifest.items() if k!='files'})
