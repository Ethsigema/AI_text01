extends SceneTree
func _init() -> void:
 print("REAL_GAME_LOAD_BEGIN")
 var script = load("res://core/game.gd")
 if script == null or not script.can_instantiate():
  push_error("REAL_GAME_LOAD_FAILED")
  quit(2)
  return
 print("REAL_GAME_LOAD_OK")
 var instance = script.new()
 if instance == null or instance._loc_prince_host == null or instance._master_realities_host == null or instance._kerrigan_zerg_recruit_host == null or instance.rng == null:
  push_error("REAL_GAME_INSTANCE_FAILED")
  quit(3)
  return
 if instance._loc_prince_host.get_script() != script.LocPrince or instance._master_realities_host.get_script() != script.MasterRealities or instance._kerrigan_zerg_recruit_host.get_script() != script.KerriganRecruit:
  push_error("REAL_GAME_NATIVE_HOST_IDENTITY_FAILED")
  quit(4)
  return
 print("REAL_GAME_INSTANCE_NATIVE_HOSTS_OK")
 instance = null
 quit(0)
