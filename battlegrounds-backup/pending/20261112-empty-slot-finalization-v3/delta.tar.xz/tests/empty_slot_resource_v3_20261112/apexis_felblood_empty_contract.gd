extends SceneTree
# Detached pure contracts only, never native combat provenance or Game execution.
const Base=preload("res://tests/empty_combat_slot_20261112/content_contract.gd")
const Apexis=preload("res://core/apexis_guardian_host.gd")
const Fel=preload("res://core/felblood_portrait_combat.gd")
var passed=0
var failed=0
var failures=[]
class EngineFixture:
 extends RefCounted
 var _seed: int=20261120
 var _options: Dictionary={}
 var _boards: Array=[[],[]]
 var _log: Array=[{"event":"combat_start"},{"event":"combat_end","error":""}]
 var _attack_gain_health_totals: Dictionary={}
func check(ok: bool,label: String) -> void:
 if ok:passed+=1;print("PASS ",label)
 else:failed+=1;failures.append(label);printerr("FAIL ",label)
func left_owner() -> Dictionary:
 return {"id":0,"name":"detached fixture","board":[],"hand":[],"tier":1,"trinkets":[]}
func right_owner() -> Dictionary:
 return {"id":-1,"name":"空位幽灵","board":[],"hand":[],"tier":1}
func options_fixture() -> Dictionary:
 var options={"left_hand":[],"right_hand":[],"right_hand_count":0,"right_tier":1,"left_is_ghost":false,"right_is_ghost":false,"left_global_card_state":{"id":0},"maximum_history_context":{"owners":[0,-1],"round":1},"delayed_gold_context":{"owners":[0,-1],"round":1,"transaction_id":"detached-shape-only"}}
 var left=left_owner();var right=right_owner()
 check(Base.Pen.attach({"state":{"round":1},"catalog":null},options,left,right).is_empty(),"fixture_pen_attach")
 check(Base.Observer.attach(options,left,right,null).is_empty(),"fixture_observer_attach")
 check(Apexis.attach(options,left,right,null).is_empty(),"fixture_apexis_attach")
 check(Fel.attach(options,left,right,null).is_empty(),"fixture_felblood_attach")
 return options
func result_for(engine) -> Dictionary:
 return {"seed":engine._seed,"log":engine._log.duplicate(true),"error":""}
func reject_apexis(options: Dictionary,label: String,left: Variant=[],right: Variant=[]) -> void:
 var engine=EngineFixture.new();engine._options=options;var before=options.duplicate(true);var host=Apexis.new()
 check(not host.initialize(engine,left,right).is_empty(),label+"_init_rejected")
 check(host.observers(engine,0).is_empty() and host.observers(engine,1).is_empty(),label+"_no_observers")
 check(host.capability(engine,0,{}, {},"", "").is_empty(),label+"_no_capability")
 check(not host._execute(engine,0,{},1,"rally",1).is_empty(),label+"_execution_held")
 check(Fel.Sources.same(before,options),label+"_read_only")
func reject_fel(options: Dictionary,label: String,right: Variant=[]) -> void:
 var engine=EngineFixture.new();engine._options=options;var before=options.duplicate(true);var host=Fel.new()
 check(not host.initialize(engine,right).is_empty(),label+"_init_rejected")
 check(not host.active(0) and not host.active(1),label+"_inactive")
 host.complete(engine)
 check(not host.settle({},result_for(engine),left_owner(),right_owner(),true).is_empty(),label+"_failed_init_no_settlement")
 check(not host.leaf(engine,{}, {},1,"deathrattle").is_empty(),label+"_leaf_held")
 check(Fel.Sources.same(before,options),label+"_read_only")
func ready(label: String,seal: bool=true) -> Dictionary:
 var engine=EngineFixture.new();engine._options=options_fixture();var host=Fel.new()
 check(host.initialize(engine,[]).is_empty(),label+"_init")
 if seal:host.complete(engine)
 return {"engine":engine,"host":host,"left":left_owner(),"right":right_owner(),"result":result_for(engine)}
func reject_settle(data: Dictionary,label: String,ghost: bool=true) -> void:
 var before=[data.left.duplicate(true),data.right.duplicate(true)]
 check(not data.host.settle({},data.result,data.left,data.right,ghost).is_empty(),label+"_settle_rejected")
 check(not data.host._consumed,label+"_not_consumed")
 check(Fel.Sources.same(before,[data.left,data.right]),label+"_owners_unchanged")
func _initialize() -> void:
 var options=options_fixture();var engine=EngineFixture.new();engine._options=options;var apexis=Apexis.new()
 check(not options.has("right_global_card_state"),"native_empty_right_global_state_absent_not_fabricated")
 check(not options.left_global_card_state.has("global_history"),"no_global_history_fixture_is_allowed")
 check(Apexis.EmptySlot.owner_is_empty(1,right_owner()),"canonical_native_five_key_shape")
 check(apexis.initialize(engine,[],[]).is_empty(),"apexis_empty_shape_initialize")
 check(apexis._contexts==[{},{}] and apexis._capability.is_empty(),"apexis_no_source_context_or_capability")
 for side in [0,1]:
  check(apexis.observers(engine,side).is_empty(),"apexis_no_observers_"+str(side))
  check(apexis.capability(engine,side,{}, {},"", "").is_empty(),"apexis_no_magnetic_capability_"+str(side))
  check(not apexis._execute(engine,side,{},1,"rally",1).is_empty(),"apexis_direct_execution_held_"+str(side))
 check(not apexis.initialize(engine).is_empty(),"apexis_reused_missing_raw_inputs_rejected")
 check(apexis.observers(engine,0).is_empty() and apexis.capability(engine,0,{}, {},"", "").is_empty(),"apexis_failed_reinit_clears_state")
 for value in [null,{},false,[{"uid":"ordinary"}]]:
  reject_apexis(options_fixture(),"apexis_bad_rawright_"+str(value),[],value)
  reject_fel(options_fixture(),"fel_bad_rawright_"+str(value),value)
 for value in [null,{},false]:reject_apexis(options_fixture(),"apexis_bad_rawleft_"+str(value),value,[])
 for value in [{},{"id":-1},null]:
  options=options_fixture();options.right_global_card_state=value;reject_apexis(options,"fabricated_right_global_state_"+str(value))
 for value in [{},{"id":1},{"id":0.0},null,[]]:
  options=options_fixture();options.left_global_card_state=value;reject_apexis(options,"wrong_left_global_state_"+str(value))
 options=options_fixture();options.erase("left_global_card_state");reject_apexis(options,"missing_left_global_state")
 options=options_fixture();options.erase("left_hand");reject_apexis(options,"missing_left_hand")
 for value in [null,{},false]:
  options=options_fixture();options.left_hand=value;reject_apexis(options,"left_hand_not_array_"+str(value))
 # Source claims are deliberate malformed negative fixtures, not native acquisitions.
 var claims=[]
 for id in Apexis.Sources.IDS:
  claims.append({"card_id":id});claims.append({"source_id":id});claims.append({"nested":[{"id":id}]})
 for kind in [Apexis.Sources.DR,Apexis.Sources.ACTION]:claims.append({"effects":[{"type":kind}]})
 for claim in claims:
  reject_apexis(options_fixture(),"raw_left_source_claim_"+str(claim),[claim],[])
  options=options_fixture();options.left_hand=[claim];reject_apexis(options,"hand_source_claim_"+str(claim))
 var nested: Variant={}
 for index in range(34):nested=[nested]
 reject_apexis(options_fixture(),"source_scan_depth_cap",[nested],[])
 # Exact zero contexts cannot carry unrelated slots, ledgers, observers or owners.
 for side in range(2):
  for field in ["owner","trinkets","observers"]:
   options=options_fixture();options[Apexis.CONTEXT][side].erase(field);reject_apexis(options,"apexis_missing_"+str(side)+field)
  for field in ["active","ledger","source"]:
   options=options_fixture();options[Apexis.CONTEXT][side][field]={};reject_apexis(options,"apexis_extra_"+str(side)+field)
  for field in ["trinkets","observers"]:
   for value in [[{}],{},null]:
    options=options_fixture();options[Apexis.CONTEXT][side][field]=value;reject_apexis(options,"apexis_nonzero_"+str(side)+field+str(value))
  for field in ["owner","active","trinkets","ledger"]:
   options=options_fixture();options[Fel.CONTEXT][side].erase(field);reject_fel(options,"fel_missing_"+str(side)+field)
  for field in ["calls","receipts","source"]:
   options=options_fixture();options[Fel.CONTEXT][side][field]=[];reject_fel(options,"fel_extra_"+str(side)+field)
  for value in [true,0,"false",null]:
   options=options_fixture();options[Fel.CONTEXT][side].active=value;reject_fel(options,"fel_bad_active_"+str(side)+str(value))
  for value in [[Fel.Sources.ID],["unrelated"],{},null]:
   options=options_fixture();options[Fel.CONTEXT][side].trinkets=value;reject_fel(options,"fel_nonzero_trinkets_"+str(side)+str(value))
  for value in [{"":{"attack":0,"health":0}}, {"injected":{}},[],null]:
   options=options_fixture();options[Fel.CONTEXT][side].ledger=value;reject_fel(options,"fel_nonempty_ledger_"+str(side)+str(value))
  for value in [-2,-1.0,"-1",8,null]:
   options=options_fixture();options[Apexis.CONTEXT][side].owner=value;reject_apexis(options,"apexis_bad_owner_"+str(side)+str(value))
   options=options_fixture();options[Fel.CONTEXT][side].owner=value;reject_fel(options,"fel_bad_owner_"+str(side)+str(value))
 for field in ["right_hand","right_hand_count","right_tier","left_is_ghost","right_is_ghost"]:
  options=options_fixture();options.erase(field);reject_apexis(options,"apexis_missing_"+field);reject_fel(options,"fel_missing_"+field)
 for field in ["left_is_ghost","right_is_ghost"]:
  for value in [true,0,"false",null]:
   options=options_fixture();options[field]=value;reject_apexis(options,"apexis_bad_"+field+str(value));reject_fel(options,"fel_bad_"+field+str(value))
  for value in [0,1,"false",null]:
   check(not Apexis.attach({field:value},left_owner(),right_owner(),null).is_empty(),"apexis_attach_bad_flag_"+field+str(value))
   check(not Fel.attach({field:value},left_owner(),right_owner(),null).is_empty(),"fel_attach_bad_flag_"+field+str(value))
 for field in ["maximum_history_context","delayed_gold_context"]:
  options=options_fixture();options[field].owners=[0,1];reject_apexis(options,"apexis_cross_context_"+field);reject_fel(options,"fel_cross_context_"+field)
 # Each attachment rejects malformed canonical empty owners before source work.
 for key in ["name","board","hand","tier"]:
  var bad=right_owner();bad.erase(key)
  check(not Apexis.attach({},left_owner(),bad,null).is_empty(),"apexis_attach_missing_empty_"+key)
  check(not Fel.attach({},left_owner(),bad,null).is_empty(),"fel_attach_missing_empty_"+key)
 for key in ["trinkets","receipts","global_history"]:
  var bad=right_owner();bad[key]=[]
  check(not Apexis.attach({},left_owner(),bad,null).is_empty(),"apexis_attach_extra_empty_"+key)
  check(not Fel.attach({},left_owner(),bad,null).is_empty(),"fel_attach_extra_empty_"+key)
 check(not Apexis.attach({},right_owner(),left_owner(),null).is_empty(),"apexis_attach_left_empty_rejected")
 check(not Fel.attach({},right_owner(),left_owner(),null).is_empty(),"fel_attach_left_empty_rejected")
 # Missing or malformed IDs must reject normally, never dereference absent owner.id.
 for side in range(2):
  var bad=left_owner() if side==0 else right_owner();bad.erase("id")
  var left=bad if side==0 else left_owner();var right=bad if side==1 else right_owner()
  check(not Apexis.attach({},left,right,null).is_empty(),"apexis_attach_missing_id_side_"+str(side))
  check(not Fel.attach({},left,right,null).is_empty(),"fel_attach_missing_id_side_"+str(side))
  for value in [null,"0","-1",true,false,8,-2,-1.0,-2.0,0.5]:
   bad=left_owner() if side==0 else right_owner();bad.id=value
   left=bad if side==0 else left_owner();right=bad if side==1 else right_owner()
   check(not Apexis.attach({},left,right,null).is_empty(),"apexis_attach_invalid_id_"+str(side)+str(value))
   check(not Fel.attach({},left,right,null).is_empty(),"fel_attach_invalid_id_"+str(side)+str(value))
  # Existing normal integer helper intentionally accepts integral float zero.
  bad=left_owner();bad.id=0.0
  left=bad if side==0 else left_owner();right=bad if side==1 else right_owner()
  check(Apexis.attach({},left,right,null).is_empty(),"apexis_existing_integral_float_owner_"+str(side))
  check(Fel.attach({},left,right,null).is_empty(),"fel_existing_integral_float_owner_"+str(side))
 var data=ready("fel_zero_chain");var before=[data.left.duplicate(true),data.right.duplicate(true)];var entry={"side":0,"unit":{"card_id":Fel.Sources.DEATH_IDS[0]}}
 check(not data.host.active(0) and not data.host.active(1),"fel_both_sides_inactive")
 check(data.host.bind(data.engine,entry,[],"deathrattle").is_empty() and not entry.has("felblood_invocation"),"fel_inactive_bind_noop_no_capability")
 check(not data.host.leaf(data.engine,entry,{},1,"deathrattle").is_empty(),"fel_inactive_leaf_held")
 check(data.host.settle({},data.result,data.left,data.right,true).is_empty(),"fel_pairghost_true_optionsghost_false_noop")
 check(data.host._consumed and not data.host._ghost,"fel_consumed_without_changing_ghost")
 check(Fel.Sources.same(before,[data.left,data.right]),"fel_no_owner_writes")
 check(not data.host.settle({},data.result,data.left,data.right,true).is_empty(),"fel_settlement_replay_rejected")
 data=ready("missing_complete",false);reject_settle(data,"missing_complete")
 data=ready("wrong_pairghost");reject_settle(data,"wrong_pairghost",false)
 for key in ["id","name","board","hand","tier"]:
  data=ready("right_missing_"+key);data.right.erase(key);reject_settle(data,"right_missing_"+key)
 for value in [-2,0,8,-1.0,"-1"]:
  data=ready("wrong_right_id");data.right.id=value;reject_settle(data,"wrong_right_id_"+str(value))
 for value in [1,-1,0.0,"0"]:
  data=ready("wrong_left_id");data.left.id=value;reject_settle(data,"wrong_left_id_"+str(value))
 for field in ["hand","board"]:
  data=ready("right_nonempty");data.right[field]=[{}];reject_settle(data,"right_nonempty_"+field)
 data=ready("left_portrait");data.left.trinkets=[Fel.Sources.ID];reject_settle(data,"left_active_portrait")
 data=ready("left_ledger");data.left.recruit_shop_bonuses={"":{"attack":0,"health":0}};reject_settle(data,"left_nonempty_ledger")
 data=ready("changed_seed");data.result.seed+=1;reject_settle(data,"changed_seed")
 data=ready("changed_error");data.result.error="injected";reject_settle(data,"changed_error")
 data=ready("changed_log");data.result.log[0].injected=true;reject_settle(data,"changed_log")
 for log in [[],[{}],[{"event":"combat_end","error":"injected"}],[{"event":Fel.EVENT},{"event":"combat_end","error":""}]]:
  data=ready("bad_sealed_log",false);data.engine._log=log;data.host.complete(data.engine);data.result=result_for(data.engine);reject_settle(data,"bad_sealed_log_"+str(log))
 # Private-state corruption is pure negative testing, never live game injection.
 data=ready("calls_injected");data.host._calls={0:{}};reject_settle(data,"calls_injected")
 data=ready("receipts_injected");data.host._receipts=[{}];reject_settle(data,"receipts_injected")
 data=ready("ledger_injected");data.host._ledger[0].attack=1;reject_settle(data,"ledger_injected")
 for side in range(2):
  data=ready("context_injected");data.host._contexts[side].active=true;reject_settle(data,"context_injected_"+str(side))
 data=ready("reuse");check(data.host.settle({},data.result,data.left,data.right,true).is_empty(),"reuse_first_settlement")
 check(not data.host.initialize(data.engine).is_empty(),"reuse_missing_rawright_rejected")
 data.host.complete(data.engine);check(not data.host.settle({},data.result,data.left,data.right,true).is_empty(),"failed_reinit_no_old_settlement")
 # Normal owner legacy shapes, not actual natural dead-player gameplay.
 for ghost in [false,true]:
  engine=EngineFixture.new();engine._options={"right_is_ghost":ghost,Apexis.CONTEXT:[{"owner":0,"trinkets":[],"observers":[]},{"owner":1,"trinkets":[],"observers":[]}],"left_global_card_state":{"id":0},"right_global_card_state":{"id":1},Fel.CONTEXT:[{"owner":0,"active":false,"trinkets":[],"ledger":{}},{"owner":1,"active":false,"trinkets":[],"ledger":{}}]}
  check(Apexis.new().initialize(engine).is_empty(),"normal_apexis_legacy_"+str(ghost))
  var host=Fel.new();check(host.initialize(engine).is_empty(),"normal_fel_legacy_"+str(ghost));host.complete(engine)
  var right=left_owner();right.id=1
  check(host.settle(engine,result_for(engine),left_owner(),right,ghost).is_empty(),"normal_fel_settle_"+str(ghost))
 print("APEXIS_FELBLOOD_EMPTY_CONTRACT ",JSON.stringify({"passed":passed,"failed":failed,"failures":failures,"real_game_run":false,"native_dead_owner_snapshot_exercised":false,"scope":"pure detached Apexis and inactive Felblood empty-slot contracts, not native provenance"}))
 quit(0 if failed==0 else 1)
