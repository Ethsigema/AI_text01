# Native empty-slot v3 detached contracts

`apexis_felblood_empty_contract.gd` is a new pure contract, not Game execution or evidence of native provenance. It uses detached shape fixtures, a minimal engine stub and synthetic completion logs. Intentional private-state corruption and source claims are negative fixtures only, never live game edits.

Apexis coverage: canonical five-key right owner; missing right global card state/global history remains legitimate without fabricated history; actual raw boards and hands supplied independently from initially empty engine boards; consistent cross-host owner carriers; exact zero observer contexts; nested source/action claims and bounded recursion; no observer list, magnetic capability or direct execution; rejected reinitialization clears authority. Normal-owner legacy fixtures retain default initialize arguments.

Felblood coverage: both sides inactive with empty trinkets and input ledgers; explicit ghost flag types; raw right supplied; initialize, complete and settle with exact log/seed/error/end and consumed/replay handling; pairing ghost true while options right_is_ghost false; zero-write no-op accepts an empty settlement engine dictionary; binding inactive returns no capability and leaf execution stays held; source/portrait, receipt/call/ledger injections and owner changes rejected; failed initialization and host reuse do not preserve earlier settlement permission. Pure normal-owner ghost-marked controls do not constitute natural dead-player gameplay.

Do not change or repeat the previously frozen 925/1231 contracts or the original 4-room real matrix. The independent v3 runner executes that original real matrix once, followed by this new contract and the retained 925/1231/68/166 contracts, only after source publication, full remote restore verification and explicit start authorization. Preserve v1 and v2 failure logs. Runtime count for this contract must come from its actual `APEXIS_FELBLOOD_EMPTY_CONTRACT` summary, not a projected count.

Not tested here: real Game, natural dead-player snapshots, active Apexis/Felblood resource execution or full content acceptance.

Attachment ID regressions additionally cover both sides missing ID, null/string/bool/out-of-range/non-integral/negative-float values. Normal integral float 0 remains accepted by the pre-existing integer helper. Initial parse failures and their logs are retained separately; no existing assertion was removed.
