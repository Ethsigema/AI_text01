extends RefCounted
const EmptySlot=preload("res://core/empty_combat_slot.gd")
const Sources=preload("res://core/apexis_guardian_sources.gd")
const Donor=preload("res://core/combat_native_speaker_donor.gd")
const Operations=preload("res://core/native_magnetic_operation.gd")
const Gains=preload("res://core/attack_gain_listeners.gd")
const CONTEXT="native_apexis_owned_context"
var _initialized: bool=false
var _empty_slot: bool=false
var _combat: RefCounted
var _contexts: Array=[{},{}]
var _capability: Dictionary={}
var _ordinal: int=0
# A bounded pure scan also rejects inherited/unbound native action claims.
static func _source_claim(value: Variant,depth: int=0) -> bool:
 if depth>32:return true
 if value is Dictionary:
  if value.get("card_id",value.get("id")) in Sources.IDS or value.get("source_id") in Sources.IDS or value.get("type") in [Sources.DR,Sources.ACTION]:return true
  for child in value.values():
   if _source_claim(child,depth+1):return true
 elif value is Array:
  for child in value:
   if _source_claim(child,depth+1):return true
 return false
static func _zero_context(context: Variant,id: int) -> bool:
 return context is Dictionary and context.size()==3 and context.get("owner") is int and context.owner==id and context.get("trinkets") is Array and context.trinkets.is_empty() and context.get("observers") is Array and context.observers.is_empty()
static func _empty_inputs(options: Dictionary,left: Variant,right: Variant) -> bool:
 if not left is Array or not EmptySlot.combat_is_empty(1,-1,right,options):return false
 if not options.get("left_hand") is Array or options.has("right_global_card_state"):return false
 var contexts: Variant=options.get(CONTEXT)
 if not contexts is Array or contexts.size()!=2:return false
 var owner_id: int=options.delayed_gold_context.owners[0]
 var global: Variant=options.get("left_global_card_state")
 if not global is Dictionary or not global.get("id") is int or global.id!=owner_id:return false
 if not _zero_context(contexts[0],owner_id) or not _zero_context(contexts[1],-1):return false
 return not _source_claim([left,right,options.left_hand,options.right_hand])
static func attach(options: Dictionary,left: Dictionary,right: Dictionary,catalog) -> String:
 for flag in ["left_is_ghost","right_is_ghost"]:
  if not options.get(flag,false) is bool:return "apexis_invalid_ghost_flag"
 for side in range(2):
  var owner: Dictionary=[left,right][side]
  if not Sources.Exact.integer(owner.get("id"),0,7) and not EmptySlot.owner_is_empty(side,owner):return "apexis_invalid_empty_owner"
 var contexts: Array=[]
 # Keep all actual owned slots even if the native parent is summoned later.
 for owner in [left,right]:
  var observers: Array=[]
  for slot in range(owner.get("trinkets",[]).size()):
   var id: String=str(owner.trinkets[slot])
   if id not in Operations.Trinkets.IDS:continue
   var issue: String=Operations.Trinkets.closure_error(catalog)
   if not issue.is_empty():return issue
   observers.append({"source_id":id,"slot":slot,"effect":Operations.Trinkets.PROGRAMS[id][1].duplicate(true)})
  if (owner.get("board",[])+owner.get("hand",[])).any(func(u):return Sources.claimed(u)):
   var issue: String=Sources.closure_error(catalog)
   if not issue.is_empty():return issue
  contexts.append({"owner":owner.id,"trinkets":owner.get("trinkets",[]).duplicate(true),"observers":observers})
 options[CONTEXT]=contexts
 return ""
func initialize(engine,left_input: Variant=null,right_input: Variant=null) -> String:
 _initialized=false;_empty_slot=false;_combat=null;_contexts=[{},{}];_capability={};_ordinal=0
 for flag in ["left_is_ghost","right_is_ghost"]:
  if not engine._options.get(flag,false) is bool:return "apexis_invalid_ghost_flag"
 var empty_claim: bool=EmptySlot.claimed(engine._options) or EmptySlot._context_claims(engine._options.get(CONTEXT),"owner")
 if empty_claim:
  if not _empty_inputs(engine._options,left_input,right_input):return "apexis_invalid_empty_slot"
  # Deliberately no source context or magnetic execution capability.
  _combat=engine;_empty_slot=true;_initialized=true
  return ""
 var contexts: Variant=engine._options.get(CONTEXT,[{},{}])
 if not contexts is Array or contexts.size()!=2:return "apexis_invalid_owned_contexts"
 for side in range(2):
  var context: Variant=contexts[side]
  if not context is Dictionary:return "apexis_invalid_owned_context"
  if context.is_empty():continue
  if context.size()!=3 or not context.get("trinkets") is Array or not context.get("observers") is Array:return "apexis_changed_owned_context"
  var expected: Array=[]
  for slot in range(context.trinkets.size()):
   var id: String=str(context.trinkets[slot])
   if id in Operations.Trinkets.IDS:expected.append({"source_id":id,"slot":slot,"effect":Operations.Trinkets.PROGRAMS[id][1].duplicate(true)})
  if not Sources.Exact.same(expected,context.observers):return "apexis_changed_real_observer_slots"
  var owner: Dictionary=engine._options.get("left_global_card_state" if side==0 else "right_global_card_state",{})
  if owner.get("id")!=context.owner:return "apexis_wrong_real_owner"
  _contexts[side]=context.duplicate(true)
 _combat=engine;_initialized=true
 return ""
func observers(engine,side: int) -> Array:
 return _contexts[side].get("observers",[]) if _initialized and not _empty_slot and is_same(engine,_combat) and side in [0,1] else []
func capability(engine,side: int,source: Dictionary,target: Dictionary,child_id: String,origin_key: String) -> Dictionary:
 if not _initialized or _empty_slot:return {}
 if not is_same(engine,_combat) or _capability.get("used",true) or _capability.get("side")!=side or not is_same(_capability.get("source"),source) or not is_same(_capability.get("target"),target) or _capability.get("child")!=child_id or _capability.get("origin")!=origin_key:return {}
 return _capability
func _execute(engine,side: int,source: Dictionary,count: int,trigger: String,repetition: int) -> String:
 if not _initialized or _empty_slot:return "apexis_empty_or_uninitialized_resource_execution_held"
 if not is_same(engine,_combat) or side not in [0,1] or _contexts[side].is_empty() or not _capability.is_empty():return "apexis_missing_actual_owner_or_nested_invocation"
 if source.get("silenced",false) or source.get("abilities_disabled",false):return ""
 var targets: Array=engine._boards[side].filter(func(u):return not is_same(u,source) and Gains.living(u) and engine._tribe_matches(u,"机械"))
 if targets.is_empty():
  engine._emit("apexis_no_other_mech",{"side":side,"source":source.uid,"source_id":source.card_id,"trigger":trigger,"repetition":repetition});return ""
 var issue: String=Donor.preflight(engine,side,source,targets,Sources.Speakers.NORMALS,trigger)
 if not issue.is_empty():return issue
 _ordinal+=1
 # Existing random-target convention: uniform, distinct targets in one native
 # activation. Color is a fresh draw from the complete three-normal domain.
 for literal in range(mini(count,targets.size())):
  var target_index: int=engine._random_index(targets.size(),"apexis_other_mech",targets.map(func(u):return u.uid))
  if not engine._error.is_empty():return str(engine._error)
  var target: Dictionary=targets[target_index];targets.remove_at(target_index)
  var child_index: int=engine._random_index(Sources.Speakers.NORMALS.size(),"apexis_native_volumizer",Sources.Speakers.NORMALS)
  if not engine._error.is_empty():return str(engine._error)
  var child: String=str(Sources.Speakers.NORMALS[child_index])
  var origin: String="%s:%s:%s:%s:%s:%s"%[side,source._combat_id,trigger,_ordinal,repetition,literal]
  _capability={"side":side,"source":source,"target":target,"child":child,"origin":origin,"used":false,"observers":observers(engine,side)}
  issue=Donor.execute(engine,side,source,target,child,trigger,origin)
  var consumed: bool=_capability.used;_capability={}
  if not issue.is_empty():return issue
  if not consumed:return "apexis_unconsumed_native_capability"
 return ""
func rally(engine,side: int,source: Dictionary,action: Dictionary,wrapper: Dictionary) -> String:
 var issue: String=Sources.wrapper_error(source,wrapper)
 if not issue.is_empty():return issue
 if not Sources.Exact.same(action,wrapper.effect):return "apexis_changed_rally_action"
 var context: Dictionary=engine._native_rally_spread_context
 if context.get("side")!=side or not is_same(context.get("source"),source) or not Sources.Exact.same(context.get("activation",{}).get("effect"),wrapper) or not is_same(engine._find_unit(side,int(source.get("_combat_id",-1))),source) or not Gains.living(source):return "apexis_actual_rally_declaration_required"
 return _execute(engine,side,source,int(action.count),"rally",int(context.repetition))
func deathrattle(engine,entry: Dictionary,effect: Dictionary,repetition: int,trigger: String) -> String:
 var source: Dictionary=entry.get("unit",{});var side: int=int(entry.get("side",-1))
 var issue: String=Sources.call_error(source,effect)
 if not issue.is_empty():return issue
 if trigger not in ["deathrattle","rally_deathrattle","triggered_deathrattle"] or side not in [0,1] or repetition<1:return "apexis_invalid_deathrattle_dispatch"
 if entry.get("live_source",false):
  if not is_same(engine._find_unit(side,int(source.get("_combat_id",-1))),source) or not Gains.living(source):return "apexis_actual_living_retrigger_required"
 else:
  var sequence: int=int(entry.get("milestone_death_sequence",-1))
  if sequence<0 or sequence>=engine._log.size() or not engine._find_unit(side,int(source.get("_combat_id",-1))).is_empty():return "apexis_actual_removed_death_required"
  var receipt: Dictionary=engine._log[sequence]
  if receipt.get("event")!="death" or receipt.get("unit")!=source.get("uid") or receipt.get("side")!=side:return "apexis_changed_actual_death_receipt"
 return _execute(engine,side,source,int(effect.count),trigger,repetition)
