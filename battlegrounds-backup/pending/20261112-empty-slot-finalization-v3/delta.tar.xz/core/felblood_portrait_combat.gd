extends RefCounted
const EmptySlot=preload("res://core/empty_combat_slot.gd")
const Sources=preload("res://core/felblood_portrait_sources.gd")
const CONTEXT: String="native_felblood_portrait_context"
const EVENT: String="felblood_permanent_shop_bonus"
var _initialized: bool=false
var _empty_slot_left: int=-1
var _contexts: Array=[]
var _calls: Dictionary={}
var _receipts: Array=[]
var _sealed: Array=[]
var _ledger: Array=[]
var _seed: int=0
var _ghost: bool=false
var _complete: bool=false
var _consumed: bool=false
static func _zero_context(context: Variant,id: int) -> bool:
	return context is Dictionary and context.size()==4 and context.get("owner") is int and context.owner==id and context.get("active") is bool and context.active==false and context.get("trinkets") is Array and context.trinkets.is_empty() and context.get("ledger") is Dictionary and context.ledger.is_empty()
static func _empty_inputs(options: Dictionary,right: Variant) -> bool:
	if not EmptySlot.combat_is_empty(1,-1,right,options):return false
	var contexts: Variant=options.get(CONTEXT)
	if not contexts is Array or contexts.size()!=2:return false
	return _zero_context(contexts[0],options.delayed_gold_context.owners[0]) and _zero_context(contexts[1],-1)
func _empty_settlement_error(left: Dictionary,right: Dictionary,ghost: bool) -> String:
	if _empty_slot_left<0 or not ghost or _ghost or not EmptySlot.owner_is_empty(1,right) or not left.get("id") is int or left.id!=_empty_slot_left:return "felblood_portrait_changed_empty_slot"
	if _contexts.size()!=2 or not _zero_context(_contexts[0],_empty_slot_left) or not _zero_context(_contexts[1],-1):return "felblood_portrait_changed_empty_contexts"
	if not _calls.is_empty() or not _receipts.is_empty() or not Sources.same(_ledger,[{"attack":0,"health":0},{"attack":0,"health":0}]):return "felblood_portrait_empty_slot_has_resources"
	if left.get("trinkets",[])!=[] or left.get("recruit_shop_bonuses",{})!={}:return "felblood_portrait_changed_empty_owner"
	return ""
static func attach(options: Dictionary,left: Dictionary,right: Dictionary,catalog) -> String:
	for flag in ["left_is_ghost","right_is_ghost"]:
		if not options.get(flag,false) is bool: return "felblood_portrait_invalid_ghost_flag"
	for side in range(2):
		var owner: Dictionary=[left,right][side]
		if not Sources.integer(owner.get("id"),0,7) and not EmptySlot.owner_is_empty(side,owner): return "felblood_portrait_invalid_empty_owner"
	var contexts: Array=[]
	for owner in [left,right]:
		var active: bool=Sources.has_source(owner)
		if active:
			var issue: String=Sources.closure_error(catalog)
			if not issue.is_empty(): return issue
		contexts.append({"owner":owner.id,"trinkets":owner.get("trinkets",[]).duplicate(),"active":active,"ledger":owner.get("recruit_shop_bonuses",{}).duplicate(true)})
	options[CONTEXT]=contexts
	return ""
func initialize(engine,right_input: Variant=null) -> String:
	_initialized=false;_empty_slot_left=-1;_contexts=[];_calls={};_receipts=[];_sealed=[];_ledger=[];_complete=false;_consumed=false;_seed=engine._seed;_ghost=false
	for flag in ["left_is_ghost","right_is_ghost"]:
		if not engine._options.get(flag,false) is bool: return "felblood_portrait_invalid_ghost_flag"
	_ghost=engine._options.get("right_is_ghost",false)
	var empty_claim: bool=EmptySlot.claimed(engine._options) or EmptySlot._context_claims(engine._options.get(CONTEXT),"owner")
	if empty_claim and not _empty_inputs(engine._options,right_input): return "felblood_portrait_invalid_empty_slot"
	var contexts: Variant=engine._options.get(CONTEXT,[])
	if not contexts is Array: return "felblood_portrait_invalid_combat_contexts"
	_contexts=contexts.duplicate(true)
	if _contexts.is_empty(): _contexts=[{"owner":-1,"active":false,"trinkets":[],"ledger":{}},{"owner":-1,"active":false,"trinkets":[],"ledger":{}}]
	if _contexts.size()!=2: return "felblood_portrait_invalid_combat_contexts"
	for context in _contexts:
		if not context is Dictionary or context.size()!=4 or not context.get("active") is bool or not context.get("trinkets") is Array or not context.get("ledger") is Dictionary or context.active!=Sources.has_source(context): return "felblood_portrait_changed_combat_context"
		if context.active and (context.trinkets.count(Sources.ID)<1 or not Sources.integer(context.owner,0,7)): return "felblood_portrait_changed_combat_owner_slots"
		var value: Dictionary=context.ledger.get("",{"attack":0,"health":0})
		if value.size()!=2 or not Sources.integer(value.get("attack")) or not Sources.integer(value.get("health")): return "felblood_portrait_invalid_combat_ledger"
		_ledger.append(value.duplicate(true))
	if empty_claim: _empty_slot_left=engine._options.delayed_gold_context.owners[0]
	_initialized=true
	return ""
func active(side: int) -> bool: return _initialized and _empty_slot_left<0 and side in [0,1] and _contexts.size()==2 and _contexts[side].active
func bind(engine,entry: Dictionary,groups: Array,trigger: String) -> String:
	var side: int=int(entry.get("side",-1));var source: Dictionary=entry.get("unit",{})
	if not active(side) or source.get("card_id") not in Sources.DEATH_IDS: return ""
	if _contexts[side].trinkets.count(Sources.ID)!=1: return "felblood_portrait_multiple_owned_attribute_semantics_partial"
	var issue: String=Sources.unit_error(source)
	if not issue.is_empty(): return issue
	if groups.size()!=1 or not Sources.same(groups[0],Sources.CHILD_PROGRAMS[source.card_id]): return "felblood_portrait_combat_attached_groups_partial"
	if not Sources.integer(entry.get("repeats",1),1,512) or entry.has("felblood_invocation"): return "felblood_portrait_replayed_combat_invocation"
	if trigger=="deathrattle" and not entry.get("live_source",false):
		var sequence: int=int(entry.get("milestone_death_sequence",-1))
		if sequence<0 or sequence>=engine._log.size() or engine._boards[side].any(func(unit):return is_same(unit,source)): return "felblood_portrait_actual_removed_source_required"
		var receipt: Dictionary=engine._log[sequence]
		if receipt.get("event")!="death" or receipt.get("unit")!=source.uid or receipt.get("side")!=side: return "felblood_portrait_invalid_removed_receipt"
	else:
		if trigger not in ["triggered_deathrattle","rally_deathrattle"] or not entry.get("live_source",false) or not is_same(engine._find_unit(side,int(source.get("_combat_id",-1))),source) or int(source.get("health",0))<=0: return "felblood_portrait_actual_living_source_required"
	var amount: int=int(Sources.CHILD_PROGRAMS[source.card_id][0].attack)
	var count: int=int(entry.get("repeats",1))
	for axis in ["attack","health"]:
		if int(_ledger[side][axis])>Sources.MAX-amount*count: return "felblood_portrait_combat_cumulative_ledger_overflow"
	var key: int=_calls.size()
	entry.felblood_invocation=key
	_calls[key]={"entry":entry,"source":source,"side":side,"trigger":trigger,"count":count,"next":1,"amount":amount}
	return ""
func leaf(engine,entry: Dictionary,effect: Dictionary,repetition: int,trigger: String) -> String:
	if not _initialized or _empty_slot_left>=0: return "felblood_portrait_empty_or_uninitialized_leaf_held"
	var key: Variant=entry.get("felblood_invocation")
	if not _calls.has(key): return "felblood_portrait_missing_real_combat_invocation"
	var call: Dictionary=_calls[key]
	if not is_same(call.entry,entry) or not is_same(call.source,entry.get("unit")) or repetition!=call.next or repetition>call.count or trigger!=call.trigger or not Sources.same(effect,Sources.CHILD_PROGRAMS[call.source.card_id][0]): return "felblood_portrait_changed_actual_combat_leaf"
	var issue: String=Sources.unit_error(call.source)
	if not issue.is_empty(): return issue
	for axis in ["attack","health"]:
		if int(_ledger[call.side][axis])>Sources.MAX-int(call.amount): return "felblood_portrait_combat_ledger_overflow"
	var before: Dictionary=_ledger[call.side].duplicate(true)
	for axis in ["attack","health"]: _ledger[call.side][axis]+=int(call.amount)
	engine._emit(EVENT,{"side":call.side,"owner":_contexts[call.side].owner,"source":call.source.uid,"source_id":call.source.card_id,"combat_id":call.source._combat_id,"portrait":Sources.ID,"invocation":key,"repetition":repetition,"trigger":trigger,"attack_delta":call.amount,"health_delta":call.amount,"ledger_before":before,"ledger_after":_ledger[call.side].duplicate(true)})
	_receipts.append(engine._log.back().duplicate(true));call.next+=1
	return ""
func complete(engine) -> void:
	if not _initialized or _consumed: return
	_sealed=engine._log.duplicate(true);_complete=true
func settle(engine,result: Dictionary,left: Dictionary,right: Dictionary,ghost: bool) -> String:
	if not _initialized: return "felblood_portrait_uninitialized_host"
	if _consumed: return "felblood_portrait_replayed_settlement"
	var log: Array=result.get("log",[])
	if _empty_slot_left>=0:
		var empty_issue: String=_empty_settlement_error(left,right,ghost)
		if not empty_issue.is_empty(): return empty_issue
	if not _complete or not Sources.same(log,_sealed) or result.get("seed")!=_seed or (_empty_slot_left<0 and ghost!=_ghost) or not str(result.get("error","")).is_empty() or log.is_empty() or not log[-1] is Dictionary or log[-1].get("event")!="combat_end" or log[-1].get("error")!="": return "felblood_portrait_unbound_complete_combat"
	var receipts: Array=log.filter(func(event):return event is Dictionary and event.get("event")==EVENT)
	if not Sources.same(receipts,_receipts): return "felblood_portrait_changed_private_combat_receipts"
	for call in _calls.values():
		if call.next!=call.count+1: return "felblood_portrait_incomplete_native_invocation"
	if _empty_slot_left>=0:
		_consumed=true
		return ""
	var plans: Array=[]
	var cumulative_totals: Dictionary=engine._attack_gain_health_totals.duplicate(true)
	# Local category order: authenticated Felblood shop claims settle as one
	# preflighted group before other combat reward categories. Ghost claims stay
	# in the combat journal, never in a different real owner's permanent ledger.
	for side in range(2):
		if not active(side): continue
		var owner: Dictionary=left if side==0 else right
		if owner.id!=_contexts[side].owner or not Sources.same(owner.get("trinkets",[]),_contexts[side].trinkets): return "felblood_portrait_settlement_owner_changed"
		if ghost and side==1: continue
		if not engine.state.players.any(func(actual):return is_same(actual,owner)): return "felblood_portrait_actual_settlement_owner_required"
		if log.any(func(event):return event.get("event")=="permanent_shop_bonus" and event.get("side")==side): return "felblood_portrait_other_combat_shop_source_overlap_partial"
		if not Sources.same(owner.get("recruit_shop_bonuses",{}),_contexts[side].ledger): return "felblood_portrait_changed_original_owner_ledger"
		var state: Dictionary=engine.HeroDamageStats.begin(engine,owner)
		state.totals=cumulative_totals.duplicate(true)
		for receipt in receipts:
			if receipt.side!=side: continue
			var before: Dictionary=engine.FelbloodPortrait.view(engine,state.player,state.totals)
			var issue: String=engine.FelbloodPortrait.project_leaf(engine,state,int(receipt.attack_delta),int(receipt.health_delta))
			if not issue.is_empty(): return issue
			plans.append({"owner":owner,"receipt":receipt,"before":before,"after":engine.FelbloodPortrait.view(engine,state.player,state.totals)})
		cumulative_totals=state.totals.duplicate(true)
	_consumed=true
	for step in plans:
		if not Sources.same(engine.FelbloodPortrait.view(engine,step.owner,engine._attack_gain_health_totals),step.before): return "felblood_portrait_settlement_before_changed"
		engine.RecruitExtensions.add_shop_bonus(engine,step.owner,"",int(step.receipt.attack_delta),int(step.receipt.health_delta))
		if engine.state.phase=="error": return "felblood_portrait_settlement_write_failed"
		if not Sources.same(engine.FelbloodPortrait.view(engine,step.owner,engine._attack_gain_health_totals),step.after): return "felblood_portrait_settlement_after_changed"
		engine._log("felblood_portrait_settled",{"player":step.owner.id,"source_uid":step.receipt.source,"source_id":step.receipt.source_id,"combat_sequence":step.receipt.sequence,"attack":step.receipt.attack_delta,"health":step.receipt.health_delta})
	return ""
