extends RefCounted
const DarkcrestSources=preload("res://core/darkcrest_sources.gd")
const Rider=preload("res://core/rider_host.gd")
var _rider_host: RefCounted
var _rider_authority: Dictionary={}
var _rider_removal_context: Dictionary={}
var _rider_dispatch_context: Dictionary={}
const TimewarpSwirler=preload("res://core/timewarp_swirler_host.gd")
const TimewarpScout=preload("res://core/timewarp_scout_host.gd")
const TimewarpRedWhelp=preload("res://core/timewarp_red_whelp_host.gd")
const SparkSnapper=preload("res://core/spark_snapper_host.gd")
const TimewarpMolten=preload("res://core/timewarp_molten_host.gd")
const TimewarpMurky=preload("res://core/timewarp_murky_host.gd")
const TimewarpPainter=preload("res://core/timewarp_painter_host.gd")
const AirBaller=preload("res://core/air_baller_host.gd")
const SnowBaller=preload("res://core/snow_baller_host.gd")
const FireBaller=preload("res://core/fire_baller_host.gd")
const Hooktusk=preload("res://core/hooktusk_host.gd")
const Ultraviolet=preload("res://core/ultraviolet_host.gd")
const TimewarpRodeo=preload("res://core/timewarp_rodeo_host.gd")
const TimewarpChimera=preload("res://core/timewarp_chimera_host.gd")
const TimewarpMythrax=preload("res://core/timewarp_mythrax_host.gd")
const TimewarpAmalgam=preload("res://core/timewarp_amalgam_host.gd")
const TimewarpElectron=preload("res://core/timewarp_electron_host.gd")
const TimewarpTheotar=preload("res://core/timewarp_theotar_sources.gd")
const Hyena=preload("res://core/hyena_host.gd")
var _hyena_host=Hyena.new()
const Lobster=preload("res://core/lobster_host.gd")
var _lobster_host: RefCounted
var _lobster_authority: Dictionary={}
var _lobster_removal_context: Dictionary={}
var _lobster_dispatch_context: Dictionary={}
const Leviathan=preload("res://core/leviathan_host.gd")
var _leviathan_host: RefCounted
var _leviathan_authority: Dictionary={}
var _leviathan_insertion_context: Dictionary={}
const Kibble=preload("res://core/kibble_host.gd")
var _kibble_host: RefCounted
var _kibble_authority: Dictionary={}
var _kibble_declaration: Dictionary={}
const Hopebringer=preload("res://core/hopebringer_host.gd")
var _hopebringer_host: RefCounted
var _hopebringer_authority: Dictionary={}
var _hopebringer_removal_context: Dictionary={}
const MurderWeapon=preload("res://core/murder_weapon_host.gd")
const WitnessProtection=preload("res://core/witness_protection_sources.gd")
const Apexis=preload("res://core/apexis_guardian_host.gd")
var _apexis_magnetic_host=Apexis.new()
const NosySources=preload("res://core/nosy_looter_sources.gd")
const PatientScoutSources=preload("res://core/patient_scout_sources.gd")
const EnergyRecycling=preload("res://core/energy_recycling_host.gd")
const AristocratSources=preload("res://core/shady_aristocrat_sources.gd")
const MutatedLasher = preload("res://core/mutated_lasher_host.gd")
const DeterminedDefender = preload("res://core/determined_defender_host.gd")
const EliseRefreshSources=preload("res://core/elise_refresh_sources.gd")
const IncubationMutationSources = preload("res://core/incubation_mutation_sources.gd")
const KidnapSackSources=preload("res://core/kidnap_sack_sources.gd")
const GoldenHammerSources=preload("res://core/golden_hammer_sources.gd")
const FalseIdolsSources=preload("res://core/false_idols_sources.gd")
const PartnerInCrimeSources=preload("res://core/partner_in_crime_sources.gd")
const PilferedLampsSources=preload("res://core/pilfered_lamps_sources.gd")
const SecretSinstoneSources=preload("res://core/secret_sinstone_sources.gd")
const VictimSpecterSources=preload("res://core/victim_specter_sources.gd")
const RitualDagger=preload("res://core/ritual_dagger_host.gd")
var _ritual_dagger_host=RitualDagger.new()
var _ritual_dagger_authority: Dictionary={}
var _ritual_dagger_death_context: Dictionary={}
const VictimSpecter=preload("res://core/victim_specter_host.gd")
var _victim_specter_host=VictimSpecter.new()
var _victim_specter_authority: Dictionary={}
var _victim_specter_death_context: Dictionary={}
const GrimFreshenerSources=preload("res://core/grim_freshener_sources.gd")
const GrimFreshener=preload("res://core/grim_freshener_host.gd")
var _grim_freshener_host=GrimFreshener.new()
var _energy_recycling_authority: Dictionary={}
var _energy_recycling_death_context: Dictionary={}
var _energy_recycling_host=EnergyRecycling.new()
var _grim_freshener_authority: Dictionary={}
var _grim_freshener_death_context: Dictionary={}
const SnickerSnacksSources=preload("res://core/snicker_snacks_sources.gd")
const SnickerSnacks=preload("res://core/snicker_snacks_host.gd")
var _snicker_snacks_host=SnickerSnacks.new()
var _snicker_snacks_authority: Dictionary={}
const ExquisiteConchSources=preload("res://core/exquisite_conch_sources.gd")
const ExquisiteConch=preload("res://core/exquisite_conch_host.gd")
var _exquisite_conch_host=ExquisiteConch.new()
var _exquisite_conch_authority: Dictionary={}
const VolatileVenomSources=preload("res://core/volatile_venom_sources.gd")
const VolatileVenom=preload("res://core/volatile_venom_host.gd")
var _volatile_venom_host=VolatileVenom.new()
var _volatile_venom_authority: Dictionary={}
var _volatile_venom_attack_context: Dictionary={}
const AlterEgoSources=preload("res://core/alter_ego_sources.gd")
const AlterEgo=preload("res://core/alter_ego_host.gd")
var _alter_ego_host=AlterEgo.new()
var _alter_ego_authority: Dictionary={}
const StolenGoldSources=preload("res://core/stolen_gold_sources.gd")
const StolenGold=preload("res://core/stolen_gold_host.gd")
var _stolen_gold_host=StolenGold.new()
var _stolen_gold_authority: Dictionary={}
var _stolen_gold_start_context: Dictionary={}
const BombSquadSources=preload("res://core/bomb_squad_sources.gd")
const BombSquad=preload("res://core/bomb_squad_host.gd")
var _bomb_squad_host=BombSquad.new()
var _bomb_squad_authority: Dictionary={}
var _bomb_squad_death_context: Dictionary={}
const TheotarParasolSources=preload("res://core/theotar_parasol_sources.gd")
const TheotarParasol=preload("res://core/theotar_parasol_host.gd")
var _theotar_parasol_host=TheotarParasol.new()
var _theotar_parasol_authority: Dictionary={}
const EvilTwinSources=preload("res://core/evil_twin_sources.gd")
const EvilTwin=preload("res://core/evil_twin_host.gd")
var _evil_twin_host=EvilTwin.new()
var _evil_twin_authority: Dictionary={}
const GoldenArrowSources=preload("res://core/golden_arrow_sources.gd")
const ArgusSources=preload("res://core/echoes_argus_sources.gd")
const PerfectedSources=preload("res://core/perfected_alchemy_sources.gd")
const RecklessSources=preload("res://core/reckless_enhancement_sources.gd")
const AntiGravitySources=preload("res://core/anti_gravity_sources.gd")
const AnomalousTwinsSources=preload("res://core/anomalous_twins_sources.gd")
const AnomalousTwins=preload("res://core/anomalous_twins_host.gd")
var _anomalous_twins_host=AnomalousTwins.new()
var _anomalous_twins_authority: Dictionary={}
const ShacklesSources=preload("res://core/shackles_primus_sources.gd")
const EleventhHourSources=preload("res://core/eleventh_hour_sources.gd")
const DoubleHeaderSources=preload("res://core/double_header_sources.gd")
const TempestSources=preload("res://core/golganneth_tempest_sources.gd")
const UpsetSources=preload("res://core/uncompensated_upset_sources.gd")
const AggramarSources=preload("res://core/aggramar_sources.gd")
const ClockworkSources=preload("res://core/clockwork_stadium_sources.gd")
const OnFireSources=preload("res://core/everything_on_fire_sources.gd")
const FactoryLineSources=preload("res://core/factory_line_sources.gd")
const TemperanceSources=preload("res://core/temperance_sources.gd")
const RicketySources=preload("res://core/rickety_repairbot_sources.gd")
const TokenOldGodsSources=preload("res://core/token_old_gods_sources.gd")
const GretaSources=preload("res://core/greta_sources.gd")
const Tony=preload("res://core/tony_host.gd")
var _tony_authority: Dictionary={}
var _tony_host=Tony.new()
const CubeSources=preload("res://core/mystery_cube_sources.gd")
const VouchersSources=preload("res://core/trip_vouchers_sources.gd")
const WishboneSources=preload("res://core/ancient_wishbone_sources.gd")
const SinstoneSources=preload("res://core/sinstone_sticker_sources.gd")
const LocketSources=preload("res://core/lovely_locket_sources.gd")
const Fermenter=preload("res://core/soul_fermenter_host.gd")
var _soul_fermenter_host=Fermenter.new()
var _soul_fermenter_authority: Dictionary={}
const WhistleSources=preload("res://core/warband_whistle_sources.gd")
const CathedralSources=preload("res://core/replica_cathedral_sources.gd")
const BoomController=preload("res://core/boom_controller_host.gd")
var _boom_controller_host=BoomController.new()
var _boom_controller_authority: Dictionary={}
const Lantern=preload("res://core/twin_lanterns_host.gd")
var _lantern_host=Lantern.new()
var _lantern_authority: Dictionary={}
const Tumbleweed=preload("res://core/toxic_tumbleweed_host.gd")
var _tumbleweed_host=Tumbleweed.new()
var _tumbleweed_authority: Dictionary={}
const DevourerSouls=preload("res://core/devourer_souls_host.gd")
var _devourer_souls_host=DevourerSouls.new()
const Amalgadon=preload("res://core/amalgadon_state.gd")
const AmalgadonSources=preload("res://core/amalgadon_sources.gd")
const OldSoul=preload("res://core/old_soul_host.gd")
const OldSoulSources=preload("res://core/old_soul_sources.gd")
var _old_soul_authority: Dictionary={}
var _old_soul_host=OldSoul.new()
const BloodbinderSources=preload("res://core/bloodbinder_sources.gd")
const LavaSources=preload("res://core/timewarped_lava_sources.gd")
const Bonerender=preload("res://core/bonerender_host.gd")
var _bonerender_host=Bonerender.new()
var _bonerender_authority: Dictionary={}
const FandralSources=preload("res://core/fandral_sources.gd")
const TaverngoerSources=preload("res://core/taverngoer_sources.gd")
const SirenSources=preload("res://core/stormscale_siren_sources.gd")
const Deathhead=preload("res://core/deaths_head_sage_host.gd")
const SnarkySharkSources=preload("res://core/snarky_shark_sources.gd")
const NightmareSources=preload("res://core/nightmare_ectoplasm_sources.gd")
const NecrolyteSources=preload("res://core/necrolyte_sources.gd")
const ImperialSources=preload("res://core/imperial_defender_sources.gd")
const BoogieSources=preload("res://core/boogie_monster_sources.gd")
const SurpriseSources=preload("res://core/surprise_elemental_sources.gd")
const BalindaSources=preload("res://core/balinda_spell_sources.gd")
const RecurringNightmare=preload("res://core/recurring_nightmare_host.gd")
var _recurring_nightmare_host: RefCounted
const Khadgar=preload("res://core/khadgar_summon_host.gd")
const Elistra=preload("res://core/elistra_redirect_host.gd")
const ValithriaEntry=preload("res://core/valithria_entry_host.gd")
var _valithria_entry_seen: Dictionary={}
var _valithria_entry_context: Dictionary={}
var _valithria_entry_domain_context: Dictionary={}
const EnhancedSpawn=preload("res://core/enhanced_spawn_host.gd")
var _enhanced_spawn_host: RefCounted
const DitchGuardian=preload("res://core/ditch_guardian_host.gd")
var _ditch_guardian_host: RefCounted
const RadiantEmber=preload("res://core/radiant_ember_host.gd")
var _radiant_ember_host: RefCounted
const Seaside=preload("res://core/seaside_gain_host.gd")
const WaterloggedPen=preload("res://core/waterlogged_pen_host.gd")
const MagneticRepeatSources=preload("res://core/magnetic_repeat_sources.gd")
const LocPrince=preload("res://core/loc_prince_host.gd")
const HandMurlocGain=preload("res://core/hand_murloc_gain_host.gd")
const Brinescale=preload("res://core/brinescale_transfer_host.gd")
const Piranha=preload("res://core/piranha_vacancy_host.gd")
var _piranha_host=Piranha.new()
const MasterRealities=preload("res://core/master_realities_host.gd")
const Expeditioner=preload("res://core/timewarped_expeditioner_host.gd")
const OwnedRallyEOTSources=preload("res://core/owned_rally_end_turn_sources.gd")
const FishBait=preload("res://core/fish_bait_combat_host.gd")
const KerriganZerg=preload("res://core/kerrigan_zerg_combat.gd")
const KerriganLifecycle=preload("res://core/kerrigan_hero_host.gd")
const EyeSargerasSources=preload("res://core/eye_sargeras_sources.gd")
const MishmashStatHost=preload("res://core/mishmash_stat_host.gd")
const BattlecruiserMissileSources=preload("res://core/battlecruiser_missile_sources.gd")
const BattlecruiserConstructionSources=preload("res://core/battlecruiser_construction_sources.gd")
const BattlecruiserUltraSources=preload("res://core/battlecruiser_ultra_sources.gd")
const BattlecruiserCaduceusSources=preload("res://core/battlecruiser_caduceus_sources.gd")
const BattlecruiserYamatoSources=preload("res://core/battlecruiser_yamato_sources.gd")
const BattlecruiserBallisticsSources=preload("res://core/battlecruiser_ballistics_sources.gd")
const BattlecruiserBunkerSources=preload("res://core/battlecruiser_bunker_sources.gd")
const BattlecruiserUpgradeSources=preload("res://core/battlecruiser_upgrade_sources.gd")
const BotanistSources=preload("res://core/botanist_sources.gd")
const InventomaticSources=preload("res://core/inventomatic_sources.gd")
const MaelstromSources=preload("res://core/maelstrom_emergent_sources.gd")
const EfficientEngineerSources=preload("res://core/efficient_engineer_sources.gd")
const RadioStar=preload("res://core/radio_star_host.gd")
const MetalDispenser=preload("res://core/metal_dispenser_host.gd")
const AutoReveilleSources=preload("res://core/auto_reveille_sources.gd")
const ResourcefulSources=preload("res://core/resourceful_robot_sources.gd")
const TrailblazerSources=preload("res://core/trailblazer_combined_choice_sources.gd")
const LassoSources=preload("res://core/lasso_barrage_sources.gd")
const ClunkerAttachments=preload("res://core/clunker_attachment_sources.gd")
const ProtectorRallyHost=preload("res://core/protector_magnetic_rally.gd")
const AssemblerMagneticHost=preload("res://core/assembler_magnetic_death.gd")
const AttachmentFixedHand=preload("res://core/attachment_fixed_hand_host.gd")
var _protector_rally_host=ProtectorRallyHost.new()
var _assembler_magnetic_host=AssemblerMagneticHost.new()
var _attachment_fixed_hand=AttachmentFixedHand.new()
const TrenchSources=preload("res://core/trench_gem_sources.gd")
const EvolutionSources=preload("res://core/timewarped_evolution_sources.gd")
const LuckyEggSources=preload("res://core/lucky_egg_sources.gd")
const UnderlingSources=preload("res://core/underling_sources.gd")
const FacelessSources=preload("res://core/faceless_sources.gd")
const JandiceApprenticeSources=preload("res://core/jandice_apprentice_sources.gd")
const AureateSources=preload("res://core/aureate_laureate_sources.gd")
const BeatboxerSources=preload("res://core/beatboxer_sources.gd")
const WaxadredSources=preload("res://core/waxadred_refresh_sources.gd")
const DiscoSources=preload("res://core/disco_choice_sources.gd")
const MiniZerekSources=preload("res://core/mini_zerek_sources.gd")
const BrigandSources=preload("res://core/brigand_choice_sources.gd")
const WindsSpendSources=preload("res://core/winds_spend_sources.gd")
const ShadowWardenSources=preload("res://core/shadow_warden_sources.gd")
const TerrorguardSources=preload("res://core/terror_guard_cast_sources.gd")
const ThelwaterSources=preload("res://core/thelwater_start_sources.gd")
const GatekeeperSources=preload("res://core/gatekeeper_cast_sources.gd")
const NexusLordSources=preload("res://core/nexus_lord_replace_sources.gd")
const AquarriorSources=preload("res://core/aquarrior_refresh_sources.gd")
const DeadscaleSources=preload("res://core/deadscale_spellcraft_sources.gd")
const ContenderSources=preload("res://core/contender_power_sources.gd")
const ReverberDrakeSources=preload("res://core/reverber_drake_sources.gd")
const WatfinSources=preload("res://core/watfin_guess_sources.gd")
const CenturionSources=preload("res://core/centurion_purchase_sources.gd")
const FaunaEotSources=preload("res://core/fauna_eot_cast_sources.gd")
const StaffEotSources=preload("res://core/staff_eot_cast_sources.gd")
const BazaarSources=preload("res://core/bazaar_health_buy_sources.gd")
const PilgrimpSources=preload("res://core/pilgrimp_health_buy_sources.gd")
const HealthBuySources=preload("res://core/health_buy_sources.gd")
const Protoss=preload("res://core/protoss_combat_host.gd")
const Octosari=preload("res://core/octosari_host.gd")
const EscapeeSources=preload("res://core/escapee_hero_damage_sources.gd")
const SeafloorCast=preload("res://core/seafloor_cast_host.gd")
const BouncySources=preload("res://core/bouncy_refresh_sources.gd")
const SpellteachSources=preload("res://core/spellteach_murloc_sources.gd")
const HealthRefreshSources=preload("res://core/health_refresh_sources.gd")
const NetherConstructSources=preload("res://core/nether_construct_sources.gd")
const PantherSources=preload("res://core/panther_sources.gd")
const ClefthoofSources=preload("res://core/clefthoof_sources.gd")
const FelboarCastSources=preload("res://core/felboar_cast_sources.gd")
const FacelessDiscipleSources=preload("res://core/faceless_disciple_sources.gd")
const SandSwirlerSources=preload("res://core/sand_swirler_sources.gd")
const NathanosSources=preload("res://core/nathanos_sources.gd")
const FelhornSources=preload("res://core/felhorn_sources.gd")
const StartFriendlyConsumeSources=preload("res://core/start_friendly_consume_sources.gd")
const BeetleBlessing=preload("res://core/beetle_blessing_host.gd")
var _beetle_blessing_host=BeetleBlessing.new()
const FriendlyConsumeSources=preload("res://core/friendly_consume_sources.gd")
const ChamberSources=preload("res://core/energizing_chamber_sources.gd")
const DeityRecruitDRSources=preload("res://core/deity_recruit_dr_sources.gd")
const DeityActivateSources=preload("res://core/deity_activate_sources.gd")
const DeityBoardCastSources=preload("res://core/deity_board_cast_sources.gd")
const DeityHandGain=preload("res://core/deity_hand_gain_host.gd")
const DeityCastSources=preload("res://core/deity_cast_sources.gd")
const DeityCombat=preload("res://core/deity_combat_host.gd")
const WickedTome=preload("res://core/wicked_tome_host.gd")
const FelbloodPortraitCombat=preload("res://core/felblood_portrait_combat.gd")
const SandBarnstormer=preload("res://core/sand_barnstormer_host.gd")
var _sand_barnstormer_host: RefCounted
var _felblood_portrait_host: RefCounted
const ImpulsivePortrait=preload("res://core/impulsive_portrait_host.gd")
const DarkGiftCombat=preload("res://core/dark_gift_combat_host.gd")
const DarkGiftResources=preload("res://core/dark_gift_resource_host.gd")
const DarkGiftSources=preload("res://core/dark_gift_sources.gd")
const DrakkariRebornSources=preload("res://core/drakkari_reborn_sources.gd")
const MagneticGoldenSources=preload("res://core/magnetic_golden_sources.gd")
const CombatMagnetic=preload("res://core/combat_magnetic_host.gd")
const AutoAssemblerSources=preload("res://core/auto_assembler_sources.gd")
const AutomatonPortrait=preload("res://core/automaton_portrait_host.gd")
const KnittedSunfin=preload("res://core/knitted_sunfin_host.gd")
const CloudSerpentHorn=preload("res://core/cloud_serpent_horn_host.gd")
const ScourgeStaff=preload("res://core/scourge_staff_host.gd")
const KarazhanChess=preload("res://core/karazhan_chess_host.gd")
const YulonSticker=preload("res://core/yulon_sticker_host.gd")
const PiggyBank=preload("res://core/piggy_bank_host.gd")
const Quilligraphy=preload("res://core/quilligraphy_host.gd")
const BronzeTimepiece=preload("res://core/bronze_timepiece_host.gd")
const RivendarePortrait=preload("res://core/rivendare_portrait_host.gd")
const KaboomPortrait=preload("res://core/kaboom_portrait_host.gd")
const RylakPortrait=preload("res://core/rylak_portrait_host.gd")
const FishySticker=preload("res://core/fishy_sticker_host.gd")
const EternalPortrait=preload("res://core/eternal_portrait_host.gd")
const PirateChest=preload("res://core/pirate_chest_board_host.gd")
const OwnedFirstDeath=preload("res://core/owned_first_death_board_host.gd")
const PaidShopBonusSources=preload("res://core/paid_shop_bonus_sources.gd")
const RatBuddyRefreshSources=preload("res://core/rat_buddy_refresh_sources.gd")
const OwnedMechShield=preload("res://core/owned_mech_shield_board_host.gd")
const OwnedAttack=preload("res://core/owned_attack_board_host.gd")
const Crowbar=preload("res://core/crowbar_acquisition_host.gd")
const LowestOpponentPlainSources=preload("res://core/lowest_health_plain_sources.gd")
const AdjacentTide=preload("res://core/adjacent_tide_host.gd")
const RightmostBattlecry=preload("res://core/rightmost_battlecry_host.gd")
const MagneticMultiplySources=preload("res://core/magnetic_multiply_sources.gd")
const CombatRingCast=preload("res://core/combat_ring_cast_host.gd")
const WhelpSummon=preload("res://core/whelp_summon_host.gd")
const RightmostDual=preload("res://core/rightmost_dual_host.gd")
const MacawPortrait=preload("res://core/macaw_portrait_host.gd")
const RylakBattlecry=preload("res://core/rylak_battlecry_host.gd")
const HagReborn=preload("res://core/hag_reborn_host.gd")
const CombatGolden=preload("res://core/combat_golden_host.gd")
const MaximumImp=preload("res://core/maximum_imp_host.gd")
const GalewingSources=preload("res://core/galewing_sources.gd")
const Dramaloc=preload("res://core/dramaloc_rally_host.gd")
const Stoneshell=preload("res://core/stoneshell_rally_host.gd")
const Sinestra=preload("res://core/sinestra_gain_sources.gd")
const FirstAttack=preload("res://core/first_attack_immune_host.gd")
const Worgen=preload("res://core/worgen_target_host.gd")
const LinkedUndead=preload("res://core/linked_undead_host.gd")
var _linked_undead_host=LinkedUndead.new()
const DancingHatSources=preload("res://core/dancing_hat_sources.gd")
const NextTurnShopSources=preload("res://core/next_turn_shop_avenge_sources.gd")
const PastryAvenge=preload("res://core/pastry_avenge_sources.gd")
const Matador=preload("res://core/matador_redirect_host.gd")
const GemGolem=preload("res://core/gem_golem_host.gd")
const HeroExtraUseSources=preload("res://core/hero_extra_use_sources.gd")
const RoogugSources=preload("res://core/roogug_relay_sources.gd")
const BattlecrySwapSources=preload("res://core/battlecry_swap_sources.gd")
const Thornspike=preload("res://core/thornspike_pauldron_host.gd")
const OwnedCombatGems=preload("res://core/owned_combat_gem_host.gd")
const PufferquilSources=preload("res://core/pufferquil_sources.gd")
const TurnGoldenSources=preload("res://core/turn_golden_sources.gd")
const CastMinionGemSources=preload("res://core/cast_minion_gem_sources.gd")
const BattlecryGoldenSources=preload("res://core/battlecry_golden_registry.gd")
const KeywordLoss=preload("res://core/keyword_loss_host.gd")
const ShopConsumeSources=preload("res://core/shop_consume_sources.gd")
const ConsumeObserverSources=preload("res://core/consume_observer_sources.gd")
const SkyhatchRallySources=preload("res://core/skyhatch_rally_sources.gd")
const CageyCastSources=preload("res://core/cagey_autocast_sources.gd")
const DroneRepeatSources=preload("res://core/drone_repeat_sources.gd")
const BattlecryActivateSources=preload("res://core/battlecry_activate_sources.gd")
const DeftDeserterSources=preload("res://core/deft_deserter_sources.gd")
const TargetedActivateSources=preload("res://core/targeted_activate_sources.gd")
const DiscardGemCopySources=preload("res://core/discard_gem_copy_sources.gd")
const ActivateDiscardAmplifierSources=preload("res://core/activate_discard_amplifier_sources.gd")
const ActivateDiscardResourceSources=preload("res://core/activate_discard_resource_sources.gd")
const ActivateDiscardSources=preload("res://core/activate_discard_gem_sources.gd")
const ActivateGemSources=preload("res://core/activate_overflow_gem_sources.gd")
const ZestySources=preload("res://core/zesty_spellcraft_sources.gd")
const HandGemRepeatSources=preload("res://core/hand_gem_repeat_sources.gd")
const AvengePoison=preload("res://core/avenge_permanent_poison_host.gd")
const ChooseOneGemSources=preload("res://core/choose_one_gem_sources.gd")
const GemLedgerTransfer=preload("res://core/gem_ledger_transfer_host.gd")
const GemSummon=preload("res://core/gem_summon_multiplier_host.gd")
const KeywordGemSources=preload("res://core/keyword_gem_sources.gd")
const CombatGemTriggers=preload("res://core/combat_gem_trigger_host.gd")
const OwnedRecruitStatSources=preload("res://core/owned_recruit_stat_sources.gd")
const CombatGems=preload("res://core/combat_gem_host.gd")
const LastSpell=preload("res://core/last_spell_dr_host.gd")
const BattlecryCostSources=preload("res://core/battlecry_cost_sources.gd")
const RallyShield=preload("res://core/rally_permanent_shield_host.gd")
const OwnedAvenge=preload("res://core/owned_avenge_board_host.gd")
const RaptorAvenge=preload("res://core/raptor_avenge_host.gd")
const OwnedTimedSources=preload("res://core/owned_timed_economy_sources.gd")
const IntrinsicTwice=preload("res://core/intrinsic_dr_twice_host.gd")
const DealtLifetimeSources=preload("res://core/dealt_lifetime_resource_sources.gd")
const Anchorman=preload("res://core/anchorman_host.gd")
const PurchaseQuotaSources=preload("res://core/purchase_quota_sources.gd")
const PurchaseStatSources=preload("res://core/purchase_stat_order_sources.gd")
const HandBoard=preload("res://core/avenge_hand_board_host.gd")
const RallyEachType=preload("res://core/rally_each_type_host.gd")
const LockboxHost=preload("res://core/lockbox_combat_host.gd")
var _lockbox_host=LockboxHost.new()
func get_lockbox_host() -> RefCounted: return _lockbox_host
const SummonGet=preload("res://core/summon_get_host.gd")
const OwnedObserverResources=preload("res://core/owned_observer_resources.gd")
const HandStartCopy=preload("res://core/hand_start_copy_host.gd")
const NativeGem=preload("res://core/native_gem_growth_host.gd")
const BeetleObserver=preload("res://core/beetle_observer_host.gd")
const HandAcquisition=preload("res://core/hand_acquisition_buffs.gd")
const TradeQuotas=preload("res://core/native_trade_quotas.gd")
const StartChoice=preload("res://core/start_choice_host.gd")
const ShinyLayer=preload("res://core/shiny_layer_host.gd")
const NativeEnforcer=preload("res://core/native_enforcer_shield_host.gd")
const ShieldPermanent=preload("res://core/shield_permanent_host.gd")
const ShieldTaunt=preload("res://core/shield_taunt_sources.gd")
const SilithidSources=preload("res://core/silithid_sources.gd")
const Silithid=preload("res://core/silithid_host.gd")
const SalvagerSources=preload("res://core/salvager_sources.gd")
const Salvager=preload("res://core/salvager_host.gd")
const MaximumHistorySources=preload("res://core/maximum_history_sources.gd")
const MaximumHistory=preload("res://core/maximum_history_host.gd")
const TechnicianKiller=preload("res://core/technician_killer_sources.gd")
const TechnicianAttacks=preload("res://core/technician_killer_host.gd")
const WhirlGroups=preload("res://core/whirl_deathrattle_sources.gd")
const WhirlAcquisition=preload("res://core/whirl_deathrattle_host.gd")
const FishGroups=preload("res://core/fish_deathrattle_sources.gd")
const FishAcquisition=preload("res://core/fish_deathrattle_host.gd")
const EachTypePermanent=preload("res://core/each_type_permanent_sources.gd")
const KrushPreemptive=preload("res://core/krush_preemptive_sources.gd")
const JailbirdJuggernaut=preload("res://core/jailbird_juggernaut_host.gd")
var _jailbird_juggernaut_host=JailbirdJuggernaut.new()
const NativeDRTriggers=preload("res://core/native_dr_trigger_sources.gd")
const TurnDeath=preload("res://core/turn_recruit_death_sources.gd")
const CastResources=preload("res://core/cast_resource_sources.gd")
const SurvivalStartSources=preload("res://core/survival_start_sources.gd")
const LivingRecruitDR=preload("res://core/living_recruit_deathrattle_sources.gd")
const MarketStats=preload("res://core/market_stat_echo_host.gd")
const NativeRallySpread=preload("res://core/native_rally_spread_host.gd")
const NativeStartGrant=preload("res://core/native_start_grant_host.gd")
const StartGrantSources=preload("res://core/native_start_grant_sources.gd")
const BrukanGrant=preload("res://core/brukan_elements_sources.gd")
const TamsinGrant=preload("res://core/tamsin_phylactery_sources.gd")
const TempDeath=preload("res://core/temporary_deathrattle_enchantments.gd")
const MegaGrants=preload("res://core/megasaur_adapt_grants.gd")
const SoldierChoice=preload("res://core/soldier_choice_sources.gd")
const RandomSpellcraftSources=preload("res://core/random_spellcraft_sources.gd")
const Wildfire=preload("res://core/wildfire_excess_host.gd")
const Pagle=preload("res://core/pagle_triple_host.gd")
const Overkill=preload("res://core/overkill_host.gd")
const OverkillSources=preload("res://core/overkill_sources.gd")
var _overkill_host=Overkill.new()
var _overkill_turn_side: int=-1
const MannorothSources=preload("res://core/mannoroth_sources.gd")
const BoogeymonsterSources=preload("res://core/boogeymonster_sources.gd")
const EachTierRefreshSources=preload("res://core/each_tier_refresh_sources.gd")
const ShopBattlecryReplaceSources=preload("res://core/shop_battlecry_replace_sources.gd")
const DragonKillSources=preload("res://core/dragon_kill_buff_sources.gd")
const KillHandSources=preload("res://core/kill_hand_sources.gd")
const NatSources=preload("res://core/nat_attack_kill_sources.gd")
const SecondKillSources=preload("res://core/second_kill_plain_sources.gd")
const SeabornSources=preload("res://core/seaborn_shop_sources.gd")
const StatSpellSources=preload("res://core/stat_spell_resource_sources.gd")
const CombatPlain=preload("res://core/combat_plain_copy_host.gd")
const CombatPlainSources=preload("res://core/combat_plain_copy_sources.gd")
const RecruitExactSources=preload("res://core/recruit_exact_copy_sources.gd")
const ZarjiraCopySources=preload("res://core/zarjira_copy_sources.gd")
const DuplicatingLensSources=preload("res://core/duplicating_lens_sources.gd")
const PreviousPlainSources=preload("res://core/previous_opponent_plain_sources.gd")
const PlainCopySources=preload("res://core/native_plain_copy_sources.gd")
const ShellTransfer=preload("res://core/shell_transfer_sources.gd")
const MilestoneHeroes=preload("res://core/milestone_hero_host.gd")
const DeathResources=preload("res://core/death_resource_trinkets.gd")
const SummonResources=preload("res://core/summon_resource_trinkets.gd")
const NativeSummonClock=preload("res://core/combat_summon_resource_clock.gd")
const LohRewards=preload("res://core/loh_attack_reward_host.gd")
const PhaseArmy=preload("res://core/phase_undead_army_sources.gd")
const DeathTrinkets=preload("res://core/deathrattle_trinket_rewards.gd")
const DamagePermanent = preload("res://core/permanent_demon_damage_sources.gd")
const ReceivedNative=preload("res://core/received_native_sources.gd")
const ElementalSources=preload("res://core/elemental_recruit_sources.gd")
const RefreshSpellcraft=preload("res://core/refresh_spellcraft_clock.gd")
const VashjSources=preload("res://core/vashj_resource_sources.gd")
const DamageFollowupSources=preload("res://core/damage_followup_sources.gd")
const KillRewards = preload("res://core/kill_reward_host.gd")
const ThresholdDamage = preload("res://core/threshold_damage_listeners.gd")
const AttackGains = preload("res://core/attack_gain_listeners.gd")
const RecruitClock = preload("res://core/bulk_recruit_clock.gd")
const CombatKeep = preload("res://core/combat_keep_gains.gd")
const GlobalCounterHost = preload("res://core/bulk_global_counter_host.gd")
const GlobalCards = preload("res://core/bulk_global_card_stats.gd")
const BulkHeroDamage = preload("res://core/bulk_hero_damage_recruit.gd")
const BulkKeywords = preload("res://core/bulk_keyword_grants.gd")
const TradeTriggers = preload("res://core/bulk_trade_trigger_effects.gd")
const BulkDiscover = preload("res://core/bulk_recruit_discover_effects.gd")
const PeriodicEot = preload("res://core/bulk_periodic_eot_effects.gd")
const BulkTurnCounters = preload("res://core/bulk_turn_counter_effects.gd")
const BulkResourceSources = preload("res://core/bulk_random_resource_sources.gd")
const BulkResourceHost = preload("res://core/bulk_random_resource_host.gd")
const RefreshOwnerBuffs = preload("res://core/refresh_owner_buffs.gd")
const FodderRefresh=preload("res://core/fodder_refresh_host.gd")
const FodderSaleSources=preload("res://core/fodder_sale_sources.gd")
const DefilerPortraitSources=preload("res://core/defiler_portrait_sources.gd")
var _fodder_refresh_host=FodderRefresh.new()
var _refresh_owner_buff_host = RefreshOwnerBuffs.new()
const DamageResource = preload("res://core/damage_resource_host.gd")
var _damage_resource_host = DamageResource.new()
var _bulk_resource_host = BulkResourceHost.new()
const GeneratedDiscover = preload("res://core/generated_tier7_discover.gd")
const BulkRecruit = preload("res://core/bulk_recruit_effects.gd")
const RebornMechanisms = preload("res://core/reborn_mechanism_sources.gd")
const RebornMechanismHost = preload("res://core/reborn_mechanism_host.gd")
const CombatTransforms = preload("res://core/combat_transform_sources.gd")
const CombatCopies = preload("res://core/combat_copy_sources.gd")
const BulkHandSummon = preload("res://core/bulk_hand_summon_sources.gd")
const Preemptive = preload("res://core/rally_preemptive_sources.gd")
const DeferredHand = preload("res://core/deferred_hand_summon_sources.gd")
const NextCombatSpells = preload("res://core/next_combat_spell_sources.gd")
const BulkActivate = preload("res://core/bulk_minion_activate.gd")
const Knights = preload("res://core/knight_summon_sources.gd")
const LivingDeathrattles = preload("res://core/living_deathrattle_sources.gd")
const RebornGrants = preload("res://core/reborn_grant_sources.gd")
const BattlecruiserUltra=preload("res://core/battlecruiser_ultra_combat.gd")
const RebornRetention = preload("res://core/reborn_retention_sources.gd")
const SummonAttempt = preload("res://core/summon_attempt_sources.gd")
const SummonPermanent = preload("res://core/summon_permanent_sources.gd")
const RebornCombat = preload("res://core/reborn_combat_sources.gd")
const OriginalJelly = preload("res://core/original_jelly_reborn_sources.gd")
const Jelly = preload("res://core/jelly_reborn_sources.gd")
const Sister = preload("res://core/sister_reborn_sources.gd")
const SisterHost = preload("res://core/sister_reborn_host.gd")
const Gnoll = preload("res://core/gnoll_death_aura_sources.gd")
const GhoulDeath = preload("res://core/ghoul_death_sources.gd")
const CompletedAttack = preload("res://core/completed_attack_sources.gd")
const Gadrin = preload("res://core/gadrin_recipient_health_sources.gd")
const Ragnaros = preload("res://core/timewarped_ragnaros_attack.gd")
const SummonOverflow = preload("res://core/summon_overflow_host.gd")
const EarthMother = preload("res://core/earth_mother_sources.gd")
const Sunscreener = preload("res://core/sunscreener_sources.gd")
const HiredRitualist = preload("res://core/hired_ritualist_gold.gd")
const DoubleStat = preload("res://core/double_stat_prize_sources.gd")
const BoneBaron = preload("res://core/bone_baron_sources.gd")
const BarovCoin = preload("res://core/barov_coin_sources.gd")
const SpikedSavior = preload("res://core/spiked_savior_normal_sources.gd")
const Enforcer = preload("res://core/enforcer_single_batch_sources.gd")
const Ticking = preload("res://core/ticking_friendly_damage_sources.gd")
const Duelist = preload("res://core/duelist_refresh.gd")
const Cruise = preload("res://core/cruise_controller_sources.gd")
const CruiseHost = preload("res://core/cruise_controller_host.gd")
const TreantAttack = preload("res://core/treant_attack_sources.gd")
const ChampionAttack = preload("res://core/champion_attack_sources.gd")
const Bristleback = preload("res://core/bristleback_taunt_sources.gd")
const AttackedAdjacent = preload("res://core/attacked_adjacent_sources.gd")
const AttackedVenomous = preload("res://core/attacked_venomous_sources.gd")
const UtilityDrone = preload("res://core/utility_drone_sources.gd")
const Saurolisk = preload("res://core/timewarped_saurolisk_sources.gd")
const EkkronSources = preload("res://core/ekkron_play_shields_sources.gd")
const SproutAvenge = preload("res://core/sprout_avenge_sources.gd")
const CorpseSale = preload("res://core/corpse_sale_bonus.gd")
const CombatEconomy = preload("res://core/combat_economy_rewards.gd")
const VoidPup = preload("res://core/void_pup_sources.gd")
const FilteredGrants = preload("res://core/filtered_battlecry_grants.gd")
const UpgradeAura = preload("res://core/tavern_upgrade_aura.gd")
const PreviousCombat = preload("res://core/previous_combat_battlecries.gd")
const Constellation = preload("res://core/constellation_type_buff.gd")
const ThreeTribe = preload("res://core/three_tribe_buffs.gd")
const BonusKeyword = preload("res://core/bonus_keyword_battlecries.gd")
const SmugglerGems = preload("res://core/blood_gems.gd")
const NativeRecruit = preload("res://core/recruit_token_sources.gd")
const NativeBattlecry = preload("res://core/battlecry_listener_sources.gd")
const CurrentTierGrants = preload("res://core/current_tier_eot_grants.gd")
const FixedGrants = preload("res://core/fixed_spell_grants.gd")
const StartFixedGrants = preload("res://core/start_turn_fixed_grants.gd")
const AccordGold = preload("res://core/accordotron_gold.gd")
const StartGold = preload("res://core/start_turn_native_gold.gd")
const RecruitExtensions = preload("res://core/recruit_extensions.gd")
const RecruitTargets = preload("res://core/recruit_target_effects.gd")
const OutbackSources = preload("res://core/outback_sources.gd")
const Alleycat = preload("res://core/alleycat_stat_summon_sources.gd")
const DamageListenerHost = preload("res://core/damage_listener_host.gd")
const DamageListenerEvents = preload("res://core/damage_listener_events.gd")
const BeetleHost = preload("res://core/beetle_growth_host.gd")
const BeetleGrowth = preload("res://core/beetle_growth_effects.gd")
const BeetleSources = preload("res://core/beetle_growth_sources.gd")
const BeetleEvents = preload("res://core/beetle_growth_events.gd")
const AttackGainOrder = preload("res://core/attack_gain_order.gd")
const FriendlyAttack = preload("res://core/friendly_attack_buffs.gd")
const FriendlyAttackRoom = preload("res://core/friendly_attack_room.gd")
const TavernAmplifier = preload("res://core/tavern_spell_amplifiers.gd")
const SaleGemSources=preload("res://core/sale_blood_gem_sources.gd")
const SaleCycleSources=preload("res://core/sale_cycle_amplifier_sources.gd")
const RefreshGoldenSources=preload("res://core/refresh_golden_sources.gd")
const InplaceGoldenSources=preload("res://core/inplace_golden_sources.gd")
const DelayedGold = preload("res://core/delayed_minion_gold.gd")
const Investigator = preload("res://core/private_investigator_sources.gd")
const NextSpellDiscount = preload("res://core/next_spell_discount.gd")
const HandSummon = preload("res://core/hand_summon_effects.gd")
const HandSummonRoom = preload("res://core/hand_summon_room.gd")
const HeroImmunity = preload("res://core/hero_immunity.gd")
const BoardAura = preload("res://core/board_aura_effects.gd")
const BoardAuraRuntime = preload("res://core/board_aura_runtime.gd")
const ArgentBraggart = preload("res://core/argent_braggart.gd")
const TurnRepeat = preload("res://core/turn_repeat_spells.gd")
const TradeStat = preload("res://core/trade_stat_listeners.gd")
const EndTurnRepeats = preload("res://core/end_turn_repeats.gd")
const CardPlayParity = preload("res://core/card_play_parity.gd")
const SpellCastListeners = preload("res://core/spell_cast_listeners.gd")
const PurchaseSpellCopy = preload("res://core/purchase_spell_copy.gd")
const MinionDiscover = preload("res://core/minion_discover_effects.gd")
const RecruitHand = preload("res://core/recruit_hand_effects.gd")
const HeroPowerRefresh = preload("res://core/hero_power_refresh.gd")
const HeroPowerListeners = preload("res://core/hero_power_listeners.gd")
const GoldIncome = preload("res://core/gold_income.gd")
const MinionActivate = preload("res://core/minion_activate.gd")
const ChooseOne = preload("res://core/choose_one_effects.gd")
const Volcanic = preload("res://core/volcanic_visitor_sources.gd")
const AllianceFlag = preload("res://core/alliance_flag_sources.gd")
const Felfire = preload("res://core/felfire_conjurer_sources.gd")
const Meditation = preload("res://core/meditation_sources.gd")
const ReefRiffer = preload("res://core/reef_riffer_sources.gd")
const RecruitCounters = preload("res://core/recruit_counter_effects.gd")
## Pure, deterministic combat engine for the explicitly supported sandbox-1 DSL.

const CombatTribeBonuses = preload("res://core/combat_tribe_bonuses.gd")
const PermanentTribeEffects = preload("res://core/permanent_tribe_effects.gd")
const CombatHand = preload("res://core/combat_hand.gd")
const StartCombatEffects = preload("res://core/start_combat_effects.gd")
const StartCombatRepeats = preload("res://core/start_combat_repeat_host.gd")
var _start_repeat_host
const IllidanStart=preload("res://core/illidan_start_host.gd")
const Counterattacker=preload("res://core/counterattacker_host.gd")
const Giantfin=preload("res://core/giantfin_hero.gd")
const Nefarian=preload("res://core/nefarian_hero.gd")
const PutricideOld=preload("res://core/putricide_old_hero.gd")
const Wagtoggle=preload("res://core/wagtoggle_hero.gd")
const CombatHero = preload("res://core/combat_hero_effects.gd")
const PersistentShopEffects = preload("res://core/persistent_shop_effects.gd")
const AttackTransfer = preload("res://core/combat_attack_transfer.gd")
const RefreshListeners = preload("res://core/refresh_listeners.gd")
const DeathwingCombat = preload("res://core/deathwing_combat_adapter.gd")
const BOARD_LIMIT: int = 7
const MAX_STAT: int = 9223372036854775807
# Complete native Dozy pair. Catalog fields are immutable source records;
# live/Reborn instances retain the program but may have changed stats/keywords.
const DOZY_IDS: Array[String] = ["BG24_300", "BG24_300_G"]
const DOZY_SOURCES: Dictionary = {
  "BG24_300": {
    "name": "瞌睡雏龙",
    "kind": "minion",
    "card_code": "BG24_300",
    "dbf_id": "97594",
    "tier": 1,
    "attack": 0,
    "health": 4,
    "tribes": [
      "龙"
    ],
    "is_golden": false,
    "normal_id": null,
    "golden_id": "BG24_300_G",
    "text": "嘲讽。每当本随从受到攻击时，永久获得+1攻击力。",
    "keywords": [
      "taunt"
    ]
  },
  "BG24_300_G": {
    "name": "瞌睡雏龙",
    "kind": "minion",
    "card_code": "BG24_300_G",
    "dbf_id": "97596",
    "tier": 1,
    "attack": 0,
    "health": 8,
    "tribes": [
      "龙"
    ],
    "is_golden": true,
    "normal_id": "BG24_300",
    "golden_id": null,
    "text": "嘲讽。每当本随从受到攻击时，永久获得+2攻击力。",
    "keywords": [
      "taunt"
    ]
  }
}
const DOZY_PROGRAMS: Dictionary = {
  "BG24_300": [
    {
      "type": "on_attacked_buff",
      "scope": "target",
      "require_self": true,
      "attack": 1,
      "health": 0,
      "permanent": true
    }
  ],
  "BG24_300_G": [
    {
      "type": "on_attacked_buff",
      "scope": "target",
      "require_self": true,
      "attack": 2,
      "health": 0,
      "permanent": true
    }
  ]
}
const SHIELD_EVENT_TYPES: Array[String] = ["on_shield_lost_buff", "on_shield_lost_keyword", "on_shield_lost_add_card"]
const MEGA_AURA_PROGRAMS: Dictionary={"BG_DAL_742":[{"type":"friendly_windfury_mega_aura","source_id":"BG_DAL_742"}],"TB_BaconUps_206":[{"type":"friendly_windfury_mega_aura","source_id":"TB_BaconUps_206"}]}
const COMBAT_KEYWORDS: Array[String] = ["elusive","stealth","taunt", "divine_shield", "reborn", "windfury", "poisonous", "venomous", "immunity_while_attacking", "target_lowest_attack"]
const RECRUIT_KEYWORDS: Array[String] = ["battlecry", "deathrattle", "magnetic", "rally"]
const RECRUIT_EFFECTS: Array[String] = ["end_turn_darkcrest_upgrade","on_play_shatterer","timewarp_swirler_giver_aura","on_sell_timewarp_scout_verified_base","on_play_spark_snapper_base","on_play_timewarp_molten_base","on_sell_air_baller_verified_base","on_sell_snow_baller_verified_base","on_sell_fire_baller_verified_base","after_discover_hooktusk_base","start_turn_timewarp_rodeo_discover","on_play_timewarp_amalgam","after_two_tavern_spells_native_magnetic","on_play_timewarp_theotar","anomaly_valuation_inflation",NosySources.TYPE,PatientScoutSources.EOT,PatientScoutSources.SALE,PatientScoutSources.START,AristocratSources.TYPE,FandralSources.TYPE,TaverngoerSources.TYPE,SirenSources.TYPE,Deathhead.Sources.TYPE,SnarkySharkSources.TYPE,NightmareSources.TYPE,NecrolyteSources.TYPE,MagneticRepeatSources.TYPE,MegaGrants.Sources.TYPE,SpellteachSources.TYPE,SpellteachSources.CAST,BouncySources.TYPE,OwnedRallyEOTSources.TYPE,FishBait.Sources.ACTIVATE,KerriganLifecycle.Sources.TYPE,KerriganZerg.Sources.MORPH,KerriganZerg.Sources.EOT,KerriganZerg.Sources.PLAY,EyeSargerasSources.TYPE,"spell_native_ice_block",BattlecruiserUltraSources.TYPE,BattlecruiserConstructionSources.TYPE,BattlecruiserMissileSources.TYPE,BattlecruiserCaduceusSources.TYPE,BattlecruiserYamatoSources.TYPE,BattlecruiserBallisticsSources.TYPE,BattlecruiserBunkerSources.TYPE,BattlecruiserUpgradeSources.TYPE,EachTierRefreshSources.TYPE,ShopBattlecryReplaceSources.TYPE,Protoss.Sources.SPEND,"end_turn_last_tavern_spell_copy",SandSwirlerSources.TYPE,EfficientEngineerSources.TYPE,NathanosSources.TYPE,FacelessDiscipleSources.TYPE,DroneRepeatSources.TYPE,CageyCastSources.TYPE,AutoReveilleSources.TYPE,ResourcefulSources.TYPE,DeftDeserterSources.TYPE,SkyhatchRallySources.TYPE,TrailblazerSources.TYPE,LassoSources.TYPE,ClunkerAttachments.TYPE,TrenchSources.EOT,TrenchSources.SPELL,EvolutionSources.TYPE,LuckyEggSources.TYPE,UnderlingSources.TYPE,FacelessSources.TYPE,JandiceApprenticeSources.TYPE,AureateSources.TYPE,BeatboxerSources.TYPE,WaxadredSources.TYPE,MiniZerekSources.TYPE,WindsSpendSources.TYPE,ShadowWardenSources.TYPE,TerrorguardSources.TYPE,ThelwaterSources.TYPE,GatekeeperSources.TYPE,NexusLordSources.TYPE,AquarriorSources.TYPE,ContenderSources.TYPE,ReverberDrakeSources.TYPE,WatfinSources.TYPE,CenturionSources.TYPE,FaunaEotSources.TYPE,StaffEotSources.TYPE,BazaarSources.TYPE,PilgrimpSources.TYPE,CombatRingCast.QueenSources.BATTLECRY,HealthBuySources.TYPE,EscapeeSources.TYPE,HealthRefreshSources.TYPE,DefilerPortraitSources.EOT,NetherConstructSources.TYPE,PantherSources.TYPE,ClefthoofSources.TYPE,FelboarCastSources.TYPE,FodderSaleSources.TYPE,FelhornSources.TYPE,FodderRefresh.Sources.BATTLECRY,FodderRefresh.Sources.FEED,StartFriendlyConsumeSources.TYPE,FriendlyConsumeSources.TYPE,ChamberSources.SPELL,DeityActivateSources.TYPE,"on_discard_self_deity_buff",DeityBoardCastSources.TYPE,"on_sell_native_minion_member_group",DeityHandGain.Sources.TYPE,DeityCastSources.TYPE,"on_sell_native_spell_member_group",DeityCombat.Sources.BATTLECRY,DrakkariRebornSources.TYPE,MagneticGoldenSources.TYPE,CombatMagnetic.Electron.TYPE,CombatMagnetic.Satellite.TYPE,"after_spend_gold_permanent_shop","refresh_free_if_hero_type_absent","start_turn_lowest_health_opponent_plain","after_self_magnetized_native_multiply",GalewingSources.BUDDY,BulkHeroDamage.Archimonde.TYPE,DancingHatSources.BUDDY_TYPE,HeroExtraUseSources.BUDDY,BattlecrySwapSources.TYPE,PufferquilSources.TYPE,TurnGoldenSources.START,"after_real_shop_consume_self_stats","after_real_shop_consume_turn_shop",CastMinionGemSources.TYPE,BattlecryGoldenSources.TYPE,ShopConsumeSources.TYPE,"after_buy_once_add_then_multiply",BattlecryActivateSources.TYPE,"battlecry_whelp_owner_layer",TargetedActivateSources.TYPE,DiscardGemCopySources.START,ActivateDiscardAmplifierSources.TYPE,ActivateDiscardResourceSources.TYPE,ActivateDiscardSources.TYPE,ActivateGemSources.TYPE,"after_self_spellcraft_copy","end_turn_frozen_shop_golden",HandGemRepeatSources.TYPE,"after_refresh_highest_shop_golden","after_sell_murloc_tavern_spell_bonus","after_choose_one_play_blood_gems","after_sell_quillboar_blood_gems","end_turn_source_keyword_blood_gems","active_tavern_spell_bonus","native_owned_recruit_stats","battlecry_native_cost_reduction","native_owned_timed_economy","native_tavern_spell_quota_discount","native_owned_battlecry_purchase_free","native_owned_stat_spell_discount","battlecry_lockbox","after_spend_gold_lockbox","locked_hand_countdown","battlecry_native_filtered_refresh","on_accepted_hand_interval_buff","on_accepted_owned_minion_buff","on_buy_same_tier_spell_limited","on_hand_added_pirate_maximum","native_turn_free_refresh_quota",VashjSources.BUDDY_TYPE,"after_discover_other_options_stats","battlecry_volumizer_resource","end_turn_volumizer_resource",BulkResourceHost.Golden.TYPE,RefreshSpellcraft.TYPE,TurnDeath.START,TurnDeath.EOT,"after_spellcraft_resource","after_tavern_spell_resource",ElementalSources.PLAY,ElementalSources.REFRESH,ElementalSources.SWAP,SurvivalStartSources.REWARD,SurvivalStartSources.DOCTOR,LivingRecruitDR.TYPE,MarketStats.Sources.EOT,TempDeath.Sources.TYPE,BulkActivate.REBORN_DESTROY,RandomSpellcraftSources.TYPE,"after_gain_gold_buff","after_gain_gold_resource",SeabornSources.TYPE,"end_turn_stat_spell_resource","spell_stat_spell_resource","after_spend_gold_pirate_buff","after_spend_gold_resource",RecruitExactSources.TYPE,"after_spend_gold_bounty",ZarjiraCopySources.TYPE,DuplicatingLensSources.TYPE,PreviousPlainSources.BATTLECRY,PreviousPlainSources.SPELL,"bounty_cast_repeat",PlainCopySources.SALE_TYPE,"battlecry_bounty_resource","end_turn_bounty_resource","spell_random_majority_resource",BulkResourceHost.Chromatic.BATTLECRY,BulkResourceHost.Chromatic.ACTIVATE,ShellTransfer.TYPE,"trinket_spellcraft","battlecry_destroy_undead","battlecry_special_magnetic_resource","spell_owner_extra_offer","mechanism_first_tavern_spell_discount","spell_refresh_extra_offer","after_real_card_play_self_attack","spell_repeat_distinct_type_buff","refresh_extra_offer","spell_board_blood_gems",BulkActivate.STEAL,BulkActivate.NEXT_BUY,"spell_bulk_discover",BulkActivate.DISCOVER,BulkActivate.RANDOM,BulkActivate.BUFF,"hero_random_tavern_spell","end_turn_all_battlecries","battlecry_generate_cost_two_spell","spell_generate_tier_one_naga","spell_refresh_owner_buff","spell_trigger_battlecry","end_turn_discard_tavern_self_buff","on_discard_other_buff","on_discard_self_cast","on_discard_max_gold","after_tavern_spell_turn_shop_bonus","after_tavern_spell_hero_damage_demon_buff","start_turn_low_tier_battlecries","start_turn_lose_attack",RefreshOwnerBuffs.BATTLECRY,"spell_generate_random_tavern","start_turn_discard_spell_gold","spell_refresh_gem_barrage",GlobalCards.TYPE,"battlecry_fixed_resource","spell_fixed_resource_absorption","spell_fixed_resource_devour_keywords","spell_fixed_resource_same_tribe",BulkHeroDamage.TYPE,BulkKeywords.BATTLECRY,BulkKeywords.EOT_SELF,BulkKeywords.EOT_OTHER,BulkKeywords.SPELL,TradeTriggers.RESOURCE,TradeTriggers.SHOP_TEMP,BulkDiscover.BATTLECRY,BulkDiscover.SALE,BulkDiscover.START,PeriodicEot.TYPE,BulkTurnCounters.TYPE,"end_turn_fixed_resource","spell_random_resource_copy","battlecry_random_resource",GeneratedDiscover.TYPE,"on_sell_bulk_source_stats","shop_bulk_sold_stats","end_turn_bulk_missing_health","end_turn_bulk_source_stats","end_turn_bulk_random_tavern_spell","on_sell_bulk_shop_spell_copy",NativeRecruit.Upstart.TYPE,NativeRecruit.Cabbie.TYPE,Alleycat.TYPE,NativeRecruit.Weaver.TYPE,NativeRecruit.Anubarak.TYPE,Duelist.TYPE,ArgentBraggart.TYPE,EkkronSources.TYPE,CurrentTierGrants.TYPE,CurrentTierGrants.FAIRY_TYPE,UpgradeAura.TYPE,"battlecry_blood_gem_bonus","start_turn_blood_gem_bonus","end_turn_add_card","battlecry_beetle_native","end_turn_self_type_count_buff","after_tavern_refresh_rightmost","spell_tavern_spell_bonus","battlecry_tavern_spell_bonus","on_sell_tavern_spell_bonus","end_turn_tavern_spell_bonus","battlecry_queue_gold","battlecry_next_tavern_spell_discount","on_trade_stat_buff","recruit_eot_repeat_modifier","on_play_card_tier_parity_buff","on_play_card_tier_range_tribe_buff","on_spell_cast_buff","battlecry_permanent_tribe_bonus", "on_sell_refresh_hero_power", "after_hero_power_divine_shield_attack", "minion_activate_add_card", "minion_activate_queue_gold", "end_turn_increase_max_gold", "on_buy_zero_cost_tavern_spell_copy", "battlecry_discover_minion", "on_sell_discover_minion", "battlecry_random_board_hand_buff", "in_hand_on_play_buff", "end_turn_hand_source_stats", "on_target_spell_hand_buff", "choose_one", "battlecry_family_play_buff", "battlecry_buy_count_buff", "battlecry_control_count_buff", "battlecry_buff", "battlecry_gold", "battlecry_summon", "end_turn_buff", "spell_buff", "spell_gold", "hero_gold", "hero_buff", "economy", "start_turn_buff", "on_play_buff", "battlecry_add_card", "battlecry_damage", "on_sell_gold", "battlecry_repeat", "on_play_effect", "on_buy_gold", "on_sell_add_card", "on_upgrade_buff", "battlecry_keyword", "battlecry_set", "battlecry_free_rolls", "battlecry_upgrade_discount", "spellcraft", "spellcraft_permanent", "on_spell_effect", "blood_gem_bonus", "on_blood_gem", "battlecry_devour", "battlecry_random_card", "battlecry_tier_buff", "end_turn_blood_gem", "end_turn_devour", "on_play_blood_gem_card", "on_play_devour", "on_play_roll_discount", "on_play_shop_buff", "on_spend_blood_gem", "shop_aura_buff", "on_sell_random_card", "battlecry_add_shop", "on_play_tier_buff", "battlecry_conditional_discover", "battlecry_each_type_buff", "end_turn_each_type_buff", "on_play_tribeless_each_type_buff", "two_copy_triple", "end_turn_keyword", "battlecry_missing_health_buff", "on_play_deathrattle_buff", "on_battlecry_triggered_buff", "end_turn_elemental_buff", "on_sell_loss_gold", "end_turn_steal_highest", "end_turn_adjacent_battlecries", "end_turn_recruit_buff", "on_play_recruit_buff", "end_turn_shop_buff", "battlecry_devour_board", "battlecry_shop_bonus"]
const COMBAT_EFFECTS: Array[String] = [Rider.Sources.TYPE,"timewarp_chimera_received_each_type",Lobster.Sources.TYPE,Leviathan.Sources.TYPE,Kibble.Sources.TYPE,Hopebringer.Sources.START,Hopebringer.Sources.GROW,Apexis.Sources.DR,EnergyRecycling.Sources.TYPE,MutatedLasher.Sources.TYPE,KidnapSackSources.TYPE,KidnapSackSources.SPELL_TYPE,GoldenHammerSources.TYPE,GoldenHammerSources.SPELL_TYPE,FalseIdolsSources.TYPE,PartnerInCrimeSources.TYPE,PilferedLampsSources.TYPE,SecretSinstoneSources.TYPE,VictimSpecterSources.TYPE,GrimFreshenerSources.TYPE,SnickerSnacksSources.TYPE,ExquisiteConchSources.TYPE,VolatileVenomSources.TYPE,AlterEgoSources.TYPE,StolenGoldSources.TYPE,BombSquadSources.TYPE,TheotarParasolSources.TYPE,EvilTwinSources.TYPE,GoldenArrowSources.TYPE,ArgusSources.TYPE,PerfectedSources.TYPE,RecklessSources.TYPE,AntiGravitySources.TYPE,AnomalousTwinsSources.TYPE,IncubationMutationSources.TYPE,ShacklesSources.TYPE,EleventhHourSources.TYPE,DoubleHeaderSources.TYPE,TempestSources.TYPE,UpsetSources.TYPE,AggramarSources.TYPE,ClockworkSources.TYPE,OnFireSources.TYPE,FactoryLineSources.TYPE,TemperanceSources.TYPE,RicketySources.TYPE,TokenOldGodsSources.TYPE,TokenOldGodsSources.OWNED,GretaSources.TYPE,Tony.Sources.TYPE,CubeSources.TYPE,VouchersSources.TYPE,WishboneSources.TYPE,SinstoneSources.TYPE,LocketSources.TYPE,Fermenter.Sources.TYPE,WhistleSources.TYPE,CathedralSources.TYPE,BoomController.Sources.TYPE,Lantern.Sources.TYPE,DevourerSouls.Sources.TYPE,AmalgadonSources.TYPE,OldSoulSources.TYPE,BloodbinderSources.TYPE,LavaSources.TYPE,Bonerender.Sources.TYPE,ImperialSources.TYPE,BoogieSources.TYPE,SurpriseSources.TYPE,BalindaSources.TYPE,Khadgar.Sources.TYPE,RecurringNightmare.Sources.TYPE,Elistra.Sources.TYPE,ValithriaEntry.Sources.TYPE,MasterRealities.Cthun.TYPE,MasterRealities.Titanic.TYPE,MasterRealities.Ragescale.TYPE,RadiantEmber.Sources.TYPE,Seaside.Sources.TYPE,MasterRealities.Storm.TYPE,LocPrince.Sources.TYPE,HandMurlocGain.Sources.TYPE,Brinescale.Sources.TYPE,Piranha.Sources.TYPE,MasterRealities.Sources.TYPE,NativeEnforcer.Sources.Enforcer.TYPE,NativeEnforcer.Sources.Bolvar.TYPE,Expeditioner.Sources.TYPE,FishBait.Sources.IMMUNITY,FishBait.Sources.DEATH,RadioStar.Sources.TYPE,KerriganZerg.Sources.COPY,KerriganZerg.Sources.RALLY,KerriganZerg.Sources.DEATH,KerriganZerg.Sources.KILL,KerriganZerg.Sources.AVENGE,KerriganZerg.Sources.MULTIPLY,Thornspike.Sources.TYPE,BattlecruiserUltraSources.PASSIVE,BattlecruiserConstructionSources.PASSIVE,BattlecruiserMissileSources.PASSIVE,MishmashStatHost.Sources.TYPE,InventomaticSources.TYPE,MaelstromSources.TYPE,Protoss.Sources.RESOURCE,Protoss.Sources.CARRIER,Protoss.Sources.ATTACK,"friendly_windfury_mega_aura",OverkillSources.TYPE,MannorothSources.TYPE,BoogeymonsterSources.TYPE,MetalDispenser.Sources.TYPE,CombatRingCast.QueenSources.DEATH,Octosari.Sources.TYPE,Octosari.Sources.GROW,FodderRefresh.Sources.DEATHRATTLE,DeityRecruitDRSources.TYPE,DeityCombat.Sources.AWAKEN,DeityCombat.Sources.DEATH,AdjacentTide.Sources.TYPE,CombatRingCast.AttackSources.TYPE,CombatRingCast.Sources.TYPE,WhelpSummon.Sources.TYPE,RylakBattlecry.Sources.TYPE,HagReborn.Sources.TYPE,CombatGolden.Sources.START,CombatGolden.Sources.DEATH,MaximumImp.Sources.TYPE,Stoneshell.Sources.TYPE,Sinestra.TYPE,FirstAttack.Sources.TYPE,Worgen.Sources.TYPE,LinkedUndead.Sources.TYPE,LinkedUndead.Sources.DEATH,NextTurnShopSources.TYPE,PastryAvenge.TYPE,Matador.Sources.TYPE,GemGolem.Sources.DEATH,KeywordLoss.Sources.TYPE,"deathrattle_whelp_owner_layer",AvengePoison.Sources.TYPE,GemLedgerTransfer.Sources.TYPE,GemSummon.Sources.AURA,GemSummon.Sources.DEATH,CombatGemTriggers.Sources.ATTACK,CombatGemTriggers.Sources.AVENGE,CombatGemTriggers.Sources.DEATH,LastSpell.Sources.TYPE,IntrinsicTwice.Sources.TYPE,DealtLifetimeSources.TYPE,Anchorman.Sources.TYPE,HandBoard.Sources.TYPE,"deathrattle_lockbox",SummonGet.Sources.DEATH,HandStartCopy.Sources.TYPE,NativeGem.Sources.SHIELD,NativeGem.Sources.DEATH,NativeGem.Sources.AVENGE,BeetleObserver.Sources.ATTACK,BeetleObserver.Sources.DAMAGE,"deathrattle_special_volumizer_resource",StartChoice.Sources.WHITE,StartChoice.Sources.MANTID,ShinyLayer.Sources.TYPE,"deathrattle_beast_owner_layer",ShieldPermanent.Sources.TYPE,ShieldTaunt.TYPE,SilithidSources.TYPE,SilithidSources.GROW,SalvagerSources.START,SalvagerSources.TYPE,MaximumHistorySources.TYPE,TechnicianKiller.TYPE,WhirlGroups.TYPE,FishGroups.TYPE,"combat_summon_interval_resource",EachTypePermanent.TYPE,KrushPreemptive.TYPE,NativeDRTriggers.DEATH,BulkResourceHost.NativeSpellcraft.DEATHRATTLE,BulkResourceHost.NativeSpellcraft.AVENGE,MarketStats.Sources.START,Wildfire.Sources.TYPE,Pagle.Sources.TYPE,DragonKillSources.TYPE,KillHandSources.TYPE,NatSources.TYPE,SecondKillSources.TYPE,CombatPlainSources.RALLY,CombatPlainSources.AVENGE,"deathrattle_bounty_resource",BulkResourceHost.Chromatic.DEATHRATTLE,BulkResourceHost.Chromatic.AVENGE,PhaseArmy.TYPE,"native_multi_hit_shield",DamagePermanent.TYPE,ReceivedNative.PERMANENT,ReceivedNative.REFRESH,DamageFollowupSources.SUMMON,DamageFollowupSources.SPELLCRAFT,DamageFollowupSources.DEALT,KillRewards.TYPE,ThresholdDamage.THRESHOLD,ThresholdDamage.DEALT,"rally_repeat",AttackGains.TYPE,"frenzy_other_buff",DeferredHand.TYPE,BulkHandSummon.TYPE,CombatKeep.TYPE,Knights.TYPE,Knights.AVENGE_TYPE,RefreshOwnerBuffs.DEATHRATTLE,CombatTransforms.TYPE,CombatTransforms.START_TYPE,"combat_transfer_stat",CombatCopies.TYPE,"avenge_shield_force_attack","on_exact_damage_destroy_self",LivingDeathrattles.TYPE,LivingDeathrattles.START_TYPE,"deathrattle_random_temporary_summon",RebornGrants.TYPE,RebornGrants.START_TYPE,SummonPermanent.CONDITIONAL_TYPE,"start_combat_grant_deathrattle",RebornRetention.TYPE,"start_combat_force_attack","cannot_attack","after_adjacent_attack_damage",SummonAttempt.CAPACITY_TYPE,"after_attacked_survived_force_leftmost","on_shield_lost_hand_buff","deathrattle_damage_for_history","after_attack_highest_health_damage",SummonAttempt.TYPE,DamageResource.COUNTER_TYPE,DamageResource.TYPE,DamageResource.Extra.HAND_TYPE,DamageResource.Extra.GEM_TYPE,DamageResource.Extra.ARMY_TYPE,"deathrattle_copy_killer_base","on_attacked_set_attacker_health","on_friendly_attack_damage","deathrattle_source_max_stats",SummonPermanent.TYPE,"deathrattle_fixed_resource","start_combat_adjacent_damage_buff","deathrattle_random_resource","deathrattle_keyword_bundle",RebornCombat.TYPE,RebornCombat.ARMY_TYPE,Sister.TYPE,Gnoll.TYPE,GhoulDeath.TYPE,CompletedAttack.DESTROY_TYPE,CompletedAttack.BUFF_TYPE,SummonOverflow.Sources.TYPE,"avenge_beetle_native",NativeRecruit.DeviousDrust.TYPE,CorpseSale.Sources.TYPE,Cruise.TYPE,AttackedAdjacent.TYPE,AttackedVenomous.TYPE,Saurolisk.TYPE,"deathrattle_tavern_spell_bonus",NativeRecruit.Thorn.TYPE,"avenge_free_rolls","deathrattle_blood_gem_bonus","deathrattle_next_tavern_spell_discount","deathrattle_increase_max_gold","damage_received","deathrattle_beetle_native","deathrattle_queue_gold","after_friendly_death_summon_self_from_hand", "deathrattle_summon_from_hand", "deathrattle_permanent_tribe_bonus", "start_combat_tribe_bonus", "deathrattle_tribe_bonus", "deathrattle_summon", "deathrattle_damage", "deathrattle_buff", "deathrattle_attack_transfer", "deathrattle_destroy_killer", "on_attack_cleave", "deathrattle_keyword", "on_friendly_death_buff", "on_friendly_summon_buff", "deathrattle_repeat", "start_combat_buff", "start_combat_multiply", "on_attack_multiply", "target_lowest_attack", "deathrattle_add_card", "avenge", "on_shield_lost_buff", "on_shield_lost_keyword", "on_attack_damage", "on_shield_lost_add_card", "on_friendly_attack_buff", "on_attacked_buff", "on_friendly_death_damage", "on_damage_survived", "on_hand_added_buff", "deathrattle_summon_history", "start_combat_damage", "rally", "on_friendly_death", "on_friendly_summon", "start_combat_hand_stats", "deathrattle_hand_buff", "start_combat_stats", "deathrattle_shop_bonus"]

var _completed_attack_enabled: bool = false
var _damage_listener_native: Dictionary = {}
var _damage_listener_counts: Dictionary = {}
var _damage_listener_consumed: Dictionary = {}
var _damage_listener_batch_id: int = 0
var _damage_listener_receipt_id: int = 0
var _damage_listener_packet: Dictionary = {}
var _beetle_players: Array = []
var _beetle_cards: Dictionary = {}

var _boards: Array = [[], []]
var _cursor: Array[int] = [0, 0]
var _log: Array[Dictionary] = []
var _rng: RandomNumberGenerator = RandomNumberGenerator.new()
var _illidan_start_used: bool=false
var _seed: int = 0
var _serial: int = 0
var _steps: int = 0
var _attacks: int = 0
var _max_steps: int = 5000
var _error: String = ""
var _native_dr_start_used: bool=false
var _options: Dictionary = {}
var _priority_side: int = 0
var _pending_deaths: Array = []
var _nested_death_queues: Array = []
var _hand_counts: Array[int] = [0, 0]
var _salvager_host: RefCounted
var _kerrigan_zerg_host: RefCounted
var _protoss_host: RefCounted
var _octosari_host: RefCounted
var _silithid_host: RefCounted
var _shiny_layer_host: RefCounted
var _hand_start_copy_host: RefCounted
var _native_gem_host: RefCounted
var _beetle_observer_host: RefCounted
var _anchorman_host: RefCounted
var _thornspike_host: RefCounted
var _owned_combat_gem_host: RefCounted
var _gem_golem_host: RefCounted
var _first_attack_host: RefCounted
var _matador_host: RefCounted
var _stoneshell_host: RefCounted
var _dramaloc_host: RefCounted
var _rightmost_dual_host: RefCounted
var _seafloor_cast_host: RefCounted
var _combat_ring_cast_host: RefCounted
var _native_spell_attack_context: Dictionary={}
var _native_spell_start_context: Dictionary={}
var _whelp_summon_host: RefCounted
var _rightmost_battlecry_host: RefCounted
var _macaw_portrait_host: RefCounted
var _rylak_battlecry_host: RefCounted
var _adjacent_tide_host: RefCounted
var _hag_reborn_host: RefCounted
var _combat_golden_host: RefCounted
var _maximum_imp_host: RefCounted
var _owned_avenge_host: RefCounted
var _raptor_avenge_host: RefCounted
var _crowbar_host: RefCounted
var _owned_attack_host: RefCounted
var _native_enforcer_host: RefCounted
var _owned_mech_shield_host: RefCounted
var _owned_first_death_host: RefCounted
var _pirate_chest_host: RefCounted
var _dark_gift_combat_host: RefCounted
var _dark_gift_resource_host: RefCounted
var _eternal_portrait_host: RefCounted
var _fishy_sticker_host: RefCounted
var _rylak_portrait_host: RefCounted
var _impulsive_portrait_host: RefCounted
var _kaboom_portrait_host: RefCounted
var _rivendare_portrait_host: RefCounted
var _bronze_timepiece_host: RefCounted
var _wicked_tome_host: RefCounted
var _quilligraphy_host: RefCounted
var _native_rally_spread_host: RefCounted
var _native_rally_spread_context: Dictionary={}
var _native_start_grant_host: RefCounted
var _native_start_grant_context: Dictionary = {}
var _piggy_bank_host: RefCounted
var _yulon_sticker_host: RefCounted
var _karazhan_chess_host: RefCounted
var _scourge_staff_host: RefCounted
var _cloud_serpent_horn_host: RefCounted
var _fish_bait_host: RefCounted
var _radio_star_host: RefCounted
var _metal_dispenser_host: RefCounted
var _combat_magnetic_host: RefCounted
var _automaton_portrait_host: RefCounted
var _knitted_sunfin_host: RefCounted
var _start_choice_host: RefCounted
var _maximum_history_host: RefCounted
var _deity_host: RefCounted
var _death_history: Array = [[], []]
var _gnoll_aura_state: Dictionary = {}
var _cruise_controller = CruiseHost.new()
var _reborn_mechanism_host = RebornMechanismHost.new()
var _reborn_grant_host = RebornGrants.new()
var _summon_attempt_host = SummonAttempt.new()
var _summon_permanent_host = SummonPermanent.new()
var _sister_reborn_host = SisterHost.new()
var _combat_tribe_bonuses = CombatTribeBonuses.new()
var _deferred_hand_host = DeferredHand.new()
var _hand_summons = HandSummon.new()
var _combat_hand = CombatHand.new()
var _global_counter_host: RefCounted
var _keep_gains_host: RefCounted
var _kill_reward_host: RefCounted
var _loh_reward_host: RefCounted
var _milestone_hero_host: RefCounted
var _owned_observer_host: RefCounted
var _death_resource_host: RefCounted
var _summon_resource_host: RefCounted
var _plain_copy_host: RefCounted
var _brinescale_host: RefCounted
var _hand_murloc_gain_host: RefCounted
var _loc_prince_host: RefCounted
var _master_realities_host: RefCounted
var _mishmash_stat_host: RefCounted
var _battlecruiser_ultra_host: RefCounted
var _attack_gains_host: RefCounted
var _permanent_tribe_effects = PermanentTribeEffects.new()
var _owner_deathrattle_sets: Array = [1,1]
var _deathwing_native_targets: Array = [[], []]
var _deathwing_start_ticket: Dictionary = {}
var _deathwing_start_plan: Dictionary = {}
var _hero_damage_terminal: Dictionary = {}

var _owned_references_released: bool = false

func release_owned_references() -> void:
	_rider_host=null;_rider_authority={};_rider_removal_context={};_rider_dispatch_context={}
	_hyena_host=null
	_lobster_host=null;_lobster_authority={};_lobster_removal_context={};_lobster_dispatch_context={}
	_leviathan_host=null;_leviathan_authority={};_leviathan_insertion_context={}
	_kibble_host=null;_kibble_authority={};_kibble_declaration={}
	_hopebringer_host=null;_hopebringer_authority={};_hopebringer_removal_context={}
	# Terminal owner teardown, only after all result and receipt consumers.
	# Do not reuse this Combat instance after release. Results remain untouched.
	if _owned_references_released: return
	_owned_references_released = true
	# These child-to-parent backrefs otherwise outlive the Combat owner edge.
	if _sand_barnstormer_host != null:
		if _sand_barnstormer_host.demon_tokens != null:
			_sand_barnstormer_host.demon_tokens.hands = null
		if _sand_barnstormer_host.pirate_tokens != null:
			_sand_barnstormer_host.pirate_tokens.native_reborn = null
			_sand_barnstormer_host.pirate_tokens.leeroy = null
	# Explicit owned-object fields; no recursive traversal or aliased container mutation.
	_jailbird_juggernaut_host = null
	_apexis_magnetic_host = null
	_ritual_dagger_host = null
	_victim_specter_host = null
	_grim_freshener_host = null
	_energy_recycling_host = null
	_snicker_snacks_host = null
	_exquisite_conch_host = null
	_volatile_venom_host = null
	_alter_ego_host = null
	_stolen_gold_host = null
	_bomb_squad_host = null
	_theotar_parasol_host = null
	_evil_twin_host = null
	_anomalous_twins_host = null
	_tony_host = null
	_soul_fermenter_host = null
	_boom_controller_host = null
	_lantern_host = null
	_tumbleweed_host = null
	_devourer_souls_host = null
	_old_soul_host = null
	_bonerender_host = null
	_recurring_nightmare_host = null
	_enhanced_spawn_host = null
	_ditch_guardian_host = null
	_radiant_ember_host = null
	_piranha_host = null
	_protector_rally_host = null
	_assembler_magnetic_host = null
	_attachment_fixed_hand = null
	_beetle_blessing_host = null
	_sand_barnstormer_host = null
	_felblood_portrait_host = null
	_linked_undead_host = null
	_lockbox_host = null
	_overkill_host = null
	_fodder_refresh_host = null
	_refresh_owner_buff_host = null
	_damage_resource_host = null
	_bulk_resource_host = null
	_start_repeat_host = null
	_rng = null
	_salvager_host = null
	_kerrigan_zerg_host = null
	_protoss_host = null
	_octosari_host = null
	_silithid_host = null
	_shiny_layer_host = null
	_hand_start_copy_host = null
	_native_gem_host = null
	_beetle_observer_host = null
	_anchorman_host = null
	_thornspike_host = null
	_owned_combat_gem_host = null
	_gem_golem_host = null
	_first_attack_host = null
	_matador_host = null
	_stoneshell_host = null
	_dramaloc_host = null
	_rightmost_dual_host = null
	_seafloor_cast_host = null
	_combat_ring_cast_host = null
	_whelp_summon_host = null
	_rightmost_battlecry_host = null
	_macaw_portrait_host = null
	_rylak_battlecry_host = null
	_adjacent_tide_host = null
	_hag_reborn_host = null
	_combat_golden_host = null
	_maximum_imp_host = null
	_owned_avenge_host = null
	_raptor_avenge_host = null
	_crowbar_host = null
	_owned_attack_host = null
	_native_enforcer_host = null
	_owned_mech_shield_host = null
	_owned_first_death_host = null
	_pirate_chest_host = null
	_dark_gift_combat_host = null
	_dark_gift_resource_host = null
	_eternal_portrait_host = null
	_fishy_sticker_host = null
	_rylak_portrait_host = null
	_impulsive_portrait_host = null
	_kaboom_portrait_host = null
	_rivendare_portrait_host = null
	_bronze_timepiece_host = null
	_wicked_tome_host = null
	_quilligraphy_host = null
	_native_rally_spread_host = null
	_native_start_grant_host = null
	_piggy_bank_host = null
	_yulon_sticker_host = null
	_karazhan_chess_host = null
	_scourge_staff_host = null
	_cloud_serpent_horn_host = null
	_fish_bait_host = null
	_radio_star_host = null
	_metal_dispenser_host = null
	_combat_magnetic_host = null
	_automaton_portrait_host = null
	_knitted_sunfin_host = null
	_start_choice_host = null
	_maximum_history_host = null
	_deity_host = null
	_cruise_controller = null
	_reborn_mechanism_host = null
	_reborn_grant_host = null
	_summon_attempt_host = null
	_summon_permanent_host = null
	_sister_reborn_host = null
	_combat_tribe_bonuses = null
	_deferred_hand_host = null
	_hand_summons = null
	_combat_hand = null
	_global_counter_host = null
	_keep_gains_host = null
	_kill_reward_host = null
	_loh_reward_host = null
	_milestone_hero_host = null
	_owned_observer_host = null
	_death_resource_host = null
	_summon_resource_host = null
	_plain_copy_host = null
	_brinescale_host = null
	_hand_murloc_gain_host = null
	_loc_prince_host = null
	_master_realities_host = null
	_mishmash_stat_host = null
	_battlecruiser_ultra_host = null
	_attack_gains_host = null
	_permanent_tribe_effects = null

func _init() -> void:
	# Low-level combat helpers may be exercised without resolve; their neutral
	# context has no owned ledger and cannot activate a permanent source.
	_permanent_tribe_effects.initialize([], [], {})

func resolve(left: Array, right: Array, seed_value: int, options: Dictionary = {}) -> Dictionary:
	_rider_host=Rider.new();_rider_removal_context={};_rider_dispatch_context={}
	var rider_input_issue: String=_rider_host.bind_inputs(self,left,right,options)
	if not rider_input_issue.is_empty(): return {"error":rider_input_issue,"log":[]}
	_hyena_host=Hyena.new()
	_lobster_host=Lobster.new();_lobster_removal_context={};_lobster_dispatch_context={}
	var lobster_input_issue: String=_lobster_host.bind_inputs(self,left,right,options,seed_value)
	if not lobster_input_issue.is_empty():
		return {"winner":-1,"damage":0,"left":[],"right":[],"log":[],"seed":seed_value,"rounds":0,"error":lobster_input_issue,"left_hand":[],"right_hand":[],"left_hand_count":0,"right_hand_count":0,"left_hand_summon_locks":[],"right_hand_summon_locks":[]}
	_leviathan_host=Leviathan.new();_leviathan_insertion_context={}
	var leviathan_input_issue: String=_leviathan_host.bind_inputs(self,left,right,options,seed_value)
	if not leviathan_input_issue.is_empty():
		return {"winner":-1,"damage":0,"left":[],"right":[],"log":[],"seed":seed_value,"rounds":0,"error":leviathan_input_issue,"left_hand":[],"right_hand":[],"left_hand_count":0,"right_hand_count":0,"left_hand_summon_locks":[],"right_hand_summon_locks":[]}
	_kibble_host=Kibble.new()
	var kibble_input_issue: String=_kibble_host.bind_inputs(self,left,right,options,seed_value)
	if not kibble_input_issue.is_empty():
		return {"error":kibble_input_issue,"log":[]}
	_hopebringer_host=Hopebringer.new();_hopebringer_removal_context={}
	var hopebringer_input_issue: String=_hopebringer_host.bind_inputs(self,left,right,options,seed_value)
	if not hopebringer_input_issue.is_empty():
		return {"winner":-1,"damage":0,"left":[],"right":[],"log":[],"seed":seed_value,"rounds":0,"error":hopebringer_input_issue,"left_hand":[],"right_hand":[],"left_hand_count":0,"right_hand_count":0,"left_hand_summon_locks":[],"right_hand_summon_locks":[]}
	_jailbird_juggernaut_host=JailbirdJuggernaut.new()
	_evil_twin_host=EvilTwin.new()
	var evil_twin_input_issue: String=_evil_twin_host.bind_inputs(self,left,right,options)
	if not evil_twin_input_issue.is_empty():
		return {"winner":-1,"damage":0,"left":[],"right":[],"log":[],"seed":seed_value,"rounds":0,"error":evil_twin_input_issue,"left_hand":[],"right_hand":[],"left_hand_count":0,"right_hand_count":0,"left_hand_summon_locks":[],"right_hand_summon_locks":[]}
	_ritual_dagger_host=RitualDagger.new();_ritual_dagger_death_context={}
	var ritual_dagger_input_issue: String=_ritual_dagger_host.bind_inputs(self,left,right,options)
	if not ritual_dagger_input_issue.is_empty():
		return {"winner":-1,"damage":0,"left":[],"right":[],"log":[],"seed":seed_value,"rounds":0,"error":ritual_dagger_input_issue,"left_hand":[],"right_hand":[],"left_hand_count":0,"right_hand_count":0,"left_hand_summon_locks":[],"right_hand_summon_locks":[]}
	_victim_specter_host=VictimSpecter.new()
	var victim_specter_input_issue: String=_victim_specter_host.bind_inputs(self,left,right,options)
	if not victim_specter_input_issue.is_empty():
		return {"winner":-1,"damage":0,"left":[],"right":[],"log":[],"seed":seed_value,"rounds":0,"error":victim_specter_input_issue,"left_hand":[],"right_hand":[],"left_hand_count":0,"right_hand_count":0,"left_hand_summon_locks":[],"right_hand_summon_locks":[]}
	_energy_recycling_host=EnergyRecycling.new()
	var energy_input_issue: String=_energy_recycling_host.bind_inputs(self,left,right,options)
	if not energy_input_issue.is_empty(): return {"error":energy_input_issue,"log":[],"winner":-1,"damage":0}
	_grim_freshener_host=GrimFreshener.new()
	var grim_freshener_input_issue: String=_grim_freshener_host.bind_inputs(self,left,right,options)
	if not grim_freshener_input_issue.is_empty():
		return {"winner":-1,"damage":0,"left":[],"right":[],"log":[],"seed":seed_value,"rounds":0,"error":grim_freshener_input_issue,"left_hand":[],"right_hand":[],"left_hand_count":0,"right_hand_count":0,"left_hand_summon_locks":[],"right_hand_summon_locks":[]}
	_snicker_snacks_host=SnickerSnacks.new()
	var snicker_snacks_input_issue: String=_snicker_snacks_host.bind_inputs(self,left,right,options)
	if not snicker_snacks_input_issue.is_empty():
		return {"winner":-1,"damage":0,"left":[],"right":[],"log":[],"seed":seed_value,"rounds":0,"error":snicker_snacks_input_issue,"left_hand":[],"right_hand":[],"left_hand_count":0,"right_hand_count":0,"left_hand_summon_locks":[],"right_hand_summon_locks":[]}
	_exquisite_conch_host=ExquisiteConch.new()
	var exquisite_conch_input_issue: String=_exquisite_conch_host.bind_inputs(self,left,right,options)
	if not exquisite_conch_input_issue.is_empty():
		return {"winner":-1,"damage":0,"left":[],"right":[],"log":[],"seed":seed_value,"rounds":0,"error":exquisite_conch_input_issue,"left_hand":[],"right_hand":[],"left_hand_count":0,"right_hand_count":0,"left_hand_summon_locks":[],"right_hand_summon_locks":[]}
	_volatile_venom_host=VolatileVenom.new()
	var volatile_venom_input_issue: String=_volatile_venom_host.bind_inputs(self,left,right,options)
	if not volatile_venom_input_issue.is_empty():
		return {"winner":-1,"damage":0,"left":[],"right":[],"log":[],"seed":seed_value,"rounds":0,"error":volatile_venom_input_issue,"left_hand":[],"right_hand":[],"left_hand_count":0,"right_hand_count":0,"left_hand_summon_locks":[],"right_hand_summon_locks":[]}
	_alter_ego_host=AlterEgo.new()
	var alter_ego_input_issue: String=_alter_ego_host.bind_inputs(self,left,right,options)
	if not alter_ego_input_issue.is_empty():
		return {"winner":-1,"damage":0,"left":[],"right":[],"log":[],"seed":seed_value,"rounds":0,"error":alter_ego_input_issue,"left_hand":[],"right_hand":[],"left_hand_count":0,"right_hand_count":0,"left_hand_summon_locks":[],"right_hand_summon_locks":[]}
	_stolen_gold_host=StolenGold.new()
	var stolen_gold_input_issue: String=_stolen_gold_host.bind_inputs(self,left,right,options)
	if not stolen_gold_input_issue.is_empty():
		return {"winner":-1,"damage":0,"left":[],"right":[],"log":[],"seed":seed_value,"rounds":0,"error":stolen_gold_input_issue,"left_hand":[],"right_hand":[],"left_hand_count":0,"right_hand_count":0,"left_hand_summon_locks":[],"right_hand_summon_locks":[]}
	_bomb_squad_host=BombSquad.new()
	var bomb_squad_input_issue: String=_bomb_squad_host.bind_inputs(self,left,right,options)
	if not bomb_squad_input_issue.is_empty():
		return {"winner":-1,"damage":0,"left":[],"right":[],"log":[],"seed":seed_value,"rounds":0,"error":bomb_squad_input_issue,"left_hand":[],"right_hand":[],"left_hand_count":0,"right_hand_count":0,"left_hand_summon_locks":[],"right_hand_summon_locks":[]}
	_theotar_parasol_host=TheotarParasol.new()
	var theotar_parasol_input_issue: String=_theotar_parasol_host.bind_inputs(self,left,right,options)
	if not theotar_parasol_input_issue.is_empty():
		return {"winner":-1,"damage":0,"left":[],"right":[],"log":[],"seed":seed_value,"rounds":0,"error":theotar_parasol_input_issue,"left_hand":[],"right_hand":[],"left_hand_count":0,"right_hand_count":0,"left_hand_summon_locks":[],"right_hand_summon_locks":[]}
	_anomalous_twins_host=AnomalousTwins.new()
	var anomalous_twins_input_issue: String=_anomalous_twins_host.bind_inputs(self,left,right,options)
	if not anomalous_twins_input_issue.is_empty():
		return {"winner":-1,"damage":0,"left":[],"right":[],"log":[],"seed":seed_value,"rounds":0,"error":anomalous_twins_input_issue,"left_hand":[],"right_hand":[],"left_hand_count":0,"right_hand_count":0,"left_hand_summon_locks":[],"right_hand_summon_locks":[]}
	_tony_host=Tony.new()
	var tony_input_issue: String=_tony_host.bind_inputs(self,left,right,options)
	if not tony_input_issue.is_empty():
		return {"winner":-1,"damage":0,"left":[],"right":[],"log":[],"seed":seed_value,"rounds":0,"error":tony_input_issue,"left_hand":[],"right_hand":[],"left_hand_count":0,"right_hand_count":0,"left_hand_summon_locks":[],"right_hand_summon_locks":[]}
	_soul_fermenter_host=Fermenter.new()
	var soul_fermenter_input_issue: String=_soul_fermenter_host.bind_inputs(self,left,right,options)
	if not soul_fermenter_input_issue.is_empty():
		return {"winner":-1,"damage":0,"left":[],"right":[],"log":[],"seed":seed_value,"rounds":0,"error":soul_fermenter_input_issue,"left_hand":[],"right_hand":[],"left_hand_count":0,"right_hand_count":0,"left_hand_summon_locks":[],"right_hand_summon_locks":[]}
	_boom_controller_host=BoomController.new()
	var boom_controller_input_issue: String=_boom_controller_host.bind_inputs(self,left,right,options)
	if not boom_controller_input_issue.is_empty():
		return {"winner":-1,"damage":0,"left":[],"right":[],"log":[],"seed":seed_value,"rounds":0,"error":boom_controller_input_issue,"left_hand":[],"right_hand":[],"left_hand_count":0,"right_hand_count":0,"left_hand_summon_locks":[],"right_hand_summon_locks":[]}
	_lantern_host=Lantern.new()
	var lantern_input_issue: String=_lantern_host.bind_inputs(self,left,right,options)
	if not lantern_input_issue.is_empty():
		return {"winner":-1,"damage":0,"left":[],"right":[],"log":[],"seed":seed_value,"rounds":0,"error":lantern_input_issue,"left_hand":[],"right_hand":[],"left_hand_count":0,"right_hand_count":0,"left_hand_summon_locks":[],"right_hand_summon_locks":[]}
	var tumbleweed_input_issue: String=Tumbleweed.combat_input_error(self,left,right,options)
	if not tumbleweed_input_issue.is_empty():
		return {"winner":-1,"damage":0,"left":[],"right":[],"log":[],"seed":seed_value,"rounds":0,"error":tumbleweed_input_issue,"left_hand":[],"right_hand":[],"left_hand_count":0,"right_hand_count":0,"left_hand_summon_locks":[],"right_hand_summon_locks":[]}
	_devourer_souls_host=DevourerSouls.new()
	_old_soul_host=OldSoul.new()
	var old_soul_input_issue: String=_old_soul_host.bind_inputs(self,left,right,options)
	if not old_soul_input_issue.is_empty():
		return {"winner":-1,"damage":0,"left":[],"right":[],"log":[],"seed":seed_value,"rounds":0,"error":old_soul_input_issue,"left_hand":[],"right_hand":[],"left_hand_count":0,"right_hand_count":0,"left_hand_summon_locks":[],"right_hand_summon_locks":[]}
	var bonerender_input_issue: String=Bonerender.combat_input_error(self,left,right,options)
	if not bonerender_input_issue.is_empty():
		return {"winner":-1,"damage":0,"left":[],"right":[],"log":[],"seed":seed_value,"rounds":0,"error":bonerender_input_issue,"left_hand":[],"right_hand":[],"left_hand_count":0,"right_hand_count":0,"left_hand_summon_locks":[],"right_hand_summon_locks":[]}
	_bonerender_host=Bonerender.new()
	var valithria_input_issue: String=ValithriaEntry.combat_input_error(self,left,right,options)
	if not valithria_input_issue.is_empty():
		return {"winner":-1,"damage":0,"left":[],"right":[],"log":[],"seed":seed_value,"rounds":0,"error":valithria_input_issue,"left_hand":[],"right_hand":[],"left_hand_count":0,"right_hand_count":0,"left_hand_summon_locks":[],"right_hand_summon_locks":[]}
	_hero_damage_terminal={}
	_piranha_host=Piranha.new()
	# Reject the new closed domain before mutating even a reused combat host.
	var pen_domain_issue: String=WaterloggedPen.combat_domain(left,right,options)
	if not pen_domain_issue.is_empty():
		return {"winner":-1,"damage":0,"left":[],"right":[],"log":[],"seed":seed_value,"rounds":0,"error":pen_domain_issue,"left_hand":[],"right_hand":[],"left_hand_count":0,"right_hand_count":0,"left_hand_summon_locks":[],"right_hand_summon_locks":[]}
	var seaside_domain_issue: String=TimewarpSwirler.combat_domain(left,right,options)
	if seaside_domain_issue.is_empty(): seaside_domain_issue=Seaside.combat_domain(left,right,options)
	if not seaside_domain_issue.is_empty():
		return {"winner":-1,"damage":0,"left":[],"right":[],"log":[],"seed":seed_value,"rounds":0,"error":seaside_domain_issue,"left_hand":[],"right_hand":[],"left_hand_count":0,"right_hand_count":0,"left_hand_summon_locks":[],"right_hand_summon_locks":[]}
	var original_jelly_reborn_issue: String = OriginalJelly.domain_error(left,right,options)
	if not original_jelly_reborn_issue.is_empty():
		return {"damage_listener_ticket":"","beetle_players":[],AttackGainOrder.FIELD:options.get(AttackGainOrder.FIELD,""),"winner":-1,"damage":0,"left":[],"right":[],"log":[],"seed":seed_value,"rounds":0,"error":original_jelly_reborn_issue,"left_hand":[],"right_hand":[],"left_hand_count":0,"right_hand_count":0,"left_hand_summon_locks":[],"right_hand_summon_locks":[]}
	var jelly_reborn_issue: String = Jelly.domain_error(left,right,options)
	if not jelly_reborn_issue.is_empty():
		return {"damage_listener_ticket":"","beetle_players":[],AttackGainOrder.FIELD:options.get(AttackGainOrder.FIELD,""),"winner":-1,"damage":0,"left":[],"right":[],"log":[],"seed":seed_value,"rounds":0,"error":jelly_reborn_issue,"left_hand":[],"right_hand":[],"left_hand_count":0,"right_hand_count":0,"left_hand_summon_locks":[],"right_hand_summon_locks":[]}
	var sister_reborn_issue: String = Sister.domain_error(left,right,options)
	if not sister_reborn_issue.is_empty():
		return {"damage_listener_ticket":"","beetle_players":[],AttackGainOrder.FIELD:options.get(AttackGainOrder.FIELD,""),"winner":-1,"damage":0,"left":[],"right":[],"log":[],"seed":seed_value,"rounds":0,"error":sister_reborn_issue,"left_hand":[],"right_hand":[],"left_hand_count":0,"right_hand_count":0,"left_hand_summon_locks":[],"right_hand_summon_locks":[]}
	var gnoll_death_aura_issue: String = Gnoll.domain_error(left,right,options)
	if not gnoll_death_aura_issue.is_empty():
		return {"damage_listener_ticket":"","beetle_players":[],AttackGainOrder.FIELD:options.get(AttackGainOrder.FIELD,""),"winner":-1,"damage":0,"left":[],"right":[],"log":[],"seed":seed_value,"rounds":0,"error":gnoll_death_aura_issue,"left_hand":[],"right_hand":[],"left_hand_count":0,"right_hand_count":0,"left_hand_summon_locks":[],"right_hand_summon_locks":[]}
	var ghoul_death_issue: String = GhoulDeath.domain_error(left,right,options)
	if not ghoul_death_issue.is_empty():
		return {"damage_listener_ticket":"","beetle_players":[],AttackGainOrder.FIELD:options.get(AttackGainOrder.FIELD,""),"winner":-1,"damage":0,"left":[],"right":[],"log":[],"seed":seed_value,"rounds":0,"error":ghoul_death_issue,"left_hand":[],"right_hand":[],"left_hand_count":0,"right_hand_count":0,"left_hand_summon_locks":[],"right_hand_summon_locks":[]}
	var completed_attack_issue: String = CompletedAttack.domain_error(left,right,options)
	if not completed_attack_issue.is_empty():
		return {"damage_listener_ticket":"","beetle_players":[],AttackGainOrder.FIELD:options.get(AttackGainOrder.FIELD,""),"winner":-1,"damage":0,"left":[],"right":[],"log":[],"seed":seed_value,"rounds":0,"error":completed_attack_issue,"left_hand":[],"right_hand":[],"left_hand_count":0,"right_hand_count":0,"left_hand_summon_locks":[],"right_hand_summon_locks":[]}
	_completed_attack_enabled = false
	_damage_listener_native = {}
	_damage_listener_counts = {}
	_damage_listener_consumed = {}
	_damage_listener_batch_id = 0
	_damage_listener_receipt_id = 0
	_damage_listener_packet = {}
	_boards = [[], []]
	_beetle_players = []
	_beetle_cards = {}
	_deathwing_native_targets = [[], []]
	_deathwing_start_ticket = {}
	_deathwing_start_plan = {}
	_cursor = [0, 0]
	_native_dr_start_used=false
	_log = []
	_valithria_entry_seen={}
	_valithria_entry_context={}
	_seed = seed_value
	_rng.seed = seed_value
	_serial = 0
	_steps = 0
	_illidan_start_used=false
	_attacks = 0
	_error = ""
	_pending_deaths = []
	_nested_death_queues = []
	_death_history = [[], []]
	_shiny_layer_host=ShinyLayer.new()
	_hand_start_copy_host=HandStartCopy.new()
	_native_gem_host=NativeGem.new()
	_beetle_observer_host=BeetleObserver.new()
	_anchorman_host=Anchorman.new()
	_thornspike_host=Thornspike.new()
	_owned_combat_gem_host=OwnedCombatGems.new()
	_gem_golem_host=GemGolem.new()
	_first_attack_host=FirstAttack.new()
	_matador_host=Matador.new()
	_stoneshell_host=Stoneshell.new()
	_dramaloc_host=Dramaloc.new()
	_rightmost_dual_host=RightmostDual.new()
	_seafloor_cast_host=SeafloorCast.new()
	_combat_ring_cast_host=CombatRingCast.new()
	_native_spell_attack_context={}
	_native_spell_start_context={}
	_whelp_summon_host=WhelpSummon.new()
	_rightmost_battlecry_host=RightmostBattlecry.new()
	_macaw_portrait_host=MacawPortrait.new()
	_rylak_battlecry_host=RylakBattlecry.new()
	_adjacent_tide_host=AdjacentTide.new()
	_hag_reborn_host=HagReborn.new()
	_combat_golden_host=CombatGolden.new()
	_maximum_imp_host=MaximumImp.new()
	_owned_avenge_host=OwnedAvenge.new()
	_raptor_avenge_host=RaptorAvenge.new()
	_crowbar_host=Crowbar.new()
	_owned_attack_host=OwnedAttack.new()
	_native_enforcer_host=NativeEnforcer.new()
	_owned_mech_shield_host=OwnedMechShield.new()
	_owned_first_death_host=OwnedFirstDeath.new()
	_pirate_chest_host=PirateChest.new()
	_dark_gift_combat_host=DarkGiftCombat.new()
	_dark_gift_resource_host=DarkGiftResources.new()
	_eternal_portrait_host=EternalPortrait.new()
	_fishy_sticker_host=FishySticker.new()
	_rylak_portrait_host=RylakPortrait.new()
	_impulsive_portrait_host=ImpulsivePortrait.new()
	_kaboom_portrait_host=KaboomPortrait.new()
	_rivendare_portrait_host=RivendarePortrait.new()
	_bronze_timepiece_host=BronzeTimepiece.new()
	_felblood_portrait_host=FelbloodPortraitCombat.new()
	_ditch_guardian_host=DitchGuardian.new()
	_enhanced_spawn_host=EnhancedSpawn.new()
	_radiant_ember_host=RadiantEmber.new()
	_sand_barnstormer_host=SandBarnstormer.new()
	_wicked_tome_host=WickedTome.new()
	_quilligraphy_host=Quilligraphy.new()
	_native_rally_spread_host=NativeRallySpread.new()
	_native_rally_spread_context={}
	_recurring_nightmare_host=RecurringNightmare.new()
	_native_start_grant_host=NativeStartGrant.new()
	_native_start_grant_context={}
	_piggy_bank_host=PiggyBank.new()
	_yulon_sticker_host=YulonSticker.new()
	_karazhan_chess_host=KarazhanChess.new()
	_scourge_staff_host=ScourgeStaff.new()
	_cloud_serpent_horn_host=CloudSerpentHorn.new()
	_apexis_magnetic_host=Apexis.new()
	_fish_bait_host=FishBait.new()
	_fish_bait_host.initialize(self)
	_radio_star_host=RadioStar.new()
	_metal_dispenser_host=MetalDispenser.new()
	_combat_magnetic_host=CombatMagnetic.new()
	_automaton_portrait_host=AutomatonPortrait.new()
	_knitted_sunfin_host=KnittedSunfin.new()
	_start_choice_host=StartChoice.new()
	_maximum_history_host=MaximumHistory.new()
	_deity_host=DeityCombat.new()
	_beetle_blessing_host=BeetleBlessing.new()
	_kerrigan_zerg_host=KerriganZerg.new()
	_protoss_host=Protoss.new()
	_octosari_host=Octosari.new()
	_silithid_host=Silithid.new()
	_salvager_host=Salvager.new()
	_gnoll_aura_state = {}
	_priority_side = 0
	_hand_counts = [0, 0]
	_cruise_controller = CruiseHost.new()
	_reborn_mechanism_host = RebornMechanismHost.new()
	_reborn_grant_host = RebornGrants.new()
	_summon_attempt_host = SummonAttempt.new()
	_summon_permanent_host = SummonPermanent.new()
	_sister_reborn_host = SisterHost.new()
	_combat_tribe_bonuses = CombatTribeBonuses.new()
	_combat_tribe_bonuses.initialize()
	_deferred_hand_host = DeferredHand.new()
	_linked_undead_host=LinkedUndead.new()
	_hand_summons = HandSummon.new()
	_hand_summons.initialize()
	_combat_hand = CombatHand.new()
	_global_counter_host = GlobalCounterHost.new()
	_keep_gains_host = CombatKeep.new()
	_overkill_host=Overkill.new()
	_overkill_turn_side=-1
	_kill_reward_host = KillRewards.new()
	_loh_reward_host = LohRewards.new()
	_milestone_hero_host = MilestoneHeroes.new()
	_owned_observer_host=OwnedObserverResources.new()
	_death_resource_host=DeathResources.new()
	_summon_resource_host=SummonResources.new()
	_plain_copy_host=CombatPlain.new()
	_brinescale_host=Brinescale.new()
	_hand_murloc_gain_host=HandMurlocGain.new()
	_master_realities_host=MasterRealities.new()
	_loc_prince_host=LocPrince.new()
	_mishmash_stat_host=MishmashStatHost.new()
	_battlecruiser_ultra_host=BattlecruiserUltra.new()
	_attack_gains_host = AttackGains.new()
	_permanent_tribe_effects = PermanentTribeEffects.new()
	_options = {}
	_fodder_refresh_host=FodderRefresh.new()
	_fodder_refresh_host.initialize(options.get("delayed_gold_context",{}),bool(options.get(BulkResourceHost.KEY,{}).get("ghost",false)))
	_refresh_owner_buff_host = RefreshOwnerBuffs.new()
	_refresh_owner_buff_host.initialize(options.get("delayed_gold_context",{}),bool(options.get(BulkResourceHost.KEY,{}).get("ghost",false)))
	_bulk_resource_host = BulkResourceHost.new()
	_protector_rally_host=ProtectorRallyHost.new()
	_assembler_magnetic_host=AssemblerMagneticHost.new()
	_attachment_fixed_hand=AttachmentFixedHand.new()
	_damage_resource_host = DamageResource.new()
	var resource_context_issue: String = _bulk_resource_host.initialize(options.get(BulkResourceHost.KEY,{}))
	if not resource_context_issue.is_empty():
		_fail(resource_context_issue)
		return _result(-1)
	_completed_attack_enabled = CompletedAttack.tree_claimed(left+right)
	var deathwing_issue: String = DeathwingCombat.context_error(left, right, options)
	if not deathwing_issue.is_empty():
		_fail(deathwing_issue)
		return _result(-1)
	var received_context_issue: String = DamageListenerHost.context_error(left,right,options)
	if not received_context_issue.is_empty():
		_fail(received_context_issue)
		return _result(-1)
	var hired_context_issue: String = HiredRitualist.combat_error(left,right,options)
	if not hired_context_issue.is_empty():
		_fail(hired_context_issue)
		return _result(-1)
	var bristleback_context_issue: String = Bristleback.combat_error(left,right,options)
	if not bristleback_context_issue.is_empty():
		_fail(bristleback_context_issue)
		return _result(-1)
	var corpse_sale_issue: String = CorpseSale.Sources.combat_error(left,right,options)
	if not corpse_sale_issue.is_empty():
		_fail(corpse_sale_issue)
		return _result(-1)
	var khadgar_context_issue: String=Khadgar.combat_error(left,right,options)
	if not khadgar_context_issue.is_empty(): _fail(khadgar_context_issue);return _result(-1)
	var summon_condition_issue: String=SummonPermanent.context_error(left,right,options)
	if not summon_condition_issue.is_empty():
		_fail(summon_condition_issue)
		return _result(-1)
	var summon_capacity_context_issue: String=SummonAttempt.context_error(options)
	if not summon_capacity_context_issue.is_empty():
		_fail(summon_capacity_context_issue)
		return _result(-1)
	var reborn_mechanism_issue: String=RebornMechanisms.context_error(options)
	if not reborn_mechanism_issue.is_empty():
		_fail(reborn_mechanism_issue)
		return _result(-1)
	var last_spell_context_issue: String=LastSpell.combat_error(left,right,options)
	if not last_spell_context_issue.is_empty(): _fail(last_spell_context_issue);return _result(-1)
	_options = options.duplicate(true)
	var incubation_context_issue: String = _incubation_combat_context_error(left, right)
	if not incubation_context_issue.is_empty(): _fail(incubation_context_issue); return _result(-1)
	var recurring_nightmare_context_issue: String=_recurring_nightmare_host.initialize(self,left,right)
	if not recurring_nightmare_context_issue.is_empty(): _fail(recurring_nightmare_context_issue);return _result(-1)
	if options.has(DitchGuardian.AUTHORITY): _options[DitchGuardian.AUTHORITY]=options[DitchGuardian.AUTHORITY]
	var ditch_guardian_context_issue: String=_ditch_guardian_host.initialize(self,left,right)
	if not ditch_guardian_context_issue.is_empty(): _fail(ditch_guardian_context_issue);return _result(-1)
	if options.has(EnhancedSpawn.AUTHORITY): _options[EnhancedSpawn.AUTHORITY]=options[EnhancedSpawn.AUTHORITY]
	var enhanced_spawn_context_issue: String=_enhanced_spawn_host.initialize(self,left,right)
	if not enhanced_spawn_context_issue.is_empty(): _fail(enhanced_spawn_context_issue);return _result(-1)
	var radiant_ember_context_issue: String=_radiant_ember_host.initialize(self,left,right)
	if not radiant_ember_context_issue.is_empty(): _fail(radiant_ember_context_issue);return _result(-1)
	if options.has(NativeRallySpread.Recruit.CONTEXT): _options[NativeRallySpread.Recruit.CONTEXT]=options[NativeRallySpread.Recruit.CONTEXT]
	var deity_context_issue: String=_deity_host.initialize(self,left,right)
	if not deity_context_issue.is_empty(): _fail(deity_context_issue);return _result(-1)
	var deity_hand_combat_issue: String=DeityHandGain.combat_start_error(self,left,right)
	if not deity_hand_combat_issue.is_empty(): _fail(deity_hand_combat_issue);return _result(-1)
	_lockbox_host=LockboxHost.new()
	var lockbox_context_issue: String=_lockbox_host.initialize(self)
	if not lockbox_context_issue.is_empty(): _fail(lockbox_context_issue);return _result(-1)
	var hand_start_copy_context_issue: String=_hand_start_copy_host.initialize(_options)
	if not hand_start_copy_context_issue.is_empty(): _fail(hand_start_copy_context_issue);return _result(-1)
	var native_gem_context_issue: String=_native_gem_host.initialize(self,left,right)
	if not native_gem_context_issue.is_empty(): _fail(native_gem_context_issue);return _result(-1)
	var summon_resource_context_issue: String=_summon_resource_host.initialize(self)
	if not summon_resource_context_issue.is_empty(): _fail(summon_resource_context_issue);return _result(-1)
	var thornspike_context_issue: String=_thornspike_host.initialize(self)
	if not thornspike_context_issue.is_empty(): _fail(thornspike_context_issue);return _result(-1)
	var owned_combat_gem_context_issue: String=_owned_combat_gem_host.initialize(self)
	if not owned_combat_gem_context_issue.is_empty(): _fail(owned_combat_gem_context_issue);return _result(-1)
	var gem_golem_context_issue: String=_gem_golem_host.initialize(self,left,right)
	if not gem_golem_context_issue.is_empty(): _fail(gem_golem_context_issue);return _result(-1)
	var raptor_context_issue: String=_raptor_avenge_host.initialize(self)
	if not raptor_context_issue.is_empty(): _fail(raptor_context_issue);return _result(-1)
	var sand_barnstormer_context_issue: String=_sand_barnstormer_host.initialize(self)
	if not sand_barnstormer_context_issue.is_empty(): _fail(sand_barnstormer_context_issue);return _result(-1)
	var felblood_context_issue: String=_felblood_portrait_host.initialize(self,right)
	if not felblood_context_issue.is_empty(): _fail(felblood_context_issue);return _result(-1)
	var wicked_tome_context_issue: String=_wicked_tome_host.initialize(self)
	if not wicked_tome_context_issue.is_empty(): _fail(wicked_tome_context_issue);return _result(-1)
	var quilligraphy_context_issue: String=_quilligraphy_host.initialize(self)
	if not quilligraphy_context_issue.is_empty(): _fail(quilligraphy_context_issue);return _result(-1)
	var owned_avenge_context_issue: String=_owned_avenge_host.initialize(self)
	if not owned_avenge_context_issue.is_empty(): _fail(owned_avenge_context_issue);return _result(-1)
	var owned_attack_context_issue: String=_owned_attack_host.initialize(self)
	if not owned_attack_context_issue.is_empty(): _fail(owned_attack_context_issue);return _result(-1)
	var owned_mech_shield_context_issue: String=_owned_mech_shield_host.initialize(self)
	if not owned_mech_shield_context_issue.is_empty(): _fail(owned_mech_shield_context_issue);return _result(-1)
	var owned_first_death_context_issue: String=_owned_first_death_host.initialize(self)
	if not owned_first_death_context_issue.is_empty(): _fail(owned_first_death_context_issue);return _result(-1)
	var pirate_chest_context_issue: String=_pirate_chest_host.initialize(self)
	if not pirate_chest_context_issue.is_empty(): _fail(pirate_chest_context_issue);return _result(-1)
	var dark_gift_resource_context_issue: String=_dark_gift_resource_host.initialize(self,left,right)
	if not dark_gift_resource_context_issue.is_empty(): _fail(dark_gift_resource_context_issue);return _result(-1)
	var dark_gift_context_issue: String=_dark_gift_combat_host.initialize(self,left,right)
	if not dark_gift_context_issue.is_empty(): _fail(dark_gift_context_issue);return _result(-1)
	var eternal_portrait_context_issue: String=_eternal_portrait_host.initialize(self)
	if not eternal_portrait_context_issue.is_empty(): _fail(eternal_portrait_context_issue);return _result(-1)
	var fishy_sticker_context_issue: String=_fishy_sticker_host.initialize(self)
	if not fishy_sticker_context_issue.is_empty(): _fail(fishy_sticker_context_issue);return _result(-1)
	var rylak_portrait_context_issue: String=_rylak_portrait_host.initialize(self)
	if not rylak_portrait_context_issue.is_empty(): _fail(rylak_portrait_context_issue);return _result(-1)
	var impulsive_portrait_context_issue: String=_impulsive_portrait_host.initialize(self)
	if not impulsive_portrait_context_issue.is_empty(): _fail(impulsive_portrait_context_issue);return _result(-1)
	var kaboom_portrait_context_issue: String=_kaboom_portrait_host.initialize(self)
	if not kaboom_portrait_context_issue.is_empty(): _fail(kaboom_portrait_context_issue);return _result(-1)
	var rivendare_portrait_context_issue: String=_rivendare_portrait_host.initialize(self)
	if not rivendare_portrait_context_issue.is_empty(): _fail(rivendare_portrait_context_issue);return _result(-1)
	var bronze_timepiece_context_issue: String=_bronze_timepiece_host.initialize(self)
	if not bronze_timepiece_context_issue.is_empty(): _fail(bronze_timepiece_context_issue);return _result(-1)
	var piggy_bank_context_issue: String=_piggy_bank_host.initialize(self)
	if not piggy_bank_context_issue.is_empty(): _fail(piggy_bank_context_issue);return _result(-1)
	var yulon_sticker_context_issue: String=_yulon_sticker_host.initialize(self)
	if not yulon_sticker_context_issue.is_empty(): _fail(yulon_sticker_context_issue);return _result(-1)
	var karazhan_chess_context_issue: String=_karazhan_chess_host.initialize(self)
	if not karazhan_chess_context_issue.is_empty(): _fail(karazhan_chess_context_issue);return _result(-1)
	var scourge_staff_context_issue: String=_scourge_staff_host.initialize(self,left,right)
	if not scourge_staff_context_issue.is_empty(): _fail(scourge_staff_context_issue);return _result(-1)
	var cloud_serpent_horn_context_issue: String=_cloud_serpent_horn_host.initialize(self)
	if not cloud_serpent_horn_context_issue.is_empty(): _fail(cloud_serpent_horn_context_issue);return _result(-1)
	var radio_context_issue: String=_radio_star_host.initialize(self)
	if not radio_context_issue.is_empty(): _fail(radio_context_issue);return _result(-1)
	var metal_context_issue: String=_metal_dispenser_host.initialize(self)
	if not metal_context_issue.is_empty(): _fail(metal_context_issue);return _result(-1)
	var apexis_context_issue: String=_apexis_magnetic_host.initialize(self,left,right)
	if not apexis_context_issue.is_empty(): _fail(apexis_context_issue);return _result(-1)
	var combat_magnetic_context_issue: String=_combat_magnetic_host.initialize(self)
	if not combat_magnetic_context_issue.is_empty(): _fail(combat_magnetic_context_issue);return _result(-1)
	var automaton_portrait_context_issue: String=_automaton_portrait_host.initialize(self)
	if not automaton_portrait_context_issue.is_empty(): _fail(automaton_portrait_context_issue);return _result(-1)
	var observer_context_issue: String=_owned_observer_host.initialize(self,right)
	if not observer_context_issue.is_empty(): _fail(observer_context_issue);return _result(-1)
	var death_resource_context_issue: String=_death_resource_host.initialize(self)
	if not death_resource_context_issue.is_empty(): _fail(death_resource_context_issue);return _result(-1)
	var milestone_context_issue: String=_milestone_hero_host.initialize(self)
	if not milestone_context_issue.is_empty(): _fail(milestone_context_issue);return _result(-1)
	var loh_context_issue: String=_loh_reward_host.initialize(self)
	if not loh_context_issue.is_empty(): _fail(loh_context_issue);return _result(-1)
	var kill_context_issue: String=_kill_reward_host.initialize(self)
	if not kill_context_issue.is_empty():
		_fail(kill_context_issue);return _result(-1)
	var knight_context_issue: String=Knights.context_error(left,right,options)
	if not knight_context_issue.is_empty():
		_fail(knight_context_issue)
		return _result(-1)
	var global_context_issue: String = GlobalCards.combat_context_error(left,right,options)
	if not global_context_issue.is_empty():
		_fail(global_context_issue)
		return _result(-1)
	var global_host_issue: String=_global_counter_host.initialize(self,_options)
	if not global_host_issue.is_empty():
		_fail(global_host_issue);return _result(-1)
	var cruise_context_issue: String = Cruise.combat_error(left,right,options)
	if not cruise_context_issue.is_empty():
		_fail(cruise_context_issue)
		return _result(-1)
	var megasaur_context_issue: String=MegaGrants.combat_error(left,right,options)
	if not megasaur_context_issue.is_empty(): _fail(megasaur_context_issue);return _result(-1)
	var saurolisk_context_issue: String = Saurolisk.combat_error(left,right,options)
	if not saurolisk_context_issue.is_empty():
		_fail(saurolisk_context_issue)
		return _result(-1)
	var beetle_issue: String = _beetle_context_error(left,right,options)
	if not beetle_issue.is_empty():
		_fail(beetle_issue)
		return _result(-1)
	if options.has("delayed_gold_context"):
		var delayed_context: Variant = options.delayed_gold_context
		if not delayed_context is Dictionary or delayed_context.size() != 3 or not DelayedGold.integer(delayed_context.get("round"),1) or not delayed_context.get("transaction_id") is String or delayed_context.transaction_id.is_empty() or not delayed_context.get("owners") is Array or delayed_context.owners.size() != 2:
			_fail("Malformed delayed gold combat context")
			return _result(-1)
		for owner in delayed_context.owners:
			if not DelayedGold.integer(owner,-1):
				_fail("Malformed delayed gold combat owner")
				return _result(-1)
	# The native listener must have a payable next round and a real owner before
	# any combat state is prepared, including sources currently in either hand.
	if options.has("delayed_gold_context"):
		for prime_side in range(2):
			var prime_inputs: Array = (left if prime_side == 0 else right).duplicate()
			var hand_key: String = "left_hand" if prime_side == 0 else "right_hand"
			if options.get(hand_key) is Array: prime_inputs.append_array(options[hand_key])
			for unit in prime_inputs:
				if not unit is Dictionary or not DelayedGold.PrimeMate.claimed(unit): continue
				if not DelayedGold.integer(options.delayed_gold_context.round,1,DelayedGold.MAX_INTEGER-1) or not DelayedGold.integer(options.delayed_gold_context.owners[prime_side]):
					_fail("Prime Mate requires an actual owner and safe next-round context before resolution")
					return _result(-1)
	if not options.has("delayed_gold_context"):
		var economy_inputs: Array = left+right
		for key in ["left_hand","right_hand"]:
			if options.has(key) and options[key] is Array: economy_inputs.append_array(options[key])
		for unit in economy_inputs:
			if unit is Dictionary and (CombatEconomy.Sources.claimed(unit) or DelayedGold.PrimeMate.claimed(unit)):
				_fail("Combat economy requires explicit owner and transaction context before resolution")
				return _result(-1)
	var echoes_argus_context_issue: String=ArgusSources.combat_context_error(options)
	if not echoes_argus_context_issue.is_empty():
		_fail(echoes_argus_context_issue)
		return _result(-1)
	_owner_deathrattle_sets = [1,1]
	for owner_side in range(2):
		var prefix: String = "left" if owner_side == 0 else "right"
		if not options.has(prefix+"_turn_repeat_context"): continue
		var owner_result: Dictionary = TurnRepeat.combat_set(options[prefix+"_turn_repeat_context"],options.get(prefix+"_turn_repeat_owner"),options.get("turn_repeat_round"),"deathrattle",options.get(prefix+"_is_ghost",false))
		if not owner_result.ok:
			_fail(str(owner_result.error))
			return _result(-1)
		_owner_deathrattle_sets[owner_side] = owner_result.amount
	_max_steps = int(options.get("max_iterations", 5000))
	if _max_steps < 1:
		_fail("max_iterations must be positive")
		return _result(-1)
	var friendly_order_issue: String = FriendlyAttackRoom.combat_error(left,right,options)
	if not friendly_order_issue.is_empty():
		_fail(friendly_order_issue)
		return _result(-1)
	var aura_context_issue: String = BoardAuraRuntime.combat_context_error(left,right,options)
	if not aura_context_issue.is_empty():
		_fail(aura_context_issue)
		return _result(-1)
	var tribe_context_error: String = CombatTribeBonuses.context_error(left, right, options)
	if not tribe_context_error.is_empty():
		_fail(tribe_context_error)
		return _result(-1)
	var native_dr_context_issue: String=NativeDRTriggers.context_error(options)
	if not native_dr_context_issue.is_empty():
		_fail(native_dr_context_issue);return _result(-1)
	var next_combat_spell_issue: String=NextCombatSpells.context_error(options)
	if not next_combat_spell_issue.is_empty():
		_fail(next_combat_spell_issue)
		return _result(-1)
	var start_context_error: String = start_combat_context_error(left, right, options)
	if not start_context_error.is_empty():
		_fail(start_context_error)
		return _result(-1)
	var double_stat_issue: String = DoubleStat.combat_error(left,right,options)
	if not double_stat_issue.is_empty():
		_fail(double_stat_issue)
		return _result(-1)
	var context_error: String = hand_context_error(left, right, options)
	if not context_error.is_empty():
		_fail(context_error)
		return _result(-1)
	var summon_hand_issue: String = _hand_summon_context_error(left,right,options)
	if not summon_hand_issue.is_empty():
		_fail(summon_hand_issue)
		return _result(-1)
	var illidan_start_context_issue: String=IllidanStart.context_error(options)
	if not illidan_start_context_issue.is_empty():
		_fail(illidan_start_context_issue);return _result(-1)
	var hero_issue: String = combat_hero_context_error(left, right, options)
	if not hero_issue.is_empty():
		_fail(hero_issue)
		return _result(-1)
	_combat_hand.initialize(left, right, options)
	var old_soul_hand_issue: String=_old_soul_host.initialize(self)
	if not old_soul_hand_issue.is_empty(): _fail(old_soul_hand_issue);return _result(-1)
	if not _macaw_portrait_host.initialize(self): return _result(-1)
	var knitted_sunfin_context_issue: String=_knitted_sunfin_host.initialize(self)
	if not knitted_sunfin_context_issue.is_empty(): _fail(knitted_sunfin_context_issue);return _result(-1)
	var crowbar_context_issue: String=_crowbar_host.initialize(self)
	if not crowbar_context_issue.is_empty(): _fail(crowbar_context_issue);return _result(-1)
	for global_hand_side in range(2):
		for global_hand_unit in _combat_hand.hands[global_hand_side]:
			var global_hand_issue: String=GlobalCards.combat_project(self,global_hand_side,global_hand_unit,"hand")
			if not global_hand_issue.is_empty():
				_fail(global_hand_issue)
				return _result(-1)
	var permanent_issue: String = _permanent_tribe_effects.initialize(left, right, options)
	if not permanent_issue.is_empty():
		_fail(permanent_issue)
		return _result(-1)
	for hand_side in range(2):
		_hand_counts[hand_side] = _combat_hand.hands[hand_side].size() if _combat_hand.available[hand_side] else int(options.get("left_hand_count" if hand_side == 0 else "right_hand_count", 0))
	var inputs: Array = [left, right]
	for side in range(2):
		if _hand_counts[side] < 0 or _hand_counts[side] > 10:
			_fail("Combat hand count must be between 0 and 10")
			return _result(-1)
		if inputs[side].size() > BOARD_LIMIT:
			_fail("Board %d exceeds the 7-minion limit" % side)
			return _result(-1)
		for raw in inputs[side]:
			if not raw is Dictionary:
				_fail("Each minion must be a Dictionary")
				return _result(-1)
			var validation: String = _validate_unit(raw, 0)
			if not validation.is_empty():
				_fail(validation)
				return _result(-1)
			if _needs_hand_context(raw) and not _combat_hand.available[side] and not options.has("left_hand_count" if side == 0 else "right_hand_count"):
				_fail("on_hand_added_buff requires explicit left_hand_count/right_hand_count for its side")
				return _result(-1)
			var prepared: Dictionary = _prepare_unit(raw, side)
			var incubation_prepared_issue: String = _incubation_receive_prepared(prepared)
			if not incubation_prepared_issue.is_empty(): _fail(incubation_prepared_issue); return _result(-1)
			var global_prepared_issue: String = GlobalCards.combat_project(self,side,prepared)
			if not global_prepared_issue.is_empty():
				_fail(global_prepared_issue)
				return _result(-1)
			incubation_prepared_issue = _incubation_receive_prepared(prepared)
			if not incubation_prepared_issue.is_empty(): _fail(incubation_prepared_issue); return _result(-1)
			_boards[side].append(prepared)
			var volatile_venom_entry_issue: String=_volatile_venom_host.entered(self,side,prepared,false)
			if not volatile_venom_entry_issue.is_empty(): _fail(volatile_venom_entry_issue);return _result(-1)
			if DeathwingCombat.active(_options):
				_deathwing_native_targets[side].append({"uid": prepared.uid, "card_id": prepared.card_id, "combat_id": prepared._combat_id, "origin": "recruit_board"})
	var tony_initialized_issue: String=_tony_host.initialize(self)
	if not tony_initialized_issue.is_empty(): _fail(tony_initialized_issue);return _result(-1)
	var spread_recruit_import_issue: String=_native_rally_spread_host.bind_recruit(self,inputs)
	if not spread_recruit_import_issue.is_empty(): _fail(spread_recruit_import_issue);return _result(-1)
	var sand_pirate_initial_issue: String=_sand_barnstormer_host.pirate_tokens.bind_initial(self)
	if not sand_pirate_initial_issue.is_empty(): _fail(sand_pirate_initial_issue);return _result(-1)
	var sand_demon_initial_issue: String=_sand_barnstormer_host.demon_tokens.bind_initial(self)
	if not sand_demon_initial_issue.is_empty(): _fail(sand_demon_initial_issue);return _result(-1)
	var sand_spirit_initial_issue: String=_sand_barnstormer_host.spirit.bind_initial(self)
	if not sand_spirit_initial_issue.is_empty(): _fail(sand_spirit_initial_issue);return _result(-1)
	var dark_gift_trait_binding_issue: String=_dark_gift_combat_host.bind_traits(self)
	if not dark_gift_trait_binding_issue.is_empty(): _fail(dark_gift_trait_binding_issue);return _result(-1)
	var dark_gift_resource_binding_issue: String=_dark_gift_resource_host.bind_prepared(self)
	if not dark_gift_resource_binding_issue.is_empty(): _fail(dark_gift_resource_binding_issue);return _result(-1)
	var native_summon_context_issue: String=_summon_resource_host.initialize_native(self)
	if not native_summon_context_issue.is_empty(): _fail(native_summon_context_issue);return _result(-1)
	var plain_copy_context_issue: String=_plain_copy_host.initialize(self,left,right)
	if not plain_copy_context_issue.is_empty(): _fail(plain_copy_context_issue);return _result(-1)
	var received_join_issue: String = DamageListenerHost.initialize_combat(self)
	if not received_join_issue.is_empty():
		_fail(received_join_issue)
		return _result(-1)
	if not _beetle_players.is_empty():
		for beetle_side in range(2):
			if _beetle_players[beetle_side].is_empty(): continue
			_beetle_players[beetle_side].board = _boards[beetle_side]
	# Both complete hands and prepared boards exist before the owned layer is
	# materialized. Start events and every later reader see exactly one layer.
	if not _permanent_tribe_effects.synchronize_combat(self):
		return _result(-1)
	if not BoardAuraRuntime.sync_combat(self,"initial_board_aura",false): return _result(-1)
	var piranha_context_issue: String=_piranha_host.initialize(self)
	if not piranha_context_issue.is_empty(): _fail(piranha_context_issue);return _result(-1)
	var kerrigan_context_issue: String=_kerrigan_zerg_host.initialize(self)
	if not kerrigan_context_issue.is_empty(): _fail(kerrigan_context_issue);return _result(-1)
	var protoss_context_issue: String=_protoss_host.initialize(self)
	if not protoss_context_issue.is_empty(): _fail(protoss_context_issue);return _result(-1)
	var rider_context_issue: String=_rider_host.initialize(self)
	if not rider_context_issue.is_empty(): _fail(rider_context_issue);return _result(-1)
	var lobster_context_issue: String=_lobster_host.initialize(self)
	if not lobster_context_issue.is_empty(): _fail(lobster_context_issue);return _result(-1)
	var hyena_context_issue: String=_hyena_host.initialize(self)
	if not hyena_context_issue.is_empty(): _fail(hyena_context_issue);return _result(-1)
	var leviathan_context_issue: String=_leviathan_host.initialize(self)
	if not leviathan_context_issue.is_empty(): _fail(leviathan_context_issue);return _result(-1)
	var hopebringer_context_issue: String=_hopebringer_host.initialize(self)
	if not hopebringer_context_issue.is_empty(): _fail(hopebringer_context_issue);return _result(-1)
	var octosari_context_issue: String=_octosari_host.initialize(self)
	if not octosari_context_issue.is_empty(): _fail(octosari_context_issue);return _result(-1)
	var beetle_blessing_context_issue: String=_beetle_blessing_host.initialize(self)
	if not beetle_blessing_context_issue.is_empty(): _fail(beetle_blessing_context_issue);return _result(-1)
	_start_repeat_host=StartCombatRepeats.new()
	var start_repeat_initialize_issue: String=_start_repeat_host.initialize(self)
	if not start_repeat_initialize_issue.is_empty(): _fail(start_repeat_initialize_issue);return _result(-1)
	_emit("combat_start", {"round_up_plain_contract":_options.get("round_up_plain_contract",""),"seed": _seed, "rules": "sandbox-1", "sort_formation_contract":"actual_combat_start_before_start_effects_v1", "left": _public_board(0), "right": _public_board(1), "left_hand_count": _hand_counts[0], "right_hand_count": _hand_counts[1],"left_hand_summon_locks":_hand_summons.snapshot_locks(0),"right_hand_summon_locks":_hand_summons.snapshot_locks(1)})
	if not _native_gem_host.begin(self): return _result(-1)
	if not _wicked_tome_host.begin(self): return _result(-1)
	if not _quilligraphy_host.begin(self): return _result(-1)
	_raptor_avenge_host.start(self)
	# Explicit local category: queued consumed owner spells precede hero/minion starts.
	if not NextCombatSpells.start(self): return _result(-1)
	if not _beetle_blessing_host.start(self): return _result(-1)
	if not ThresholdDamage.combat_start(self): return _result(-1)
	if not _apply_deathwing_start():
		return _result(-1)
	if _boards[0].is_empty() and _boards[1].is_empty() and not _beetle_blessing_host.has_pending() and not HandStartCopy.has_sources(_combat_hand.hands) and not _plain_copy_host._yshaarj_host.has_pending() and not _plain_copy_host._ship_bottle_host.has_pending() and not _fishy_sticker_host.has_pending() and not _plain_copy_host._ozumat_host.has_pending() and not _plain_copy_host._turn_seven_copy_host.has_pending() and not _plain_copy_host._tamsin_host.has_start() and not _plain_copy_host._teron_host.has_start() and not _plain_copy_host._brukan_host.has_start() and not _automaton_portrait_host.has_pending() and not _knitted_sunfin_host.has_pending():
		return _finished_result()
	var side: int = 0
	if _boards[0].size() == _boards[1].size():
		side = _random_index(2, "first_attacker", [0, 1])
	elif _boards[1].size() > _boards[0].size():
		side = 1
	_emit("first_attacker", {"side": side, "left_count": _boards[0].size(), "right_count": _boards[1].size()})
	var anomalous_twins_start_issue: String=_anomalous_twins_host.start_pair(self,side)
	if not anomalous_twins_start_issue.is_empty(): _fail(anomalous_twins_start_issue);return _result(-1)
	_stolen_gold_start_context={"first_side":side,"used":false}
	var stolen_gold_start_issue: String=_stolen_gold_host.start_pair(self,side)
	_stolen_gold_start_context={}
	if not stolen_gold_start_issue.is_empty(): _fail(stolen_gold_start_issue);return _result(-1)
	var evil_twin_start_issue: String=_evil_twin_host.start_pair(self,side)
	if not evil_twin_start_issue.is_empty(): _fail(evil_twin_start_issue);return _result(-1)
	var soul_fermenter_start_issue: String=_soul_fermenter_host.start_pair(self,side)
	if not soul_fermenter_start_issue.is_empty(): _fail(soul_fermenter_start_issue);return _result(-1)
	if not _dark_gift_combat_host.start_pair(self,side): return _result(-1)
	if not _dark_gift_combat_host.start_deathrattles(self,side): return _result(-1)
	if not _eternal_portrait_host.start_pair(self,side): return _result(-1)
	if not _rivendare_portrait_host.start_pair(self,side): return _result(-1)
	if not _bronze_timepiece_host.start_pair(self,side): return _result(-1)
	if not _yulon_sticker_host.start_pair(self,side): return _result(-1)
	if not _karazhan_chess_host.start_pair(self,side): return _result(-1)
	if not _automaton_portrait_host.start_pair(self,side): return _result(-1)
	if not _knitted_sunfin_host.start_pair(self,side): return _result(-1)
	if not _combat_magnetic_host.start_pair(self,side): return _result(-1)
	if not _piggy_bank_host.start_pair(self,side): return _result(-1)
	if not _hand_start_copy_host.start_pair(self,side): return _result(-1)
	# Heroes in this closed family do not change board counts; their keywords
	# precede minion Start of Combat without introducing another RNG draw.
	if not CombatHero.apply_start_pair(self, _options.get("left_combat_hero",{}), _options.get("right_combat_hero",{})):
		return _result(-1)
	for native_hero_side in [side,1-side]:
		if not Giantfin.start_pair(self,side,native_hero_side): return _result(-1)
		if not Nefarian.start_pair(self,side,native_hero_side): return _result(-1)
	if not PutricideOld.start_pair(self,side): return _result(-1)
	if not Wagtoggle.start_pair(self,side): return _result(-1)
	# Explicit local Illidan category: after existing Hero keywords, before owned Gems.
	if not IllidanStart.start_pair(self,side): return _result(-1)
	if not _plain_copy_host._yshaarj_host.start_pair(self,side): return _result(-1)
	if not _plain_copy_host._ship_bottle_host.start_pair(self,side): return _result(-1)
	if not _fishy_sticker_host.start_pair(self,side): return _result(-1)
	if not _plain_copy_host._ozumat_host.start_pair(self,side): return _result(-1)
	if not _plain_copy_host._turn_seven_copy_host.start_pair(self,side): return _result(-1)
	if not _plain_copy_host._tamsin_host.start_pair(self,side): return _result(-1)
	if not _plain_copy_host._teron_host.start_pair(self,side): return _result(-1)
	if not _plain_copy_host._brukan_host.start_pair(self,side): return _result(-1)
	if not _owned_combat_gem_host.start_pair(self,side): return _result(-1)
	if not NativeDRTriggers.start_combat(self,side): return _result(-1)
	if not _rylak_portrait_host.start_pair(self,side): return _result(-1)
	_apply_start_combat(side)
	if not _piranha_host.start(self,side): return _result(-1)
	if _boards[0].is_empty() or _boards[1].is_empty():
		return _finished_result()
	while not _boards[0].is_empty() and not _boards[1].is_empty() and _error.is_empty():
		var stealth_issue: String=_stealth_boundary_error()
		if not stealth_issue.is_empty(): _fail(stealth_issue);return _result(-1)
		if not _has_attacker(0) and not _has_attacker(1):
			_emit("stalemate", {"reason": "Neither board has a living positive-attack minion"})
			return _result(-1)
		if not _has_attacker(side):
			_emit("skip_side", {"side": side, "reason": "no_positive_attack"})
			side = 1 - side
			continue
		var attacker: Dictionary = _next_attacker(side)
		var attacker_id: int = int(attacker["_combat_id"])
		var strikes: int = 4 if _has_keyword(attacker, "windfury") else 1
		for strike in range(strikes):
			if strike>=2 and not _has_live_mega_aura(side) and not OverkillSources.intrinsic_four(_find_unit(side,attacker_id)): break
			if not _error.is_empty() or _boards[1 - side].is_empty():
				break
			var current: Dictionary = _find_unit(side, attacker_id)
			if current.is_empty() or int(current["health"]) <= 0 or int(current["attack"]) <= 0:
				break
			if not _tick("attack"):
				break
			_priority_side = side
			current["_attacking"] = true
			_overkill_turn_side=side
			_attack(side, current, strike + 1)
			_resolve_deaths()
			current["_attacking"] = false
			_overkill_turn_side=-1
		side = 1 - side
	if not _error.is_empty():
		return _result(-1)
	return _finished_result()

func claim_hero_damage_terminal(result: Dictionary) -> Dictionary:
	if _hero_damage_terminal.is_empty() or _hero_damage_terminal.get("stage")!="issued": return {"ok":false,"error":"hero_terminal_missing_or_reclaimed_combat_receipt"}
	var issue: String=hero_damage_terminal_error(_hero_damage_terminal,result)
	if not issue.is_empty(): return {"ok":false,"error":issue}
	_hero_damage_terminal.stage="claimed"
	return {"ok":true,"error":"","ticket":_hero_damage_terminal}

func hero_damage_terminal_error(ticket: Dictionary,result: Dictionary) -> String:
	if not is_same(ticket,_hero_damage_terminal) or not is_same(ticket.get("result"),result) or ticket.get("stage") not in ["issued","claimed"] or not _error.is_empty(): return "hero_terminal_foreign_stale_or_failed_combat"
	for key in ticket.core:
		if not UnderlingSources.same(ticket.core[key],result.get(key)): return "hero_terminal_actual_result_changed"
	if result.get("seed")!=_seed or result.get("winner") not in [-1,0,1] or not result.get("error","").is_empty(): return "hero_terminal_bad_completed_result"
	var winner: int=int(result.winner)
	if winner==-1:
		if result.damage!=0: return "hero_terminal_tie_with_damage"
	else:
		if not _boards[1-winner].is_empty() or _boards[winner].is_empty(): return "hero_terminal_loser_not_empty"
		var damage: int=int(_options.get("left_tier" if winner==0 else "right_tier",1))
		for unit in _boards[winner]:
			if unit.get("health",0)<=0 or unit.get("_pending_destroy",false): return "hero_terminal_unresolved_death"
			damage+=int(unit.get("tier",1))
		if damage!=result.damage: return "hero_terminal_native_damage_changed"
	if not UnderlingSources.same(result.left,_public_board(0)) or not UnderlingSources.same(result.right,_public_board(1)): return "hero_terminal_actual_board_changed"
	return ""

func finish_hero_damage_terminal(ticket: Dictionary,result: Dictionary) -> String:
	var issue: String=hero_damage_terminal_error(ticket,result)
	if not issue.is_empty(): return issue
	if ticket.stage!="claimed": return "hero_terminal_not_claimed"
	ticket.stage="completed"
	return ""

func get_owned_attack_host() -> RefCounted:
	return _owned_attack_host

func get_pirate_chest_host() -> RefCounted:
	return _pirate_chest_host

func get_keep_gains_host() -> RefCounted:
	return _keep_gains_host

func get_kill_reward_host() -> RefCounted:
	return _kill_reward_host

func get_loh_reward_host() -> RefCounted:
	return _loh_reward_host

func get_plain_copy_host() -> RefCounted:
	return _plain_copy_host

func get_owned_observer_host() -> RefCounted:
	return _owned_observer_host

func get_death_resource_host() -> RefCounted:
	return _death_resource_host

func get_summon_resource_host() -> RefCounted:
	return _summon_resource_host

func get_milestone_hero_host() -> RefCounted:
	return _milestone_hero_host

func get_global_card_host() -> RefCounted:
	return _global_counter_host

func get_fodder_refresh_ticket() -> Dictionary:
	return _fodder_refresh_host.ticket()

func get_refresh_owner_buff_ticket() -> Dictionary:
	return _refresh_owner_buff_host.ticket()

func get_native_gem_host() -> RefCounted: return _native_gem_host

func get_random_resource_ticket() -> Dictionary:
	return _bulk_resource_host.ticket()

func get_deathwing_start_ticket() -> Dictionary:
	# Only this instance's actual pre-start deployment can supply the ticket.
	# Result JSON is deliberately not a source of trusted expected state.
	return _deathwing_start_ticket.duplicate(true)

func get_deathwing_start_plan() -> Dictionary:
	return _deathwing_start_plan.duplicate(true)

func _apply_deathwing_start() -> bool:
	if not DeathwingCombat.active(_options): return true
	var programs: Array=[{},{}]
	var source_repeats: Array=[1,1]
	for side in range(2):
		if _options.deathwing_start_context.contexts[side].is_empty(): continue
		programs[side]=_start_repeat_host.owner_program(self,side,DeathwingCombat.Deathwing.HERO,"hero:"+str(_options.deathwing_start_context.owners[side]))
		if not programs[side].get("ok",false): _fail(str(programs[side].get("error","deathwing_missing_start_program")));return false
		source_repeats[side]=int(programs[side].count)
	_deathwing_start_ticket = DeathwingCombat.ticket(_options.deathwing_start_context, _boards, _deathwing_native_targets,source_repeats)
	var staged: Dictionary = DeathwingCombat.staged_pair(_deathwing_start_ticket, _boards)
	if not str(staged.error).is_empty():
		_fail(str(staged.error))
		return false
	# Reserve the whole batch before any new effect, stat write or budget write.
	# No-target batches still produce a trusted, exactly-once host receipt.
	var cost: int = 0 if staged.changes.is_empty() else staged.steps.size()
	if _steps > _max_steps - cost:
		_fail("Combat iteration limit exceeded before Deathwing start batch; no winner declared")
		return false
	var targets: Array = []
	for change in staged.changes:
		var unit: Dictionary = _find_unit(change.side, change.combat_id)
		if unit.is_empty() or unit.uid != change.uid or unit.is_read_only():
			_fail("Deathwing native target changed before publishing the whole pair")
			return false
		targets.append(unit)
	var expeditioner_pair: Dictionary=Expeditioner.prepare_deathwing(self,staged,targets)
	if not expeditioner_pair.ok: _fail(str(expeditioner_pair.error));return false
	if int(expeditioner_pair.hand_cost)>_max_steps-cost or _steps>_max_steps-cost-int(expeditioner_pair.hand_cost):
		_fail("expeditioner_deathwing_complete_pair_iteration_preflight");return false
	# All source ordinals were preflighted before the paired transaction writes.
	# Publish each complete +2 contribution under its own real owner capability.
	_steps += cost
	_deathwing_start_plan = staged.plan.duplicate(true)
	for step_index in range(staged.steps.size()):
		var step: Dictionary=staged.steps[step_index]
		var program: Dictionary=programs[int(step.side)]
		var ordinal_claim: Dictionary=_start_repeat_host.claim_owner(self,program,int(step.ordinal))
		if not ordinal_claim.get("ok",false): _fail(str(ordinal_claim.get("error","deathwing_missing_start_ordinal")));return false
		for index in range(step.changes.size()):
			var change: Dictionary=step.changes[index]
			var unit: Dictionary=targets[index]
			var expeditioner_grant: Dictionary=Expeditioner.before_deathwing_grant(self,expeditioner_pair,step_index,index,unit)
			if not expeditioner_grant.ok: _fail(str(expeditioner_grant.error));return false
			unit.attack=change.attack
			if change.has_ordinary: unit[BoardAura.ORDINARY_ATTACK_KEY]=change.ordinary
			else: unit.erase(BoardAura.ORDINARY_ATTACK_KEY)
			var expeditioner_grant_issue: String=Expeditioner.commit_deathwing_grant(self,expeditioner_pair,unit,expeditioner_grant)
			if not expeditioner_grant_issue.is_empty(): _fail(expeditioner_grant_issue);return false
		for event in step.events:
			_emit("persistent_buff",event)
			if not _error.is_empty(): return false
		var ordinal_finish_issue: String=_start_repeat_host.finish_owner(self,program,int(step.ordinal))
		if not ordinal_finish_issue.is_empty(): _fail(ordinal_finish_issue);return false
	var expeditioner_receipt_issue: String=Expeditioner.publish_deathwing_receipts(self,expeditioner_pair)
	if not expeditioner_receipt_issue.is_empty(): _fail(expeditioner_receipt_issue);return false
	# A single absolute projection per aggregate target; the exact +2 source
	# contributions above are the only persistent events, including two heroes.
	for index in range(staged.changes.size()):
		var change: Dictionary = staged.changes[index]
		var unit: Dictionary = targets[index]
		var source: Dictionary = _deathwing_start_plan.sources[0]
		_emit("stat_set", {"source": source.source, "source_side": source.source_side, "source_owner": source.source_owner,
			"side": change.side, "recipient_owner": change.owner, "target": unit.uid, "combat_id": change.combat_id,
			"transaction_id": _deathwing_start_plan.transaction_id, "reason": DeathwingCombat.FAMILY,
			"attack": unit.attack, "health": unit.health, "max_health": unit.max_health})
		if not _error.is_empty(): return false
	return true

func _validate_unit(unit: Dictionary, depth: int, is_base_unit: bool = false, source_templates: Dictionary = {}) -> String:
	var darkcrest_eot_unit_issue: String=DarkcrestSources.eot_combat_unit_error(unit,is_base_unit)
	if not darkcrest_eot_unit_issue.is_empty(): return darkcrest_eot_unit_issue
	if not TimewarpSwirler.unit_error(unit).is_empty(): return TimewarpSwirler.unit_error(unit)
	var timewarp_scout_issue: String=TimewarpScout.unit_error(unit)
	if not timewarp_scout_issue.is_empty(): return timewarp_scout_issue
	var timewarp_red_whelp_issue: String=TimewarpRedWhelp.unit_error(unit)
	if not timewarp_red_whelp_issue.is_empty(): return timewarp_red_whelp_issue
	var spark_snapper_unit_issue: String=SparkSnapper.unit_error(unit)
	if not spark_snapper_unit_issue.is_empty(): return spark_snapper_unit_issue
	var timewarp_molten_unit_issue: String=TimewarpMolten.unit_error(unit)
	if not timewarp_molten_unit_issue.is_empty(): return timewarp_molten_unit_issue
	var timewarp_murky_unit_issue: String=TimewarpMurky.unit_error(unit)
	if not timewarp_murky_unit_issue.is_empty(): return timewarp_murky_unit_issue
	var timewarp_painter_unit_issue: String=TimewarpPainter.unit_error(unit)
	if not timewarp_painter_unit_issue.is_empty(): return timewarp_painter_unit_issue
	var air_baller_issue: String=AirBaller.unit_error(unit)
	if not air_baller_issue.is_empty(): return air_baller_issue
	var snow_baller_issue: String=SnowBaller.unit_error(unit)
	if not snow_baller_issue.is_empty(): return snow_baller_issue
	var fire_baller_issue: String=FireBaller.unit_error(unit)
	if not fire_baller_issue.is_empty(): return fire_baller_issue
	var hooktusk_issue: String=Hooktusk.unit_error(unit)
	if not hooktusk_issue.is_empty(): return hooktusk_issue
	var ultraviolet_issue: String=Ultraviolet.unit_error(unit)
	if not ultraviolet_issue.is_empty(): return ultraviolet_issue
	var rodeo_issue: String=TimewarpRodeo.unit_error(unit)
	if not rodeo_issue.is_empty(): return rodeo_issue
	var chimera_issue: String=TimewarpChimera.unit_error(unit)
	if not chimera_issue.is_empty(): return chimera_issue
	var mythrax_issue: String=TimewarpMythrax.unit_error(unit)
	if not mythrax_issue.is_empty(): return mythrax_issue
	var amalgam_issue: String=TimewarpAmalgam.unit_error(unit)
	if not amalgam_issue.is_empty(): return amalgam_issue
	var electron_issue: String=TimewarpElectron.unit_error(unit)
	if not electron_issue.is_empty(): return electron_issue
	var theotar_issue: String=TimewarpTheotar.unit_error(unit)
	if not theotar_issue.is_empty(): return theotar_issue
	var apexis_unit_issue: String=Apexis.Sources.unit_error(unit)
	if not apexis_unit_issue.is_empty(): return apexis_unit_issue
	var nosy_unit_issue: String=NosySources.unit_error(unit)
	if not nosy_unit_issue.is_empty(): return nosy_unit_issue
	if unit.has(IncubationMutationSources.MARK):
		var incubation_unit_issue: String = IncubationMutationSources.unit_error(unit)
		if not incubation_unit_issue.is_empty(): return incubation_unit_issue
	var tumbleweed_unit_issue: String=Tumbleweed.Sources.unit_error(unit)
	if not tumbleweed_unit_issue.is_empty(): return tumbleweed_unit_issue
	var imperial_issue: String=ImperialSources.unit_error(unit)
	if not imperial_issue.is_empty(): return imperial_issue
	var lava_issue: String=LavaSources.unit_error(unit)
	if not lava_issue.is_empty(): return lava_issue
	var bloodbinder_issue: String=BloodbinderSources.unit_error(unit)
	if not bloodbinder_issue.is_empty(): return bloodbinder_issue
	var amalgadon_issue: String=Amalgadon.complete_error(unit)
	if not amalgadon_issue.is_empty(): return amalgadon_issue
	if Amalgadon.marked(unit) and "reborn" in unit.get("keywords",[]): return "amalgadon_acquired_reborn_lifetime_partial"
	var rickety_issue: String=RicketySources.unit_error(unit)
	if not rickety_issue.is_empty(): return rickety_issue
	if unit.get("card_id")==GoldenHammerSources.SPELL:
		var golden_hammer_child_issue: String=GoldenHammerSources.spell_error(unit)
		if not golden_hammer_child_issue.is_empty(): return golden_hammer_child_issue
	if unit.get("card_id")==KidnapSackSources.SPELL:
		var kidnap_sack_child_issue: String=KidnapSackSources.spell_error(unit)
		if not kidnap_sack_child_issue.is_empty(): return kidnap_sack_child_issue
	var greta_issue: String=GretaSources.unit_error(unit)
	if not greta_issue.is_empty(): return greta_issue
	var tony_issue: String=Tony.Sources.unit_error(unit)
	if not tony_issue.is_empty(): return tony_issue
	var old_soul_issue: String=OldSoulSources.unit_error(unit)
	if not old_soul_issue.is_empty(): return old_soul_issue
	var boogie_issue: String=BoogieSources.unit_error(unit)
	if not boogie_issue.is_empty(): return boogie_issue
	if BoogieSources.claimed(unit) and "reborn" in unit.get("keywords",[]): return "boogie_reborn_progress_inheritance_partial"
	var balinda_issue: String=BalindaSources.unit_error(unit)
	if not balinda_issue.is_empty(): return balinda_issue
	if RecurringNightmare.Sources.contains_acquired(unit): return "recurring_nightmare_imported_or_copied_acquisition_partial"
	var recurring_nightmare_identity_issue: String=RecurringNightmare.Sources.unit_error(unit)
	if not recurring_nightmare_identity_issue.is_empty(): return recurring_nightmare_identity_issue
	var ditch_guardian_identity_issue: String=DitchGuardian.Sources.unit_error(unit)
	if not ditch_guardian_identity_issue.is_empty(): return ditch_guardian_identity_issue
	var enhanced_spawn_identity_issue: String=EnhancedSpawn.Sources.unit_error(unit)
	if not enhanced_spawn_identity_issue.is_empty(): return enhanced_spawn_identity_issue
	var valithria_entry_identity_issue: String=ValithriaEntry.Sources.unit_error(unit)
	if not valithria_entry_identity_issue.is_empty(): return valithria_entry_identity_issue
	var radiant_ember_identity_issue: String=RadiantEmber.Sources.unit_error(unit)
	if not radiant_ember_identity_issue.is_empty(): return radiant_ember_identity_issue
	var seaside_identity_issue: String=Seaside.Sources.unit_error(unit)
	if not seaside_identity_issue.is_empty(): return seaside_identity_issue
	var slither_unit_issue: String=CombatKeep.SlitherCombat.Grants.unit_error(unit)
	if not slither_unit_issue.is_empty(): return slither_unit_issue
	var megasaur_source_issue: String=MegaGrants.Sources.unit_error(unit)
	if not megasaur_source_issue.is_empty(): return megasaur_source_issue
	var loc_identity_issue: String=LocPrince.Sources.unit_error(unit)
	if not loc_identity_issue.is_empty(): return loc_identity_issue
	var hand_murloc_issue: String=HandMurlocGain.Sources.unit_error(unit)
	if not hand_murloc_issue.is_empty(): return hand_murloc_issue
	var piranha_issue: String=Piranha.Sources.unit_error(unit)
	if not piranha_issue.is_empty(): return piranha_issue
	var cthun_issue: String=MasterRealities.CthunGrants.unit_error(unit)
	if cthun_issue.is_empty(): cthun_issue=MasterRealities.CthunGrants.combat_error(unit)
	if not cthun_issue.is_empty(): return cthun_issue
	var titanic_issue: String=MasterRealities.Titanic.unit_error(unit)
	if not titanic_issue.is_empty(): return titanic_issue
	var ragescale_issue: String=MasterRealities.Ragescale.unit_error(unit)
	if not ragescale_issue.is_empty(): return ragescale_issue
	var surprise_issue: String=SurpriseSources.unit_error(unit)
	if not surprise_issue.is_empty(): return surprise_issue
	var stormbringer_issue: String=MasterRealities.Storm.unit_error(unit)
	if not stormbringer_issue.is_empty(): return stormbringer_issue
	var master_realities_issue: String=MasterRealities.Sources.unit_error(unit)
	if not master_realities_issue.is_empty(): return master_realities_issue
	var brinescale_issue: String=Brinescale.Sources.unit_error(unit)
	if not brinescale_issue.is_empty(): return brinescale_issue
	var expeditioner_issue: String=Expeditioner.Sources.unit_error(unit)
	if not expeditioner_issue.is_empty(): return expeditioner_issue
	var kerrigan_unit_issue: String=KerriganZerg.Sources.unit_error(unit)
	if not kerrigan_unit_issue.is_empty(): return kerrigan_unit_issue
	var mishmash_issue: String=MishmashStatHost.Sources.unit_error(unit)
	if not mishmash_issue.is_empty(): return mishmash_issue
	if BattlecruiserBallisticsSources.marked(unit):
		var ballistics_issue: String=BattlecruiserBallisticsSources.unit_error(unit,source_templates if not source_templates.is_empty() else _options.get("hand_card_templates",{}))
		if not ballistics_issue.is_empty(): return ballistics_issue
	if BattlecruiserMissileSources.claimed(unit):
		var missile_issue: String=BattlecruiserMissileSources.unit_error(unit,source_templates if not source_templates.is_empty() else _options.get("hand_card_templates",{}))
		if not missile_issue.is_empty(): return missile_issue
	if BattlecruiserConstructionSources.claimed(unit):
		var construction_issue: String=BattlecruiserConstructionSources.unit_error(unit,source_templates if not source_templates.is_empty() else _options.get("hand_card_templates",{}))
		if not construction_issue.is_empty(): return construction_issue
	if BattlecruiserUltraSources.claimed(unit):
		var ultra_issue: String=BattlecruiserUltraSources.unit_error(unit,source_templates if not source_templates.is_empty() else _options.get("hand_card_templates",{}))
		if not ultra_issue.is_empty(): return ultra_issue
	if BattlecruiserCaduceusSources.marked(unit):
		var caduceus_issue: String=BattlecruiserCaduceusSources.unit_error(unit,source_templates if not source_templates.is_empty() else _options.get("hand_card_templates",{}))
		if not caduceus_issue.is_empty(): return caduceus_issue
	if BattlecruiserYamatoSources.marked(unit):
		var yamato_issue: String=BattlecruiserYamatoSources.unit_error(unit,source_templates if not source_templates.is_empty() else _options.get("hand_card_templates",{}))
		if not yamato_issue.is_empty(): return yamato_issue
	if BattlecruiserBunkerSources.marked(unit):
		var bunker_issue: String=BattlecruiserBunkerSources.unit_error(unit,source_templates if not source_templates.is_empty() else _options.get("hand_card_templates",{}))
		if not bunker_issue.is_empty(): return bunker_issue
	if BotanistSources.claimed(unit):
		var botanist_issue: String=BotanistSources.base_error(unit) if is_base_unit else (BotanistSources.source_error(unit) if unit.has("id") and not unit.has("card_id") else BotanistSources.unit_error(unit))
		if not botanist_issue.is_empty(): return botanist_issue
	var overkill_issue: String=OverkillSources.unit_error(unit)
	if not overkill_issue.is_empty(): return overkill_issue
	var inventomatic_issue: String=InventomaticSources.unit_error(unit,source_templates if not source_templates.is_empty() else _options.get("hand_card_templates",{}))
	if not inventomatic_issue.is_empty(): return inventomatic_issue
	var maelstrom_issue: String=MaelstromSources.unit_error(unit)
	if not maelstrom_issue.is_empty(): return maelstrom_issue
	var mannoroth_issue: String=MannorothSources.unit_error(unit)
	if not mannoroth_issue.is_empty(): return mannoroth_issue
	var putricide_issue: String=PutricideOld.unit_error(unit)
	if not putricide_issue.is_empty(): return putricide_issue
	var counterattacker_issue: String=Counterattacker.Sources.unit_error(unit)
	if not counterattacker_issue.is_empty(): return counterattacker_issue
	var bait_unit_issue: String=FishBait.Sources.unit_error(unit)
	if not bait_unit_issue.is_empty(): return bait_unit_issue
	if unit.has("card_id") and FishBait.Sources.enabled_bait(unit):
		bait_unit_issue=FishBait.Sources.stat_history_error(unit)
		if not bait_unit_issue.is_empty(): return bait_unit_issue
	var radio_unit_issue: String=RadioStar.Sources.unit_error(unit)
	if not radio_unit_issue.is_empty(): return radio_unit_issue
	var metal_unit_issue: String=MetalDispenser.Sources.unit_error(unit)
	if not metal_unit_issue.is_empty(): return metal_unit_issue
	if unit.has(MetalDispenser.Sources.KEY):
		if is_base_unit or _metal_dispenser_host==null: return "metal_dispenser_unbound_base_attachment"
		metal_unit_issue=_metal_dispenser_host.source_error(unit)
		if not metal_unit_issue.is_empty(): return metal_unit_issue
	var clunker_unit_issue: String=ClunkerAttachments.unit_error(unit,source_templates if not source_templates.is_empty() else _options.get("hand_card_templates",{}),is_base_unit)
	if not clunker_unit_issue.is_empty(): return clunker_unit_issue
	var aureate_unit_issue: String=AureateSources.admission_error(unit,depth,is_base_unit)
	if not aureate_unit_issue.is_empty(): return aureate_unit_issue
	var dark_gift_unit_issue: String=DarkGiftSources.unit_error(unit,is_base_unit)
	if not dark_gift_unit_issue.is_empty(): return dark_gift_unit_issue
	if DarkGiftSources.marked(unit) and "reborn" in unit.get("keywords",[]): return "dark_gift_reborn_inheritance_partial"
	var drakkari_reborn_unit_issue: String=DrakkariRebornSources.unit_error(unit,is_base_unit)
	if not drakkari_reborn_unit_issue.is_empty(): return drakkari_reborn_unit_issue
	var magnetic_golden_unit_issue: String=MagneticGoldenSources.unit_error(unit,is_base_unit)
	if not magnetic_golden_unit_issue.is_empty(): return magnetic_golden_unit_issue
	var electron_magnetic_unit_issue: String=CombatMagnetic.Electron.unit_error(unit,is_base_unit)
	if not electron_magnetic_unit_issue.is_empty(): return electron_magnetic_unit_issue
	var satellite_magnetic_unit_issue: String=CombatMagnetic.Satellite.unit_error(unit,is_base_unit)
	if not satellite_magnetic_unit_issue.is_empty(): return satellite_magnetic_unit_issue
	if CombatMagnetic.Sources.marked(unit):
		if is_base_unit: return "combat_magnetic_native_base_contains_attachment"
		var combat_magnetic_unit_issue: String="combat_magnetic_missing_actual_host" if _combat_magnetic_host==null else _combat_magnetic_host.source_error(unit)
		if not combat_magnetic_unit_issue.is_empty(): return combat_magnetic_unit_issue
	var auto_assembler_unit_issue: String=AutoAssemblerSources.unit_error(unit,source_templates if not source_templates.is_empty() else _options.get("hand_card_templates",{}),is_base_unit)
	if not auto_assembler_unit_issue.is_empty(): return auto_assembler_unit_issue
	var paid_shop_unit_issue: String=PaidShopBonusSources.unit_error(unit)
	if not paid_shop_unit_issue.is_empty(): return paid_shop_unit_issue
	var rat_buddy_unit_issue: String=RatBuddyRefreshSources.unit_error(unit)
	if not rat_buddy_unit_issue.is_empty(): return rat_buddy_unit_issue
	var lowest_plain_unit_issue: String=LowestOpponentPlainSources.unit_error(unit)
	if not lowest_plain_unit_issue.is_empty(): return lowest_plain_unit_issue
	var magnetic_multiply_unit_issue: String=MagneticMultiplySources.unit_error(unit,source_templates if not source_templates.is_empty() else _options.get("hand_card_templates",{}))
	if not magnetic_multiply_unit_issue.is_empty(): return magnetic_multiply_unit_issue
	var galewing_unit_issue: String=GalewingSources.unit_error(unit)
	if not galewing_unit_issue.is_empty(): return galewing_unit_issue
	var battlecry_cost_unit_issue: String=BattlecryCostSources.unit_error(unit)
	if not battlecry_cost_unit_issue.is_empty(): return battlecry_cost_unit_issue
	var purchase_stat_unit_issue: String=PurchaseStatSources.unit_error(unit)
	if not purchase_stat_unit_issue.is_empty(): return purchase_stat_unit_issue
	var purchase_quota_unit_issue: String=PurchaseQuotaSources.unit_error(unit)
	if not purchase_quota_unit_issue.is_empty(): return purchase_quota_unit_issue
	var lockbox_unit_issue: String=LockboxHost.Sources.unit_error(unit)
	if not lockbox_unit_issue.is_empty(): return lockbox_unit_issue
	var native_hand_unit_issue: String=HandAcquisition.Sources.unit_error(unit)
	if not native_hand_unit_issue.is_empty(): return native_hand_unit_issue
	var discard_gem_unit_issue: String=DiscardGemCopySources.unit_error(unit)
	if not discard_gem_unit_issue.is_empty(): return discard_gem_unit_issue
	var zesty_unit_issue: String=ZestySources.unit_error(unit)
	if not zesty_unit_issue.is_empty(): return zesty_unit_issue
	var escapee_unit_issue: String=EscapeeSources.unit_error(unit)
	if not escapee_unit_issue.is_empty(): return escapee_unit_issue
	var health_buy_unit_issue: String=HealthBuySources.unit_error(unit)
	if not health_buy_unit_issue.is_empty(): return health_buy_unit_issue
	var pilgrimp_unit_issue: String=PilgrimpSources.unit_error(unit)
	if not pilgrimp_unit_issue.is_empty(): return pilgrimp_unit_issue
	var bazaar_unit_issue: String=BazaarSources.unit_error(unit)
	if not bazaar_unit_issue.is_empty(): return bazaar_unit_issue
	var watfin_unit_issue: String=WatfinSources.unit_error(unit)
	if not watfin_unit_issue.is_empty(): return watfin_unit_issue
	var contender_power_unit_issue: String=ContenderSources.unit_error(unit)
	if not contender_power_unit_issue.is_empty(): return contender_power_unit_issue
	var aquarrior_unit_issue: String=AquarriorSources.unit_error(unit)
	if not aquarrior_unit_issue.is_empty(): return aquarrior_unit_issue
	var nexus_lord_unit_issue: String=NexusLordSources.unit_error(unit)
	if not nexus_lord_unit_issue.is_empty(): return nexus_lord_unit_issue
	var thelwater_unit_issue: String=ThelwaterSources.unit_error(unit)
	if not thelwater_unit_issue.is_empty(): return thelwater_unit_issue
	var shadow_warden_unit_issue: String=ShadowWardenSources.unit_error(unit)
	if not shadow_warden_unit_issue.is_empty(): return shadow_warden_unit_issue
	var jandice_apprentice_unit_issue: String=JandiceApprenticeSources.unit_error(unit)
	if not jandice_apprentice_unit_issue.is_empty(): return jandice_apprentice_unit_issue
	var underling_unit_issue: String=UnderlingSources.unit_error(unit)
	if not underling_unit_issue.is_empty(): return underling_unit_issue
	# The recruit listener is inactive during battle; terminal hero damage is
	# separately authenticated against this actual battle board, never retained copies.
	var waxadred_unit_issue: String=WaxadredSources.unit_error(unit)
	if not waxadred_unit_issue.is_empty(): return waxadred_unit_issue
	var mini_zerek_unit_issue: String=MiniZerekSources.unit_error(unit)
	if not mini_zerek_unit_issue.is_empty(): return mini_zerek_unit_issue
	var faceless_unit_issue: String=FacelessSources.unit_error(unit)
	if not faceless_unit_issue.is_empty(): return faceless_unit_issue
	var lucky_egg_unit_issue: String=LuckyEggSources.unit_error(unit)
	if not lucky_egg_unit_issue.is_empty(): return lucky_egg_unit_issue
	var timewarped_evolution_unit_issue: String=EvolutionSources.unit_error(unit)
	if not timewarped_evolution_unit_issue.is_empty(): return timewarped_evolution_unit_issue
	var trench_unit_issue: String=TrenchSources.unit_error(unit)
	if not trench_unit_issue.is_empty(): return trench_unit_issue
	var lasso_unit_issue: String=LassoSources.unit_error(unit)
	if not lasso_unit_issue.is_empty(): return lasso_unit_issue
	var trailblazer_unit_issue: String=TrailblazerSources.unit_error(unit)
	if not trailblazer_unit_issue.is_empty(): return trailblazer_unit_issue
	var centurion_unit_issue: String=CenturionSources.unit_error(unit)
	if not centurion_unit_issue.is_empty(): return centurion_unit_issue
	var spellteach_unit_issue: String=SpellteachSources.unit_error(unit)
	if not spellteach_unit_issue.is_empty(): return spellteach_unit_issue
	var bouncy_unit_issue: String=BouncySources.unit_error(unit)
	if not bouncy_unit_issue.is_empty(): return bouncy_unit_issue
	var health_refresh_unit_issue: String=HealthRefreshSources.unit_error(unit)
	if not health_refresh_unit_issue.is_empty(): return health_refresh_unit_issue
	var quota_unit_issue: String=TradeQuotas.Sources.unit_error(unit)
	if not quota_unit_issue.is_empty(): return quota_unit_issue
	var market_stat_echo_issue: String=MarketStats.Sources.unit_error(unit)
	if not market_stat_echo_issue.is_empty(): return market_stat_echo_issue
	var dancing_hat_unit_issue: String=DancingHatSources.unit_error(unit)
	if not dancing_hat_unit_issue.is_empty(): return dancing_hat_unit_issue
	var hand_start_unit_issue: String=HandStartCopy.Sources.unit_error(unit)
	if not hand_start_unit_issue.is_empty(): return hand_start_unit_issue
	var survival_start_issue: String=SurvivalStartSources.unit_error(unit)
	if not survival_start_issue.is_empty(): return survival_start_issue
	var turn_destroy_issue: String=TurnDeath.unit_error(unit)
	if not turn_destroy_issue.is_empty(): return turn_destroy_issue
	var soldier_choice_issue: String=SoldierChoice.unit_error(unit)
	if not soldier_choice_issue.is_empty(): return soldier_choice_issue
	var wildfire_excess_issue: String=Wildfire.Sources.unit_error(unit)
	if not wildfire_excess_issue.is_empty(): return wildfire_excess_issue
	var pagle_triple_issue: String=Pagle.Sources.unit_error(unit)
	if not pagle_triple_issue.is_empty(): return pagle_triple_issue
	if unit.has(Pagle.Sources.USED): return "pagle_triple_spent_instance_import_partial"
	if EachTierRefreshSources.claimed(unit):
		var each_tier_issue: String=EachTierRefreshSources.source_error(unit) if unit.has("id") and not unit.has("card_id") else EachTierRefreshSources.unit_error(unit)
		if not each_tier_issue.is_empty(): return each_tier_issue
	var shop_replace_issue: String=ShopBattlecryReplaceSources.unit_error(unit)
	if not shop_replace_issue.is_empty(): return shop_replace_issue
	var boogeymonster_issue: String=BoogeymonsterSources.unit_error(unit)
	if not boogeymonster_issue.is_empty(): return boogeymonster_issue
	var dragon_kill_buff_issue: String=DragonKillSources.unit_error(unit)
	if not dragon_kill_buff_issue.is_empty(): return dragon_kill_buff_issue
	var kill_hand_issue: String=KillHandSources.unit_error(unit)
	if not kill_hand_issue.is_empty(): return kill_hand_issue
	var nat_attack_kill_issue: String=NatSources.unit_error(unit)
	if not nat_attack_kill_issue.is_empty(): return nat_attack_kill_issue
	var second_kill_plain_issue: String=SecondKillSources.unit_error(unit)
	if not second_kill_plain_issue.is_empty(): return second_kill_plain_issue
	var seaborn_shop_issue: String=SeabornSources.unit_error(unit)
	if not seaborn_shop_issue.is_empty(): return seaborn_shop_issue
	var stat_spell_resource_issue: String=StatSpellSources.unit_error(unit)
	if not stat_spell_resource_issue.is_empty(): return stat_spell_resource_issue
	var combat_plain_source_issue: String=CombatPlainSources.unit_error(unit)
	if not combat_plain_source_issue.is_empty(): return combat_plain_source_issue
	var recruit_exact_copy_issue: String=RecruitExactSources.unit_error(unit)
	if not recruit_exact_copy_issue.is_empty(): return recruit_exact_copy_issue
	var zarjira_copy_issue: String=ZarjiraCopySources.unit_error(unit)
	if not zarjira_copy_issue.is_empty(): return zarjira_copy_issue
	var duplicating_lens_issue: String=DuplicatingLensSources.unit_error(unit)
	if not duplicating_lens_issue.is_empty(): return duplicating_lens_issue
	var previous_plain_issue: String=PreviousPlainSources.unit_error(unit)
	if not previous_plain_issue.is_empty(): return previous_plain_issue
	var plain_copy_issue: String=PlainCopySources.unit_error(unit)
	if not plain_copy_issue.is_empty(): return plain_copy_issue
	var shell_transfer_issue: String=ShellTransfer.unit_error(unit)
	if not shell_transfer_issue.is_empty(): return shell_transfer_issue
	var phase_army_issue: String=PhaseArmy.unit_error(unit)
	if not phase_army_issue.is_empty(): return phase_army_issue
	var followup_unit_issue: String=DamageFollowupSources.unit_error(unit)
	if not followup_unit_issue.is_empty(): return followup_unit_issue
	var native_summon_unit_issue: String=NativeSummonClock.unit_error(unit)
	if not native_summon_unit_issue.is_empty(): return native_summon_unit_issue
	var vashj_unit_issue: String=VashjSources.unit_error(unit)
	if not vashj_unit_issue.is_empty(): return vashj_unit_issue
	var refresh_spellcraft_unit_issue: String=RefreshSpellcraft.unit_error(unit)
	if not refresh_spellcraft_unit_issue.is_empty(): return refresh_spellcraft_unit_issue
	var elemental_unit_issue: String=ElementalSources.unit_error(unit)
	if not elemental_unit_issue.is_empty(): return elemental_unit_issue
	var dealt_lifetime_unit_issue: String=DealtLifetimeSources.unit_error(unit)
	if not dealt_lifetime_unit_issue.is_empty(): return dealt_lifetime_unit_issue
	var received_native_issue: String=ReceivedNative.unit_error(unit)
	if not received_native_issue.is_empty(): return received_native_issue
	var permanent_damage_unit_issue: String=DamagePermanent.unit_error(unit)
	if not permanent_damage_unit_issue.is_empty(): return permanent_damage_unit_issue
	var kill_unit_issue: String=KillRewards.unit_error(unit)
	if not kill_unit_issue.is_empty(): return kill_unit_issue
	if unit.get("card_id",unit.get("id",""))==KillRewards.HERO: return "kill_reward_hero_cannot_be_minion"
	var multi_shield_claimed: bool=unit.get("card_id") in ["BG36_360t4","BG36_360_Gt4"]
	for multi_shield_effect in unit.get("effects",[]):
		if multi_shield_effect.get("type")=="native_multi_hit_shield": multi_shield_claimed=true
	if multi_shield_claimed:
		var native_capacity: int=3 if unit.get("card_id")=="BG36_360t4" else 4
		if unit.get("card_id") not in ["BG36_360t4","BG36_360_Gt4"] or unit.get("effects")!=[{"type":"native_multi_hit_shield","capacity":native_capacity}]: return "multi_hit_shield_wrong_native_program"
		if unit.has("_native_shield_hits") and (not unit._native_shield_hits is int or unit._native_shield_hits<0 or unit._native_shield_hits>=native_capacity): return "multi_hit_shield_invalid_private_counter"
	var threshold_unit_issue: String=ThresholdDamage.unit_error(unit)
	if not threshold_unit_issue.is_empty(): return threshold_unit_issue
	var attack_gain_unit_issue: String=AttackGains.unit_error(unit)
	if not attack_gain_unit_issue.is_empty(): return attack_gain_unit_issue
	var clock_unit_issue: String=RecruitClock.unit_error(unit)
	if not clock_unit_issue.is_empty(): return clock_unit_issue
	var keep_unit_issue: String=CombatKeep.unit_error(unit)
	if not keep_unit_issue.is_empty(): return keep_unit_issue
	var rider_unit_issue: String=Rider.Sources.unit_error(unit,is_base_unit)
	if not rider_unit_issue.is_empty(): return rider_unit_issue
	var global_unit_issue: String = GlobalCards.unit_error(unit)
	if not global_unit_issue.is_empty(): return global_unit_issue
	var hero_damage_unit_issue: String = BulkHeroDamage.unit_error(unit)
	if not hero_damage_unit_issue.is_empty(): return hero_damage_unit_issue
	var keyword_unit_issue: String = BulkKeywords.unit_error(unit)
	if not keyword_unit_issue.is_empty(): return keyword_unit_issue
	var trade_unit_issue: String = TradeTriggers.unit_error(unit)
	if not trade_unit_issue.is_empty(): return trade_unit_issue
	var cast_resource_unit_issue: String=CastResources.unit_error(unit)
	if not cast_resource_unit_issue.is_empty(): return cast_resource_unit_issue
	var living_recruit_dr_unit_issue: String=LivingRecruitDR.unit_error(unit)
	if not living_recruit_dr_unit_issue.is_empty(): return living_recruit_dr_unit_issue
	if PiggyBank.Sources.contains_marker(unit):
		var piggy_bank_unit_issue: String="piggy_bank_missing_actual_host" if _piggy_bank_host==null else _piggy_bank_host.source_error(unit)
		if not piggy_bank_unit_issue.is_empty(): return piggy_bank_unit_issue
	if NativeRallySpread.Sources.contains_combat_marker(unit): return "native_rally_spread_imported_or_copied_combat_grant_partial"
	var recruit_spread_shape_issue: String=NativeRallySpread.Recruit.unit_shape_error(unit)
	if not recruit_spread_shape_issue.is_empty():return recruit_spread_shape_issue
	if is_base_unit and NativeRallySpread.Recruit.marked(unit):return "recruit_rally_spread_contaminated_native_base"
	if StartGrantSources.contains_marker(unit): return "native_start_grant_imported_or_copied_combat_grant_partial"
	if BrukanGrant.contains_marker(unit): return "brukan_elements_imported_or_copied_combat_grant_partial"
	if TamsinGrant.contains_marker(unit): return "tamsin_phylactery_imported_or_copied_combat_grant_partial"
	var megasaur_grant_issue: String=MegaGrants.grant_error(unit)
	if not megasaur_grant_issue.is_empty(): return megasaur_grant_issue
	if is_base_unit and MegaGrants.marked(unit): return "megasaur_adapt_native_base_contaminated"
	var temp_death_unit_issue: String=TempDeath.unit_error(unit)
	if not temp_death_unit_issue.is_empty(): return temp_death_unit_issue
	var random_spellcraft_unit_issue: String=RandomSpellcraftSources.unit_error(unit)
	if not random_spellcraft_unit_issue.is_empty(): return random_spellcraft_unit_issue
	var bulk_discover_unit_issue: String = BulkDiscover.unit_error(unit)
	if not bulk_discover_unit_issue.is_empty(): return bulk_discover_unit_issue
	var periodic_unit_issue: String = PeriodicEot.unit_error(unit)
	if not periodic_unit_issue.is_empty(): return periodic_unit_issue
	var combat_transform_issue: String=CombatTransforms.unit_error(unit)
	if not combat_transform_issue.is_empty(): return combat_transform_issue
	var combat_copy_issue: String=CombatCopies.unit_error(unit)
	if not combat_copy_issue.is_empty(): return combat_copy_issue
	var bulk_hand_issue: String=BulkHandSummon.unit_error(unit)
	if not bulk_hand_issue.is_empty(): return bulk_hand_issue
	var salvager_source_issue: String=SalvagerSources.unit_error(unit)
	if not salvager_source_issue.is_empty(): return salvager_source_issue
	var protoss_source_issue: String=Protoss.Sources.unit_error(unit,source_templates if not source_templates.is_empty() else _options.get("hand_card_templates",{}))
	if not protoss_source_issue.is_empty(): return protoss_source_issue
	var hyena_source_issue: String=Hyena.Sources.unit_error(unit)
	if not hyena_source_issue.is_empty(): return hyena_source_issue
	var lobster_source_issue: String=Lobster.Sources.unit_error(unit)
	if not lobster_source_issue.is_empty(): return lobster_source_issue
	var leviathan_source_issue: String=Leviathan.Sources.unit_error(unit)
	if not leviathan_source_issue.is_empty(): return leviathan_source_issue
	var hopebringer_source_issue: String=Hopebringer.Sources.unit_error(unit)
	if not hopebringer_source_issue.is_empty(): return hopebringer_source_issue
	var octosari_source_issue: String=Octosari.Sources.unit_error(unit)
	if not octosari_source_issue.is_empty(): return octosari_source_issue
	var silithid_source_issue: String=SilithidSources.unit_error(unit)
	if not silithid_source_issue.is_empty(): return silithid_source_issue
	var shield_taunt_source_issue: String=ShieldTaunt.unit_error(unit)
	if not shield_taunt_source_issue.is_empty(): return shield_taunt_source_issue
	var native_enforcer_source_issue: String=NativeEnforcer.Sources.unit_error(unit)
	if not native_enforcer_source_issue.is_empty(): return native_enforcer_source_issue
	var shield_permanent_source_issue: String=ShieldPermanent.Sources.unit_error(unit)
	if not shield_permanent_source_issue.is_empty(): return shield_permanent_source_issue
	var shiny_layer_source_issue: String=ShinyLayer.Sources.unit_error(unit)
	if not shiny_layer_source_issue.is_empty(): return shiny_layer_source_issue
	if unit.has(StartChoice.MARK) and (_start_choice_host==null or not _start_choice_host.known_mark(unit)): return "whitemane_combat_mark_import_requires_actual_private_binding"
	var start_choice_source_issue: String=StartChoice.Sources.unit_error(unit)
	if not start_choice_source_issue.is_empty(): return start_choice_source_issue
	var keyword_loss_source_issue: String=KeywordLoss.Sources.unit_error(unit)
	if not keyword_loss_source_issue.is_empty(): return keyword_loss_source_issue
	var roogug_source_issue: String=RoogugSources.unit_error(unit)
	if not roogug_source_issue.is_empty(): return roogug_source_issue
	var pufferquil_source_issue: String=PufferquilSources.unit_error(unit)
	if not pufferquil_source_issue.is_empty(): return pufferquil_source_issue
	var cast_minion_gem_source_issue: String=CastMinionGemSources.unit_error(unit)
	if not cast_minion_gem_source_issue.is_empty(): return cast_minion_gem_source_issue
	var deity_recruit_dr_unit_issue: String=DeityRecruitDRSources.unit_error(unit)
	if not deity_recruit_dr_unit_issue.is_empty(): return deity_recruit_dr_unit_issue
	var deity_board_cast_unit_issue: String=DeityBoardCastSources.unit_error(unit)
	if not deity_board_cast_unit_issue.is_empty(): return deity_board_cast_unit_issue
	var deity_cast_unit_issue: String=DeityCastSources.unit_error(unit)
	if not deity_cast_unit_issue.is_empty(): return deity_cast_unit_issue
	var deity_hand_native_issue: String=DeityHandGain.Sources.unit_error(unit)
	if not deity_hand_native_issue.is_empty(): return deity_hand_native_issue
	var deity_native_unit_issue: String=DeityCombat.Sources.unit_error(unit)
	if not deity_native_unit_issue.is_empty(): return deity_native_unit_issue
	var maximum_history_source_issue: String=MaximumHistorySources.unit_error(unit)
	if not maximum_history_source_issue.is_empty(): return maximum_history_source_issue
	var technician_native_source_issue: String=TechnicianKiller.unit_error(unit)
	if not technician_native_source_issue.is_empty(): return technician_native_source_issue
	var fish_native_source_issue: String=FishGroups.unit_error(unit)
	if not fish_native_source_issue.is_empty(): return fish_native_source_issue
	var each_type_source_issue: String=EachTypePermanent.unit_error(unit)
	if not each_type_source_issue.is_empty(): return each_type_source_issue
	var jailbird_source_issue: String=JailbirdJuggernaut.Sources.unit_error(unit)
	if not jailbird_source_issue.is_empty(): return jailbird_source_issue
	var krush_source_issue: String=KrushPreemptive.unit_error(unit)
	if not krush_source_issue.is_empty(): return krush_source_issue
	var preemptive_issue: String=Preemptive.unit_error(unit)
	if not preemptive_issue.is_empty(): return preemptive_issue
	var deferred_hand_issue: String=DeferredHand.unit_error(unit)
	if not deferred_hand_issue.is_empty(): return deferred_hand_issue
	var bulk_activate_issue: String=BulkActivate.unit_error(unit,is_base_unit)
	if not bulk_activate_issue.is_empty(): return bulk_activate_issue
	var knight_issue: String=Knights.unit_error(unit)
	if not knight_issue.is_empty(): return knight_issue
	var native_dr_issue: String=NativeDRTriggers.unit_error(unit)
	if not native_dr_issue.is_empty(): return native_dr_issue
	var living_dr_issue: String=LivingDeathrattles.unit_error(unit)
	if not living_dr_issue.is_empty(): return living_dr_issue
	var reborn_grant_issue: String=RebornGrants.unit_error(unit)
	if not reborn_grant_issue.is_empty(): return reborn_grant_issue
	var reborn_retention_issue: String=RebornRetention.unit_error(unit)
	if not reborn_retention_issue.is_empty(): return reborn_retention_issue
	var summon_attempt_issue: String=SummonAttempt.unit_error(unit)
	if not summon_attempt_issue.is_empty(): return summon_attempt_issue
	var summon_permanent_issue: String=SummonPermanent.unit_error(unit)
	if not summon_permanent_issue.is_empty(): return summon_permanent_issue
	var bulk_counter_unit_issue: String = BulkTurnCounters.unit_error(unit)
	if not bulk_counter_unit_issue.is_empty(): return bulk_counter_unit_issue
	if BulkResourceHost.FiniteAvenge.claimed(unit):
		var finite_template_issue: String=BulkResourceHost.FiniteAvenge.context_error(_options.get(BulkResourceHost.KEY,{}).get(BulkResourceHost.FiniteAvenge.KEY,{}),source_templates if not source_templates.is_empty() else _options.get("hand_card_templates",{}),BulkResourceHost.FiniteAvenge.pool_for(BulkResourceSources.identity(unit)))
		if not finite_template_issue.is_empty() and not _options.is_empty(): return finite_template_issue
	if BulkResourceHost.VolumizerSpecial.claimed(unit):
		var volumizer_template_issue: String=BulkResourceHost.VolumizerSpecial.context_error(_options.get(BulkResourceHost.KEY,{}).get(BulkResourceHost.VolumizerSpecial.KEY,{}),source_templates if not source_templates.is_empty() else _options.get("hand_card_templates",{}))
		if not volumizer_template_issue.is_empty() and not _options.is_empty(): return volumizer_template_issue
	if BulkResourceHost.Chromatic.claimed(unit):
		var chromatic_template_issue: String=BulkResourceHost.Chromatic.context_error(_options.get(BulkResourceHost.KEY,{}).get(BulkResourceHost.Chromatic.KEY,{}),source_templates if not source_templates.is_empty() else _options.get("hand_card_templates",{}))
		if not chromatic_template_issue.is_empty() and not _options.is_empty(): return chromatic_template_issue
	var native_spellcraft_unit_issue: String=BulkResourceHost.NativeSpellcraft.unit_error(unit)
	if not native_spellcraft_unit_issue.is_empty(): return native_spellcraft_unit_issue
	var summon_get_unit_issue: String=SummonGet.Sources.unit_error(unit)
	if not summon_get_unit_issue.is_empty(): return summon_get_unit_issue
	var rally_each_type_unit_issue: String=RallyEachType.Sources.unit_error(unit)
	if not rally_each_type_unit_issue.is_empty(): return rally_each_type_unit_issue
	var hand_board_unit_issue: String=HandBoard.Sources.unit_error(unit)
	if not hand_board_unit_issue.is_empty(): return hand_board_unit_issue
	var anchorman_unit_issue: String=Anchorman.Sources.unit_error(unit)
	if not anchorman_unit_issue.is_empty(): return anchorman_unit_issue
	var intrinsic_twice_unit_issue: String=IntrinsicTwice.Sources.unit_error(unit)
	if not intrinsic_twice_unit_issue.is_empty(): return intrinsic_twice_unit_issue
	var rally_permanent_shield_unit_issue: String=RallyShield.Sources.unit_error(unit)
	if not rally_permanent_shield_unit_issue.is_empty(): return rally_permanent_shield_unit_issue
	var last_spell_unit_issue: String=LastSpell.Sources.unit_error(unit)
	if not last_spell_unit_issue.is_empty(): return last_spell_unit_issue
	var combat_gem_trigger_unit_issue: String=CombatGemTriggers.Sources.unit_error(unit)
	if not combat_gem_trigger_unit_issue.is_empty(): return combat_gem_trigger_unit_issue
	var gem_summon_unit_issue: String=GemSummon.Sources.unit_error(unit)
	if not gem_summon_unit_issue.is_empty(): return gem_summon_unit_issue
	var gem_golem_unit_issue: String=GemGolem.Sources.unit_error(unit)
	if not gem_golem_unit_issue.is_empty(): return gem_golem_unit_issue
	var bonerender_unit_issue: String=Bonerender.Sources.unit_error(unit)
	if not bonerender_unit_issue.is_empty(): return bonerender_unit_issue
	var khadgar_unit_issue: String=Khadgar.Sources.unit_error(unit)
	if not khadgar_unit_issue.is_empty(): return khadgar_unit_issue
	var elistra_unit_issue: String=Elistra.Sources.unit_error(unit)
	if not elistra_unit_issue.is_empty(): return elistra_unit_issue
	var matador_unit_issue: String=Matador.Sources.unit_error(unit)
	if not matador_unit_issue.is_empty(): return matador_unit_issue
	var next_shop_unit_issue: String=NextTurnShopSources.unit_error(unit)
	if not next_shop_unit_issue.is_empty(): return next_shop_unit_issue
	var linked_undead_unit_issue: String=LinkedUndead.Sources.unit_error(unit)
	if not linked_undead_unit_issue.is_empty(): return linked_undead_unit_issue
	var pastry_unit_issue: String=PastryAvenge.unit_error(unit)
	if not pastry_unit_issue.is_empty(): return pastry_unit_issue
	if PastryAvenge.claimed(unit) and not _options.is_empty():
		var pastry_child_issue: String=PastryAvenge.template_error(_options.get("hand_card_templates",{}).get(PastryAvenge.CHILD,{}))
		if not pastry_child_issue.is_empty(): return pastry_child_issue
	var worgen_unit_issue: String=Worgen.Sources.unit_error(unit)
	if not worgen_unit_issue.is_empty(): return worgen_unit_issue
	var first_attack_unit_issue: String=FirstAttack.Sources.unit_error(unit)
	if not first_attack_unit_issue.is_empty(): return first_attack_unit_issue
	var sinestra_unit_issue: String=Sinestra.unit_error(unit)
	if not sinestra_unit_issue.is_empty(): return sinestra_unit_issue
	var stoneshell_unit_issue: String=Stoneshell.Sources.unit_error(unit)
	if not stoneshell_unit_issue.is_empty(): return stoneshell_unit_issue
	var dramaloc_unit_issue: String=Dramaloc.Sources.unit_error(unit)
	if not dramaloc_unit_issue.is_empty(): return dramaloc_unit_issue
	var rightmost_dual_unit_issue: String=RightmostDual.Sources.unit_error(unit)
	if not rightmost_dual_unit_issue.is_empty(): return rightmost_dual_unit_issue
	var seafloor_unit_issue: String=SeafloorCast.Sources.unit_error(unit)
	if not seafloor_unit_issue.is_empty(): return seafloor_unit_issue
	var rally_dragon_spell_unit_issue: String=CombatRingCast.DragonSources.unit_error(unit)
	if not rally_dragon_spell_unit_issue.is_empty(): return rally_dragon_spell_unit_issue
	var friendly_attack_ring_unit_issue: String=CombatRingCast.AttackSources.unit_error(unit)
	if not friendly_attack_ring_unit_issue.is_empty(): return friendly_attack_ring_unit_issue
	var staff_eot_unit_issue: String=StaffEotSources.unit_error(unit)
	if not staff_eot_unit_issue.is_empty(): return staff_eot_unit_issue
	var fauna_eot_unit_issue: String=FaunaEotSources.unit_error(unit)
	if not fauna_eot_unit_issue.is_empty(): return fauna_eot_unit_issue
	var reverber_drake_unit_issue: String=ReverberDrakeSources.unit_error(unit)
	if not reverber_drake_unit_issue.is_empty(): return reverber_drake_unit_issue
	var efficient_engineer_unit_issue: String=EfficientEngineerSources.unit_error(unit)
	if not efficient_engineer_unit_issue.is_empty(): return efficient_engineer_unit_issue
	var deadscale_spellcraft_unit_issue: String=DeadscaleSources.unit_error(unit)
	if not deadscale_spellcraft_unit_issue.is_empty(): return deadscale_spellcraft_unit_issue
	var terror_guard_unit_issue: String=TerrorguardSources.unit_error(unit)
	if not terror_guard_unit_issue.is_empty(): return terror_guard_unit_issue
	var brigand_unit_issue: String=BrigandSources.unit_error(unit)
	if not brigand_unit_issue.is_empty(): return brigand_unit_issue
	var disco_unit_issue: String=DiscoSources.unit_error(unit)
	if not disco_unit_issue.is_empty(): return disco_unit_issue
	var beatboxer_unit_issue: String=BeatboxerSources.unit_error(unit)
	if not beatboxer_unit_issue.is_empty(): return beatboxer_unit_issue
	var winds_spend_unit_issue: String=WindsSpendSources.unit_error(unit)
	if not winds_spend_unit_issue.is_empty(): return winds_spend_unit_issue
	var gatekeeper_cast_unit_issue: String=GatekeeperSources.unit_error(unit)
	if not gatekeeper_cast_unit_issue.is_empty(): return gatekeeper_cast_unit_issue
	var queensguard_unit_issue: String=CombatRingCast.QueenSources.unit_error(unit)
	if not queensguard_unit_issue.is_empty(): return queensguard_unit_issue
	var combat_ring_unit_issue: String=CombatRingCast.Sources.unit_error(unit)
	if not combat_ring_unit_issue.is_empty(): return combat_ring_unit_issue
	var whelp_summon_unit_issue: String=WhelpSummon.Sources.unit_error(unit)
	if not whelp_summon_unit_issue.is_empty(): return whelp_summon_unit_issue
	var rightmost_battlecry_unit_issue: String=RightmostBattlecry.Sources.unit_error(unit)
	if not rightmost_battlecry_unit_issue.is_empty(): return rightmost_battlecry_unit_issue
	var rylak_battlecry_unit_issue: String=RylakBattlecry.Sources.unit_error(unit)
	if not rylak_battlecry_unit_issue.is_empty(): return rylak_battlecry_unit_issue
	var adjacent_tide_unit_issue: String=AdjacentTide.Sources.unit_error(unit)
	if not adjacent_tide_unit_issue.is_empty(): return adjacent_tide_unit_issue
	var hag_reborn_unit_issue: String=HagReborn.Sources.unit_error(unit)
	if not hag_reborn_unit_issue.is_empty(): return hag_reborn_unit_issue
	var combat_golden_unit_issue: String=CombatGolden.Sources.unit_error(unit)
	if not combat_golden_unit_issue.is_empty(): return combat_golden_unit_issue
	var maximum_imp_unit_issue: String=MaximumImp.Sources.unit_error(unit)
	if not maximum_imp_unit_issue.is_empty(): return maximum_imp_unit_issue
	var gem_ledger_transfer_unit_issue: String=GemLedgerTransfer.Sources.unit_error(unit)
	if not gem_ledger_transfer_unit_issue.is_empty(): return gem_ledger_transfer_unit_issue
	var avenge_poison_unit_issue: String=AvengePoison.Sources.unit_error(unit)
	if not avenge_poison_unit_issue.is_empty(): return avenge_poison_unit_issue
	var hand_gem_unit_issue: String=HandGemRepeatSources.unit_error(unit)
	if not hand_gem_unit_issue.is_empty(): return hand_gem_unit_issue
	var activate_gem_unit_issue: String=ActivateGemSources.unit_error(unit)
	if not activate_gem_unit_issue.is_empty(): return activate_gem_unit_issue
	var activate_discard_unit_issue: String=ActivateDiscardSources.unit_error(unit)
	if not activate_discard_unit_issue.is_empty(): return activate_discard_unit_issue
	var activate_discard_resource_unit_issue: String=ActivateDiscardResourceSources.unit_error(unit)
	if not activate_discard_resource_unit_issue.is_empty(): return activate_discard_resource_unit_issue
	var activate_discard_amplifier_unit_issue: String=ActivateDiscardAmplifierSources.unit_error(unit)
	if not activate_discard_amplifier_unit_issue.is_empty(): return activate_discard_amplifier_unit_issue
	var reveille_unit_issue: String=AutoReveilleSources.unit_error(unit)
	if not reveille_unit_issue.is_empty(): return reveille_unit_issue
	var resourceful_unit_issue: String=ResourcefulSources.unit_error(unit)
	if not resourceful_unit_issue.is_empty(): return resourceful_unit_issue
	var deft_deserter_unit_issue: String=DeftDeserterSources.unit_error(unit)
	if not deft_deserter_unit_issue.is_empty(): return deft_deserter_unit_issue
	var targeted_activate_unit_issue: String=TargetedActivateSources.unit_error(unit)
	if not targeted_activate_unit_issue.is_empty(): return targeted_activate_unit_issue
	var skyhatch_rally_unit_issue: String=SkyhatchRallySources.unit_error(unit)
	if not skyhatch_rally_unit_issue.is_empty(): return skyhatch_rally_unit_issue
	var cagey_autocast_unit_issue: String=CageyCastSources.unit_error(unit)
	if not cagey_autocast_unit_issue.is_empty(): return cagey_autocast_unit_issue
	var magnetic_repeat_unit_issue: String=MagneticRepeatSources.unit_error(unit)
	if not magnetic_repeat_unit_issue.is_empty(): return magnetic_repeat_unit_issue
	var drone_repeat_unit_issue: String=DroneRepeatSources.unit_error(unit)
	if not drone_repeat_unit_issue.is_empty(): return drone_repeat_unit_issue
	var battlecry_activate_unit_issue: String=BattlecryActivateSources.unit_error(unit)
	if not battlecry_activate_unit_issue.is_empty(): return battlecry_activate_unit_issue
	var consume_observer_unit_issue: String=ConsumeObserverSources.unit_error(unit)
	if not consume_observer_unit_issue.is_empty(): return consume_observer_unit_issue
	var shop_consume_unit_issue: String=ShopConsumeSources.unit_error(unit)
	if not shop_consume_unit_issue.is_empty(): return shop_consume_unit_issue
	var deity_activate_unit_issue: String=DeityActivateSources.unit_error(unit)
	if not deity_activate_unit_issue.is_empty(): return deity_activate_unit_issue
	var combat_gem_unit_issue: String=CombatGems.Sources.unit_error(unit)
	if not combat_gem_unit_issue.is_empty(): return combat_gem_unit_issue
	var turn_golden_unit_issue: String=TurnGoldenSources.unit_error(unit)
	if not turn_golden_unit_issue.is_empty(): return turn_golden_unit_issue
	var hero_extra_unit_issue: String=HeroExtraUseSources.unit_error(unit)
	if not hero_extra_unit_issue.is_empty(): return hero_extra_unit_issue
	var friendly_consume_unit_issue: String=FriendlyConsumeSources.unit_error(unit)
	if not friendly_consume_unit_issue.is_empty(): return friendly_consume_unit_issue
	var start_friendly_consume_unit_issue: String=StartFriendlyConsumeSources.unit_error(unit)
	if not start_friendly_consume_unit_issue.is_empty(): return start_friendly_consume_unit_issue
	var faceless_disciple_unit_issue: String=FacelessDiscipleSources.unit_error(unit)
	if not faceless_disciple_unit_issue.is_empty(): return faceless_disciple_unit_issue
	var sand_swirler_unit_issue: String=SandSwirlerSources.unit_error(unit)
	if not sand_swirler_unit_issue.is_empty(): return sand_swirler_unit_issue
	var nathanos_unit_issue: String=NathanosSources.unit_error(unit)
	if not nathanos_unit_issue.is_empty(): return nathanos_unit_issue
	var felhorn_unit_issue: String=FelhornSources.unit_error(unit)
	if not felhorn_unit_issue.is_empty(): return felhorn_unit_issue
	var nether_unit_issue: String=NetherConstructSources.unit_error(unit)
	if not nether_unit_issue.is_empty(): return nether_unit_issue
	var felboar_unit_issue: String=FelboarCastSources.unit_error(unit)
	if not felboar_unit_issue.is_empty(): return felboar_unit_issue
	var clefthoof_unit_issue: String=ClefthoofSources.unit_error(unit)
	if not clefthoof_unit_issue.is_empty(): return clefthoof_unit_issue
	var panther_unit_issue: String=PantherSources.unit_error(unit)
	if not panther_unit_issue.is_empty(): return panther_unit_issue
	var snarky_shark_unit_issue: String=SnarkySharkSources.unit_error(unit)
	if not snarky_shark_unit_issue.is_empty(): return snarky_shark_unit_issue
	var nightmare_unit_issue: String=NightmareSources.unit_error(unit)
	if not nightmare_unit_issue.is_empty(): return nightmare_unit_issue
	var deathhead_unit_issue: String=Deathhead.Sources.unit_error(unit)
	if not deathhead_unit_issue.is_empty(): return deathhead_unit_issue
	var siren_unit_issue: String=SirenSources.unit_error(unit)
	if not siren_unit_issue.is_empty(): return siren_unit_issue
	var taverngoer_unit_issue: String=TaverngoerSources.unit_error(unit)
	if not taverngoer_unit_issue.is_empty(): return taverngoer_unit_issue
	var fandral_unit_issue: String=FandralSources.unit_error(unit)
	if not fandral_unit_issue.is_empty(): return fandral_unit_issue
	var necrolyte_unit_issue: String=NecrolyteSources.unit_error(unit)
	if not necrolyte_unit_issue.is_empty(): return necrolyte_unit_issue
	var battlecry_swap_unit_issue: String=BattlecrySwapSources.unit_error(unit)
	if not battlecry_swap_unit_issue.is_empty(): return battlecry_swap_unit_issue
	var battlecry_golden_unit_issue: String=BattlecryGoldenSources.unit_error(unit)
	if not battlecry_golden_unit_issue.is_empty(): return battlecry_golden_unit_issue
	var inplace_golden_unit_issue: String=InplaceGoldenSources.unit_error(unit)
	if not inplace_golden_unit_issue.is_empty(): return inplace_golden_unit_issue
	var refresh_golden_unit_issue: String=RefreshGoldenSources.unit_error(unit)
	if not refresh_golden_unit_issue.is_empty(): return refresh_golden_unit_issue
	var sale_cycle_unit_issue: String=SaleCycleSources.unit_error(unit)
	if not sale_cycle_unit_issue.is_empty(): return sale_cycle_unit_issue
	var sale_gem_unit_issue: String=SaleGemSources.unit_error(unit)
	if not sale_gem_unit_issue.is_empty(): return sale_gem_unit_issue
	var active_tavern_bonus_issue: String=TavernAmplifier.Active.complete_error(unit,source_templates if not source_templates.is_empty() else _options.get("hand_card_templates",{}))
	if not active_tavern_bonus_issue.is_empty(): return active_tavern_bonus_issue
	var random_resource_issue: String = BulkResourceSources.unit_error(unit,source_templates,is_base_unit)
	if not random_resource_issue.is_empty(): return random_resource_issue
	var generated_source_issue: String = GeneratedDiscover.unit_error(unit)
	if not generated_source_issue.is_empty(): return generated_source_issue
	var bulk_source_issue: String = BulkRecruit.unit_error(unit)
	if not bulk_source_issue.is_empty(): return bulk_source_issue
	var reborn_combat_issue: String=RebornCombat.unit_error(unit,source_templates,is_base_unit)
	if not reborn_combat_issue.is_empty(): return reborn_combat_issue
	var original_jelly_source_issue: String = OriginalJelly.unit_error(unit,source_templates if not source_templates.is_empty() else _options.get("hand_card_templates",{}),is_base_unit)
	if not original_jelly_source_issue.is_empty(): return original_jelly_source_issue
	var jelly_source_issue: String = Jelly.unit_error(unit,source_templates if not source_templates.is_empty() else _options.get("hand_card_templates",{}),is_base_unit)
	if not jelly_source_issue.is_empty(): return jelly_source_issue
	var sister_source_issue: String = Sister.unit_error(unit,source_templates if not source_templates.is_empty() else _options.get("hand_card_templates",{}),is_base_unit)
	if not sister_source_issue.is_empty(): return sister_source_issue
	var gnoll_source_issue: String = Gnoll.unit_error(unit,source_templates if not source_templates.is_empty() else _options.get("hand_card_templates",{}),is_base_unit)
	if not gnoll_source_issue.is_empty(): return gnoll_source_issue
	var ghoul_source_issue: String = GhoulDeath.unit_error(unit,source_templates if not source_templates.is_empty() else _options.get("hand_card_templates",{}),is_base_unit)
	if not ghoul_source_issue.is_empty(): return ghoul_source_issue
	var completed_source_issue: String = CompletedAttack.unit_error(unit,source_templates if not source_templates.is_empty() else _options.get("hand_card_templates",{}),is_base_unit)
	if not completed_source_issue.is_empty(): return completed_source_issue
	var alleycat_issue: String = Alleycat.unit_error(unit,source_templates if not source_templates.is_empty() else _options.get("hand_card_templates",{}),is_base_unit)
	if not alleycat_issue.is_empty(): return alleycat_issue
	var gadrin_issue: String = Gadrin.inspect_unit(unit,source_templates if not source_templates.is_empty() else _options.get("hand_card_templates",{}),is_base_unit)
	if not gadrin_issue.is_empty(): return gadrin_issue
	var ragnaros_issue: String = Ragnaros.Sources.unit_error(unit,source_templates if not source_templates.is_empty() else _options.get("hand_card_templates",{}),is_base_unit)
	if not ragnaros_issue.is_empty(): return ragnaros_issue
	if DoubleStat.claimed(unit): return "double_stat_prize_cannot_be_combat_minion"
	if EarthMother.same(unit.get("card_id"),EarthMother.EYE): return "earth_mother_spell_cannot_be_combat_minion"
	var earth_issue: String = EarthMother.unit_error(unit,source_templates if not source_templates.is_empty() else _options.get("hand_card_templates",{}),is_base_unit)
	if not earth_issue.is_empty(): return earth_issue
	var bone_issue: String = BoneBaron.unit_error(unit,source_templates if not source_templates.is_empty() else _options.get("hand_card_templates",{}),is_base_unit)
	if not bone_issue.is_empty(): return bone_issue
	var spiked_issue: String = SpikedSavior.unit_error(unit,source_templates if not source_templates.is_empty() else _options.get("hand_card_templates",{}),is_base_unit)
	if not spiked_issue.is_empty(): return spiked_issue
	var enforcer_issue: String = Enforcer.unit_error(unit,source_templates if not source_templates.is_empty() else _options.get("hand_card_templates",{}),is_base_unit)
	if not enforcer_issue.is_empty(): return enforcer_issue
	var overflow_issue: String = SummonOverflow.Sources.unit_error(unit,source_templates if not source_templates.is_empty() else _options.get("hand_card_templates",{}),is_base_unit)
	if not overflow_issue.is_empty(): return overflow_issue
	var ticking_issue: String = "" if SpikedSavior.claimed(unit) else Ticking.unit_error(unit,source_templates if not source_templates.is_empty() else _options.get("hand_card_templates",{}),is_base_unit)
	if not ticking_issue.is_empty(): return ticking_issue
	var duelist_issue: String = Duelist.runtime_source_error(unit)
	if not duelist_issue.is_empty(): return duelist_issue
	var cruise_unit_issue: String = Cruise.unit_error(unit,source_templates if not source_templates.is_empty() else _options.get("hand_card_templates",{}),is_base_unit)
	if not cruise_unit_issue.is_empty(): return cruise_unit_issue
	var argent_unit_issue: String = ArgentBraggart.unit_error(unit,source_templates if not source_templates.is_empty() else _options.get("hand_card_templates",{}),is_base_unit)
	if not argent_unit_issue.is_empty(): return argent_unit_issue
	var hired_issue: String = HiredRitualist.unit_error(unit,source_templates if not source_templates.is_empty() else _options.get("hand_card_templates",{}),is_base_unit)
	if not hired_issue.is_empty(): return hired_issue
	var bristleback_issue: String = Bristleback.unit_error(unit,source_templates if not source_templates.is_empty() else _options.get("hand_card_templates",{}),is_base_unit)
	if not bristleback_issue.is_empty(): return bristleback_issue
	var treant_issue: String = TreantAttack.unit_error(unit,source_templates if not source_templates.is_empty() else _options.get("hand_card_templates",{}),is_base_unit)
	if not treant_issue.is_empty(): return treant_issue
	var champion_issue: String = ChampionAttack.unit_error(unit,source_templates if not source_templates.is_empty() else _options.get("hand_card_templates",{}),is_base_unit)
	if not champion_issue.is_empty(): return champion_issue
	var sunscreener_issue: String = Sunscreener.inspect_unit(unit,source_templates if not source_templates.is_empty() else _options.get("hand_card_templates",{}),is_base_unit)
	if not sunscreener_issue.is_empty(): return sunscreener_issue
	var attacked_adjacent_issue: String = AttackedAdjacent.unit_error(unit,source_templates if not source_templates.is_empty() else _options.get("hand_card_templates",{}),is_base_unit)
	if not attacked_adjacent_issue.is_empty(): return attacked_adjacent_issue
	var attacked_venomous_issue: String = AttackedVenomous.unit_error(unit,source_templates if not source_templates.is_empty() else _options.get("hand_card_templates",{}),is_base_unit)
	if not attacked_venomous_issue.is_empty(): return attacked_venomous_issue
	var saurolisk_issue: String = Saurolisk.unit_error(unit,source_templates if not source_templates.is_empty() else _options.get("hand_card_templates",{}),is_base_unit)
	if not saurolisk_issue.is_empty(): return saurolisk_issue
	var prime_issue: String = DelayedGold.PrimeMate.unit_error(unit,source_templates if not source_templates.is_empty() else _options.get("hand_card_templates",{}),is_base_unit)
	if not prime_issue.is_empty(): return prime_issue
	var felfire_issue: String = Felfire.unit_error(unit,source_templates if not source_templates.is_empty() else _options.get("hand_card_templates",{}),is_base_unit)
	if not felfire_issue.is_empty(): return felfire_issue
	var barov_issue: String = BarovCoin.unit_error(unit,source_templates if not source_templates.is_empty() else _options.get("hand_card_templates",{}),is_base_unit)
	if not barov_issue.is_empty(): return barov_issue
	var reef_issue: String = ReefRiffer.unit_error(unit,source_templates if not source_templates.is_empty() else _options.get("hand_card_templates",{}),is_base_unit)
	if not reef_issue.is_empty(): return reef_issue
	var meditation_issue: String = Meditation.unit_error(unit,source_templates if not source_templates.is_empty() else _options.get("hand_card_templates",{}),is_base_unit)
	if not meditation_issue.is_empty(): return meditation_issue
	var alliance_flag_issue: String = AllianceFlag.unit_error(unit,source_templates,is_base_unit)
	if not alliance_flag_issue.is_empty(): return alliance_flag_issue
	var volcanic_issue: String = Volcanic.unit_error(unit,source_templates if not source_templates.is_empty() else _options.get("hand_card_templates",{}),is_base_unit)
	if not volcanic_issue.is_empty(): return volcanic_issue
	var sprout_issue: String = SproutAvenge.unit_error(unit,source_templates if not source_templates.is_empty() else _options.get("hand_card_templates",{}),is_base_unit)
	if not sprout_issue.is_empty(): return sprout_issue
	var corpse_sale_unit_issue: String = CorpseSale.Sources.unit_error(unit,source_templates if not source_templates.is_empty() else _options.get("hand_card_templates",{}),is_base_unit)
	if not corpse_sale_unit_issue.is_empty(): return corpse_sale_unit_issue
	var economy_issue: String = CombatEconomy.Sources.unit_error(unit,source_templates if not source_templates.is_empty() else _options.get("hand_card_templates",{}),is_base_unit)
	if not economy_issue.is_empty(): return economy_issue
	var void_pup_issue: String = VoidPup.runtime_source_error(unit)
	if not void_pup_issue.is_empty(): return void_pup_issue
	var filtered_grant_issue: String = FilteredGrants.unit_error(unit)
	if not filtered_grant_issue.is_empty(): return filtered_grant_issue
	var upgrade_aura_issue: String = UpgradeAura.runtime_source_error(unit)
	if not upgrade_aura_issue.is_empty(): return upgrade_aura_issue
	var painter_issue: String = CardPlayParity.Painter.runtime_source_error(unit)
	if not painter_issue.is_empty(): return painter_issue
	var previous_combat_issue: String = PreviousCombat.runtime_source_error(unit,is_base_unit)
	if not previous_combat_issue.is_empty(): return previous_combat_issue
	var three_tribe_issue: String = ThreeTribe.runtime_source_error(unit)
	if not three_tribe_issue.is_empty(): return three_tribe_issue
	var constellation_issue: String = Constellation.runtime_source_error(unit)
	if not constellation_issue.is_empty(): return constellation_issue
	var bonus_keyword_issue: String = BonusKeyword.runtime_source_error(unit)
	if not bonus_keyword_issue.is_empty(): return bonus_keyword_issue
	var dozy_issue: String = dozy_program_error(unit)
	if not dozy_issue.is_empty(): return dozy_issue
	if is_dozy_identity(unit.get("card_id",unit.get("id",""))):
		if unit.has("uid") and (not unit.uid is String or unit.uid.is_empty()): return "Dozy source UID must be a nonempty String"
		if not unit.get("_pending_destroy",false) is bool: return "Dozy pending destruction flag must be boolean"
		for stat in ["attack","health","max_health"]:
			if not FriendlyAttack.integer(unit.get(stat,unit.get("health") if stat == "max_health" else null),0 if stat == "attack" else 1): return "Dozy source requires bounded integer " + stat
		if int(unit.get("max_health",unit.health)) < int(unit.health): return "Dozy source Health exceeds maximum"
	var smuggler_issue: String = SmugglerGems.smuggler_unit_error(unit)
	if not smuggler_issue.is_empty(): return smuggler_issue
	var ekkron_issue: String = EkkronSources.unit_error(unit,source_templates if not source_templates.is_empty() else _options.get("hand_card_templates",{}),is_base_unit)
	if not ekkron_issue.is_empty(): return ekkron_issue
	var native_recruit_issue: String = NativeRecruit.unit_error(unit,source_templates if not source_templates.is_empty() else _options.get("hand_card_templates",{}),is_base_unit)
	if not native_recruit_issue.is_empty(): return native_recruit_issue
	var native_battlecry_issue: String = NativeBattlecry.unit_error(unit)
	if not native_battlecry_issue.is_empty(): return native_battlecry_issue
	if Investigator.claimed(unit):
		var investigator_issue: String = Investigator.unit_error(unit,source_templates if not source_templates.is_empty() else _options.get("hand_card_templates",{}),is_base_unit)
		if not investigator_issue.is_empty(): return investigator_issue
	if UtilityDrone.claimed(unit):
		var utility_issue: String = UtilityDrone.unit_error(unit,source_templates if not source_templates.is_empty() else _options.get("hand_card_templates",{}),is_base_unit)
		if not utility_issue.is_empty(): return utility_issue
	if AccordGold.claimed(unit):
		var accord_issue: String = AccordGold.unit_error(unit,source_templates if not source_templates.is_empty() else _options.get("hand_card_templates",{}),is_base_unit)
		if not accord_issue.is_empty(): return accord_issue
	if StartGold.claimed(unit):
		var start_gold_issue: String = StartGold.unit_error(unit,source_templates if not source_templates.is_empty() else _options.get("hand_card_templates",{}),is_base_unit)
		if not start_gold_issue.is_empty(): return start_gold_issue
	if StartFixedGrants.claimed(unit):
		var start_fixed_issue: String = StartFixedGrants.unit_error(unit)
		if not start_fixed_issue.is_empty(): return start_fixed_issue
	if CurrentTierGrants.claimed(unit):
		var current_tier_issue: String = CurrentTierGrants.unit_error(unit)
		if not current_tier_issue.is_empty(): return current_tier_issue
	if FixedGrants.claimed(unit):
		var fixed_issue: String = FixedGrants.unit_error(unit)
		if not fixed_issue.is_empty(): return fixed_issue
	var received_program_issue: String = DamageListenerHost.program_error(unit)
	if not received_program_issue.is_empty(): return received_program_issue
	var beetle_program_issue: String = _beetle_program_error(unit)
	if not beetle_program_issue.is_empty(): return beetle_program_issue
	var friendly_program_issue: String = FriendlyAttack.program_error(unit)
	if not friendly_program_issue.is_empty(): return friendly_program_issue
	var friendly_source: bool = FriendlyAttack.SPECS.has(unit.get("card_id",unit.get("id","")))
	for candidate in unit.get("effects",[]):
		if candidate is Dictionary and candidate.get("type") is String and candidate.get("type") == FriendlyAttack.TYPE: friendly_source = true
	if friendly_source:
		if unit.has("uid") and (not unit.uid is String or unit.uid.is_empty()): return "Friendly attack source UID must be a nonempty String"
		if not unit.get("_pending_destroy",false) is bool: return "Friendly attack pending destruction flag must be boolean"
		if not unit.get("tribes",[]) is Array: return "Friendly attack tribes must be an Array"
		for tribe in unit.get("tribes",[]):
			if not tribe is String: return "Friendly attack tribes must contain Strings"
		for stat in ["attack","health","max_health"]:
			if not FriendlyAttack.integer(unit.get(stat,unit.get("health") if stat == "max_health" else null),0 if stat == "attack" else 1): return "Friendly attack source requires bounded integer " + stat
		if int(unit.get("max_health",unit.health)) < int(unit.health): return "Friendly attack source Health exceeds maximum"
	var aura_shape_issue: String = BoardAura.marker_shape_error(unit)
	if not aura_shape_issue.is_empty(): return aura_shape_issue
	# Recruit passthroughs can contain nested definitions. Inspect the whole
	# dependency tree before any passthrough branch accepts an outer effect.
	if depth == 0:
		var permanent_inspection: Dictionary = PermanentTribeEffects.inspect_unit(unit)
		if not str(permanent_inspection["error"]).is_empty():
			return str(permanent_inspection["error"])
	if depth > 16:
		return "Summon/base_unit nesting exceeds 16 levels"
	var transfer_issue: String = _attack_transfer_program_error(unit)
	if not transfer_issue.is_empty(): return transfer_issue
	if _uses_attack_transfer(unit):
		# Validate before _prepare_unit can coerce a malformed scalar to an int.
		for stat in ["attack", "health", "max_health"]:
			if not AttackTransfer.integer(unit.get(stat, unit.get("health") if stat == "max_health" else null), 0 if stat == "attack" else 1):
				return "Attack-transfer source requires bounded integer " + stat
		if int(unit.get("max_health", unit.health)) < int(unit.health):
			return "Attack-transfer source current Health exceeds maximum Health"
		if unit.has("uid") and (not unit.uid is String or unit.uid.is_empty()):
			return "Attack-transfer source UID must be a nonempty String"
	if int(unit.get("attack", -1)) < 0 or int(unit.get("health", 0)) < 1:
		return "Minion attack must be non-negative and health must be positive: %s" % str(unit.get("name", "unknown"))
	if int(unit.get("tier", 1)) < 0:
		return "Minion tier must be non-negative"
	if not unit.get("keywords", []) is Array or not unit.get("effects", []) is Array:
		return "Minion keywords and effects must be Arrays"
	for keyword in unit.get("keywords", []):
		# Exact historical native Charge is retained. This auto-combat scheduler
		# has no summoning sickness; it grants no extra or immediate attack.
		if keyword=="charge" and BoardAura.OldMurkEye.accepts_id(unit.get("card_id",unit.get("id"))): continue
		if not str(keyword) in COMBAT_KEYWORDS and not str(keyword) in RECRUIT_KEYWORDS:
			return "Unsupported combat keyword: %s" % str(keyword)
	for effect in unit.get("effects", []):
		if not effect is Dictionary:
			return "Each effect must be a Dictionary"
		# Validate this reserved recruit marker before any passthrough; do not execute it.
		if RecruitTargets.is_all_other_shop(effect):
			var recruit_scope_issue: String = RecruitTargets.validate_effect(effect)
			if not recruit_scope_issue.is_empty(): return recruit_scope_issue
		if effect.has("exact_tier"):
			var tier_reward_issue: String = RecruitExtensions.validate_effect(effect)
			if not tier_reward_issue.is_empty(): return tier_reward_issue
		var hired_effect_issue: String = HiredRitualist.effect_error(effect)
		if not hired_effect_issue.is_empty(): return hired_effect_issue
		if NativeRecruit.Upstart.effect_claimed(effect):
			var upstart_effect_issue: String = NativeRecruit.Upstart.effect_error(effect)
			if not upstart_effect_issue.is_empty(): return upstart_effect_issue
			continue
		if effect.get("type")==DefilerPortraitSources.EOT:
			var defiler_leaf_issue: String=DefilerPortraitSources.wrapper_error(unit,effect)
			if not defiler_leaf_issue.is_empty(): return defiler_leaf_issue
		if effect.get("type")==FodderSaleSources.TYPE:
			var fodder_sale_leaf_issue: String=FodderSaleSources.call_error(unit,effect)
			if not fodder_sale_leaf_issue.is_empty(): return fodder_sale_leaf_issue
		if effect.get("type") in [FodderRefresh.Sources.BATTLECRY,FodderRefresh.Sources.DEATHRATTLE,FodderRefresh.Sources.FEED]:
			var fodder_leaf_issue: String=FodderRefresh.Sources.call_error(unit,effect)
			if not fodder_leaf_issue.is_empty(): return fodder_leaf_issue
		if effect.get("type")==OwnedRallyEOTSources.TYPE:
			var owned_rally_leaf_issue: String=OwnedRallyEOTSources.source_error(unit)
			if owned_rally_leaf_issue.is_empty(): owned_rally_leaf_issue=OwnedRallyEOTSources.effect_error(effect)
			if not owned_rally_leaf_issue.is_empty(): return owned_rally_leaf_issue
			continue
		if effect.get("type")==Apexis.Sources.DR:
			var apexis_leaf_issue: String=Apexis.Sources.call_error(unit,effect)
			if not apexis_leaf_issue.is_empty(): return apexis_leaf_issue
			continue
		if effect.get("type") in [FishBait.Sources.ACTIVATE,FishBait.Sources.IMMUNITY,FishBait.Sources.DEATH]:
			var bait_leaf_issue: String=FishBait.Sources.effect_error(effect)
			if not bait_leaf_issue.is_empty(): return bait_leaf_issue
			if effect.get("source_id")!=unit.get("card_id",unit.get("id")): return "fish_bait_wrong_native_leaf_owner"
			continue
		if effect.get("type")==RadioStar.Sources.TYPE:
			var radio_leaf_issue: String=RadioStar.Sources.effect_error(effect)
			if not radio_leaf_issue.is_empty(): return radio_leaf_issue
			if effect.get("source_id")!=unit.get("card_id",unit.get("id")): return "radio_star_wrong_native_leaf_owner"
			continue
		if effect.get("type")==MetalDispenser.Sources.TYPE:
			var metal_leaf_issue: String=MetalDispenser.Sources.effect_error(effect)
			if not metal_leaf_issue.is_empty(): return metal_leaf_issue
			continue
		if effect.get("type")==OwnedTimedSources.TYPE:
			var owned_timed_leaf_issue: String=OwnedTimedSources.effect_error(effect)
			if not owned_timed_leaf_issue.is_empty(): return owned_timed_leaf_issue
			continue
		if effect.get("type")==BattlecryCostSources.TYPE:
			var battlecry_cost_leaf_issue: String=BattlecryCostSources.effect_error(effect)
			if not battlecry_cost_leaf_issue.is_empty(): return battlecry_cost_leaf_issue
			continue
		if effect.get("type")==KeywordGemSources.TYPE:
			var keyword_gem_leaf_issue: String=KeywordGemSources.effect_error(effect)
			if not keyword_gem_leaf_issue.is_empty(): return keyword_gem_leaf_issue
			continue
		if effect.get("type")==ChooseOneGemSources.TYPE:
			var choose_one_gem_leaf_issue: String=ChooseOneGemSources.effect_error(effect)
			if not choose_one_gem_leaf_issue.is_empty(): return choose_one_gem_leaf_issue
			continue
		if effect.get("type")==DiscardGemCopySources.START:
			var discard_gem_leaf_issue: String=DiscardGemCopySources.effect_error(effect)
			if not discard_gem_leaf_issue.is_empty(): return discard_gem_leaf_issue
			continue
		if effect.get("type")==ZestySources.TYPE:
			var zesty_leaf_issue: String=ZestySources.effect_error(effect)
			if not zesty_leaf_issue.is_empty(): return zesty_leaf_issue
			continue
		if effect.get("type")==OwnedRecruitStatSources.TYPE:
			var owned_recruit_stat_leaf_issue: String=OwnedRecruitStatSources.effect_error(effect)
			if not owned_recruit_stat_leaf_issue.is_empty(): return owned_recruit_stat_leaf_issue
			continue
		if effect.get("type")==PurchaseStatSources.TYPE:
			var purchase_stat_leaf_issue: String=PurchaseStatSources.effect_error(effect)
			if not purchase_stat_leaf_issue.is_empty(): return purchase_stat_leaf_issue
			continue
		if effect.get("type") in PurchaseQuotaSources.TYPES:
			var purchase_quota_leaf_issue: String=PurchaseQuotaSources.effect_error(effect)
			if not purchase_quota_leaf_issue.is_empty(): return purchase_quota_leaf_issue
			continue
		if effect.get("type") in LockboxHost.Sources.TYPES:
			var lockbox_leaf_issue: String=LockboxHost.Sources.effect_error(effect)
			if not lockbox_leaf_issue.is_empty(): return lockbox_leaf_issue
			continue
		if NativeRecruit.Cabbie.effect_claimed(effect):
			var cabbie_effect_issue: String = NativeRecruit.Cabbie.effect_error(effect)
			if not cabbie_effect_issue.is_empty(): return cabbie_effect_issue
			continue
		if RebornCombat.effect_claimed(effect):
			var reborn_combat_effect_issue: String=RebornCombat.effect_error(effect)
			if not reborn_combat_effect_issue.is_empty(): return reborn_combat_effect_issue
			continue
		if OriginalJelly.effect_claimed(effect):
			var original_jelly_effect_issue: String = OriginalJelly.effect_error(effect)
			if not original_jelly_effect_issue.is_empty(): return original_jelly_effect_issue
			continue
		if Jelly.effect_claimed(effect):
			var jelly_effect_issue: String = Jelly.effect_error(effect)
			if not jelly_effect_issue.is_empty(): return jelly_effect_issue
			continue
		if Sister.effect_claimed(effect):
			var sister_effect_issue: String = Sister.effect_error(effect)
			if not sister_effect_issue.is_empty(): return sister_effect_issue
			continue
		if Gnoll.effect_claimed(effect):
			var gnoll_effect_issue: String = Gnoll.effect_error(effect)
			if not gnoll_effect_issue.is_empty(): return gnoll_effect_issue
			continue
		if GhoulDeath.effect_claimed(effect):
			var ghoul_effect_issue: String = GhoulDeath.effect_error(effect)
			if not ghoul_effect_issue.is_empty(): return ghoul_effect_issue
			continue
		var effect_type: String = str(effect.get("type", ""))
		if effect_type == MutatedLasher.Sources.TYPE:
			var mutated_lasher_issue: String = MutatedLasher.Sources.program_error(unit)
			if mutated_lasher_issue.is_empty(): mutated_lasher_issue = MutatedLasher.Sources.effect_error(effect)
			if not mutated_lasher_issue.is_empty(): return mutated_lasher_issue
			continue
		if effect_type == DeterminedDefender.Sources.TYPE:
			var determined_defender_issue: String = DeterminedDefender.Sources.program_error(unit)
			if determined_defender_issue.is_empty(): determined_defender_issue = DeterminedDefender.Sources.effect_error(effect)
			if not determined_defender_issue.is_empty(): return determined_defender_issue
			continue
		if effect_type==EliseRefreshSources.TYPE:
			var elise_program_issue: String=EliseRefreshSources.program_error(unit)
			if not elise_program_issue.is_empty(): return elise_program_issue
			continue # Recruit-only real refresh listener.
		if effect_type==CombatKeep.TYPE:
			var keep_effect_issue: String=CombatKeep.effect_error(effect)
			if not keep_effect_issue.is_empty(): return keep_effect_issue
			continue
		if effect_type in RecruitClock.TYPES:
			var clock_effect_issue: String=RecruitClock.effect_error(effect)
			if not clock_effect_issue.is_empty(): return clock_effect_issue
			continue
		if effect_type==AttackGains.TYPE:
			var attack_gain_effect_issue: String=AttackGains.effect_error(effect)
			if not attack_gain_effect_issue.is_empty(): return attack_gain_effect_issue
			continue
		if effect_type in ThresholdDamage.TYPES:
			var threshold_effect_issue: String=ThresholdDamage.effect_error(effect)
			if not threshold_effect_issue.is_empty(): return threshold_effect_issue
			continue
		if effect_type==KillRewards.TYPE:
			var kill_effect_issue: String=KillRewards.effect_error(effect)
			if not kill_effect_issue.is_empty(): return kill_effect_issue
			continue
		if effect_type in DamageFollowupSources.TYPES:
			var followup_effect_issue: String=DamageFollowupSources.effect_error(effect)
			if not followup_effect_issue.is_empty(): return followup_effect_issue
			continue
		if effect_type==HandStartCopy.Sources.TYPE:
			var hand_start_effect_issue: String=HandStartCopy.Sources.effect_error(effect)
			if not hand_start_effect_issue.is_empty(): return hand_start_effect_issue
			continue
		if effect_type==Anchorman.Sources.TYPE:
			var anchorman_effect_issue: String=Anchorman.Sources.effect_error(effect)
			if not anchorman_effect_issue.is_empty(): return anchorman_effect_issue
			continue
		if effect_type==IntrinsicTwice.Sources.TYPE:
			var intrinsic_twice_effect_issue: String=IntrinsicTwice.Sources.effect_error(effect)
			if not intrinsic_twice_effect_issue.is_empty(): return intrinsic_twice_effect_issue
			continue
		if effect_type==LastSpell.Sources.TYPE:
			var last_spell_effect_issue: String=LastSpell.Sources.effect_error(effect)
			if not last_spell_effect_issue.is_empty(): return last_spell_effect_issue
			continue
		if effect_type in BulkResourceHost.NativeSpellcraft.TYPES:
			var native_spellcraft_effect_issue: String=BulkResourceHost.NativeSpellcraft.effect_error(effect)
			if not native_spellcraft_effect_issue.is_empty(): return native_spellcraft_effect_issue
			continue
		if effect_type==VashjSources.BUDDY_TYPE:
			var vashj_effect_issue: String=VashjSources.effect_error(effect)
			if not vashj_effect_issue.is_empty(): return vashj_effect_issue
			continue
		if effect_type in ElementalSources.TYPES:
			var elemental_effect_issue: String=ElementalSources.effect_error(effect)
			if not elemental_effect_issue.is_empty(): return elemental_effect_issue
			continue
		if effect_type==DealtLifetimeSources.TYPE:
			var dealt_lifetime_effect_issue: String=DealtLifetimeSources.effect_error(effect)
			if not dealt_lifetime_effect_issue.is_empty(): return dealt_lifetime_effect_issue
			continue
		if effect_type==TimewarpChimera.TYPE:
			var chimera_effect_issue: String=TimewarpChimera.effect_error(effect)
			if not chimera_effect_issue.is_empty(): return chimera_effect_issue
			continue
		if effect_type in ReceivedNative.TYPES:
			var received_native_effect_issue: String=ReceivedNative.effect_error(effect)
			if not received_native_effect_issue.is_empty(): return received_native_effect_issue
			continue
		if effect_type==DamagePermanent.TYPE:
			var permanent_damage_effect_issue: String=DamagePermanent.effect_error(effect)
			if not permanent_damage_effect_issue.is_empty(): return permanent_damage_effect_issue
			continue
		if effect_type in GlobalCards.Whelps.Sources.TYPES:
			var whelp_source_issue: String=GlobalCards.Whelps.Sources.unit_error(unit)
			if not whelp_source_issue.is_empty(): return whelp_source_issue
			continue
		if effect_type==GlobalCards.Beasts.Sources.TYPE:
			var beast_source_issue: String=GlobalCards.Beasts.Sources.unit_error(unit)
			if not beast_source_issue.is_empty(): return beast_source_issue
			continue
		if effect_type in TradeQuotas.Sources.TYPES:
			var quota_effect_issue: String=TradeQuotas.Sources.effect_error(effect)
			if not quota_effect_issue.is_empty(): return quota_effect_issue
			continue
		if effect_type in HandAcquisition.Sources.TYPES:
			var native_hand_effect_issue: String=HandAcquisition.Sources.effect_error(effect)
			if not native_hand_effect_issue.is_empty(): return native_hand_effect_issue
			continue
		if effect_type == GlobalCards.TYPE:
			var global_effect_issue: String = GlobalCards.effect_error(effect)
			if not global_effect_issue.is_empty(): return global_effect_issue
			continue
		if effect_type in [BulkHeroDamage.TYPE,BulkHeroDamage.Archimonde.TYPE]:
			var hero_damage_effect_issue: String = BulkHeroDamage.effect_error(effect)
			if not hero_damage_effect_issue.is_empty(): return hero_damage_effect_issue
			continue
		if effect_type in BulkKeywords.TYPES:
			var keyword_effect_issue: String = BulkKeywords.effect_error(effect)
			if not keyword_effect_issue.is_empty(): return keyword_effect_issue
			continue
		if effect_type in TradeTriggers.TYPES:
			var trade_effect_issue: String = TradeTriggers.effect_error(effect)
			if not trade_effect_issue.is_empty(): return trade_effect_issue
			continue
		if effect_type in CastResources.TYPES:
			var cast_resource_effect_issue: String=CastResources.effect_error(effect)
			if not cast_resource_effect_issue.is_empty(): return cast_resource_effect_issue
		if effect_type==LivingRecruitDR.TYPE:
			var living_recruit_dr_effect_issue: String=LivingRecruitDR.effect_error(effect)
			if not living_recruit_dr_effect_issue.is_empty(): return living_recruit_dr_effect_issue
		if effect_type==AmalgadonSources.TYPE:
			var amalgadon_effect_issue: String=AmalgadonSources.effect_error(effect)
			if not amalgadon_effect_issue.is_empty(): return amalgadon_effect_issue
			continue # Native recruit-only Battlecry, never automatic combat replay.
		if effect_type==MegaGrants.Sources.TYPE:
			var megasaur_effect_issue: String=MegaGrants.Sources.effect_error(effect)
			if not megasaur_effect_issue.is_empty(): return megasaur_effect_issue
			continue # Recruit-only source-owned choice; never replay it in combat.
		if effect_type==TempDeath.Sources.TYPE:
			var temp_death_spell_issue: String=TempDeath.Sources.effect_error(effect)
			if not temp_death_spell_issue.is_empty(): return temp_death_spell_issue
		if effect_type==RandomSpellcraftSources.TYPE:
			var random_spellcraft_effect_issue: String=RandomSpellcraftSources.effect_error(effect)
			if not random_spellcraft_effect_issue.is_empty(): return random_spellcraft_effect_issue
		if effect_type in [GlobalCards.Volumizers.BATTLECRY,GlobalCards.Volumizers.EOT]:
			var volumizer_program_issue: String=GlobalCards.Volumizers.effect_error(effect)
			if not volumizer_program_issue.is_empty(): return volumizer_program_issue
			continue
		if effect_type==BulkDiscover.NativePayoffs.Sources.TYPE:
			var payoff_program_issue: String=BulkDiscover.NativePayoffs.Sources.unit_error(unit)
			if not payoff_program_issue.is_empty(): return payoff_program_issue
			continue
		if effect_type in BulkDiscover.TYPES:
			var bulk_discover_effect_issue: String = BulkDiscover.effect_error(effect)
			if not bulk_discover_effect_issue.is_empty(): return bulk_discover_effect_issue
			continue
		if StatSpellSources.effect_claimed(effect):
			var stat_spell_effect_issue: String=StatSpellSources.effect_error(effect)
			if not stat_spell_effect_issue.is_empty(): return stat_spell_effect_issue
			continue
		if effect_type == PeriodicEot.TYPE:
			var periodic_effect_issue: String = PeriodicEot.effect_error(effect)
			if not periodic_effect_issue.is_empty(): return periodic_effect_issue
			continue
		if effect_type == BulkTurnCounters.TYPE:
			var bulk_counter_issue: String = BulkTurnCounters.effect_error(effect)
			if not bulk_counter_issue.is_empty(): return bulk_counter_issue
			continue
		if effect_type == GeneratedDiscover.TYPE:
			var generated_effect_issue: String = GeneratedDiscover.effect_error(effect)
			if not generated_effect_issue.is_empty(): return generated_effect_issue
			continue
		if effect_type in BulkRecruit.TYPES:
			var bulk_effect_issue: String = BulkRecruit.effect_error(effect)
			if not bulk_effect_issue.is_empty(): return bulk_effect_issue
			continue
		if CompletedAttack.effect_claimed(effect):
			var completed_effect_issue: String = CompletedAttack.effect_error(effect)
			if not completed_effect_issue.is_empty(): return completed_effect_issue
			continue
		if effect_type == Cruise.TYPE:
			var cruise_effect_issue: String = Cruise.effect_error(effect)
			if not cruise_effect_issue.is_empty(): return cruise_effect_issue
			continue
		if effect_type == Saurolisk.TYPE:
			var saurolisk_effect_issue: String = Saurolisk.effect_error(effect)
			if not saurolisk_effect_issue.is_empty(): return saurolisk_effect_issue
		if NativeBattlecry.effect_claimed(effect): continue # Whole independent native program checked above; recruit-only.
		if effect_type in CurrentTierGrants.TYPES: continue # Exact complete source above; recruit-only.
		if effect_type == FixedGrants.TYPE: continue # Complete native program checked above; recruit-only.
		if effect_type == StartFixedGrants.TYPE: continue # Exact source checked above; never a combat grant.
		if effect_type == UtilityDrone.TYPE: continue # Complete native/attachment provenance checked above.
		if effect_type == BeatboxerSources.TYPE:
			var beatboxer_effect_issue: String=BeatboxerSources.effect_error(effect)
			if not beatboxer_effect_issue.is_empty(): return beatboxer_effect_issue
			continue
		if effect_type == AccordGold.TYPE: continue # Complete native/attachment provenance checked above.
		if effect_type == BarovCoin.TYPE: continue # Whole source above; only one actual recruit hand play can pay.
		if effect_type == StartGold.TYPE: continue # Whole source checked above; never a combat Gold grant.
		if effect_type == Alleycat.TYPE: continue # Full exact native source/base context validated above; recruit-only.
		if effect_type == OutbackSources.TYPE:
			var outback_id: Variant = unit.get("card_id",unit.get("id"))
			if not outback_id is String or outback_id not in OutbackSources.ALL_PARENTS or not OutbackSources.Pure._same(unit.get("effects"),OutbackSources.Pure.definition(outback_id).effects): return "Outback combat input requires its entire native recruit program"
			if not OutbackSources.effect_error(effect).is_empty(): return "Invalid Outback effect"
			continue
		if effect_type == "damage_received" or effect_type in DamageResource.TYPES: continue # Complete exact source checked above.
		if effect_type in BeetleHost.TYPES: continue # Whole native program validated above.
		if effect_type in CombatEconomy.Sources.TYPES:
			var economy_effect_issue: String = CombatEconomy.Sources.effect_error(effect)
			if not economy_effect_issue.is_empty(): return economy_effect_issue
		if effect_type in DelayedGold.TYPES:
			var delayed_issue: String = DelayedGold.validate_effect(effect)
			if not delayed_issue.is_empty(): return delayed_issue
			var delayed_id: String = str(unit.get("card_id",unit.get("id","")))
			if not DelayedGold.has_source(delayed_id) or effect not in DelayedGold.effects_for_id(delayed_id): return "Delayed gold effect needs its independent native source identity"
		if effect_type in TavernAmplifier.TYPES:
			var amp_issue: String = TavernAmplifier.validate_effect(effect)
			if not amp_issue.is_empty(): return amp_issue
		if effect_type == NextSpellDiscount.TYPE:
			var next_discount_issue: String = NextSpellDiscount.validate_effect(effect)
			if not next_discount_issue.is_empty(): return next_discount_issue
		if effect_type in PermanentTribeEffects.TYPES:
			var permanent_issue: String = PermanentTribeEffects.effect_error(effect)
			if not permanent_issue.is_empty(): return permanent_issue
			continue
		if effect_type in PersistentShopEffects.TYPES:
			var shop_error: String = PersistentShopEffects.validate_effect(effect)
			if not shop_error.is_empty():
				return shop_error
			continue
		var refresh_issue: String = HeroPowerRefresh.validate_effect(effect)
		if not refresh_issue.is_empty(): return refresh_issue
		var listener_issue: String = HeroPowerListeners.validate_effect(effect)
		if not listener_issue.is_empty(): return listener_issue
		var income_issue: String = GoldIncome.validate_effect(effect)
		if not income_issue.is_empty(): return income_issue
		var activate_issue: String = MinionActivate.validate_effect(effect)
		if not activate_issue.is_empty(): return activate_issue
		var copy_issue: String = PurchaseSpellCopy.validate_effect(effect)
		if not copy_issue.is_empty(): return copy_issue
		var discover_issue: String = MinionDiscover.validate_effect(effect)
		if not discover_issue.is_empty(): return discover_issue
		if effect_type in RecruitHand.TYPES:
			var recruit_hand_issue: String = RecruitHand.validate_effect(effect)
			if not recruit_hand_issue.is_empty(): return recruit_hand_issue
		if effect_type in RecruitCounters.TYPES:
			var counter_issue:String=RecruitCounters.validate_effect(effect)
			if not counter_issue.is_empty():return counter_issue
		if effect_type == ChooseOne.TYPE:
			var choice_issue: String = ChooseOne.effect_error(effect)
			if not choice_issue.is_empty(): return choice_issue
		if effect_type == HeroImmunity.TYPE:
			if unit.get("card_id",unit.get("id","")) not in HeroImmunity.SOURCES: return "Hero immunity source identity is not native"
			var immunity_issue: String = HeroImmunity.effect_error(effect)
			if not immunity_issue.is_empty(): return immunity_issue
			continue
		if effect_type == BoardAura.EFFECT_TYPE:
			var aura_issue: String = BoardAura.effect_error(effect)
			if not aura_issue.is_empty(): return aura_issue
			continue
		if effect_type == TradeStat.TYPE:
			var trade_issue: String = TradeStat.validate_effect(effect)
			if not trade_issue.is_empty(): return trade_issue
		if effect_type == EndTurnRepeats.TYPE:
			var eot_issue: String = EndTurnRepeats.validate_effect(effect)
			if not eot_issue.is_empty(): return eot_issue
		if effect_type in CardPlayParity.TYPES:
			var parity_issue: String = CardPlayParity.validate_effect(effect)
			if not parity_issue.is_empty(): return parity_issue
		if effect_type == SpellCastListeners.TYPE:
			var cast_issue: String = SpellCastListeners.validate_effect(effect)
			if not cast_issue.is_empty(): return cast_issue
		if effect_type == Duelist.TYPE:
			var duelist_effect_issue: String = Duelist.effect_error(effect)
			if not duelist_effect_issue.is_empty(): return duelist_effect_issue
		if effect_type == RefreshListeners.TYPE:
			var refresh_shape_ok: bool = false
			for refresh_identity in RefreshListeners.EFFECTS:
				if RefreshListeners.effect_error(refresh_identity, effect).is_empty():
					refresh_shape_ok = true
					break
			if not refresh_shape_ok: return "Unsupported after_tavern_refresh_rightmost effect schema"
		if effect_type == "battlecry_blood_gem" and effect.get("scope", "target") == "all_other":
			continue # Complete independent Gem Smuggler program validated above; recruit-only.
		var argent_effect_issue: String = ArgentBraggart.effect_error(effect)
		if not argent_effect_issue.is_empty(): return argent_effect_issue
		if effect_type==EyeSargerasSources.TYPE:
			var eye_effect_issue: String=EyeSargerasSources.effect_error(effect)
			if not eye_effect_issue.is_empty(): return eye_effect_issue
		if effect_type==KerriganLifecycle.Sources.TYPE:
			var kerrigan_hero_effect_issue: String=KerriganLifecycle.Sources.effect_error(effect)
			if not kerrigan_hero_effect_issue.is_empty(): return kerrigan_hero_effect_issue
		if effect_type in KerriganZerg.Sources.TYPES:
			var kerrigan_effect_issue: String=KerriganZerg.Sources.effect_error(effect)
			if not kerrigan_effect_issue.is_empty(): return kerrigan_effect_issue
		if effect_type in [SpellteachSources.TYPE,SpellteachSources.CAST]:
			var spellteach_effect_issue: String=SpellteachSources.effect_error(effect)
			if not spellteach_effect_issue.is_empty(): return spellteach_effect_issue
		if effect_type==AristocratSources.TYPE:
			var aristocrat_effect_issue: String=AristocratSources.effect_error(effect)
			if not aristocrat_effect_issue.is_empty(): return aristocrat_effect_issue
		if effect_type in RECRUIT_EFFECTS:
			continue
		if effect_type=="friendly_windfury_mega_aura":
			var mega_identity: String=str(unit.get("card_id",unit.get("id","")))
			if not MEGA_AURA_PROGRAMS.has(mega_identity) or unit.effects!=MEGA_AURA_PROGRAMS[mega_identity]: return "mega_windfury_aura_wrong_native_source"
			continue
		if effect_type==Thornspike.Sources.TYPE:
			var thornspike_effect_issue: String=Thornspike.Sources.effect_error(effect)
			if not thornspike_effect_issue.is_empty(): return thornspike_effect_issue
			continue
		if effect_type==EnhancedSpawn.Sources.TYPE:
			var enhanced_spawn_effect_issue: String=EnhancedSpawn.Sources.effect_error(effect)
			if not enhanced_spawn_effect_issue.is_empty(): return enhanced_spawn_effect_issue
			continue # Native EOT is not a combat trigger.
		if effect_type==ValithriaEntry.Sources.TYPE:
			var valithria_entry_effect_issue: String=ValithriaEntry.Sources.effect_error(effect)
			if not valithria_entry_effect_issue.is_empty(): return valithria_entry_effect_issue
			continue
		if not effect_type in COMBAT_EFFECTS:
			return "Unsupported combat effect: %s" % effect_type
		if effect_type in CombatTribeBonuses.TYPES:
			var tribe_issue: String = CombatTribeBonuses.effect_error(effect)
			if not tribe_issue.is_empty(): return tribe_issue
			continue
		if effect_type in SHIELD_EVENT_TYPES:
			var shield_error: String = _validate_shield_event(effect)
			if not shield_error.is_empty():
				return shield_error
			continue
		if effect_type == HandSummon.SELF_TYPE:
			var hand_trigger_issue: String = HandSummon.trigger_effect_error(effect)
			if not hand_trigger_issue.is_empty(): return hand_trigger_issue
		if effect_type == HandSummon.TYPE:
			var hand_summon_issue: String = HandSummon.effect_error(effect)
			if not hand_summon_issue.is_empty(): return hand_summon_issue
			continue
		if effect_type in CombatHand.EFFECT_TYPES:
			var hand_error: String = CombatHand.effect_error(effect)
			if not hand_error.is_empty():
				return hand_error
			continue
		if effect_type == AttackTransfer.TYPE:
			var transfer_effect_issue: String = AttackTransfer.effect_error(effect)
			if not transfer_effect_issue.is_empty(): return transfer_effect_issue
			continue
		if effect_type == SummonOverflow.Sources.TYPE:
			var overflow_effect_issue: String = SummonOverflow.Sources.effect_error(effect)
			if not overflow_effect_issue.is_empty(): return overflow_effect_issue
			var overflow_token_issue: String = _validate_unit(effect.unit,depth+1)
			if not overflow_token_issue.is_empty(): return overflow_token_issue
			continue
		match effect_type:
			TokenOldGodsSources.TYPE,TokenOldGodsSources.OWNED:
				var token_old_gods_effect: String=TokenOldGodsSources.effect_error(effect)
				if not token_old_gods_effect.is_empty(): return token_old_gods_effect
			RicketySources.TYPE:
				var rickety_effect_issue: String=RicketySources.effect_error(effect)
				if not rickety_effect_issue.is_empty(): return rickety_effect_issue
			GretaSources.TYPE:
				var greta_effect_issue: String=GretaSources.effect_error(effect)
				if not greta_effect_issue.is_empty(): return greta_effect_issue
			Tony.Sources.TYPE:
				var tony_effect_issue: String=Tony.Sources.effect_error(effect)
				if not tony_effect_issue.is_empty(): return tony_effect_issue
			AvengePoison.Sources.TYPE:
				var avenge_poison_effect_issue: String=AvengePoison.Sources.effect_error(effect)
				if not avenge_poison_effect_issue.is_empty(): return avenge_poison_effect_issue
			GemGolem.Sources.DEATH:
				var gem_golem_effect_issue: String=GemGolem.Sources.effect_error(effect)
				if not gem_golem_effect_issue.is_empty(): return gem_golem_effect_issue
			Lantern.Sources.TYPE:
				var lantern_effect_issue: String=Lantern.Sources.effect_error(effect)
				if not lantern_effect_issue.is_empty(): return lantern_effect_issue
			WhistleSources.TYPE:
				var whistle_effect_issue: String=WhistleSources.effect_error(effect)
				if not whistle_effect_issue.is_empty(): return whistle_effect_issue
			CubeSources.TYPE:
				var cube_effect_issue: String=CubeSources.effect_error(effect)
				if not cube_effect_issue.is_empty(): return cube_effect_issue
			VouchersSources.TYPE:
				var vouchers_effect_issue: String=VouchersSources.effect_error(effect)
				if not vouchers_effect_issue.is_empty(): return vouchers_effect_issue
			FactoryLineSources.TYPE:
				var factory_line_effect_issue: String=FactoryLineSources.effect_error(effect)
				if not factory_line_effect_issue.is_empty(): return factory_line_effect_issue
			OnFireSources.TYPE:
				var on_fire_effect_issue: String=OnFireSources.effect_error(effect)
				if not on_fire_effect_issue.is_empty(): return on_fire_effect_issue
			ClockworkSources.TYPE:
				var clockwork_effect_issue: String=ClockworkSources.effect_error(effect)
				if not clockwork_effect_issue.is_empty(): return clockwork_effect_issue
			ShacklesSources.TYPE:
				var shackles_effect_issue: String=ShacklesSources.effect_error(effect)
				if not shackles_effect_issue.is_empty(): return shackles_effect_issue
			AnomalousTwinsSources.TYPE:
				var anomalous_twins_effect_issue: String=AnomalousTwinsSources.effect_error(effect)
				if not anomalous_twins_effect_issue.is_empty(): return anomalous_twins_effect_issue
			AntiGravitySources.TYPE:
				var anti_gravity_effect_issue: String=AntiGravitySources.effect_error(effect)
				if not anti_gravity_effect_issue.is_empty(): return anti_gravity_effect_issue
			RecklessSources.TYPE:
				var reckless_enhancement_effect_issue: String=RecklessSources.effect_error(effect)
				if not reckless_enhancement_effect_issue.is_empty(): return reckless_enhancement_effect_issue
			PerfectedSources.TYPE:
				var perfected_alchemy_effect_issue: String=PerfectedSources.effect_error(effect)
				if not perfected_alchemy_effect_issue.is_empty(): return perfected_alchemy_effect_issue
			GoldenArrowSources.TYPE:
				var golden_arrow_effect_issue: String=GoldenArrowSources.effect_error(effect)
				if not golden_arrow_effect_issue.is_empty(): return golden_arrow_effect_issue
			EvilTwinSources.TYPE:
				var evil_twin_effect_issue: String=EvilTwinSources.effect_error(effect)
				if not evil_twin_effect_issue.is_empty(): return evil_twin_effect_issue
			KidnapSackSources.TYPE,KidnapSackSources.SPELL_TYPE:
				var kidnap_sack_effect_issue: String=KidnapSackSources.effect_error(effect)
				if not kidnap_sack_effect_issue.is_empty(): return kidnap_sack_effect_issue
			GoldenHammerSources.TYPE,GoldenHammerSources.SPELL_TYPE:
				var golden_hammer_effect_issue: String=GoldenHammerSources.effect_error(effect)
				if not golden_hammer_effect_issue.is_empty(): return golden_hammer_effect_issue
			FalseIdolsSources.TYPE:
				var false_idols_effect_issue: String=FalseIdolsSources.effect_error(effect)
				if not false_idols_effect_issue.is_empty(): return false_idols_effect_issue
			PartnerInCrimeSources.TYPE:
				var partner_in_crime_effect_issue: String=PartnerInCrimeSources.effect_error(effect)
				if not partner_in_crime_effect_issue.is_empty(): return partner_in_crime_effect_issue
			PilferedLampsSources.TYPE:
				var pilfered_lamps_effect_issue: String=PilferedLampsSources.effect_error(effect)
				if not pilfered_lamps_effect_issue.is_empty(): return pilfered_lamps_effect_issue
			SecretSinstoneSources.TYPE:
				var secret_sinstone_effect_issue: String=SecretSinstoneSources.effect_error(effect)
				if not secret_sinstone_effect_issue.is_empty(): return secret_sinstone_effect_issue
			VictimSpecterSources.TYPE:
				var victim_specter_effect_issue: String=VictimSpecterSources.effect_error(effect)
				if not victim_specter_effect_issue.is_empty(): return victim_specter_effect_issue
			EnergyRecycling.Sources.TYPE:
				if not EnergyRecycling.Sources.effect_error(effect).is_empty(): return "energy_recycling_changed_effect"
			GrimFreshenerSources.TYPE:
				var grim_freshener_effect_issue: String=GrimFreshenerSources.effect_error(effect)
				if not grim_freshener_effect_issue.is_empty(): return grim_freshener_effect_issue
			SnickerSnacksSources.TYPE:
				var snicker_snacks_effect_issue: String=SnickerSnacksSources.effect_error(effect)
				if not snicker_snacks_effect_issue.is_empty(): return snicker_snacks_effect_issue
			ExquisiteConchSources.TYPE:
				var exquisite_conch_effect_issue: String=ExquisiteConchSources.effect_error(effect)
				if not exquisite_conch_effect_issue.is_empty(): return exquisite_conch_effect_issue
			VolatileVenomSources.TYPE:
				var volatile_venom_effect_issue: String=VolatileVenomSources.effect_error(effect)
				if not volatile_venom_effect_issue.is_empty(): return volatile_venom_effect_issue
			AlterEgoSources.TYPE:
				var alter_ego_effect_issue: String=AlterEgoSources.effect_error(effect)
				if not alter_ego_effect_issue.is_empty(): return alter_ego_effect_issue
			StolenGoldSources.TYPE:
				var stolen_gold_effect_issue: String=StolenGoldSources.effect_error(effect)
				if not stolen_gold_effect_issue.is_empty(): return stolen_gold_effect_issue
			BombSquadSources.TYPE:
				var bomb_squad_effect_issue: String=BombSquadSources.effect_error(effect)
				if not bomb_squad_effect_issue.is_empty(): return bomb_squad_effect_issue
			TheotarParasolSources.TYPE:
				var theotar_parasol_effect_issue: String=TheotarParasolSources.effect_error(effect)
				if not theotar_parasol_effect_issue.is_empty(): return theotar_parasol_effect_issue
			EleventhHourSources.TYPE:
				var eleventh_hour_effect_issue: String=EleventhHourSources.effect_error(effect)
				if not eleventh_hour_effect_issue.is_empty(): return eleventh_hour_effect_issue
			AggramarSources.TYPE:
				var aggramar_effect_issue: String=AggramarSources.effect_error(effect)
				if not aggramar_effect_issue.is_empty(): return aggramar_effect_issue
			UpsetSources.TYPE:
				var uncompensated_upset_effect_issue: String=UpsetSources.effect_error(effect)
				if not uncompensated_upset_effect_issue.is_empty(): return uncompensated_upset_effect_issue
			TempestSources.TYPE:
				var golganneth_tempest_effect_issue: String=TempestSources.effect_error(effect)
				if not golganneth_tempest_effect_issue.is_empty(): return golganneth_tempest_effect_issue
			DoubleHeaderSources.TYPE:
				var double_header_effect_issue: String=DoubleHeaderSources.effect_error(effect)
				if not double_header_effect_issue.is_empty(): return double_header_effect_issue
			ArgusSources.TYPE:
				var echoes_argus_effect_issue: String=ArgusSources.effect_error(effect)
				if not echoes_argus_effect_issue.is_empty(): return echoes_argus_effect_issue
			TemperanceSources.TYPE:
				var temperance_effect_issue: String=TemperanceSources.effect_error(effect)
				if not temperance_effect_issue.is_empty(): return temperance_effect_issue
			WishboneSources.TYPE:
				var wishbone_effect_issue: String=WishboneSources.effect_error(effect)
				if not wishbone_effect_issue.is_empty(): return wishbone_effect_issue
			SinstoneSources.TYPE:
				var sinstone_effect_issue: String=SinstoneSources.effect_error(effect)
				if not sinstone_effect_issue.is_empty(): return sinstone_effect_issue
			LocketSources.TYPE:
				var locket_effect_issue: String=LocketSources.effect_error(effect)
				if not locket_effect_issue.is_empty(): return locket_effect_issue
			CathedralSources.TYPE:
				var cathedral_effect_issue: String=CathedralSources.effect_error(effect)
				if not cathedral_effect_issue.is_empty(): return cathedral_effect_issue
			BoomController.Sources.TYPE:
				var boom_controller_effect_issue: String=BoomController.Sources.effect_error(effect)
				if not boom_controller_effect_issue.is_empty(): return boom_controller_effect_issue
			Fermenter.Sources.TYPE:
				var soul_fermenter_effect_issue: String=Fermenter.Sources.effect_error(effect)
				if not soul_fermenter_effect_issue.is_empty(): return soul_fermenter_effect_issue
			Bonerender.Sources.TYPE:
				var bonerender_effect_issue: String=Bonerender.Sources.effect_error(effect)
				if not bonerender_effect_issue.is_empty(): return bonerender_effect_issue
			Khadgar.Sources.TYPE:
				var khadgar_effect_issue: String=Khadgar.Sources.effect_error(effect)
				if not khadgar_effect_issue.is_empty(): return khadgar_effect_issue
			Elistra.Sources.TYPE:
				var elistra_effect_issue: String=Elistra.Sources.effect_error(effect)
				if not elistra_effect_issue.is_empty(): return elistra_effect_issue
			Matador.Sources.TYPE:
				var matador_effect_issue: String=Matador.Sources.effect_error(effect)
				if not matador_effect_issue.is_empty(): return matador_effect_issue
			Worgen.Sources.TYPE:
				var worgen_effect_issue: String=Worgen.Sources.effect_error(effect)
				if not worgen_effect_issue.is_empty(): return worgen_effect_issue
			FirstAttack.Sources.TYPE:
				var first_attack_effect_issue: String=FirstAttack.Sources.effect_error(effect)
				if not first_attack_effect_issue.is_empty(): return first_attack_effect_issue
			Sinestra.TYPE:
				var sinestra_effect_issue: String=Sinestra.effect_error(effect)
				if not sinestra_effect_issue.is_empty(): return sinestra_effect_issue
			Stoneshell.Sources.TYPE:
				var stoneshell_effect_issue: String=Stoneshell.Sources.effect_error(effect)
				if not stoneshell_effect_issue.is_empty(): return stoneshell_effect_issue
			CombatRingCast.AttackSources.TYPE:
				var friendly_attack_ring_effect_issue: String=CombatRingCast.AttackSources.effect_error(effect)
				if not friendly_attack_ring_effect_issue.is_empty(): return friendly_attack_ring_effect_issue
			CombatRingCast.QueenSources.DEATH:
				var queensguard_leaf_issue: String=CombatRingCast.QueenSources.effect_error(effect)
				if not queensguard_leaf_issue.is_empty(): return queensguard_leaf_issue
			CombatRingCast.Sources.TYPE:
				var combat_ring_effect_issue: String=CombatRingCast.Sources.effect_error(effect)
				if not combat_ring_effect_issue.is_empty(): return combat_ring_effect_issue
			WhelpSummon.Sources.TYPE:
				var whelp_summon_effect_issue: String=WhelpSummon.Sources.effect_error(effect)
				if not whelp_summon_effect_issue.is_empty(): return whelp_summon_effect_issue
			RylakBattlecry.Sources.TYPE:
				var rylak_battlecry_effect_issue: String=RylakBattlecry.Sources.effect_error(effect)
				if not rylak_battlecry_effect_issue.is_empty(): return rylak_battlecry_effect_issue
			AdjacentTide.Sources.TYPE:
				var adjacent_tide_effect_issue: String=AdjacentTide.Sources.effect_error(effect)
				if not adjacent_tide_effect_issue.is_empty(): return adjacent_tide_effect_issue
			HagReborn.Sources.TYPE:
				var hag_reborn_effect_issue: String=HagReborn.Sources.effect_error(effect)
				if not hag_reborn_effect_issue.is_empty(): return hag_reborn_effect_issue
			CombatGolden.Sources.START,CombatGolden.Sources.DEATH:
				var combat_golden_effect_issue: String=CombatGolden.Sources.effect_error(effect)
				if not combat_golden_effect_issue.is_empty(): return combat_golden_effect_issue
			MaximumImp.Sources.TYPE:
				var maximum_imp_effect_issue: String=MaximumImp.Sources.effect_error(effect)
				if not maximum_imp_effect_issue.is_empty(): return maximum_imp_effect_issue
				maximum_imp_effect_issue=MaximumImp.Sources.template_error(source_templates.get(MaximumImp.Sources.CHILD,_options.get("hand_card_templates",{}).get(MaximumImp.Sources.CHILD,{})))
				if not maximum_imp_effect_issue.is_empty(): return maximum_imp_effect_issue
			GemLedgerTransfer.Sources.TYPE:
				var gem_ledger_transfer_effect_issue: String=GemLedgerTransfer.Sources.effect_error(effect)
				if not gem_ledger_transfer_effect_issue.is_empty(): return gem_ledger_transfer_effect_issue
			GemSummon.Sources.AURA,GemSummon.Sources.DEATH:
				var gem_summon_effect_issue: String=GemSummon.Sources.effect_error(effect)
				if not gem_summon_effect_issue.is_empty(): return gem_summon_effect_issue
			CombatGemTriggers.Sources.ATTACK,CombatGemTriggers.Sources.AVENGE,CombatGemTriggers.Sources.DEATH:
				var combat_gem_trigger_effect_issue: String=CombatGemTriggers.Sources.effect_error(effect)
				if not combat_gem_trigger_effect_issue.is_empty(): return combat_gem_trigger_effect_issue
			CombatTransforms.TYPE, CombatTransforms.START_TYPE:
				var combat_transform_effect_issue: String=CombatTransforms.effect_error(effect)
				if not combat_transform_effect_issue.is_empty(): return combat_transform_effect_issue
			CombatCopies.TYPE:
				var combat_copy_effect_issue: String=CombatCopies.effect_error(effect)
				if not combat_copy_effect_issue.is_empty(): return combat_copy_effect_issue
			BulkHandSummon.TYPE:
				var bulk_hand_effect_issue: String=BulkHandSummon.effect_error(effect)
				if not bulk_hand_effect_issue.is_empty(): return bulk_hand_effect_issue
			DeferredHand.TYPE:
				var deferred_hand_effect_issue: String=DeferredHand.effect_error(effect)
				if not deferred_hand_effect_issue.is_empty(): return deferred_hand_effect_issue
			Knights.TYPE, Knights.AVENGE_TYPE:
				var knight_effect_issue: String=Knights.effect_error(effect)
				if not knight_effect_issue.is_empty(): return knight_effect_issue
			SalvagerSources.START,SalvagerSources.TYPE:
				var salvager_effect_issue: String=SalvagerSources.effect_error(effect)
				if not salvager_effect_issue.is_empty(): return salvager_effect_issue
			Protoss.Sources.ATTACK,Protoss.Sources.CARRIER,Protoss.Sources.RESOURCE:
				var protoss_effect_issue: String=Protoss.Sources.effect_error(effect)
				if not protoss_effect_issue.is_empty(): return protoss_effect_issue
			Lobster.Sources.TYPE:
				var lobster_effect_issue: String=Lobster.Sources.effect_error(effect)
				if not lobster_effect_issue.is_empty(): return lobster_effect_issue
			Leviathan.Sources.TYPE:
				var leviathan_effect_issue: String=Leviathan.Sources.effect_error(effect)
				if not leviathan_effect_issue.is_empty(): return leviathan_effect_issue
			Hopebringer.Sources.START,Hopebringer.Sources.GROW:
				var hopebringer_effect_issue: String=Hopebringer.Sources.effect_error(effect)
				if not hopebringer_effect_issue.is_empty(): return hopebringer_effect_issue
			Octosari.Sources.TYPE,Octosari.Sources.GROW:
				var octosari_effect_issue: String=Octosari.Sources.effect_error(effect)
				if not octosari_effect_issue.is_empty(): return octosari_effect_issue
			SilithidSources.TYPE,SilithidSources.GROW:
				var silithid_effect_issue: String=SilithidSources.effect_error(effect)
				if not silithid_effect_issue.is_empty(): return silithid_effect_issue
			ShieldTaunt.TYPE:
				var shield_taunt_effect_issue: String=ShieldTaunt.effect_error(effect)
				if not shield_taunt_effect_issue.is_empty(): return shield_taunt_effect_issue
			NativeEnforcer.Sources.Enforcer.TYPE,NativeEnforcer.Sources.Bolvar.TYPE:
				var native_enforcer_effect_issue: String=NativeEnforcer.Sources.effect_error(effect)
				if not native_enforcer_effect_issue.is_empty(): return native_enforcer_effect_issue
			ShieldPermanent.Sources.TYPE:
				var shield_permanent_effect_issue: String=ShieldPermanent.Sources.effect_error(effect)
				if not shield_permanent_effect_issue.is_empty(): return shield_permanent_effect_issue
			ShinyLayer.Sources.TYPE:
				var shiny_layer_effect_issue: String=ShinyLayer.Sources.effect_error(effect)
				if not shiny_layer_effect_issue.is_empty(): return shiny_layer_effect_issue
			StartChoice.Sources.WHITE,StartChoice.Sources.MANTID:
				var start_choice_effect_issue: String=StartChoice.Sources.effect_error(effect)
				if not start_choice_effect_issue.is_empty(): return start_choice_effect_issue
			KeywordLoss.Sources.TYPE:
				var keyword_loss_effect_issue: String=KeywordLoss.Sources.effect_error(effect)
				if not keyword_loss_effect_issue.is_empty(): return keyword_loss_effect_issue
			LinkedUndead.Sources.DEATH:
				var linked_undead_effect_issue: String=LinkedUndead.Sources.effect_error(effect)
				if not linked_undead_effect_issue.is_empty(): return linked_undead_effect_issue
			DeityRecruitDRSources.TYPE:
				var deity_recruit_dr_effect_issue: String=DeityRecruitDRSources.effect_error(effect)
				if not deity_recruit_dr_effect_issue.is_empty(): return deity_recruit_dr_effect_issue
			DeityCombat.Sources.AWAKEN,DeityCombat.Sources.DEATH:
				var deity_native_effect_issue: String=DeityCombat.Sources.effect_error(effect)
				if not deity_native_effect_issue.is_empty(): return deity_native_effect_issue
			MaximumHistorySources.TYPE:
				var maximum_history_effect_issue: String=MaximumHistorySources.effect_error(effect)
				if not maximum_history_effect_issue.is_empty(): return maximum_history_effect_issue
			TechnicianKiller.TYPE:
				var technician_native_effect_issue: String=TechnicianKiller.effect_error(effect)
				if not technician_native_effect_issue.is_empty(): return technician_native_effect_issue
			WhirlGroups.TYPE:
				var whirl_native_effect_issue: String=WhirlGroups.effect_error(effect)
				if not whirl_native_effect_issue.is_empty(): return whirl_native_effect_issue
			DevourerSouls.Sources.TYPE:
				var devourer_souls_effect_issue: String=DevourerSouls.Sources.effect_error(effect)
				if not devourer_souls_effect_issue.is_empty(): return devourer_souls_effect_issue
			FishGroups.TYPE:
				var fish_native_effect_issue: String=FishGroups.effect_error(effect)
				if not fish_native_effect_issue.is_empty(): return fish_native_effect_issue
			EachTypePermanent.TYPE:
				var each_type_effect_issue: String=EachTypePermanent.effect_error(effect)
				if not each_type_effect_issue.is_empty(): return each_type_effect_issue
			KrushPreemptive.TYPE:
				var krush_effect_issue: String=KrushPreemptive.effect_error(effect)
				if not krush_effect_issue.is_empty(): return krush_effect_issue
			NativeDRTriggers.DEATH:
				var native_dr_effect_issue: String=NativeDRTriggers.effect_error(effect)
				if not native_dr_effect_issue.is_empty(): return native_dr_effect_issue
			LivingDeathrattles.TYPE, LivingDeathrattles.START_TYPE:
				var living_dr_effect_issue: String=LivingDeathrattles.effect_error(effect)
				if not living_dr_effect_issue.is_empty(): return living_dr_effect_issue
			RebornGrants.TYPE, RebornGrants.START_TYPE:
				var grant_effect_issue: String=RebornGrants.effect_error(effect)
				if not grant_effect_issue.is_empty(): return grant_effect_issue
			BattlecruiserMissileSources.PASSIVE:
				var missile_effect_issue: String=BattlecruiserMissileSources.passive_error(effect)
				if not missile_effect_issue.is_empty(): return missile_effect_issue
			BattlecruiserConstructionSources.PASSIVE:
				var construction_effect_issue: String=BattlecruiserConstructionSources.passive_error(effect)
				if not construction_effect_issue.is_empty(): return construction_effect_issue
			BattlecruiserUltraSources.PASSIVE:
				var ultra_effect_issue: String=BattlecruiserUltraSources.passive_error(effect)
				if not ultra_effect_issue.is_empty(): return ultra_effect_issue
			RebornRetention.TYPE:
				var retention_effect_issue: String=RebornRetention.effect_error(effect)
				if not retention_effect_issue.is_empty(): return retention_effect_issue
			SummonAttempt.TYPE, SummonAttempt.CAPACITY_TYPE:
				var summon_attempt_effect_issue: String=SummonAttempt.effect_error(effect)
				if not summon_attempt_effect_issue.is_empty(): return summon_attempt_effect_issue
			SummonPermanent.TYPE, SummonPermanent.CONDITIONAL_TYPE:
				var summon_permanent_effect_issue: String=SummonPermanent.effect_error(effect)
				if not summon_permanent_effect_issue.is_empty(): return summon_permanent_effect_issue
			"start_combat_stats":
				var start_error: String = _validate_start_combat_stats(effect)
				if not start_error.is_empty():
					return start_error
			"on_friendly_summon":
				var summon_error: String = _validate_friendly_summon(effect, depth)
				if not summon_error.is_empty():
					return summon_error
			"on_friendly_death":
				var death_error: String = _validate_friendly_death(effect, depth)
				if not death_error.is_empty():
					return death_error
			"rally":
				var rally_error: String = _validate_rally(effect, depth, unit, source_templates if not source_templates.is_empty() else _options.get("hand_card_templates",{}), is_base_unit)
				if not rally_error.is_empty():
					return rally_error
			"deathrattle_source_max_stats":
				if effect.keys().size()!=2 or effect.get("scope")!="random_other": return "source max stat transfer requires random_other"
			"deathrattle_random_temporary_summon":
				if effect.size() not in [3,4,5] or not _rally_integer(effect.get("count"),1) or effect.get("filter") not in ["deathrattle","海盗","亡灵","野兽","divine_shield","cost_one","cost_two","cost_four","any"]: return "Invalid temporary random summon"
				if effect.has("set_stats") and not _rally_integer(effect.set_stats,1): return "Invalid summoned stat set"
				if effect.has("tier_sequence") and (effect.tier_sequence!=[2,3,4] or int(effect.count)!=3 or not effect.get("golden") is bool): return "Invalid tier summon sequence"
			OverkillSources.TYPE:
				var overkill_effect_issue: String=OverkillSources.effect_error(effect)
				if not overkill_effect_issue.is_empty(): return overkill_effect_issue
			InventomaticSources.TYPE:
				var inventomatic_effect_issue: String=InventomaticSources.effect_error(effect)
				if not inventomatic_effect_issue.is_empty(): return inventomatic_effect_issue
			Piranha.Sources.TYPE:
				var piranha_effect_issue: String=Piranha.Sources.effect_error(effect)
				if not piranha_effect_issue.is_empty(): return piranha_effect_issue
			HandMurlocGain.Sources.TYPE:
				var hand_murloc_gain_effect_issue: String=HandMurlocGain.Sources.effect_error(effect)
				if not hand_murloc_gain_effect_issue.is_empty(): return hand_murloc_gain_effect_issue
			RecurringNightmare.Sources.TYPE:
				var recurring_nightmare_effect_issue: String=RecurringNightmare.Sources.effect_error(effect)
				if not recurring_nightmare_effect_issue.is_empty(): return recurring_nightmare_effect_issue
			RadiantEmber.Sources.TYPE:
				var radiant_ember_effect_issue: String=RadiantEmber.Sources.effect_error(effect)
				if not radiant_ember_effect_issue.is_empty(): return radiant_ember_effect_issue
			Seaside.Sources.TYPE:
				var seaside_effect_issue: String=Seaside.Sources.effect_error(effect)
				if not seaside_effect_issue.is_empty(): return seaside_effect_issue
			LocPrince.Sources.TYPE:
				var loc_effect_issue: String=LocPrince.Sources.effect_error(effect)
				if not loc_effect_issue.is_empty(): return loc_effect_issue
			MasterRealities.Cthun.TYPE:
				var cthun_effect_issue: String=MasterRealities.Cthun.effect_error(effect)
				if not cthun_effect_issue.is_empty(): return cthun_effect_issue
			MasterRealities.Titanic.TYPE:
				var titanic_effect_issue: String=MasterRealities.Titanic.effect_error(effect)
				if not titanic_effect_issue.is_empty(): return titanic_effect_issue
			MasterRealities.Ragescale.TYPE:
				var ragescale_effect_issue: String=MasterRealities.Ragescale.effect_error(effect)
				if not ragescale_effect_issue.is_empty(): return ragescale_effect_issue
			SurpriseSources.TYPE:
				var surprise_effect_issue: String=SurpriseSources.effect_error(effect)
				if not surprise_effect_issue.is_empty(): return surprise_effect_issue
			MasterRealities.Storm.TYPE:
				var stormbringer_effect_issue: String=MasterRealities.Storm.effect_error(effect)
				if not stormbringer_effect_issue.is_empty(): return stormbringer_effect_issue
			ImperialSources.TYPE:
				var imperial_effect_issue: String=ImperialSources.effect_error(effect)
				if not imperial_effect_issue.is_empty(): return imperial_effect_issue
			LavaSources.TYPE:
				var lava_effect_issue: String=LavaSources.effect_error(effect)
				if not lava_effect_issue.is_empty(): return lava_effect_issue
			BloodbinderSources.TYPE:
				var bloodbinder_effect_issue: String=BloodbinderSources.effect_error(effect)
				if not bloodbinder_effect_issue.is_empty(): return bloodbinder_effect_issue
			OldSoulSources.TYPE:
				var old_soul_effect_issue: String=OldSoulSources.effect_error(effect)
				if not old_soul_effect_issue.is_empty(): return old_soul_effect_issue
			BoogieSources.TYPE:
				var boogie_effect_issue: String=BoogieSources.effect_error(effect)
				if not boogie_effect_issue.is_empty(): return boogie_effect_issue
			BalindaSources.TYPE:
				var balinda_effect_issue: String=BalindaSources.effect_error(effect)
				if not balinda_effect_issue.is_empty(): return balinda_effect_issue
			MasterRealities.Sources.TYPE:
				var master_realities_effect_issue: String=MasterRealities.Sources.effect_error(effect)
				if not master_realities_effect_issue.is_empty(): return master_realities_effect_issue
			Brinescale.Sources.TYPE:
				var brinescale_effect_issue: String=Brinescale.Sources.effect_error(effect)
				if not brinescale_effect_issue.is_empty(): return brinescale_effect_issue
			Expeditioner.Sources.TYPE:
				var expeditioner_effect_issue: String=Expeditioner.Sources.effect_error(effect)
				if not expeditioner_effect_issue.is_empty(): return expeditioner_effect_issue
			MishmashStatHost.Sources.TYPE:
				var mishmash_effect_issue: String=MishmashStatHost.Sources.effect_error(effect)
				if not mishmash_effect_issue.is_empty(): return mishmash_effect_issue
			MaelstromSources.TYPE:
				var maelstrom_effect_issue: String=MaelstromSources.effect_error(effect)
				if not maelstrom_effect_issue.is_empty(): return maelstrom_effect_issue
			MannorothSources.TYPE:
				var mannoroth_effect_issue: String=MannorothSources.effect_error(effect)
				if not mannoroth_effect_issue.is_empty(): return mannoroth_effect_issue
			BoogeymonsterSources.TYPE:
				var boogeymonster_effect_issue: String=BoogeymonsterSources.effect_error(effect)
				if not boogeymonster_effect_issue.is_empty(): return boogeymonster_effect_issue
			"on_exact_damage_destroy_self":
				if effect.size()!=2 or not _rally_integer(effect.get("amount"),1): return "Invalid exact damage destruction"
			"avenge_shield_force_attack":
				if effect.size()!=2 or effect.get("count") not in [1,2]: return "Invalid Avenge shield attack"
			"combat_transfer_stat":
				var bulk_transfer_issue: String=_combat_transfer_error(effect)
				if not bulk_transfer_issue.is_empty(): return bulk_transfer_issue
			SummonGet.Sources.DEATH:
				var summon_get_effect_issue: String=SummonGet.Sources.call_error(unit,effect)
				if not summon_get_effect_issue.is_empty(): return summon_get_effect_issue
			"deathrattle_summon":
				if effect.has("summon_for_opponent") and not effect.summon_for_opponent is bool: return "Opponent summon flag must be boolean"
				if effect.has("attack_immediately") and not effect.attack_immediately is bool: return "Immediate summon attack flag must be boolean"
				if not effect.get("unit", null) is Dictionary or int(effect.get("count", 1)) < 1:
					return "deathrattle_summon requires a unit and a positive count"
				if effect.has("count_from") and str(effect["count_from"]) != "source_attack":
					return "deathrattle_summon count_from only supports source_attack"
				var nested_error: String = _validate_unit(effect["unit"], depth + 1)
				if not nested_error.is_empty():
					return nested_error
			"deathrattle_summon_history":
				if int(effect.get("count", 0)) < 1:
					return "deathrattle_summon_history requires positive count"
			"deathrattle_damage":
				if Enforcer.effect_claimed(effect):
					var enforcer_effect_issue: String = Enforcer.effect_error(effect)
					if not enforcer_effect_issue.is_empty(): return enforcer_effect_issue
					continue # Exact ordinary source and complete program authenticated above.
				if SpikedSavior.claimed(unit):
					var spiked_effect_issue: String = SpikedSavior.effect_error(effect)
					if not spiked_effect_issue.is_empty(): return spiked_effect_issue
					continue # Entire normal source and ordered pair authenticated above.
				if Ticking.effect_claimed(effect):
					var ticking_effect_issue: String = Ticking.effect_error(effect)
					if not ticking_effect_issue.is_empty(): return ticking_effect_issue
					continue # Whole native source/program authenticated above.
				if int(effect.get("amount", -1)) < 0 or not str(effect.get("target", "")) in ["all_enemies", "random_enemy", "all", "highest_health_enemy", "lowest_health_enemy"]:
					return "deathrattle_damage requires non-negative amount and all_enemies/random_enemy/all/highest_health_enemy target"
			"combat_summon_interval_resource", "deathrattle_random_resource", "deathrattle_fixed_resource", "deathrattle_special_chromatic_resource":
				var resource_leaf_issue: String = BulkResourceSources.leaf_error(unit,effect)
				if not resource_leaf_issue.is_empty(): return resource_leaf_issue
			"deathrattle_copy_killer_base":
				if effect.keys().size()!=2 or not _rally_integer(effect.get("count"),1) or effect.count>2: return "Killer base copy requires native count1/2"
			"deathrattle_add_card":
				if str(effect.get("card_id", "")).is_empty() or int(effect.get("count", 1)) < 1:
					return "deathrattle_add_card requires card_id and positive count"
			"avenge":
				for key in effect:
					if key not in ["type", "count", "effect"]: return "avenge has an unsupported field"
				if not _rally_integer(effect.get("count", null), 1) or not effect.get("effect", null) is Dictionary:
					return "avenge requires positive integer count and nested effect Dictionary"
				var nested: Dictionary = effect["effect"]
				if nested.get("type")==KerriganZerg.Sources.AVENGE:
					var kerrigan_wrapper_issue: String=KerriganZerg.Sources.wrapper_error(unit,effect)
					if not kerrigan_wrapper_issue.is_empty(): return kerrigan_wrapper_issue
				elif nested.get("type") in [Protoss.Sources.CARRIER,Protoss.Sources.RESOURCE]:
					var protoss_identity: String=str(unit.get("card_id",unit.get("id","")))
					if not Protoss.Sources.PROGRAMS.has(protoss_identity) or not Protoss.Sources.Exact.same(effect,Protoss.Sources.PROGRAMS[protoss_identity][0]): return "protoss_changed_native_avenge_wrapper"
				elif nested.get("type")==MetalDispenser.Sources.TYPE:
					if not MetalDispenser.Sources.accepts_id(unit.get("card_id")) or not MetalDispenser.Sources.same(effect,MetalDispenser.Sources.PROGRAMS[unit.card_id][0]): return "metal_dispenser_changed_native_avenge_wrapper"
				elif nested.get("type")==LinkedUndead.Sources.TYPE:
					var linked_undead_wrapper_issue: String=LinkedUndead.Sources.wrapper_error(unit,effect)
					if not linked_undead_wrapper_issue.is_empty(): return linked_undead_wrapper_issue
				elif nested.get("type")==NextTurnShopSources.TYPE:
					var next_shop_wrapper_issue: String=NextTurnShopSources.wrapper_error(unit,effect)
					if not next_shop_wrapper_issue.is_empty(): return next_shop_wrapper_issue
				elif nested.get("type")==PastryAvenge.TYPE:
					var pastry_wrapper_issue: String=PastryAvenge.wrapper_error(unit,effect)
					if not pastry_wrapper_issue.is_empty(): return pastry_wrapper_issue
				elif nested.get("type")==Tony.Sources.TYPE:
					var tony_wrapper_issue: String=Tony.Sources.wrapper_error(unit,effect)
					if not tony_wrapper_issue.is_empty(): return tony_wrapper_issue
				elif nested.get("type")==AvengePoison.Sources.TYPE:
					var avenge_poison_wrapper_issue: String=AvengePoison.Sources.wrapper_error(unit,effect)
					if not avenge_poison_wrapper_issue.is_empty(): return avenge_poison_wrapper_issue
				elif nested.get("type")==CombatGemTriggers.Sources.AVENGE:
					var combat_gem_trigger_wrapper_issue: String=CombatGemTriggers.Sources.wrapper_error(unit,effect)
					if not combat_gem_trigger_wrapper_issue.is_empty(): return combat_gem_trigger_wrapper_issue
				elif nested.get("type")==HandBoard.Sources.TYPE:
					var hand_board_wrapper_issue: String=HandBoard.Sources.wrapper_error(unit,effect)
					if not hand_board_wrapper_issue.is_empty(): return hand_board_wrapper_issue
				elif nested.get("type")==NativeGem.Sources.AVENGE:
					var native_gem_wrapper_issue: String=NativeGem.Sources.wrapper_error(unit,effect)
					if not native_gem_wrapper_issue.is_empty(): return native_gem_wrapper_issue
				elif nested.get("type")==EachTypePermanent.TYPE:
					var each_type_wrapper_issue: String=EachTypePermanent.wrapper_error(unit,effect)
					if not each_type_wrapper_issue.is_empty(): return each_type_wrapper_issue
				elif nested.get("type")==BulkResourceHost.NativeSpellcraft.AVENGE:
					var native_spellcraft_wrapper_issue: String=BulkResourceHost.NativeSpellcraft.wrapper_error(unit,effect)
					if not native_spellcraft_wrapper_issue.is_empty(): return native_spellcraft_wrapper_issue
				elif nested.get("type")==CombatPlainSources.AVENGE:
					var combat_plain_wrapper_issue: String=CombatPlainSources.wrapper_error(unit,effect)
					if not combat_plain_wrapper_issue.is_empty(): return combat_plain_wrapper_issue
				elif nested.get("type")==Knights.AVENGE_TYPE:
					if not Knights.accepts_id(unit.get("card_id",unit.get("id"))) or not Knights.unit_error(unit).is_empty() or not Knights.effect_error(nested).is_empty(): return "knight_summon_unbound_avenge_source"
				elif nested.get("type")==CombatTransforms.TYPE:
					if not CombatTransforms.accepts_id(unit.get("card_id",unit.get("id"))) or not CombatTransforms.unit_error(unit).is_empty() or not CombatTransforms.effect_error(nested).is_empty(): return "combat_transform_unbound_avenge_source"
				elif nested.get("type") is String and nested.type == BeetleSources.AVENGE_TYPE:
					var beetle_id: String = str(unit.get("card_id",unit.get("id","")))
					var runed_issue: String = BeetleSources.runed_effect_error(beetle_id,nested)
					if not runed_issue.is_empty(): return runed_issue
					if not BeetleSources.same(effect,BeetleSources.compiled_effects(beetle_id)[0]): return "Runed Progenitor requires its complete Avenge threshold wrapper"
				elif nested.get("type") is String and nested.type == "deathrattle_permanent_tribe_bonus":
					# Keep the actual whole source; this is not a generic Army whitelist.
					if not NativeRecruit.Primus.claimed(unit): return "unbound Primus Army Avenge source"
					var primus_issue: String = NativeRecruit.Primus.unit_error(unit,source_templates if not source_templates.is_empty() else _options.get("hand_card_templates",{}),is_base_unit)
					if primus_issue.is_empty(): primus_issue = NativeRecruit.Primus.effect_error(effect)
					if primus_issue.is_empty(): primus_issue = PermanentTribeEffects.effect_error(nested)
					if not primus_issue.is_empty(): return primus_issue
				elif nested.get("scope") is String and nested.get("scope") == "adjacent_friendly":
					# The complete source was checked above; never erase its identity
					# by validating this reserved leaf on the generic dummy minion.
					if not SproutAvenge.claimed(unit) or not SproutAvenge.effect_error(nested).is_empty(): return "unbound adjacent Avenge source"
				elif nested.get("type")==SilithidSources.GROW:
					if not SilithidSources.claimed(unit) or not SilithidSources.effect_error(nested).is_empty(): return "silithid_unbound_avenge_leaf"
				elif BulkResourceSources.marker(nested):
					var resource_wrapper_issue: String = BulkResourceSources.wrapper_error(unit,effect)
					if not resource_wrapper_issue.is_empty(): return resource_wrapper_issue
				elif nested.get("type") == CorpseSale.Sources.TYPE:
					if not CorpseSale.Sources.claimed(unit): return "corpse_sale_unbound_avenge_leaf"
					var sale_leaf_issue: String = CorpseSale.Sources.effect_error(nested)
					if not sale_leaf_issue.is_empty(): return sale_leaf_issue
				elif nested.get("type") in CombatEconomy.Sources.TYPES:
					# Preserve the real whole source here; an identity-less dummy
					# would incorrectly admit an arbitrary nested economy leaf.
					if not CombatEconomy.Sources.avenge_claimed(unit): return "avenge economy source is unsupported"
					var recycler_issue: String = CombatEconomy.Sources.unit_error(unit,source_templates if not source_templates.is_empty() else _options.get("hand_card_templates",{}),is_base_unit)
					if not recycler_issue.is_empty(): return recycler_issue
				else:
					if not str(nested.get("type", "")) in ["combat_transfer_stat", "avenge_shield_force_attack", "deathrattle_damage", "deathrattle_buff", "deathrattle_add_card", "deathrattle_shop_bonus", "deathrattle_keyword"]:
						return "avenge nested effect is unsupported"
					var nested_error: String = _validate_unit({"attack": 0, "health": 1, "effects": [nested]}, depth + 1)
					if not nested_error.is_empty():
						return nested_error
			"deathrattle_buff":
				if not str(effect.get("scope", "")) in ["all_friendly", "random_friendly", "rightmost_friendly", "leftmost_friendly"]:
					return "deathrattle_buff scope must be all_friendly, random_friendly, leftmost_friendly or rightmost_friendly"
				if effect.has("permanent_scope") and (not effect.permanent_scope is String or effect.permanent_scope not in ["all", "golden"]):
					return "deathrattle_buff permanent_scope must be all or golden"
				if int(effect.get("attack", 0)) < 0 or int(effect.get("health", 0)) < 0:
					return "deathrattle_buff does not support negative stat changes"
				if effect.has("health_from") and str(effect["health_from"]) != "source_max_health":
					return "deathrattle_buff health_from only supports source_max_health"
				if int(effect.get("health_multiplier", 1)) < 1 or (effect.has("health_multiplier") and not effect.has("health_from")):
					return "deathrattle_buff health_multiplier requires health_from and positive multiplier"
				if effect.has("transfer_effect") and not effect["transfer_effect"] is bool:
					return "deathrattle_buff transfer_effect must be a boolean"
			"deathrattle_keyword_bundle":
				for key in effect:
					if key not in ["type","keywords","count"]: return "deathrattle_keyword_bundle unexpected field"
				if not effect.get("keywords") is Array or effect.keywords.is_empty(): return "deathrattle_keyword_bundle requires keywords"
				var bundle_seen: Array = []
				for keyword in effect.keywords:
					if not keyword is String or keyword not in COMBAT_KEYWORDS or keyword in bundle_seen: return "deathrattle_keyword_bundle invalid keyword"
					bundle_seen.append(keyword)
				if not _rally_integer(effect.get("count",1),1) or effect.get("count",1)>7: return "deathrattle_keyword_bundle invalid count"
			"deathrattle_keyword":
				for key in effect:
					if key not in ["type", "keyword", "scope", "count", "tribe", "exclude_self"]: return "deathrattle_keyword has an unsupported field"
				if effect.has("exclude_self") and not effect.exclude_self is bool: return "deathrattle_keyword exclude_self must be a boolean"
				if effect.get("exclude_self",false) and effect.get("scope","random_friendly") == "self": return "deathrattle_keyword cannot require and exclude its source"
				if effect.has("tribe") and not effect.tribe is String: return "deathrattle_keyword tribe must be a String"
				if not effect.get("scope", "random_friendly") is String or str(effect.get("scope", "random_friendly")) not in ["self", "random_friendly"]:
					return "deathrattle_keyword scope must be self or random_friendly"
				if not _rally_integer(effect.get("count", 1), -1):
					return "deathrattle_keyword count must be an integer"
				if str(effect.get("scope", "random_friendly")) == "self" and (int(effect.get("count", 1)) != 1 or not str(effect.get("tribe", "")).is_empty()):
					return "self keyword requires count 1 and no tribe filter"
				if not str(effect.get("keyword", "")) in COMBAT_KEYWORDS:
					return "deathrattle_keyword requires a supported combat keyword"
				var count: int = int(effect.get("count", 1))
				if count != -1 and count < 1:
					return "deathrattle_keyword count must be positive, or -1 for all"
			"on_friendly_death_buff", "on_friendly_summon_buff":
				if int(effect.get("attack", 0)) < 0 or int(effect.get("health", 0)) < 0:
					return "%s does not support negative stat changes" % effect_type
				if effect_type == "on_friendly_summon_buff" and not str(effect.get("scope", "")) in ["self", "summoned", "random_other"]:
					return "on_friendly_summon_buff scope must be self, summoned or random_other"
				if effect.has("keyword") and not str(effect["keyword"]) in COMBAT_KEYWORDS:
					return "on_friendly_summon_buff keyword is unsupported"
				if effect_type == "on_friendly_death_buff" and effect.has("keyword"):
					return "on_friendly_death_buff does not support keyword grants"
			"on_friendly_death_damage":
				if int(effect.get("amount", -1)) < 0 or not str(effect.get("target", "")) in ["random_enemy", "highest_health_enemy", "all_enemies", "all"] or int(effect.get("shots", 1)) < 1:
					return "on_friendly_death_damage requires supported target, non-negative amount and positive shots"
			"on_damage_survived":
				if str(effect.get("keyword", "")) != "divine_shield":
					return "on_damage_survived only supports divine_shield"
				if effect.has("limit") and int(effect["limit"]) < 1:
					return "on_damage_survived limit must be positive"
			"on_hand_added_self_temporary_health":
				var thorn_issue: String = NativeRecruit.Thorn.effect_error(effect)
				if not thorn_issue.is_empty(): return thorn_issue
			"on_hand_added_pirate_board_buff":
				var drust_issue: String = NativeRecruit.DeviousDrust.effect_error(effect)
				if not drust_issue.is_empty(): return drust_issue
			"on_hand_added_buff":
				if int(effect.get("attack", 0)) < 0 or int(effect.get("health", 0)) < 0:
					return "on_hand_added_buff requires non-negative stats"
			"rally_repeat":
				if effect.get("mode")!="set" or not _rally_integer(effect.get("multiplier"),2) or int(effect.multiplier)>3 or effect.size()!=3: return "Invalid owner Rally multiplier"
			"deathrattle_repeat":
				var mode: String = str(effect.get("mode", "extra"))
				if mode == "set":
					if not int(effect.get("multiplier", 0)) in [2, 3]:
						return "Set-mode deathrattle_repeat requires multiplier 2 or 3"
				elif mode != "extra" or int(effect.get("extra", -1)) < 0:
					return "deathrattle_repeat requires extra mode with non-negative extra, or set mode"
			"on_friendly_attack_buff":
				var friendly_issue: String = FriendlyAttack.effect_error(effect)
				if not friendly_issue.is_empty(): return friendly_issue
			"on_attacked_adjacent_buff":
				var attacked_adjacent_effect_issue: String = AttackedAdjacent.effect_error(effect)
				if not attacked_adjacent_effect_issue.is_empty(): return attacked_adjacent_effect_issue
			"on_attacked_keyword":
				var attacked_keyword_issue: String = AttackedVenomous.effect_error(effect)
				if not attacked_keyword_issue.is_empty(): return attacked_keyword_issue
			"on_attacked_set_attacker_health":
				if effect.keys().size()!=2 or not _rally_integer(effect.get("health"),1): return "Attacked health set requires positive health"
			"on_attacked_buff":
				var attacked_issue: String = attacked_effect_error(effect)
				if not attacked_issue.is_empty(): return attacked_issue
			"on_friendly_attack_damage":
				for key in effect:
					if key not in ["type","tribe","exclude_self","amount"]: return "Friendly attack damage unexpected field"
				if not effect.get("tribe") is String or not effect.get("exclude_self") is bool or not _rally_integer(effect.get("amount"),1): return "Friendly attack damage malformed parameters"
			"after_attack_highest_health_damage":
				if effect.size()!=2 or not _rally_integer(effect.get("multiplier"),1) or int(effect.multiplier) not in [1,2]: return "Malformed after attack damage multiplier"
			"deathrattle_damage_for_history":
				if effect.size()!=3 or effect.get("tribe")!="机械" or not _rally_integer(effect.get("amount"),1): return "Malformed history damage"
			"after_attacked_survived_force_leftmost":
				if effect.size()!=1: return "Unexpected attacked survival force field"
			"cannot_attack":
				if effect.size()!=1: return "Invalid cannot-attack effect"
			"after_adjacent_attack_damage":
				if effect.size()!=3 or not _rally_integer(effect.get("amount"),1) or not _rally_integer(effect.get("shots"),1) or int(effect.shots)>2: return "Invalid adjacent attack damage"
			"start_combat_force_attack":
				if effect.size()!=2 or not _rally_integer(effect.get("count"),1) or int(effect.count)>2: return "Invalid start attack count"
			"start_combat_grant_deathrattle":
				if effect.size()!=4 or not effect.get("tribe") is String or effect.get("exclude_self")!=true or not effect.get("effect") is Dictionary or effect.effect.get("type")!="deathrattle_summon": return "Invalid start granted deathrattle"
				if not effect.effect.get("unit") is Dictionary or int(effect.effect.get("count",0))!=1: return "Invalid granted summon body"
				var granted_body_error: String=_validate_unit(effect.effect.unit,depth+1)
				if not granted_body_error.is_empty(): return granted_body_error
			"on_attack_damage":
				if int(effect.get("amount", -1)) < 0 or str(effect.get("target", "")) != "defender_and_neighbors":
					return "on_attack_damage requires non-negative amount and defender_and_neighbors target"
			"start_combat_adjacent_damage_buff":
				for key in effect:
					if key not in ["type","amount","attack","shots"]: return "adjacent start unexpected field"
				for field in ["amount","attack","shots"]:
					if not _rally_integer(effect.get(field),1): return "adjacent start requires positive integer parameters"
				if effect.shots > 2: return "adjacent start supports at most two native actions"
			"start_combat_damage":
				if Ragnaros.Sources.effect_claimed(effect):
					var ragnaros_effect_issue: String = Ragnaros.Sources.effect_error(effect)
					if not ragnaros_effect_issue.is_empty(): return ragnaros_effect_issue
					continue
				if not str(effect.get("target", "")) in ["random_enemy", "highest_health_enemy", "all_enemies", "all", "all_other"] or int(effect.get("shots", 1)) < 1:
					return "start_combat_damage requires supported target and positive shots"
				if effect.has("amount_from"):
					if str(effect["amount_from"]) != "count_tribe" or str(effect.get("tribe", "")).is_empty():
						return "start_combat_damage amount_from only supports count_tribe with tribe"
				elif int(effect.get("amount", -1)) < 0:
					return "start_combat_damage requires non-negative amount"
			"start_combat_buff":
				if effect.has("require_no_friendly_shield") and not effect.require_no_friendly_shield is bool: return "start buff shield condition must be boolean"
				if not str(effect.get("scope", "")) in ["self", "all_friendly", "all_other", "random_other", "adjacent_friendly"]:
					return "start_combat_buff scope must be self, all_friendly, all_other or random_other"
				if int(effect.get("attack", 0)) < 0 or int(effect.get("health", 0)) < 0:
					return "start_combat_buff does not support negative stat changes"
				if effect.has("keyword") and not str(effect["keyword"]) in COMBAT_KEYWORDS:
					return "start_combat_buff keyword is unsupported"
				if int(effect.get("count", 1)) < 1:
					return "start_combat_buff count must be positive"
			"start_combat_multiply", "on_attack_multiply":
				if int(effect.get("attack", 1)) < 1 or int(effect.get("health", 1)) < 1:
					return "Stat multipliers must be positive integers"
				if effect_type == "on_attack_multiply" and effect.has("health"):
					return "on_attack_multiply only supports attack multiplication"
	if unit.has("base_unit"):
		if not unit["base_unit"] is Dictionary:
			return "base_unit must be a Dictionary"
		var base_error: String = _validate_unit(unit["base_unit"], depth + 1,true,source_templates)
		if not base_error.is_empty():
			return "Invalid base_unit: " + base_error
	return ""

static func attacked_effect_error(effect: Variant) -> String:
	if not effect is Dictionary: return "on_attacked_buff must be a Dictionary"
	if TreantAttack.effect_claimed(effect): return TreantAttack.effect_error(effect)
	if ChampionAttack.effect_claimed(effect): return ChampionAttack.effect_error(effect)
	for field in effect:
		if field not in ["type","scope","attack","health","require_keyword","permanent","require_self"]: return "on_attacked_buff has an unsupported field"
	if not effect.get("type") is String or effect.type != "on_attacked_buff": return "on_attacked_buff requires its exact String type"
	if not effect.get("scope","target") is String or effect.get("scope","target") != "target": return "on_attacked_buff requires target scope"
	for stat in ["attack","health"]:
		if not FriendlyAttack.integer(effect.get(stat,0)): return "on_attacked_buff requires bounded non-negative integer " + stat
	if effect.has("require_keyword") and (not effect.require_keyword is String or (not effect.require_keyword.is_empty() and effect.require_keyword not in COMBAT_KEYWORDS)): return "on_attacked_buff requires a known combat keyword"
	for flag in ["permanent","require_self"]:
		if effect.has(flag) and not effect[flag] is bool: return "on_attacked_buff flags must be boolean"
	return ""

static func is_dozy_identity(value: Variant) -> bool:
	return value is String and value in DOZY_IDS

static func dozy_program_error(unit: Dictionary) -> String:
	var identity: Variant = unit.get("card_id",unit.get("id",""))
	var claimed: bool = is_dozy_identity(identity) or is_dozy_identity(unit.get("id")) or is_dozy_identity(unit.get("card_code"))
	var effects: Variant = unit.get("effects",[])
	if effects is Array:
		for effect in effects:
			if effect is Dictionary and effect.has("require_self"): claimed = true
	if not claimed: return ""
	if not identity is String or identity not in DOZY_IDS: return "Self-attacked predicate requires an exact Dozy identity"
	for alias in ["id","card_id","card_code"]:
		if unit.has(alias) and (not unit[alias] is String or unit[alias] != identity): return "Dozy source identity aliases conflict"
	if not FriendlyAttack.same(effects,DOZY_PROGRAMS[identity]): return "Dozy needs its complete exact self-attacked permanent program"
	if not FriendlyAttack.same(unit.get("tribes"),DOZY_SOURCES[identity].tribes): return "Dozy native tribes differ from source"
	if unit.has("kind") and unit.kind != "minion": return "Dozy source must be a minion"
	for variant in ["golden","is_golden"]:
		if unit.has(variant) and not FriendlyAttack.same(unit[variant],DOZY_SOURCES[identity].is_golden): return "Dozy source variant differs from identity"
	if unit.has("text") and not FriendlyAttack.same(unit.text,DOZY_SOURCES[identity].text): return "Dozy source text differs from complete native text"
	return ""

static func dozy_source_error(card: Dictionary, custom_projection: bool = false) -> String:
	var issue: String = dozy_program_error(card)
	if not issue.is_empty(): return issue
	var identity: Variant = card.get("id")
	if not identity is String or identity not in DOZY_IDS: return "Dozy source requires its exact catalog identity"
	for field in DOZY_SOURCES[identity]:
		if custom_projection and field == "tier": continue
		if not card.has(field) or not FriendlyAttack.same(card[field],DOZY_SOURCES[identity][field]): return "Dozy complete native source field differs: " + str(field)
	return ""

static func dozy_source_closure_error(catalog, card: Dictionary) -> String:
	var issue: String = dozy_program_error(card)
	if not issue.is_empty(): return issue
	if not is_dozy_identity(card.get("id")): return ""
	issue = dozy_source_error(card,catalog.source_catalog != null)
	if not issue.is_empty(): return issue
	# Check both actual programs and bodies, not only their text hashes.
	var original = catalog.source_catalog if catalog.source_catalog != null else catalog
	for identity in DOZY_IDS:
		issue = dozy_source_error(original.get_card(identity))
		if not issue.is_empty(): return issue
		issue = dozy_source_error(catalog.get_card(identity),catalog.source_catalog != null)
		if not issue.is_empty(): return issue
	return ""

static func dozy_persistence_error(unit: Dictionary, event: Dictionary) -> String:
	# Called only for the actual matched recruit-board UID. The local combat copy
	# can have been reduced by Rally, so its safety does not bound recruit stats.
	for stat in ["attack_delta","health_delta"]:
		if not FriendlyAttack.integer(event.get(stat)): return "Dozy persistent delta must be a bounded non-negative integer"
	return FriendlyAttack.recipient_error(unit,int(event.get("attack_delta",0)),int(event.get("health_delta",0)))

func _uses_attack_transfer(unit: Dictionary) -> bool:
	if unit.get("card_id", unit.get("id", "")) in AttackTransfer.IDENTITIES:
		return true
	if unit.get("effects") is Array:
		for effect in unit.effects:
			if effect is Dictionary and str(effect.get("type", "")) == AttackTransfer.TYPE:
				return true
	return false

func _attack_transfer_program_error(unit: Dictionary) -> String:
	if not _uses_attack_transfer(unit): return ""
	# Native identity owns exactly one/two transfer instructions. Independently
	# authenticated Magnetic/enchantment actions may coexist and still pass the
	# ordinary Combat validators; they cannot add another transfer instruction.
	if not unit.get("effects") is Array:
		return "Attack-transfer source effects must be an Array"
	var native_program: Array = []
	for effect in unit.effects:
		if effect is Dictionary and str(effect.get("type", "")) == AttackTransfer.TYPE:
			native_program.append(effect)
	return AttackTransfer.program_error(unit.get("card_id", unit.get("id", "")), native_program)

func _validate_start_combat_stats(effect: Dictionary) -> String:
	return StartCombatEffects.effect_error(effect)

func start_combat_context_error(left: Array, right: Array, options: Dictionary = {}) -> String:
	return StartCombatEffects.context_error(left, right, options)

func _validate_shield_event(effect: Dictionary) -> String:
	# Catalog calls this exact validator too. Keep the existing flat event DSL;
	# unrelated nested actions, hand buffs and global auras are not accepted.
	if not effect.get("type", null) is String or effect["type"] not in SHIELD_EVENT_TYPES:
		return "Unsupported shield-loss event type"
	var effect_type: String = effect["type"]
	var allowed: Array = ["type", "tribe", "exclude_self", "limit", "times"]
	match effect_type:
		"on_shield_lost_buff": allowed.append_array(["scope", "attack", "health", "permanent"])
		"on_shield_lost_keyword": allowed.append("keyword")
		"on_shield_lost_add_card": allowed.append_array(["card_id", "count"])
	for key in effect:
		if key not in allowed:
			return "Unknown %s parameter: %s" % [effect_type, str(key)]
	if effect.has("tribe") and not effect["tribe"] is String:
		return "Shield-loss tribe must be a String"
	for key in ["exclude_self", "permanent"]:
		if effect.has(key) and not effect[key] is bool:
			return "Shield-loss %s must be boolean" % key
	for key in ["limit", "times", "count"]:
		if effect.has(key) and not _rally_integer(effect[key], 1):
			return "Shield-loss %s must be a positive integer" % key
	if effect_type == "on_shield_lost_buff":
		if not effect.get("scope", null) is String or effect["scope"] not in ["self", "target"]:
			return "on_shield_lost_buff requires self/target scope"
		for key in ["attack", "health"]:
			if effect.has(key) and not _rally_integer(effect[key], 0):
				return "Shield-loss %s must be a non-negative integer" % key
	elif effect_type == "on_shield_lost_keyword":
		if not effect.get("keyword", null) is String or effect["keyword"] != "divine_shield":
			return "on_shield_lost_keyword only supports divine_shield"
	elif not effect.get("card_id", null) is String or effect["card_id"].is_empty():
		return "on_shield_lost_add_card requires a nonempty String card_id"
	return ""

func _validate_friendly_summon(effect: Dictionary, depth: int = 0) -> String:
	if depth > 16:
		return "Friendly summon nesting exceeds 16 levels"
	for key in effect:
		if key not in ["type", "combat_only", "tribe", "limit", "effect"]:
			return "Unknown on_friendly_summon parameter: " + str(key)
	if not effect.get("combat_only", null) is bool or effect["combat_only"] != true:
		return "on_friendly_summon currently requires combat_only:true"
	if effect.has("tribe") and not effect["tribe"] is String:
		return "on_friendly_summon tribe must be a String"
	if effect.has("limit") and not _rally_integer(effect["limit"], 1):
		return "on_friendly_summon limit must be a positive integer"
	if not effect.get("effect", null) is Dictionary:
		return "on_friendly_summon requires a nested effect Dictionary"
	var action: Dictionary = effect["effect"]
	if not action.get("type", null) is String:
		return "on_friendly_summon action type must be a String"
	var action_type: String = action["type"]
	var allowed: Array = ["type", "scope"]
	if action_type == "buff":
		allowed.append_array(["tribe", "attack", "health", "attack_from", "health_from", "attack_multiplier", "health_multiplier", "permanent"])
	elif action_type == "multiply":
		allowed.append_array(["attack","health"])
	else:
		return "Unsupported on_friendly_summon action: " + action_type
	for key in action:
		if key not in allowed:
			return "Unknown on_friendly_summon %s parameter: %s" % [action_type, str(key)]
	if not action.get("scope", null) is String:
		return "on_friendly_summon action requires a String scope"
	if action_type == "multiply":
		if action["scope"] != "summoned" or not _rally_integer(action.get("attack", null), 1):
			return "on_friendly_summon multiply requires summoned scope and positive integer attack multiplier"
		if action.has("health") and not _rally_integer(action.health,1): return "on_friendly_summon health multiplier requires a positive integer"
		return ""
	if action["scope"] not in ["self", "summoned", "all_friendly", "rightmost_friendly"]:
		return "on_friendly_summon buff requires a supported recipient scope"
	if action.has("tribe") and not action["tribe"] is String:
		return "on_friendly_summon recipient tribe must be a String"
	if action.has("permanent") and not action["permanent"] is bool:
		return "on_friendly_summon permanent must be boolean"
	for key in ["attack", "health"]:
		if action.has(key) and not _rally_integer(action[key], 0):
			return "on_friendly_summon %s must be a non-negative integer" % key
		var dynamic_key: String = key + "_from"
		if action.has(dynamic_key):
			var dynamic_values: Array = ["source_attack", "summoned_attack"] if key == "attack" else ["source_max_health", "summoned_health", "summoned_attack"]
			if not action[dynamic_key] is String or action[dynamic_key] not in dynamic_values or action.has(key):
				return "on_friendly_summon %s requires a supported source and excludes fixed %s" % [dynamic_key, key]
		var multiplier: String = key + "_multiplier"
		if action.has(multiplier) and (not action.has(dynamic_key) or not _rally_integer(action[multiplier], 1)):
			return "on_friendly_summon %s requires its dynamic stat and a positive integer" % multiplier
	return ""

func _validate_friendly_death(effect: Dictionary, depth: int = 0) -> String:
	if depth > 16:
		return "Friendly death nesting exceeds 16 levels"
	for key in effect:
		if key not in ["type", "tribe", "require_keyword", "require_deathrattle", "exclude_self", "limit", "times", "effect"]:
			return "Unknown on_friendly_death parameter: " + str(key)
	for key in ["tribe", "require_keyword"]:
		if effect.has(key) and not effect[key] is String:
			return "on_friendly_death %s must be a String" % key
	if effect.has("require_keyword") and effect["require_keyword"] not in COMBAT_KEYWORDS:
		return "on_friendly_death requires a supported combat keyword"
	for key in ["require_deathrattle", "exclude_self"]:
		if effect.has(key) and not effect[key] is bool:
			return "on_friendly_death %s must be boolean" % key
	for key in ["limit", "times"]:
		if effect.has(key) and not _rally_integer(effect[key], 1):
			return "on_friendly_death %s must be a positive integer" % key
	if not effect.get("effect", null) is Dictionary:
		return "on_friendly_death requires a nested effect Dictionary"
	var action: Dictionary = effect["effect"]
	if not action.get("type", null) is String:
		return "on_friendly_death action type must be a String"
	var action_type: String = action["type"]
	if action_type == DelayedGold.FRIENDLY_DEATH_TYPE:
		return DelayedGold.validate_effect(action) # Whole wrapper/source is authenticated by _validate_unit.
	var allowed: Array = ["type"]
	if action_type == "buff":
		allowed.append_array(["scope", "attack", "health", "attack_from", "health_from", "permanent"])
	elif action_type == "add_card":
		allowed.append_array(["card_id", "count"])
	else:
		return "Unsupported on_friendly_death action: " + action_type
	for key in action:
		if key not in allowed:
			return "Unknown on_friendly_death %s parameter: %s" % [action_type, str(key)]
	if action_type == "add_card":
		if not action.get("card_id", null) is String or str(action["card_id"]).is_empty() or not _rally_integer(action.get("count", 1), 1):
			return "on_friendly_death add_card requires card_id and positive integer count"
		return ""
	if not action.get("scope", null) is String or action["scope"] not in ["self", "all_friendly", "dead_neighbors"]:
		return "on_friendly_death buff requires self/all_friendly/dead_neighbors scope"
	if action.has("permanent") and not action["permanent"] is bool:
		return "on_friendly_death permanent must be boolean"
	for key in ["attack", "health"]:
		if action.has(key) and not _rally_integer(action[key], 0):
			return "on_friendly_death buff %s must be a non-negative integer" % key
		var dynamic_key: String = key + "_from"
		if action.has(dynamic_key):
			var expected: String = "dead_attack" if key == "attack" else "dead_max_health"
			if not action[dynamic_key] is String or action[dynamic_key] != expected or action.has(key):
				return "on_friendly_death %s requires %s and excludes fixed %s" % [dynamic_key, expected, key]
	return ""

func _validate_rally(effect: Dictionary, depth: int, source: Dictionary = {}, templates: Dictionary = {}, is_base: bool = false) -> String:
	if Hyena.Sources.claimed(source) or Hyena.Sources.marker(effect): return Hyena.Sources.wrapper_error(source,effect)
	if JailbirdJuggernaut.Sources.claimed(source) or JailbirdJuggernaut.Sources.marker(effect): return JailbirdJuggernaut.Sources.wrapper_error(source,effect)
	if effect.get("effect",{}).get("type")==DarkGiftResources.Sources.FODDER_ACTION:
		var demonology_source_issue: String=DarkGiftResources.Sources.unit_error(source)
		if not demonology_source_issue.is_empty(): return demonology_source_issue
		return "" if DarkGiftResources.Sources.fodder_gift(source) and DarkGiftResources.Sources.same(effect,DarkGiftResources.Sources.fodder_wrapper(source)) else "demonology_unbound_attached_rally_wrapper"
	if Apexis.Sources.claimed(source) or effect.get("effect",{}).get("type")==Apexis.Sources.ACTION: return Apexis.Sources.wrapper_error(source,effect)
	if DitchGuardian.Sources.claimed(source) or DitchGuardian.Sources.marker(effect): return DitchGuardian.Sources.wrapper_error(source,effect)
	if effect.get("effect",{}).get("type")==KerriganZerg.Sources.RALLY: return KerriganZerg.Sources.wrapper_error(source,effect)
	if effect.get("effect",{}).get("type")==Protoss.Sources.COLOSSUS:
		var protoss_identity: String=str(source.get("card_id",source.get("id","")))
		return "" if Protoss.Sources.PROGRAMS.has(protoss_identity) and Protoss.Sources.Exact.same(effect,Protoss.Sources.PROGRAMS[protoss_identity][0]) else "protoss_changed_native_rally_wrapper"
	if Counterattacker.Sources.marker(effect): return Counterattacker.Sources.wrapper_error(source,effect)
	if SeafloorCast.Sources.marker(effect): return SeafloorCast.Sources.wrapper_error(source,effect)
	if CombatRingCast.QueenSources.marker(effect): return CombatRingCast.QueenSources.wrapper_error(source,effect)
	if CombatRingCast.DragonSources.marker(effect): return CombatRingCast.DragonSources.wrapper_error(source,effect)
	if RightmostDual.Sources.marker(effect): return RightmostDual.Sources.wrapper_error(source,effect)
	if RightmostBattlecry.Sources.marker(effect): return RightmostBattlecry.Sources.wrapper_error(source,effect)
	if Dramaloc.Sources.marker(effect): return Dramaloc.Sources.wrapper_error(source,effect)
	if CombatGems.Sources.marker(effect): return CombatGems.Sources.wrapper_error(source,effect)
	if RallyShield.Sources.marker(effect): return RallyShield.Sources.wrapper_error(source,effect)
	if RallyEachType.Sources.marker(effect): return RallyEachType.Sources.wrapper_error(source,effect)
	if SummonGet.Sources.marker(effect): return SummonGet.Sources.wrapper_error(source,effect)
	if source.get("card_id",source.get("id")) in BeetleObserver.Sources.RALLY_IDS or effect.get("effect",{}).get("type")==BeetleObserver.Sources.RALLY: return BeetleObserver.Sources.wrapper_error(source,effect)
	if source.get("card_id",source.get("id")) in CombatPlainSources.RALLY_IDS or effect.get("effect",{}).get("type")==CombatPlainSources.RALLY: return CombatPlainSources.wrapper_error(source,effect)
	if Preemptive.claimed(source) or (effect.get("effect") is Dictionary and effect.effect.get("type")==Preemptive.TYPE): return Preemptive.wrapper_error(source,effect)
	if BulkResourceSources.marker(effect): return BulkResourceSources.wrapper_error(source,effect)
	if NativeRecruit.Dustbone.claimed(source) or NativeRecruit.Dustbone.effect_claimed(effect):
		if depth > 16: return "Rally nesting exceeds 16 levels"
		if not NativeRecruit.Dustbone.accepts_id(source.get("card_id",source.get("id"))): return "dustbone_rally_unbound_source"
		var dustbone_issue: String = NativeRecruit.Dustbone.unit_error(source,templates,is_base)
		if not dustbone_issue.is_empty(): return dustbone_issue
		if not NativeRecruit.Dustbone.Exact._same([effect],NativeRecruit.Dustbone.program_for(source.get("card_id",source.get("id")))): return "dustbone_rally_wrapper_source_mismatch"
		return NativeRecruit.Dustbone.effect_error(effect)
	if depth > 16:
		return "Rally nesting exceeds 16 levels"
	for key in effect:
		if str(key) not in ["type", "effect", "times", "limit"]:
			return "Unknown rally parameter: " + str(key)
	if not effect.get("effect", null) is Dictionary or not _rally_integer(effect.get("times", 1), 1):
		return "rally requires a nested effect and positive integer times"
	if effect.has("limit") and not _rally_integer(effect["limit"], 1):
		return "rally limit must be a positive integer"
	var action: Dictionary = effect["effect"]
	if not action.get("type", null) is String:
		return "rally action type must be a String"
	var action_type: String = action["type"]
	if action_type == "golden_board_shield": return "" if action.size()==2 and action.get("threshold")==4 else "Invalid golden board Shield condition"
	if action_type == "combat_transfer_stat": return _combat_transfer_error(action)
	if action_type == NativeRallySpread.Sources.TYPE:
		var spread_issue: String=NativeRallySpread.Sources.native_error(source,templates,is_base)
		if not spread_issue.is_empty(): return spread_issue
		return "" if NativeRallySpread.Sources.same(effect,NativeRallySpread.Sources.PROGRAMS[str(source.get("card_id",source.get("id")))][0]) else "native_rally_spread_changed_original_wrapper"
	if action_type == CombatEconomy.Sources.Felblaze.TYPE: return CombatEconomy.Sources.Felblaze.wrapper_error(effect)
	if action_type == CombatEconomy.Sources.Refiner.TYPE: return CombatEconomy.Sources.Refiner.wrapper_error(effect)
	if action_type == CombatEconomy.Sources.SpellBonus.Rally.TYPE: return CombatEconomy.Sources.SpellBonus.Rally.wrapper_error(effect)
	if action_type == HandSummon.RALLY_TYPE: return HandSummon.trigger_effect_error(action)
	var allowed: Array = ["type"]
	match action_type:
		"buff": allowed.append_array(["scope", "tribe", "exclude_self", "count", "attack", "health", "permanent"])
		"keyword": allowed.append_array(["scope", "tribe", "exclude_self", "count", "keyword", "permanent"])
		"multiply": allowed.append_array(["scope", "attack", "health", "permanent"])
		"summon": allowed.append_array(["unit", "count", "permanent"])
		"add_card": allowed.append_array(["card_id", "count"])
		"trigger_deathrattle": allowed.append("scope")
		"damage": allowed.append_array(["scope", "amount", "amount_from", "exclude_self", "count", "neighbor_count"])
		"set_stats": allowed.append_array(["scope", "attack", "health"])
		"remove_keywords": allowed.append_array(["scope", "keywords"])
		_: return "Unsupported rally effect: " + action_type
	for key in action:
		if key not in allowed:
			return "Unknown rally %s parameter: %s" % [action_type, str(key)]
	for key in ["exclude_self", "permanent"]:
		if action.has(key) and not action[key] is bool:
			return "rally %s must be boolean" % key
	for key in ["scope", "tribe", "keyword", "card_id", "amount_from"]:
		if action.has(key) and not action[key] is String:
			return "rally %s must be a String" % key
	if action.has("count") and not _rally_integer(action["count"], 1):
		return "rally count must be a positive integer"
	for key in ["attack", "health"]:
		if action.has(key) and not _rally_integer(action[key], 1 if action_type == "multiply" else 0):
			return "rally %s must be an integer in the valid stat range" % key
	if action_type == "damage":
		var scope: String = str(action.get("scope", ""))
		if scope not in ["self", "all_friendly", "all_enemies", "defender", "defender_and_neighbors", "random_enemy_except_defender"]:
			return "rally damage requires a supported scope"
		if action.has("amount") == action.has("amount_from"):
			return "rally damage requires exactly one of amount or amount_from"
		if action.has("amount") and not _rally_integer(action["amount"], 0):
			return "rally damage amount must be a non-negative integer"
		if action.has("amount_from") and action["amount_from"] != "source_attack":
			return "rally damage amount_from only supports source_attack"
		if action.has("count") and scope != "random_enemy_except_defender":
			return "rally damage count only supports random_enemy_except_defender"
		if action.has("exclude_self") and scope != "all_friendly":
			return "rally damage exclude_self only supports all_friendly"
		if action.has("neighbor_count") and (scope != "defender_and_neighbors" or not _rally_integer(action["neighbor_count"], 1) or int(action["neighbor_count"]) > 2):
			return "rally damage neighbor_count must be 1 or 2 for defender_and_neighbors"
	elif action_type == "set_stats":
		if action.get("scope", "defender") != "defender" or not _rally_integer(action.get("attack", null), 0) or not _rally_integer(action.get("health", null), 1):
			return "rally set_stats requires defender scope and valid attack/health"
	elif action_type == "remove_keywords":
		if action.get("scope", "defender") != "defender" or not action.get("keywords", null) is Array or action["keywords"].is_empty():
			return "rally remove_keywords requires defender scope and a nonempty keyword Array"
		var seen: Array = []
		for keyword in action["keywords"]:
			if not keyword is String or keyword not in ["reborn", "taunt"] or keyword in seen:
				return "rally remove_keywords only supports distinct reborn/taunt entries"
			seen.append(keyword)
	elif action_type in ["buff", "keyword"]:
		var scope: String = str(action.get("scope", ""))
		if scope not in ["self", "all_friendly", "random_friendly", "left", "right", "neighbors"]:
			return "rally buff/keyword requires supported scope"
		if action.has("count") and scope not in ["random_friendly", "left", "right"]:
			return "rally count only applies to random_friendly/left/right scopes"
		if action_type == "keyword" and (str(action.get("keyword", "")) not in COMBAT_KEYWORDS or bool(action.get("permanent", false))):
			return "rally keyword requires a supported keyword; permanent keyword is not implemented"
	elif action_type == "multiply":
		if str(action.get("scope", "self")) != "self":
			return "rally multiply only supports self scope"
	elif action_type == "summon":
		if not action.get("unit", null) is Dictionary or bool(action.get("permanent", false)):
			return "rally summon requires a fixed unit and cannot be permanent"
		var template: Dictionary = action["unit"]
		if not _rally_integer(template.get("attack", null), 0) or not _rally_integer(template.get("health", null), 1):
			return "rally summon requires valid integer unit stats"
		return _validate_unit(template, depth + 1)
	elif action_type == "add_card":
		if str(action.get("card_id", "")).is_empty():
			return "rally add_card requires card_id"
	elif action_type == "trigger_deathrattle":
		if str(action.get("scope", "leftmost_other")) != "leftmost_other":
			return "rally trigger_deathrattle only supports leftmost_other"
	return ""

func _rally_integer(value: Variant, minimum: int) -> bool:
	if value is int:
		return value >= minimum
	if value is float:
		return is_finite(value) and value == floor(value) and value >= minimum and value < 9223372036854775807.0
	return false

func _rally_targets(source: Dictionary, action: Dictionary) -> Array:
	var side: int = int(source["_side"])
	var board: Array = _boards[side]
	var source_index: int = board.find(source)
	var scope: String = str(action["scope"])
	var candidates: Array = []
	if scope == "self":
		if source_index >= 0:
			candidates = [source]
	elif scope in ["left", "right", "neighbors"]:
		if source_index >= 0:
			var directions: Array = [-1, 1] if scope == "neighbors" else ([-1] if scope == "left" else [1])
			var count: int = 1 if scope == "neighbors" else int(action.get("count", 1))
			for direction in directions:
				for offset in range(1, mini(count, BOARD_LIMIT) + 1):
					var index: int = source_index + int(direction) * offset
					if index >= 0 and index < board.size():
						candidates.append(board[index])
	else:
		candidates = board.duplicate()
	var eligible: Array = []
	for candidate in candidates:
		if int(candidate["health"]) <= 0 or not _tribe_matches(candidate, str(action.get("tribe", ""))):
			continue
		if bool(action.get("exclude_self", false)) and int(candidate["_combat_id"]) == int(source["_combat_id"]):
			continue
		if str(action["type"]) == "keyword" and _has_keyword(candidate, str(action["keyword"])):
			continue
		eligible.append(candidate)
	if scope != "random_friendly":
		return eligible
	var selected: Array = []
	for _index in range(mini(int(action.get("count", 1)), eligible.size())):
		var ids: Array = []
		for candidate in eligible:
			ids.append(candidate["uid"])
		var choice: int = _random_index(eligible.size(), "rally_target", ids)
		selected.append(eligible[choice])
		eligible.remove_at(choice)
	return selected

func _trigger_rallies(side: int, source: Dictionary, defender: Dictionary) -> void:
	var hyena_rally_admission: String=_hyena_host.admission_error(side,source,defender)
	if not hyena_rally_admission.is_empty(): _fail(hyena_rally_admission);return
	if Hyena.Sources.claimed(source) and (source.get("silenced",false) or source.get("abilities_disabled",false)): return
	var jailbird_rally_admission: String=_jailbird_juggernaut_host.admission_error(side,source,defender)
	if not jailbird_rally_admission.is_empty(): _fail(jailbird_rally_admission);return
	if JailbirdJuggernaut.Sources.claimed(source) and (source.get("silenced",false) or source.get("abilities_disabled",false)): return
	if DitchGuardian.Sources.claimed(source) and (source.get("silenced",false) or source.get("abilities_disabled",false)): return
	if (source.get("card_id") in NativeRallySpread.Sources.IDS or (NativeRallySpread.Sources.marked(source) or NativeRallySpread.Recruit.marked(source))) and (source.get("silenced",false) or source.get("abilities_disabled",false)): return
	if Counterattacker.Sources.claimed(source) and (source.get("silenced",false) or source.get("abilities_disabled",false)): return
	if ProtectorRallyHost.Sources.claimed(source) and (source.get("silenced",false) or source.get("abilities_disabled",false)): return
	if source.get("card_id") in CombatRingCast.QueenSources.IDS and (source.get("silenced",false) or source.get("abilities_disabled",false)): return
	if source.get("card_id") in SeafloorCast.Sources.IDS and (source.get("silenced",false) or source.get("abilities_disabled",false)): return
	if source.get("card_id") in BulkResourceHost.RallyFixedHand.Native.PARENTS and (source.get("silenced",false) or source.get("abilities_disabled",false)): return
	if source.get("card_id") in Dramaloc.Sources.IDS and (source.get("silenced",false) or source.get("abilities_disabled",false)): return
	if source.get("card_id") in CombatGems.Sources.IDS and (source.get("silenced",false) or source.get("abilities_disabled",false)): return
	if source.get("card_id") in RallyShield.Sources.IDS and (source.get("silenced",false) or source.get("abilities_disabled",false)): return
	if source.get("card_id") in RallyEachType.Sources.IDS and (source.get("silenced",false) or source.get("abilities_disabled",false)): return
	if source.get("card_id") in SummonGet.Sources.RALLY_IDS and (source.get("silenced",false) or source.get("abilities_disabled",false)): return
	if source.get("card_id") in BeetleObserver.Sources.RALLY_IDS and (source.get("silenced",false) or source.get("abilities_disabled",false)): return
	if source.get("card_id") in CombatPlainSources.RALLY_IDS and (source.get("silenced",false) or source.get("abilities_disabled",false)): return
	# Rally is an attack-declaration trigger, not an after-surviving-attack hook.
	# Snapshot effect entries, so acquired effects never join this declaration.
	var context: Dictionary = {"defender": defender, "neighbors": []}
	var defender_index: int = _boards[1 - side].find(defender)
	if defender_index >= 0:
		for index in [defender_index - 1, defender_index + 1]:
			if index >= 0 and index < _boards[1 - side].size():
				context["neighbors"].append(_boards[1 - side][index])
	var queued: Array = []
	for index in range(source["effects"].size()):
		var effect: Dictionary = source["effects"][index]
		if str(effect.get("type", "")) == "rally":
			queued.append({"index": index, "effect": effect.duplicate(true)})
	var spread_groups: Dictionary=_native_rally_spread_host.queued(self,side,source)
	if not str(spread_groups.error).is_empty(): _fail(str(spread_groups.error));return
	queued.append_array(spread_groups.groups)
	var stoneshell_groups: Dictionary=_stoneshell_host.queued(self,side,source)
	if not str(stoneshell_groups.error).is_empty(): _fail(str(stoneshell_groups.error));return
	queued.append_array(stoneshell_groups.groups)
	var dark_gift_resource_groups: Dictionary=_dark_gift_resource_host.queued(self,side,source,queued)
	if not str(dark_gift_resource_groups.error).is_empty(): _fail(str(dark_gift_resource_groups.error));return
	queued.append_array(dark_gift_resource_groups.groups)
	var ditch_guardian_queue_issue: String=_ditch_guardian_host.queued(self,side,source,defender,queued)
	if not ditch_guardian_queue_issue.is_empty(): _fail(ditch_guardian_queue_issue);return
	if not _protector_rally_host.prepare(self,side,source,defender,queued): return
	for activation in queued:
		if not _error.is_empty():
			return
		if _find_unit(side, int(source["_combat_id"])).is_empty() or int(source["health"]) <= 0:
			_emit("rally_skipped", {"source": source["uid"], "reason": "source_dead_before_activation"})
			continue
		var spread_activation_issue: String=_native_rally_spread_host.activation_error(self,side,source,activation)
		if not spread_activation_issue.is_empty(): _fail(spread_activation_issue);return
		var acquired_spread: bool=activation.has("rally_spread_grant_id") or activation.has("rally_spread_recruit_grant_id")
		var stoneshell_activation_issue: String=_stoneshell_host.activation_error(self,side,source,activation)
		if not stoneshell_activation_issue.is_empty(): _fail(stoneshell_activation_issue);return
		var effect: Dictionary = activation["effect"]
		var counter_key: String = str(activation["index"])
		var used: int = int(source["_rally_used"].get(counter_key, 0))
		if effect.has("limit") and used >= int(effect["limit"]):
			_emit("rally_skipped", {"source": source["uid"], "reason": "limit", "used": used, "limit": int(effect["limit"])})
			continue
		if not _protector_rally_host.before_group(self,source,activation,used): return
		var queensguard_rally_issue: String="" if acquired_spread else CombatRingCast.queen_rally_admission(self,side,source,activation)
		if not queensguard_rally_issue.is_empty(): _fail(queensguard_rally_issue);return
		var seafloor_group_issue: String="" if acquired_spread else _seafloor_cast_host.prepare_activation(self,side,source,activation)
		if not seafloor_group_issue.is_empty(): _fail(seafloor_group_issue);return
		var fixed_rally_plan: Dictionary={"ok":true,"ticket":{}} if acquired_spread else _bulk_resource_host._rally_fixed_hand.prepare_activation(self,side,source,defender,activation,used)
		if not fixed_rally_plan.ok: return
		var fixed_rally_ticket: Dictionary=fixed_rally_plan.ticket
		var summon_get_rally_plan: Dictionary={"ok":true,"ticket":{}} if acquired_spread else _bulk_resource_host._summon_get_rally_hand.prepare_activation(self,side,source,defender,activation,used)
		if not summon_get_rally_plan.ok: return
		var summon_get_rally_ticket: Dictionary=summon_get_rally_plan.ticket
		source["_rally_used"][counter_key] = used + 1
		var owner_rally_multiplier: int=_owner_rally_multiplier(side)
		var whole_rally_times: int=mini(int(effect.get("times",1)),_max_steps+1)*owner_rally_multiplier
		var macaw_native_group: bool=_macaw_portrait_host.applies(side,source,effect)
		for repetition in range(mini(whole_rally_times,_max_steps+1)):
			if JailbirdJuggernaut.Sources.claimed(source) and not Preemptive.live(self,1-side,defender): break
			if not _rally_live_target(source) or source.get("_pending_destroy",false):
				if macaw_native_group and repetition%int(effect.times)!=0:
					_fail("macaw_portrait_source_lost_inside_native_program_partial");return
				break
			if not _protector_rally_host.before_repeat(self,source,activation,repetition+1): return
			if not _bulk_resource_host._rally_fixed_hand.before_repeat(self,fixed_rally_ticket,repetition+1): return
			if not _bulk_resource_host._summon_get_rally_hand.before_repeat(self,summon_get_rally_ticket,repetition+1): return
			if not _tick("rally"):
				return
			var action: Dictionary = effect["effect"]
			_stoneshell_host.observed(self,side,source,activation,repetition+1)
			_emit("rally", {"side": side, "source": source["uid"], "defender": defender["uid"], "action": action["type"], "repetition": repetition + 1, "times": whole_rally_times, "activation": used + 1})
			if macaw_native_group:
				if not _macaw_portrait_host.activate(self,side,source,effect,repetition+1,used+1): return
			else:
				var previous_spread_context: Dictionary=_native_rally_spread_context
				_native_rally_spread_context={"side":side,"source":source,"activation":activation,"repetition":repetition+1}
				_execute_rally_action(side, source, action, context, effect)
				_native_rally_spread_context=previous_spread_context
			_resolve_deaths()
			if not _error.is_empty():
				return
			if not _bulk_resource_host._rally_fixed_hand.after_repeat(self,fixed_rally_ticket,repetition+1): return
			if not _bulk_resource_host._summon_get_rally_hand.after_repeat(self,summon_get_rally_ticket,repetition+1): return
			if not _protector_rally_host.after_repeat(self,source,activation,repetition+1): return
		if not _bulk_resource_host._rally_fixed_hand.finish_activation(self,fixed_rally_ticket): return
		if not _bulk_resource_host._summon_get_rally_hand.finish_activation(self,summon_get_rally_ticket): return
	if not _protector_rally_host.completed(self,source): return

func _execute_rally_action(side: int, source: Dictionary, action: Dictionary, context: Dictionary, wrapper: Dictionary = {}) -> void:
	if action.get("type")==Hyena.Sources.TYPE:
		_hyena_host.activate(self,side,source,action,context,wrapper)
		return
	if action.get("type")==JailbirdJuggernaut.Sources.TYPE:
		_jailbird_juggernaut_host.activate(self,side,source,action,context,wrapper)
		return
	if action.get("type")==Apexis.Sources.ACTION:
		var apexis_rally_issue: String=_apexis_magnetic_host.rally(self,side,source,action,wrapper)
		if not apexis_rally_issue.is_empty(): _fail(apexis_rally_issue)
		return
	if action.get("type")==DitchGuardian.Sources.TYPE:
		var ditch_guardian_dispatch_issue: String=_ditch_guardian_host.activate(self,side,source,action,wrapper)
		if not ditch_guardian_dispatch_issue.is_empty(): _fail(ditch_guardian_dispatch_issue)
		return
	if action.get("type")==NativeRallySpread.Sources.TYPE:
		_native_rally_spread_host.apply(self,side,source,action,wrapper)
		return
	if action.get("type")==KerriganZerg.Sources.RALLY:
		_kerrigan_zerg_host.rally(_kill_reward_host,self,side,source,action,wrapper)
		return
	if action.get("type")==Protoss.Sources.COLOSSUS:
		Protoss.colossus(self,side,source,action,context,wrapper)
		return
	if action.get("type")==Counterattacker.Sources.TYPE:
		Counterattacker.activate(self,side,source,action,context,wrapper)
		return
	if action.get("type")==SeafloorCast.Sources.TYPE:
		_seafloor_cast_host.activate(self,side,source,action,wrapper)
		return
	if action.get("type") in [DarkGiftResources.Sources.GEM_ACTION,DarkGiftResources.Sources.MAJORITY_ACTION,DarkGiftResources.Sources.FODDER_ACTION]:
		_dark_gift_resource_host.rally(self,side,source,action,wrapper)
		return
	if action.get("type")==RightmostBattlecry.Sources.TYPE:
		_rightmost_battlecry_host.activate(self,side,source,action,wrapper)
		return
	if action.get("type")==CombatRingCast.QueenSources.RALLY:
		_combat_ring_cast_host.queen_rally(self,side,source,action,wrapper)
		return
	if action.get("type")==CombatRingCast.DragonSources.TYPE:
		_combat_ring_cast_host.dragon_rally(self,side,source,action,wrapper)
		return
	if action.get("type")==RightmostDual.Sources.TYPE:
		_rightmost_dual_host.activate(self,side,source,action,wrapper)
		return
	if action.get("type")==Dramaloc.Sources.TYPE:
		_dramaloc_host.activate(self,side,source,action,wrapper)
		return
	if action.get("type")==CombatGems.Sources.TYPE:
		CombatGems.activate(_kill_reward_host,self,side,source,action,wrapper)
		return
	if action.get("type")==RallyShield.Sources.TYPE:
		RallyShield.activate(_kill_reward_host,self,side,source,action,wrapper)
		return
	if action.get("type")==RallyEachType.Sources.TYPE:
		RallyEachType.activate(_kill_reward_host,self,side,source,action,wrapper)
		return
	if action.get("type")==SummonGet.Sources.RALLY:
		var summon_get_entry: Dictionary={"side":side,"unit":source,"position":_boards[side].find(source)+1,"order":0,"live_source":true,"repeats":1}
		SummonGet.activate(_bulk_resource_host,self,summon_get_entry,action,"rally",wrapper)
		return
	if action.get("type")==BeetleObserver.Sources.RALLY:
		_beetle_observer_host.rally(self,side,source,action,wrapper)
		return
	if action.get("type")==CombatPlainSources.RALLY:
		if _plain_copy_host==null: _fail("combat_plain_copy_missing_actual_host");return
		_plain_copy_host.activate(self,side,source,action,"rally",wrapper)
		return
	if action.get("type")==Preemptive.TYPE:
		Preemptive.activate(self,side,source,action,context,wrapper)
		return
	if BulkResourceSources.marker(action):
		var resource_wrapper_issue: String = BulkResourceSources.wrapper_error(source,wrapper)
		if not resource_wrapper_issue.is_empty(): _fail(resource_wrapper_issue); return
		_bulk_resource_host.activate(self,side,source,action)
		return
	if NativeRecruit.Dustbone.claimed(source) or NativeRecruit.Dustbone._army_nested(action):
		var dustbone_issue: String = NativeRecruit.Dustbone.combat_call_error(source,action,side,_boards,_options.get("hand_card_templates",{}),wrapper,context,_log)
		if not dustbone_issue.is_empty(): _fail(dustbone_issue); return
	match str(action["type"]):
		"deathrattle_permanent_tribe_bonus":
			_permanent_tribe_effects.activate(self,side,source,action)
		"rally_tavern_spell_bonus", "rally_blood_gem_bonus", "rally_shop_bonus":
			if not _options.get("delayed_gold_context") is Dictionary:
				_fail("Combat economy requires actual owner and transaction context")
				return
			var economy_event: Dictionary = CombatEconomy.build_event(_options.delayed_gold_context,side,source,action,_log.size(),"rally",_options.get("hand_card_templates",{}))
			if not economy_event.ok:
				_fail(str(economy_event.error))
				return
			_emit(CombatEconomy.EVENT,economy_event.event)
		"summon_from_hand":
			_rally_summon_from_hand(side,source,action)
		"damage":
			var amount: int = int(source["attack"]) if str(action.get("amount_from", "")) == "source_attack" else int(action["amount"])
			var targets: Array = _rally_damage_targets(side, source, action, context)
			var packets: Array = []
			var ids: Array = []
			for target in targets:
				packets.append({"source": source, "target": target, "amount": amount, "kind": "rally"})
				ids.append(target["uid"])
			_emit("rally_damage", {"side": side, "source": source["uid"], "defender": context["defender"]["uid"], "targets": ids, "amount": amount, "scope": action["scope"]})
			if not packets.is_empty():
				_damage_batch(packets)
		"set_stats":
			var target: Dictionary = context["defender"]
			if _rally_live_target(target):
				if BoardAuraRuntime.managed(target):
					var owner: Variant = target.get(BoardAura.APPLIED_KEY,{}).get("owner",_options.get(("left" if int(target._side)==0 else "right")+"_board_aura_owner",0))
					var set_plan: Dictionary = BoardAura.build_rebase_plan(target,owner,{"attack":int(action.attack),"health":int(action.health),"max_health":int(action.health)})
					if not str(set_plan.error).is_empty(): _fail(str(set_plan.error)); return
					var scalar_after: Dictionary=target.duplicate(true)
					BoardAura._write_stats(scalar_after,set_plan.after)
					var loc_scalar: Dictionary=LocPrince.scalar(target,scalar_after)
					if not loc_scalar.ok: _fail(str(loc_scalar.error));return
					scalar_after=loc_scalar.after
					var loc_scalar_context: String=LocPrince.combat_error(self,target,int(scalar_after.attack)-int(target.attack),int(scalar_after.max_health)-int(target.max_health))
					if not loc_scalar_context.is_empty(): _fail(loc_scalar_context);return
					if _mishmash_stat_host!=null:
						var scalar_issue: String=_mishmash_stat_host.prepare_combat_transition(self,target,scalar_after,"stat_set","rally")
						if not scalar_issue.is_empty(): _fail(scalar_issue);return
					var issue: String = BoardAura.commit_unit_plan(target,owner,set_plan)
					if not issue.is_empty(): _fail(issue); return
				else:
					var scalar_after: Dictionary=target.duplicate(true)
					scalar_after.attack=int(action.attack);scalar_after.health=int(action.health);scalar_after.max_health=int(action.health)
					var loc_scalar: Dictionary=LocPrince.scalar(target,scalar_after)
					if not loc_scalar.ok: _fail(str(loc_scalar.error));return
					scalar_after=loc_scalar.after
					var loc_scalar_context: String=LocPrince.combat_error(self,target,int(scalar_after.attack)-int(target.attack),int(scalar_after.max_health)-int(target.max_health))
					if not loc_scalar_context.is_empty(): _fail(loc_scalar_context);return
					if _mishmash_stat_host!=null:
						var scalar_issue: String=_mishmash_stat_host.prepare_combat_transition(self,target,scalar_after,"stat_set","rally")
						if not scalar_issue.is_empty(): _fail(scalar_issue);return
					target.attack=int(scalar_after.attack);target.health=int(scalar_after.health);target.max_health=int(scalar_after.max_health)
				_loc_prince_host.capture(target)
				_emit("stat_set", {"source": source["uid"], "target": target["uid"], "attack": target["attack"], "health": target["health"], "max_health": target["max_health"], "reason": "rally"})
		"remove_keywords":
			var target: Dictionary = context["defender"]
			if _rally_live_target(target):
				if "taunt" in action["keywords"] and ShieldTaunt.derived_taunt(target): _fail("shield_taunt_explicit_removal_partial");return
				for keyword in action["keywords"]:
					if _has_keyword(target, str(keyword)):
						target["keywords"].erase(keyword)
						var bonus_rally_sequence: int=_log.size()
						_emit("keyword_removed", {"source": source["uid"], "target": target["uid"], "keyword": keyword, "reason": "rally"})
						if not KeywordLoss.observe(self,target,str(keyword),bonus_rally_sequence): return

		"combat_transfer_stat":
			_combat_transfer_stat(source,action)

		"golden_board_shield":
			var golden_count: int=0
			for friendly in _boards[side]:
				if int(friendly.health)>0 and not friendly.get("_pending_destroy",false) and friendly.get("golden",false): golden_count+=1
			if golden_count>=int(action.threshold) and _rally_live_target(source) and not source.get("_pending_destroy",false) and not _has_keyword(source,"divine_shield"):
				source.keywords.append("divine_shield")
				_emit("keyword_granted",{"source":source.uid,"target":source.uid,"keyword":"divine_shield","reason":"rally_golden_board"})

		"buff", "keyword":
			for recipient in _rally_targets(source, action):
				if str(action["type"]) == "keyword":
					recipient["keywords"].append(str(action["keyword"]))
					_emit("keyword_granted", {"source": source["uid"], "target": recipient["uid"], "keyword": action["keyword"], "reason": "rally"})
				else:
					_apply_trigger_buff(source, recipient, action, "rally", str(source["uid"]))
					if bool(action.get("permanent", false)):
						_emit("persistent_buff", {"type": "persistent_buff", "side": side, "source": source["uid"], "target_uid": recipient["uid"], "attack_delta": int(action.get("attack", 0)), "health_delta": int(action.get("health", 0))})
		"multiply":
			if not _find_unit(side, int(source["_combat_id"])).is_empty() and int(source["health"]) > 0:
				var old_attack: int = int(source["attack"])
				var old_max_health: int = int(source["max_health"])
				_multiply_stats(source, action, "rally")
				if bool(action.get("permanent", false)):
					_emit("persistent_buff", {"type": "persistent_buff", "side": side, "source": source["uid"], "target_uid": source["uid"], "attack_delta": int(source["attack"]) - old_attack, "health_delta": int(source["max_health"]) - old_max_health, "stat_operation": "multiply"})
		"add_card":
			if _bulk_resource_host._rally_fixed_hand.handles(source,action): _bulk_resource_host._rally_fixed_hand.execute(self,side,source,action)
			else: _queue_card_reward(side, source, str(action["card_id"]), int(action.get("count", 1)))
		"summon":
			var source_index: int = _boards[side].find(source)
			if source_index < 0:
				return
			var entry: Dictionary = {"side": side, "unit": source, "position": source_index + 1, "order": source_index, "live_source": true}
			var requested: int=int(action.get("count",1)) if _summon_attempt_observers(side) else mini(int(action.get("count",1)),BOARD_LIMIT+1)
			var summon_index: int=0
			while summon_index<requested:
				summon_index+=1
				if _boards[side].size() >= BOARD_LIMIT:
					var continue_attempts: bool=_summon_attempt_observers(side)
					if not _summon_capacity_miss({"side": side, "source": source["uid"], "reason": "board_full", "kind": "rally"}): return
					if continue_attempts: continue
					break
				_summon(entry, action["unit"], "rally")
				if not _error.is_empty(): return
		"trigger_deathrattle":
			_trigger_living_deathrattle(side, source)

func _rally_live_target(unit: Dictionary) -> bool:
	return not unit.is_empty() and int(unit.get("health", 0)) > 0 and not _find_unit(int(unit["_side"]), int(unit["_combat_id"])).is_empty()

func _rally_damage_targets(side: int, source: Dictionary, action: Dictionary, context: Dictionary) -> Array:
	var scope: String = str(action["scope"])
	var defender: Dictionary = context.get("defender", {})
	var targets: Array = []
	if scope in ["self", "all_friendly", "all_enemies"]:
		var candidates: Array = [source] if scope == "self" else _boards[side if scope == "all_friendly" else 1 - side]
		for candidate in candidates:
			if not _rally_live_target(candidate):
				continue
			if bool(action.get("exclude_self", false)) and int(candidate["_combat_id"]) == int(source["_combat_id"]):
				continue
			targets.append(candidate)
	elif scope in ["defender", "defender_and_neighbors"]:
		if _rally_live_target(defender):
			targets.append(defender)
		if scope == "defender_and_neighbors":
			var neighbors: Array = []
			for candidate in context.get("neighbors", []):
				if _rally_live_target(candidate):
					neighbors.append(candidate)
			if int(action.get("neighbor_count", 2)) == 1 and neighbors.size() > 1:
				var ids: Array = []
				for candidate in neighbors:
					ids.append(candidate["uid"])
				neighbors = [neighbors[_random_index(neighbors.size(), "rally_damage_neighbor", ids)]]
			targets.append_array(neighbors)
	elif scope == "random_enemy_except_defender":
		var candidates: Array = []
		for candidate in _boards[1 - side]:
			if _rally_live_target(candidate) and int(candidate["_combat_id"]) != int(defender.get("_combat_id", -1)):
				candidates.append(candidate)
		for _selection in range(mini(int(action.get("count", 1)), candidates.size())):
			var ids: Array = []
			for candidate in candidates:
				ids.append(candidate["uid"])
			var choice: int = _random_index(candidates.size(), "rally_damage_target", ids)
			targets.append(candidates[choice])
			candidates.remove_at(choice)
	return targets

func _trigger_living_deathrattle(side: int, rally_source: Dictionary) -> void:
	var target: Dictionary = {}
	var deathrattles: Array = []
	for candidate in _boards[side]:
		if int(candidate["health"]) <= 0 or int(candidate["_combat_id"]) == int(rally_source["_combat_id"]):
			continue
		var effects: Array = []
		for effect in candidate["effects"]:
			var effect_type: String = str(effect.get("type", ""))
			if effect_type.begins_with("deathrattle_") and effect_type != "deathrattle_repeat":
				effects.append(effect.duplicate(true))
		effects.append_array(RecurringNightmare.Sources.effects(candidate))
		effects.append_array(StartGrantSources.effects(candidate))
		effects.append_array(FishGroups.effects(candidate))
		effects.append_array(TempDeath.effects(candidate))
		effects.append_array(MegaGrants.effects(candidate))
		effects.append_array(TamsinGrant.effects(candidate))
		effects.append_array(PiggyBank.Sources.effects(candidate))
		effects.append_array(BrukanGrant.effects(candidate))
		effects.append_array(DarkGiftResources.Sources.resource_effects(candidate))
		if not effects.is_empty():
			target = candidate
			deathrattles = effects
			break
	if target.is_empty():
		_emit("rally_deathrattle_no_target", {"side": side, "source": rally_source["uid"]})
		return
	var repeats: int = _deathrattle_repeats(side)
	var index: int = _boards[side].find(target)
	var entry: Dictionary = {"side": side, "unit": target, "position": index + 1, "order": index, "live_source": true, "repeats": repeats}
	_emit("rally_deathrattle_target", {"side": side, "source": rally_source["uid"], "target": target["uid"], "repeats": repeats, "effects": deathrattles.size()})
	# A triggered living Deathrattle is not a death: no history, no Reborn.
	# Resolve its snapshotted full effect list/repeats before checking deaths.
	_run_native_deathrattles(entry,deathrattles,"rally_deathrattle")

# Owner type projection is applied to the original combat factory output,
# after its final identity exists and before type-sensitive receiving layers.
# Status: written_unverified. Existing effect/domain validators remain intact.
func _incubation_combat_active() -> bool:
	return bool(_options.get(IncubationMutationSources.CONTEXT, {}).get("active", false))

func _incubation_combat_context_error(left: Array, right: Array) -> String:
	var context: Variant = _options.get(IncubationMutationSources.CONTEXT, {})
	if not context is Dictionary: return "incubation_mutation_invalid_combat_context"
	if not context.is_empty():
		if context.get("source_id") != IncubationMutationSources.ID or not context.get("active") is bool:
			return "incubation_mutation_invalid_combat_context"
	var active: bool = bool(context.get("active", false))
	for bodies in [left, right, _options.get("left_hand", []), _options.get("right_hand", [])]:
		if not bodies is Array: continue # Existing combat-hand validation owns its shape.
		for unit in bodies:
			if not unit is Dictionary: continue
			if not active and not unit.has(IncubationMutationSources.MARK): continue
			var issue: String = IncubationMutationSources.unit_error(unit, null, active)
			if not issue.is_empty(): return issue
	return ""

func _incubation_receive_prepared(unit: Dictionary) -> String:
	var active: bool = _incubation_combat_active()
	if not active and not unit.has(IncubationMutationSources.MARK): return ""
	# A native registry entry is evidence, not a replacement factory body. Do
	# not silently recast a copied current tribe list as a fresh native base.
	var native: Variant = _options.get("hand_card_templates", {}).get(IncubationMutationSources.identity(unit))
	if active and native is Dictionary:
		var base: Variant = unit.get("base_unit", unit.get("_base", {}))
		if not base is Dictionary or base.get("tribes", []) != native.get("tribes", []):
			return "incubation_mutation_combat_native_types_changed_partial"
	return IncubationMutationSources.apply(unit, null, active)

# Only the existing hand-copy host's live, reserved plan can authorize
# discarding its inherited owner marker. A matching serialized UID alone is
# never a copy authority and cannot normalize a loaded or arbitrary body.
func _incubation_summon_copy_binding(entry: Dictionary, template: Dictionary, reason: String) -> Dictionary:
	var result: Dictionary = {"error": "", "parent": {}}
	if not template.has(IncubationMutationSources.MARK): return result
	if not _incubation_combat_active():
		result.error = "incubation_mutation_layer_without_anomaly"; return result
	if reason != "hand_summon" or _hand_summons == null or _combat_hand == null:
		result.error = "incubation_mutation_combat_current_copy_layer_partial"; return result
	var side: int = int(entry.get("side", -1))
	var plan: Variant = entry.get("hand_summon_plan")
	if side not in [0, 1] or not plan is Dictionary or plan.get("side") != side or not is_same(plan.get("template"), template):
		result.error = "incubation_mutation_combat_copy_plan_unbound"; return result
	var issue: String = _hand_summons.plan_error(plan, _combat_hand.hands[side])
	if not issue.is_empty(): result.error = issue; return result
	var reference_key: String = HandSummon._reference_key(plan.reference)
	if _hand_summons._reserved[side].get(reference_key) != plan.plan_id:
		result.error = "incubation_mutation_combat_copy_plan_unreserved"; return result
	var parents: Array = _combat_hand.hands[side].filter(func(card): return HandSummon.card_reference(card) == plan.reference)
	if parents.size() != 1:
		result.error = "incubation_mutation_combat_copy_parent_missing"; return result
	issue = IncubationMutationSources.detached_copy_error(parents[0], template)
	if not issue.is_empty(): result.error = issue; return result
	result.parent = parents[0]
	return result

func _prepare_unit(raw: Dictionary, side: int, incubation_copy_parent: Dictionary = {}) -> Dictionary:
	var unit: Dictionary = raw.duplicate(true)
	if not incubation_copy_parent.is_empty():
		# This is the actual original preparation output, not a substitute
		# factory result. Keep the source and immutable copy plan untouched.
		var incubation_detach_issue: String = IncubationMutationSources.detach_copy(incubation_copy_parent, unit)
		if not incubation_detach_issue.is_empty(): _fail(incubation_detach_issue); return {}
	# Native Reborn/history templates intentionally omit presentation text.
	# Restore it from the already validated exact aura identity, never infer an
	# effect from text and never overwrite a contradictory supplied string.
	if (BoardAura.SOURCE_SPECS.has(str(unit.get("card_id",""))) or Gnoll.accepts_id(unit.get("card_id"))) and not unit.has("text"):
		unit.text = _options.get("board_aura_catalog",{}).get(unit.card_id,{}).get("text","")
	if AutoReveilleSources.accepts_id(unit.get("card_id")) and not unit.has("text"): unit.text=AutoReveilleSources.RAW[unit.card_id].text
	if ResourcefulSources.accepts_id(unit.get("card_id")) and not unit.has("text"): unit.text=ResourcefulSources.RAW[unit.card_id].text
	var base: Dictionary = raw.get("base_unit", raw).duplicate(true)
	if GlobalCards.claimed(raw): base=GlobalCards.native_base(raw)
	for key in base.keys():
		if str(key).begins_with("_"):
			base.erase(key)
	base.erase("base_unit")
	base.erase(CastResources.STATE)
	base.erase(HandAcquisition.Sources.STATE)
	base.erase(EscapeeSources.STATE)
	base.erase(PilgrimpSources.STATE)
	base.erase(BazaarSources.STATE)
	base.erase(HealthRefreshSources.STATE)
	base.erase(TradeQuotas.Sources.STATE)
	base.erase(ZestySources.STATE)
	base.erase(NativeRallySpread.Recruit.KEY)
	base.erase(RecurringNightmare.Sources.KEY)
	base.erase(StartGrantSources.KEY)
	base.erase(TempDeath.KEY)
	base.erase(MegaGrants.KEY)
	base.erase(TamsinGrant.KEY)
	base.erase(BrukanGrant.KEY)
	base.erase(PiggyBank.Sources.KEY)
	base.erase(FishGroups.KEY)
	base.erase(SilithidSources.STATE)
	base.erase(Octosari.Sources.STATE)
	base.erase(ThresholdDamage.DONE)
	_serial += 1
	unit["_combat_id"] = _serial
	unit["_side"] = side
	unit["_pending_destroy"] = false
	unit["_killer"] = -1
	unit["_killer_card_id"] = ""
	unit["_avenge_counters"] = {}
	unit["_survival_used"] = {}
	unit["_rally_used"] = {}
	unit["_friendly_death_used"] = {}
	unit["_friendly_summon_used"] = {}
	unit["_shield_lost_used"] = {}
	if DarkGiftSources.shield_gift(unit): unit.erase("_native_shield_hits")
	unit["_base"] = base
	unit["uid"] = str(unit.get("uid", "combat_%d" % _serial))
	unit["attack"] = int(unit.get("attack", 0))
	unit["health"] = int(unit.get("health", 1))
	unit["max_health"] = maxi(int(unit.get("max_health", unit["health"])), int(unit["health"]))
	unit["tier"] = int(unit.get("tier", 1))
	unit["keywords"] = unit.get("keywords", []).duplicate(true)
	unit["effects"] = unit.get("effects", []).duplicate(true)
	RebornRetention.initialize(unit)
	if not raw.has("uid"): GlobalCards.Automata.initialize(unit)
	if not raw.has("uid"): HandAcquisition.Sources.initialize(unit)
	if not raw.has("uid"): ZestySources.initialize(unit)
	if not raw.has("uid"): TradeQuotas.Sources.initialize(unit,int(_options.get("left_global_card_state" if side==0 else "right_global_card_state",{}).get("beast_round",1)))
	if _plain_copy_host!=null and _plain_copy_host._jaraxxus_host!=null: _plain_copy_host._jaraxxus_host.register_unit(unit)
	return unit

func _has_keyword(unit: Dictionary, keyword: String) -> bool:
	if keyword=="immunity_while_attacking" and _first_attack_host!=null and _first_attack_host.protects(unit): return true
	return keyword in unit.get("keywords", []) or (keyword=="taunt" and ShieldTaunt.derived_taunt(unit))

func _cannot_attack(unit: Dictionary) -> bool:
	if unit.get("silenced",false) or unit.get("abilities_disabled",false): return false
	for effect in unit.get("effects",[]):
		if effect.get("type")=="cannot_attack": return true
	return false

func _stealthed(unit: Dictionary) -> bool:
	return _has_keyword(unit,"stealth") and not unit.get("silenced",false) and not unit.get("abilities_disabled",false)

func _visible_attack_target(side: int) -> bool:
	for unit in _boards[side]:
		if int(unit.health)>0 and not unit.get("_pending_destroy",false) and not _stealthed(unit): return true
	return false

func _stealth_boundary_error() -> String:
	var hidden: Array=[]
	for board in _boards:
		for unit in board:
			if int(unit.health)<=0 or unit.get("_pending_destroy",false) or not _stealthed(unit): continue
			# Universal zero-Attack reveal versus whole-board deadlock wording is
			# contradictory; this independent unresolved boundary stays explicit.
			if int(unit.attack)<=0 or _cannot_attack(unit): return "Stealth unable-to-attack automatic reveal rule remains unresolved"
			hidden.append(unit)
	if hidden.is_empty() or _visible_attack_target(0) or _visible_attack_target(1): return ""
	# Native rule reported contemporaneously with designer attribution:
	# when both entire armies are Stealthed, ALL lose Stealth. Remove the
	# keywords as one transition before publishing per-unit observer events.
	if not _tick("all_stealth_reveal"): return _error
	for unit in hidden:
		RebornRetention.consume_keyword(unit,"stealth")
		_battlecruiser_ultra_host.consume_keyword(unit,"stealth")
		_hag_reborn_host.consume_keyword(unit,"stealth")
		unit.keywords.erase("stealth")
	for unit in hidden:
		var sequence: int=_log.size()
		_emit("keyword_removed",{"source":unit.uid,"target":unit.uid,"keyword":"stealth","reason":"both_armies_all_stealthed"})
		if not KeywordLoss.observe(self,unit,"stealth",sequence): return _error
	return ""

func _has_attacker(side: int) -> bool:
	if not _visible_attack_target(1-side): return false
	for unit in _boards[side]:
		if int(unit["health"]) > 0 and int(unit["attack"]) > 0 and not _cannot_attack(unit):
			return true
	return false

func _next_attacker(side: int) -> Dictionary:
	var board: Array = _boards[side]
	for offset in range(board.size()):
		var index: int = (_cursor[side] + offset) % board.size()
		var unit: Dictionary = board[index]
		if int(unit["health"]) > 0 and int(unit["attack"]) > 0 and not _cannot_attack(unit):
			_cursor[side] = index + 1
			return unit
	return {}

func _find_unit(side: int, combat_id: int) -> Dictionary:
	for unit in _boards[side]:
		if int(unit["_combat_id"]) == combat_id:
			return unit
	return {}

func _target(side: int, purpose: String, respect_taunt: bool = true, lowest_attack: bool = false, highest_health: bool = false, lowest_health: bool = false, attack_selection: bool = false) -> Dictionary:
	var available: Array = []
	var taunts: Array = []
	for unit in _boards[side]:
		if attack_selection and _stealthed(unit): continue
		if int(unit["health"]) > 0:
			available.append(unit)
			if _has_keyword(unit, "taunt"):
				taunts.append(unit)
	if lowest_health and not available.is_empty():
		var minimum_health: int = int(available[0]["health"])
		for unit in available: minimum_health = mini(minimum_health,int(unit["health"]))
		available = available.filter(func(unit): return int(unit["health"]) == minimum_health)
	elif highest_health and not available.is_empty():
		var maximum_health: int = int(available[0]["health"])
		for unit in available:
			maximum_health = maxi(maximum_health, int(unit["health"]))
		var highest: Array = []
		for unit in available:
			if int(unit["health"]) == maximum_health:
				highest.append(unit)
		available = highest
	elif lowest_attack and not available.is_empty():
		var minimum_attack: int = int(available[0]["attack"])
		for unit in available:
			minimum_attack = mini(minimum_attack, int(unit["attack"]))
		var lowest: Array = []
		for unit in available:
			if int(unit["attack"]) == minimum_attack:
				lowest.append(unit)
		available = lowest
	elif respect_taunt and not taunts.is_empty():
		available = taunts
	if available.is_empty():
		return {}
	var ids: Array = []
	for unit in available:
		ids.append(unit["uid"])
	return available[_random_index(available.size(), purpose, ids)]

func _random_index(size: int, purpose: String, candidates: Array) -> int:
	var sand_pirate_rng_issue: String=_sand_barnstormer_host.pirate_tokens.before_rng(self,size,purpose,candidates)
	if not sand_pirate_rng_issue.is_empty(): _fail(sand_pirate_rng_issue);return 0
	var index: int = _rng.randi_range(0, size - 1)
	_emit("rng", {"purpose": purpose, "candidates": candidates.duplicate(true), "index": index, "choice": candidates[index]})
	var sand_pirate_rng_done: String=_sand_barnstormer_host.pirate_tokens.after_rng(self,purpose,index,_log[-1])
	if not sand_pirate_rng_done.is_empty(): _fail(sand_pirate_rng_done)
	return index

func _attack(side: int, attacker: Dictionary, strike: int, fixed_target: Dictionary = {}) -> void:
	var sand_pirate_exchange_issue: String=_sand_barnstormer_host.pirate_tokens.before_attack(self,side,attacker,strike,fixed_target)
	if not sand_pirate_exchange_issue.is_empty(): _fail(sand_pirate_exchange_issue);return
	var first_attack_frame: int=_first_attack_host.enter(self,side,attacker)
	if first_attack_frame<0: return
	var ditch_guardian_attack: Dictionary=_ditch_guardian_host.begin_attack(self,side,attacker,strike)
	if not ditch_guardian_attack.ok: _fail(str(ditch_guardian_attack.error));_first_attack_host.leave(self,first_attack_frame);return
	var hyena_attack_frame: int=_hyena_host.begin_attack(side,attacker)
	var jailbird_attack_frame: int=_jailbird_juggernaut_host.begin_attack(side,attacker)
	_piranha_host.exchange_depth+=1
	_attack_body(side,attacker,strike,fixed_target)
	_piranha_host.exchange_depth-=1
	_jailbird_juggernaut_host.close_attack(self,jailbird_attack_frame)
	_hyena_host.close_attack(self,hyena_attack_frame)
	var ditch_guardian_attack_close: String=_ditch_guardian_host.close_attack(self,ditch_guardian_attack.frame)
	if not ditch_guardian_attack_close.is_empty(): _fail(ditch_guardian_attack_close)
	_first_attack_host.leave(self,first_attack_frame)
	if _error.is_empty():
		var sand_pirate_exchange_done: String=_sand_barnstormer_host.pirate_tokens.after_attack(self,side,attacker)
		if not sand_pirate_exchange_done.is_empty(): _fail(sand_pirate_exchange_done)

func _attack_body(side: int, attacker: Dictionary, strike: int, fixed_target: Dictionary = {}) -> void:
	if not fixed_target.is_empty() and not Preemptive.live(self,1-side,fixed_target): _fail("rally_preemptive_original_defender_lost_unresolved");return
	if _cannot_attack(attacker): return
	# Recheck actual live sources after summons/reborn, before multiplication.
	var friendly_order_issues: Array[String] = FriendlyAttackRoom.errors_for_units(_boards[side],_options.get("hand_card_templates",{}),_options)
	if not friendly_order_issues.is_empty(): _fail(friendly_order_issues[0]); return
	# Only a concrete live reviewed witness may move a multiplier. Disjoint
	# attacks retain the old path, regardless of the room selection.
	var defer_multiply: bool = _options.get(AttackGainOrder.FIELD,"") == AttackGainOrder.FRIENDLY_FIRST and FriendlyAttackRoom.has_live_witness(_boards[side],attacker)
	var lowest_attack: bool = _has_keyword(attacker, "target_lowest_attack")
	for effect in attacker["effects"]:
		if str(effect.get("type", "")) == "on_attack_multiply":
			if not defer_multiply:
				_multiply_stats(attacker, effect, "on_attack")
		elif str(effect.get("type", "")) == "target_lowest_attack":
			lowest_attack = true
	var worgen_target_plan: Dictionary=Worgen.select(self,side,attacker,fixed_target)
	if not str(worgen_target_plan.error).is_empty(): _fail(str(worgen_target_plan.error));return
	var defender: Dictionary
	if worgen_target_plan.handled: defender=worgen_target_plan.target
	else: defender = fixed_target if not fixed_target.is_empty() else _target(1 - side, "lowest_attack_target" if lowest_attack else "attack_target", true, lowest_attack, false, false, true)
	if defender.is_empty():
		return
	if not _error.is_empty(): return
	# Keep the legal initial choice, then replace this attack's actual defender.
	# All following declaration, Rally, cleave and completion code sees this body.
	var elistra_target_plan: Dictionary=Elistra.replace_target(self,side,attacker,defender,fixed_target)
	if not str(elistra_target_plan.error).is_empty(): _fail(str(elistra_target_plan.error));return
	defender=elistra_target_plan.target
	var first_attack_issue: String=_first_attack_host.declaration_error(self,side,attacker)
	if not first_attack_issue.is_empty(): _fail(first_attack_issue);return
	_attacks += 1
	_emit("attack_declared", {"side": side, "attacker": attacker["uid"], "target": defender["uid"], "strike": strike})
	var krush_declaration_receipt: Dictionary=_log[-1]
	var ditch_guardian_declaration_issue: String=_ditch_guardian_host.declared(self,side,attacker,defender,krush_declaration_receipt)
	if not ditch_guardian_declaration_issue.is_empty(): _fail(ditch_guardian_declaration_issue);return
	_kibble_declaration={"side":side,"attacker":attacker,"receipt":krush_declaration_receipt}
	if not _kibble_host.capture(self,side,attacker,krush_declaration_receipt): return
	_kibble_declaration={}
	if not _owned_attack_host.capture(self,side,attacker,krush_declaration_receipt): return
	if not _first_attack_host.declared(self,side,attacker,krush_declaration_receipt): return
	if _has_keyword(attacker,"stealth"):
		RebornRetention.consume_keyword(attacker,"stealth")
		_battlecruiser_ultra_host.consume_keyword(attacker,"stealth")
		_hag_reborn_host.consume_keyword(attacker,"stealth")
		attacker.keywords.erase("stealth")
		var bonus_stealth_sequence: int=_log.size()
		_emit("keyword_removed",{"source":attacker.uid,"target":attacker.uid,"keyword":"stealth","reason":"actual_attack_declaration"})
		if not KeywordLoss.observe(self,attacker,"stealth",bonus_stealth_sequence): return
	_trigger_attack_declaration(side, attacker, defender, defer_multiply,krush_declaration_receipt)
	if not _error.is_empty():
		return
	if not KrushPreemptive.after_declaration(self,side,attacker,defender,krush_declaration_receipt): return
	if not _rally_live_target(attacker) or not _rally_live_target(defender):
		_emit("attack_cancelled",{"declaration_sequence":krush_declaration_receipt.sequence,"attacker":attacker.uid,"target":defender.uid,"reason":"participant_died_during_declaration"})
		return
	var queued_attack_effects: Array = []
	# All attack-triggered effects are queued from the declared target geometry.
	# A repeated effect still damages surviving original neighbours after the
	# primary dies; newly summoned replacements are not retroactively targeted.
	for effect in attacker["effects"]:
		if str(effect.get("type", "")) != "on_attack_damage":
			continue
		var pre_packets: Array = [{"source": attacker, "target": defender, "amount": int(effect["amount"]), "kind": "on_attack_damage"}]
		var defender_index: int = _boards[1 - side].find(defender)
		for neighbor in [defender_index - 1, defender_index + 1]:
			if neighbor >= 0 and neighbor < _boards[1 - side].size():
				pre_packets.append({"source": attacker, "target": _boards[1 - side][neighbor], "amount": int(effect["amount"]), "kind": "on_attack_damage"})
		queued_attack_effects.append({"packets": pre_packets, "amount": int(effect["amount"])})
	_hyena_host.rallies(self,side,attacker,defender,krush_declaration_receipt)
	if not _error.is_empty():
		return
	if JailbirdJuggernaut.Sources.claimed(attacker) and (not Preemptive.live(self,side,attacker) or not Preemptive.live(self,1-side,defender)):
		_emit("attack_cancelled",{"declaration_sequence":krush_declaration_receipt.sequence,"attacker":attacker.uid,"target":defender.uid,"reason":"participant_died_during_jailbird_rally"})
		return
	if Preemptive.claimed(attacker) and not Preemptive.live(self,side,attacker):
		_emit("attack_cancelled",{"declaration_sequence":krush_declaration_receipt.sequence,"attacker":attacker.uid,"target":defender.uid,"reason":"attacker_died_during_preemptive_rally"})
		return
	for queued in queued_attack_effects:
		if not _tick("attack_trigger_damage"):
			return
		var live_packets: Array = []
		for packet in queued["packets"]:
			var target_unit: Dictionary = packet["target"]
			if not _find_unit(int(target_unit["_side"]), int(target_unit["_combat_id"])).is_empty() and int(target_unit["health"]) > 0:
				live_packets.append(packet)
		_emit("attack_effect", {"source": attacker["uid"], "target": defender["uid"], "effect": "on_attack_damage", "amount": queued["amount"]})
		if not live_packets.is_empty():
			_damage_batch(live_packets)
		_resolve_deaths()
		if not _error.is_empty():
			return
	if _find_unit(side, int(attacker["_combat_id"])).is_empty() or _find_unit(1 - side, int(defender["_combat_id"])).is_empty():
		_emit("attack_cancelled", {"declaration_sequence":krush_declaration_receipt.sequence,"attacker": attacker["uid"], "target": defender["uid"], "reason": "participant_died_before_damage_exchange"})
		return
	var attack_damage: int = int(attacker["attack"])
	var retaliation: int = int(defender["attack"])
	var packets: Array = [{"source": attacker, "target": defender, "amount": attack_damage, "kind": "attack"}, {"source": defender, "target": attacker, "amount": retaliation, "kind": "retaliation"}]
	for effect in attacker["effects"]:
		if str(effect.get("type", "")) == "on_attack_cleave":
			var target_index: int = _boards[1 - side].find(defender)
			for adjacent_index in [target_index - 1, target_index + 1]:
				if adjacent_index >= 0 and adjacent_index < _boards[1 - side].size():
					packets.append({"source": attacker, "target": _boards[1 - side][adjacent_index], "amount": attack_damage, "kind": "cleave"})
			break
	var loh_attack_sequence: int=_log.size()
	_emit("attack", {"witness_taunt_contract":WitnessProtection.CONTRACT,"declaration_sequence":krush_declaration_receipt.sequence,"target_side":1-side,"target_taunt":_has_keyword(defender,"taunt"),"side": side, "attacker": attacker["uid"], "target": defender["uid"], "attacker_name": attacker.get("name", ""), "target_name": defender.get("name", ""), "strike": strike, "damage": attack_damage, "retaliation": retaliation})
	if not _pirate_chest_host.capture(self,side,attacker,loh_attack_sequence): return
	# Bind direct attack/retaliation packets to this actual exchange receipt.
	for attack_packet in packets: attack_packet.attack_sequence=loh_attack_sequence
	var adjacent_attack_observers: Array=[]
	var attack_position: int=_boards[side].find(attacker)
	for adjacent_position in [attack_position-1,attack_position+1]:
		if adjacent_position>=0 and adjacent_position<_boards[side].size(): adjacent_attack_observers.append(_boards[side][adjacent_position])
	# Retain the original host-owned identity across the complete exchange.
	var beetle_attack_observers: Array=BeetleObserver.attack_snapshot(self,side)
	var living_dr_observers: Array=LivingDeathrattles.attack_snapshot(self,side,attacker)
	var completed_uid: String = str(attacker.uid) if _completed_attack_enabled else ""
	var completed_id: int = int(attacker._combat_id) if _completed_attack_enabled else 0
	_damage_batch(packets)
	if _error.is_empty():
		_volatile_venom_attack_context={"side":side,"attacker":attacker,"sequence":loh_attack_sequence,"used":false}
		var volatile_venom_attack_issue: String=_volatile_venom_host.completed_attack(self,side,attacker,loh_attack_sequence)
		_volatile_venom_attack_context={}
		if not volatile_venom_attack_issue.is_empty(): _fail(volatile_venom_attack_issue);return
	if _error.is_empty() and not _pirate_chest_host.completed_exchange(self,side,attacker,loh_attack_sequence): return
	if _error.is_empty() and not _beetle_observer_host.after_attack(self,side,attacker,loh_attack_sequence,beetle_attack_observers): return
	if _error.is_empty() and _loh_reward_host!=null and not _loh_reward_host.after_attack(self,side,str(attacker.uid),str(defender.uid),strike,loh_attack_sequence): return
	if _completed_attack_enabled and _error.is_empty():
		CompletedAttack.completed_attack(self,side,completed_uid,completed_id)
	if _error.is_empty() and not LivingDeathrattles.after_attack(self,side,str(attacker.uid),living_dr_observers): return
	if _error.is_empty() and not _owned_combat_gem_host.after_attack(self,side,attacker,loh_attack_sequence): return
	if _error.is_empty():
		for listener in adjacent_attack_observers:
			if not _rally_live_target(listener) or listener.get("_pending_destroy",false) or listener.get("silenced",false) or listener.get("abilities_disabled",false): continue
			for effect in listener.get("effects",[]):
				if effect.get("type")!="after_adjacent_attack_damage": continue
				for shot in range(int(effect.shots)):
					if not _tick("after_adjacent_attack_damage"): return
					var candidates: Array=[]
					var candidate_uids: Array=[]
					for enemy in _boards[1-side]:
						if int(enemy.health)>0 and not enemy.get("_pending_destroy",false): candidates.append(enemy);candidate_uids.append(enemy.uid)
					if candidates.is_empty(): break
					var recipient: Dictionary=candidates[_random_index(candidates.size(),"adjacent_attack_damage_enemy",candidate_uids)]
					_emit("adjacent_attack_damage",{"source":listener.uid,"attacker":attacker.uid,"target":recipient.uid,"shot":shot+1,"amount":int(effect.amount)})
					_damage_batch([{"source":listener,"target":recipient,"amount":int(effect.amount),"kind":"adjacent_attack_damage"}])
					if not _error.is_empty(): return
					if not _rally_live_target(listener) or listener.get("_pending_destroy",false): break
	if _error.is_empty() and _rally_live_target(defender) and not defender.get("_pending_destroy",false) and not defender.get("silenced",false) and not defender.get("abilities_disabled",false):
		for effect in defender.get("effects",[]):
			if effect.get("type")!="after_attacked_survived_force_leftmost": continue
			var leftmost: Dictionary={}
			for friendly in _boards[1-side]:
				if int(friendly.health)>0 and not friendly.get("_pending_destroy",false): leftmost=friendly;break
			if leftmost.is_empty(): continue
			_emit("attacked_survived_counter",{"source":defender.uid,"target":leftmost.uid,"attacker":attacker.uid})
			_force_single_attack(1-side,leftmost,"attacked_survived_immediate_attack")
			if not _error.is_empty() or not _rally_live_target(defender) or defender.get("_pending_destroy",false): break

	if not _error.is_empty() or not _rally_live_target(attacker) or attacker.get("_pending_destroy",false): return
	for effect in attacker.get("effects",[]):
		if effect.get("type")!="after_attack_highest_health_damage": continue
		if attacker.get("silenced",false) or attacker.get("abilities_disabled",false): continue
		if not _tick("after_attack_highest_health_damage"): return
		var multiplier: int=int(effect.multiplier)
		var current_attack: int=int(attacker.attack)
		if current_attack<0 or current_attack>9007199254740991/multiplier: _fail("After attack damage arithmetic overflow");return
		var candidates: Array=[]
		var highest_health: int=0
		for enemy in _boards[1-side]:
			if int(enemy.health)<=0 or enemy.get("_pending_destroy",false): continue
			if int(enemy.health)>highest_health: highest_health=int(enemy.health);candidates.clear()
			if int(enemy.health)==highest_health: candidates.append(enemy)
		if candidates.is_empty(): continue
		var candidate_uids: Array=[]
		for enemy in candidates: candidate_uids.append(enemy.uid)
		var recipient: Dictionary=candidates[_random_index(candidates.size(),"after_attack_highest_health",candidate_uids)]
		var amount: int=current_attack*multiplier
		_emit("after_attack_highest_health_damage",{"source":attacker.uid,"target":recipient.uid,"amount":amount})
		_damage_batch([{"source":attacker,"target":recipient,"amount":amount,"kind":"after_attack_highest_health_damage"}])
		if not _error.is_empty(): return
		_resolve_deaths()
		if not _error.is_empty() or not _rally_live_target(attacker) or attacker.get("_pending_destroy",false): return


func _trigger_attack_declaration(side: int, attacker: Dictionary, defender: Dictionary, defer_multiply: bool = false, declaration: Dictionary = {}) -> void:
	# Attack declaration hooks resolve before pre-hit damage and before the
	# normal simultaneous exchange snapshots either minion's attack value.
	for listener in _boards[side].duplicate():
		if not FriendlyAttack.living(listener): continue
		for effect in listener["effects"]:
			if effect.get("type")==Protoss.Sources.ATTACK:
				if not Protoss.void_ray(self,side,listener,attacker,effect): return
				continue
			if effect.get("type")==CombatRingCast.AttackSources.TYPE:
				if not _native_spell_attack_context.is_empty(): _fail("friendly_attack_ring_nested_dispatch");return
				_native_spell_attack_context={"side":side,"source":listener,"effect":effect,"attacker":attacker,"receipt":declaration}
				var friendly_attack_ring_ok: bool=_combat_ring_cast_host.friendly_attack(self,side,listener,effect,attacker,declaration)
				_native_spell_attack_context={}
				if not friendly_attack_ring_ok: return
				continue
			if effect.get("type")==CombatGemTriggers.Sources.ATTACK:
				if not CombatGemTriggers.attack(_kill_reward_host,self,side,listener,attacker,effect,declaration): return
				continue
			if effect.get("type") == "on_friendly_attack_damage":
				if effect.exclude_self and int(listener._combat_id)==int(attacker._combat_id): continue
				if not _tribe_matches(attacker,str(effect.tribe)): continue
				if not _rally_live_target(attacker) or not _rally_live_target(defender): continue
				if not _tick("friendly_attack_damage"): return
				_emit("friendly_attack_damage",{"source":listener.uid,"attacker":attacker.uid,"target":defender.uid,"amount":int(effect.amount)})
				_damage_batch([{"source":listener,"target":defender,"amount":int(effect.amount),"kind":"friendly_attack_damage"}])
				if not _error.is_empty(): return
				_resolve_deaths()
				if not _error.is_empty(): return
				continue
			if effect.get("type") != FriendlyAttack.TYPE: continue
			if not FriendlyAttack.trigger(self,side,listener,attacker,effect): return
	if not _kibble_host.declared(self,side,attacker,declaration): return
	if not _owned_attack_host.declared(self,side,attacker,declaration): return
	if defer_multiply:
		# The one validated scalar program was skipped at the original seam.
		# Defender-attacked hooks, Rally, pre-hit and exchange stay after it.
		_multiply_stats(attacker, attacker.effects[0], "on_attack")
		if not _error.is_empty(): return
	for listener in _boards[1 - side].duplicate():
		if int(listener["health"]) <= 0:
			continue
		for effect in listener["effects"]:
			if TreantAttack.effect_claimed(effect):
				if not TreantAttack.trigger(self,1-side,listener,defender,effect): return
				continue
			if ChampionAttack.effect_claimed(effect):
				if not ChampionAttack.trigger(self,1-side,listener,defender,effect): return
				continue
			if effect.get("type") == "on_attacked_set_attacker_health":
				if int(listener._combat_id)!=int(defender._combat_id) or not is_same(listener,defender): continue
				if not FriendlyAttack.living(listener) or not _rally_live_target(attacker): continue
				if not _tick("attacked_set_attacker_health"): return
				if BoardAuraRuntime.managed(attacker):
					var attacker_owner: Variant = attacker.get(BoardAura.APPLIED_KEY,{}).get("owner",_options.get(("left" if side==0 else "right")+"_board_aura_owner",0))
					var health_plan: Dictionary = BoardAura.build_rebase_plan(attacker,attacker_owner,{"health":int(effect.health),"max_health":int(effect.health)})
					if not str(health_plan.error).is_empty(): _fail(str(health_plan.error)); return
					var scalar_after: Dictionary=attacker.duplicate(true)
					BoardAura._write_stats(scalar_after,health_plan.after)
					var loc_scalar: Dictionary=LocPrince.scalar(attacker,scalar_after)
					if not loc_scalar.ok: _fail(str(loc_scalar.error));return
					scalar_after=loc_scalar.after
					var loc_scalar_context: String=LocPrince.combat_error(self,attacker,int(scalar_after.attack)-int(attacker.attack),int(scalar_after.max_health)-int(attacker.max_health))
					if not loc_scalar_context.is_empty(): _fail(loc_scalar_context);return
					if _mishmash_stat_host!=null:
						var scalar_issue: String=_mishmash_stat_host.prepare_combat_transition(self,attacker,scalar_after,"stat_set","attacked_set_attacker_health")
						if not scalar_issue.is_empty(): _fail(scalar_issue);return
					var health_issue: String = BoardAura.commit_unit_plan(attacker,attacker_owner,health_plan)
					if not health_issue.is_empty(): _fail(health_issue); return
				else:
					var scalar_after: Dictionary=attacker.duplicate(true)
					scalar_after.health=int(effect.health);scalar_after.max_health=int(effect.health)
					var loc_scalar: Dictionary=LocPrince.scalar(attacker,scalar_after)
					if not loc_scalar.ok: _fail(str(loc_scalar.error));return
					scalar_after=loc_scalar.after
					var loc_scalar_context: String=LocPrince.combat_error(self,attacker,int(scalar_after.attack)-int(attacker.attack),int(scalar_after.max_health)-int(attacker.max_health))
					if not loc_scalar_context.is_empty(): _fail(loc_scalar_context);return
					if _mishmash_stat_host!=null:
						var scalar_issue: String=_mishmash_stat_host.prepare_combat_transition(self,attacker,scalar_after,"stat_set","attacked_set_attacker_health")
						if not scalar_issue.is_empty(): _fail(scalar_issue);return
					attacker.attack=int(scalar_after.attack);attacker.health=int(scalar_after.health);attacker.max_health=int(scalar_after.max_health)
				_loc_prince_host.capture(attacker)
				var loc_set_event: Dictionary={"source":listener.uid,"target":attacker.uid,"health":attacker.health,"max_health":attacker.max_health,"reason":"attacked_set_attacker_health"}
				if LocPrince.Sources.claimed(attacker): loc_set_event.attack=attacker.attack
				_emit("stat_set",loc_set_event)
				continue
			if effect.get("type") == AttackedAdjacent.TYPE:
				if not AttackedAdjacent.trigger(self,1-side,listener,defender,effect): return
				continue
			if effect.get("type") == AttackedVenomous.TYPE:
				if not AttackedVenomous.trigger(self,1-side,listener,defender,effect): return
				continue
			if str(effect.get("type", "")) != "on_attacked_buff":
				continue
			if effect.get("require_self",false):
				var self_issue: String = dozy_program_error(listener)
				if self_issue.is_empty(): self_issue = attacked_effect_error(effect)
				if not self_issue.is_empty(): _fail(self_issue); return
				if not FriendlyAttack.living(listener) or not FriendlyAttack.living(defender): continue
				if listener.get("_combat_id") != defender.get("_combat_id") or listener.get("uid") != defender.get("uid"): continue
				var actual_defender: Dictionary = _find_unit(1-side,int(defender.get("_combat_id",-1)))
				if not is_same(actual_defender,defender) or not is_same(actual_defender,listener): continue
				self_issue = FriendlyAttack.recipient_error(defender,int(effect.get("attack",0)),int(effect.get("health",0)))
				if not self_issue.is_empty(): _fail(self_issue); return
			var required: String = str(effect.get("require_keyword", ""))
			if not required.is_empty() and not _has_keyword(defender, required):
				continue
			if not _tick("attacked_trigger"):
				return
			_apply_trigger_buff(listener, defender, effect, "friendly_attacked", str(defender["uid"]))
			if effect.get("require_self",false) and not _error.is_empty(): return
			if bool(effect.get("permanent", false)):
				_emit("persistent_buff", {"type": "persistent_buff", "side": 1 - side, "source": str(listener["uid"]), "target_uid": str(defender["uid"]), "attack_delta": int(effect.get("attack", 0)), "health_delta": int(effect.get("health", 0))})

func _damage_batch(packets: Array) -> void:
	var belcher_portrait_batch_issue: String=_kill_reward_host._belcher_portrait_host.batch_error(self,packets)
	if not belcher_portrait_batch_issue.is_empty(): _fail(belcher_portrait_batch_issue);return
	var matador_batch_issue: String=_matador_host.batch_error(self,packets)
	if not matador_batch_issue.is_empty(): _fail(matador_batch_issue);return
	var orca_issue: String=DamageListenerHost.orca_batch_error(self,packets)
	if not orca_issue.is_empty(): _fail(orca_issue); return
	_damage_listener_batch_id += 1
	var native_enforcer_batch: int=_damage_listener_batch_id
	if not _native_enforcer_host.begin_batch(self,native_enforcer_batch): return
	var overkill_tickets: Array=[]
	var received_packets: Array = []
	var actual_damage_packets: Array = []
	var beetle_received_tickets: Array=[]
	var received_native_tickets: Array=[]
	var damage_followup_tickets: Array=[]
	var dealt_lifetime_tickets: Array=[]
	var dealt_packets: Array = []
	var exact_destroy_targets: Array = []
	var packet_index: int = -1
	var shield_losses: Array = []
	var bonus_keyword_losses: Array=[]
	var damaged_units: Array = []
	var damaged_ids: Dictionary = {}
	_emit("damage_batch_start", {"count": packets.size()})
	# Apply all snapshotted damage before checking deaths. A lethally hit defender
	# still retaliates; cleave neighbours never retaliate.
	for packet in packets:
		packet_index += 1
		var matador_packet_plan: Dictionary=_matador_host.replace_packet(self,packet,packet_index)
		if not str(matador_packet_plan.error).is_empty(): _fail(str(matador_packet_plan.error));return
		if matador_packet_plan.changed: packet=matador_packet_plan.packet
		actual_damage_packets.append(packet)
		var source: Dictionary = packet["source"]
		var target_unit: Dictionary = packet["target"]
		var amount: int = int(packet["amount"])
		if _options.has(DamageListenerHost.CONTEXT):
			_damage_listener_packet={"batch_id":_damage_listener_batch_id,"packet_index":packet_index,"source":source.uid,"source_side":source._side,"source_combat_id":source._combat_id,"target":target_unit.uid,"target_side":target_unit._side,"target_combat_id":target_unit._combat_id,"kind":str(packet["kind"])}
		if amount <= 0:
			_emit("damage", {"source": source["uid"], "target": target_unit["uid"], "amount": 0, "kind": packet["kind"]})
			continue
		if bool(target_unit.get("_attacking", false)) and _has_keyword(target_unit, "immunity_while_attacking"):
			_emit("immune_blocked", {"source": source["uid"], "target": target_unit["uid"], "blocked": amount})
			continue
		if _has_keyword(target_unit, "divine_shield"):
			if DarkGiftSources.shield_gift(target_unit):
				var gift_shield_issue: String=_dark_gift_combat_host.trait_error(self,int(target_unit._side),target_unit)
				if not gift_shield_issue.is_empty(): _fail(gift_shield_issue);return
				if not target_unit.get("silenced",false) and not target_unit.get("abilities_disabled",false):
					var gift_shield_used: int=int(target_unit.get("_native_shield_hits",0))+1
					if gift_shield_used<3:
						target_unit._native_shield_hits=gift_shield_used
						_emit("native_shield_hit",{"source":source.uid,"target":target_unit.uid,"blocked":amount,"kind":packet.kind,"capacity":3,"remaining":3-gift_shield_used,"gift_id":DarkGiftSources.SHIELD_GIFT,"gift_receipt":target_unit[DarkGiftSources.MARKER].duplicate(true)})
						continue
			if target_unit.get("card_id") in ["BG36_360t4","BG36_360_Gt4"] and not target_unit.get("silenced",false) and not target_unit.get("abilities_disabled",false):
				var multi_capacity: int=3 if target_unit.card_id=="BG36_360t4" else 4
				if target_unit.get("effects")!=[{"type":"native_multi_hit_shield","capacity":multi_capacity}]: _fail("multi_hit_shield_changed_live_program");return
				var multi_used: int=int(target_unit.get("_native_shield_hits",0))+1
				if multi_used<multi_capacity:
					target_unit._native_shield_hits=multi_used
					_emit("native_shield_hit",{"source":source.uid,"target":target_unit.uid,"blocked":amount,"kind":packet.kind,"capacity":multi_capacity,"remaining":multi_capacity-multi_used})
					continue
			_hopebringer_removal_context={"source":source,"target":target_unit,"amount":amount}
			var hopebringer_loss_ticket: Dictionary=_hopebringer_host.before_loss(self,source,target_unit,amount)
			_hopebringer_removal_context={}
			if not _error.is_empty(): return
			target_unit.erase("_native_shield_hits")
			RebornRetention.consume_keyword(target_unit,"divine_shield")
			_battlecruiser_ultra_host.consume_keyword(target_unit,"divine_shield")
			_hag_reborn_host.consume_keyword(target_unit,"divine_shield")
			target_unit["keywords"].erase("divine_shield")
			var shield_loss_sequence: int=_log.size()
			_emit("shield_lost", {"source": source["uid"], "target": target_unit["uid"], "blocked": amount, "kind": packet["kind"]})
			var sand_mech_shield_issue: String=_sand_barnstormer_host.demon_tokens.consumed_shield(self,source,target_unit,amount,str(packet["kind"]),_log[-1])
			if not sand_mech_shield_issue.is_empty(): _fail(sand_mech_shield_issue);return
			if not _hopebringer_host.finish_loss(self,hopebringer_loss_ticket,_log[shield_loss_sequence]): return
			shield_losses.append({"unit": target_unit, "source": source,"sequence":shield_loss_sequence,"hopebringer_ticket":hopebringer_loss_ticket})
			if not _native_enforcer_host.capture(self,native_enforcer_batch,source,target_unit,_log[shield_loss_sequence]): return
			if not _owned_mech_shield_host.capture(self,"shield_lost",int(target_unit._side),target_unit,_log[shield_loss_sequence]): return
			bonus_keyword_losses.append({"unit":target_unit,"keyword":"divine_shield","sequence":shield_loss_sequence})
			# Packet Attack was captured by _attack before this batch. Only the
			# current Shield recipient layer changes here; pending bodies remain.
			if BoardAuraRuntime.Aura.Cyberdrake.boards_have_source(_boards):
				if not BoardAuraRuntime.sync_combat(self,"shield_loss_board_aura"): return
			continue
		var whitemane_damage_plan: Dictionary=_start_choice_host.damage_plan(self,target_unit,amount)
		if not str(whitemane_damage_plan.error).is_empty(): _fail(str(whitemane_damage_plan.error));return
		amount=int(whitemane_damage_plan.amount)
		var received_packet_issue: String = DamageListenerHost.before_packet(self,source,target_unit,amount)
		if not received_packet_issue.is_empty(): _fail(received_packet_issue); return
		var jaraxxus_damage_ticket: int=_plain_copy_host._jaraxxus_host.before_packet(self,source,target_unit,amount,str(packet["kind"]))
		if not _error.is_empty(): return
		var dealt_lifetime_ticket: int=_kill_reward_host._dealt_lifetime_host.before_packet(self,_kill_reward_host,source,target_unit,amount)
		if not _error.is_empty(): return
		var damage_followup_ticket: int=_kill_reward_host._damage_followup_host.before_packet(self,source,target_unit,amount)
		if not _error.is_empty(): return
		var received_native_ticket: int=_kill_reward_host.before_received_packet(self,source,target_unit,amount)
		if not _error.is_empty(): return
		var received_health_before: int = int(target_unit["health"])
		var received_pending_before: bool = bool(target_unit.get("_pending_destroy",false))
		var was_alive: bool = int(target_unit["health"]) > 0
		var wildfire_capture: Dictionary=Wildfire.capture(self,source,target_unit,amount,received_health_before,int(packet.get("attack_sequence",-1))) if was_alive and not received_pending_before and packet.get("kind")=="attack" else {}
		if not str(wildfire_capture.get("error","")).is_empty(): _fail(str(wildfire_capture.error));return
		target_unit["health"] = int(target_unit["health"]) - amount
		var poison: bool = _has_keyword(source, "poisonous")
		var venom: bool = _has_keyword(source, "venomous")
		if venom:
			RebornRetention.consume_keyword(source,"venomous")
			_battlecruiser_ultra_host.consume_keyword(source,"venomous")
			_hag_reborn_host.consume_keyword(source,"venomous")
			source["keywords"].erase("venomous")
			var bonus_venom_sequence: int=_log.size()
			_emit("venomous_used", {"source": source["uid"], "target": target_unit["uid"]})
			if not _kill_reward_host._belcher_portrait_host.capture(self,source,target_unit,amount,bonus_venom_sequence): return
			bonus_keyword_losses.append({"unit":source,"keyword":"venomous","sequence":bonus_venom_sequence})
		if poison or venom:
			target_unit["_pending_destroy"] = true
			target_unit["health"] = mini(0, int(target_unit["health"]))
		if was_alive and int(target_unit["health"]) <= 0:
			target_unit["_killer"] = int(source["_combat_id"])
			target_unit["_killer_card_id"] = str(source.get("card_id",source.get("id",""))) if source.get("kind","minion")=="minion" else ""
		_emit("damage", {"attack_sequence":packet.get("attack_sequence",-1),"source_combat_id":source.get("_combat_id",-1),"health_before":received_health_before,"source": source["uid"], "target": target_unit["uid"], "amount": amount, "health": target_unit["health"], "lethal_keyword": poison or venom, "kind": packet["kind"]})
		var actual_damage_sequence: int=_log.size()-1
		var overkill_ticket: Dictionary=_overkill_host.capture(self,source,target_unit,amount,received_health_before,received_pending_before,actual_damage_sequence)
		if not _error.is_empty(): return
		if not overkill_ticket.is_empty(): overkill_tickets.append(overkill_ticket)
		_plain_copy_host._jaraxxus_host.capture(self,jaraxxus_damage_ticket,actual_damage_sequence,_damage_listener_batch_id,packet_index)
		if not _error.is_empty(): return
		if target_unit.get("card_id") in BeetleObserver.Sources.DAMAGE_IDS and was_alive and not received_pending_before and not target_unit.get("silenced",false) and not target_unit.get("abilities_disabled",false):
			beetle_received_tickets.append({"source":target_unit,"sequence":actual_damage_sequence})
		_kill_reward_host._dealt_lifetime_host.capture(self,dealt_lifetime_ticket,actual_damage_sequence,_damage_listener_batch_id,packet_index)
		if not _error.is_empty(): return
		if dealt_lifetime_ticket>0: dealt_lifetime_tickets.append(dealt_lifetime_ticket)
		_kill_reward_host._damage_followup_host.capture(self,damage_followup_ticket,actual_damage_sequence,_damage_listener_batch_id,packet_index)
		if not _error.is_empty(): return
		if damage_followup_ticket>0: damage_followup_tickets.append(damage_followup_ticket)
		_kill_reward_host.capture_received_packet(self,received_native_ticket,actual_damage_sequence,_damage_listener_batch_id,packet_index)
		if not _error.is_empty(): return
		if received_native_ticket>0: received_native_tickets.append(received_native_ticket)
		if was_alive and not received_pending_before and int(target_unit.health)<=0 and _kill_reward_host!=null:
			_kill_reward_host.capture(self,source,target_unit,actual_damage_sequence,str(packet["kind"]),int(packet.get("attack_sequence",-1)),wildfire_capture)
			var sand_leeroy_capture_issue: String=_sand_barnstormer_host.pirate_tokens.leeroy.capture_damage(self,packet,target_unit,received_health_before,received_pending_before,actual_damage_sequence)
			if not sand_leeroy_capture_issue.is_empty(): _fail(sand_leeroy_capture_issue);return
		var received_packet: Dictionary = DamageListenerHost.capture(self,source,target_unit,amount,str(packet["kind"]),received_health_before,received_pending_before,packet_index,actual_damage_sequence)
		if not received_packet.is_empty(): received_packets.append(received_packet)
		var dealt_packet: Dictionary=ThresholdDamage.capture_dealt(self,source,target_unit,amount,was_alive,received_pending_before,_damage_listener_batch_id,packet_index,actual_damage_sequence)
		if not dealt_packet.is_empty(): dealt_packets.append(dealt_packet)
		if was_alive and not received_pending_before and not target_unit.get("silenced",false) and not target_unit.get("abilities_disabled",false):
			for reaction in target_unit.get("effects",[]):
				if reaction.get("type")=="on_exact_damage_destroy_self" and int(reaction.amount)==amount:
					if not exact_destroy_targets.has(target_unit): exact_destroy_targets.append(target_unit)

		var damaged_id: int = int(target_unit["_combat_id"])
		if not damaged_ids.has(damaged_id):
			damaged_ids[damaged_id] = true
			damaged_units.append(target_unit)
	_emit("damage_batch_end", {})
	if not _overkill_host.process(self,overkill_tickets): return
	if _error.is_empty():
		for bonus_loss in bonus_keyword_losses:
			if not KeywordLoss.observe(self,bonus_loss.unit,str(bonus_loss.keyword),int(bonus_loss.sequence)): return
			if not _kill_reward_host._belcher_portrait_host.observe(self,_kill_reward_host,bonus_loss.unit,str(bonus_loss.keyword),int(bonus_loss.sequence)): return
	_process_shield_losses(shield_losses)
	if not _error.is_empty() or not _native_enforcer_host.finish_batch(self,native_enforcer_batch): return
	if _error.is_empty():
		for beetle_ticket in beetle_received_tickets:
			if not _beetle_observer_host.received(self,beetle_ticket.source,int(beetle_ticket.sequence)): return
	if _error.is_empty():
		_damage_resource_host.begin_counter_window()
		DamageListenerHost.process(self,received_packets,actual_damage_packets)
		if _error.is_empty() and not _kill_reward_host.process_received_packets(self,received_native_tickets): return
		if _error.is_empty() and not _kill_reward_host._damage_followup_host.process_received(self,_kill_reward_host,damage_followup_tickets): return
		_damage_resource_host.complete_counter_window(self)
	if _error.is_empty():
		for target in exact_destroy_targets:
			if not _rally_live_target(target) or target.get("_pending_destroy",false): continue
			if not _tick("exact_damage_self_destroy"): return
			target._pending_destroy=true;target.health=0
			target._killer=-1;target._killer_card_id=""
			_emit("destroy",{"source":target.uid,"target":target.uid,"reason":"exact_damage_self_destroy"})
		_process_damage_survivals(damaged_units)
	if _error.is_empty(): ThresholdDamage.resolve_dealt(self,dealt_packets)
	if _error.is_empty(): _kill_reward_host._damage_followup_host.process_dealt(self,_kill_reward_host,damage_followup_tickets)
	if _error.is_empty(): _kill_reward_host._dealt_lifetime_host.process(self,dealt_lifetime_tickets)



func _process_damage_survivals(damaged_units: Array) -> void:
	for unit in damaged_units:
		if unit.get("card_id","") in ["BG_BAR_073","TB_BaconUps_320"] and int(unit.get("health",0))>0 and not unit.get("_pending_destroy",false) and not unit.get("silenced",false) and not unit.get("abilities_disabled",false):
			for frenzy_index in range(unit.effects.size()):
				var frenzy_effect: Dictionary=unit.effects[frenzy_index]
				if frenzy_effect.get("type")!="frenzy_other_buff": continue
				var frenzy_key: String="bulk_frenzy:"+str(frenzy_index)
				if unit._survival_used.has(frenzy_key): continue
				var frenzy_amount: int=4 if unit.card_id=="TB_BaconUps_320" else 2
				if frenzy_effect!={"type":"frenzy_other_buff","attack":frenzy_amount,"health":frenzy_amount}: _fail("Invalid native Frenzy program");return
				if not _tick("frenzy_other_buff"): return
				unit._survival_used[frenzy_key]=1
				for frenzy_target in _boards[int(unit._side)].duplicate():
					if frenzy_target.uid==unit.uid or int(frenzy_target.health)<=0 or frenzy_target.get("_pending_destroy",false): continue
					_apply_trigger_buff(unit,frenzy_target,frenzy_effect,"frenzy_other_buff",str(unit.uid))
					if not _error.is_empty(): return
		if int(unit["health"]) <= 0:
			continue
		for effect_index in range(unit["effects"].size()):
			var effect: Dictionary = unit["effects"][effect_index]
			if str(effect.get("type", "")) != "on_damage_survived":
				continue
			var key: String = str(effect_index)
			var limit: int = int(effect.get("limit", 1 if bool(effect.get("once", true)) else _max_steps))
			var used: int = int(unit["_survival_used"].get(key, 0))
			if used >= limit:
				continue
			if not _tick("damage_survived"):
				return
			unit["_survival_used"][key] = used + 1
			_emit("damage_survived", {"source": unit["uid"], "keyword": effect["keyword"], "health": unit["health"], "used": used + 1, "limit": limit})
			if not _has_keyword(unit, str(effect["keyword"])):
				unit["keywords"].append(str(effect["keyword"]))
				_emit("keyword_granted", {"source": unit["uid"], "target": unit["uid"], "keyword": effect["keyword"], "reason": "damage_survived"})

func _process_shield_losses(losses: Array) -> void:
	# Explicit local order: packets first, then loss-major/board-source callbacks.
	# The source-bound native Enforcer reader admits initially active health-lethal
	# bodies before collection. Legacy readers retain their existing live filter;
	# no inference is made about Mecherel or official simultaneous ordering.
	for loss in losses:
		var shielded: Dictionary = loss["unit"]
		var side: int = int(shielded["_side"])
		for listener in _boards[side].duplicate():
			if Hopebringer.Sources.claimed(listener):
				if not _hopebringer_host.observe(self,listener,loss): return
				continue
			if NativeEnforcer.Sources.claimed(listener):
				if not _native_enforcer_host.activate(self,listener,loss): return
				continue
			if listener.get("card_id","") in ["BGS_068", "BG20_401", "BG20_401_G", "BGS_067", "TB_BaconUps_117", "BG_ICC_858", "TB_BaconUps_047", "BG21_037", "BG21_037_G"] and (listener.get("silenced",false) or listener.get("abilities_disabled",false) or listener.get("_pending_destroy",false)): continue
			if int(listener["health"]) <= 0:
				continue
			for effect_index in range(listener["effects"].size()):
				var effect: Dictionary = listener["effects"][effect_index]
				var effect_type: String = str(effect.get("type", ""))
				if effect_type==NativeGem.Sources.SHIELD:
					if not _native_gem_host.shield(self,listener,effect,loss): return
					continue
				if effect_type==ShinyLayer.Sources.TYPE:
					if not _shiny_layer_host.activate(self,listener,effect,loss): return
					continue
				if effect_type==ShieldPermanent.Sources.TYPE:
					if _kill_reward_host==null: _fail("shield_permanent_private_journal_missing");return
					if not ShieldPermanent.activate(_kill_reward_host,self,listener,effect,loss): return
					continue
				if effect_type=="on_shield_lost_hand_buff":
					if listener.get("_pending_destroy",false) or listener.get("silenced",false) or listener.get("abilities_disabled",false): continue
					if not _tick("shield_loss_hand_buff"): return
					_emit("shield_loss_hand_buff",{"source":listener.uid,"trigger_unit":shielded.uid,"attack":int(effect.attack),"health":int(effect.health)})
					_apply_hand_buff(side,listener,effect,1)
					if not _error.is_empty(): return
					continue
				if effect_type not in SHIELD_EVENT_TYPES or not _tribe_matches(shielded, str(effect.get("tribe", ""))):
					continue
				if bool(effect.get("exclude_self", false)) and int(listener["_combat_id"]) == int(shielded["_combat_id"]):
					continue
				var counter_key: String = str(effect_index)
				var used: int = int(listener["_shield_lost_used"].get(counter_key, 0))
				if effect.has("limit") and used >= int(effect["limit"]):
					continue
				if listener.get("card_id") in BulkResourceHost.FixedEvents.SHIELD_IDS:
					if not _bulk_resource_host._fixed_hand.shield(self,side,listener,effect,shielded,effect_index,used): return
				listener["_shield_lost_used"][counter_key] = used + 1
				var repetition: int = 0
				while repetition < int(effect.get("times", 1)):
					repetition += 1
					if not _tick("shield_loss_trigger"):
						return
					_emit("shield_loss_observed", {"side": side, "source": listener["uid"], "target": shielded["uid"], "effect": effect_type, "effect_index": effect_index, "activation": used + 1, "repetition": repetition})
					if effect_type == "on_shield_lost_keyword":
						var keyword: String = str(effect["keyword"])
						if not _has_keyword(listener, keyword):
							listener["keywords"].append(keyword)
							_emit("keyword_granted", {"source": listener["uid"], "target": listener["uid"], "keyword": keyword, "reason": "friendly_shield_lost", "trigger_unit": shielded["uid"]})
					elif effect_type == "on_shield_lost_add_card":
						if listener.get("card_id") in BulkResourceHost.FixedEvents.SHIELD_IDS:
							_bulk_resource_host.activate_fixed_spell(self,side,listener,effect)
						else: _queue_card_reward(side, listener, str(effect["card_id"]), int(effect.get("count", 1)))
					else:
						var recipient: Dictionary = listener if str(effect["scope"]) == "self" else shielded
						if int(recipient["health"]) <= 0:
							continue
						var attack_delta: int = int(effect.get("attack", 0))
						var health_delta: int = int(effect.get("health", 0))
						# Fail before mutation rather than wrapping a valid individual
						# int bonus when several shield events aggregate on one unit.
						if int(recipient["attack"]) > MAX_STAT - attack_delta or int(recipient["health"]) > MAX_STAT - health_delta or int(recipient["max_health"]) > MAX_STAT - health_delta:
							_fail("Shield-loss buff exceeds the signed integer stat range")
							return
						_apply_trigger_buff(listener, recipient, effect, "friendly_shield_lost", str(shielded["uid"]))
						if bool(effect.get("permanent", false)):
							_emit("persistent_buff", {"type": "persistent_buff", "side": side, "source": str(listener["uid"]), "target_uid": str(recipient["uid"]), "attack_delta": attack_delta, "health_delta": health_delta})
					if not _error.is_empty():
						return
		if _owned_observer_host!=null and not _owned_observer_host.shield_loss(self,loss): return
		if not _owned_mech_shield_host.observe(self,"shield_lost",side,shielded,_log[int(loss.sequence)]): return

func _resolve_deaths() -> void:
	# Keep delayed hand requests outside all nested death batches. This wraps
	# the existing real resolver; no artificial empty-slot event is emitted.
	_deferred_hand_host.death_depth+=1
	_resolve_deaths_inner()
	_deferred_hand_host.death_depth-=1
	if _error.is_empty(): _deferred_hand_host.pump(self,"resolved_deaths")
	if _error.is_empty() and _plain_copy_host!=null and _plain_copy_host._ozumat_host!=null: _plain_copy_host._ozumat_host.pump(self,"resolved_deaths")
	if _error.is_empty() and _plain_copy_host!=null and _plain_copy_host._turn_seven_copy_host!=null: _plain_copy_host._turn_seven_copy_host.pump(self,"resolved_deaths")
	if _error.is_empty() and _plain_copy_host!=null and _plain_copy_host._teron_host!=null: _plain_copy_host._teron_host.pump(self,"resolved_deaths")
	if _error.is_empty(): _automaton_portrait_host.pump(self,"resolved_deaths")
	if _error.is_empty(): _knitted_sunfin_host.pump(self,"resolved_deaths")
	if _error.is_empty(): _beetle_blessing_host.pump(self,"resolved_deaths")
	if _error.is_empty(): _piranha_host.pump(self,"resolved_deaths")

func _resolve_deaths_inner() -> void:
	while _error.is_empty():
		var queue: Array = []
		for side in [_priority_side, 1 - _priority_side]:
			var board: Array = _boards[side]
			var living_before: int = 0
			for index in range(board.size()):
				var unit: Dictionary = board[index]
				if int(unit["health"]) <= 0 or bool(unit.get("_pending_destroy",false)):
					var neighbors: Array = []
					for neighbor_index in [index - 1, index + 1]:
						if neighbor_index >= 0 and neighbor_index < board.size():
							neighbors.append(int(board[neighbor_index]["_combat_id"]))
					queue.append({"side": side, "unit": unit, "position": living_before, "order": index, "neighbors": neighbors, "dead_attack": int(unit["attack"]), "dead_max_health": int(unit["max_health"])})
				else:
					living_before += 1
		if queue.is_empty():
			return
		for deity_recruit_dr_entry in queue:
			if DeityRecruitDRSources.claimed(deity_recruit_dr_entry.unit) and not deity_recruit_dr_entry.unit.get("silenced",false) and not deity_recruit_dr_entry.unit.get("abilities_disabled",false):
				_fail("deity_deathrattle_combat_reserve_awakened_persistence_partial");return
		var beetle_capacity_wave_issue: String=_beetle_blessing_host.capture_wave(self,queue)
		if not beetle_capacity_wave_issue.is_empty(): _fail(beetle_capacity_wave_issue);return
		if not _deity_host.capture_wave(self,queue): return
		for dark_gift_entry in queue:
			if DarkGiftSources.marked(dark_gift_entry.unit) and _has_keyword(dark_gift_entry.unit,"reborn"):
				_fail("dark_gift_reborn_inheritance_partial");return
		for metal_death_entry in queue:
			var metal_death_issue: String=_metal_dispenser_host.source_error(metal_death_entry.unit)
			if not metal_death_issue.is_empty(): _fail(metal_death_issue);return
		if not _combat_magnetic_host.capture_deaths(self,queue): return
		if not _piggy_bank_host.capture_deaths(self,queue): return
		if not _dark_gift_resource_host.capture_deaths(self,queue): return
		if not _plain_copy_host._tamsin_host.capture_deaths(self,queue): return
		if not _plain_copy_host._brukan_host.capture_deaths(self,queue): return
		if not _owned_first_death_host.capture(self,queue): return
		if not _keep_gains_host._slither_host.capture(self,queue): return
		# Freeze selected native retention at actual death, while layer provenance
		# and the real source instance are still present. No insertion is invented.
		for entry in queue:
			if RebornRetention.active(entry.unit) and _has_keyword(entry.unit,"reborn"):
				if MegaGrants.marked(entry.unit): _fail("megasaur_adapt_living_spores_special_reborn_retention_partial");return
				var retained_reborn: Dictionary=RebornRetention.plan(self,entry.unit,int(entry.side))
				if not str(retained_reborn.error).is_empty(): _fail(str(retained_reborn.error));return
				entry.retained_reborn=retained_reborn.template
		for entry in queue:
			if not _battlecruiser_ultra_host.capture_death(self,entry): return
			if not _hag_reborn_host.capture_death(self,entry): return
			if not _maximum_imp_host.capture_death(self,entry): return
			if not _gem_golem_host.capture_death(self,entry): return
			entry.maximum_history_snapshot=_maximum_history_host.capture(self,entry)
		var boom_controller_capture_issue: String=_boom_controller_host.capture_wave(self,queue)
		if not boom_controller_capture_issue.is_empty(): _fail(boom_controller_capture_issue);return
		var soul_fermenter_capture_issue: String=_soul_fermenter_host.before_wave(self,queue)
		if not soul_fermenter_capture_issue.is_empty(): _fail(soul_fermenter_capture_issue);return
		var devourer_souls_before_issue: String=_devourer_souls_host.before_wave(self,queue)
		if not devourer_souls_before_issue.is_empty(): _fail(devourer_souls_before_issue);return
		if not _tick("death_wave"):
			return
		var sand_pirate_wave_issue: String=_sand_barnstormer_host.pirate_tokens.before_wave(self,queue)
		if not sand_pirate_wave_issue.is_empty(): _fail(sand_pirate_wave_issue);return
		_pending_deaths = queue
		if not _radio_star_host.before_removal(self,queue): return
		# Remove the entire simultaneous death set before any deathrattle summons.
		for entry in queue:
			var side: int = int(entry["side"])
			var index: int = _boards[side].find(entry["unit"])
			if index < _cursor[side]:
				_cursor[side] -= 1
			for outer_queue in _nested_death_queues:
				for outer_entry in outer_queue:
					if int(outer_entry.side)==side and index<int(outer_entry.position): outer_entry.position=maxi(0,int(outer_entry.position)-1)
			_boards[side].remove_at(index)
			var dead: Dictionary = entry["unit"]
			var original: Dictionary = dead["_base"].duplicate(true)
			original["health"] = maxi(int(original.get("health", 1)), int(original.get("max_health", original.get("health", 1))))
			original["max_health"] = int(original["health"])
			_death_history[side].append({"uid": dead["uid"], "tribes": dead.get("tribes", []).duplicate(), "base_unit": original})
			_emit("death_history", {"side": side, "source": dead["uid"], "index": _death_history[side].size() - 1, "base_card_id": original.get("card_id", "")})
			entry.milestone_death_sequence=_log.size()
			_emit("death", {"side": side, "unit": entry["unit"]["uid"], "name": entry["unit"].get("name", ""), "killer_id": entry["unit"]["_killer"]})
			if dead.get("card_id") in Rider.IDS:
				_rider_removal_context={"entry":entry,"queue":queue}
				var rider_removed_issue: String=_rider_host.removed(self,entry)
				_rider_removal_context={}
				if not rider_removed_issue.is_empty(): _fail(rider_removed_issue);return
			if Lobster.Sources.claimed(dead):
				if _lobster_host==null: _fail("lobster_missing_private_death_host");return
				_lobster_removal_context={"entry":entry,"queue":queue}
				var lobster_removed_issue: String=_lobster_host.removed(self,entry)
				_lobster_removal_context={}
				if not lobster_removed_issue.is_empty(): _fail(lobster_removed_issue);return
			var boom_controller_removed_issue: String=_boom_controller_host.removed(self,entry)
			if not boom_controller_removed_issue.is_empty(): _fail(boom_controller_removed_issue);return
			var soul_fermenter_removed_issue: String=_soul_fermenter_host.removed(self,entry)
			if not soul_fermenter_removed_issue.is_empty(): _fail(soul_fermenter_removed_issue);return
			var old_soul_removed_issue: String=_old_soul_host.removed(self,entry)
			if not old_soul_removed_issue.is_empty(): _fail(old_soul_removed_issue);return
			var recurring_nightmare_removed: String=_recurring_nightmare_host.removed(self,entry)
			if not recurring_nightmare_removed.is_empty(): _fail(recurring_nightmare_removed);return
			var radiant_ember_removed: String=_radiant_ember_host.removed(self,entry)
			if not radiant_ember_removed.is_empty(): _fail(radiant_ember_removed);return
			if not _keep_gains_host._slither_host.removed(self,entry): return
			_salvager_host.record_removed(self,entry)
			if not _error.is_empty(): return
			_maximum_history_host.record_removed(self,entry)
			if not _error.is_empty(): return
		var sand_pirate_wave_done: String=_sand_barnstormer_host.pirate_tokens.after_wave(self,queue)
		if not sand_pirate_wave_done.is_empty(): _fail(sand_pirate_wave_done);return
		if not BoardAuraRuntime.sync_combat(self,"death_batch_board_aura"): return
		if not _deity_host.removed_wave(self,queue): return
		var sthera_sticker_ticket: Dictionary=_kill_reward_host._sthera_sticker_host.capture(self,queue)
		if not _error.is_empty(): return
		var devourer_souls_removed_issue: String=_devourer_souls_host.authorize_removed(self,queue)
		if not devourer_souls_removed_issue.is_empty(): _fail(devourer_souls_removed_issue);return
		if not FishAcquisition.removed_death_batch(self,queue): return
		var devourer_souls_acquired_issue: String=_devourer_souls_host.finish_acquisition(self,queue)
		if not devourer_souls_acquired_issue.is_empty(): _fail(devourer_souls_acquired_issue);return
		if _kill_reward_host!=null and not _kill_reward_host.removed_deaths(self,queue): return
		if _global_counter_host != null and not _global_counter_host.removed_death_batch(self,queue): return
		if not _kill_reward_host._scrapsmith_portrait_host.removed(self,_kill_reward_host,queue): return
		if _milestone_hero_host!=null and not _milestone_hero_host.removed_death_batch(self,queue): return
		if _death_resource_host!=null and not _death_resource_host.removed_death_batch(self,queue): return
		if not _owned_first_death_host.removed(self,queue): return
		# All simultaneously dead listeners are gone before observing deaths.
		# Repeat counts are snapshotted at death time, not after later summons.
		for entry in queue:
			entry["repeats"] = _deathrattle_repeats(int(entry["side"]))
		if not _plain_copy_host._onyxia_host.removed(self,queue): return
		_trigger_friendly_deaths(queue)
		if not _error.is_empty():
			return
		if not _kill_reward_host._sthera_sticker_host.commit_wave(self,sthera_sticker_ticket): return
		var lantern_space_issue: String=_lantern_host.pump(self,"whole_death_wave_space")
		if not lantern_space_issue.is_empty(): _fail(lantern_space_issue);return
		# Simultaneous cross-side Deathrattles choose a fresh first side. This
		# window is separate from normal attack priority, corpse slots, listeners
		# and Reborn; same-side sources retain their left-to-right order.
		for entry in _deathrattle_order(queue):
			var deathrattles: Array = []
			for effect in entry["unit"]["effects"]:
				var effect_type: String = str(effect.get("type", ""))
				if effect_type.begins_with("deathrattle_") and effect_type != "deathrattle_repeat":
					deathrattles.append(effect)
			deathrattles.append_array(RecurringNightmare.Sources.effects(entry.unit))
			deathrattles.append_array(StartGrantSources.effects(entry.unit))
			deathrattles.append_array(FishGroups.effects(entry.unit))
			deathrattles.append_array(TempDeath.effects(entry.unit))
			deathrattles.append_array(MegaGrants.effects(entry.unit))
			deathrattles.append_array(TamsinGrant.effects(entry.unit))
			deathrattles.append_array(PiggyBank.Sources.effects(entry.unit))
			deathrattles.append_array(BrukanGrant.effects(entry.unit))
			deathrattles.append_array(DarkGiftResources.Sources.resource_effects(entry.unit))
			if deathrattles.is_empty():
				continue
			_run_native_deathrattles(entry,deathrattles)
			if not _error.is_empty(): return
		for entry in queue:
			if _has_keyword(entry["unit"], "reborn"):
				var reborn: Dictionary = entry["unit"]["_base"].duplicate(true)
				reborn["base_unit"] = entry["unit"]["_base"].duplicate(true)
				reborn["health"] = 1
				reborn["max_health"] = int(entry["unit"]["_base"].get("max_health", entry["unit"]["_base"].get("health", 1)))
				reborn["keywords"] = reborn.get("keywords", []).duplicate(true)
				reborn["keywords"].erase("reborn")
				if entry.has("retained_reborn"): reborn=entry.retained_reborn
				var sand_hand_reborn_begin_issue: String=_sand_barnstormer_host.demon_tokens.hands.begin(self,entry,reborn)
				if not sand_hand_reborn_begin_issue.is_empty(): _fail(sand_hand_reborn_begin_issue);return
				var sand_spirit_reborn_begin_issue: String=_sand_barnstormer_host.spirit.before_reborn(self,entry,reborn)
				if not sand_spirit_reborn_begin_issue.is_empty(): _fail(sand_spirit_reborn_begin_issue);return
				var sand_pirate_reborn_begin_issue: String=_sand_barnstormer_host.pirate_tokens.native_reborn.begin(self,_sand_barnstormer_host.pirate_tokens,entry,reborn)
				if not sand_pirate_reborn_begin_issue.is_empty(): _fail(sand_pirate_reborn_begin_issue);return
				var evil_begin_issue: String=_deity_host.evil_experiment.begin_reborn(_deity_host,self,entry,reborn)
				if not evil_begin_issue.is_empty(): _fail(evil_begin_issue);return
				_summon(entry, reborn, "reborn")
				if not _error.is_empty():
					_deity_host.evil_experiment.abort_reborn();return
				var evil_finish_issue: String=_deity_host.evil_experiment.finish_reborn(_deity_host,self,entry)
				if not evil_finish_issue.is_empty(): _fail(evil_finish_issue);return
				var sand_spirit_reborn_finish_issue: String=_sand_barnstormer_host.spirit.after_reborn(self,entry)
				if not sand_spirit_reborn_finish_issue.is_empty(): _fail(sand_spirit_reborn_finish_issue);return
				var sand_pirate_reborn_finish_issue: String=_sand_barnstormer_host.pirate_tokens.native_reborn.finish(self,_sand_barnstormer_host.pirate_tokens,entry)
				if not sand_pirate_reborn_finish_issue.is_empty(): _fail(sand_pirate_reborn_finish_issue);return
				var sand_hand_reborn_finish_issue: String=_sand_barnstormer_host.demon_tokens.hands.finish(self,entry)
				if not sand_hand_reborn_finish_issue.is_empty(): _fail(sand_hand_reborn_finish_issue);return
		# Hand-only listeners observe each genuine death after this batch
		# finishes all Deathrattles and Reborns; they never steal a Reborn slot.
		for entry in queue:
			if not _error.is_empty(): return
			_after_death_hand_summons(entry)
		if not _error.is_empty(): return
		var soul_fermenter_space_issue: String=_soul_fermenter_host.pump(self,"whole_death_wave_completed")
		if not soul_fermenter_space_issue.is_empty(): _fail(soul_fermenter_space_issue);return
		if not _error.is_empty(): return
		var boom_controller_space_issue: String=_boom_controller_host.pump(self,"whole_death_wave_completed")
		if not boom_controller_space_issue.is_empty(): _fail(boom_controller_space_issue);return

func _deathrattle_order(queue: Array) -> Array:
	var active_sides: Array = []
	for entry in queue:
		if (RecurringNightmare.Sources.has_active(entry.unit) or StartGrantSources.has_active(entry.unit) or PiggyBank.Sources.has_active(entry.unit) or FishGroups.has_active(entry.unit) or TempDeath.has_active(entry.unit) or MegaGrants.has_active(entry.unit) or TamsinGrant.has_active(entry.unit) or BrukanGrant.has_active(entry.unit) or not DarkGiftResources.Sources.resource_effects(entry.unit).is_empty() or entry.unit.effects.any(func(effect):return str(effect.get("type","")).begins_with("deathrattle_") and effect.type!="deathrattle_repeat")) and int(entry.side) not in active_sides:
			active_sides.append(int(entry.side))
	if active_sides.size()<2: return queue
	var first: int = _random_index(2,"deathrattle_first_side",[0,1])
	var ordered: Array = []
	for side in [first,1-first]:
		for entry in queue:
			if int(entry.side)==side: ordered.append(entry)
	return ordered

func _saurolisk_listeners(side: int) -> Array:
	return _boards[side].filter(func(unit):return (Saurolisk.accepts_id(unit.get("card_id")) or Saurolisk.Ghoul.accepts_id(unit.get("card_id"))) and int(unit.get("health",0))>0 and not unit.get("_pending_destroy",false) and not unit.get("silenced",false) and not unit.get("abilities_disabled",false))

func _run_native_deathrattles(entry: Dictionary, effects: Array, trigger: String = "deathrattle") -> void:
	if effects.any(func(e):return e.get("type")==DeityRecruitDRSources.TYPE): _fail("deity_living_deathrattle_combat_persistence_partial");return
	var deity_native_group_issue: String=_deity_host.death_admission(self,entry,trigger)
	if not deity_native_group_issue.is_empty(): _fail(deity_native_group_issue);return
	var metal_group_issue: String=_metal_dispenser_host.source_error(entry.unit)
	if not metal_group_issue.is_empty(): _fail(metal_group_issue);return
	var combat_magnetic_group_issue: String=_combat_magnetic_host.source_error(entry.unit)
	if not combat_magnetic_group_issue.is_empty(): _fail(combat_magnetic_group_issue);return
	var impulsive_group_issue: String=_impulsive_portrait_host.group_error(self,int(entry.get("side",-1)),entry.get("unit",{}))
	if not impulsive_group_issue.is_empty(): _fail(impulsive_group_issue);return
	var kaboom_group_issue: String=_kaboom_portrait_host.group_error(self,int(entry.get("side",-1)),entry.get("unit",{}))
	if not kaboom_group_issue.is_empty(): _fail(kaboom_group_issue);return
	if (entry.get("live_source",false) or trigger!="deathrattle") and GemLedgerTransfer.Sources.claimed(entry.unit): _fail("gem_ledger_transfer_living_source_semantics_partial");return
	if trigger not in ["deathrattle","rally_deathrattle","triggered_deathrattle"]:
		_fail("timewarped_saurolisk_invalid_native_dispatch"); return
	var deferred_first_transfer: bool=DarkGiftResources.Sacrifice.FirstTransfer.defer_binding(self,entry)
	if not deferred_first_transfer and not _dark_gift_resource_host.bind_invocation(self,entry,trigger): return
	if not _piggy_bank_host.bind_invocation(self,entry,trigger): return
	if not _plain_copy_host._tamsin_host.bind_invocation(self,entry,trigger): return
	if not _plain_copy_host._brukan_host.bind_invocation(self,entry,trigger): return
	var side: int = int(entry.side)
	var spread_grant_issue: String=_native_rally_spread_host.verify(self,entry.unit)
	if not spread_grant_issue.is_empty(): _fail(spread_grant_issue);return
	var recurring_nightmare_verify: String=_recurring_nightmare_host.verify(self,entry.unit)
	if not recurring_nightmare_verify.is_empty(): _fail(recurring_nightmare_verify);return
	var start_grant_issue: String=_native_start_grant_host.verify(self,entry.unit)
	if not start_grant_issue.is_empty(): _fail(start_grant_issue);return
	var plan: Dictionary = Saurolisk.deathrattle_groups(entry.unit,_options.get("hand_card_templates",{}))
	if Lobster.Sources.claimed(entry.unit):
		if _lobster_host==null: _fail("lobster_missing_private_death_host");return
		plan=_lobster_host.group_plan(self,entry,effects,trigger)
		if not str(plan.error).is_empty(): _fail(str(plan.error));return
	# Old rooms retain their exact instruction ordering and have no new listener
	# requirement. A later listener appearance cannot silently bless an unknown group.
	var verified: bool = str(plan.error).is_empty()
	var exhume_active: bool=bool(_options.get("left_exhume_quest_active" if side==0 else "right_exhume_quest_active",false))
	if exhume_active and not verified: _fail("exhume_bones_unknown_whole_group:"+str(plan.error));return
	if (RecurringNightmare.Sources.marked(entry.unit) or RecurringNightmare.Sources.claimed(entry.unit) or StartGrantSources.marked(entry.unit) or BattlecruiserCaduceusSources.marked(entry.unit) or ClunkerAttachments.marked(entry.unit) or CombatMagnetic.Sources.marked(entry.unit) or PiggyBank.Sources.marked(entry.unit) or FishGroups.marked(entry.unit) or TempDeath.marked(entry.unit) or MegaGrants.marked(entry.unit) or TamsinGrant.marked(entry.unit) or BrukanGrant.marked(entry.unit) or DarkGiftResources.Sources.death_group_gift(entry.unit)) and not verified: _fail(str(plan.error));return
	if not verified and not _saurolisk_listeners(side).is_empty(): _fail(str(plan.error)); return
	if not verified and _owned_combat_gem_host.has_death_source(side): _fail("owned_combat_gem_unverified_whole_group:"+str(plan.error));return
	if not verified and not DeathTrinkets.context_sources(_options,side).is_empty(): _fail("deathrattle_trinket_unverified_whole_group:"+str(plan.error));return
	if not verified and _options.has("left_global_card_state" if side==0 else "right_global_card_state"):
		_fail("global_counter_unverified_whole_deathrattle_group:"+str(plan.error));return
	var groups: Array = plan.groups if verified else [effects.duplicate(true)]
	var first_deathrattle_plan: Dictionary=_kill_reward_host._first_deathrattle_host.plan(self,entry,groups,trigger,verified)
	if not str(first_deathrattle_plan.error).is_empty(): _fail(str(first_deathrattle_plan.error));return
	var first_deathrattle_ticket: Dictionary=first_deathrattle_plan.ticket
	if not first_deathrattle_ticket.is_empty(): entry.repeats=2
	if deferred_first_transfer and not DarkGiftResources.Sacrifice.FirstTransfer.bind(self,entry,first_deathrattle_ticket): return
	var queensguard_group_issue: String=_combat_ring_cast_host.queen_prepare_death(self,entry,groups,trigger)
	if not queensguard_group_issue.is_empty(): _fail(queensguard_group_issue);return
	var octosari_group_issue: String=_octosari_host.prepare_group(self,entry,groups,trigger)
	if not octosari_group_issue.is_empty(): _fail(octosari_group_issue);return
	var radiant_ember_invocation_issue: String=_radiant_ember_host.bind(self,entry,groups,trigger)
	if not radiant_ember_invocation_issue.is_empty(): _fail(radiant_ember_invocation_issue);return
	var sand_barnstormer_invocation_issue: String=_sand_barnstormer_host.bind(self,entry,groups,trigger)
	if not sand_barnstormer_invocation_issue.is_empty(): _fail(sand_barnstormer_invocation_issue);return
	var felblood_invocation_issue: String=_felblood_portrait_host.bind(self,entry,groups,trigger)
	if not felblood_invocation_issue.is_empty(): _fail(felblood_invocation_issue);return
	if not _assembler_magnetic_host.prepare(self,entry,groups,trigger,first_deathrattle_ticket): return
	var recurring_nightmare_bind: String=_recurring_nightmare_host.bind(self,entry,groups,trigger)
	if not recurring_nightmare_bind.is_empty(): _fail(recurring_nightmare_bind);return
	if not _native_start_grant_host.bind_invocation(self,entry,trigger): return
	for repetition in range(int(entry.get("repeats",1))):
		for group_index in range(groups.size()):
			if not _assembler_magnetic_host.before_group(self,entry,repetition,group_index): return
			var impulsive_native_group_issue: String=_impulsive_portrait_host.preflight_group(self,entry,groups[group_index])
			if not impulsive_native_group_issue.is_empty(): _fail(impulsive_native_group_issue);return
			if not _attachment_fixed_hand.prepare(self,entry,groups[group_index],group_index,repetition,trigger,first_deathrattle_ticket): return
			if not _attachment_fixed_hand.attached_group(self,entry,group_index):
				if not _bulk_resource_host._fixed_hand.death_group(self,entry,groups[group_index],trigger,repetition): return
				if not _bulk_resource_host._native_fixed_hand.native_death_group(self,entry,groups[group_index],trigger,repetition): return
				if not _bulk_resource_host._fixed_spell_dr_hand.native_death_group(self,entry,groups[group_index],trigger,repetition): return
				if not _bulk_resource_host._random_spell_dr_hand.native_death_group(self,entry,groups[group_index],trigger,repetition): return
				if not _bulk_resource_host._random_minion_dr_hand.native_death_group(self,entry,groups[group_index],trigger,repetition): return
			if not _kill_reward_host._first_deathrattle_host.begin_group(self,entry,group_index,repetition,first_deathrattle_ticket): return
			var before: Array = _saurolisk_listeners(side).map(func(unit):return int(unit._combat_id))
			var global_group_start: int=_log.size()
			for effect in groups[group_index]:
				if not _tick(trigger): return
				if not _dark_gift_resource_host._sacrifice.before_leaf(self,entry,effect,repetition+1,group_index): return
				var sand_pirate_leaf_issue: String=_sand_barnstormer_host.pirate_tokens.before_leaf(self,entry,effect,repetition+1,group_index,trigger)
				if not sand_pirate_leaf_issue.is_empty(): _fail(sand_pirate_leaf_issue);return
				var sand_demon_leaf_issue: String=_sand_barnstormer_host.demon_tokens.before_leaf(self,entry,effect,repetition+1,group_index,trigger)
				if not sand_demon_leaf_issue.is_empty(): _fail(sand_demon_leaf_issue);return
				if effect.get("type")==Lobster.Sources.TYPE:
					if not _lobster_dispatch_context.is_empty(): _fail("lobster_reentrant_native_dispatch");return
					_lobster_dispatch_context={"entry":entry,"effect":effect,"group":group_index,"repetition":repetition+1,"trigger":trigger}
				if effect.get("type")==Rider.Sources.TYPE:
					if not _rider_dispatch_context.is_empty(): _fail("rider_reentrant_dispatch");return
					_rider_dispatch_context={"entry":entry,"effect":effect,"group":group_index,"repetition":repetition+1,"trigger":trigger}
				_deathrattle(entry,effect,repetition+1,trigger)
				_rider_dispatch_context={}
				_lobster_dispatch_context={}
				if not _error.is_empty(): return
				var sand_pirate_leaf_done: String=_sand_barnstormer_host.pirate_tokens.after_leaf(self,entry)
				if not sand_pirate_leaf_done.is_empty(): _fail(sand_pirate_leaf_done);return
				var sand_demon_leaf_done_issue: String=_sand_barnstormer_host.demon_tokens.after_leaf(self,entry)
				if not sand_demon_leaf_done_issue.is_empty(): _fail(sand_demon_leaf_done_issue);return
				if not _dark_gift_resource_host._sacrifice.after_leaf(self,entry): return
			if not _attachment_fixed_hand.completed(self,entry): return
			if not _assembler_magnetic_host.after_leaf(self,entry): return
			if not verified and not _saurolisk_listeners(side).is_empty(): _fail(str(plan.error)); return
			if exhume_active:
				_emit("quest_actual_deathrattle_group",{"side":side,"source":entry.unit.uid,"source_id":entry.unit.card_id,"combat_id":entry.unit._combat_id,"group":group_index,"repetition":repetition+1,"trigger":trigger,"start_sequence":global_group_start})
			if _global_counter_host != null and not _global_counter_host.completed_deathrattle(self,entry,trigger,repetition+1,group_index,global_group_start): return
			if _kill_reward_host != null and not _kill_reward_host.grant_deathrattle_group(self,entry,trigger,repetition+1,group_index,global_group_start): return
			_after_native_deathrattle(entry,before,group_index,repetition+1,trigger)
			if not _error.is_empty(): return
			if not _owned_combat_gem_host.after_group(self,entry,trigger,repetition+1,group_index,global_group_start): return
			if not _kill_reward_host._first_deathrattle_host.completed_group(self,entry,repetition,first_deathrattle_ticket): return
			if not _dark_gift_resource_host._sacrifice.after_group(self,entry,repetition+1,group_index): return
			if not _assembler_magnetic_host.after_group(self,entry): return
			var sand_pirate_group_done: String=_sand_barnstormer_host.pirate_tokens.after_group(self,entry,repetition+1,group_index,trigger,global_group_start)
			if not sand_pirate_group_done.is_empty(): _fail(sand_pirate_group_done);return
			var sand_demon_group_done_issue: String=_sand_barnstormer_host.demon_tokens.after_group(self,entry,repetition+1,group_index,trigger,global_group_start)
			if not sand_demon_group_done_issue.is_empty(): _fail(sand_demon_group_done_issue);return
	if not _kill_reward_host._first_deathrattle_host.finish_invocation(self,entry,first_deathrattle_ticket): return
	if not _dark_gift_resource_host._sacrifice.finish(self,entry): return
	if not _assembler_magnetic_host.completed(self,entry): return

func _after_native_deathrattle(entry: Dictionary, before: Array, group_index: int, repetition: int, trigger: String) -> void:
	var side: int = int(entry.side)
	var listeners: Array = _saurolisk_listeners(side)
	var plans: Array = []
	var pending: Dictionary = {}
	for listener in listeners:
		var all_friendly: bool = Saurolisk.Ghoul.accepts_id(listener.get("card_id"))
		if int(listener._combat_id) not in before:
			_fail("ghoul_acabra_dynamic_listener_registration_unverified" if all_friendly else "timewarped_saurolisk_dynamic_listener_registration_unverified"); return
		var issue: String = Saurolisk.unit_error(listener,_options.get("hand_card_templates",{}))
		if not issue.is_empty(): _fail(issue); return
		var effect: Dictionary = Saurolisk.effect_for(str(listener.card_id))
		# Current board after the completed group. Pending-death bodies cannot be
		# rescued by a later positive Health delta; silenced recipients still qualify.
		var targets: Array = _boards[side].filter(func(unit):return unit.get("kind","minion")=="minion" and int(unit.get("health",0))>0 and not unit.get("_pending_destroy",false)) if all_friendly else [listener]
		for target in targets:
			# Hand-origin writeback remains outside the proven host. The room and
			# combat closure gate already rejects this combination; fail closed here too.
			if all_friendly and target.has("_hand_source_reference"):
				_fail("ghoul_acabra_hand_origin_permanent_reconciliation_unverified"); return
			var target_id: int = int(target._combat_id)
			if not pending.has(target_id): pending[target_id] = {"attack":0,"health":0,"max_health":0}
			for stat in ["attack","health","max_health"]:
				var delta: int = int(effect.attack if stat == "attack" else effect.health)
				if int(target[stat]) > 9007199254740991-delta-int(pending[target_id][stat]):
					_fail("ghoul_acabra_buff_exceeds_safe_integer_range" if all_friendly else "timewarped_saurolisk_buff_exceeds_safe_integer_range"); return
				pending[target_id][stat] += delta
		plans.append({"listener":listener,"effect":effect,"targets":targets})
	for plan in plans:
		var listener: Dictionary = plan.listener
		var effect: Dictionary = plan.effect
		if not _tick("friendly_deathrattle_listener"): return
		_emit("friendly_deathrattle_observed",{"side":side,"source":listener.uid,"source_id":listener.card_id,"trigger_unit":entry.unit.uid,"effect":Saurolisk.TYPE,"group_index":group_index,"repetition":repetition,"trigger":trigger})
		for target in plan.targets:
			_apply_trigger_buff(listener,target,effect,"friendly_deathrattle",str(entry.unit.uid))
			if not _error.is_empty(): return
			_emit("persistent_buff",{"type":"persistent_buff","side":side,"source":listener.uid,"target_uid":target.uid,"attack_delta":effect.attack,"health_delta":effect.health})

func _deathrattle(entry: Dictionary, effect: Dictionary, repetition: int = 1, trigger: String = "deathrattle") -> void:
	if not _error.is_empty():
		return
	var side: int = int(entry["side"])
	var source: Dictionary = entry["unit"]
	if effect.has(MegaGrants.EFFECT_KEY):
		var megasaur_call_issue: String=MegaGrants.call_error(source,effect)
		if not megasaur_call_issue.is_empty(): _fail(megasaur_call_issue);return
		# Keep the ordinary deathrattle_summon branch below: actual insertion,
		# native repeaters, capacity attempts, summon buffs and observers.
		_emit("megasaur_living_spores_group",{"side":side,"source":source.uid,"grant":effect[MegaGrants.EFFECT_KEY].duplicate(true),"repetition":repetition,"trigger":trigger,"policy":MegaGrants.POLICY})
	if effect.get("type")==Apexis.Sources.DR:
		var apexis_death_issue: String=_apexis_magnetic_host.deathrattle(self,entry,effect,repetition,trigger)
		if not apexis_death_issue.is_empty(): _fail(apexis_death_issue)
		return
	if effect.get("type")==FishBait.Sources.DEATH:
		_fish_bait_host.execute(self,entry,effect,repetition,trigger)
		return
	if effect.get("type")==RadioStar.Sources.TYPE:
		_radio_star_host.execute(self,entry,effect,repetition,trigger)
		return
	if effect.get("type")==MetalDispenser.Sources.TYPE:
		_metal_dispenser_host.execute(self,entry,effect,repetition,trigger)
		return
	if effect.get("type") in [DarkGiftResources.Sources.REFRESH_GRANT,DarkGiftResources.Sources.SPELL_GRANT,DarkGiftResources.Sources.TRANSFER_GRANT]:
		_dark_gift_resource_host.deathrattle(self,entry,effect,repetition,trigger)
		return
	if PiggyBank.Sources.grant_effect_type(effect.get("type")):
		_piggy_bank_host.combat_effect(self,entry,effect,repetition,trigger)
		return
	if effect.get("type")==RecurringNightmare.Sources.GRANT:
		var recurring_nightmare_summon: String=_recurring_nightmare_host.summon(self,entry,effect,repetition,trigger)
		if not recurring_nightmare_summon.is_empty(): _fail(recurring_nightmare_summon)
		return
	if effect.get("type")==StartGrantSources.TYPE:
		_native_start_grant_host.execute(self,entry,effect,repetition,trigger)
		return
	if effect.get("type")==BrukanGrant.GRANT:
		_plain_copy_host._brukan_host.combat_effect(self,entry,effect,repetition,trigger)
		return
	if effect.get("type")==TamsinGrant.GRANT:
		_plain_copy_host._tamsin_host.combat_effect(self,entry,effect,repetition,trigger)
		return
	if effect.get("type")==TempDeath.TYPE:
		TempDeath.combat_effect(self,entry,effect,repetition,trigger)
		return
	var crystal_call_issue: String = NativeRecruit.Crystal.combat_effect_error(source,effect,_options.get("hand_card_templates",{}))
	if not crystal_call_issue.is_empty():
		_fail(crystal_call_issue)
		return
	var earth_call_issue: String = EarthMother.call_error(source,effect,_options.get("hand_card_templates",{}))
	if not earth_call_issue.is_empty():
		_fail(earth_call_issue)
		return
	var bone_call_issue: String = BoneBaron.call_error(source,effect,_options.get("hand_card_templates",{}))
	if not bone_call_issue.is_empty():
		_fail(bone_call_issue)
		return
	var spiked_call_issue: String = SpikedSavior.call_error(source,effect,_options.get("hand_card_templates",{}))
	if not spiked_call_issue.is_empty():
		_fail(spiked_call_issue)
		return
	var enforcer_call_issue: String = Enforcer.call_error(source,effect,_options.get("hand_card_templates",{}))
	if not enforcer_call_issue.is_empty():
		_fail(enforcer_call_issue)
		return
	var ticking_call_issue: String = "" if SpikedSavior.claimed(source) else Ticking.call_error(source,effect,_options.get("hand_card_templates",{}))
	if not ticking_call_issue.is_empty():
		_fail(ticking_call_issue)
		return
	var bristleback_call_issue: String = Bristleback.call_error(source,effect,_options.get("hand_card_templates",{}))
	if not bristleback_call_issue.is_empty():
		_fail(bristleback_call_issue)
		return
	var overflow_call_issue: String = SummonOverflow.Sources.call_error(source,effect,_options.get("hand_card_templates",{}))
	if not overflow_call_issue.is_empty(): _fail(overflow_call_issue); return
	if effect.get("type")==Rider.Sources.TYPE:
		var rider_projection: Dictionary=_rider_host.project(self,entry,effect,repetition,trigger)
		if not rider_projection.ok: _fail(str(rider_projection.error));return
		effect=rider_projection.effect
	var effect_type: String = str(effect["type"])
	if effect_type in [Protoss.Sources.CARRIER,Protoss.Sources.RESOURCE]:
		_protoss_host.avenge(self,entry,effect,repetition,trigger)
		return
	if effect_type==NativeGem.Sources.AVENGE:
		_native_gem_host.avenge(self,entry,effect,repetition,trigger)
		return
	if effect_type==CombatPlainSources.AVENGE:
		if trigger!="avenge_effect" or repetition!=1 or entry.get("repeats",1)!=1 or _plain_copy_host==null: _fail("combat_plain_copy_requires_actual_avenge_host");return
		_plain_copy_host.activate(self,side,source,effect,trigger)
		return
	if effect_type == SummonOverflow.Sources.TYPE:
		SummonOverflow.activate(self,entry,effect,repetition,trigger)
		return
	if effect_type == CorpseSale.Sources.TYPE and (trigger != "avenge_effect" or repetition != 1 or entry.get("repeats",1) != 1):
		_fail("corpse_sale_requires_single_real_avenge_activation")
		return
	if effect_type == BeetleSources.AVENGE_TYPE:
		_beetle_avenge(entry,effect,repetition,trigger)
		return
	if effect_type == "deathrattle_beetle_native":
		_beetle_deathrattle(entry,effect,repetition,trigger)
		return
	if effect_type == "deathrattle_permanent_tribe_bonus" and NativeRecruit.Dustbone.claimed(source):
		_fail("dustbone_rally_requires_actual_rally_event"); return
	if effect_type == "deathrattle_permanent_tribe_bonus" and (NativeRecruit.Primus.claimed(source) or trigger == "avenge_effect"):
		var primus_issue: String = NativeRecruit.Primus.combat_call_error(source,effect,side,_boards,_options.get("hand_card_templates",{}),trigger,repetition,entry.get("repeats",1))
		if not primus_issue.is_empty(): _fail(primus_issue); return
	if SpikedSavior.claimed(source) and effect_type == "deathrattle_buff":
		# Validate every recipient before the first trigger event or stat write.
		# The old queue, recipient selection and damage batching stay unchanged.
		for friendly in _boards[side]:
			if int(friendly.get("health",0)) <= 0: continue
			if not StartCombatEffects.buff_fits(friendly,0,1):
				_fail("spiked_savior_health_buff_overflow"); return
			if _options.has(DamageListenerHost.CONTEXT):
				var received_issue: String = DamageListenerHost.adjust_error(friendly,0,1)
				if not received_issue.is_empty(): _fail(received_issue); return
			if BoardAuraRuntime.managed(friendly):
				var aura_issue: String = BoardAuraRuntime.adjust(friendly.duplicate(true),0,1)
				if not aura_issue.is_empty(): _fail(aura_issue); return
	_emit(trigger, {"side": side, "source": source["uid"], "effect": effect_type, "repetition": repetition, "total_repetitions": entry.get("repeats", 1)})
	match effect_type:
		Lobster.Sources.TYPE:
			if _lobster_host==null: _fail("lobster_missing_private_death_host");return
			if not _lobster_host.deathrattle(self,entry,effect,repetition,trigger): return
		MutatedLasher.Sources.TYPE:
			var mutated_lasher_issue: String = MutatedLasher.execute(self, entry, effect, repetition, trigger)
			if not mutated_lasher_issue.is_empty(): _fail(mutated_lasher_issue)
		DeterminedDefender.Sources.TYPE:
			var determined_defender_issue: String = DeterminedDefender.execute(self, entry, effect, repetition, trigger)
			if not determined_defender_issue.is_empty(): _fail(determined_defender_issue)
		RecurringNightmare.Sources.TYPE:
			var recurring_nightmare_grant: String=_recurring_nightmare_host.grant(self,entry,effect,repetition,trigger)
			if not recurring_nightmare_grant.is_empty(): _fail(recurring_nightmare_grant);return
		RadiantEmber.Sources.TYPE:
			var radiant_ember_leaf_issue: String=_radiant_ember_host.leaf(self,entry,effect,repetition,trigger)
			if not radiant_ember_leaf_issue.is_empty(): _fail(radiant_ember_leaf_issue);return
		KerriganZerg.Sources.DEATH,KerriganZerg.Sources.AVENGE:
			_kerrigan_zerg_host.deathrattle(_kill_reward_host,self,entry,effect,repetition,trigger)
		Tony.Sources.TYPE:
			_tony_host.payload(self,entry,effect,repetition,trigger)
		AvengePoison.Sources.TYPE:
			AvengePoison.payload(_kill_reward_host,self,entry,effect,repetition,trigger)
		GemGolem.Sources.DEATH:
			_gem_golem_host.payload(self,entry,effect,repetition,trigger)
		NextTurnShopSources.TYPE:
			_kill_reward_host._next_turn_shop_host.activate(self,entry,effect,trigger,repetition)
		LinkedUndead.Sources.TYPE:
			_linked_undead_host.avenge(self,entry,effect,trigger,repetition)
		LinkedUndead.Sources.DEATH:
			_linked_undead_host.deathrattle(self,entry,effect)
		PastryAvenge.TYPE:
			_bulk_resource_host.activate_fixed_avenge(self,entry,effect,trigger,repetition)
		RylakBattlecry.Sources.TYPE:
			_rylak_battlecry_host.activate(self,entry,effect,trigger,repetition)
		AdjacentTide.Sources.TYPE:
			_adjacent_tide_host.activate(self,entry,effect,trigger,repetition)
		CombatGolden.Sources.DEATH:
			_combat_golden_host.activate(self,side,source,effect,trigger,repetition)
		MaximumImp.Sources.TYPE:
			_maximum_imp_host.payload(self,entry,effect,repetition,trigger)
		GemLedgerTransfer.Sources.TYPE:
			GemLedgerTransfer.payload(_kill_reward_host,self,entry,effect,repetition,trigger)
		GemSummon.Sources.DEATH:
			GemSummon.payload(_kill_reward_host,self,entry,effect,repetition,trigger)
		CombatGemTriggers.Sources.DEATH,CombatGemTriggers.Sources.AVENGE:
			CombatGemTriggers.payload(_kill_reward_host,self,entry,effect,repetition,trigger)
		LastSpell.Sources.TYPE:
			LastSpell.combat(self,entry,effect,trigger)
		IntrinsicTwice.Sources.TYPE:
			IntrinsicTwice.activate(self,entry,effect,trigger)
		HandBoard.Sources.TYPE:
			HandBoard.activate(_kill_reward_host,self,entry,effect,trigger)
		SummonGet.Sources.DEATH:
			SummonGet.activate(_bulk_resource_host,self,entry,effect,trigger)
		SalvagerSources.TYPE:
			_salvager_host.deathrattle(self,entry,effect)
		CombatRingCast.QueenSources.DEATH:
			_combat_ring_cast_host.queen_death(self,entry,effect,repetition,trigger)
		Octosari.Sources.TYPE:
			_octosari_host.payload(self,entry,effect,repetition,trigger)
		SilithidSources.TYPE:
			_silithid_host.buff(self,entry,effect,trigger)
		SilithidSources.GROW:
			_silithid_host.grow(self,entry,effect,trigger)
		DeityCombat.Sources.DEATH:
			_deity_host.deathrattle(self,entry,effect,trigger)
		MaximumHistorySources.TYPE:
			_maximum_history_host.activate(self,entry,effect)
		TechnicianKiller.TYPE:
			TechnicianAttacks.activate(self,entry,effect,trigger)
		EachTypePermanent.TYPE:
			_kill_reward_host.EachTypePermanent.activate(_kill_reward_host,self,entry,effect,trigger)
		NativeDRTriggers.DEATH:
			NativeDRTriggers.adjacent_combat(self,entry,effect,trigger)
		BulkHandSummon.TYPE:
			BulkHandSummon.activate(self,entry,effect,repetition,trigger)
		Knights.TYPE, Knights.AVENGE_TYPE:
			Knights.activate(self,entry,effect,repetition,trigger)
		CombatTransforms.TYPE:
			if _incubation_combat_active(): _fail("incubation_mutation_combat_identity_transform_partial"); return
			if trigger!="avenge_effect" or repetition!=1 or entry.get("repeats",1)!=1: _fail("combat_transform_requires_actual_avenge");return
			CombatTransforms.activate(self,side,source,effect)
		FodderRefresh.Sources.DEATHRATTLE:
			_fodder_refresh_host.deathrattle(self,entry,effect,repetition,trigger)
		RefreshOwnerBuffs.DEATHRATTLE:
			_refresh_owner_buff_host.deathrattle(self,entry,effect,repetition,trigger)
		CorpseSale.Sources.TYPE:
			var sale_event: Dictionary = CorpseSale.build_event(_options.get("delayed_gold_context",{}),side,source,effect,_log.size(),trigger,_options.get("hand_card_templates",{}))
			if not sale_event.ok:
				_fail(str(sale_event.error))
				return
			_emit(CorpseSale.EVENT,sale_event.event)
		Cruise.TYPE:
			_cruise_controller.register_deathrattle(self,entry,effect,repetition,trigger)
		"deathrattle_next_tavern_spell_discount", "deathrattle_increase_max_gold", "deathrattle_blood_gem_bonus", "avenge_free_rolls", "deathrattle_tavern_spell_bonus":
			if not _options.get("delayed_gold_context") is Dictionary:
				_fail("Combat economy requires actual owner and transaction context")
				return
			var economy_event: Dictionary = CombatEconomy.build_event(_options.delayed_gold_context,side,source,effect,_log.size(),trigger,_options.get("hand_card_templates",{}))
			if not economy_event.ok:
				_fail(str(economy_event.error))
				return
			_emit(CombatEconomy.EVENT,economy_event.event)
		"deathrattle_queue_gold":
			var context: Dictionary = _options.get("delayed_gold_context",{"round":1,"transaction_id":"isolated-combat:"+str(_seed),"owners":[0,1]})
			var queued: Dictionary = DelayedGold.build_event(context.owners[side],str(source.get("card_id",source.get("id",""))),source.uid,effect,context.round,context.transaction_id,_log.size(),"combat",side)
			if not queued.ok:
				_fail(str(queued.error))
				return
			_emit(DelayedGold.EVENT,queued.event)
		"deathrattle_permanent_tribe_bonus", PhaseArmy.TYPE:
			_permanent_tribe_effects.activate(self, side, source, effect)
		"deathrattle_whelp_owner_layer":
			_global_counter_host.whelp_deathrattle(self,entry,effect,repetition,trigger)
		"deathrattle_beast_owner_layer":
			_global_counter_host.beast_deathrattle(self,entry,effect,repetition,trigger)
		"deathrattle_tribe_bonus":
			_combat_tribe_bonuses.activate(self, side, source, effect)
		"deathrattle_shop_bonus":
			if _sand_barnstormer_host.active(side) and SandBarnstormer.accepts(source):
				var sand_barnstormer_leaf_issue: String=_sand_barnstormer_host.leaf(self,entry,effect,repetition,trigger)
				if not sand_barnstormer_leaf_issue.is_empty(): _fail(sand_barnstormer_leaf_issue)
			elif _felblood_portrait_host.active(side) and source.get("card_id") in FelbloodPortraitCombat.Sources.DEATH_IDS:
				var felblood_leaf_issue: String=_felblood_portrait_host.leaf(self,entry,effect,repetition,trigger)
				if not felblood_leaf_issue.is_empty(): _fail(felblood_leaf_issue)
			else: _emit("permanent_shop_bonus", {"side": side, "source": source["uid"], "tribe": effect["tribe"], "attack_delta": effect["attack"], "health_delta": effect["health"]})
		"deathrattle_random_temporary_summon":
			_random_temporary_summons(entry,effect)

		"avenge_shield_force_attack":
			for activation in range(int(effect.count)):
				if not _rally_live_target(source) or source.get("_pending_destroy",false) or source.get("silenced",false) or source.get("abilities_disabled",false): return
				if not _tick("avenge_shield_grant"): return
				if not _has_keyword(source,"divine_shield"):
					source.keywords.append("divine_shield")
					_emit("keyword_granted",{"source":source.uid,"target":source.uid,"keyword":"divine_shield","reason":"avenge"})
				_force_single_attack(side,source,"avenge_immediate_attack")
				if not _error.is_empty(): return

		"combat_transfer_stat":
			_combat_transfer_stat(source,effect)

		"deathrattle_summon":
			var khadgar_plan: Dictionary=Khadgar.combat_plan(self,entry,effect,repetition,trigger)
			if not khadgar_plan.ok: _fail(str(khadgar_plan.error));return
			if effect.get("summon_for_opponent",false):
				var opposing_entry: Dictionary={"side":1-side,"unit":source,"position":_boards[1-side].size(),"order":2147483647}
				for summon_index in range(int(effect.get("count",1))):
					if not _tick("opponent_deathrattle_summon"): return
					if not _summon(opposing_entry,effect.unit,"opponent_deathrattle") and not _error.is_empty(): return
				return
			var summon_count: int = maxi(0, int(source["attack"])) if str(effect.get("count_from", "")) == "source_attack" else int(effect.get("count", 1))
			if khadgar_plan.active: summon_count=int(khadgar_plan.count)
			var summon_index: int=0
			while summon_index<summon_count:
				summon_index+=1
				var khadgar_attempt_issue: String=Khadgar.before_attempt(self,entry,khadgar_plan)
				if not khadgar_attempt_issue.is_empty(): _fail(khadgar_attempt_issue);return
				if _boards[side].size() >= BOARD_LIMIT:
					var continue_attempts: bool=_summon_attempt_observers(side)
					if not _summon_capacity_miss({"side": side, "source": source["uid"], "reason": "board_full"}): return
					if continue_attempts: continue
					break
				_summon(entry, effect["unit"], "deathrattle",bool(effect.get("attack_immediately",false)),0,{},null,khadgar_plan)
				if not _error.is_empty(): return
		"deathrattle_summon_history":
			var selected: Array = []
			for historical in _death_history[side]:
				if _tribe_matches(historical, str(effect.get("tribe", ""))):
					selected.append(historical)
					if selected.size() >= int(effect["count"]):
						break
			var ids: Array = []
			for historical in selected:
				ids.append(historical["uid"])
			_emit("history_selected", {"side": side, "source": source["uid"], "selected": ids, "repetition": repetition})
			for historical in selected:
				if _boards[side].size() >= BOARD_LIMIT:
					var continue_attempts: bool=_summon_attempt_observers(side)
					if not _summon_capacity_miss({"side": side, "source": source["uid"], "reason": "board_full", "kind": "deathrattle_history"}): return
					if continue_attempts: continue
					break
				_summon(entry, historical["base_unit"], "deathrattle_history")
				if not _error.is_empty(): return
		"deathrattle_damage_for_history":
			var shots: int=0
			for historical in _death_history[side]:
				if _tribe_matches(historical,str(effect.tribe)): shots+=1
			_emit("history_damage_count",{"source":source.uid,"count":shots,"tribe":effect.tribe})
			for shot in range(shots):
				if not _tick("history_damage_shot"): return
				var candidates: Array=[]
				var ids: Array=[]
				for enemy in _boards[1-side]:
					if int(enemy.health)>0 and not enemy.get("_pending_destroy",false): candidates.append(enemy);ids.append(enemy.uid)
				if candidates.is_empty(): break
				var recipient: Dictionary=candidates[_random_index(candidates.size(),"history_damage_enemy",ids)]
				_damage_batch([{"source":source,"target":recipient,"amount":int(effect.amount),"kind":"history_deathrattle_damage"}])
				if not _error.is_empty(): return

		"deathrattle_damage":
			var kaboom_damage_plan: Dictionary=_kaboom_portrait_host.damage_plan(self,entry,effect,repetition,trigger)
			if not str(kaboom_damage_plan.error).is_empty(): _fail(str(kaboom_damage_plan.error));return
			var packets: Array = []
			if str(effect["target"]) in ["all_enemies", "all", "all_other", "all_friendly", "all_except_friendly_demons"]:
				var sides: Array = [side] if effect["target"] == "all_friendly" else ([1 - side] if str(effect["target"]) == "all_enemies" else [side, 1 - side])
				for affected_side in sides:
					for target_unit in _boards[affected_side]:
						if int(target_unit["health"]) > 0:
							if effect["target"] == "all_except_friendly_demons" and affected_side == side and _tribe_matches(target_unit,"恶魔"): continue
							if effect["target"] == "all_other" and int(target_unit["_combat_id"]) == int(source["_combat_id"]): continue
							packets.append({"source": source, "target": target_unit, "amount": int(kaboom_damage_plan.amount), "kind": trigger})
			else:
				var highest: bool = str(effect["target"]) == "highest_health_enemy"
				var lowest_health_target: bool = str(effect["target"]) == "lowest_health_enemy"
				var purpose: String = ("start_combat_" if trigger == "start_combat_damage_effect" else "deathrattle_") + ("lowest_health_enemy" if lowest_health_target else ("highest_health_enemy" if highest else "random_enemy"))
				var target_unit: Dictionary = _target(1 - side, purpose, false, false, highest, lowest_health_target)
				if not target_unit.is_empty():
					packets.append({"source": source, "target": target_unit, "amount": int(kaboom_damage_plan.amount), "kind": trigger})
			if not packets.is_empty():
				_damage_batch(packets)
		"deathrattle_source_max_stats":
			var transferred_attack: int = int(entry.get("dead_attack",source.get("attack",0)))
			var transferred_health: int = int(entry.get("dead_max_health",source.get("max_health",source.get("health",0))))
			if transferred_attack<0 or transferred_health<1: _fail("Invalid source maximum stat snapshot"); return
			var transfer_candidates: Array = []
			var transfer_ids: Array = []
			for candidate in _boards[side]:
				if int(candidate.health)>0 and int(candidate._combat_id)!=int(source._combat_id):
					transfer_candidates.append(candidate); transfer_ids.append(candidate.uid)
			if not transfer_candidates.is_empty():
				var recipient: Dictionary = transfer_candidates[_random_index(transfer_candidates.size(),"deathrattle_source_max_stats",transfer_ids)]
				_apply_trigger_buff(source,recipient,{"attack":transferred_attack,"health":transferred_health},"deathrattle_source_max_stats",str(source.uid))
		"deathrattle_attack_transfer":
			_apply_attack_transfer(entry, effect, repetition, trigger)
		"deathrattle_buff":
			if _impulsive_portrait_host.has_source(side) and source.get("card_id") in ImpulsivePortrait.Sources.CHILD_IDS:
				_impulsive_portrait_host.apply(self,entry,effect,repetition,trigger)
				return
			var recipients: Array = []
			if effect.get("scope") is String and effect.get("scope") == "adjacent_friendly":
				if trigger != "avenge_effect" or not SproutAvenge.effect_error(effect).is_empty() or effect.source_id != source.get("card_id",source.get("id")):
					_fail("Adjacent permanent buff requires its exact living Avenge source")
					return
				# The death-wave host has already removed its simultaneous death set.
				# Use the current surviving body order, never the source's old slot,
				# a queued corpse's neighbors, or an original/reborn UID remapping.
				var alive: Array = _boards[side].filter(func(body): return int(body.health) > 0)
				var source_index: int = -1
				for index in range(alive.size()):
					if int(alive[index]._combat_id) == int(source._combat_id): source_index = index; break
				if source_index < 0: return
				for index in [source_index-1,source_index+1]:
					if index >= 0 and index < alive.size(): recipients.append(alive[index])
			else:
				for friendly in _boards[side]:
					# A minion already mortally wounded cannot be revived by a buff.
					if int(friendly["health"]) <= 0 or not _tribe_matches(friendly, str(effect.get("tribe", ""))):
						continue
					if bool(effect.get("exclude_self", false)) and int(friendly["_combat_id"]) == int(source["_combat_id"]):
						continue
					recipients.append(friendly)
				if str(effect["scope"]) == "random_friendly" and not recipients.is_empty():
					var ids: Array = []
					for friendly in recipients:
						ids.append(friendly["uid"])
					recipients = [recipients[_random_index(recipients.size(), "deathrattle_buff_target", ids)]]
				elif str(effect["scope"]) == "leftmost_friendly" and not recipients.is_empty():
					recipients = [recipients.front()]
				elif str(effect["scope"]) == "rightmost_friendly" and not recipients.is_empty():
					recipients = [recipients.back()]
			var health_delta: int = int(effect.get("health", 0))
			if str(effect.get("health_from", "")) == "source_max_health":
				health_delta = int(source["max_health"]) * int(effect.get("health_multiplier", 1))
			if trigger == "avenge_effect" or effect.has("permanent_scope"):
				# Preflight this single action, not later literal repetitions.
				# Existing receiving eligibility above remains unchanged.
				for friendly in recipients:
					if not StartCombatEffects.buff_fits(friendly, int(effect.get("attack", 0)), health_delta):
						_fail("Deathrattle buff exceeds the supported integer range" if effect.has("permanent_scope") else "Avenge buff exceeds the supported integer range")
						return
			for friendly in recipients:
				if not _adjust_board_stats(friendly,int(effect.get("attack",0)),health_delta,source): return
				_emit("buff", {"source": source["uid"], "target": friendly["uid"], "attack": friendly["attack"], "health": friendly["health"], "attack_delta": int(effect.get("attack", 0)), "health_delta": health_delta})
				# Actual runtime recipient variant; do not infer from source or ID.
				if effect.get("permanent_scope", "") == "all" or (effect.get("permanent_scope", "") == "golden" and friendly.get("golden", false) is bool and friendly.get("golden", false)):
					_emit("persistent_buff", {"type": "persistent_buff", "side": side, "source": source["uid"], "target_uid": friendly["uid"], "attack_delta": int(effect.get("attack", 0)), "health_delta": health_delta})
				if bool(effect.get("transfer_effect", false)):
					friendly["effects"].append(effect.duplicate(true))
					_emit("effect_transferred", {"source": source["uid"], "target": friendly["uid"], "effect": effect, "reason": trigger})
		"deathrattle_summon_from_hand":
			_summon_from_hand(entry,effect)
		"deathrattle_hand_buff":
			_apply_hand_buff(side, source, effect, repetition)
		BulkResourceHost.NativeSpellcraft.DEATHRATTLE,BulkResourceHost.NativeSpellcraft.AVENGE:
			_bulk_resource_host.activate_native_spellcraft(self,side,source,effect,trigger,repetition)
		"deathrattle_lockbox":
			_lockbox_host.activate(self,side,source,effect,trigger,repetition)
		"deathrattle_special_volumizer_resource":
			_bulk_resource_host.activate_volumizer(self,side,source,effect,trigger,repetition)
		"avenge_special_chromatic_resource", "deathrattle_special_chromatic_resource":
			_bulk_resource_host.activate_chromatic(self,side,source,effect,trigger,repetition)
		"deathrattle_bounty_resource":
			_bulk_resource_host.activate_bounty(self,side,source,effect,trigger,repetition)
		"avenge_finite_special_resource":
			_bulk_resource_host.activate_finite_avenge(self,side,source,effect,trigger,repetition)
		"avenge_special_magnetic_resource":
			_bulk_resource_host.activate_special(self,side,source,effect,trigger,repetition)
		"deathrattle_random_resource", "deathrattle_fixed_resource":
			if effect_type == "deathrattle_fixed_resource" and effect.get("kind") == "spell":
				_bulk_resource_host.activate_fixed_spell(self,side,source,effect)
			else:
				_bulk_resource_host.activate(self,side,source,effect)
		"deathrattle_copy_killer_base":
			var killer_identity: String = str(source.get("_killer_card_id",""))
			# Only a real first lethal packet/destroy operation sets this private
			# identity; a living/retriggered deathrattle without a killer grants none.
			if not killer_identity.is_empty():
				if _options.get("hand_card_kinds",{}).get(killer_identity)!="minion" or not _options.get("hand_card_templates",{}).has(killer_identity):
					_fail("Killer original copy requires its supported canonical minion template"); return
				_queue_card_reward(side,source,killer_identity,int(effect.count))

		"deathrattle_add_card":
			if _attachment_fixed_hand.matches(entry,effect): _attachment_fixed_hand.execute(self,entry,effect,repetition,trigger)
			elif source.get("card_id") in BulkResourceHost.NativeFixedHand.Native.DEATH_IDS: _bulk_resource_host._native_fixed_hand.execute(self,side,source,effect)
			else: _queue_card_reward(side, source, str(effect["card_id"]), int(effect.get("count", 1)))
		"deathrattle_keyword_bundle":
			# Select distinct living minions once, then grant the whole bundle to
			# each same target. Never resample separately for the three keywords.
			var bundle_candidates: Array = []
			for friendly in _boards[side]:
				if int(friendly.get("health",0))>0: bundle_candidates.append(friendly)
			for _selection in range(mini(int(effect.get("count",1)),bundle_candidates.size())):
				var bundle_ids: Array = []
				for candidate in bundle_candidates: bundle_ids.append(candidate.uid)
				var pick: int = _random_index(bundle_candidates.size(),"deathrattle_keyword_bundle_target",bundle_ids)
				var recipient: Dictionary = bundle_candidates[pick]
				bundle_candidates.remove_at(pick)
				for keyword in effect.keywords:
					if not _has_keyword(recipient,keyword):
						recipient.keywords.append(keyword)
						_emit("keyword_granted",{"source":source.uid,"target":recipient.uid,"keyword":keyword,"reason":"deathrattle_keyword_bundle"})

		"deathrattle_keyword":
			var keyword: String = str(effect["keyword"])
			if str(effect.get("scope", "random_friendly")) == "self":
				# A real Deathrattle source is gone; an Avenge source must still live.
				var live_source: Dictionary = _find_unit(side, int(source["_combat_id"]))
				if not live_source.is_empty() and int(live_source["health"]) > 0 and not _has_keyword(live_source, keyword):
					live_source["keywords"].append(keyword)
					_emit("keyword_granted", {"source": source["uid"], "target": live_source["uid"], "keyword": keyword})
				return
			var eligible: Array = []
			for friendly in _boards[side]:
				if effect.get("exclude_self",false) and friendly["uid"] == source["uid"]: continue
				if int(friendly["health"]) > 0 and _tribe_matches(friendly, str(effect.get("tribe", ""))) and not _has_keyword(friendly, keyword):
					eligible.append(friendly)
			var count: int = eligible.size() if int(effect.get("count", 1)) == -1 else mini(int(effect.get("count", 1)), eligible.size())
			for _index in range(count):
				var ids: Array = []
				for friendly in eligible:
					ids.append(friendly["uid"])
				var selected: int = _random_index(eligible.size(), "deathrattle_keyword_target", ids)
				var recipient: Dictionary = eligible[selected]
				eligible.remove_at(selected)
				recipient["keywords"].append(keyword)
				_emit("keyword_granted", {"source": source["uid"], "target": recipient["uid"], "keyword": keyword})
		"deathrattle_destroy_killer":
			var killer: Dictionary = _find_unit(1 - side, int(source["_killer"]))
			if not killer.is_empty() and int(killer["health"]) > 0:
				killer["_pending_destroy"] = true
				killer["health"] = 0
				killer["_killer"] = int(source["_combat_id"])
				killer["_killer_card_id"] = str(source.get("card_id",source.get("id","")))
				_emit("destroy", {"source": source["uid"], "target": killer["uid"], "reason": "destroy_killer"})
				if _kill_reward_host!=null: _kill_reward_host.capture(self,source,killer,_log.size()-1,"destroy_killer")

func _summon_attempt_observers(side: int) -> bool:
	return SummonAttempt.active_for(self,side)

func _summon_capacity_miss(payload: Dictionary) -> bool:
	if not _error.is_empty(): return false
	var side: int=int(payload.get("side",-1))
	if side not in [0,1] or _boards[side].size()!=BOARD_LIMIT or payload.get("reason")!="board_full": _fail("summon_attempt_false_capacity_miss");return false
	var sand_pirate_capacity_issue: String=_sand_barnstormer_host.pirate_tokens.capacity_miss(self,payload)
	if not sand_pirate_capacity_issue.is_empty(): _fail(sand_pirate_capacity_issue);return false
	_emit("summon_blocked",payload)
	if not _summon_attempt_observers(side): return true
	return _summon_attempt_host.capacity_miss(self,_log[-1])

func _summon(entry: Dictionary, template: Dictionary, reason: String, attack_immediately: bool = false, copy_damage: int = 0, attack_target: Dictionary = {}, created: Variant = null, khadgar_plan: Dictionary = {}) -> bool:
	var volatile_venom_template_issue: String=_volatile_venom_host.before_summon(self,entry,template)
	if not volatile_venom_template_issue.is_empty(): _fail(volatile_venom_template_issue);return false
	if template.has(TheotarParasolSources.GRANT):
		_fail("theotar_parasol_temporary_grant_fresh_summon_inheritance_partial");return false
	var incubation_copy_binding: Dictionary = _incubation_summon_copy_binding(entry, template, reason)
	if not str(incubation_copy_binding.error).is_empty(): _fail(str(incubation_copy_binding.error)); return false
	if Tony.Sources.claimed(template):
		_fail("tony_copied_or_reborn_source_partial");return false
	var tumbleweed_summon_issue: String=_tumbleweed_host.before_summon(self,entry,template,reason,attack_immediately)
	if not tumbleweed_summon_issue.is_empty():
		_fail(tumbleweed_summon_issue)
		return false
	if Amalgadon.contains_marker(template):
		_fail("amalgadon_acquired_copy_reborn_inheritance_partial");return false
	if OldSoulSources.claimed(template):
		_fail("old_soul_combat_copy_reborn_inheritance_partial");return false
	var lantern_plan: Dictionary=_lantern_host.before_summon(self,entry,template,reason,attack_immediately,copy_damage,attack_target)
	if not lantern_plan.ok: _fail(str(lantern_plan.error));return false
	var boom_controller_plan: Dictionary=_boom_controller_host.before_summon(self,entry,template,reason,attack_immediately,copy_damage,attack_target)
	if not boom_controller_plan.ok: _fail(str(boom_controller_plan.error));return false
	var soul_fermenter_plan: Dictionary=_soul_fermenter_host.before_summon(self,entry,template,reason,attack_immediately,copy_damage,attack_target)
	if not soul_fermenter_plan.ok: _fail(str(soul_fermenter_plan.error));return false
	var bonerender_plan: Dictionary=_bonerender_host.before_summon(self,entry,template,reason,attack_immediately,copy_damage,attack_target)
	if not bonerender_plan.ok: _fail(str(bonerender_plan.error));return false
	var khadgar_insertion_issue: String=Khadgar.insertion_error(self,entry,template,reason,khadgar_plan)
	if not khadgar_insertion_issue.is_empty(): _fail(khadgar_insertion_issue);return false
	if EnhancedSpawn.Sources.claimed(template): _fail("enhanced_spawn_fresh_combat_copy_summon_reborn_partial");return false
	if DitchGuardian.Sources.claimed(template): _fail("ditch_guardian_fresh_combat_copy_summon_reborn_partial");return false
	var seaside_summon_side: int=int(entry.get("side",-1))
	if seaside_summon_side in [0,1] and (Seaside.has(_boards[seaside_summon_side]) or Seaside.Sources.claimed(template)):
		var seaside_summon_issue: String=Seaside.domain(_boards[seaside_summon_side]+[template],_combat_hand.hands[seaside_summon_side])
		if not seaside_summon_issue.is_empty(): _fail(seaside_summon_issue);return false
	if Piranha.Sources.claimed(template): _fail("piranha_fresh_source_copy_reborn_inheritance_partial");return false
	var sand_demon_summon_issue: String=_sand_barnstormer_host.demon_tokens.before_summon(self,entry,template,reason)
	if not sand_demon_summon_issue.is_empty(): _fail(sand_demon_summon_issue);return false
	var sand_spirit_summon_issue: String=_sand_barnstormer_host.spirit.before_summon(self,entry,template,reason)
	if not sand_spirit_summon_issue.is_empty(): _fail(sand_spirit_summon_issue);return false
	var deity_summon_issue: String=_deity_host.summon_error(entry,template,reason)
	if not deity_summon_issue.is_empty(): _fail(deity_summon_issue);return false
	if DarkGiftSources.marked(template):
		_fail("dark_gift_combat_copy_inheritance_partial");return false
	if EscapeeSources.claimed(template): _fail("escapee_fresh_combat_source_inheritance_partial");return false
	if PilgrimpSources.claimed(template): _fail("pilgrimp_fresh_combat_source_inheritance_partial");return false
	if BazaarSources.claimed(template): _fail("bazaar_fresh_combat_source_inheritance_partial");return false
	if BouncySources.claimed(template): _fail("bouncy_refresh_fresh_combat_source_inheritance_partial");return false
	if HealthRefreshSources.claimed(template): _fail("health_refresh_fresh_combat_source_inheritance_partial");return false
	if TradeQuotas.Sources.claimed(template): _fail("trade_quota_fresh_combat_source_inheritance_partial");return false
	var friendly_consume_template_issue: String=FriendlyConsumeSources.unit_error(template)
	if not friendly_consume_template_issue.is_empty(): _fail(friendly_consume_template_issue);return false
	var start_friendly_consume_template_issue: String=StartFriendlyConsumeSources.unit_error(template)
	if not start_friendly_consume_template_issue.is_empty(): _fail(start_friendly_consume_template_issue);return false
	var faceless_disciple_template_issue: String=FacelessDiscipleSources.unit_error(template)
	if not faceless_disciple_template_issue.is_empty(): _fail(faceless_disciple_template_issue);return false
	var sand_swirler_template_issue: String=SandSwirlerSources.unit_error(template)
	if not sand_swirler_template_issue.is_empty(): _fail(sand_swirler_template_issue);return false
	var nathanos_template_issue: String=NathanosSources.unit_error(template)
	if not nathanos_template_issue.is_empty(): _fail(nathanos_template_issue);return false
	var snarky_shark_template_issue: String=SnarkySharkSources.unit_error(template)
	if not snarky_shark_template_issue.is_empty():
		_fail(snarky_shark_template_issue)
		return false
	var nightmare_template_issue: String=NightmareSources.unit_error(template)
	if not nightmare_template_issue.is_empty():
		_fail(nightmare_template_issue)
		return false
	var deathhead_template_issue: String=Deathhead.Sources.unit_error(template)
	if not deathhead_template_issue.is_empty():
		_fail(deathhead_template_issue)
		return false
	var siren_template_issue: String=SirenSources.unit_error(template)
	if not siren_template_issue.is_empty():
		_fail(siren_template_issue)
		return false
	var taverngoer_template_issue: String=TaverngoerSources.unit_error(template)
	if not taverngoer_template_issue.is_empty(): _fail(taverngoer_template_issue);return false
	var fandral_template_issue: String=FandralSources.unit_error(template)
	if not fandral_template_issue.is_empty(): _fail(fandral_template_issue);return false
	var necrolyte_template_issue: String=NecrolyteSources.unit_error(template)
	if not necrolyte_template_issue.is_empty(): _fail(necrolyte_template_issue);return false
	var felhorn_template_issue: String=FelhornSources.unit_error(template)
	if not felhorn_template_issue.is_empty(): _fail(felhorn_template_issue);return false
	var nether_template_issue: String=NetherConstructSources.unit_error(template)
	if not nether_template_issue.is_empty(): _fail(nether_template_issue);return false
	var felboar_template_issue: String=FelboarCastSources.unit_error(template)
	if not felboar_template_issue.is_empty(): _fail(felboar_template_issue);return false
	var clefthoof_template_issue: String=ClefthoofSources.unit_error(template)
	if not clefthoof_template_issue.is_empty(): _fail(clefthoof_template_issue);return false
	var panther_template_issue: String=PantherSources.unit_error(template)
	if not panther_template_issue.is_empty(): _fail(panther_template_issue);return false
	var native_hand_template_issue: String=HandAcquisition.Sources.unit_error(template)
	if not native_hand_template_issue.is_empty(): _fail(native_hand_template_issue);return false
	if HandAcquisition.Sources.has_counter(template): _fail("hand_acquisition_fresh_counter_source_inheritance_partial");return false
	if FishGroups.marked(template): _fail("fish_deathrattle_fresh_copy_inheritance_partial");return false
	if PiggyBank.Sources.contains_marker(template): _fail("piggy_bank_fresh_copy_inheritance_partial");return false
	if NativeRallySpread.Sources.contains_marker(template): _fail("native_rally_spread_fresh_copy_inheritance_partial");return false
	if RecurringNightmare.Sources.contains_acquired(template): _fail("recurring_nightmare_fresh_copy_inheritance_partial");return false
	var recurring_nightmare_template_issue: String=RecurringNightmare.Sources.unit_error(template)
	if not recurring_nightmare_template_issue.is_empty(): _fail(recurring_nightmare_template_issue);return false
	if StartGrantSources.contains_marker(template): _fail("native_start_grant_fresh_copy_inheritance_partial");return false
	if BrukanGrant.contains_marker(template): _fail("brukan_elements_fresh_copy_inheritance_partial");return false
	if TamsinGrant.contains_marker(template): _fail("tamsin_phylactery_fresh_copy_inheritance_partial");return false
	if TempDeath.marked(template): _fail("temporary_deathrattle_fresh_copy_inheritance_partial");return false
	if MegaGrants.contains_marker(template): _fail("megasaur_adapt_living_spores_fresh_copy_or_retention_partial");return false
	if created!=null and not created is Array: _fail("summon_created_receipt_requires_private_array");return false
	if not attack_target.is_empty() and not attack_immediately: _fail("rally_preemptive_target_requires_actual_attack");return false
	if copy_damage<0: _fail("combat_copy_negative_damage");return false
	var combat_transform_issue: String=CombatTransforms.unit_error(template)
	if not combat_transform_issue.is_empty(): _fail(combat_transform_issue);return false
	var hand_start_template_issue: String=HandStartCopy.Sources.unit_error(template)
	if not hand_start_template_issue.is_empty(): _fail(hand_start_template_issue);return false
	var summon_get_template_issue: String=SummonGet.Sources.unit_error(template)
	if not summon_get_template_issue.is_empty(): _fail(summon_get_template_issue);return false
	var rally_each_type_template_issue: String=RallyEachType.Sources.unit_error(template)
	if not rally_each_type_template_issue.is_empty(): _fail(rally_each_type_template_issue);return false
	var hand_board_template_issue: String=HandBoard.Sources.unit_error(template)
	if not hand_board_template_issue.is_empty(): _fail(hand_board_template_issue);return false
	var anchorman_template_issue: String=Anchorman.Sources.unit_error(template)
	if not anchorman_template_issue.is_empty(): _fail(anchorman_template_issue);return false
	var intrinsic_twice_template_issue: String=IntrinsicTwice.Sources.unit_error(template)
	if not intrinsic_twice_template_issue.is_empty(): _fail(intrinsic_twice_template_issue);return false
	var rally_permanent_shield_template_issue: String=RallyShield.Sources.unit_error(template)
	if not rally_permanent_shield_template_issue.is_empty(): _fail(rally_permanent_shield_template_issue);return false
	var last_spell_template_issue: String=LastSpell.Sources.unit_error(template)
	if not last_spell_template_issue.is_empty(): _fail(last_spell_template_issue);return false
	var combat_gem_trigger_template_issue: String=CombatGemTriggers.Sources.unit_error(template)
	if not combat_gem_trigger_template_issue.is_empty(): _fail(combat_gem_trigger_template_issue);return false
	var gem_summon_template_issue: String=GemSummon.Sources.unit_error(template)
	if not gem_summon_template_issue.is_empty(): _fail(gem_summon_template_issue);return false
	var gem_golem_template_issue: String=GemGolem.Sources.unit_error(template)
	if not gem_golem_template_issue.is_empty(): _fail(gem_golem_template_issue);return false
	var elistra_template_issue: String=Elistra.Sources.unit_error(template)
	if not elistra_template_issue.is_empty(): _fail(elistra_template_issue);return false
	var matador_template_issue: String=Matador.Sources.unit_error(template)
	if not matador_template_issue.is_empty(): _fail(matador_template_issue);return false
	var next_shop_template_issue: String=NextTurnShopSources.unit_error(template)
	if not next_shop_template_issue.is_empty(): _fail(next_shop_template_issue);return false
	var linked_undead_template_issue: String=LinkedUndead.Sources.unit_error(template)
	if not linked_undead_template_issue.is_empty(): _fail(linked_undead_template_issue);return false
	var pastry_template_issue: String=PastryAvenge.unit_error(template)
	if not pastry_template_issue.is_empty(): _fail(pastry_template_issue);return false
	var worgen_template_issue: String=Worgen.Sources.unit_error(template)
	if not worgen_template_issue.is_empty(): _fail(worgen_template_issue);return false
	var first_attack_template_issue: String=FirstAttack.Sources.unit_error(template)
	if not first_attack_template_issue.is_empty(): _fail(first_attack_template_issue);return false
	var sinestra_template_issue: String=Sinestra.unit_error(template)
	if not sinestra_template_issue.is_empty(): _fail(sinestra_template_issue);return false
	var stoneshell_template_issue: String=Stoneshell.Sources.unit_error(template)
	if not stoneshell_template_issue.is_empty(): _fail(stoneshell_template_issue);return false
	var dramaloc_template_issue: String=Dramaloc.Sources.unit_error(template)
	if not dramaloc_template_issue.is_empty(): _fail(dramaloc_template_issue);return false
	var rightmost_dual_template_issue: String=RightmostDual.Sources.unit_error(template)
	if not rightmost_dual_template_issue.is_empty(): _fail(rightmost_dual_template_issue);return false
	var seafloor_template_issue: String=SeafloorCast.Sources.unit_error(template)
	if not seafloor_template_issue.is_empty(): _fail(seafloor_template_issue);return false
	var rally_dragon_spell_template_issue: String=CombatRingCast.DragonSources.unit_error(template)
	if not rally_dragon_spell_template_issue.is_empty(): _fail(rally_dragon_spell_template_issue);return false
	var friendly_attack_ring_template_issue: String=CombatRingCast.AttackSources.unit_error(template)
	if not friendly_attack_ring_template_issue.is_empty(): _fail(friendly_attack_ring_template_issue);return false
	var staff_eot_template_issue: String=StaffEotSources.unit_error(template)
	if not staff_eot_template_issue.is_empty(): _fail(staff_eot_template_issue);return false
	var fauna_eot_template_issue: String=FaunaEotSources.unit_error(template)
	if not fauna_eot_template_issue.is_empty(): _fail(fauna_eot_template_issue);return false
	var reverber_drake_template_issue: String=ReverberDrakeSources.unit_error(template)
	if not reverber_drake_template_issue.is_empty(): _fail(reverber_drake_template_issue);return false
	var deadscale_spellcraft_template_issue: String=DeadscaleSources.unit_error(template)
	if not deadscale_spellcraft_template_issue.is_empty(): _fail(deadscale_spellcraft_template_issue);return false
	var terror_guard_template_issue: String=TerrorguardSources.unit_error(template)
	if not terror_guard_template_issue.is_empty(): _fail(terror_guard_template_issue);return false
	var brigand_template_issue: String=BrigandSources.unit_error(template)
	if not brigand_template_issue.is_empty(): _fail(brigand_template_issue);return false
	var disco_template_issue: String=DiscoSources.unit_error(template)
	if not disco_template_issue.is_empty(): _fail(disco_template_issue);return false
	var beatboxer_template_issue: String=BeatboxerSources.unit_error(template)
	if not beatboxer_template_issue.is_empty(): _fail(beatboxer_template_issue);return false
	var winds_spend_template_issue: String=WindsSpendSources.unit_error(template)
	if not winds_spend_template_issue.is_empty(): _fail(winds_spend_template_issue);return false
	var gatekeeper_cast_template_issue: String=GatekeeperSources.unit_error(template)
	if not gatekeeper_cast_template_issue.is_empty(): _fail(gatekeeper_cast_template_issue);return false
	var queensguard_template_issue: String=CombatRingCast.QueenSources.unit_error(template)
	if not queensguard_template_issue.is_empty(): _fail(queensguard_template_issue);return false
	var combat_ring_template_issue: String=CombatRingCast.Sources.unit_error(template)
	if not combat_ring_template_issue.is_empty(): _fail(combat_ring_template_issue);return false
	var whelp_summon_template_issue: String=WhelpSummon.Sources.unit_error(template)
	if not whelp_summon_template_issue.is_empty(): _fail(whelp_summon_template_issue);return false
	var rightmost_battlecry_template_issue: String=RightmostBattlecry.Sources.unit_error(template)
	if not rightmost_battlecry_template_issue.is_empty(): _fail(rightmost_battlecry_template_issue);return false
	var rylak_battlecry_template_issue: String=RylakBattlecry.Sources.unit_error(template)
	if not rylak_battlecry_template_issue.is_empty(): _fail(rylak_battlecry_template_issue);return false
	var adjacent_tide_template_issue: String=AdjacentTide.Sources.unit_error(template)
	if not adjacent_tide_template_issue.is_empty(): _fail(adjacent_tide_template_issue);return false
	var hag_reborn_template_issue: String=HagReborn.Sources.unit_error(template)
	if not hag_reborn_template_issue.is_empty(): _fail(hag_reborn_template_issue);return false
	var combat_golden_template_issue: String=CombatGolden.Sources.unit_error(template)
	if not combat_golden_template_issue.is_empty(): _fail(combat_golden_template_issue);return false
	var maximum_imp_template_issue: String=MaximumImp.Sources.unit_error(template)
	if not maximum_imp_template_issue.is_empty(): _fail(maximum_imp_template_issue);return false
	var gem_ledger_transfer_template_issue: String=GemLedgerTransfer.Sources.unit_error(template)
	if not gem_ledger_transfer_template_issue.is_empty(): _fail(gem_ledger_transfer_template_issue);return false
	var avenge_poison_template_issue: String=AvengePoison.Sources.unit_error(template)
	if not avenge_poison_template_issue.is_empty(): _fail(avenge_poison_template_issue);return false
	var hand_gem_template_issue: String=HandGemRepeatSources.unit_error(template)
	if not hand_gem_template_issue.is_empty(): _fail(hand_gem_template_issue);return false
	var activate_gem_template_issue: String=ActivateGemSources.unit_error(template)
	if not activate_gem_template_issue.is_empty(): _fail(activate_gem_template_issue);return false
	var activate_discard_template_issue: String=ActivateDiscardSources.unit_error(template)
	if not activate_discard_template_issue.is_empty(): _fail(activate_discard_template_issue);return false
	var activate_discard_resource_template_issue: String=ActivateDiscardResourceSources.unit_error(template)
	if not activate_discard_resource_template_issue.is_empty(): _fail(activate_discard_resource_template_issue);return false
	var activate_discard_amplifier_template_issue: String=ActivateDiscardAmplifierSources.unit_error(template)
	if not activate_discard_amplifier_template_issue.is_empty(): _fail(activate_discard_amplifier_template_issue);return false
	var deft_deserter_template_issue: String=DeftDeserterSources.unit_error(template)
	if not deft_deserter_template_issue.is_empty(): _fail(deft_deserter_template_issue);return false
	var targeted_activate_template_issue: String=TargetedActivateSources.unit_error(template)
	if not targeted_activate_template_issue.is_empty(): _fail(targeted_activate_template_issue);return false
	var skyhatch_rally_template_issue: String=SkyhatchRallySources.unit_error(template)
	if not skyhatch_rally_template_issue.is_empty(): _fail(skyhatch_rally_template_issue);return false
	var cagey_autocast_template_issue: String=CageyCastSources.unit_error(template)
	if not cagey_autocast_template_issue.is_empty(): _fail(cagey_autocast_template_issue);return false
	var magnetic_repeat_template_issue: String=MagneticRepeatSources.unit_error(template)
	if not magnetic_repeat_template_issue.is_empty(): _fail(magnetic_repeat_template_issue);return false
	var drone_repeat_template_issue: String=DroneRepeatSources.unit_error(template)
	if not drone_repeat_template_issue.is_empty(): _fail(drone_repeat_template_issue);return false
	var battlecry_activate_template_issue: String=BattlecryActivateSources.unit_error(template)
	if not battlecry_activate_template_issue.is_empty(): _fail(battlecry_activate_template_issue);return false
	var consume_observer_template_issue: String=ConsumeObserverSources.unit_error(template)
	if not consume_observer_template_issue.is_empty(): _fail(consume_observer_template_issue);return false
	var shop_consume_template_issue: String=ShopConsumeSources.unit_error(template)
	if not shop_consume_template_issue.is_empty(): _fail(shop_consume_template_issue);return false
	var deity_activate_template_issue: String=DeityActivateSources.unit_error(template)
	if not deity_activate_template_issue.is_empty(): _fail(deity_activate_template_issue);return false
	var combat_gem_template_issue: String=CombatGems.Sources.unit_error(template)
	if not combat_gem_template_issue.is_empty(): _fail(combat_gem_template_issue);return false
	var combat_copy_issue: String=CombatCopies.unit_error(template)
	if not combat_copy_issue.is_empty(): _fail(combat_copy_issue);return false
	var bulk_hand_issue: String=BulkHandSummon.unit_error(template)
	if not bulk_hand_issue.is_empty(): _fail(bulk_hand_issue);return false
	var salvager_template_issue: String=SalvagerSources.unit_error(template)
	if not salvager_template_issue.is_empty(): _fail(salvager_template_issue);return false
	if Hyena.Sources.claimed(template): _fail("hyena_fresh_source_copy_reborn_inheritance_partial");return false
	if Lobster.Sources.claimed(template):
		var hyena_summon_issue: String=_hyena_host.consume_summon(self,entry,template,reason,attack_immediately,copy_damage,attack_target,created,khadgar_plan)
		if not hyena_summon_issue.is_empty(): _fail(hyena_summon_issue);return false
	if Leviathan.Sources.claimed(template): _fail("leviathan_fresh_source_copy_reborn_inheritance_partial");return false
	if Hopebringer.Sources.claimed(template): _fail("hopebringer_fresh_source_copy_reborn_inheritance_partial");return false
	if Octosari.Sources.claimed(template): _fail("octosari_fresh_source_copy_reborn_inheritance_partial");return false
	var silithid_template_issue: String=SilithidSources.unit_error(template)
	if not silithid_template_issue.is_empty(): _fail(silithid_template_issue);return false
	var shield_taunt_template_issue: String=ShieldTaunt.unit_error(template)
	if not shield_taunt_template_issue.is_empty(): _fail(shield_taunt_template_issue);return false
	var native_enforcer_template_issue: String=NativeEnforcer.Sources.unit_error(template)
	if not native_enforcer_template_issue.is_empty(): _fail(native_enforcer_template_issue);return false
	var shield_permanent_template_issue: String=ShieldPermanent.Sources.unit_error(template)
	if not shield_permanent_template_issue.is_empty(): _fail(shield_permanent_template_issue);return false
	var shiny_layer_template_issue: String=ShinyLayer.Sources.unit_error(template)
	if not shiny_layer_template_issue.is_empty(): _fail(shiny_layer_template_issue);return false
	var marked_copy_issue: String=_start_choice_host.copy_summon_error(entry,template,reason)
	if not marked_copy_issue.is_empty(): _fail(marked_copy_issue);return false
	var start_choice_template_issue: String=StartChoice.Sources.unit_error(template)
	if not start_choice_template_issue.is_empty(): _fail(start_choice_template_issue);return false
	var keyword_loss_template_issue: String=KeywordLoss.Sources.unit_error(template)
	if not keyword_loss_template_issue.is_empty(): _fail(keyword_loss_template_issue);return false
	var roogug_template_issue: String=RoogugSources.unit_error(template)
	if not roogug_template_issue.is_empty(): _fail(roogug_template_issue);return false
	var satellite_magnetic_template_issue: String=CombatMagnetic.Satellite.unit_error(template)
	if not satellite_magnetic_template_issue.is_empty(): _fail(satellite_magnetic_template_issue);return false
	var electron_magnetic_template_issue: String=CombatMagnetic.Electron.unit_error(template)
	if not electron_magnetic_template_issue.is_empty(): _fail(electron_magnetic_template_issue);return false
	var magnetic_golden_template_issue: String=MagneticGoldenSources.unit_error(template)
	if not magnetic_golden_template_issue.is_empty(): _fail(magnetic_golden_template_issue);return false
	var drakkari_reborn_template_issue: String=DrakkariRebornSources.unit_error(template)
	if not drakkari_reborn_template_issue.is_empty(): _fail(drakkari_reborn_template_issue);return false
	var pufferquil_template_issue: String=PufferquilSources.unit_error(template)
	if not pufferquil_template_issue.is_empty(): _fail(pufferquil_template_issue);return false
	var cast_minion_gem_template_issue: String=CastMinionGemSources.unit_error(template)
	if not cast_minion_gem_template_issue.is_empty(): _fail(cast_minion_gem_template_issue);return false
	var maximum_history_template_issue: String=MaximumHistorySources.unit_error(template)
	if not maximum_history_template_issue.is_empty(): _fail(maximum_history_template_issue);return false
	var technician_native_template_issue: String=TechnicianKiller.unit_error(template)
	if not technician_native_template_issue.is_empty(): _fail(technician_native_template_issue);return false
	var fish_native_template_issue: String=FishGroups.unit_error(template)
	if not fish_native_template_issue.is_empty(): _fail(fish_native_template_issue);return false
	var each_type_template_issue: String=EachTypePermanent.unit_error(template)
	if not each_type_template_issue.is_empty(): _fail(each_type_template_issue);return false
	var jailbird_template_issue: String=JailbirdJuggernaut.Sources.unit_error(template)
	if not jailbird_template_issue.is_empty(): _fail(jailbird_template_issue);return false
	var krush_template_issue: String=KrushPreemptive.unit_error(template)
	if not krush_template_issue.is_empty(): _fail(krush_template_issue);return false
	var preemptive_issue: String=Preemptive.unit_error(template)
	if not preemptive_issue.is_empty(): _fail(preemptive_issue);return false
	var deferred_hand_issue: String=DeferredHand.unit_error(template)
	if not deferred_hand_issue.is_empty(): _fail(deferred_hand_issue);return false
	var knight_issue: String=Knights.unit_error(template)
	if not knight_issue.is_empty(): _fail(knight_issue);return false
	var living_dr_issue: String=LivingDeathrattles.unit_error(template)
	if not living_dr_issue.is_empty(): _fail(living_dr_issue);return false
	var grant_issue: String=RebornGrants.unit_error(template)
	if not grant_issue.is_empty(): _fail(grant_issue);return false
	var retention_issue: String=RebornRetention.unit_error(template)
	if not retention_issue.is_empty(): _fail(retention_issue);return false
	var attempt_issue: String=SummonAttempt.unit_error(template)
	if not attempt_issue.is_empty(): _fail(attempt_issue);return false
	var reborn_combat_issue: String=RebornCombat.unit_error(template)
	if not reborn_combat_issue.is_empty(): _fail(reborn_combat_issue); return false
	var original_jelly_issue: String = OriginalJelly.unit_error(template,_options.get("hand_card_templates",{}))
	if not original_jelly_issue.is_empty(): _fail(original_jelly_issue); return false
	var jelly_issue: String = Jelly.unit_error(template,_options.get("hand_card_templates",{}))
	if not jelly_issue.is_empty(): _fail(jelly_issue); return false
	var sister_issue: String = Sister.unit_error(template,_options.get("hand_card_templates",{}))
	if not sister_issue.is_empty(): _fail(sister_issue); return false
	if Gnoll.has_dynamic_layer(template):
		_fail("gnoll_death_aura_imported_summon_layer")
		return false
	if CorpseSale.Sources.claimed(template):
		_fail("corpse_sale_combat_source_summon_inheritance_not_verified")
		return false
	var side: int = int(entry["side"])
	if _boards[side].size() >= BOARD_LIMIT:
		_summon_capacity_miss({"side": side, "source": entry["unit"]["uid"], "reason": "board_full", "kind": reason})
		if entry.get("hand_summon_plan") is Dictionary:
			var cancelled: String = _hand_summons.commit(entry.hand_summon_plan,false)
			if not cancelled.is_empty(): _fail(cancelled)
		return false
	var octosari_birth_issue: String=_octosari_host.before_insertion(self,side,template)
	if not octosari_birth_issue.is_empty(): _fail(octosari_birth_issue);return false
	if reason=="reborn" and entry.has("retained_reborn") and GlobalCards.Whelps.needs_projection(_options.get("left_global_card_state" if side==0 else "right_global_card_state",{}),template): _fail("whelp_owner_retained_reborn_intersection_partial");return false
	if NativeSummonClock.claimed(template): _fail("summon_resource_source_reborn_copy_insertion_counter_unproved_partial");return false
	var sand_pirate_birth_issue: String=_sand_barnstormer_host.pirate_tokens.before_birth(self,entry,template,reason)
	if not sand_pirate_birth_issue.is_empty(): _fail(sand_pirate_birth_issue);return false
	var token_entry: Dictionary = _beetle_entry_preview(template,side,"%s:%s:%d" % [str(entry["unit"]["uid"]),reason,_serial+1])
	if not str(token_entry.error).is_empty(): _fail(str(token_entry.error)); return false
	var index: int = int(entry["position"])
	if not incubation_copy_binding.parent.is_empty():
		# Recheck the original reservation/source at the real birth boundary.
		# The preview may alter stats, never native identity or type authority.
		incubation_copy_binding = _incubation_summon_copy_binding(entry, template, reason)
		if not str(incubation_copy_binding.error).is_empty(): _fail(str(incubation_copy_binding.error)); return false
		var incubation_preview_issue: String = IncubationMutationSources.detached_copy_error(incubation_copy_binding.parent, token_entry.template)
		if not incubation_preview_issue.is_empty(): _fail(incubation_preview_issue); return false
	var unit: Dictionary = _prepare_unit(token_entry.template, side, incubation_copy_binding.parent)
	if not _error.is_empty(): return false
	unit["uid"] = "%s:%s:%d" % [str(entry["unit"]["uid"]), reason, int(unit["_combat_id"])]
	# Reborn/native summons receive their own UID-bound layer; the native
	# _base remains unchanged and never stores the owner's all-type marker.
	var incubation_summon_issue: String = _incubation_receive_prepared(unit)
	if not incubation_summon_issue.is_empty(): _fail(incubation_summon_issue); return false
	if not _start_choice_host.materialize_copy(self,entry,template,unit,reason): return false
	if not _hag_reborn_host.materialize(self,entry,template,unit,reason): return false
	if not _battlecruiser_ultra_host.materialize(self,entry,template,unit,reason): return false
	if not token_entry.after.is_empty(): BeetleGrowth._write_stats(unit,token_entry.after)
	var drakkari_summon_issue: String=GlobalCards.DrakkariTypes.receive(_options.get("left_global_card_state" if side==0 else "right_global_card_state",{}),unit,"board")
	if not drakkari_summon_issue.is_empty(): _fail(drakkari_summon_issue);return false
	var lightfang_summon_issue: String=GlobalCards.LightfangTypes.receive(_options.get("left_global_card_state" if side==0 else "right_global_card_state",{}),unit,"board")
	if not lightfang_summon_issue.is_empty(): _fail(lightfang_summon_issue);return false
	var smuggler_summon_issue: String=GlobalCards.SmugglerTypes.receive(_options.get("left_global_card_state" if side==0 else "right_global_card_state",{}),unit,"board")
	if not smuggler_summon_issue.is_empty(): _fail(smuggler_summon_issue);return false
	var bronzebeard_summon_issue: String=GlobalCards.BronzebeardTypes.receive(_options.get("left_global_card_state" if side==0 else "right_global_card_state",{}),unit,"board")
	if not bronzebeard_summon_issue.is_empty(): _fail(bronzebeard_summon_issue);return false
	if not _combat_tribe_bonuses.apply_to_summon(self, side, unit): return false
	if not _permanent_tribe_effects.apply_to_summon(self, side, unit): return false
	var global_summon_issue: String = GlobalCards.combat_project(self,side,unit)
	if not global_summon_issue.is_empty(): _fail(global_summon_issue); return false
	incubation_summon_issue = _incubation_receive_prepared(unit)
	if not incubation_summon_issue.is_empty(): _fail(incubation_summon_issue); return false
	if reason=="reborn" and (unit.has(GlobalCards.Whelps.MARKER) or unit.has(GlobalCards.LightfangTypes.MARKER) or unit.has(GlobalCards.SmugglerTypes.MARKER) or unit.has(GlobalCards.BronzebeardTypes.MARKER)): unit.health=1
	var automaton_insert_preview_issue: String=_global_counter_host.preflight_insertion(self,side,unit)
	if not automaton_insert_preview_issue.is_empty(): _fail(automaton_insert_preview_issue);return false
	# Keep ghost-slot positions for every corpse in this wave. This preserves
	# original board order even when a later corpse's Deathrattle summons before
	# an earlier corpse's Reborn, and when adjacent minions die simultaneously.
	var pending_queues: Array = _nested_death_queues.duplicate()
	if not bool(entry.get("live_source",false)): pending_queues.append(_pending_deaths)
	var all_pending: Array = []
	for pending_queue in pending_queues:
		for pending_item in pending_queue:
			if not all_pending.any(func(existing): return is_same(existing,pending_item)): all_pending.append(pending_item)
	for pending in all_pending:
		if int(pending["side"]) != side:
			continue
		var pending_position: int = int(pending["position"])
		if pending_position > index or (pending_position == index and int(pending["order"]) >= int(entry["order"])):
			pending["position"] = pending_position + 1
	if index < _cursor[side]:
		_cursor[side] += 1
	var listeners: Array = _boards[side].duplicate()
	_boards[side].insert(index, unit)
	var volatile_venom_entry_issue: String=_volatile_venom_host.entered(self,side,unit,true)
	if not volatile_venom_entry_issue.is_empty(): _fail(volatile_venom_entry_issue);return false
	# Initialize all new live source layers before summon readers. Its own final
	# stats enter the summon event; existing recipients get explicit projections.
	if not BoardAuraRuntime.sync_combat(self,"summon_board_aura"): return false
	# Inherited wounds are state, not a new damage event. Copy-only callers
	# restore them after every managed layer, before actual summon observers.
	if copy_damage>0:
		if copy_damage>=int(unit.max_health): _fail("combat_copy_damage_exceeds_reprojected_body");return false
		unit.health=int(unit.max_health)-copy_damage
	if bool(entry.get("live_source", false)):
		entry["position"] = index + 1
	if entry.get("hand_summon_plan") is Dictionary:
		var locked: String = _hand_summons.commit(entry.hand_summon_plan,true)
		if not locked.is_empty(): _fail(locked); return false
		unit["_hand_source_reference"] = entry.hand_summon_plan.reference
	var sand_pirate_insert_issue: String=_sand_barnstormer_host.pirate_tokens.inserted_before_global(self,entry,unit)
	if not sand_pirate_insert_issue.is_empty(): _fail(sand_pirate_insert_issue);return false
	if _global_counter_host != null and not _global_counter_host.successful_insertion(self,side,unit): return false
	if not ThresholdDamage.combat_check(self,unit,"successful_insertion"): return false
	var summon_event: Dictionary = {"side": side, "source": entry["unit"]["uid"], "unit": _public_unit(unit), "position": index, "kind": reason}
	if entry.get("hand_summon_plan") is Dictionary: summon_event.hand_source_reference=entry.hand_summon_plan.reference
	_emit("summon",summon_event)
	var actual_summon_receipt: Dictionary=_log[-1]
	var hyena_insert_issue: String=_hyena_host.inserted(self,entry,template,unit,reason,actual_summon_receipt)
	if not hyena_insert_issue.is_empty(): _fail(hyena_insert_issue);return false
	var sand_pirate_receipt_issue: String=_sand_barnstormer_host.pirate_tokens.birth_receipt(self,entry,template,unit,reason,actual_summon_receipt)
	if not sand_pirate_receipt_issue.is_empty(): _fail(sand_pirate_receipt_issue);return false
	var sand_demon_birth_issue: String=_sand_barnstormer_host.demon_tokens.inserted(self,entry,template,unit,reason,actual_summon_receipt)
	if not sand_demon_birth_issue.is_empty(): _fail(sand_demon_birth_issue);return false
	var sand_spirit_birth_issue: String=_sand_barnstormer_host.spirit.inserted(self,entry,template,unit,reason,actual_summon_receipt)
	if not sand_spirit_birth_issue.is_empty(): _fail(sand_spirit_birth_issue);return false
	if not _octosari_host.successful(self,side,unit,actual_summon_receipt,listeners): return false
	if not _owned_mech_shield_host.capture(self,"summon",side,unit,actual_summon_receipt): return false
	if _summon_resource_host!=null and not _summon_resource_host.successful_summon(self,side,unit,actual_summon_receipt,listeners): return false
	# This local placement claims no official priority. Noncommuting same-side
	# interactions and source-self-Reborn are rejected by pure entry gates.
	if reason == "reborn" and not _sister_reborn_host.on_reborn(self,side,unit,listeners): return false
	# Local category order: minion listeners, then actual acquired trinket slots.
	if reason == "reborn" and not _reborn_mechanism_host.on_reborn(self,side,unit,actual_summon_receipt): return false
	if not CombatHero.on_summon(self, side, unit, _options.get("left_combat_hero" if side == 0 else "right_combat_hero",{})): return false
	if not _cruise_controller.on_summon(self,side,unit,listeners): return false
	if not _valithria_entry_context.is_empty(): _fail("valithria_reentrant_combat_insertion");return false
	_valithria_entry_context={"body":unit,"listeners":listeners,"receipt":actual_summon_receipt}
	if not _leviathan_insertion_context.is_empty(): _fail("leviathan_reentrant_combat_insertion");return false
	_leviathan_insertion_context={"target":unit,"listeners":listeners,"receipt":actual_summon_receipt}
	_trigger_friendly_summon(unit, listeners, actual_summon_receipt)
	_leviathan_insertion_context={}
	_valithria_entry_context={}
	if not _error.is_empty(): return false
	if not _reborn_mechanism_host.on_summon(self,side,unit,actual_summon_receipt): return false
	if not _owned_mech_shield_host.observe(self,"summon",side,unit,actual_summon_receipt): return false
	if attack_immediately and _error.is_empty():
		if attack_target.is_empty(): _attack_new_summon(side,unit)
		else: _force_single_attack(side,unit,"immediate_summon_attack",attack_target)
	if _error.is_empty() and not _deferred_hand_host.pump(self,"successful_insertion"): return false
	if _error.is_empty() and _plain_copy_host!=null and _plain_copy_host._ozumat_host!=null and not _plain_copy_host._ozumat_host.pump(self,"successful_insertion"): return false
	if _error.is_empty() and _plain_copy_host!=null and _plain_copy_host._turn_seven_copy_host!=null and not _plain_copy_host._turn_seven_copy_host.pump(self,"successful_insertion"): return false
	if _error.is_empty() and _plain_copy_host!=null and _plain_copy_host._teron_host!=null and not _plain_copy_host._teron_host.pump(self,"successful_insertion"): return false
	if _error.is_empty() and not _automaton_portrait_host.pump(self,"successful_insertion"): return false
	if _error.is_empty() and not _knitted_sunfin_host.pump(self,"successful_insertion"): return false
	if _error.is_empty() and not _beetle_blessing_host.pump(self,"successful_insertion"): return false
	if _error.is_empty():
		var bonerender_issue: String=_bonerender_host.after_summon(self,entry,unit,actual_summon_receipt,bonerender_plan)
		if not bonerender_issue.is_empty(): _fail(bonerender_issue);return false
	if _error.is_empty():
		var lantern_issue: String=_lantern_host.after_summon(self,entry,unit,actual_summon_receipt,lantern_plan)
		if not lantern_issue.is_empty(): _fail(lantern_issue);return false
	if _error.is_empty() and created is Array: created.append(unit)
	return _error.is_empty()


func _attack_new_summon(side: int, unit: Dictionary) -> void:
	_force_single_attack(side,unit,"immediate_summon_attack")

func _force_single_attack(side: int, unit: Dictionary, reason: String, fixed_target: Dictionary = {}) -> void:
	if not fixed_target.is_empty() and not Preemptive.live(self,1-side,fixed_target): _fail("rally_preemptive_original_defender_lost_unresolved");return
	# A forced one-exchange attack uses the complete real attack path. It does
	# not advance the ordinary side alternation or consume extra Windfury hits.
	if int(unit.get("health",0))<=0 or int(unit.get("attack",0))<=0 or unit.get("_pending_destroy",false): return
	if _find_unit(side,int(unit._combat_id)).is_empty() or _boards[1-side].is_empty(): return
	if _nested_death_queues.size()>=32: _fail("Forced attack nesting exceeds controlled depth 32");return
	if not _tick(reason): return
	var sand_pirate_force_issue: String=_sand_barnstormer_host.pirate_tokens.before_force(self,side,unit,reason,fixed_target)
	if not sand_pirate_force_issue.is_empty(): _fail(sand_pirate_force_issue);return
	# Forced attacks do not acquire the outer turn. Preserve its owner even
	# when the forced attacker is opposing; defending outer-owner Overkill
	# remains eligible through the actual damage-source side check.
	var suspended_overkill_turn: int=_overkill_turn_side
	if _overkill_turn_side<0: _overkill_turn_side=side
	var suspended_queue: Array = _pending_deaths
	var suspended_priority: int = _priority_side
	_nested_death_queues.append(suspended_queue)
	_emit(reason,{"side":side,"source":unit.uid,"combat_id":unit._combat_id})
	_priority_side=side
	var previous_attacking: bool=bool(unit.get("_attacking",false))
	unit["_attacking"]=true
	_attack(side,unit,1,fixed_target)
	if _error.is_empty(): _resolve_deaths()
	if _error.is_empty():
		var sand_pirate_return_issue: String=_sand_barnstormer_host.pirate_tokens.before_force_return(self,side,unit)
		if not sand_pirate_return_issue.is_empty(): _fail(sand_pirate_return_issue)
	unit["_attacking"]=previous_attacking
	_nested_death_queues.pop_back()
	_pending_deaths=suspended_queue
	_priority_side=suspended_priority
	_overkill_turn_side=suspended_overkill_turn
	if _error.is_empty():
		var sand_pirate_return_done: String=_sand_barnstormer_host.pirate_tokens.after_force_return(self,side,unit)
		if not sand_pirate_return_done.is_empty(): _fail(sand_pirate_return_done)
	if _error.is_empty(): _piranha_host.pump(self,"completed_forced_attack")

func _hand_summon_context_error(left: Array, right: Array, options: Dictionary) -> String:
	var inputs: Array = [left,right]
	var active: bool = false
	for side in range(2):
		var all: Array = inputs[side].duplicate()
		var hand: Variant = options.get("left_hand" if side == 0 else "right_hand",[])
		if hand is Array: all.append_array(hand)
		for unit in all:
			if unit is Dictionary and HandSummon.inspect_unit(unit).observes: active = true
	# A combat reward can introduce a hand observer that was absent at entry.
	# Traverse only real reward dependencies, not unrelated catalog templates.
	var pending_sources: Array = []
	for side in range(2):
		var initial: Array = inputs[side].duplicate()
		var initial_hand: Variant = options.get("left_hand" if side==0 else "right_hand",[])
		if initial_hand is Array: initial.append_array(initial_hand)
		for unit in initial:
			if unit is Dictionary: pending_sources.append_array(CombatHand.inspect_unit(unit).rewards)
	var seen_sources: Dictionary = {}
	while not pending_sources.is_empty():
		var identity: String = str(pending_sources.pop_front())
		if seen_sources.has(identity): continue
		seen_sources[identity]=true
		var future: Variant = options.get("hand_card_templates",{}).get(identity)
		if not future is Dictionary: continue # Existing CombatHand validation reports missing required templates.
		if HandSummon.inspect_unit(future).observes: active=true
		pending_sources.append_array(CombatHand.inspect_unit(future).rewards)
	if not active: return ""
	var reachable: Array = []
	var generation: Array = []
	for side in range(2):
		var prefix: String = "left" if side == 0 else "right"
		if options.get(prefix+"_is_ghost",false): return "手牌召唤的淘汰快照锁生命周期尚待核实；不能默认清锁或锁死。"
		if not options.has(prefix+"_hand"): return "手牌召唤需要双方真实完整手牌。"
		var issue: String = HandSummon.hand_error(options[prefix+"_hand"])
		if not issue.is_empty(): return issue
		var all: Array = inputs[side].duplicate()
		all.append_array(options[prefix+"_hand"])
		for unit in all:
			if unit.get("kind","minion") != "minion": continue
			if not HandSummon.integer(unit.get("tier"),0):return "手牌召唤目标需要真实整数星级。"
			issue = _validate_unit(unit,0)
			if not issue.is_empty():return issue
			reachable.append(unit)
			generation.append_array(CombatHand.inspect_unit(unit).rewards)
	# Only actually reachable combat rewards, never the entire catalog template
	# registry, can enter the future hand and therefore its effect closure.
	var seen: Dictionary = {}
	while not generation.is_empty():
		var id: String = str(generation.pop_front())
		if seen.has(id):continue
		seen[id]=true
		if options.get("hand_card_kinds",{}).get(id,"")!="minion":continue
		var template: Variant = options.get("hand_card_templates",{}).get(id)
		if not template is Dictionary:return "手牌召唤缺少生成随从完整模板："+id
		var issue: String = HandSummon._unit_shape_error(template)
		if not issue.is_empty():return issue
		if not HandSummon.integer(template.get("tier"),0):return "生成手牌召唤目标需要真实整数星级。"
		issue = _validate_unit(template,0)
		if not issue.is_empty():return issue
		reachable.append(template)
		generation.append_array(CombatHand.inspect_unit(template).rewards)
	var errors: Array[String] = HandSummonRoom.errors_for_units(reachable)
	if not errors.is_empty():return errors[0]
	# Newly summoned live aura sources need the same explicit native registry
	# and real owner context even if the initial board had no active source.
	if BoardAuraRuntime.contains(reachable) or options.has("left_owner_aura_context") or options.has("right_owner_aura_context"):
		if not options.get("board_aura_catalog") is Dictionary:return "手牌可召唤的持续光环需要完整来源目录。"
		var aura_errors: Array[String] = BoardAuraRuntime.Admission.errors_for_units(reachable+BoardAuraRuntime.owner_context_cards(options),options.board_aura_catalog)
		if not aura_errors.is_empty():return aura_errors[0]
		for side in range(2):
			var prefix: String = "left" if side == 0 else "right"
			if not BoardAura.integer(options.get(prefix+"_board_aura_owner")) or not BoardAura.integer(options.get(prefix+"_tier"),1):return "手牌光环需要真实控制者与等级。"
	return ""

func _summon_from_hand(entry: Dictionary, effect: Dictionary) -> void:
	var side: int = int(entry.side)
	var choose: Callable = func(references: Array) -> int:
		return _random_index(references.size(),"hand_summon_highest_health",references)
	# Source-specific reviewed callback semantics: Timewarped Bassgill and Sneed
	# release the original hand reservation on cancelled insertion. Ordinary
	# Bassgill is partial: its conflicting cancellation branch stays held.
	var policy: String = HandSummon.SUCCESS_ONLY_POLICY if str(entry.unit.get("card_id","")) in ["BG34_Giant_071","BG34_Giant_071_G","BG21_HERO_030t","BG21_HERO_030t_G"] else ""
	var batch: Dictionary = _hand_summons.plan_batch(side,_combat_hand.hands[side],effect,_boards[side].size(),choose,[],policy,_options.get("hand_card_templates",{}))
	if not str(batch.error).is_empty():_fail(batch.error);return
	if batch.status != "ready":
		if batch.status=="blocked" and batch.get("reason")=="board_full" and _summon_attempt_observers(side):
			for attempt in range(int(batch.get("capacity_misses",0))):
				if not _summon_capacity_miss({"side":side,"source":entry.unit.uid,"reason":"board_full","kind":"hand_summon","attempt":attempt+1}): return
		return
	var issue: String = _hand_summons.reserve_batch(batch.plans,_combat_hand.hands[side])
	if not issue.is_empty():_fail(issue);return
	for plan in batch.plans:
		if not _error.is_empty():
			_hand_summons.commit(plan,false)
			continue
		if str(entry.unit.get("card_id","")) in ["BG26_350","BG26_350_G"] and _boards[side].size()>=BOARD_LIMIT:
			_hand_summons.commit(plan,false)
			_fail("Ordinary Bassgill later capacity cancellation remains policy-required")
			continue
		var context: Dictionary = entry.duplicate(false)
		context.hand_summon_plan=plan
		_summon(context,plan.template,"hand_summon")
		# Live Macaw source positions must advance between the batch's copies;
		# dead-source ghost-slot ordering is maintained by _pending_deaths.
		if bool(entry.get("live_source",false)):entry.position=context.position

func _rally_summon_from_hand(side: int, source: Dictionary, action: Dictionary) -> void:
	var choose: Callable = func(references: Array) -> int:
		return _random_index(references.size(),"hand_summon_highest_attack",references)
	# Freeze only the candidate references. Unlike the Deathrattle batch, each
	# candidate's current numbers are copied when its own insertion begins.
	var selected: Dictionary = _hand_summons.select_references(side,_combat_hand.hands[side],action,choose)
	if not str(selected.error).is_empty(): _fail(selected.error); return
	for reference in selected.references:
		if not _error.is_empty(): return
		var source_index: int = _boards[side].find(source)
		if source_index < 0 or int(source.health)<=0: return
		var current: Dictionary = {}
		for card in _combat_hand.hands[side]:
			if HandSummon.card_reference(card)==reference: current=card; break
		var native: Dictionary = _options.get("hand_card_templates",{}).get(str(current.get("card_id","")),{})
		var prepared: Dictionary = _hand_summons.prepare_reference(side,_combat_hand.hands[side],action,reference,_boards[side].size(),native)
		if not str(prepared.error).is_empty(): _fail(prepared.error); return
		if prepared.status!="ready":
			if prepared.status=="blocked" and prepared.get("reason")=="board_full" and _summon_attempt_observers(side):
				if not _summon_capacity_miss({"side":side,"source":source.uid,"reason":"board_full","kind":"hand_summon","hand_source_reference":reference}): return
			continue
		var issue: String = _hand_summons.reserve_batch([prepared.plan],_combat_hand.hands[side])
		if not issue.is_empty(): _fail(issue); return
		# Every candidate anchors immediately right of the still-living Aviator;
		# golden H then L enter in that order, ending Aviator,L,H without readers.
		var entry: Dictionary = {"side":side,"unit":source,"position":source_index+1,"order":source_index,"live_source":true,"hand_summon_plan":prepared.plan}
		_summon(entry,prepared.plan.template,"hand_summon")

func _after_death_hand_summons(entry: Dictionary) -> void:
	var side: int = int(entry.side)
	var observer: bool = false
	for held in _combat_hand.hands[side]:
		for effect in held.get("effects",[]):
			if effect.get("type")==HandSummon.SELF_TYPE: observer=true
	if not observer: return
	var batch: Dictionary = _hand_summons.plan_self_batch(side,_combat_hand.hands[side],entry.unit.get("tribes",[]),_boards[side].size(),[],_options.get("hand_card_templates",{}),_summon_attempt_observers(side))
	if not str(batch.error).is_empty(): _fail(batch.error); return
	if batch.status!="ready": return
	var issue: String = _hand_summons.reserve_batch(batch.plans,_combat_hand.hands[side])
	if not issue.is_empty(): _fail(issue); return
	for plan in batch.plans:
		if not _error.is_empty():
			_hand_summons.commit(plan,false)
			continue
		# Actual dead Beast supplies the event/position anchor, while plan holds
		# the distinct hand-source UID. No hand card is removed or returned.
		var context: Dictionary = entry.duplicate(false)
		context.hand_summon_plan=plan
		_summon(context,plan.template,"hand_summon")

func _apply_start_combat(first_side: int) -> void:
	# Original sources/effects only. Resolve each live source in first-side / LTR
	# order; a source removed by earlier start damage cannot activate afterward.
	var scheduled: Dictionary=_start_repeat_host.prepare(self,first_side)
	if not scheduled.ok: _fail(str(scheduled.error));return
	var queued: Array=scheduled.queue
	for activation in queued:
		if not _error.is_empty():
			return
		var repeat_issue: String=_start_repeat_host.advance(self,activation)
		if not repeat_issue.is_empty(): _fail(repeat_issue);return
		if activation.get("skip_repeat",false): continue
		var side: int = int(activation["side"])
		var source: Dictionary = activation["source"]
		var effect: Dictionary = activation["effect"]
		var effect_type: String = str(effect["type"])
		if _find_unit(side, int(source["_combat_id"])).is_empty() or int(source["health"]) <= 0:
			_emit("start_combat_skipped", {"source": source["uid"], "effect": effect_type, "reason": "source_dead"})
			continue
		if activation.get("inactive_source",false):
			_emit("start_combat_skipped", {"source": source["uid"], "effect": effect_type, "reason": "source_inactive"})
			continue
		var own_attack_plan: Dictionary = {}
		if Ragnaros.Sources.claimed(source) or Ragnaros.Sources.effect_claimed(effect):
			own_attack_plan = Ragnaros.plan(self,side,source,effect)
			if not str(own_attack_plan.error).is_empty(): _fail(str(own_attack_plan.error)); return
			if own_attack_plan.inactive: continue
		var gadrin_plan: Dictionary = {}
		if Gadrin.claimed(source) or Gadrin.effect_claimed(effect):
			gadrin_plan = StartCombatEffects.recipient_health_plan(self,side,source,effect)
			if not str(gadrin_plan.error).is_empty(): _fail(str(gadrin_plan.error)); return
			if gadrin_plan.inactive: continue
		_priority_side = side
		if effect_type==Hopebringer.Sources.START:
			if not _hopebringer_host.start(self,side,source,effect): return
		elif effect_type in [KerriganZerg.Sources.COPY,KerriganZerg.Sources.MULTIPLY]:
			if not _kerrigan_zerg_host.start_combat(self,side,source,effect,func(original,template):return KerriganLifecycle.combat_inheritance(original,template)): return
		elif effect_type==Anchorman.Sources.TYPE:
			if not _anchorman_host.activate(self,side,source,effect): return
		elif effect_type in StartChoice.Sources.TYPES:
			if not _start_choice_host.activate(self,side,source,effect): return
		elif effect_type==MarketStats.Sources.START:
			if not MarketStats.combat(self,side,source,effect): return
		elif effect_type==DeferredHand.TYPE:
			if not _deferred_hand_host.register(self,side,source,effect): return
		elif effect_type==SalvagerSources.START:
			if not _salvager_host.start(self,side,source,effect): return
		elif effect_type==HagReborn.Sources.TYPE:
			if not _hag_reborn_host.grant(self,side,source,effect): return
		elif effect_type==CombatRingCast.Sources.TYPE:
			_native_spell_start_context={"side":side,"source":source,"effect":effect}
			var combat_ring_start_ok: bool=_combat_ring_cast_host.start(self,side,source,effect)
			_native_spell_start_context={}
			if not combat_ring_start_ok: return
		elif effect_type==CombatGolden.Sources.START:
			if not _combat_golden_host.activate(self,side,source,effect): return
		elif effect_type==CombatTransforms.START_TYPE:
			if _incubation_combat_active(): _fail("incubation_mutation_combat_identity_transform_partial"); return
			if not CombatTransforms.activate(self,side,source,effect): return
		elif effect_type==CombatCopies.TYPE:
			if MegaGrants.marked(source): _fail("megasaur_adapt_living_spores_current_self_copy_partial");return
			if not CombatCopies.activate(self,side,source,effect): return
		elif effect_type==Stoneshell.Sources.TYPE:
			if not _stoneshell_host.acquire(self,side,source,effect): return
		elif effect_type==WhirlGroups.TYPE:
			if not WhirlAcquisition.activate(self,side,source,effect): return
		elif effect_type==LivingDeathrattles.START_TYPE:
			if not LivingDeathrattles.activate(self,side,source,effect): return
		elif effect_type==RebornGrants.START_TYPE:
			if not RebornGrants.apply_start(self,side,source,effect): return
		elif effect_type=="start_combat_grant_deathrattle":
			if source.get("silenced",false) or source.get("abilities_disabled",false) or source.get("_pending_destroy",false): continue
			_native_start_grant_context={"side":side,"source":source,"effect":effect}
			var native_start_grant_ok: bool=_native_start_grant_host.apply(self,side,source,effect)
			_native_start_grant_context={}
			if not native_start_grant_ok: return
		elif effect_type=="start_combat_force_attack":
			for activation_index in range(int(effect.count)):
				if not _rally_live_target(source) or source.get("_pending_destroy",false) or source.get("silenced",false) or source.get("abilities_disabled",false): break
				_force_single_attack(side,source,"start_combat_immediate_attack")
				if not _error.is_empty(): return
		elif effect_type == "start_combat_tribe_bonus":
			_combat_tribe_bonuses.activate(self, side, source, effect)
		elif effect_type == "start_combat_stats":
			StartCombatEffects.apply(self, side, source, effect, gadrin_plan)
		elif effect_type == "start_combat_hand_stats":
			_apply_start_hand_stats(side, source, effect)
		elif effect_type == "start_combat_multiply":
			if not _tick("start_combat"):
				return
			_multiply_stats(source, effect, "start_combat")
		elif effect_type == "start_combat_buff":
			if effect.get("require_no_friendly_shield",false):
				var any_shield: bool = false
				for friendly in _boards[side]:
					if int(friendly.health)>0 and _has_keyword(friendly,"divine_shield"): any_shield=true; break
				if any_shield: continue
			if not _tick("start_combat"):
				return
			var targets: Array = []
			var scope: String = str(effect["scope"])
			var start_source_index: int = _boards[side].find(source)
			for candidate in _boards[side]:
				if scope == "adjacent_friendly" and abs(_boards[side].find(candidate)-start_source_index)!=1: continue
				if not _tribe_matches(candidate, str(effect.get("tribe", ""))):
					continue
				if scope == "self" and int(candidate["_combat_id"]) != int(source["_combat_id"]):
					continue
				if scope in ["random_other", "all_other"] and int(candidate["_combat_id"]) == int(source["_combat_id"]):
					continue
				targets.append(candidate)
			if scope == "random_other" and not targets.is_empty():
				var selected_targets: Array = []
				for _selection in range(mini(int(effect.get("count", 1)), targets.size())):
					var ids: Array = []
					for target_unit in targets:
						ids.append(target_unit["uid"])
					var selected_index: int = _random_index(targets.size(), "start_combat_target", ids)
					selected_targets.append(targets[selected_index])
					targets.remove_at(selected_index)
				targets = selected_targets
			# One all-other action is atomic: preflight every target before stats or keywords.
			if scope == "all_other":
				for recipient in targets:
					if not StartCombatEffects.buff_fits(recipient, int(effect.get("attack", 0)), int(effect.get("health", 0))):
						_fail("Start-combat all-other buff exceeds the supported integer range")
						return
			for recipient in targets:
				_apply_trigger_buff(source, recipient, effect, "start_combat", str(source["uid"]))
				if effect.has("keyword") and not _has_keyword(recipient, str(effect["keyword"])):
					recipient["keywords"].append(str(effect["keyword"]))
					_emit("keyword_granted", {"source": source["uid"], "target": recipient["uid"], "keyword": effect["keyword"], "reason": "start_combat"})

		elif effect_type == "start_combat_adjacent_damage_buff":
			for shot in range(int(effect.shots)):
				if not _tick("start_combat_adjacent_damage_buff"): return
				var source_index: int = _boards[side].find(source)
				if source_index < 0: break
				var neighbors: Array = []
				var adjacent_packets: Array = []
				for index in [source_index-1,source_index+1]:
					if index>=0 and index<_boards[side].size():
						var recipient: Dictionary = _boards[side][index]
						if int(recipient.health)<=0: continue
						neighbors.append(recipient)
						adjacent_packets.append({"source":source,"target":recipient,"amount":int(effect.amount),"kind":"start_combat_adjacent_damage_buff"})
				if not adjacent_packets.is_empty(): _damage_batch(adjacent_packets)
				if not _error.is_empty(): return
				for recipient in neighbors:
					if int(recipient.health)>0 and not _find_unit(side,int(recipient._combat_id)).is_empty():
						_apply_trigger_buff(source,recipient,{"attack":int(effect.attack),"health":0},"start_combat_adjacent_damage_buff",str(source.uid))
						if not _error.is_empty(): return
				_emit("start_combat_adjacent_action",{"source":source.uid,"shot":shot+1,"shots":int(effect.shots),"damage":int(effect.amount),"attack":int(effect.attack)})
				_resolve_deaths()
				if not _error.is_empty(): return

		elif effect_type == "start_combat_damage":
			for shot in range(int(effect.get("shots", 1))):
				if not _tick("start_combat_damage"):
					return
				var amount: int = int(effect.get("amount", 0))
				if not own_attack_plan.is_empty():
					amount = int(own_attack_plan.amount)
				elif str(effect.get("amount_from", "")) == "count_tribe":
					amount = 0
					for friendly in _boards[side]:
						if int(friendly["health"]) > 0 and _tribe_matches(friendly, str(effect["tribe"])):
							amount += 1
				_emit("start_combat_damage", {"side": side, "source": source["uid"], "amount": amount, "shot": shot + 1, "shots": int(effect.get("shots", 1))})
				_deathrattle({"side": side, "unit": source}, {"type": "deathrattle_damage", "amount": amount, "target": effect["target"]}, shot + 1, "start_combat_damage_effect")
				_resolve_deaths()
				if not _error.is_empty():
					return
	var repeat_finish_issue: String=_start_repeat_host.finish(self)
	if not repeat_finish_issue.is_empty(): _fail(repeat_finish_issue)

func _multiply_stats(unit: Dictionary, effect: Dictionary, reason: String) -> void:
	if unit.has(VolatileVenomSources.MARK): _fail("volatile_venom_nonadditive_combat_layer_partial");return
	# All three fields are preflighted before any multiplicative write.
	for stat in ["attack", "health", "max_health"]:
		var multiplier: int = int(effect.get("attack" if stat == "attack" else "health", 1))
		if multiplier < 1 or int(unit[stat]) < 0 or int(unit[stat]) > MAX_STAT / multiplier:
			_fail("Combat stat multiplication exceeds the supported integer range")
			return
	var scalar_after: Dictionary=unit.duplicate(true)
	for field in ["attack","health","max_health"]: scalar_after[field]=int(unit[field])*int(effect.get("attack" if field=="attack" else "health",1))
	var loc_scalar: Dictionary=LocPrince.scalar(unit,scalar_after)
	if not loc_scalar.ok: _fail(str(loc_scalar.error));return
	scalar_after=loc_scalar.after
	var loc_scalar_context: String=LocPrince.combat_error(self,unit,int(scalar_after.attack)-int(unit.attack),int(scalar_after.max_health)-int(unit.max_health))
	if not loc_scalar_context.is_empty(): _fail(loc_scalar_context);return
	if _mishmash_stat_host!=null:
		var scalar_issue: String=_mishmash_stat_host.prepare_combat_transition(self,unit,scalar_after,"stat_multiply",reason)
		if not scalar_issue.is_empty(): _fail(scalar_issue);return
	unit.attack=int(scalar_after.attack);unit.health=int(scalar_after.health);unit.max_health=int(scalar_after.max_health)
	_loc_prince_host.capture(unit)
	_emit("stat_multiply", {"source": unit["uid"], "reason": reason, "attack": unit["attack"], "health": unit["health"], "max_health": unit["max_health"]})

func _tribe_matches(unit: Dictionary, tribe: String) -> bool:
	return tribe.is_empty() or tribe in ["all", "全部"] or tribe in unit.get("tribes", []) or "all" in unit.get("tribes", []) or "全部" in unit.get("tribes", [])

func _owner_rally_multiplier(side: int) -> int:
	var result: int=1
	for listener in _boards[side]:
		if int(listener.health)<=0 or listener.get("_pending_destroy",false) or listener.get("silenced",false) or listener.get("abilities_disabled",false): continue
		for effect in listener.get("effects",[]):
			if effect.get("type")=="rally_repeat": result=maxi(result,int(effect.multiplier))
	return result

func _deathrattle_repeats(side: int) -> int:
	var multiplier: int = _owner_deathrattle_sets[side]
	var extra: int = 0
	for listener in _boards[side]:
		if listener.get("card_id","") in ["BG34_Giant_376","BG34_Giant_376_G"] and (listener.get("_pending_destroy",false) or listener.get("silenced",false) or listener.get("abilities_disabled",false)): continue
		if int(listener["health"]) <= 0:
			continue
		for effect in listener["effects"]:
			if str(effect.get("type", "")) == "deathrattle_repeat":
				if str(effect.get("mode", "extra")) == "set":
					multiplier = maxi(multiplier, int(effect["multiplier"]))
				else:
					extra = mini(_max_steps, extra + mini(int(effect["extra"]), _max_steps))
	return mini(_max_steps + 1, multiplier + extra + ArgusSources.combat_extra(_options,side))

func _trigger_friendly_deaths(queue: Array) -> void:
	if not _bulk_resource_host._native_fixed_hand.enter_wave(self,queue): return
	for entry in queue:
		var dead: Dictionary = entry["unit"]
		for listener in _boards[int(entry["side"])]:
			if int(listener["health"]) <= 0:
				continue
			for effect_index in range(listener["effects"].size()):
				if int(listener["health"]) <= 0:
					break
				var effect: Dictionary = listener["effects"][effect_index]
				var effect_type: String = str(effect.get("type", ""))
				if effect_type==NativeGem.Sources.DEATH:
					if not _native_gem_host.friendly_death(self,listener,effect,entry): return
				elif GhoulDeath.effect_claimed(effect):
					if not GhoulDeath.listener(self,listener,entry): return
				elif effect_type == "on_friendly_death":
					_trigger_friendly_death_action(listener, entry, effect, effect_index)
					if not _error.is_empty():
						return
				elif effect_type == "on_friendly_death_buff" and _tribe_matches(dead, str(effect.get("tribe", ""))):
					_apply_trigger_buff(listener, listener, effect, "friendly_death", str(dead["uid"]))
				elif effect_type == "on_friendly_death_damage" and _tribe_matches(dead, str(effect.get("tribe", ""))):
					for _shot in range(int(effect.get("shots", 1))):
						if not _tick("friendly_death_damage"):
							return
						var nested: Dictionary = {"type": "deathrattle_damage", "amount": int(effect["amount"]), "target": str(effect["target"])}
						_deathrattle({"side": entry["side"], "unit": listener, "repeats": 1}, nested, _shot + 1, "friendly_death_damage")
				elif effect_type == "avenge":
					if KerriganZerg.Sources.claimed(listener) and not KerriganZerg.active(self,int(entry.side),listener): continue
					if MetalDispenser.Sources.claimed(listener) and not MetalDispenser.Gains.active(listener): continue
					if listener.get("card_id") in BulkResourceHost.RandomSpellAvengeHand.Sources.IDS and (listener.get("silenced",false) or listener.get("abilities_disabled",false) or listener.get("_pending_destroy",false)): continue
					if listener.get("card_id") in BulkResourceHost.FixedEvents.AVENGE_IDS and (listener.get("silenced",false) or listener.get("abilities_disabled",false) or listener.get("_pending_destroy",false)): continue
					if (LinkedUndead.Sources.claimed(listener) or NextTurnShopSources.claimed(listener) or PastryAvenge.claimed(listener)) and (listener.get("silenced",false) or listener.get("abilities_disabled",false) or listener.get("_pending_destroy",false)): continue
					if listener.get("card_id") in ["BG31_HERO_802pt1","BG31_HERO_802pt1_G","BG31_HERO_802pt7","BG31_HERO_802pt7_G"] and not Protoss.active(self,int(entry.side),listener): continue
					if BulkResourceHost.FiniteAvenge.claimed(listener) and (listener.get("silenced",false) or listener.get("abilities_disabled",false) or listener.get("_pending_destroy",false)): continue
					if AvengePoison.Sources.claimed(listener) and not AvengePoison.Gains.active(listener): continue
					if CombatGemTriggers.Sources.claimed(listener) and not CombatGemTriggers.Gains.active(listener): continue
					if HandBoard.Sources.claimed(listener) and not HandBoard.Gains.active(listener): continue
					if listener.get("card_id") in NativeGem.Sources.AVENGE_IDS and not NativeGem.Gains.active(listener): continue
					if ShieldTaunt.claimed(listener) and (listener.get("silenced",false) or listener.get("abilities_disabled",false) or listener.get("_pending_destroy",false)): continue
					if SilithidSources.claimed(listener) and (listener.get("silenced",false) or listener.get("abilities_disabled",false) or listener.get("_pending_destroy",false)): continue
					if listener.get("card_id") in EachTypePermanent.AVENGE_IDS and (listener.get("silenced",false) or listener.get("abilities_disabled",false)): continue
					if listener.get("card_id") in CombatPlainSources.AVENGE_IDS and (listener.get("silenced",false) or listener.get("abilities_disabled",false)): continue
					if NativeRecruit.Primus.claimed(listener):
						if NativeRecruit.Primus.inactive(listener): continue
						var primus_issue: String = NativeRecruit.Primus.combat_call_error(listener,effect.get("effect",{}),int(entry.side),_boards,_options.get("hand_card_templates",{}),"avenge_effect")
						if not primus_issue.is_empty(): _fail(primus_issue); return
					var counter_key: String = str(effect_index)
					var threshold: int = int(effect["count"])
					var progress: int = int(listener["_avenge_counters"].get(counter_key, 0)) + 1
					if listener.get("card_id") in BulkResourceHost.FixedEvents.AVENGE_IDS:
						if not _bulk_resource_host._fixed_hand.avenge(self,int(entry.side),listener,effect,dead,effect_index,progress): return
					if listener.get("card_id") in BulkResourceHost.RandomSpellAvengeHand.Sources.IDS:
						if not _bulk_resource_host._random_spell_avenge_hand.avenge(self,listener,entry,effect,effect_index,progress): return
					listener["_avenge_counters"][counter_key] = progress
					var progress_event: Dictionary = {"source": listener["uid"], "dead": dead["uid"], "progress": progress, "threshold": threshold}
					var recycler: bool = CombatEconomy.Sources.avenge_identity(listener.get("card_id",listener.get("id"))) or CorpseSale.Sources.accepts_id(listener.get("card_id",listener.get("id")))
					if recycler:
						progress_event.merge({"side":entry.side,"source_id":listener.get("card_id",listener.get("id")),"effect_index":effect_index})
					_emit("avenge_progress", progress_event)
					if progress >= threshold:
						listener["_avenge_counters"][counter_key] = progress - threshold
						if not _tick("avenge"):
							return
						var avenge_event: Dictionary = {"source": listener["uid"], "effect": effect["effect"].get("type", ""), "remaining": progress - threshold}
						if recycler:
							avenge_event.merge({"side":entry.side,"source_id":listener.get("card_id",listener.get("id")),"effect_index":effect_index})
						_emit("avenge", avenge_event)
						var actual_avenge_entry: Dictionary={"side":entry["side"],"unit":listener,"repeats":1}
						if MetalDispenser.Sources.claimed(listener) or LinkedUndead.Sources.claimed(listener) or NextTurnShopSources.claimed(listener) or PastryAvenge.claimed(listener) or SilithidSources.claimed(listener) or HandBoard.Sources.claimed(listener) or CombatGemTriggers.Sources.claimed(listener) or AvengePoison.Sources.claimed(listener) or Tony.Sources.claimed(listener): actual_avenge_entry.merge({"actual_death_sequence":entry.get("milestone_death_sequence",-1),"actual_dead_uid":dead.uid})
						_deathrattle(actual_avenge_entry,effect["effect"],1,"avenge_effect")
						if not _error.is_empty(): return

		_bomb_squad_death_context={"entry":entry,"queue":queue,"used":false}
		var bomb_squad_death_issue: String=_bomb_squad_host.removed(self,entry)
		_bomb_squad_death_context={}
		if not bomb_squad_death_issue.is_empty(): _fail(bomb_squad_death_issue);return
		_energy_recycling_death_context={"entry":entry,"queue":queue,"used":false}
		var energy_death_issue: String=_energy_recycling_host.removed(self,entry)
		_energy_recycling_death_context={}
		if not energy_death_issue.is_empty(): _fail(energy_death_issue);return
		_grim_freshener_death_context={"entry":entry,"queue":queue,"used":false}
		var grim_freshener_death_issue: String=_grim_freshener_host.removed(self,entry)
		_grim_freshener_death_context={}
		if not grim_freshener_death_issue.is_empty(): _fail(grim_freshener_death_issue);return
		_victim_specter_death_context={"entry":entry,"queue":queue,"used":false}
		var victim_specter_death_issue: String=_victim_specter_host.removed(self,entry)
		_victim_specter_death_context={}
		if not victim_specter_death_issue.is_empty(): _fail(victim_specter_death_issue);return
		_ritual_dagger_death_context={"entry":entry,"queue":queue,"used":false}
		var ritual_dagger_death_issue: String=_ritual_dagger_host.removed(self,entry)
		_ritual_dagger_death_context={}
		if not ritual_dagger_death_issue.is_empty(): _fail(ritual_dagger_death_issue);return
		if _owned_avenge_host!=null and not _owned_avenge_host.removed(self,entry): return
		if not _scourge_staff_host.removed(self,entry): return
		if not _cloud_serpent_horn_host.removed(self,entry): return
		if not _quilligraphy_host.removed(self,entry): return
		if not _wicked_tome_host.removed(self,entry): return
		if not _kill_reward_host._thorned_rose_host.removed(self,_kill_reward_host,entry): return
		if not _kill_reward_host._battle_horn_host.removed(self,_kill_reward_host,entry): return
		if _raptor_avenge_host!=null and not _raptor_avenge_host.removed(self,entry): return
		if not _gem_golem_host.removed(self,entry): return

		# Opposite-side observation is Ghoul-only; never replay old friendly listeners.
		for listener in _boards[1-int(entry.side)]:
			if GhoulDeath.claimed(listener):
				if not GhoulDeath.listener(self,listener,entry): return

	_bulk_resource_host._native_fixed_hand.leave_wave(self,queue)

func _trigger_friendly_death_action(listener: Dictionary, entry: Dictionary, effect: Dictionary, effect_index: int) -> void:
	var dead: Dictionary = entry["unit"]
	if listener.get("card_id") in BulkResourceHost.NativeFixedHand.Native.FRIENDLY_IDS and (listener.get("silenced",false) or listener.get("abilities_disabled",false) or listener.get("_pending_destroy",false)): return
	if not _tribe_matches(dead, str(effect.get("tribe", ""))):
		return
	if bool(effect.get("exclude_self", false)) and int(listener["_combat_id"]) == int(dead["_combat_id"]):
		return
	if effect.has("require_keyword") and not _has_keyword(dead, str(effect["require_keyword"])):
		return
	if bool(effect.get("require_deathrattle", false)):
		var has_deathrattle: bool = RecurringNightmare.Sources.has_active(dead) or StartGrantSources.has_active(dead) or PiggyBank.Sources.has_active(dead) or FishGroups.has_active(dead) or TempDeath.has_active(dead) or MegaGrants.has_active(dead) or TamsinGrant.has_active(dead) or BrukanGrant.has_active(dead) or not DarkGiftResources.Sources.resource_effects(dead).is_empty()
		for dead_effect in dead["effects"]:
			var dead_type: String = str(dead_effect.get("type", ""))
			if dead_type.begins_with("deathrattle_") and dead_type != "deathrattle_repeat":
				has_deathrattle = true
				break
		if not has_deathrattle:
			return
	var counter_key: String = str(effect_index)
	var used: int = int(listener["_friendly_death_used"].get(counter_key, 0))
	if effect.has("limit") and used >= int(effect["limit"]):
		return
	if listener.get("card_id") in BulkResourceHost.NativeFixedHand.Native.FRIENDLY_IDS:
		if not _bulk_resource_host._native_fixed_hand.friendly_death(self,listener,entry,effect,effect_index,used): return
	listener["_friendly_death_used"][counter_key] = used + 1
	var action: Dictionary = effect["effect"]
	var side: int = int(entry["side"])
	# The corpse's stats/geometry were snapshotted before the entire death wave
	# was removed. No later listener buff, summon or repetition can change them.
	var attack_delta: int = int(entry["dead_attack"]) if action.has("attack_from") else int(action.get("attack", 0))
	var health_delta: int = int(entry["dead_max_health"]) if action.has("health_from") else int(action.get("health", 0))
	var times: int = int(effect.get("times", 1))
	for repetition in range(mini(times, _max_steps + 1)):
		if not _tick("friendly_death_trigger"):
			return
		_emit("friendly_death_trigger", {"side": side, "source": listener["uid"], "dead": dead["uid"], "effect": action["type"], "effect_index": effect_index, "activation": used + 1, "repetition": repetition + 1, "total_repetitions": times})
		if action["type"] == DelayedGold.FRIENDLY_DEATH_TYPE:
			# This is a surviving friendly-death listener, never a Deathrattle dispatch.
			var context: Dictionary = _options.delayed_gold_context
			var queued: Dictionary = DelayedGold.build_event(context.owners[side],str(listener.get("card_id",listener.get("id",""))),listener.uid,action,context.round,context.transaction_id,_log.size(),"combat",side)
			if not queued.ok:
				_fail(str(queued.error))
				return
			_emit(DelayedGold.EVENT,queued.event)
			continue
		if action["type"] == "add_card":
			if listener.get("card_id") in BulkResourceHost.NativeFixedHand.Native.FRIENDLY_IDS: _bulk_resource_host._native_fixed_hand.execute(self,side,listener,action)
			else: _queue_card_reward(side, listener, str(action["card_id"]), int(action.get("count", 1)))
			if not _error.is_empty():
				return
			continue
		var recipients: Array = []
		for friendly in _boards[side]:
			if int(friendly["health"]) <= 0:
				continue
			match str(action["scope"]):
				"self":
					if int(friendly["_combat_id"]) != int(listener["_combat_id"]):
						continue
				"dead_neighbors":
					if not int(friendly["_combat_id"]) in entry["neighbors"]:
						continue
			recipients.append(friendly)
		for recipient in recipients:
			_apply_trigger_buff(listener, recipient, {"attack": attack_delta, "health": health_delta}, "friendly_death_action", str(dead["uid"]))
			if bool(action.get("permanent", false)):
				_emit("persistent_buff", {"type": "persistent_buff", "side": side, "source": listener["uid"], "target_uid": recipient["uid"], "attack_delta": attack_delta, "health_delta": health_delta})

func _trigger_friendly_summon(summoned: Dictionary, listeners: Array, insertion: Dictionary = {}) -> void:
	for listener in listeners:
		if int(listener["health"]) <= 0:
			continue
		for effect_index in range(listener["effects"].size()):
			if int(listener["health"]) <= 0 or int(summoned["health"]) <= 0:
				break
			var effect: Dictionary = listener["effects"][effect_index]
			if str(effect.get("type", "")) == Leviathan.Sources.TYPE:
				if not _leviathan_host.observe(self,listener,summoned,insertion): return
				continue
			if str(effect.get("type", "")) == ValithriaEntry.Sources.TYPE:
				if not ValithriaEntry.combat(self,listener,summoned,insertion): return
				continue
			if str(effect.get("type", "")) == WhelpSummon.Sources.TYPE:
				if not _whelp_summon_host.combat(self,listener,summoned,insertion): return
				continue
			if str(effect.get("type", "")) == RebornGrants.TYPE:
				if not _reborn_grant_host.combat_listener(self,listener,summoned,insertion): return
				continue
			if str(effect.get("type", "")) == SummonAttempt.TYPE:
				if not _summon_attempt_host.combat_listener(self,listener,summoned,insertion): return
				continue
			if str(effect.get("type", "")) in [SummonPermanent.TYPE,SummonPermanent.CONDITIONAL_TYPE]:
				if not _summon_permanent_host.combat_listener(self,listener,summoned,insertion): return
				continue
			if str(effect.get("type", "")) == "on_friendly_summon":
				_trigger_friendly_summon_action(listener, summoned, effect, effect_index)
				if not _error.is_empty():
					return
			if str(effect.get("type", "")) == "on_friendly_summon_buff" and _tribe_matches(summoned, str(effect.get("tribe", ""))):
				if listener.get("card_id","")=="BG_GVG_062" and (listener.get("silenced",false) or listener.get("abilities_disabled",false) or listener.get("_pending_destroy",false)): continue
				var recipient: Dictionary = listener if str(effect["scope"]) == "self" else summoned
				if str(effect["scope"]) == "random_other":
					var candidates: Array = []
					var ids: Array = []
					for friendly in _boards[int(summoned["_side"])]:
						if int(friendly["health"]) > 0 and int(friendly["_combat_id"]) != int(summoned["_combat_id"]) and _tribe_matches(friendly, str(effect.get("tribe", ""))):
							candidates.append(friendly)
							ids.append(friendly["uid"])
					if candidates.is_empty():
						continue
					recipient = candidates[_random_index(candidates.size(), "friendly_summon_buff_target", ids)]
				_apply_trigger_buff(listener, recipient, effect, "friendly_summon", str(summoned["uid"]))
				if effect.has("keyword") and not _has_keyword(recipient, str(effect["keyword"])):
					recipient["keywords"].append(str(effect["keyword"]))
					_emit("keyword_granted", {"source": listener["uid"], "target": recipient["uid"], "keyword": effect["keyword"], "reason": "friendly_summon", "trigger_unit": summoned["uid"]})


func _trigger_friendly_summon_action(listener: Dictionary, summoned: Dictionary, effect: Dictionary, effect_index: int) -> void:
	if not _tribe_matches(summoned, str(effect.get("tribe", ""))):
		return
	var counter_key: String = str(effect_index)
	var used: int = int(listener["_friendly_summon_used"].get(counter_key, 0))
	if effect.has("limit") and used >= int(effect["limit"]):
		return
	if not _tick("friendly_summon_trigger"):
		return
	listener["_friendly_summon_used"][counter_key] = used + 1
	var action: Dictionary = effect["effect"]
	var side: int = int(listener["_side"])
	_emit("summon_trigger", {"side": side, "source": listener["uid"], "summoned": summoned["uid"], "effect": action["type"], "effect_index": effect_index, "activation": used + 1})
	if action["type"] == "multiply":
		_multiply_stats(summoned, {"attack": int(action["attack"]),"health":int(action.get("health",1))}, "friendly_summon")
		return
	# Dynamic stats are captured at this listener's activation, after preceding
	# left-to-right listeners. One snapshot supplies every recipient of the action.
	var attack_delta: int = _summon_action_stat(action, "attack", listener, summoned)
	var health_delta: int = _summon_action_stat(action, "health", listener, summoned)
	if not _error.is_empty(): return
	var recipients: Array = []
	var scope: String = str(action["scope"])
	for friendly in _boards[side]:
		if int(friendly["health"]) <= 0 or not _tribe_matches(friendly, str(action.get("tribe", ""))):
			continue
		if scope == "self" and int(friendly["_combat_id"]) != int(listener["_combat_id"]):
			continue
		if scope == "summoned" and int(friendly["_combat_id"]) != int(summoned["_combat_id"]):
			continue
		recipients.append(friendly)
	if scope == "rightmost_friendly" and not recipients.is_empty():
		recipients = [recipients[-1]]
	for recipient in recipients:
		_apply_trigger_buff(listener, recipient, {"attack": attack_delta, "health": health_delta}, "friendly_summon_action", str(summoned["uid"]))
		if not _error.is_empty(): return
		if bool(action.get("permanent", false)):
			_emit("persistent_buff", {"type": "persistent_buff", "side": side, "source": listener["uid"], "target_uid": recipient["uid"], "attack_delta": attack_delta, "health_delta": health_delta})

func _summon_action_stat(action: Dictionary, stat: String, source: Dictionary, summoned: Dictionary) -> int:
	var value: int = int(action.get(stat, 0))
	match str(action.get(stat + "_from", "")):
		"source_attack": value = int(source["attack"])
		"source_max_health": value = int(source["max_health"])
		"summoned_attack": value = int(summoned["attack"])
		"summoned_health": value = int(summoned["health"])
	var factor: int=int(action.get(stat + "_multiplier", 1))
	if factor<1 or value<0 or value>MAX_STAT/factor:
		_fail("Friendly summon dynamic stat exceeds the supported integer range")
		return 0
	return value * factor

func permanent_tribe_context_error(left: Array, right: Array, options: Dictionary = {}) -> String:
	return PermanentTribeEffects.context_error(left, right, options)

func hand_context_error(left: Array, right: Array, options: Dictionary = {}) -> String:
	# Public pure preflight for Game/pool capability gates. No RNG or mutation.
	return CombatHand.context_error(left, right, options)

func _apply_start_hand_stats(side: int, source: Dictionary, effect: Dictionary) -> void:
	for _repetition in range(int(effect.get("repeats", 1))):
		if not _tick("start_combat_hand_stats"):
			return
		var amount: Dictionary = _combat_hand.stats(side, str(effect["mode"]), int(effect.get("multiplier", 1)))
		if not str(amount["error"]).is_empty():
			_fail(str(amount["error"]))
			return
		var targets: Array = []
		if effect["scope"] == "self":
			targets.append(source)
		else:
			var index: int = _boards[side].find(source)
			for neighbor in [index - 1, index + 1]:
				if neighbor >= 0 and neighbor < _boards[side].size():
					var candidate: Dictionary = _boards[side][neighbor]
					if int(candidate["health"]) > 0 and _tribe_matches(candidate, str(effect.get("tribe", ""))):
						targets.append(candidate)
		# Do not wrap or clamp unsupported large stats, or half-apply one trigger.
		for recipient in targets:
			if not CombatHand.buff_fits(recipient, int(amount["attack"]), int(amount["health"])):
				_fail("Combat hand board buff exceeds the supported integer range")
				return
		for recipient in targets:
			_apply_trigger_buff(source, recipient, amount, "start_combat_hand_stats", str(source["uid"]))

func _activate_received_gem_economy(side: int, source: Dictionary, effect: Dictionary) -> void:
	if not _options.get("delayed_gold_context") is Dictionary:
		_fail("Received Gem bonus requires actual owner and transaction context"); return
	var issued: Dictionary = CombatEconomy.build_event(_options.delayed_gold_context,side,source,effect,_log.size(),DamageResource.Extra.TRIGGER,_options.get("hand_card_templates",{}))
	if not issued.ok: _fail(str(issued.error)); return
	_emit(CombatEconomy.EVENT,issued.event)

# Genuine producer boundary shared by existing hand writers. Preparing a
# projection or emitting hand_buff alone cannot issue an actual-gain receipt.
func _commit_native_hand_stats(side: int,subject: Dictionary,after: Dictionary) -> bool:
	var prepared: Dictionary=_master_realities_host.prepare_combat_hand(self,side,subject,after)
	if not prepared.ok: _fail(str(prepared.error));return false
	subject.clear();subject.merge(after.duplicate(true),true)
	var issue: String=_master_realities_host.capture_combat_hand(self,subject,prepared)
	if not issue.is_empty(): _fail(issue);return false
	return true

func _apply_hand_buff(side: int, source: Dictionary, effect: Dictionary, repetition: int, reason: String = "deathrattle_hand_buff_target") -> void:
	var candidates: Array = _combat_hand.minions(side)
	if candidates.is_empty():
		return
	var ids: Array = []
	for card in candidates:
		ids.append(CombatHand.target_reference(card))
	var recipient: Dictionary = candidates[_random_index(candidates.size(), reason, ids)]
	var attack_delta: int = int(effect["attack"])
	var health_delta: int = int(effect["health"])
	var ditch_guardian_hand_vector: Dictionary=_ditch_guardian_host.combat_vector(self,recipient,attack_delta,health_delta,source,side)
	if not ditch_guardian_hand_vector.ok: _fail(str(ditch_guardian_hand_vector.error));return
	attack_delta=int(ditch_guardian_hand_vector.attack);health_delta=int(ditch_guardian_hand_vector.health)
	var enhanced_spawn_hand_vector: Dictionary=_enhanced_spawn_host.combat_vector(self,recipient,attack_delta,health_delta,source,side)
	if not enhanced_spawn_hand_vector.ok: _fail(str(enhanced_spawn_hand_vector.error));return
	attack_delta=int(enhanced_spawn_hand_vector.attack);health_delta=int(enhanced_spawn_hand_vector.health)
	var radiant_ember_hand_vector: Dictionary=_radiant_ember_host.combat_vector(self,recipient,attack_delta,health_delta,source,side)
	if not radiant_ember_hand_vector.ok: _fail(str(radiant_ember_hand_vector.error));return
	attack_delta=int(radiant_ember_hand_vector.attack);health_delta=int(radiant_ember_hand_vector.health)
	var pen_hand_vector: Dictionary=WaterloggedPen.combat_vector(self,recipient,attack_delta,health_delta,source,side)
	if not pen_hand_vector.ok: _fail(str(pen_hand_vector.error));return
	attack_delta=int(pen_hand_vector.attack);health_delta=int(pen_hand_vector.health)
	var seaside_hand_vector: Dictionary=Seaside.combat_vector(self,recipient,attack_delta,health_delta,source,side)
	if not seaside_hand_vector.ok: _fail(str(seaside_hand_vector.error));return
	attack_delta=int(seaside_hand_vector.attack);health_delta=int(seaside_hand_vector.health)
	var native_hand_after: Dictionary=recipient.duplicate(true)
	if LocPrince.Sources.claimed(recipient):
		var hand_owner: int=int(_options.get("left_global_card_state" if side==0 else "right_global_card_state",{}).get("id",-1))
		var native_hand_plan: Dictionary=KillRewards.KillHand.adjust_copy(recipient,hand_owner,attack_delta,health_delta,_options.has(DamageListenerHost.CONTEXT))
		if not str(native_hand_plan.error).is_empty(): _fail(str(native_hand_plan.error));return
		native_hand_after=native_hand_plan.after
	else:
		if not CombatHand.buff_fits(recipient,attack_delta,health_delta): _fail("Combat hand permanent buff exceeds the supported integer range");return
		native_hand_after.attack=int(recipient.attack)+attack_delta
		native_hand_after.health=int(recipient.health)+health_delta
		native_hand_after.max_health=int(recipient.max_health)+health_delta
	if not _commit_native_hand_stats(side,recipient,native_hand_after): return
	var payload: Dictionary = {"type": "hand_buff", "side": side, "source": source["uid"], "attack_delta": attack_delta, "health_delta": health_delta, "attack": recipient["attack"], "health": recipient["health"], "max_health": recipient["max_health"], "permanent": true, "repetition": repetition}
	if recipient.get("generated", false):
		payload["reward_sequence"] = recipient["reward_sequence"]
		payload["reward_index"] = recipient["reward_index"]
	else:
		payload["target_uid"] = recipient["uid"]
	_emit("hand_buff", payload)

func _needs_hand_context(unit: Dictionary) -> bool:
	for effect in unit.get("effects", []):
		if str(effect.get("type", "")) in ["on_hand_added_buff",NativeRecruit.Thorn.TYPE,NativeRecruit.DeviousDrust.TYPE]:
			return true
		if str(effect.get("type", "")) == "deathrattle_summon" and effect.get("unit", null) is Dictionary and _needs_hand_context(effect["unit"]):
			return true
		if str(effect.get("type", "")) == "rally" and str(effect.get("effect", {}).get("type", "")) == "summon" and _needs_hand_context(effect["effect"]["unit"]):
			return true
	return unit.has("base_unit") and _needs_hand_context(unit["base_unit"])

func _queue_card_reward(side: int, source: Dictionary, card_id: String, count: int, resource_metadata: Dictionary = {}) -> void:
	if resource_metadata.get("resource_family")==BulkResourceHost.FAMILY and not resource_metadata.has("resource_special_policy") and _bulk_resource_host!=null and _bulk_resource_host._context.get("cards",{}).has(card_id):
		var resource_selection_issue: String=_bulk_resource_host.selected_combat_error(card_id) if _bulk_resource_host!=null else "random_resource_missing_selected_context"
		if not resource_selection_issue.is_empty(): _fail(resource_selection_issue);return
	var crystal_reward_issue: String = NativeRecruit.Crystal.combat_reward_error(source,card_id,count,_options.get("hand_card_templates",{}))
	if not crystal_reward_issue.is_empty():
		_fail(crystal_reward_issue)
		return
	var accepted: int = mini(count, maxi(0, 10 - _hand_counts[side]))
	var deathhead_reward_issue: String=Deathhead.combat_reward_error(self,side,card_id,accepted)
	if not deathhead_reward_issue.is_empty(): _fail(deathhead_reward_issue);return
	var deity_hand_reward_issue: String=DeityHandGain.combat_reward_error(self,side,accepted)
	if not deity_hand_reward_issue.is_empty(): _fail(deity_hand_reward_issue);return
	var native_hand_reward_issue: String=HandAcquisition.combat_acquisition_error(self,side,card_id,accepted)
	if not native_hand_reward_issue.is_empty(): _fail(native_hand_reward_issue);return
	var pirate_quota_issue: String=TradeQuotas.combat_acquisition_error(self,side,card_id,accepted)
	if not pirate_quota_issue.is_empty(): _fail(pirate_quota_issue);return
	var templates: Dictionary = _options.get("hand_card_templates", {}).duplicate(true)
	if resource_metadata.get("lockbox_open_reward",false):
		var lockbox_template: Dictionary=_lockbox_host.reward_template(side,source,card_id,count,resource_metadata)
		if lockbox_template.is_empty(): _fail("lockbox_unbound_golden_reward_template");return
		templates[card_id]=lockbox_template
	elif resource_metadata.has(RadioStar.FIELD):
		var radio_template: Dictionary=_radio_star_host.reward_template(side,source,card_id,count,resource_metadata)
		if radio_template.is_empty(): _fail("radio_star_unbound_private_template");return
		templates[card_id]=radio_template
	elif resource_metadata.has(MetalDispenser.FIELD):
		var metal_template: Dictionary=_metal_dispenser_host.reward_template(side,source,card_id,count,resource_metadata)
		if metal_template.is_empty(): _fail("metal_dispenser_unbound_private_template");return
		templates[card_id]=metal_template
	elif resource_metadata.has(Pagle.FIELD):
		var pagle_template: Dictionary=_kill_reward_host._pagle_host.reward_template(side,source,card_id,count,resource_metadata) if _kill_reward_host!=null else {}
		if pagle_template.is_empty(): _fail("pagle_triple_unbound_actual_reward");return
		templates[card_id]=pagle_template
	elif card_id==LohRewards.Sources.REWARD or resource_metadata.has("triple_hero_family"):
		var triple_template: Dictionary=_loh_reward_host.reward_template(side,source,card_id,count,resource_metadata) if _loh_reward_host!=null else {}
		if triple_template.is_empty(): _fail("loh_unbound_actual_reward");return
		templates[card_id]=triple_template
	# Materialize only a private reward template, before mutating the local hand
	# or notifying hand-add listeners. The immutable catalog/options stay raw.
	if accepted > 0 and _combat_hand.available[side] and templates.has(card_id):
		var global_reward_issue: String = GlobalCards.combat_project(self,side,templates[card_id],"hand")
		if not global_reward_issue.is_empty(): _fail(global_reward_issue); return
		if not _permanent_tribe_effects.apply_to_summon(self, side, templates[card_id]):
			return
	var crowbar_reward_ticket: Dictionary=_crowbar_host.prepare_reward(self,side,card_id,accepted,templates)
	if not crowbar_reward_ticket.ok: _fail(str(crowbar_reward_ticket.error));return
	_hand_counts[side] += accepted
	_combat_hand.record_generation(side, card_id, accepted, _log.size(), _options.get("hand_card_kinds", {}), templates)
	var reward_payload: Dictionary = {"type": "recruit_add_card", "side": side, "source": source["uid"], "card_id": card_id, "count": count, "accepted_count": accepted, "burned_count": count - accepted}
	reward_payload.merge(resource_metadata,false)
	if resource_metadata.get("resource_protected",false): reward_payload.burned_count=0;reward_payload.queued_count=count-accepted
	var loh_reward_sequence: int=_log.size()
	_emit("recruit_add_card", reward_payload)
	var crowbar_reward_issue: String=_crowbar_host.commit_reward(self,crowbar_reward_ticket,_log[loh_reward_sequence])
	if not crowbar_reward_issue.is_empty(): _fail(crowbar_reward_issue);return
	if resource_metadata.has(RadioStar.FIELD) and not _radio_star_host.record_reward(self,_log[loh_reward_sequence]): return
	if resource_metadata.has(MetalDispenser.FIELD) and not _metal_dispenser_host.record_reward(self,_log[loh_reward_sequence]): return
	if resource_metadata.has("linked_undead_trigger") and not _linked_undead_host.generated(self,source,_log[loh_reward_sequence]): return
	if resource_metadata.has(Pagle.FIELD) and not _kill_reward_host._pagle_host.record_reward(self,_log[loh_reward_sequence]): return
	if resource_metadata.has("triple_hero_family") and not _loh_reward_host.record_reward(self,_log[loh_reward_sequence]): return
	# Keep requested count for the outer hand-limit/overflow log dispatcher,
	# but only cards that actually fit can trigger combat-local Peggy buffs.
	for _card in range(accepted):
		for listener in _boards[side].duplicate():
			if NativeRecruit.Thorn.claimed(listener):
				_apply_thorncaptain(side,listener,card_id)
				if not _error.is_empty(): return
				continue
			if NativeRecruit.Peggy.claimed(listener):
				_apply_timewarped_peggy(side,listener,card_id)
				if not _error.is_empty(): return
				continue
			if NativeRecruit.DeviousDrust.claimed(listener):
				_apply_devious_drust(side,listener,card_id)
				if not _error.is_empty(): return
				continue
			if int(listener["health"]) <= 0:
				continue
			for effect in listener["effects"]:
				if str(effect.get("type", "")) != "on_hand_added_buff":
					continue
				var candidates: Array = []
				var ids: Array = []
				for friendly in _boards[side]:
					if int(friendly["health"]) > 0 and int(friendly["_combat_id"]) != int(listener["_combat_id"]) and _tribe_matches(friendly, str(effect.get("tribe", ""))):
						candidates.append(friendly)
						ids.append(friendly["uid"])
				if candidates.is_empty():
					continue
				if not _tick("hand_added_trigger"):
					return
				var recipient: Dictionary = candidates[_random_index(candidates.size(), "hand_added_pirate_buff", ids)]
				_apply_trigger_buff(listener, recipient, effect, "hand_added", card_id)
	if accepted>0 and _error.is_empty(): _deferred_hand_host.pump(self,"hand_generation")

# Preserve one accepted-addition/source group at a time. No new acquisition,
# permanence event, reward ticket, RNG selection, or original-hand inheritance.
func _apply_thorncaptain(side: int, source: Dictionary, card_id: String) -> void:
	var plan: Dictionary = NativeRecruit.Thorn.combat_plan(self,side,source)
	if not str(plan.error).is_empty(): _fail(str(plan.error)); return
	if plan.recipients.is_empty(): return
	if not _tick("hand_added_trigger"): return
	# Existing absolute replay event; no recruit ledger or permanence receipt.
	_apply_trigger_buff(source,source,plan.effects[0],"hand_added",card_id)

func _apply_timewarped_peggy(side: int, source: Dictionary, card_id: String) -> void:
	var plan: Dictionary = NativeRecruit.Peggy.combat_plan(self,side,source)
	if not str(plan.error).is_empty(): _fail(str(plan.error)); return
	if plan.recipients.is_empty(): return
	# Reserve the existing group tick budget before the first recipient write.
	if _steps > _max_steps-plan.effects.size():
		_fail("Combat iteration limit exceeded during Timewarped Peggy source groups; no winner declared")
		return
	for effect in plan.effects:
		if not _tick("hand_added_trigger"): return
		for recipient in plan.recipients:
			_apply_trigger_buff(source,recipient,effect,"hand_added",card_id)
			if not _error.is_empty(): return

# One accepted typed receipt, one native source group, independently golden targets.
# Numeric/identity/side preflight and the single group tick precede every write.
func _apply_devious_drust(side: int, source: Dictionary, card_id: String) -> void:
	var plan: Dictionary = NativeRecruit.DeviousDrust.combat_plan(self,side,source,card_id)
	if not str(plan.error).is_empty(): _fail(str(plan.error)); return
	if plan.recipients.is_empty(): return
	if _steps >= _max_steps:
		_fail("Combat iteration limit exceeded during Devious Drust source group; no winner declared")
		return
	if not _tick("hand_added_trigger"): return
	for adjustment in plan.adjustments:
		_apply_trigger_buff(source,adjustment.recipient,{"attack":adjustment.attack,"health":adjustment.health},"hand_added",card_id)
		if not _error.is_empty(): return

func _apply_trigger_buff(source: Dictionary, recipient: Dictionary, effect: Dictionary, reason: String, trigger_unit: String) -> void:
	if not _adjust_board_stats(recipient,int(effect.get("attack",0)),int(effect.get("health",0)),source): return
	_emit("trigger_buff", {"source": source["uid"], "target": recipient["uid"], "reason": reason, "trigger_unit": trigger_unit, "attack": recipient["attack"], "health": recipient["health"], "max_health": recipient["max_health"]})

func _tick(context: String) -> bool:
	_steps += 1
	if _steps > _max_steps:
		_fail("Combat iteration limit exceeded (%d) during %s; no winner declared" % [_max_steps, context])
		return false
	return true

func _emit(event: String, payload: Dictionary) -> void:
	if _loc_prince_host!=null and _error.is_empty():
		var loc_event_issue: String=LocPrince.annotate_hand(self,payload) if event=="hand_buff" else _loc_prince_host.observe(self,event,payload)
		if not loc_event_issue.is_empty(): _fail(loc_event_issue);return
	if _brinescale_host!=null and _error.is_empty():
		var brinescale_issue: String=_brinescale_host.consume_scalar(self,event,payload)
		if not brinescale_issue.is_empty(): _fail(brinescale_issue);return
	if _hand_murloc_gain_host!=null and _error.is_empty():
		var hand_murloc_issue: String=_hand_murloc_gain_host.consume_scalar(self,event,payload)
		if not hand_murloc_issue.is_empty(): _fail(hand_murloc_issue);return
	if _deity_host!=null: _deity_host.observe(event,payload)
	var record: Dictionary = payload.duplicate(true)
	if _options.has(DamageListenerHost.CONTEXT):
		if event == "combat_start":
			record.damage_listener_instances=[]
			for side in range(2):
				for unit in _boards[side]: record.damage_listener_instances.append({"uid":unit.uid,"side":side,"combat_id":unit._combat_id,"card_id":unit.card_id})
		elif event in ["damage","shield_lost","immune_blocked"]:
			record.damage_listener_packet=_damage_listener_packet.duplicate(true)
		elif event == "summon":
			for unit in _boards[int(payload.side)]:
				if unit.uid == payload.unit.uid: record.damage_listener_combat_id=unit._combat_id; break
	if event in ["buff", "trigger_buff", "stat_set", "stat_multiply", "permanent_tribe_view"] and (event != "permanent_tribe_view" or str(payload.get("zone", "")) == "board"):
		# Public aura ledgers are part of the absolute stat transition, including
		# ordinary buffs after the last source died. Null explicitly clears a
		# missing field; absent fields in older recordings remain unspecified.
		var uid: String = str(payload.get("source" if event == "stat_multiply" else "target", ""))
		for board in _boards:
			for unit in board:
				if uid.is_empty() or str(unit.get("uid", "")) != uid: continue
				record[BoardAura.APPLIED_KEY] = unit[BoardAura.APPLIED_KEY].duplicate(true) if unit.has(BoardAura.APPLIED_KEY) else null
				record[BoardAura.ORDINARY_ATTACK_KEY] = unit.get(BoardAura.ORDINARY_ATTACK_KEY, null)
				if unit.has(BeetleGrowth.APPLIED_KEY): record[BeetleGrowth.APPLIED_KEY] = unit[BeetleGrowth.APPLIED_KEY].duplicate(true)
				break
	record["event"] = event
	record["sequence"] = _log.size()
	_log.append(record)
	if _plain_copy_host!=null and _plain_copy_host._azshara_host!=null: _plain_copy_host._azshara_host.observe(self,event,record)
	if _kill_reward_host!=null: _kill_reward_host.observe(self,event)
	if _hand_murloc_gain_host!=null: _hand_murloc_gain_host.observe(self,event,record)
	if _master_realities_host != null: _master_realities_host.begin_event(self,event,record)
	if _mishmash_stat_host != null: _mishmash_stat_host.begin_event(self,event,record)
	if _attack_gains_host != null: _attack_gains_host.begin_event(self,event,record)
	if _keep_gains_host != null: _keep_gains_host.observe(self,event,record)
	if _kill_reward_host!=null: _kill_reward_host.credit_keep(self,event,record)
	if _attack_gains_host != null: _attack_gains_host.end_event(self)
	if _mishmash_stat_host != null: _mishmash_stat_host.end_event(self)
	if _master_realities_host != null: _master_realities_host.end_event(self)
	ThresholdDamage.combat_stat_event(self,event,record)

func _fail(message: String) -> void:
	_error = message
	_emit("error", {"message": message})

func _finished_result() -> Dictionary:
	var winner: int = -1
	if not _boards[0].is_empty() and _boards[1].is_empty():
		winner = 0
	elif _boards[0].is_empty() and not _boards[1].is_empty():
		winner = 1
	return _result(winner)

func _result(winner: int) -> Dictionary:
	if _recurring_nightmare_host!=null and _error.is_empty():
		var recurring_nightmare_final: String=_recurring_nightmare_host.final_error(self)
		if not recurring_nightmare_final.is_empty(): _fail(recurring_nightmare_final)
	if _ditch_guardian_host!=null and _error.is_empty():
		var ditch_guardian_final: String=_ditch_guardian_host.final_error()
		if not ditch_guardian_final.is_empty(): _fail(ditch_guardian_final)
	if _radiant_ember_host!=null and _error.is_empty():
		var radiant_ember_final: String=_radiant_ember_host.final_error()
		if not radiant_ember_final.is_empty(): _fail(radiant_ember_final)
	if _hand_murloc_gain_host!=null and _error.is_empty():
		var hand_murloc_finish: String=_hand_murloc_gain_host.final_error()
		if not hand_murloc_finish.is_empty(): _fail(hand_murloc_finish)
	if _master_realities_host!=null and _error.is_empty():
		var master_finish: String=_master_realities_host.final_error()
		if not master_finish.is_empty(): _fail(master_finish)
	var damage: int = 0
	if not _error.is_empty():
		winner = -1
	if winner >= 0:
		damage = int(_options.get("left_tier" if winner == 0 else "right_tier", 1))
		for unit in _boards[winner]:
			damage += int(unit.get("tier", 1))
	_emit("combat_end", {"winner": winner, "damage": damage, "error": _error, "attacks": _attacks})
	var result: Dictionary = {"damage_listener_ticket":DamageListenerEvents.digest(_options[DamageListenerHost.CONTEXT]) if _options.has(DamageListenerHost.CONTEXT) else "","beetle_players":_beetle_result_players(),AttackGainOrder.FIELD:_options.get(AttackGainOrder.FIELD,""),"winner": winner, "damage": damage, "left": _public_board(0), "right": _public_board(1), "log": _log.duplicate(true), "seed": _seed, "rounds": _attacks, "error": _error, "left_hand": _combat_hand.hands[0].duplicate(true), "right_hand": _combat_hand.hands[1].duplicate(true), "left_hand_count": _hand_counts[0], "right_hand_count": _hand_counts[1],"left_hand_summon_locks":_hand_summons.snapshot_locks(0),"right_hand_summon_locks":_hand_summons.snapshot_locks(1)}
	if _lobster_host!=null: _lobster_host.complete(self,result)
	if _leviathan_host!=null: _leviathan_host.complete(self,result)
	if _kibble_host!=null: _kibble_host.complete(self,result)
	if _hopebringer_host!=null: _hopebringer_host.complete(self,result)
	_energy_recycling_host.complete(self,result)
	_grim_freshener_host.complete(self,result)
	_ritual_dagger_host.complete(self,result)
	_victim_specter_host.complete(self,result)
	if _tony_host!=null: _tony_host.complete(self,result)
	if _old_soul_host!=null: _old_soul_host.complete(self,result)
	if _protoss_host!=null: _protoss_host.complete(self)
	if _octosari_host!=null: _octosari_host.complete(self)
	if _radio_star_host!=null: _radio_star_host.complete(self)
	if _metal_dispenser_host!=null: _metal_dispenser_host.complete(self)
	if _global_counter_host != null: _global_counter_host.complete(self)
	if _crowbar_host!=null: _crowbar_host.complete(self)
	if _owned_attack_host!=null: _owned_attack_host.complete(self)
	if _pirate_chest_host!=null: _pirate_chest_host.complete(self)
	if _keep_gains_host != null: _keep_gains_host.complete(self)
	if _plain_copy_host!=null: _plain_copy_host.Rafaam.complete_combat(_plain_copy_host,self)
	if _plain_copy_host!=null and _plain_copy_host._ship_bottle_host!=null: _plain_copy_host._ship_bottle_host.complete(self)
	if _plain_copy_host!=null and _plain_copy_host._yshaarj_host!=null: _plain_copy_host._yshaarj_host.complete(self)
	if _plain_copy_host!=null and _plain_copy_host._jaraxxus_host!=null: _plain_copy_host._jaraxxus_host.complete(self)
	if _plain_copy_host!=null and _plain_copy_host._ozumat_host!=null: _plain_copy_host._ozumat_host.complete(self)
	if _beetle_blessing_host!=null: _beetle_blessing_host.complete(self)
	if _plain_copy_host!=null and _plain_copy_host._turn_seven_copy_host!=null: _plain_copy_host._turn_seven_copy_host.complete(self)
	if _plain_copy_host!=null and _plain_copy_host._tamsin_host!=null: _plain_copy_host._tamsin_host.complete(self)
	if _plain_copy_host!=null and _plain_copy_host._teron_host!=null: _plain_copy_host._teron_host.complete(self)
	if _plain_copy_host!=null and _plain_copy_host._brukan_host!=null: _plain_copy_host._brukan_host.complete(self)
	if _plain_copy_host!=null and _plain_copy_host._azshara_host!=null: _plain_copy_host._azshara_host.complete(self)
	if _plain_copy_host!=null and _plain_copy_host._onyxia_host!=null: _plain_copy_host._onyxia_host.complete(self)
	if _kill_reward_host!=null: _kill_reward_host.complete(self)
	if _loh_reward_host!=null: _loh_reward_host.complete(self)
	if _milestone_hero_host!=null: _milestone_hero_host.complete(self)
	if _felblood_portrait_host!=null: _felblood_portrait_host.complete(self)
	if _ditch_guardian_host!=null: _ditch_guardian_host.complete(self)
	if _radiant_ember_host!=null: _radiant_ember_host.complete(self)
	if _sand_barnstormer_host!=null: _sand_barnstormer_host.complete(self)
	if _wicked_tome_host!=null: _wicked_tome_host.complete(self)
	if _quilligraphy_host!=null: _quilligraphy_host.complete(self)
	if _piggy_bank_host!=null: _piggy_bank_host.complete(self)
	if _dark_gift_resource_host!=null: _dark_gift_resource_host.complete(self)
	if _owned_observer_host!=null: _owned_observer_host.complete(self)
	if _death_resource_host!=null: _death_resource_host.complete(self)
	if _summon_resource_host!=null: _summon_resource_host.complete(self)
	if _error.is_empty():
		var terminal_core: Dictionary={}
		for key in ["winner","damage","left","right","log","seed","rounds","error"]: terminal_core[key]=result.get(key)
		_hero_damage_terminal={"result":result,"core":terminal_core.duplicate(true),"stage":"issued"}
	return result

func _apply_attack_transfer(entry: Dictionary, effect: Dictionary, repetition: int, trigger: String) -> void:
	# Context belongs to these two host dispatch paths, never imported card data.
	var issue: String = AttackTransfer.effect_error(effect)
	if not issue.is_empty(): _fail(issue); return
	if not AttackTransfer.integer(entry.get("side")) or int(entry.side) not in [0, 1] or not entry.get("unit") is Dictionary:
		_fail("Attack transfer requires a valid host-owned deathrattle entry"); return
	var side: int = int(entry.side)
	var source: Dictionary = entry.unit
	issue = _attack_transfer_program_error(source)
	if not issue.is_empty() or not _uses_attack_transfer(source):
		_fail(issue if not issue.is_empty() else "Attack transfer requires its native source program"); return
	if effect not in AttackTransfer.effects_for_id(source.get("card_id", source.get("id", ""))):
		_fail("Dispatched transfer instruction does not belong to this exact native source"); return
	if not source.get("uid") is String or source.uid.is_empty() or not AttackTransfer.integer(source.get("_combat_id"), 1):
		_fail("Attack transfer requires the exact source UID and combat instance"); return
	var context: String = ""
	var reader: Dictionary = {}
	if trigger in ["rally_deathrattle","triggered_deathrattle"] and entry.get("live_source") is bool and entry.live_source:
		context = "living_deathrattle"
		# Re-resolve on EVERY literal instruction, including both golden entries
		# and each outer repeat. A first self-gain changes the second read.
		reader = _find_unit(side, int(source._combat_id))
		if reader.is_empty() or reader.get("uid") != source.uid or not is_same(reader, source):
			_fail("Attack-transfer living source disappeared or was replaced"); return
		issue = AttackTransfer._living_unit_error(reader)
		if not issue.is_empty(): _fail(issue); return
	elif trigger == "deathrattle" and not entry.has("live_source") and entry.has("dead_attack"):
		context = "natural_death"
		# _resolve_deaths captured this before corpse removal and aura revocation.
		reader = {"attack": entry.dead_attack, "uid": source.uid}
	else:
		_fail("Attack transfer requires natural death or the native living-deathrattle dispatch"); return
	var amount: Dictionary = AttackTransfer.read_amount(effect, reader)
	if not amount.ok: _fail(str(amount.error)); return
	var recipients: Array = []
	var ids: Array = []
	var instances: Array = []
	for friendly in _boards[side]:
		if not friendly.get("_pending_destroy", false) is bool:
			_fail("Attack-transfer destruction marker must be boolean"); return
		if not AttackTransfer.integer(friendly.get("health"), -MAX_STAT):
			_fail("Attack-transfer candidate Health must be a bounded integer"); return
		if int(friendly.health) <= 0 or friendly.get("_pending_destroy", false): continue
		issue = AttackTransfer._living_unit_error(friendly)
		if not issue.is_empty(): _fail(issue); return
		if friendly.get("_side") != side or not AttackTransfer.integer(friendly.get("_combat_id"), 1) or friendly.uid in ids or friendly._combat_id in instances:
			_fail("Attack-transfer recipients require distinct friendly combat instances and UIDs"); return
		for enemy in _boards[1 - side]:
			if enemy.get("uid") == friendly.uid or enemy.get("_combat_id") == friendly._combat_id:
				_fail("Attack-transfer recipient identity is shared with the enemy board"); return
		if not AttackTransfer.recipient_matches(effect, source.uid, friendly): continue
		recipients.append(friendly)
		ids.append(friendly.uid)
		instances.append(friendly._combat_id)
	# Distinctness is local to ONE instruction. A golden second instruction
	# rebuilds candidates and re-reads the living source only at its own start.
	var selected: Array = []
	for _choice in range(mini(AttackTransfer.recipient_count(effect), recipients.size())):
		var selected_index: int = _random_index(recipients.size(), "deathrattle_attack_transfer_target", ids)
		selected.append(recipients[selected_index])
		recipients.remove_at(selected_index)
		ids.remove_at(selected_index)
	var plan: Dictionary = AttackTransfer.plan_instruction(effect, reader, selected, context)
	if not plan.ok: _fail(str(plan.error)); return
	if plan.skipped: return
	if effect.scope == "random_friendly":
		# Keep the accepted Fiendish single-recipient adapter and ordering intact.
		var recipient: Dictionary = selected[0]
		if BoardAuraRuntime.managed(recipient):
			var owner: Variant = recipient.get(BoardAura.APPLIED_KEY, {}).get("owner", recipient.get("permanent_tribe_applied", {}).get("owner", 0))
			var layer_plan: Dictionary = BoardAura.build_adjust_plan(recipient, owner, plan.value, 0)
			if not str(layer_plan.get("error", "")).is_empty(): _fail(str(layer_plan.error)); return
		if not _adjust_board_stats(recipient, int(plan.value), 0): return
		_emit("buff", {"side": side, "source": source.uid, "target": recipient.uid, "attack": recipient.attack, "health": recipient.health, "max_health": recipient.max_health, "attack_delta": plan.value, "health_delta": 0, "reason": AttackTransfer.TYPE, "trigger_context": context, "repetition": repetition})
		return
	# Preflight this complete instruction's recipients using existing adapters.
	# No writes occur between its one source read and complete group preflight.
	for index in range(selected.size()):
		var recipient: Dictionary = selected[index]
		var change: Dictionary = plan.changes[index]
		if _options.has(DamageListenerHost.CONTEXT):
			issue = DamageListenerHost.adjust_error(recipient, int(change.attack_delta), int(change.health_delta))
			if not issue.is_empty(): _fail(issue); return
		if BoardAuraRuntime.managed(recipient):
			var owner: Variant = recipient.get(BoardAura.APPLIED_KEY, {}).get("owner", recipient.get("permanent_tribe_applied", {}).get("owner", 0))
			var layer_plan: Dictionary = BoardAura.build_adjust_plan(recipient, owner, change.attack_delta, change.health_delta)
			if not str(layer_plan.get("error", "")).is_empty(): _fail(str(layer_plan.error)); return
	for index in range(selected.size()):
		var recipient: Dictionary = selected[index]
		var change: Dictionary = plan.changes[index]
		if not _adjust_board_stats(recipient, int(change.attack_delta), int(change.health_delta)): return
		_emit("buff", {"side": side, "source": source.uid, "target": recipient.uid, "attack": recipient.attack, "health": recipient.health, "max_health": recipient.max_health, "attack_delta": change.attack_delta, "health_delta": change.health_delta, "reason": AttackTransfer.TYPE, "trigger_context": context, "repetition": repetition})

func _public_unit(unit: Dictionary) -> Dictionary:
	var result: Dictionary = unit.duplicate(true)
	for key in result.keys():
		if str(key).begins_with("_"):
			result.erase(key)
	return result

func _public_board(side: int) -> Array:
	var result: Array = []
	for unit in _boards[side]:
		result.append(_public_unit(unit))
	return result

func combat_hero_context_error(left: Array, right: Array, options: Dictionary = {}) -> String:
	var giantfin_issue: String=Giantfin.context_error(options)
	if not giantfin_issue.is_empty(): return giantfin_issue
	var nefarian_issue: String=Nefarian.context_error(options)
	if not nefarian_issue.is_empty(): return nefarian_issue
	var wagtoggle_issue: String=Wagtoggle.context_error(options)
	if not wagtoggle_issue.is_empty(): return wagtoggle_issue
	for side in range(2):
		var context: Variant = options.get("left_combat_hero" if side == 0 else "right_combat_hero",{})
		var issue: String = CombatHero.validate_context(context)
		if not issue.is_empty(): return issue
		if context.get("hero_id","") != CombatHero.GREYBOUGH: continue
		var units: Array = (left if side == 0 else right).duplicate()
		var hand: Variant = options.get("left_hand" if side == 0 else "right_hand",[])
		if not hand is Array: return "格雷布手牌战斗上下文格式无效。"
		units.append_array(hand)
		for unit in units:
			issue = CombatHero.boundary_error(unit)
			if not issue.is_empty(): return "格雷布同侧召唤组合未验证：" + issue
	return ""

func _adjust_board_stats(unit: Dictionary, attack: int, health: int, giver: Dictionary={}) -> bool:
	var swirler_combat_vector: Dictionary=TimewarpSwirler.combat_vector(self,unit,attack,health,giver)
	if not swirler_combat_vector.ok: _fail(str(swirler_combat_vector.error));return false
	attack=int(swirler_combat_vector.attack);health=int(swirler_combat_vector.health)
	var murder_weapon_ticket: Dictionary=MurderWeapon.before_combat(self,unit,attack,health,giver)
	if not murder_weapon_ticket.ok: _fail(str(murder_weapon_ticket.error));return false
	if _ditch_guardian_host!=null:
		var ditch_guardian_vector: Dictionary=_ditch_guardian_host.combat_vector(self,unit,attack,health,giver)
		if not ditch_guardian_vector.ok: _fail(str(ditch_guardian_vector.error));return false
		attack=int(ditch_guardian_vector.attack);health=int(ditch_guardian_vector.health)
	if _enhanced_spawn_host!=null:
		var enhanced_spawn_vector: Dictionary=_enhanced_spawn_host.combat_vector(self,unit,attack,health,giver)
		if not enhanced_spawn_vector.ok: _fail(str(enhanced_spawn_vector.error));return false
		attack=int(enhanced_spawn_vector.attack);health=int(enhanced_spawn_vector.health)
	if _radiant_ember_host!=null:
		var radiant_ember_vector: Dictionary=_radiant_ember_host.combat_vector(self,unit,attack,health,giver)
		if not radiant_ember_vector.ok: _fail(str(radiant_ember_vector.error));return false
		attack=int(radiant_ember_vector.attack);health=int(radiant_ember_vector.health)
	var pen_vector: Dictionary=WaterloggedPen.combat_vector(self,unit,attack,health,giver)
	if not pen_vector.ok: _fail(str(pen_vector.error));return false
	attack=int(pen_vector.attack);health=int(pen_vector.health)
	var seaside_vector: Dictionary=Seaside.combat_vector(self,unit,attack,health,giver)
	if not seaside_vector.ok: _fail(str(seaside_vector.error));return false
	attack=int(seaside_vector.attack);health=int(seaside_vector.health)
	var loc_vector: Dictionary=LocPrince.vector(unit,attack,health)
	if not loc_vector.ok: _fail(str(loc_vector.error));return false
	var loc_context_issue: String=LocPrince.combat_error(self,unit,attack,health)
	if not loc_context_issue.is_empty(): _fail(loc_context_issue);return false
	var bait_gain: Dictionary=FishBait.Sources.gain_plan(unit,attack,health)
	if not str(bait_gain.error).is_empty(): _fail(str(bait_gain.error));return false
	if bait_gain.handled: return true
	var master_plan: Dictionary=_master_realities_host.prepare_combat(self,unit,attack,health)
	if not master_plan.ok: _fail(str(master_plan.error));return false
	var expeditioner_plan: Dictionary=Expeditioner.prepare_combat(self,unit,attack,health)
	if not expeditioner_plan.ok: _fail(str(expeditioner_plan.error));return false
	var hand_murloc_plan: Dictionary=HandMurlocGain.prepare_combat(self,unit,attack,health,expeditioner_plan)
	if not hand_murloc_plan.ok: _fail(str(hand_murloc_plan.error));return false
	attack=int(loc_vector.attack);health=int(loc_vector.health)
	if _options.has(DamageListenerHost.CONTEXT):
		var received_issue: String=DamageListenerHost.adjust_error(unit,attack,health)
		if not received_issue.is_empty(): _fail(received_issue); return false
	if BoardAuraRuntime.managed(unit):
		var issue: String = BoardAuraRuntime.adjust(unit,attack,health,true)
		if not issue.is_empty(): _fail(issue); return false
	else:
		unit.attack = int(unit.attack)+attack
		unit.health = int(unit.health)+health
		unit.max_health = int(unit.max_health)+health
	_loc_prince_host.capture(unit)
	var master_capture: String=_master_realities_host.capture_combat(unit,master_plan)
	if not master_capture.is_empty(): _fail(master_capture);return false
	var expeditioner_issue: String=Expeditioner.commit_combat(self,unit,expeditioner_plan)
	if not expeditioner_issue.is_empty(): _fail(expeditioner_issue);return false
	var hand_murloc_issue: String=_hand_murloc_gain_host.commit_combat(self,unit,hand_murloc_plan)
	if not hand_murloc_issue.is_empty(): _fail(hand_murloc_issue);return false
	var murder_weapon_issue: String=MurderWeapon.after_combat(self,murder_weapon_ticket)
	if not murder_weapon_issue.is_empty(): _fail(murder_weapon_issue);return false
	return true

# Beetle host: exact source programs, stable queue and owner-local sessions.
func _beetle_program_error(unit: Dictionary) -> String:
	var observer_issue: String=BeetleObserver.Sources.unit_error(unit)
	if not observer_issue.is_empty(): return observer_issue
	var identity: String = str(unit.get("card_id",unit.get("id","")))
	if identity in BeetleSources.SOURCE_IDS:
		if not BeetleSources.same(unit.get("beetle_native_program"),BeetleSources.SOURCE_SPECS[identity].beetle_native_program): return "Complete Beetle source native clauses are missing or changed"
		return BeetleSources.compiled_error(identity,unit.get("effects"))
	if BeetleSources.runed_claimed(unit.get("effects",[])): return "Runed Progenitor Avenge leaf needs its exact physical source"
	for effect in unit.get("effects",[]):
		if effect is Dictionary and effect.get("type") in BeetleHost.TYPES: return "Beetle native payload needs its exact physical source"
	return ""

func _beetle_context_error(left: Array, right: Array, options: Dictionary) -> String:
	var needed: bool = false
	for unit in left+right:
		if str(unit.get("card_id","")) in BeetleSources.SOURCE_IDS or unit.has(BeetleGrowth.APPLIED_KEY): needed=true
	if not options.has("beetle_context"):
		return "Beetle native/layer requires an explicit conditional owner context" if needed else ""
	var context: Variant = options.beetle_context
	if not context is Dictionary or not context.get("combat_id") is String or context.combat_id.is_empty() or not context.get("players") is Array or context.players.size()!=2 or not context.get("cards") is Dictionary: return "Malformed complete Beetle combat context"
	for identity in BeetleSources.SOURCE_SPECS:
		var issue: String = BeetleSources.card_error(context.cards.get(identity))
		if not issue.is_empty(): return issue
	var closed: Array = left+right
	for prefix in ["left","right"]:
		if not options.get(prefix+"_hand",[]) is Array: return "Malformed Beetle combat hand context"
		closed.append_array(options.get(prefix+"_hand",[]))
		var hero: Dictionary = options.get(prefix+"_combat_hero",{})
		if not hero.is_empty(): closed.append(hero)
	var errors: Array = BeetleHost.Room.errors_for_cards(closed)
	if not errors.is_empty(): return str(errors[0])
	var unique_owners: Array = []
	for side in range(2):
		var player: Variant = context.players[side]
		var board: Array = left if side==0 else right
		if not player is Dictionary: return "Missing explicit Beetle combat owner"
		if player.is_empty():
			if side!=1 or not board.is_empty(): return "Only the empty absent right side may omit a Beetle owner"
			continue
		var issue: String = BeetleHost.bounded_error(player)
		if not issue.is_empty(): return issue
		if player.id in unique_owners: return "Combat owners must be distinct"
		unique_owners.append(player.id)
		var session: Variant = player.get(BeetleGrowth.SESSION_KEY)
		if not session is Dictionary or session.size()!=3 or not BeetleSources.same(session.get("owner"),player.id) or session.get("combat_id")!=context.combat_id or session.get("origin") not in ["live","ghost"]: return "Beetle local session owner/container/combat identity mismatch"
		var ghost: bool = options.get("right_is_ghost",false) if side==1 else options.get("left_is_ghost",false)
		if session.origin != ("ghost" if ghost else "live"): return "Beetle local session origin mismatch"
		if ghost:
			issue=BeetleHost.ghost_error(player)
			if not issue.is_empty(): return issue
		if not BeetleSources.same(player.board,board): return "Beetle complete native board differs from combat input"
		if not BeetleSources.same(player.get("hand",[]),options.get("left_hand" if side==0 else "right_hand",[])): return "Beetle complete hand differs from combat input"
		# Finite additive budget proves no valid admitted fight first discovers
		# numeric overflow midway. It is scoped to this fight, not a ledger cap.
		var bound: Dictionary = BeetleHost.combat_numeric_error(player,closed,int(options.get("max_iterations",5000)))
		if not str(bound.error).is_empty(): return str(bound.error)
	_beetle_players=context.players.duplicate(true)
	_beetle_cards=context.cards.duplicate(true)
	return ""

func _beetle_entry_preview(raw: Dictionary, side: int, uid: String) -> Dictionary:
	var result: Dictionary = {"error":"","template":raw,"after":{}}
	var identity: String = str(raw.get("card_id",raw.get("id","")))
	if _beetle_players.is_empty() or identity not in BeetleSources.TOKEN_IDS: return result
	if _beetle_players[side].is_empty(): return {"error":"Beetle cannot enter an ownerless side"}
	var definition: Dictionary = _beetle_cards[identity]
	var body: Dictionary = raw.duplicate(true)
	# Old genuine summon templates omit presentation/identity fields. Fill only
	# missing pinned metadata, never replace a contrary supplied field or stats.
	for pair in [["card_id","id"],["kind","kind"],["name","name"],["text","text"],["golden","is_golden"],["tribes","tribes"],["keywords","keywords"],["effects","effects"]]:
		if not body.has(pair[0]): body[pair[0]]=definition[pair[1]].duplicate(true) if definition[pair[1]] is Array or definition[pair[1]] is Dictionary else definition[pair[1]]
	if not body.has("max_health"): body.max_health=body.get("health")
	body.uid=uid
	var plan: Dictionary = BeetleGrowth.build_entry_plan(_beetle_players[side],body,true)
	if not str(plan.error).is_empty(): return plan
	for stat in ["attack","health","max_health"]:
		if not BeetleHost.exact(plan.after[stat]): return {"error":"Future Beetle exceeds exact JSON bound"}
	result.template=body
	result.after=plan.after
	return result

func _beetle_deathrattle(entry: Dictionary, effect: Dictionary, repetition: int, trigger: String) -> void:
	if _beetle_players.is_empty(): _fail("Missing Beetle combat context"); return
	var side: int = int(entry.side)
	var source: Dictionary = entry.unit
	if trigger in ["rally_deathrattle","triggered_deathrattle"]:
		if entry.get("live_source")!=true or not is_same(_find_unit(side,int(source.get("_combat_id",-1))),source) or not LivingDeathrattles.active(source): _fail("Beetle triggered Deathrattle requires its actual living board source");return
	elif trigger!="deathrattle": _fail("Beetle invocation requires native death or actual living Deathrattle dispatch");return
	var player: Dictionary = _beetle_players[side]
	var card: Dictionary = _beetle_cards.get(source.card_id,{})
	if effect not in BeetleSources.compiled_effects(source.card_id): _fail("Unbound Beetle deathrattle descriptor"); return
	var token: Dictionary = _beetle_cards["BG28_603t"]
	var context: Dictionary = {"side":side,"source_uid":source.uid,"position":entry.position,"order":entry.order,"repetition":repetition,"queue":_pending_deaths.duplicate(true),"serial":_serial,"sequence":_log.size()}
	var plan: Dictionary = BeetleHost.native_plan(player,source,card,token,"deathrattle",BOARD_LIMIT-_boards[side].size(),context)
	if not str(plan.error).is_empty(): _fail(str(plan.error)); return
	var event: Dictionary = BeetleEvents.build_event(plan.native,side,_log.size()+1)
	if not str(event.error).is_empty(): _fail(str(event.error)); return
	# Full native program/capacity/event preflight is complete before FIRST write.
	var issue: String = BeetleHost.commit_native(player,source,card,token,"deathrattle",BOARD_LIMIT-_boards[side].size(),context,plan)
	if not issue.is_empty(): _fail(issue); return
	_emit(trigger,{"side":side,"source":source.uid,"effect":effect.type,"repetition":repetition,"total_repetitions":entry.get("repeats",1)})
	if not event.event.is_empty(): _emit(BeetleGrowth.EVENT_TYPE,event.event)
	for index in range(int(plan.summon_count)):
		if _boards[side].size() >= BOARD_LIMIT:
			var continue_attempts: bool=_summon_attempt_observers(side)
			if not _summon_capacity_miss({"side":side,"source":source.uid,"reason":"board_full","kind":"deathrattle"}): return
			if continue_attempts: continue
			break
		if not _summon(entry,BeetleHost.template(token),"deathrattle"): return

# Only the unchanged real Avenge scheduler may enter this source-bound leaf.
# It does not borrow Deathrattle repeats, positions, ordering or summon behavior.
func _beetle_avenge(entry: Dictionary, effect: Dictionary, repetition: int, trigger: String) -> void:
	if _beetle_players.is_empty(): _fail("Missing Beetle combat context"); return
	if trigger != "avenge_effect" or repetition != 1 or entry.get("repeats",1) != 1: _fail("Runed Progenitor requires one real Avenge activation"); return
	var side: int = int(entry.side)
	var source: Dictionary = entry.unit
	var identity: String = str(source.get("card_id",""))
	var issue: String = BeetleSources.runed_effect_error(identity,effect)
	if not issue.is_empty(): _fail(issue); return
	var actual: Dictionary = _find_unit(side,int(source.get("_combat_id",-1)))
	if actual.is_empty() or not is_same(actual,source) or int(source.get("health",0)) <= 0: _fail("Runed Progenitor Avenge requires its actual living board source"); return
	var player: Dictionary = _beetle_players[side]
	if player.is_empty() or not is_same(player.board,_boards[side]): _fail("Runed Progenitor owner board differs from the stable combat board"); return
	var card: Dictionary = _beetle_cards.get(identity,{})
	var token: Dictionary = _beetle_cards["BG28_603t"]
	var context: Dictionary = {"side":side,"source_uid":source.uid,"repetition":repetition,"queue":_pending_deaths.duplicate(true),"serial":_serial,"sequence":_log.size()}
	var plan: Dictionary = BeetleHost.native_plan(player,source,card,token,"avenge",BOARD_LIMIT-_boards[side].size(),context)
	if not str(plan.error).is_empty(): _fail(str(plan.error)); return
	if int(plan.summon_count) != 0: _fail("Runed Progenitor Avenge cannot summon"); return
	var event: Dictionary = BeetleEvents.build_event(plan.native,side,_log.size()+1)
	if not str(event.error).is_empty(): _fail(str(event.error)); return
	issue = BeetleHost.commit_native(player,source,card,token,"avenge",BOARD_LIMIT-_boards[side].size(),context,plan)
	if not issue.is_empty(): _fail(issue); return
	_emit(trigger,{"side":side,"source":source.uid,"effect":effect.type,"repetition":1,"total_repetitions":1})
	_emit(BeetleGrowth.EVENT_TYPE,event.event)

func _beetle_result_players() -> Array:
	var result: Array = _beetle_players.duplicate(true)
	for side in range(result.size()):
		if not result[side].is_empty(): result[side].board = _public_board(side)
	return result

func _random_temporary_summons(entry: Dictionary, effect: Dictionary) -> void:
	var side: int=int(entry.side)
	var filter: String=str(effect.filter)
	for pick in range(int(effect.count)):
		if not _tick("temporary_random_summon"): return
		if _boards[side].size()>=BOARD_LIMIT:
			var observe: bool=_summon_attempt_observers(side)
			if not _summon_capacity_miss({"side":side,"source":entry.unit.uid,"reason":"board_full","kind":"temporary_random"}): return
			if observe: continue
			return
		var leaf: Dictionary={"kind":"minion"}
		if filter in ["海盗","亡灵","野兽"]: leaf.tribe=filter
		if filter=="cost_one": leaf.cost=1
		if filter=="cost_two": leaf.cost=2
		if filter=="cost_four": leaf.cost=4
		if effect.has("tier_sequence"): leaf.tier=int(effect.tier_sequence[pick])
		var plan: Dictionary=_bulk_resource_host.temporary_choices(side,leaf)
		if not plan.ok: _fail(str(plan.error));return
		var choices: Array=[]
		var templates: Dictionary=_options.get("hand_card_templates",{})
		for choice in plan.choices:
			if effect.get("golden",false) and not templates.has(str(choice.golden_id)): continue
			var template: Dictionary=templates.get(str(choice.id),{})
			if template.is_empty(): _fail("temporary_summon_missing_template:"+str(choice.id));return
			if filter=="divine_shield" and "divine_shield" not in template.get("keywords",[]): continue
			if filter=="deathrattle":
				var found: bool=false
				for child_effect in template.get("effects",[]):
					if str(child_effect.get("type","")).begins_with("deathrattle_") and child_effect.get("type")!="deathrattle_repeat": found=true
				if not found: continue
			choices.append(choice)
		var total: int=BulkResourceHost._total(choices)
		if total<=0: continue
		var ticket: int=_rng.randi_range(0,total-1)
		var identity: String=BulkResourceHost._selected(choices,ticket)
		_emit("rng",{"purpose":"temporary_random_summon","candidates":choices,"ticket":ticket,"choice":identity,"total":total})
		if effect.get("golden",false):
			for choice in choices:
				if choice.id==identity: identity=str(choice.golden_id);break
		var unit: Dictionary=templates[identity].duplicate(true)
		for field in ["pool_id","pool_kind","pool_count"]: unit.erase(field)
		if effect.has("set_stats"):
			unit.base_unit=unit.get("base_unit",unit).duplicate(true)
			unit.attack=int(effect.set_stats);unit.health=int(effect.set_stats);unit.max_health=int(effect.set_stats)
		var issue: String=_validate_unit(unit,0,false,templates)
		if not issue.is_empty(): _fail(issue);return
		_summon(entry,unit,"temporary_random")
		if not _error.is_empty(): return

func _combat_transfer_stat(source: Dictionary, action: Dictionary) -> void:
	var side: int=int(source._side)
	for repetition in range(int(action.get("times",1))):
		if not _rally_live_target(source) or source.get("_pending_destroy",false): return
		var amount: int=maxi(0,int(source.get(str(action.stat),0)))
		var candidates: Array=[]
		for target in _boards[side]:
			if int(target.health)<=0 or target.get("_pending_destroy",false): continue
			if action.get("exclude_self",false) and int(target._combat_id)==int(source._combat_id): continue
			if str(target.get("card_id","")) in action.get("exclude_ids",[]): continue
			if not _tribe_matches(target,str(action.get("tribe",""))): continue
			candidates.append(target)
		var selected: Array=[]
		for pick in range(mini(int(action.count),candidates.size())):
			var names: Array=[]
			for target in candidates: names.append(target.uid)
			var chosen: int=_random_index(candidates.size(),"combat_stat_transfer",names)
			selected.append(candidates[chosen]);candidates.remove_at(chosen)
		for recipient in selected:
			if not _tick("combat_stat_transfer"): return
			var buff: Dictionary={"attack":amount if action.stat=="attack" else 0,"health":amount if action.stat=="max_health" else 0}
			_apply_trigger_buff(source,recipient,buff,"combat_stat_transfer",str(source.uid))
			if not _error.is_empty(): return

func _combat_transfer_error(action: Dictionary) -> String:
	if action.get("type")!="combat_transfer_stat" or action.get("stat") not in ["attack","max_health"] or not _rally_integer(action.get("count"),1) or not _rally_integer(action.get("times",1),1): return "Invalid combat stat transfer"
	for field in action:
		if field not in ["type","stat","count","times","tribe","exclude_self","exclude_ids"]: return "Unknown stat transfer field"
	if action.has("exclude_self") and not action.exclude_self is bool: return "Invalid stat transfer exclusion"
	if action.has("tribe") and not action.tribe is String: return "Invalid stat transfer tribe"
	if action.has("exclude_ids"):
		if not action.exclude_ids is Array: return "Invalid stat transfer identities"
		for id in action.exclude_ids:
			if not id is String: return "Invalid stat transfer identity"
	return ""

func _has_live_mega_aura(side: int) -> bool:
	for source in _boards[side]:
		var identity: String=str(source.get("card_id",""))
		if MEGA_AURA_PROGRAMS.has(identity) and source.get("effects")==MEGA_AURA_PROGRAMS[identity] and int(source.get("health",0))>0 and not source.get("_pending_destroy",false) and not source.get("silenced",false) and not source.get("abilities_disabled",false): return true
	return false
