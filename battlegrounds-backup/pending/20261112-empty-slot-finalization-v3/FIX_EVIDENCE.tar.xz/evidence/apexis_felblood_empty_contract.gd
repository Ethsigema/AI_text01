extends "res://tests/empty_slot_resource_v3_20261112/apexis_felblood_empty_contract.gd"
