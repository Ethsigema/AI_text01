# 实际 Game / 外部 validator 失败独立复核

结论：本次停止是外部 PASS 清单错误，不是实际 Game 失败。可修订外部 validator 并保留这次 Game 原证据，只续跑尚未执行的13项纯合同；此时仍不能称整批验收完成。

## 实际证据而非 synthetic
读取 remote_snapshot_32a8b33/independent_tests 的原 log、scene、进程 result、STARTED、ATTEMPT_SUMMARY、外部 wrapper 与四份 source map。
- 固定源码 32a8b33abe2bfb980c5ec890e7950f6b5a9f1346；远端 real_matrix SHA 实算 e38c557f0e420b9521a67a4a2a2043a2e80a004acb4172abd8eb6986d72f4f02。wrapper 仅 extends 该真实源码。
- 进程 receipt：exit0，reason exited，exception null，347.721307451 秒，峰值 RSS 3053264896 bytes。该进程已完成，不是 timeout 或待运行。
- 原 log 实数155条 PASS，最终 cases=1 casts=2 combats=3 checks=155；无 FAIL / SCRIPT ERROR / ERROR 行。实际 log SHA 8cc894e7825b84fca3d93431faa12bcbe5642f5be889efcdafa82b444d334eac，与进程 receipt 一致。
- JSON checks154，后写文件检查1，总155。actual casts round1/2 attack2→4→6；sale round3 attack6/health5/kept0；时钟 lastcast82 < reset87 == current87 == first_recruit87 == retirement87。unused expiry used=false、expired=true、spells54→54；结果记录两个前战和一个售后非空战、原 token 后继新UID。
- INITIAL/FINAL × candidate/restored 的四个 map 文件实际 SHA 全为 a20b935157ef28e0fd8e2953e4e121824ba2fc665c0df851554892ca6cd7e9ef。ATTEMPT_SUMMARY 记录两树27994 files、1550944027 bytes、缺失/多余/不符均空。这里核对已生成 map 和receipt，不声称本审查再次重读1.55GB树。

## 两个错误要求的确定来源
原 CARRIED_SALE_FULL_MARKERS 包含裸 `first:1`、`second:1`。实际源码是 `observe_current_cast_sale_gate(lava,"first")` 与 `..."second"`；参数不是 must label。本方法拼接并打印：
- actual_current_cast_sale_gate_first / second
- current_cast_sale_gate_read_only_first / second
这四项实际各一次，原validator也已正确要求它们。全清单对实际 log 逐项计数，唯一不符正是不存在的裸 first/second。旧 ATTEMPT_SUMMARY 在第一个错误项抛 ValueError，并列13合同无result、validated_tests为空，与真实停止点吻合。

## 独立只读复算
以 Python -B 在内存加载原runner（不执行main），只在该临时模块的 marker 字典移除上述两项，再对真实 log/scene 调用原完整 validate_lava_carried_sale_full。原 schema、全部其余 marker multiplicity、ordered markers、native preview、会计、clock、token UID、cast/combat/expiry 约束不变，返回155/JSON154成功。未使用synthetic输入，未修改runner、源码、日志、回执或原冻结包；未启动Godot。

## 修复与剩余边界
V2应只修错误标记清单，明确旧失败属于验证器；保留旧runner及失败回执。新的续跑入口必须重新绑定原进程 exit/log/wrapper/source SHA、同固定源码及已有场景验证，随后仅跑13缺失合同，再做约定全树核验，不可用本审查替代完整最终回执。未发现实际单Game证据另有阻塞；13纯合同及最终打包仍待完成。Coin fixture、preview非真实rebuy、有限房间而非全池验收的范围声明保持。
