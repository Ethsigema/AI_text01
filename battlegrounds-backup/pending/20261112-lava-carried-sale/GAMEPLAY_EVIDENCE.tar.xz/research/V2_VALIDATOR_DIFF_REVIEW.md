# V2 validator 独立差分复核

只读核验通过。原冻结runner实际 SHA：37609d5f0fc9f14fb321397feef271df0a8f1353ab21e8969639cd8f684f5b2d；新 validator_v2.py：a0c8e0c81e08280987dd8de80a9557b0526070c0fa440098c379ab04662010e8。

完整文件差分及忽略位置的 AST 比较确认：91个顶层节点中仅两项改变。
1. CARRIED_SALE_FULL_MARKERS 精确移除错误裸 first/second；程序比较其余键和值完全相同。真实四个动态拼接标记保留。
2. main 删除原完整执行流程，替换为抛 RuntimeError，说明只作validator support，原Game不得重跑，使用独立pure resume。

其余函数/常量 AST 完全不变，包括实际场景 schema、ordered markers、所有13纯合同validator、计数、哈希/源树/进程辅助函数。该文件没有额外路径语义放松；路径支持若需调整位于其它recovery工具，非本文件。

读取 ORIGINAL_GAME_REVALIDATED_V2.json：155checks，game_rerun=false、godot_started=false，保留原 FAILED_OR_INCOMPLETE_ATTEMPT 和裸first错误。所引用 corrected validation receipt 文件实际SHA与引用一致。此与上一独立审查对真实log/scene的只读复算一致，不借synthetic声称实际成功。

边界：main禁用防止直接CLI重跑，但原 run_test 辅助函数仍保留供纯合同使用，因此不能称模块在任意导入者手里绝不可能启动Game。最终run_pure_resume必须严格仅选13个pure、拒full标签/路径并保持原证据只读；该运行边界可在工具冻结后另核。本次未执行main、Godot或恢复执行器，未修改源/runner/旧回执。整批最终验收仍待13合同和最终源树核验。
