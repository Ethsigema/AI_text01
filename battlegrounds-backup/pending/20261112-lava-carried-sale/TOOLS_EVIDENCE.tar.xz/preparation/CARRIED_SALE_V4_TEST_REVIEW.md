# Carried sale V4 实战测试只读审查

结论：按实际调用链，该测试安排的是一房间两次原 Mini cast、三次真实战斗，第三轮 reset 后首条成功命令出售 Lava，第四轮验证保留的 unused token 原生到期及重新发牌。未见测试写入私有授权或跳改 round/sequence；无新的确定静态阻塞。此结论不是已运行通过。

## SHA 与实际继承
候选 real_matrix.gd 实际 SHA 为 e38c557f0e420b9521a67a4a2a2043a2e80a004acb4172abd8eb6986d72f4f02，与指定值一致。
已沿实际继承读取 buffed_sale → mini_after_cast → mini_sale → lava_permanent → lava_rebuy → lava_sale → lava → tier6 → tier5 → tier4 → darkcrest 的相关方法。新 _initialize 只调用 carried_sale_case，没有 super 初始化器，不重复各旧完整矩阵。

## 实际流程与计数
- prepare_room 使用真实 Game.start/Catalog、四玩家、固定 seed 20261120、23 张 enabled minions。Mini/Lava 在原 Darkcrest 购入前通过真实 shop buy 留手；原 Darkcrest public buy/play；然后原 Lava、Mini public play。
- 实际 cast_first 来自 buffed_sale：取真实 hand Trident、验证私有原 token/owner/source/round/refs，public play 到原 Lava，核 +2、kept1、手牌消费、spells+1、UID/RNG/库存不变及完整 cast receipt。分别期望 attack4、attack6，两次调用各一次。
- 两次 observe_current_cast_sale_gate 仅读 sale/preflight 并比较 live_snapshot，不调用 sell、不改时钟，覆盖 kept1 旧分支仍可行。
- next_round 实际来自 tier5：先其他玩家 public end_turn，再0号 public end_turn；要求 recruit 且 oldround+1、原 Darkcrest 唯一 growth event 对应目标等级及 EOT 窗口清空。三次 next_round 目标2/3/4，非直接写 round。
- 前两战 inspect_permanent_combat 查 last_combats 原玩家唯一结果、error为空、非空对手、combat_start 原 Lava UID/attack4或6，下一招募原对象/health5/kept0/无临时层。
- 第二次 next_round 后立即保存 first_recruit_sequence。到 sale 之间仅查询原 ready token、历史/复制对象/错owner负例、snapshot 比较；显式要求 lastcast<reset==current==first_recruit_sequence，历史观察后 sequence 不变。sell_buffed_lava 内售前检查同样不发成功命令，最终 public sell 是第三轮第一条成功命令。未通过额外命令掩盖 reset 相等边界。
- 原 sell_buffed_lava 核完整 board/hand 对象和值、gold/sold/pool唯一+1、spellpool/UID/RNG不变、原对象全zone消失、原 Mini still alive、原 token registry refs/facts、buffed退休及owner-bound buy/play deny。
- 售后原 ready 对象及原 record/facts 保留，错误目标 public cast 必须拒绝且 live_snapshot/receipt refs 不变。随后第三次真实 next_round；验证战斗 Mini仍在、Lava不在、对手非空，原保留token expired=true/used=false且全zone消失、spells不增加，Mini新发牌为新UID/新对象、同原source/owner/currentround。

## 非自然 fixture 与权限边界
- 继承 fund 明确只允许尚未拥有 Darkcrest 时，用原 _unit(Coin)+_add_hand 注入资金，再 public play；这是已标注的 Coin fixture，不是自然经济。结果声明 coin_pre_source_fixture=true、entirely_natural_game=false，准确。
- native child/fresh Lava preview 是 detached 原factory预览，未入手、未分配实际UID、未赋予 token/board 权限；预览 flags 仅写 detached 字典，完整 live snapshot/receipt refs 不变。不能把它称为真实发牌或实际 rebuy。
- 新历史负例只复制参数后调用实际 helper，无替换真实 _tokens/_board/marker；真实授权只来自 Game 原流程。观察代码未给 source/owner/round/sequence 补值。
- marker 中 casts=2/combats=3 是完成整个案例后打印的预期计数，不是独立日志扫描。实际证据由两次 cast 数组、两次前战记录及最后战日志形成；最终回执仍应读实际结果核对，不能仅凭字符串宣告通过。

## 未验证
未运行 Game/Godot，未等候或读取未来长测成功结果。pre-freeze42只有早期拒绝，不证明真实 history 深层负例。该脚本不验证 buffed 真重购、其他目标、黄金/多Mini、任意混合池或所有历史损坏类型；三场实际对局与原生到期/重发仍以正式执行结果为准。
