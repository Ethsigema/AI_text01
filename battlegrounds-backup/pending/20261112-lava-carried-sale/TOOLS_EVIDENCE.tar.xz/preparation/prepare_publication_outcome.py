"""Package an actually completed single-runtime attempt; never run Game or upload."""
import shutil
from render_verified_slice import render_slice
from packaging_common import *
def main():
 ap=parser(__doc__);ap.add_argument('--outcome',choices=['success','failure'],required=True);a=ap.parse_args();guard=lock();r,commit,folder,m,expected,d=context(a);e=r/'independent_tests'
 summary=read(e/'ATTEMPT_SUMMARY.json');audit=read(r/'POST_ATTEMPT_SOURCE_AUDIT.json');final=read(r/'INDEPENDENT_GAME_VERIFICATION.json') if (r/'INDEPENDENT_GAME_VERIFICATION.json').exists() else None
 for receipt in [summary,audit]+([final] if final else []):assert receipt['source_commit']==commit and receipt['source_map_sha256']==m['source_map_sha256'] and receipt['aggregate_sha256']==m['aggregate_sha256']
 assert outcome_metadata(summary,audit,final)==a.outcome
 prep=read(e/'PREPARED_FROM_REMOTE.json');candidate=Path(prep['candidate_path']);restored=Path(prep['restored_snapshot_path']);assert candidate==ROOT/'candidate' and r in restored.parents
 trees={n:runner.scan_tree(p,expected,m['aggregate_sha256'])[0] for n,p in [('candidate',candidate),('restored_snapshot',restored)]}
 if a.outcome=='success':assert all(row['matches'] is True for row in trees.values())
 runs={};validation_errors={};prior=None
 for label,source,_,count in runner.TESTS:
  f=e/(label+'_result.json');log=e/(label+'.log')
  if not f.exists():
   assert a.outcome=='failure', 'Success requires every process result';continue
  result=read(f);assert result['source_commit']==commit and result['source']==source and result['source_sha256']==expected[source]['sha256'] and result['log_sha256']==sha(log.read_bytes())
  assert prior is None or result['started_at_utc']>=prior;prior=result['finished_at_utc'];runs[label]=result
  try:
   assert result['exit']==0 and result['reason']=='exited';n,case=runner.validate(label,log.read_text(),count,e)
   if a.outcome=='success':assert final['tests'][label]==read(e/(label+'_VALIDATED.json')) and final['tests'][label]['passed_checks']==n
  except Exception as exc:
   validation_errors[label]=repr(exc)
   if a.outcome=='success':raise
 if a.outcome=='success':assert len(runs)==len(runner.TESTS) and not validation_errors
 files={'independent_tests/'+p.name:p.read_bytes() for p in e.iterdir() if p.is_file() and p.suffix in {'.gd','.log','.json'}}
 for n in ['POST_ATTEMPT_SOURCE_AUDIT.json','INDEPENDENT_RESTORE_VERIFIED.json','FIX_EVIDENCE_VERIFIED.json','FRESH_PACKAGE_DOWNLOAD_VERIFIED.json']:files[n]=(r/n).read_bytes()
 for p in (ROOT/'preparation').iterdir():
  if p.is_file() and (p.suffix in {'.py','.md'} or p.suffix=='.json' and any(k in p.name for k in ['SYNTHETIC','PREPARATION','FROZEN'])):files['preparation/'+p.name]=p.read_bytes()
 post={'source_commit':commit,'source_map_sha256':m['source_map_sha256'],'trees':trees,'outcome':a.outcome,'validation_errors':validation_errors,'tests_without_result_receipt':[x[0] for x in runner.TESTS if x[0] not in runs],'not_run_tests_are_not_passes':True,'runtime_mode':runner.RUNTIME_MODE,'two_runtime_copies':False,'game_started_by_packager':False,'source_integrity_ok':all(row['matches'] is True for row in trees.values()),'test_classifications':{key:value['classification'] for key,value in audit['tests'].items()},'baseline':runner.BASELINE}
 files['PACKAGING_POST_TEST_REHASH.json']=enc(post)
 if final:files['INDEPENDENT_GAME_VERIFICATION.json']=(r/'INDEPENDENT_GAME_VERIFICATION.json').read_bytes()
 slice_text=render_slice(summary,audit,final,read(e/runner.NEW_TEST_METADATA['scenario_file']) if final else None,commit)
 slice_name='GAMEPLAY_VERIFIED_SLICE.md' if final else 'GAMEPLAY_FAILED_SLICE.md'
 files[slice_name]=slice_text.encode()
 data,meta=archive(files,commit)
 early=ROOT/'restore_receipt_package';earlymeta=read(ROOT/'RESTORE_RECEIPT_UPLOAD_METADATA.json')
 for row in earlymeta['records']:
  b=(early/row['name']).read_bytes();assert len(b)==row['bytes'] and sha(b)==row['sha256']
 p=ROOT/('final_package' if a.outcome=='success' else 'failed_run_receipt_package');assert not p.exists();shutil.copytree(early,p)
 put(p/slice_name,slice_text.encode())
 for n,b in {'GAMEPLAY_EVIDENCE.tar.xz':data,'GAMEPLAY_EVIDENCE_MANIFEST.json':enc(meta),'GAMEPLAY_OUTCOME.json':enc(post)}.items():put(p/n,b)
 if final:
  put(p/'GAMEPLAY_INDEPENDENT_VERIFICATION.json',(r/'INDEPENDENT_GAME_VERIFICATION.json').read_bytes());put(p/'GAMEPLAY_MATRIX_RESULT.json',(e/runner.NEW_TEST_METADATA['scenario_file']).read_bytes())
 counts={k:v['passed_checks'] for k,v in final['tests'].items()} if final else {}
 note=slice_text+'\n\n保留基线 source b74934926d8e5eaeb4a9b27328cd07da3da54007 / accepted final 49f3a8d59dd2a5c6f6d5e399887ba41f39500bdb。本批计划范围为两次原Mini首塑造将原Lava变4/5再6/5，经原生reset到kept0后公开出售；当前原ready票保留，第3次非空combat后unused expiry与fresh grant。泛化合法steps>=1不等于真实样本已覆盖所有计数；同轮两次admission仅只读观察，不是另跑同轮sale。暗潮获取牌等级4不是随从星级变化。禁金色、新目标、退役Mini、buffed Lava重买或inactive全局规则。上一批db9a研究封装丢失例外仍如实保留，不是本批再次丢失；源码原SHA与差分可恢复，不声称所有unique都保留。最终远端发布回读仍待完成。\n'
 put(p/'GAMEPLAY_OUTCOME.md',note.encode());checksum(p);records=rows(p);old={x['name']:x for x in earlymeta['records']};changed=[x for x in records if x['name'] not in old or x['sha256']!=old[x['name']]['sha256']]
 assert [x['name'] for x in changed if x['name'] in old]==['SHA256SUMS.txt']
 metaout={'status':'LOCAL_OUTCOME_READY_NOT_PUBLISHED','outcome':a.outcome,'source_commit':commit,'remote_folder':folder,'folder':folder,'files':len(records),'bytes':sum(x['bytes'] for x in records),'records':records,'changed_records':changed}
 put(ROOT/('FINAL_UPLOAD_METADATA.json' if final else 'FAILED_RUN_UPLOAD_METADATA.json'),enc(metaout));put(ROOT/('FINAL_PUBLICATION_FILES.json' if final else 'FAILED_RUN_PUBLICATION_FILES.json'),enc(records))
if __name__=='__main__':main()
