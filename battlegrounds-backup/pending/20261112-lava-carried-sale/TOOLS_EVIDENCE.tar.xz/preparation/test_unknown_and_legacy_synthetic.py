"""Synthetic fail-closed and retained-legacy checks only; never Game or source scans."""
import copy,json,tempfile
from pathlib import Path
import run_remote_lava_carried_sale as r
checks=[]
def reject(label,fn):
 try:fn()
 except (ValueError,AssertionError,TypeError,KeyError):checks.append(label);return
 raise AssertionError('Accepted '+label)
reject('unknown_stage_refuses_runtime',r.require_frozen)
reject('unknown_new_full_rejects_fabricated_pass',lambda:r.validate(r.TESTS[0][0],'PASS fake\nDARKCREST_LAVA_CARRIED_SALE_REAL_MATRIX_PASS cases=1 casts=2 combats=3 checks=1\n',None,Path('.')))
reject('unknown_new_pure_rejects_fabricated_pass',lambda:r.validate(r.TESTS[1][0],'PASS fake\n',None,Path('.')))
ready=r.NEW_VALIDATORS_READY;r.NEW_VALIDATORS_READY=True
reject('ready_flag_cannot_enable_unimplemented_new_full',lambda:r.validate_lava_carried_sale_full('',Path('.')))
reject('ready_flag_cannot_enable_unimplemented_new_pure',lambda:r.validate_lava_carried_sale_pure('',1))
r.NEW_VALIDATORS_READY=ready
assert len(r.TESTS)==14 and len([x for x in r.TESTS if 'real_matrix' in x[0]])==1 and sum(x[3] for x in r.TESTS[2:])==3292;checks.append('exact_fourteen_processes_twelve_old_pure_3292')
assert r.FROZEN_SOURCE_COMMIT=='UNKNOWN_NOT_PUBLISHED' and all(r.PINNED_TESTS[x[1]]=='UNKNOWN_NOT_FROZEN' for x in r.TESTS[:2]);checks.append('source_commit_and_new_hashes_unset_not_baseline_defaults')
# Legacy pure observer must not accidentally read the unknown new count/readiness.
lines=[]
for name,n in r.MINI_AFTER_CAST_PURE_MARKERS.items():lines.extend(['PASS '+name]*n)
for prefix,n in r.MINI_AFTER_CAST_PURE_PREFIX_COUNTS.items():lines.extend(['PASS '+prefix+str(i) for i in range(n)])
assert len(lines)==85
summary={'passed':85,'failed':0,'failures':[],'real_game_run':False,'actual_provenance_proven':False,'scope':r.MINI_AFTER_CAST_PURE_SCOPE}
log='\n'.join(lines+['DARKCREST_MINI_AFTER_CAST_CONTENT_CONTRACT '+json.dumps(summary)])+'\n'
assert r.validate('mini_after_cast_content_contract',log,85,Path('.'))==(85,None);checks.append('legacy_aftercast85_independent_of_new_unknown_metadata')
reject('legacy_aftercast_missing_marker_rejected',lambda:r.validate('mini_after_cast_content_contract',log.replace(lines[0]+'\n','',1),85,Path('.')))
reject('old_full_is_not_in_new_suite',lambda:r.validate('mini_after_cast_real_matrix','',None,Path('.')))
# The newly retained buffed-sale44 pure also must ignore new UNKNOWN count/readiness.
lines=[]
for name,n in r.BUFFED_SALE_PURE_MARKERS.items():lines.extend(['PASS '+name]*n)
for prefix,n in r.BUFFED_SALE_PURE_PREFIX_COUNTS.items():lines.extend(['PASS '+prefix+str(i) for i in range(n)])
assert len(lines)==44
summary={'passed':44,'failed':0,'failures':[],'real_game_run':False,'actual_provenance_proven':False,'scope':r.BUFFED_SALE_PURE_SCOPE}
log='\n'.join(lines+['DARKCREST_LAVA_BUFFED_SALE_CONTENT_CONTRACT '+json.dumps(summary)])+'\n'
assert r.validate('lava_buffed_sale_content_contract',log,44,Path('.'))==(44,None);checks.append('legacy_buffed44_independent_of_new_unknown_metadata')
reject('legacy_buffed_missing_marker_rejected',lambda:r.validate('lava_buffed_sale_content_contract',log.replace(lines[0]+'\n','',1),44,Path('.')))
reject('prior_buffed_full_not_repeated',lambda:r.validate('lava_buffed_sale_real_matrix','',None,Path('.')))
print(json.dumps({'status':'PASS_SYNTHETIC_UNKNOWN_AND_LEGACY_ONLY','passed':len(checks),'checks':checks,'game_started':False,'godot_started':False,'real_source_scanned':False},indent=2))
