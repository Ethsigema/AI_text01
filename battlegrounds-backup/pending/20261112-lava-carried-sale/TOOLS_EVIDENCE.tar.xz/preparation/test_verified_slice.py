"""Synthetic carried-sale explanation tests, not gameplay or publication."""
from copy import deepcopy
import json
from render_verified_slice import render_slice,runner
from test_lava_carried_sale_schema_synthetic import fixture
labels=[x[0] for x in runner.TESTS];commit='a'*40;row,_,n=fixture();checks=[]
s={'source_commit':commit,'runtime_mode':runner.RUNTIME_MODE,'two_runtime_copies':False,'status':'TESTS_VALIDATED_SOURCE_INTEGRITY_PASS','error':None,'validated_tests':labels}
a={'source_commit':commit,'runtime_mode':runner.RUNTIME_MODE,'two_runtime_copies':False,'runner_suite_accepted':True,'status':'PASS_POST_ATTEMPT_SOURCE_AND_EVIDENCE_AUDIT','tests':{k:{'classification':'executed_validated','process_started':True,'revalidated_checks':v if v else n} for k,_,_,v in runner.TESTS}}
f={'source_commit':commit,'status':runner.FINAL_STATUS,'tests':{k:{'passed_checks':v} for k,_,_,v in runner.TESTS},'full_game_processes':1,'full_game_acceptance':False,'default_pool_promoted':False,'old_full_matrices_repeated':False};f['tests'][labels[0]]={'passed_checks':n,'verified_scenario_fields':row}
text=render_slice(s,a,f,row,commit)
for label,ok in [('dynamic_Game_plus42_plus3292',str(n+42+3292) in text),('acquisition_card_level4_not_stars','暗潮的获取牌等级推进至4（不是随从星级变化）' in text),('active_only_not_global','不新增 inactive/off-Darkcrest 全局规则' in text),('two_samples_not_all_counts','真实样本只覆盖2次' in text),('same_round_gate_not_actual_old_sales','仅作两次只读admission观察' in text),('clock_equality_first_command','reset_sequence == current_sequence == first_recruit_sequence' in text),('V1_static_bug_not_Game_failure','已被静态确认' in text and '没有因此运行失败的Game' in text),('current_unused_original_expires','该原unused票原生到期' in text),('not_deep_registry_coverage','不证明deep registry故障分支覆盖' in text),('prior_db9a_not_new_loss','不是本批再次丢失' in text and '不能声称所有unique产物均已保留' in text),('no_actual_shop_rebuy_claim','不是实际商店重买挑战' in text)]:
 assert ok,label;checks.append(label)
for label,mutate in [('wrong_new_pure',lambda x:x[2]['tests'][labels[1]].update(passed_checks=41)),('wrong_commit',lambda x:x[0].update(source_commit='b'*40)),('actual_rebuy_claim',lambda x:x[3].update(actual_lava_rebuy_tested=True)),('source_level_wrong',lambda x:x[3].update(darkcrest_final_tier=3)),('sale_kept1_wrong_case',lambda x:x[3]['sale']['departed_stats'].update(kept=1)),('clock_advanced_by_command',lambda x:x[3]['sale_clock'].update(current_sequence=31)),('clock_equality_not_observed',lambda x:x[3]['sale_clock'].update(reset_equals_current=False)),('used_not_unused_expiry',lambda x:x[3]['unused_expiry'].update(used=True)),('extra_cast',lambda x:x[3]['casts'].append(deepcopy(x[3]['casts'][0]))),('missing_second_reset',lambda x:x[3]['pre_sale_combats'][1].update(recruit_kept=1)),('token_not_fresh',lambda x:x[3].update(replacement_token_uid='u80')),('no_real_history_gate',lambda x:x[3]['sale'].update(owner_bound_history_gate_observed=False))]:
 x=deepcopy([s,a,f,row]);mutate(x)
 try:render_slice(*x,commit)
 except (AssertionError,ValueError):checks.append(label)
 else:raise AssertionError('accepted '+label)
fs={**s,'status':'FAILED_OR_INCOMPLETE_ATTEMPT','error':'synthetic failure','validated_tests':[]};fa={**a,'runner_suite_accepted':False,'status':'FAIL_POST_ATTEMPT_AUDIT','tests':{k:{'classification':'omitted','process_started':False} for k in labels}};fa['tests'][labels[0]]={'classification':'process_failed','process_started':True}
text=render_slice(fs,fa,None,None,commit);assert '13 份纯合同全部未运行' in text;checks.append('first_full_failure_thirteen_not_run')
x=deepcopy(fa);x['tests'][labels[0]]={'classification':'executed_validated','process_started':True,'revalidated_checks':n};x['tests'][labels[1]]={'classification':'process_failed','process_started':True};text=render_slice(fs,x,None,None,commit);assert '明确未启动 12 项' in text and '13 份纯合同全部未运行' not in text;checks.append('new_pure_failure_twelve_not_run')
x=deepcopy(fa);x['tests'][labels[0]]={'classification':'launch_or_execution_without_completion_receipt','process_started':None};text=render_slice(fs,x,None,None,commit);assert '待确认 1 项' in text and '确认启动 0 项' in text;checks.append('uncertain_not_claimed_started')
print(json.dumps({'status':'PASS_SYNTHETIC_CARRIED_RENDERER_ONLY','passed':len(checks),'checks':checks,'game_started':False,'package_created':False,'actual_Game_count_not_inferred':True},indent=2))
