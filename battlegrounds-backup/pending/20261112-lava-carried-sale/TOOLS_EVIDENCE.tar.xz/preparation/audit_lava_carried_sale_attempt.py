"""Read-only audit of one single-runtime carried-buff Lava native-sale compatibility attempt; never launches Godot.

Always distinguish executed, launch-failed, incomplete, preflight-only, omitted,
and validated tests. Source integrity never upgrades failed gameplay to a pass.
Report facts even when other audit checks fail. No run_tree is used or created.
"""
from pathlib import Path
import argparse
import fcntl
import json
import sys
from run_remote_lava_carried_sale import (sha, read_json, write_new, utc, TESTS, require,
    verify_package, validate_paths, snapshot_trees, validate, verify_prepared,
    RUNTIME_MODE, FINAL_STATUS, NEW_TEST_METADATA, require_frozen, PINNED_TESTS, PLANNED_SCOPE)


def classify_attempt(evidence, expected, bindings, restored, prepared):
    results = {}; errors = []; prior_end = None
    for label, source, budget, count in TESTS:
        receipt_path = evidence / (label + '_result.json')
        log_path = evidence / (label + '.log')
        started = evidence / (label + '_STARTED.json')
        intent = evidence / (label + '_LAUNCH_INTENT.json')
        precheck_path = evidence / (label + '_PRECHECK.json')
        row = {'source': source, 'process_started': False, 'classification': 'omitted'}
        results[label] = row
        if not receipt_path.exists():
            if started.exists() or log_path.exists() or intent.exists():
                row['classification'] = 'launch_or_execution_without_completion_receipt'
                row['process_started'] = True if started.exists() else None
                errors.append(label + ': launch/execution outcome uncertain; not omitted or passed')
            elif precheck_path.exists():
                row['classification'] = 'preflight_only_not_started'
            continue
        try:
            result = read_json(receipt_path); row['result'] = result
            row['process_started'] = result.get('process_started')
            require(type(row['process_started']) is bool, 'Missing explicit process_started')
            row['classification'] = 'executed_not_yet_validated' if row['process_started'] else 'launch_failed_not_executed'
            for key, value in bindings.items(): require(result.get(key) == value, 'Result binding mismatch: ' + key)
            require(result['source'] == source and result['runtime_mode'] == RUNTIME_MODE, 'Wrong test/runtime source')
            require(result['source_sha256'] == expected[source]['sha256'], 'Result test hash mismatch')
            wrapper = evidence / (label + '.gd')
            require(result['command'] == ['godot', '--headless', '--path', str(restored), '--script', str(wrapper)], 'Unexpected runtime command')
            require(result['wrapper_sha256'] == prepared[wrapper.name]['sha256'] == sha(wrapper.read_bytes()), 'Wrapper hash mismatch')
            require(log_path.is_file() and sha(log_path.read_bytes()) == result['log_sha256'], 'Log hash mismatch')
            precheck = read_json(precheck_path)
            for key, value in bindings.items(): require(precheck.get(key) == value, 'Precheck binding mismatch: ' + key)
            require(precheck['runtime_tree'] == str(restored) and precheck['source'] == source and precheck['runtime_mode'] == RUNTIME_MODE, 'Precheck wrong runtime')
            observed = evidence / precheck['source_map_file']
            require(observed == evidence / (label + '_source_map.json'), 'Precheck map path mismatch')
            require(sha(observed.read_bytes()) == precheck['observed_source_map_sha256'] and read_json(observed) == expected, 'Full pretest source map mismatch')
            tree = precheck['tree']
            require(tree['matches'] is True and tree['aggregate_sha256'] == bindings['aggregate_sha256'], 'Pretest aggregate mismatch')
            require(all(tree[k] == [] for k in ['missing', 'extra', 'mismatched']), 'Pretest map changed')
            require(result['start_tree'] == tree and result['source_snapshot_matches'] is True, 'Result/precheck mismatch')
            require(result['timeout_seconds'] == budget and type(result['rss_soft_limit']) is int and 0 < result['rss_soft_limit'] <= 4 * 1024**3, 'Budget mismatch')
            if not row['process_started']:
                require(result['exit'] is None and result['reason'] == 'launch_failed', 'Invalid no-process receipt')
                errors.append(label + ': launch failed before process start'); continue
            require(started.is_file(), 'Started process missing start receipt')
            start_record = read_json(started)
            require(start_record['command'] == result['command'] and start_record['source_commit'] == bindings['source_commit'], 'Start receipt binding mismatch')
            require(prior_end is None or result['started_at_utc'] >= prior_end, 'Test processes not serial')
            require(result['finished_at_utc'] >= result['started_at_utc'], 'Invalid process timestamps')
            prior_end = result['finished_at_utc']
            if result['exit'] != 0 or result['reason'] != 'exited':
                row['classification'] = 'process_failed'; errors.append(label + ': process failed'); continue
            log = log_path.read_text(encoding='utf-8')
            passed, scenario = validate(label, log, count, evidence)
            row['classification'] = 'executed_revalidated'
            row['revalidated_checks'] = passed
            validated_path = evidence / (label + '_VALIDATED.json')
            require(validated_path.is_file(), 'Revalidated log has no runner validation receipt')
            saved = read_json(validated_path)
            require(saved['result'] == result and saved['result_sha256'] == sha(receipt_path.read_bytes()), 'Validation/result receipt mismatch')
            require(saved['passed_checks'] == passed and saved['log_sha256'] == result['log_sha256'] and saved['failures'] == [], 'Validation counts/log mismatch')
            if scenario is not None:
                require(saved['verified_scenario_fields'] == scenario and saved['scenario_sha256'] == sha((evidence / NEW_TEST_METADATA['scenario_file']).read_bytes()), 'Scenario binding mismatch')
            row['classification'] = 'executed_validated'
        except Exception as exc:
            if row['classification'] not in ['process_failed', 'launch_failed_not_executed']:
                row['classification'] = 'executed_validation_or_evidence_failed' if row['process_started'] else 'receipt_or_launch_evidence_failed'
            row['audit_error'] = repr(exc); errors.append(label + ': ' + repr(exc))
    return results, errors


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--remote-root', required=True, type=Path)
    parser.add_argument('--candidate', required=True, type=Path)
    parser.add_argument('--restored-snapshot', required=True, type=Path)
    parser.add_argument('--commit', required=True)
    parser.add_argument('--source-map-sha256', required=True)
    parser.add_argument('--aggregate-sha256', required=True)
    parser.add_argument('--report-name', default='POST_ATTEMPT_SOURCE_AUDIT.json', help='New external audit filename; existing files never overwritten')
    args = parser.parse_args()
    root = args.remote_root.resolve(); candidate = args.candidate.resolve(); restored = args.restored_snapshot.resolve()
    tranche = Path(__file__).resolve().parent.parent
    require(args.report_name.endswith('.json') and Path(args.report_name).name == args.report_name, 'Simple external report filename required')
    require(tranche in root.parents and root != tranche, 'Audit only the new tranche remote root')
    require(candidate == tranche / 'candidate', 'Never audit old backups or another candidate')
    require(candidate != restored and candidate not in restored.parents and restored not in candidate.parents, 'Distinct non-nested source roots required')
    require(root in restored.parents and restored.parent in [root, root / 'single_tree_restore'], 'Restore must belong to this current remote root')
    require(not (root / 'run_tree').exists(), 'No second runtime copy allowed')
    output = root / args.report_name
    require(not output.exists(), 'Never overwrite a prior audit')
    lock_path = tranche.parent / 'develop_empty_ghost_20261112/.independent_full_game.lock'
    with lock_path.open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        errors = []; expected = {}; bindings = {'source_commit': args.commit, 'source_map_sha256': args.source_map_sha256, 'aggregate_sha256': args.aggregate_sha256}
        try:
            validate_paths(candidate, restored, tranche)
            _, expected, bindings = verify_package(root / 'package', root / 'INDEPENDENT_RESTORE_VERIFIED.json',
                root / 'FRESH_PACKAGE_DOWNLOAD_VERIFIED.json', args.commit, args.source_map_sha256, args.aggregate_sha256, restored, check_pins=False)
            require_frozen()
            for _, name, _, _ in TESTS:
                require(expected[name]['sha256'] == PINNED_TESTS[name], 'Pinned test changed: ' + name)
        except Exception as exc:
            errors.append('Package/restore/path validation: ' + repr(exc))
        evidence = root / 'independent_tests'
        require(evidence.is_dir() and not evidence.is_symlink(), 'No completed-attempt evidence directory to audit')
        prepared = {}
        try:
            preparation = read_json(evidence / 'PREPARED_FROM_REMOTE.json')
            for key, value in bindings.items(): require(preparation.get(key) == value, 'Preparation binding mismatch: ' + key)
            require(preparation['runtime_mode'] == RUNTIME_MODE and preparation['two_runtime_copies'] is False, 'Wrong preparation runtime mode')
            require(preparation['candidate_path'] == str(candidate) and preparation['restored_snapshot_path'] == str(restored), 'Preparation source paths changed')
            require(preparation['runtime_trees'] == [str(restored)], 'Unexpected additional runtime tree')
            require(preparation['new_test_metadata'] == NEW_TEST_METADATA, 'Prepared test metadata changed')
            require(preparation['runner_sha256'] == sha((Path(__file__).parent / 'run_remote_lava_carried_sale.py').read_bytes()), 'Runner bytes changed after launch')
            prepared = preparation['entries']; verify_prepared(evidence, prepared)
        except Exception as exc: errors.append('Preparation: ' + repr(exc))
        # Full byte scans of both distinct roots even if earlier audit checks fail.
        prefix = 'AUDIT_' + output.stem
        trees = snapshot_trees(candidate, restored, expected, args.aggregate_sha256, evidence, prefix)
        if not expected: errors.append('No trusted complete map; source match cannot be asserted')
        if not all(row['matches'] for row in trees.values()): errors.append('Candidate/restored post-attempt source mismatch')
        results, test_errors = classify_attempt(evidence, expected, bindings, restored, prepared)
        errors.extend(test_errors)
        accepted = False
        final_path = root / 'INDEPENDENT_GAME_VERIFICATION.json'
        if final_path.exists():
            try:
                final = read_json(final_path)
                for key, value in bindings.items(): require(final.get(key) == value, 'Final receipt binding mismatch: ' + key)
                require(final['status'] == FINAL_STATUS and final['runtime_mode'] == RUNTIME_MODE and final['two_runtime_copies'] is False, 'Final runtime/status mismatch')
                require(final['runtime_trees'] == [str(restored)] and final['source_integrity_trees'] == [str(candidate), str(restored)], 'Final source/runtime paths mismatch')
                require(final['full_game_processes'] == 1 and final['sequential_game_execution'] is True and final['old_full_matrices_repeated'] is False, 'Final process scope mismatch')
                require(final['planned_scope'] == PLANNED_SCOPE and final['new_test_metadata'] == NEW_TEST_METADATA, 'Final reviewed test scope changed')
                require(final['new_native_permanence_algorithm_added'] is False and final['full_game_acceptance'] is False and final['default_pool_promoted'] is False, 'Final receipt overclaims native behavior or broader acceptance')
                require(set(final['tests']) == set(results), 'Final tests incomplete')
                require(all(x['classification'] == 'executed_validated' for x in results.values()), 'Final receipt present with unvalidated/omitted tests')
                for label in results:
                    require(final['tests'][label] == read_json(evidence / (label + '_VALIDATED.json')), 'Final test receipt changed: ' + label)
                require(all(final['trees'][k]['matches'] is True and final['trees'][k]['aggregate_sha256'] == args.aggregate_sha256 for k in ['candidate', 'restored_snapshot']), 'Final tree hashes invalid')
                accepted = not errors
            except Exception as exc: errors.append('Final receipt: ' + repr(exc))
        executed = [label for label, row in results.items() if row.get('process_started') is True]
        omitted = [label for label, row in results.items() if row['classification'] == 'omitted']
        report = {'status': 'PASS_POST_ATTEMPT_SOURCE_AND_EVIDENCE_AUDIT' if not errors else 'FAIL_POST_ATTEMPT_AUDIT',
                  'verified_at_utc': utc(), **bindings, 'trees': trees, 'errors': errors,
                  'runtime_mode': RUNTIME_MODE, 'two_runtime_copies': False,
                  'source_integrity_trees': [str(candidate), str(restored)], 'runtime_trees': [str(restored)],
                  'runner_success_receipt_present': final_path.exists(), 'runner_suite_accepted': accepted,
                  'tests': results, 'executed_tests': executed, 'omitted_tests': omitted,
                  'not_run_tests_are_not_passes': True, 'source_integrity_is_not_gameplay_acceptance': True,
                  'note': 'Failed/unknown tests remain failed/unknown; omitted tests remain not run. Only one restored runtime was used.',
                  'godot_or_game_started_by_audit': False}
        write_new(output, report)
        print(json.dumps({'status': report['status'], 'suite_accepted': accepted, 'executed': executed, 'omitted': omitted, 'errors': errors}))
        if errors: sys.exit(1)


if __name__ == '__main__':
    main()
