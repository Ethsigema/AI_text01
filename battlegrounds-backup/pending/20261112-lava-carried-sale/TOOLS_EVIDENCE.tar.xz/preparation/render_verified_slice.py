"""Pure Chinese carried-buff Lava-sale evidence renderer, no Game, uploads or invented totals."""
import json
import run_remote_lava_carried_sale as runner

def render_slice(summary,audit,final,scenario,commit):
 from packaging_common import outcome_metadata
 outcome=outcome_metadata(summary,audit,final)
 assert all(row.get('source_commit')==commit for row in [summary,audit]+([final] if final else []))
 if outcome=='failure':
  assert scenario is None
  classes={key:value['classification'] for key,value in audit['tests'].items()}
  executed=[key for key,value in audit['tests'].items() if value.get('process_started') is True]
  omitted=[key for key,value in audit['tests'].items() if value['classification']=='omitted']
  not_started=[key for key,value in audit['tests'].items() if value['classification'] in ['omitted','preflight_only_not_started','launch_failed_not_executed']]
  uncertain=[key for key,value in audit['tests'].items() if value['classification']=='launch_or_execution_without_completion_receipt']
  validated={key:value['revalidated_checks'] for key,value in audit['tests'].items() if value['classification']=='executed_validated'}
  assert all(type(n) is int and n>0 for n in validated.values())
  prefix='首次新 Game 失败，后续 13 份纯合同全部未运行，不能计为通过。\n\n' if classes[runner.TESTS[0][0]]=='process_failed' and len(omitted)==13 else ''
  detail='\n'.join('- '+key+'：'+value for key,value in classes.items())
  return f'''# Carried-buff Lava 原生出售切片未获验收

源码：{commit}。本次失败或未完成，未运行、结果不明或证据不足项目不计为通过。

{prefix}确认启动 {len(executed)} 项；明确未启动 {len(not_started)} 项，其中完全未运行 {len(omitted)} 项；结果待确认 {len(uncertain)} 项。审计验证的检查数仅为 {validated}。

新 pure 的预冻结数（{runner.NEW_TEST_METADATA.get('pure_checks')}）与既有12份纯合同3292项不能自动算作本轮通过。原错误：{summary.get('error')}。

逐测试分类：
{detail}

原日志、源码与完整源哈希观察均保留，不通过包装改变结论。旧完整Game不重跑；本页不表示默认启用、全卡池或全游戏验收。
'''
 assert runner.NEW_VALIDATORS_READY is True and isinstance(scenario,dict)
 full=final['tests']['lava_carried_sale_real_matrix'];assert full['verified_scenario_fields']==scenario
 actual_full=full['passed_checks'];assert type(actual_full) is int and actual_full>0
 pure={key:value['passed_checks'] for key,value in final['tests'].items() if key!='lava_carried_sale_real_matrix'}
 expected={label:count for label,_,_,count in runner.TESTS[1:]};assert pure==expected and all(type(n) is int and n>0 for n in pure.values())
 new_pure=pure['lava_carried_sale_content_contract'];assert new_pure==runner.NEW_TEST_METADATA['pure_checks']
 old_pure=sum(n for k,n in pure.items() if k!='lava_carried_sale_content_contract');assert old_pure==3292
 assert scenario['scope']==runner.CARRIED_SALE_SCOPE and len(scenario['casts'])==len(scenario['pre_sale_combats'])==2
 assert scenario['darkcrest_final_tier']==4 and scenario['coin_pre_source_fixture'] is True
 assert all(scenario[k] is False for k in ['entirely_natural_game','actual_lava_rebuy_tested','old_full_matrix_repeated'])
 sale=scenario['sale'];clock=scenario['sale_clock'];expiry=scenario['unused_expiry']
 assert sale['lava_uid']==scenario['lava_uid'] and sale['mini_uid']==scenario['mini_uid'] and sale['departed_stats']=={'attack':6,'health':5,'kept':0}
 assert sale['retirement']['round']==3 and sale['retirement']['owner']==0 and sale['retirement']['mini_buffed'] is True
 assert 0<clock['last_cast_sequence']<clock['reset_sequence']==clock['current_sequence']==clock['first_recruit_sequence']==sale['retirement']['sequence']
 assert clock['reset_equals_current'] is True and clock['first_after_reset'] is True
 assert sale['owner_bound_history_gate_observed'] is True and sale['actual_shop_buy_attempted'] is False and sale['preview_not_actual_rebuy'] is True
 assert (sale['native_preview_attack'],sale['native_preview_health'])==(2,5)
 for i,cast in enumerate(scenario['casts']):
  assert cast['source_uid']==scenario['mini_uid'] and cast['target_uid']==scenario['lava_uid'] and (cast['round'],cast['attack_before'],cast['attack_after'],cast['health'],cast['kept'])==(i+1,2+2*i,4+2*i,5,1)
  combat=scenario['pre_sale_combats'][i];assert (combat['round'],combat['recruit_attack'],combat['recruit_health'],combat['recruit_kept'])==(i+1,4+2*i,5,0)
 assert expiry['used'] is False and expiry['expired'] is True and expiry['spells_before']==expiry['spells_after']
 assert scenario['preserved_token_uid']!=scenario['replacement_token_uid']
 return f'''# 已验证的有限玩法：跨轮永久增益 Lava 出售并保留当前原票

源码：{commit}。仅 active 暗潮路径，不新增 inactive/off-Darkcrest 全局规则。

原普通Mini在两轮分别原生发出原三叉戟，对同一原普通Lava首次塑造，2/5 → 4/5 → 6/5。前两次真实非空combat及next recruit保留永久增益并原生reset。跨到round3时Lava为6/5、kept0，Mini仍活着且已有当前未用ready票；公开sell出售原Lava，原生返金返池，当前原手牌和Mini权限不变，native factory preview仍2/5，不污染库存。

实际出售发生于reset后的首条命令边界：last_cast_sequence < reset_sequence == current_sequence == first_recruit_sequence。只读history观察没有额外命令推进时钟。V1的>=拒绝合法相等边界已被静态确认，V2改为>；此前没有因此运行失败的Game，不把静态问题写成实战失败。

售后对Mini的实际施法请求因没有Lava目标而拒绝、原ready票未消费。第3次真实非空combat后，该原unused票原生到期，施法计数不增；round4原Mini再发不同UID新票，已售Lava不在。暗潮的获取牌等级推进至4（不是随从星级变化）。

实现按真实完整cast/reset凭据允许合法steps>=1，真实样本只覆盖2次，不能称所有计数均已验收。前两轮kept1的same-round sale preflight仅作两次只读admission观察，不是又执行两次旧sale实战。退休历史的owner-bound rebuy gate被观察到，不是实际商店重买挑战。禁金色、新目标、退役Mini和buffed Lava重买；不代表默认启用或全游戏验收，不新增Lava永久塑造或原生出售算法。

实际检查：新Game {actual_full} 项；新pure {new_pure} 项；12份旧纯合同 {old_pure} 项；总计 {actual_full+new_pure+old_pure} 项。一次新Game、唯一新restored_snapshot runtime，candidate与恢复树各完整SHA核验；旧完整Game不重跑。资金使用暗潮激活前Coin夹具，不称完全自然对局。新pure仅actual-only早拒，不证明deep registry故障分支覆盖或伪造原生权限。

历史保留例外：上一批db9a67c511460b5d84e280e198290f309635c4f9b1a4ac978ec2ef1f3e0cc798未发布研究封装原字节已丢失，不是本批再次丢失；两份源码原SHA与保存差分可精确恢复，不能声称所有unique产物均已保留。旧静态43误计不曾执行成一次Game失败。本批修订继续原版本另路径保留。
''' 

ACQUISITION_LEVEL_WORDING = '暗潮的获取牌等级推进至4（不是随从星级变化）'
HISTORICAL_RETENTION_NOTE = '上一批db9a原研究封装已丢失，不是本批再次丢失；源码原SHA及差分可恢复，不声称所有unique都保留。'
