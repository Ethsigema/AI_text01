extends "res://tests/darkcrest_mini_after_cast_20261112/content_contract.gd"
class PretendLavaHost:
 extends RefCounted
 var _lava_play
 static func actual(_game) -> bool:return true
func _initialize():
 check(Sources.proof_error().is_empty(),"complete_buffed_sale_source_runtime_proof")
 var host=Host.new();var helper=host.LavaPlay.new();var owner={"id":0}
 check(not helper.buffed_sale_history(owner),"empty_history_not_buffed_departure")
 for id in range(8):
  helper._retired={"u10":{"owner":id,"round":1,"sequence":2,"mini_buffed":true}}
  check(helper.buffed_sale_history({"id":id}),"detached_buffed_history_denial_owner_"+str(id))
  check(not helper.buffed_sale_history({"id":(id+1)%8}),"other_owner_history_not_applied_"+str(id))
 for value in [null,true,0.0,"0"]:
  helper._retired={"u10":{"owner":value,"mini_buffed":true}}
  check(not helper.buffed_sale_history(owner),"invalid_history_owner_type_"+str(value))
 for value in [null,false,0,1,"true"]:
  helper._retired={"u10":{"owner":0,"mini_buffed":value}}
  check(not helper.buffed_sale_history(owner),"invalid_history_buff_flag_"+str(value))
 helper._retired={"u10":{"owner":0,"round":1,"sequence":2}}
 check(not helper.buffed_sale_history(owner),"untouched_native_sale_history_not_blocked")
 helper._retired={"u10":{"owner":1,"mini_buffed":true},"u11":{"owner":0,"mini_buffed":true}}
 var before=helper._retired.duplicate(true)
 check(helper.buffed_sale_history(owner),"mixed_history_finds_only_matching_denial")
 check(host.purchase_value_same(before,helper._retired),"history_predicate_does_not_mutate_records")
 # These dictionaries exercise denial content only, never prove a native retirement.
 helper._retired={"u12":{"owner":0,"mini_buffed":true}}
 check(helper.buffed_sale_history(owner),"fabricated_history_shape_is_denial_not_authority")
 helper._retired={}
 check(not helper.buffed_sale_history(owner),"isolated_history_reset_shape_only")
 var pretend=PretendLavaHost.new();pretend._lava_play=helper
 for fake_game in [{},RefCounted.new()]:
  check(not helper.buffed_sale_error(pretend,fake_game,owner,{"uid":"u40"}).is_empty(),"fake_actual_buffed_sale_authority_refused")
  check(not helper.sale_preflight(pretend,fake_game,owner,{"uid":"u40"}).is_empty(),"fake_buffed_sale_preflight_refused")
  check(not helper.begin_sale(pretend,fake_game,owner,0,{}).is_empty(),"fake_native_buffed_sale_context_refused")
 for steps in [null,0,1,2,1.0]:
  helper._board={"u40":{"unit":{"uid":"u40"},"mini_steps":steps,"mini_round":1}}
  check(not helper.buffed_sale_error(pretend,{},owner,{"uid":"u40"}).is_empty(),"unissued_buff_receipt_never_authorizes_sale_"+str(steps))
 check(helper._sale_pending.is_empty() and helper._retired.is_empty(),"fake_calls_create_no_success_or_retirement")
 print("DARKCREST_LAVA_BUFFED_SALE_CONTENT_CONTRACT ",JSON.stringify({"passed":passed,"failed":failed,"failures":failures,"real_game_run":false,"actual_provenance_proven":false,"scope":"buffed departure denial history and unbound refusal only"}))
 quit(0 if failed==0 else 1)
