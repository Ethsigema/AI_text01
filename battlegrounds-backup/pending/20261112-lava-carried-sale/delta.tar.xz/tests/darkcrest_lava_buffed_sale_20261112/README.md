# Buffed ordinary Lava native sale: frozen test scope

Production interface V2 and these test sources are statically frozen. Pure expected count is44, not an actual passed count; execution is still pending. Earlier V1/V2/V3 records, original README and all prior packages remain unchanged. This V4 directory preserves both GDScript files byte-for-byte and replaces only the delivery README.

Canonical paths: tests/darkcrest_lava_buffed_sale_20261112/{content_contract.gd,real_matrix.gd,README.md}.

## One new real Game

Use the already established four-player seed20261120 room, same Game/Catalog, original public acquisitions and unchanged random domain. Pre-source funding explicitly uses native factory/add_hand/public Coin casting. This is not a fixture-free natural match.

Original Mini publicplay/Waiting issues the original Trident. One first-of-turn public cast permanently changes the same ordinary Lava2/5→4/5, kept1. Original Mini must still be an authenticated live board source before public sale of that Lava. The sale must remove only original Lava, return exactly gold+1/pool+1/sold+1, leave UID/RNG/spellpool and remaining hand/board unchanged, retire original Lava authority and preserve live Mini and its token-record references/facts.

One actual nonempty combat/recruit must contain Mini but not departed Lava. Darkcrest grows1→2. Original live Mini must issue a distinct fresh token. With no Lava present, public casting on Mini must be held without consuming the token or mutating live state.

The new test overrides inherited cast_first only to remove the obsolete buffed-Lava-sale-held command; all other original positive cast and negative token/target checks remain. No old full Game initializer or complete matrix is repeated.

## Denial history and preview boundaries

Actual buffed departure records owner-bound mini_buffed retirement history. SameGame buy/play gates must return the exact buffed-rebuy/reentry refusal and leave full state unchanged; history must persist after next recruit. These are observations of a gate fed by an actual native retirement, not an actual shop purchase or full rebuy transaction. The longer chain in which Mini is later sold and Lava is bought is NOT executed here.

A local originalfactory preview after sale must remain ordinary2/5 kept0 with no allocation or live-state change. This is factory-shape/no-leak evidence, not actual rebuy or a fresh shop offer. The earlier token preview is likewise shape-only; authentic Waiting issuance remains independently mandatory.

## Pure contract and limitations

44 static checks = eight singleton assertions, six fake-game calls, and30 range/variant assertions. Pure history dictionaries exercise owner-bound denial content only; they do not prove native retirement or grant any authority. Fake/unbound rejection stops at actual-authority checks and does not prove deeper malformed buff-receipt branches.

V2 explicitly checks Mini.board_error before consumed-history admission. The real success path checks original Mini identity and live custody before sale and confirms Mini remains live afterward. The reverse chain cast→sell Mini→attempt sell Lava is NOT live-tested; its rejection is supported only by production gate/static review, not fault injection.

No second Mini, golden, multiple buffs, other targets, actual buffed-Lava rebuy, native partial-sale failure injection, default-pool promotion, UI/save or whole-game acceptance. Original Lava permanence algorithm already exists; this is finite compatibility and native sale admission only. Old tests and failed evidence remain preserved.
