from pathlib import Path
import json,hashlib,tarfile,io,ast
R=Path.cwd();P=Path(__file__).resolve().parent;sha=lambda b:hashlib.sha256(b).hexdigest();enc=lambda d:(json.dumps(d,indent=2,sort_keys=True)+'\n').encode();files={}
for x in json.loads((P/'LOCAL_ONLY_SMALL_EVIDENCE.json').read_text())['records']:
 b=(R/x['path']).read_bytes();assert sha(b)==x['sha256'];files[x['path']]=b
for p in [P/'readonly_cleanup_preflight.py',P/'CLEANUP_PREFLIGHT.json',P/'CLEANUP_PREFLIGHT.log',P/'LOCAL_ONLY_SMALL_EVIDENCE.json',P/'build_pre_cleanup_audit.py',R/'develop_lava_next_20261112/preparation/cleanup_preflight.py']:
 b=p.read_bytes();files[p.relative_to(R).as_posix()]=b
 if p.suffix=='.py':ast.parse(b)
out=P/'pre_cleanup_evidence_package';out.mkdir(exist_ok=False)
with tarfile.open(out/'LATE_EVIDENCE.tar.xz','w:xz') as t:
 for n,b in sorted(files.items()):
  info=tarfile.TarInfo(n);info.size=len(b);info.mode=0o644;info.mtime=0;t.addfile(info,io.BytesIO(b))
mem={n:{'bytes':len(b),'sha256':sha(b)} for n,b in files.items()}
with tarfile.open(out/'LATE_EVIDENCE.tar.xz') as t:assert {x.name:{'bytes':x.size,'sha256':sha(t.extractfile(x).read())} for x in t if x.isfile()}==mem
(out/'LATE_EVIDENCE_MANIFEST.json').write_bytes(enc({'archive_sha256':sha((out/'LATE_EVIDENCE.tar.xz').read_bytes()),'members':mem}))
(out/'README.md').write_text('''# 跨回合永久增益Lava出售新批清理前只读证据

本包保存上一批f793审计实际回读与验证器等6项晚证据、本轮两个冗余副本完整路径集/长度/SHA/aggregate预检与脚本。尚未删除、copy、下载或运行Game，不是删除授权。

1. develop_lava_buffed_sale_20261112/candidate 等价于保留 remote_snapshot_b749349/single_tree_restore/restored_snapshot，27991文件。
2. 成功Lava批 fresh_remote/restored_tier6 等价于保留 develop_darkcrest_tier6_20261112/remote_snapshot_dd428c2/restored_snapshot，27968文件；已核固定15dcc575包和原TIER6_RESTORE报告及该批完整下载依赖，确属完成使用的依赖中间树，不是最终remote snapshot。

所有备份/下载/package/最终remote/失败树/日志及唯一未核验内容保留。仅未来明确授权且锁内再次全核后才能清理这两个对象。历史脚本若引用中间路径，须显式使用保留等价源，不暗改旧脚本。

预计fileblocks可回收3,238,641,664B，清后约5,291,991,040B，新copy+fresh55+单restore后约1,717,079,040B；实际释放以后续执行回执为准。

已知历史例外：未发布研究db9a初始tar封装丢失，未恢复；最终源码与diff可精确恢复并不代表该封装找回。不能声称所有历史unique从未丢失。本次未涉及该失败历史或改写其证据。

先核SHA256SUMS，再逐LATE_EVIDENCE_MANIFEST校验regular成员。只解到新空目录，不覆盖工程。完整工程仍以source b74934926d8e5eaeb4a9b27328cd07da3da54007/final49f3a8d59dd2a5c6f6d5e399887ba41f39500bdb及原Release/base14恢复，新范围尚未验收。
''')
(out/'SHA256SUMS.txt').write_text(''.join(sha(p.read_bytes())+'  '+p.name+'\n' for p in sorted(out.iterdir()) if p.name!='SHA256SUMS.txt'))
folder='battlegrounds-backup/audits/20261112T1715Z-pre-carried-sale-cleanup';rows=[]
for p in sorted(out.iterdir()):
 b=p.read_bytes();rows.append({'name':p.name,'path':folder+'/'+p.name,'bytes':len(b),'sha256':sha(b),'git_sha':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()})
d={'status':'FROZEN_PRE_CLEANUP_EVIDENCE_NOT_UPLOADED_NO_DELETION','remote_folder':folder,'files':len(rows),'bytes':sum(x['bytes'] for x in rows),'members':len(mem),'records':rows};(P/'PRE_CLEANUP_UPLOAD_METADATA.json').write_bytes(enc(d));print(json.dumps({k:v for k,v in d.items() if k!='records'},indent=2))
