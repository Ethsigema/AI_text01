from pathlib import Path
import json,gzip,hashlib,fcntl,shutil,tarfile
R=Path.cwd();P=Path(__file__).resolve().parent;sha=lambda b:hashlib.sha256(b).hexdigest();read=lambda p:json.loads(p.read_text())
ns={};exec((R/'develop_lava_next_20261112/preparation/cleanup_preflight.py').read_text().split('specs=')[0],ns);scan=ns['scan'];sums=ns['sums']
pre=read(P/'CLEANUP_PREFLIGHT.json');pub=read(P/'PRE_CLEANUP_PUBLICATION_VERIFIED.json');assert pub['commit']=='db6f28fe99a7adb041d595098c6c6c68540e1ec2' and pub['every_member_rehashed']
for x in pub['records']:
 b=(Path(pub['download_directory'])/x['name']).read_bytes();assert len(b)==x['bytes'] and sha(b)==x['sha256']
with tarfile.open(Path(pub['download_directory'])/'LATE_EVIDENCE.tar.xz') as t:assert t.extractfile('develop_lava_carried_sale_20261112/preparation/CLEANUP_PREFLIGHT.json').read()==(P/'CLEANUP_PREFLIGHT.json').read_bytes()
allowed=[R/'develop_lava_buffed_sale_20261112/candidate',R/'develop_darkcrest_lava_20261112/fresh_remote/restored_tier6'];assert [Path(x['target']) for x in pre['targets']]==allowed
with Path(pre['common_lock']).open('r') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);before=shutil.disk_usage(R)._asdict();checks=[];preserved=[]
 for row in pre['targets']:
  target=Path(row['target']);restore=Path(row['equivalent_preserved_tree']);pkg=Path(row['source_package']);raw=gzip.decompress((pkg/'SOURCE_MAP.json.gz').read_bytes());assert sha(raw)==row['source_map_sha256'] and sha((pkg/'MANIFEST.json').read_bytes())==row['manifest_sha256'];assert sha(Path(row['publication_receipt']).read_bytes())==row['publication_receipt_sha256'];expected=json.loads(raw)
  a=scan(target,expected,row['aggregate_sha256']);b=scan(restore,expected,row['aggregate_sha256']);assert a==row['target_full_check'] and b==row['equivalent_full_check'];sums(pkg)
  for q in map(Path,row['preserved_paths']):
   assert q.exists();preserved.append(q)
   if q.is_dir() and (q/'SHA256SUMS.txt').exists():sums(q)
  checks.append({'target':str(target),'equivalent':str(restore),'target_check':a,'equivalent_check':b})
 # Recheck complete same-stage original dependencies before deletion.
 fresh=R/'develop_darkcrest_lava_20261112/fresh_remote'
 for x in read(fresh/'FRESH_DOWNLOAD_VERIFIED.json')['records']:
  b=(fresh/x['filename']).read_bytes();assert len(b)==x['bytes'] and sha(b)==x['sha256']
 for q in allowed:shutil.rmtree(q)
 assert all(not q.exists() for q in allowed) and all(q.exists() for q in preserved)
 after=shutil.disk_usage(R)._asdict();report={'status':'AUTHORIZED_EXACT_TWO_NON_BACKUP_DUPLICATES_REMOVED','deleted_paths':list(map(str,allowed)),'checks':checks,'preserved_paths':list(map(str,preserved)),'before_disk':before,'after_disk':after,'available_bytes_increase':after['free']-before['free'],'old_scripts_unchanged':True,'backups_deleted':False,'game_started':False};(P/'CLEANUP_EXECUTED.json').write_text(json.dumps(report,indent=2)+'\n');print('CLEANUP_DONE',report['available_bytes_increase'],flush=True)
 source=R/'develop_lava_buffed_sale_20261112/remote_snapshot_b749349/single_tree_restore/restored_snapshot';pkg=source.parent.parent/'package';raw=gzip.decompress((pkg/'SOURCE_MAP.json.gz').read_bytes());expected=json.loads(raw);m=read(pkg/'MANIFEST.json');one=scan(source,expected,m['aggregate_sha256']);two=scan(source,expected,m['aggregate_sha256']);assert one==two;dest=P.parent/'candidate';assert not dest.exists();shutil.copytree(source,dest);copied=scan(dest,expected,m['aggregate_sha256']);assert {k:v for k,v in one.items() if k!='allocated_file_bytes'}=={k:v for k,v in copied.items() if k!='allocated_file_bytes'}
 (P/'CANDIDATE_PREIMAGE_SOURCE_MAP.json').write_bytes(raw);(P/'CANDIDATE_PREIMAGE_SOURCE_SHA256.json').write_text(json.dumps({n:x['sha256'] for n,x in expected.items()},indent=2,sort_keys=True)+'\n');d={'status':'PASS_ACCEPTED_B749_SOURCE_DOUBLE_READ_INDEPENDENT_COPY','source_commit':'b74934926d8e5eaeb4a9b27328cd07da3da54007','final_commit':'49f3a8d59dd2a5c6f6d5e399887ba41f39500bdb','source':str(source),'candidate':str(dest),'source_map_sha256':sha(raw),'source_first_read':one,'source_second_read':two,'candidate_verified':copied,'no_hardlinks':True,'game_started':False,'disk':shutil.disk_usage(R)._asdict()};(P/'CANDIDATE_PREIMAGE_VERIFIED.json').write_text(json.dumps(d,indent=2)+'\n');print('CANDIDATE_READY',d['disk'],flush=True)
