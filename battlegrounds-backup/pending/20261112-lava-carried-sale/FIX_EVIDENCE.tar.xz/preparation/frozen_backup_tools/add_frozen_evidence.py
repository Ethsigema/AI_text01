"""Run only after explicit package-build authorization. No Game/source edits/upload."""
from common import *
import argparse,re,tarfile,io

def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--execute',action='store_true',required=True);ap.add_argument('--evidence-list',type=Path,required=True);ap.add_argument('--expected-pins',type=int,required=True);ap.add_argument('--expected-pin-updates',type=int,required=True);args=ap.parse_args()
 stage=ROOT.parent;source=stage/'candidate';out=stage/'unaccepted_package'
 assert out.is_dir() and not (out/'FIX_EVIDENCE.tar.xz').exists()
 m=json.loads((out/'MANIFEST.json').read_text());expected=json.loads(gzip.decompress((out/'SOURCE_MAP.json.gz').read_bytes()));verify(source,expected,m['aggregate_sha256'])
 pat=re.compile(r'("((?:res://)?[^"\n]+\.[a-z0-9]+)"\s*:\s*")([0-9a-f]{64})(")');checks=0
 for f in sorted(source.glob('core/*.gd')):
  for match in pat.finditer(f.read_text()):
   target=source/match[2].removeprefix('res://')
   if target.is_file():assert sha(target.read_bytes())==match[3],str(target);checks+=1
 pins=[json.loads(p.read_text()) for p in sorted((stage/'evidence').glob('PIN_UPDATES_*.json'))]
 assert checks==args.expected_pins and sum(len(p['updates']) for p in pins)==args.expected_pin_updates
 selected=json.loads(args.evidence_list.read_text());assert isinstance(selected,list) and selected and len(set(selected))==len(selected)
 files={};excluded=[]
 for n in selected:
  assert safe(n) and n.split('/')[0] in {'preparation','research','evidence'}
  assert not any(x in {'cache','config','data','home','__pycache__','.godot','parse_env'} for x in Path(n).parts)
  p=stage/n;assert p.is_file() and not p.is_symlink() and p.stat().st_size<=8*1024**2
  assert p.suffix in {'.gd','.log','.json','.py','.txt','.md','.gz','.xz','.diff'}
  before=p.stat();data=p.read_bytes();after=p.stat();assert (before.st_size,before.st_mtime_ns)==(after.st_size,after.st_mtime_ns),n
  files[n]=data
 static={'status':'PASS_STATIC_FROZEN_BYTES_ONLY_NOT_GAME_ACCEPTANCE','checked_at_utc':utc(),'source_map_sha256':m['source_map_sha256'],'aggregate_sha256':m['aggregate_sha256'],'declared_file_sha_matches':checks,'recorded_pin_updates':args.expected_pin_updates,'small_evidence_included':len(files),'evidence_capture_note':'Only explicitly captured completed files; later-added or modified preparation scripts are not claimed included','excluded':excluded,'failure_logs_preserved_unedited':True,'historical_results_not_current_gameplay_acceptance':True,'pure_contracts_not_actual_acquisition':True,'empty_slot_candidates_excluded':True,'game_started':False}
 write(out/'STATIC_SHA_VERIFIED.json',static);files['STATIC_SHA_VERIFIED.json']=(out/'STATIC_SHA_VERIFIED.json').read_bytes()
 with tarfile.open(out/'FIX_EVIDENCE.tar.xz','w:xz') as t:
  for n,b in sorted(files.items()):
   x=tarfile.TarInfo(n);x.size=len(b);x.mode=0o644;x.mtime=0;t.addfile(x,io.BytesIO(b))
 membermap={n:{'bytes':len(b),'sha256':sha(b)} for n,b in sorted(files.items())};write(out/'FIX_EVIDENCE_MANIFEST.json',membermap)
 with tarfile.open(out/'FIX_EVIDENCE.tar.xz') as t:assert {x.name:{'bytes':x.size,'sha256':sha(t.extractfile(x).read())} for x in t}==membermap
 (out/'SHA256SUMS.txt').write_text(''.join(sha(p.read_bytes())+'  '+p.name+'\n' for p in sorted(out.iterdir()) if p.is_file() and p.name!='SHA256SUMS.txt'))
 verify(source,expected,m['aggregate_sha256']);records=[]
 for p in sorted(out.iterdir()):
  assert p.is_file();b=p.read_bytes();records.append({'name':p.name,'path':REMOTE_FOLDER+'/'+p.name,'bytes':len(b),'size':len(b),'sha256':sha(b),'git_sha':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()})
 metadata={'status':STATUS,'remote_folder':REMOTE_FOLDER,'created_at_utc':utc(),'files':len(records),'bytes':sum(x['bytes'] for x in records),'source_map_sha256':m['source_map_sha256'],'aggregate_sha256':m['aggregate_sha256'],'evidence_members':len(files),'records':records};write(stage/'PACKAGE_UPLOAD_METADATA.json',metadata)
 print(json.dumps({k:v for k,v in metadata.items() if k!='records'},indent=2))
if __name__=='__main__':main()
