# Carried Lava sale V1 独立静态审查

结论：有一项原生时序阻塞，修复后才建议进入有限验证。未运行 Godot/Game，未修改生产或冻结产物。

## 实际输入
只读 b749349 restored_snapshot 的 Game 与原 helper；逐项读取 CARRIED_SALE_V1.diff 及 overlay_v1 两源码。实际冻结清单名是 `CARRIED_SALE_V1_FROZEN.json`。
- core/darkcrest_mini.gd: ff6d4caf1098e54c6f670f80f483745d5efb27b98878ed6116107818daf9d08c，实际 SHA 匹配。
- core/darkcrest_lava_play.gd: 0a207148f3ea4f98dd3f2533d2aedcb58d34c29cef062b548a057b6a44d0bf8f，实际 SHA 匹配。

## 必修：reset 与下一条命令可以同 sequence
Game:3289 在成功命令尾部自增 command_sequence；3295–3296 才在 end_turn 分支调用 _finish_round，后者11712调用 _begin_round。原 reset_begin/complete 位于12088–12116，记录的是已经自增后的序号。下一轮第一条 public sale 在命令尾部自增前执行，因此合法 reset_sequence == sale 当前 sequence。
V1 history kept0 分支以 mini_reset_sequence >= game.state.command_sequence 拒绝，会误拒该正常首条出售。最小建议仅拒大于当前序号，保持 last_cast_sequence < reset_sequence。两者不是同一语义：cast 在此前独立 play 的尾部自增前记录，reset 在 end_turn 自增后记录。不要用先执行一条无关命令规避问题；真实测试应在下一 recruit 第一条命令前只读观察 sale_preflight。

## 其余已核边界
- 新 last_cast_round/sequence 只在原完整 cast suffix 比较通过后与 used ledger 一起记录；reset 标量只在原 reset window 和 expected state 核验通过后写入。未见旧 record 回填；mini_round 仍为最近 reset/当前 cast 观察轮。
- history 入口绑定 actual Game/owned helper、原 Lava registry record；原 Mini board_error 同时要求真实对象、同 owner、alive 在场、未 retired/poison。Lava 同样由原 custody/snapshot 校验，不靠裸形状赋权。
- 遍历私有原 token registry，key/unit UID、owner/source、原 token snapshot、ready/used/expired 类型、每轮唯一、used target、全 zone 消失及先前 sequence 均核验。used 数等于 steps，按 round 排序序号严格递增，最近 cast 与新增私有标量匹配。
- kept1 要求本轮已消费且无本轮 ready；kept0 要求旧轮消费、恰一本轮原 ready 手票、原 reset 回执。旧未用 token 必须已记录 expired 且不在任何 zone，不能当 buff 计数。
- 原 sale begin/finish 全手牌、其他战队、原 token refs/facts、金币/库存/UID/RNG 会计未改；真实离场即 retire 并保留 owner-bound buffed buy/play deny。未动 untouched 分支及 Mini 出售规则。
- 同轮合法旧路径需要本次新源码从原 cast 产生 markers，不应把旧运行态没有 markers 的对象追认为已证明历史。

## 未验证
静态不保证真实房间通过。纯42仅 fake actual 早拒不证明深层负例。待测：实际两次 native cast 的历史累积、下轮第一命令 sale 可行、ready 手票不变、实际 combat 后 unused expiry/regrant。未扩 golden、第二 Mini、其他目标、retired Mini、inactive 全局权限或 buffed rebuy。
