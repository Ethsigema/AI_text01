# 跨轮累计Lava出售：独立只读最小方案

实际读取b749349固定恢复树Lava.buffed_sale_error、Mini.consumed_sale_error及reset/ledger链，不沿旧diff猜测。未改源码、未跑Game或复制树。

## 时钟必须分清

mini_round不仅在cast成功时更新，也在reset_complete后设为当前round。正常round1/2各cast一次、round3 kept0出售时，mini_round==3，最后cast token.round==2。不能要求lastcast.round==mini_round，否则正常路径必拒。当前mini_round==当前round与精确snapshot/kept0来自原reset观察；历史最后cast轮必须早于当前轮。若要求紧接最后cast下一轮，可明确lastcast.round==当前round-1；不能将此等式误用为当前字段。

## 新分支最小真实权限

仅增加carried kept0分支，保留原same-round steps1/kept1分支和untouched路径。actual owned Game/helper/recruit/无pending、原Lava board_error和原Mini活source board_error必须先核，禁止retired/丢失Mini。steps可安全整数>=1，而实战样本2不成为终身cap。

从真实Mini._tokens registry提取该原source、原owner、原target Lava的历史used记录；每项键与原unit.uid一致，原unit和snapshot未变，ready/used真、非expired、成功cast_sequence整数且早于当前序号，原token全zone已消失。不同历史cast轮应唯一，sequence随轮严格递增；计数精确等于Lava.mini_steps，不能只检count后接受复制/重复值。不同source/target或未知矛盾记录不应被忽略后凑数。

本轮必须唯一该source的原ready未用未expired票，真实hand对象/UID唯一、round本轮、sourceUID相符；不要求它已cast，不将旧used票重新赋权限。历史expired未用票可保留为失效事实，不计入buff次数。所有内容谓词仅负例检查，实际入口仍绑定原registry/owner/unit与原Lava/Mini记录。

## 原sale与未来流程

继续原begin/finish完整native sale，成功保持当前hand票、Mini原source及全部tokens引用/事实、其他board、经济stock/UID/RNG；实际离场即撤Lava权限及mini_buffed退休deny，不rollback。既有owner-bound buy/play deny继续，不能换新UID或先卖Mini绕过有限暗潮边界。pool归还只有数量，不含永久unit。

售后Mini还活着，当前未用票可在原EOT正常expiry，下一recruit原Waiting再发；这本身复用已存在tokenexpiry/source发行链，但本批新增交互需一条真实sale→combat→expiry/regrant证据。无Lava实际target时cast继续held。未要求新target、golden、再购或inactive全局拦截。

结论：范围可控，不需重写buff或reset；关键是别把mini_round当lastcast轮以及别以累计数值shape取代真实历史。等待生产diff再给冻结结论。
