# Carried-buff Lava sale tests V2, not yet executed

Canonical tests/darkcrest_lava_carried_sale_20261112. V1 draft remains untouched. New real scenario inherits approved helpers, overrides initializer, and runs only one new Game. Two genuine first-of-turn Mini casts produce4/5 then6/5, with real combat/recruit resetting kept0 each time. In round3 publicsell original Lava6/5kept0 while the current original unused Mini token stays in hand. Exact sale accounting, UID/RNG/spellpool invariants, original retirement, living Mini and current ready token identity/history are checked. Third nonempty combat/recruit expires that unused token without increasing casts, then Mini issues a distinct original token; Darkcrest4.

Production generic valid mini_steps history is not a hardcoded two-cast allowance; two casts are only this test sample. Native last-cast/reset receipt metadata is issued only by real successful cast/reset; tests do not write live receipts. Actual-only history checks are called against original record and read-only copied record/Lava/source/wrongowner negatives; whole state must remain unchanged.

New pure checks refuse fake/unbound callers and detached changed history at actual-authority gate. They do not reach deeper registry count/round/order/target/expiry validation and do not provide positive content authority. Those deep malformed-registry branches are static-review-only here; no live private corruption or forged successful records. Actual complete history is established only by the real public chain.

Pre-source native factory/add_hand/publicCoin funding is disclosed, not a fixture-free match. No random-domain narrowing, birth/UID injection, actual buffedLava rebuy, golden/secondMini/fullgame/default promotion. Gate observation and native factory preview remain not actual purchase proof. Old full matrices are not rerun. Full count is runtime-derived; explicit static pure count breakdown is recorded separately and actual count must be confirmed.

## V3 read-only current-cast regression observations

V1/V2 file bytes and static SHA receipts remain unchanged. Immediately after each of the two genuine first casts, actual buffed_sale_error and sale_preflight must permit the original Lava with kept1, and full live snapshots must remain unchanged. Four new checks (two gate successes plus two nonmutation checks), not extra sales or Games. These observations do not claim the previous full same-turn-sale scenario reran. Only the later carried kept0 sale is actually executed.

Darkcrest progression1→4 refers to its generated-card level/receipt state, not the minion's tavern star tier. Expected rounds and values are assertions against actual public-flow observations; a mismatch must fail rather than alter live state to fit. Pure42 remains unchanged and covers early authority refusals only; actual history/refusal evidence is separately collected in this real scenario.

## V4 actual native clock boundary

V1/V2/V3 remain byte-for-byte unchanged. The inherited Tier5 next_round sends opponent endturns then owner endturn; after that it only reads events and released context. inspect_permanent_combat/trident/original_mini_token and subsequent history observations are read-only. No roll, extra cast, noop or other command is inserted before round3 sale.

New real assertions require actual last_cast_sequence < mini_reset_sequence <= current command_sequence, and specifically mini_reset_sequence == current command_sequence == the first recruit sequence captured immediately after next_round/readonly combat inspection. The test records all four integers plus reset_equals_current/first_after_reset in sale_clock, and checks history observations did not advance the sequence. It fails if this template does not genuinely exercise equality; it never moves the clock to force passage. Only afterward does the original public sale command execute. This is a planned actual boundary observation, not a detached forged receipt. Pure42 unchanged and does not cover the deep clock gate.
