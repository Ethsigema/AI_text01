extends "res://tests/darkcrest_lava_buffed_sale_20261112/content_contract.gd"
# New history evaluator is actual-only. No detached success is manufactured.
func _initialize():
 check(Sources.proof_error().is_empty(),"complete_carried_sale_source_runtime_proof")
 var host=Host.new();var helper=host.LavaPlay.new();var fake_host=PretendLavaHost.new();fake_host._lava_play=helper
 var owner={"id":0,"board":[],"hand":[]};var lava={"uid":"u40","card_id":"BG23_009","attack":6,"health":5,"spellcraft_kept":0};var mini={"uid":"u20","card_id":"BG23_000"}
 var invented={"unit":lava,"owner":owner,"mini_steps":2,"mini_round":3,"mini_last_cast_round":2,"mini_last_cast_sequence":20,"mini_reset_round":3,"mini_reset_sequence":30,"snapshot":lava.duplicate(true)}
 for game_fixture in [{},RefCounted.new()]:
  check(not helper.buffed_cast_history_error(fake_host,game_fixture,owner,lava,mini,invented).is_empty(),"fake_actual_cannot_certify_history")
  check(not helper.buffed_sale_error(fake_host,game_fixture,owner,lava).is_empty(),"fake_history_cannot_authorize_buffed_sale")
  check(not helper.sale_preflight(fake_host,game_fixture,owner,lava).is_empty(),"fake_carried_sale_preflight_refused")
  check(not helper.begin_sale(fake_host,game_fixture,owner,0,{}).is_empty(),"unbound_carried_sale_context_refused")
 # Vary detached history fields to show none can bypass actual authority.
 # These are early-gate negatives, NOT deep registry validation coverage.
 for key in ["mini_steps","mini_last_cast_round","mini_last_cast_sequence","mini_reset_round","mini_reset_sequence"]:
  for value in [null,true,0,1.0,"2",-1]:
   var record=invented.duplicate(false);record[key]=value
   check(not helper.buffed_cast_history_error(fake_host,{},owner,lava,mini,record).is_empty(),"detached_changed_history_never_authorizes_"+key+str(value))
 var snapshot=invented.duplicate(true)
 check(not helper.buffed_cast_history_error(host,{},owner,lava,mini,invented).is_empty(),"real_host_without_actual_game_cannot_certify_history")
 check(host.purchase_value_same(snapshot,invented),"history_negative_calls_do_not_mutate_detached_facts")
 check(helper._board.is_empty() and helper._retired.is_empty() and helper._pending.is_empty() and helper._sale_pending.is_empty(),"unbound_history_creates_no_live_receipts")
 print("DARKCREST_LAVA_CARRIED_SALE_CONTENT_CONTRACT ",JSON.stringify({"passed":passed,"failed":failed,"failures":failures,"real_game_run":false,"actual_provenance_proven":false,"deep_registry_faults_tested":false,"scope":"actual-only carried history refuses unbound fixtures"}))
 quit(0 if failed==0 else 1)
