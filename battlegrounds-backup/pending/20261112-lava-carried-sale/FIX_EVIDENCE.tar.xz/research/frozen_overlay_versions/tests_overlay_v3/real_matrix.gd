extends "res://tests/darkcrest_lava_buffed_sale_20261112/real_matrix.gd"
# One new two-cast carried-buff sale scenario, not inherited full initializers.
func observed_history_and_refusals(lava: Dictionary,mini: Dictionary) -> bool:
 var p=game.state.players[0];var h=game._darkcrest_host;var helper=h._lava_play;var r=helper._board[lava.uid];var before=live_snapshot()
 if not must(helper.buffed_cast_history_error(h,game,p,lava,mini,r).is_empty(),"actual_two_cast_and_reset_history_authenticated"):return false
 if not must(not helper.buffed_cast_history_error(h,game,p,lava,mini,r.duplicate(true)).is_empty(),"copied_history_record_cannot_authorize_sale"):return false
 if not must(not helper.buffed_cast_history_error(h,game,p,lava.duplicate(true),mini,r).is_empty(),"copied_history_lava_cannot_authorize_sale"):return false
 if not must(not helper.buffed_cast_history_error(h,game,p,lava,mini.duplicate(true),r).is_empty(),"copied_history_source_cannot_authorize_sale"):return false
 if not must(not helper.buffed_cast_history_error(h,game,game.state.players[1],lava,mini,r).is_empty(),"wrong_history_owner_cannot_authorize_sale"):return false
 return must(h.Sources.same(before,live_snapshot()),"history_refusals_leave_entire_live_state_unchanged")
func observe_current_cast_sale_gate(lava: Dictionary,label: String) -> bool:
 var h=game._darkcrest_host;var p=game.state.players[0];var before=live_snapshot()
 if not must(lava.spellcraft_kept==1 and h._lava_play.buffed_sale_error(h,game,p,lava).is_empty() and h._lava_play.sale_preflight(h,game,p,lava).is_empty(),"actual_current_cast_sale_gate_"+label):return false
 return must(h.Sources.same(before,live_snapshot()),"current_cast_sale_gate_read_only_"+label)
func carried_sale_case() -> bool:
 var setup=prepare_room()
 if setup.is_empty():return false
 var mini=setup.mini;var lava=setup.lava;var parent=setup.parent;var p=game.state.players[0];var h=game._darkcrest_host
 if not public_lava_play(lava,0):return false
 if not must(command(0,{"type":"play","index":p.hand.find(mini),"target":-1,"position":1}).get("ok",false),"original_mini_publicplay_real_waiting_grant"):return false
 if not cast_first(mini,lava,parent,4) or not observe_current_cast_sale_gate(lava,"first") or not prepare_real_opponents():return false
 if not next_round(parent,2) or not inspect_permanent_combat(lava,4,1):return false
 if not cast_first(mini,lava,parent,6) or not observe_current_cast_sale_gate(lava,"second"):return false
 if not next_round(parent,3) or not inspect_permanent_combat(lava,6,2):return false
 var ready=trident()
 if ready.is_empty() or not original_mini_token(ready,mini):return false
 var record=h._mini._tokens[ready.uid];var facts=h.Mini.token_facts(record);var spells=p.stats.spells
 if not must(lava.attack==6 and lava.health==5 and lava.spellcraft_kept==0 and record.used==false and record.ready==true,"carried_two_buffs_reset_and_current_unused_token"):return false
 if not observed_history_and_refusals(lava,mini) or not sell_buffed_lava(lava,mini):return false
 if not must(p.hand.any(func(u):return is_same(u,ready)) and is_same(h._mini._tokens[ready.uid],record) and h.purchase_value_same(facts,h.Mini.token_facts(record)) and h._mini.token_error(h,game,p,ready).is_empty(),"carried_sale_keeps_original_ready_token_authority"):return false
 if not rejected_public({"type":"play","index":p.hand.find(ready),"target":p.board.find(mini),"target_zone":"board","position":-1},"post_carried_sale_no_lava_cast_held_without_consumption"):return false
 if not next_round(parent,4):return false
 var matches=game.last_combats.filter(func(c):return c.get("left_player")==0 or c.get("right_player")==0)
 if not must(matches.size()==1 and matches[0].get("error","")=="","one_actual_post_carried_sale_combat"):return false
 var combat=matches[0];var side="left" if combat.left_player==0 else "right";var enemy="right" if side=="left" else "left"
 var starts=combat.log.filter(func(e):return e.get("event")=="combat_start")
 if not must(starts.size()==1 and not starts[0][enemy].is_empty() and starts[0][side].any(func(u):return u.uid==mini.uid) and not starts[0][side].any(func(u):return u.uid==lava.uid),"post_carried_sale_nonempty_combat_mini_only"):return false
 if not must(absent_from_all_zones(ready) and p.stats.spells==spells and record.get("expired")==true and record.get("used")==false,"preserved_unused_token_native_expiry_without_cast"):return false
 var replacement=trident()
 if replacement.is_empty() or not original_mini_token(replacement,mini):return false
 if not must(replacement.uid!=ready.uid and not is_same(replacement,ready) and absent_from_all_zones(lava),"live_mini_regrants_after_carried_sale_expiry"):return false
 var before=live_snapshot()
 if not must(h._lava_play.buffed_sale_history(p) and h.lava_purchase_error(game,p,lava)=="darkcrest_lava_buffed_rebuy_held" and h.Sources.same(before,live_snapshot()),"carried_sale_owner_history_still_blocks_rebuy_gate"):return false
 var result={"scope":"two genuine first casts carried Lava buff sale at kept0 retaining current unused Mini token","seed":20261120,"checks":checks,"sale":buffed_sale,"casts":mini_casts,"pre_sale_combats":buff_combats,"post_sale_combat_start":starts[0],"darkcrest_uid":parent.uid,"darkcrest_final_tier":4,"mini_uid":mini.uid,"lava_uid":lava.uid,"preserved_token_uid":ready.uid,"replacement_token_uid":replacement.uid,"unused_expiry":{"used":record.used,"expired":record.expired,"spells_before":spells,"spells_after":p.stats.spells},"native_preview_diagnostic":native_preview_diagnostic,"acquisitions":acquisition,"coin_pre_source_fixture":true,"entirely_natural_game":false,"actual_lava_rebuy_tested":false,"old_full_matrix_repeated":false}
 var file=FileAccess.open(get_script().resource_path.get_base_dir()+"/DARKCREST_LAVA_CARRIED_SALE_MATRIX_RESULT.json",FileAccess.WRITE)
 if not must(file!=null,"matrix_result_file"):return false
 file.store_string(JSON.stringify(result,"  ")+"\n");file.close();return true
func _initialize():
 print("DARKCREST_LAVA_CARRIED_SALE_MATRIX_LOAD_BEGIN")
 var Game=load("res://core/game.gd")
 if not must(Game!=null and Game.can_instantiate(),"complete_game_script"):return
 cat=load("res://core/catalog.gd").new();cat.load_catalog()
 if not must(cat.load_errors.is_empty(),"complete_catalog"):return
 if not carried_sale_case():return
 print("DARKCREST_LAVA_CARRIED_SALE_REAL_MATRIX_PASS cases=1 casts=2 combats=3 checks=",checks)
 quit(0)
