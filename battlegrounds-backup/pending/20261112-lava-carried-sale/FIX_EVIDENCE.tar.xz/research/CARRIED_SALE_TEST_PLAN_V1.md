# Carried Lava buffs: one new public-flow test

Read-only baseline b749349, no old files overwritten. Draft version1 lives in tests_overlay_v1; subsequent revisions require a new version directory. No Game or full-tree copying by this task.

Same established four-player seed20261120 room and original Mini/Lava/Darkcrest acquisitions with disclosed pre-source native factory/add_hand/publicCoin fixture. Same Game/Catalog, no random-domain narrowing, no live unit/UID/pool/history edits. First original Mini token cast produces4/5 then real combat/recruit kept0; second genuine next-round first token cast produces6/5 then second realcombat/recruit kept0. In round3, original current ready unused token stays in hand while publicsellLava6/5kept0 executes. Reuse full native sale accounting/retirement/liveMini/history-gate checks; preserve current token object, original registry record and facts.

Without Lava, publicwrongtargetMini cast refuses without mutation. Third realcombat/recruit expires that original unused token with unchanged spellcount, sets original history expiredtrue/usedfalse, leaves liveMini and issues a distinct genuine token; Darkcrest reaches4. Prior two combat copies must contain4/5 then6/5, post-sale combat containsMini notLava. No generic rebuy, secondMini/golden/default acceptance.

This is one new complete Game, not replaying any old complete initializer. Old pure contracts can be preserved as separate regressions. Full assertion count is runtime-derived; pure count must be calculated explicitly after final producer predicate API and confirmed by actual execution. No count guessed now. Detached history predicates cannot prove actual source or receipt authority.
