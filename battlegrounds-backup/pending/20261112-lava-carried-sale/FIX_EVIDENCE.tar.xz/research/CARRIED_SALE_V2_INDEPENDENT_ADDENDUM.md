# V2 独立只读复核附录

实际读取 `CARRIED_SALE_V2_FROZEN.json` 并逐文件 SHA 核验：
- Mini: ff6d4caf1098e54c6f670f80f483745d5efb27b98878ed6116107818daf9d08c，匹配。
- Lava: af8054153c41d4940f70744dbec54bacc91e904646f819d7ef25fc12cbe78729，匹配。

实际 V1→V2 逐行差分：Mini 无变化；Lava 唯一变化是 history kept0 分支拒绝条件 `mini_reset_sequence >= game.state.command_sequence` 改为 `>`。
这准确修复 V1 独立审查指出的原生时钟问题：end_turn 自增后进入 reset，下一条命令执行前尚未再次自增，因此 reset==当前合法。last_cast<reset、当前 round、原 ready token、私有历史与身份等门槛全部保留，没有以内容谓词替代权限或额外扩大范围。

结论：V1 所报确定阻塞已修；可进入计划中的有限验证。本附录没有运行 Game/Godot，也不宣称测试成功。V1 冻结及原审查保持不变。实战仍需证明第一条命令边界、累计历史、原手牌 token 保留及售后 expiry/regrant；静态结论不是全玩法验收。
