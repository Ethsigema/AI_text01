# V2 static clock correction, unaccepted

V1 artifacts untouched. Only production change from V1: reject mini_reset_sequence > current command_sequence instead of >=. Native Game increments command_sequence before _finish_round, whose _begin_round performs the observed reset. Thus the immediately following public sale legitimately has reset_sequence equal to current command_sequence. Preserve lastcast_sequence < reset_sequence, current reset round, and all original authority/content conditions. No unrelated command should be inserted to advance this clock.

This is a statically confirmed boundary correction, NOT an observed Game failure. V1 description's strict reset < current relation is superseded by reset <= current. All other scope and unaccepted status remain. Full V2 diff rebuilt both files from actual immutable b749 preimages with patch --fuzz=0 and exact frozen SHA matches. No Game or old-tree changes. All revisions use new V2 paths.
