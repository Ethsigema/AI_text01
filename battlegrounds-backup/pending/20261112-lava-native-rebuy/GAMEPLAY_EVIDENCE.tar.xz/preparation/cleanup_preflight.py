"""Read-only full-tree redundancy proof; no delete action."""
from pathlib import Path
import json,gzip,hashlib,fcntl,datetime,sys,shutil
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT/'develop_lava_followup_20261112/fresh_remote/snapshot_tools'))
from common import verify
sha=lambda b:hashlib.sha256(b).hexdigest();read=lambda p:json.loads(p.read_text())
lockpath=ROOT/'develop_empty_ghost_20261112/.independent_full_game.lock'
with lockpath.open('r') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);rows=[]
 for stage,snap,run,source,final,download in [
 ('develop_lava_followup_20261112','remote_snapshot_73ef3f4','run_tree','73ef3f42e2a52b71aacd29fac2d6392731015d9d','c3873696df2d384a833bc78a6a58897faa810dce','final_remote_publication_c3873696df2d384a833bc78a6a58897faa810dce'),
 ('recover_tier5_after_environment_change_20261112','remote_snapshot_3da3922','independent_run_tree','3da3922e990fd2ed2637d1cc95c8a6e11322e32f','fd0355f88ef67f7e05fb5eae8c7e677356624734','final_remote_publication_fd0355f')]:
  s=ROOT/stage;r=s/snap;p=r/'package';m=read(p/'MANIFEST.json');raw=gzip.decompress((p/'SOURCE_MAP.json.gz').read_bytes());assert sha(raw)==m['source_map_sha256'];expected=json.loads(raw)
  pub=read(s/'FINAL_PUBLICATION_VERIFIED.json');assert pub['commit']==final and pub['source_commit']==source and pub['status'].startswith('PASS_FINAL_PUBLICATION_FRESH_BYTES')
  d=read(r/'FRESH_PACKAGE_DOWNLOAD_VERIFIED.json');assert d['source_commit']==source
  for n in ['MANIFEST.json','SOURCE_MAP.json.gz','delta.tar.xz']:
   entry=next(x for x in d['records'] if x['filename']==n);assert len((p/n).read_bytes())==entry['bytes'] and sha((p/n).read_bytes())==entry['sha256'];assert (p/n).read_bytes()==(s/download/n).read_bytes()
  gb=(r/'INDEPENDENT_GAME_VERIFICATION.json').read_bytes();game=json.loads(gb);assert game['source_commit']==source and game['source_map_sha256']==m['source_map_sha256'] and game['status'].startswith('PASS_FIXED_REMOTE')
  assert json.loads(gb)==read(s/download/'GAMEPLAY_INDEPENDENT_VERIFICATION.json')
  runtime=verify(r/run,expected,m['aggregate_sha256']);replacement=verify(r/'restored_snapshot',expected,m['aggregate_sha256']);assert runtime==replacement==game['trees'][run]==game['trees']['restored_snapshot']
  paths=list((r/run).rglob('*'));assert all(x.is_file() or x.is_dir() for x in paths);hardlinks=[str(x) for x in paths if x.is_file() and x.stat().st_nlink!=1];assert not hardlinks
  rows.append({'deletion_candidate':str(r/run),'equivalent_preserved_replacement':str(r/'restored_snapshot'),'source_commit':source,'final_commit':final,'source_map_sha256':sha(raw),'source_manifest_sha256':sha((p/'MANIFEST.json').read_bytes()),'runtime':runtime,'replacement':replacement,'unique_files':[],'non_single_link_files':hardlinks,'logical_reclaimable_bytes':runtime['bytes'],'estimated_allocated_bytes_including_directories':sum(x.stat().st_blocks*512 for x in paths)+(r/run).stat().st_blocks*512,'publication_receipt':str(s/'FINAL_PUBLICATION_VERIFIED.json'),'publication_receipt_sha256':sha((s/'FINAL_PUBLICATION_VERIFIED.json').read_bytes()),'game_receipt_sha256':sha(gb),'logs_preserved_at':str(r/'independent_tests')})
 report={'status':'READ_ONLY_PREFLIGHT_PASS_AWAIT_EXPLICIT_DELETE_AUTHORIZATION','checked_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exclusive_common_lock_held_during_hashing':True,'common_lock':str(lockpath),'no_ps_inference':True,'targets':rows,'total_logical_reclaimable_bytes':sum(x['logical_reclaimable_bytes'] for x in rows),'total_estimated_allocated_bytes':sum(x['estimated_allocated_bytes_including_directories'] for x in rows),'excluded_runtime_trees':[{'path':str(ROOT/a/b/'run_tree'),'reason':'Failed or unaccepted empty-slot attempt; expressly preserved, not a deletion candidate'} for a,b in [('develop_empty_ghost_20261112','remote_snapshot_e38175e'),('develop_empty_ghost_v2_20261112','remote_snapshot_aae0cf4'),('develop_empty_ghost_v3_20261112','remote_snapshot_b7ca89a')]],'third_accepted_runtime_duplicate_found':False,'deleted_paths':[],'preserved':'All backup packages, immutable restores, candidates, fresh restored_base trees, logs, independent_tests, failed/unaccepted work and 18:00 audit.','disk':shutil.disk_usage(ROOT)._asdict()}
 with (Path(__file__).parent/'CLEANUP_PREFLIGHT.json').open('x') as f:json.dump(report,f,indent=2)
 print(json.dumps(report,indent=2))
