"""Synthetic JSON/log schema fixtures ONLY. No engine instantiation or subprocess."""
from pathlib import Path
import copy
import json
import tempfile
import run_remote_lava_rebuy as runner


def main():
    labels=[]
    retired={'owner':0,'round':3,'sequence':40}
    sale={'uid':'u1','index':0,'gold_before':5,'gold_after':6,'stock_before':8,'stock_after':9,'sold_before':0,'sold_after':1,'uid_before':50,'uid_after':50,'rng_before':100,'rng_after':100,'retirement':retired}
    purchase={'uid':'u2','source_uid':'u3','source_tier':3,'round':3,'gold_before':6,'gold_after':3,'bought_before':2,'bought_after':3,'next_uid_before':51,'next_uid_after':51,'rng_before':200,'rng_after':200}
    case={'kind':'pre_source_lava_sale_mature_source_different_uid_rebuy','seed':20261120,'pre_source_first_lava_rolls':1,'pre_source_cooffer_rolls':2,'offer_uids':['u1','u2'],'source_uid':'u3','source_tier':4,'final_round':4,'first_buy_before_source':True,'active_purchase_count':1,'first_purchase':{'uid':'u1','gold_before':6,'gold_after':3,'source_owned':False,'active_purchase':False},'offer_created_after_first_sale':False,'second_offer_created_before_source':True,'post_sale_new_offer_generation_tested':False,'retirement':retired,'purchases':[purchase],'sale_effects':[sale],'holds':[{'kind':'already_owned_lava_purchase','error':'darkcrest_lava_purchase_second_body_held','uid':'u2','round':3},{'kind':'current_token_purchase','error':'darkcrest_lava_purchase_token_or_waiting_held','uid':'u2','round':3}]}
    scenario={'scope':runner.NEW_TEST_METADATA['scope'],'checks':0,'cases':[case],'coin_pre_source_fixture':True,'entirely_natural_game':False,'old_matrices_repeated':False,'post_sale_new_offer_generation_tested':False,'no_live_state_injection':True}
    acquired={'tier':3,'source_uid':'u3','id':'BG23_007','uid':'u50','pool_before':10,'pool_after':9}
    with tempfile.TemporaryDirectory(prefix='rebuy_schema_synthetic_', dir=Path(__file__).parent) as temp:
        root=Path(temp);path=root/runner.NEW_TEST_METADATA['scenario_file']
        def materialize(data, passlines):
            count=len(passlines);data=copy.deepcopy(data);data['checks']=count-1
            path.write_text(json.dumps(data))
            return '\n'.join(passlines+['ACQUIRED '+json.dumps(acquired),'DARKCREST_LAVA_REBUY_CASE_PASS '+json.dumps(data['cases'][0]),f'DARKCREST_LAVA_REBUY_REAL_MATRIX_PASS cases=1 checks={count}'])+'\n'
        # Capture marker vocabulary for an artificial fixture, then RESTORE and
        # exercise the actual marker validator. This never describes real play.
        captured={};original=runner.marker_counts
        def collect(_log, markers):
            for key,value in markers.items():
                assert key not in captured or captured[key]==value
                captured[key]=value
        runner.marker_counts=collect
        try:runner.validate_rebuy_full(materialize(scenario,['PASS coin_fixture_only_before_darkcrest_owned']),root)
        finally:runner.marker_counts=original
        passlines=['PASS '+key for key,count in captured.items() for _ in range(count)]+['PASS coin_fixture_only_before_darkcrest_owned']
        goodlog=materialize(scenario,passlines)
        count,_=runner.validate_rebuy_full(goodlog,root)
        assert count==len(passlines);labels.append('synthetic_valid_schema_not_real_game_evidence')
        mutations=[
            ('two_active_claim',lambda s:s['cases'][0].update(active_purchase_count=2),'Exactly one active'),
            ('post_sale_factory_claim',lambda s:s['cases'][0].update(offer_created_after_first_sale=True),'different preexisting'),
            ('first_buy_wrongly_active',lambda s:s['cases'][0]['first_purchase'].update(active_purchase=True),'First buy is pre-source'),
            ('duplicate_offer_uid',lambda s:s['cases'][0]['offer_uids'].__setitem__(1,'u1'),'Distinct original UID'),
            ('wrong_hold_order',lambda s:s['cases'][0]['holds'].reverse(),'Wrong exact public hold'),
            ('wrong_gold_debit',lambda s:s['cases'][0]['purchases'][0].update(gold_after=4),'Natural active buy'),
            ('purchase_factory_allocation',lambda s:s['cases'][0]['purchases'][0].update(next_uid_after=52),'cannot birth'),
            ('missing_retirement',lambda s:s['cases'][0].pop('retirement'),'Unexpected schema'),
            ('boolean_integer',lambda s:s['cases'][0].update(active_purchase_count=True),'Strict integer'),
            ('wrong_old_first_buy_semantics',lambda s:s['cases'][0].update(first_buy_before_source=False),'Exactly one active'),
        ]
        for label,mutate,fragment in mutations:
            changed=copy.deepcopy(scenario);mutate(changed)
            try:runner.validate_rebuy_full(materialize(changed,passlines),root)
            except ValueError as exc:assert fragment in str(exc),(label,exc);labels.append(label)
            else:raise AssertionError('Accepted synthetic negative '+label)
        badlog=materialize(scenario,passlines).replace('PASS bound_shadow_low_level_native_sale_refused\n','')
        try:runner.validate_rebuy_full(badlog,root)
        except ValueError as exc:assert 'multiplicity' in str(exc);labels.append('missing_security_marker')
        else:raise AssertionError('Accepted missing security marker')
    print(json.dumps({'status':'PASS_SYNTHETIC_NEW_SCHEMA_ONLY','checks':len(labels),'labels':labels,'game_started':False,'godot_started':False,'real_play_verified':False}))


if __name__=='__main__':main()
