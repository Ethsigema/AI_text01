"""Archive verified bytes-only restore receipts and prepared tools; never gameplay acceptance."""
import shutil
from packaging_common import *
def main():
 a=parser(__doc__).parse_args();r,commit,folder,m,expected,d=context(a)
 p=ROOT/'restore_receipt_package';assert not p.exists()
 fixed=read(r/'FIX_EVIDENCE_VERIFIED.json');assert fixed['every_member_rehashed']
 files=completed_single_tree_evidence(r,m,commit)
 for f in sorted((ROOT/'preparation').iterdir()):
  if f.is_file() and f.suffix in {'.py','.md','.json','.txt'} and not f.name.endswith('.log'):files['preparation/'+f.name]=f.read_bytes()
 files['TOOL_SNAPSHOT_NOTE.json']=enc({'scope':'prepared tools only, not proof that future packaging or Game ran','gameplay_acceptance':False})
 data,meta=archive(files,commit);shutil.copytree(r/'package',p)
 put(p/'TOOLS_EVIDENCE.tar.xz',data);put(p/'TOOLS_EVIDENCE_MANIFEST.json',enc(meta))
 for src,dst in [('INDEPENDENT_RESTORE_VERIFIED.json','REMOTE_SNAPSHOT_RESTORE_VERIFIED.json'),('FRESH_PACKAGE_DOWNLOAD_VERIFIED.json','REMOTE_SNAPSHOT_DOWNLOAD_VERIFIED.json'),('FIX_EVIDENCE_VERIFIED.json','REMOTE_FIX_EVIDENCE_VERIFIED.json')]:put(p/dst,(r/src).read_bytes())
 put(p/'RESTORE_VERIFIED.md',f'# Source restoration only\n\nFixed source {commit}. Actual downloaded package has {d["files"]} files. Map {m["source_map_sha256"]}; aggregate {m["aggregate_sha256"]}. This is bytes-only evidence, not gameplay acceptance. Single restored runtime intended; no extra run_tree copy. All old source packages remain unchanged.\n'.encode())
 checksum(p);records=rows(p);original={x['filename']:x for x in d['records']};changed=[x for x in records if x['name'] not in original or x['sha256']!=original[x['name']]['sha256']]
 assert [x['name'] for x in changed if x['name'] in original]==['SHA256SUMS.txt']
 put(ROOT/'RESTORE_RECEIPT_UPLOAD_METADATA.json',enc({'status':'LOCAL_BYTES_ONLY_RECEIPT_READY_NOT_PUBLISHED','source_commit':commit,'remote_folder':folder,'folder':folder,'files':len(records),'bytes':sum(x['bytes'] for x in records),'records':records,'changed_records':changed}))
if __name__=='__main__':main()
