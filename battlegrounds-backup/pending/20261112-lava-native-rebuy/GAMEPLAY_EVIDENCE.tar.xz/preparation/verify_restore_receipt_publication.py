"""Fresh bytes-only receipt download; never inspect live Game results or run Game."""
from pathlib import Path,PurePosixPath
import json,hashlib,subprocess,concurrent.futures,tarfile,datetime,argparse
ROOT=Path(__file__).resolve().parent.parent;COMMIT='f0e02d1bad0edbf02a89826615927949ad607e39';SOURCE='b40bc9b7701afbca41defd5f35a9c931a8b5ee9e';FOLDER='battlegrounds-backup/pending/20261112-lava-native-rebuy'
def sha(b):return hashlib.sha256(b).hexdigest()
def safe(n):return bool(n) and not PurePosixPath(n).is_absolute() and '..' not in PurePosixPath(n).parts and '\\' not in n
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--execute',action='store_true',required=True);ap.parse_args()
 rows=json.loads((ROOT/'fresh_remote/snapshot_tools/RESTORE_RECEIPT_REMOTE_METADATA.json').read_text());local=json.loads((ROOT/'RESTORE_RECEIPT_UPLOAD_METADATA.json').read_text());pins={x['name']:x for x in local['records']};assert len(rows)==len(pins)==23
 out=ROOT/'restore_receipt_remote_f0e02d1';out.mkdir(exist_ok=False)
 def fetch(row):
  n=row['name'];assert safe(n) and '/' not in n and row['type']=='file' and row['path']==FOLDER+'/'+n
  url='https://raw.githubusercontent.com/Ethsigema/AI_text01/'+COMMIT+'/'+row['path'];assert row['download_url']==url
  p=out/n;part=Path(str(p)+'.partial');subprocess.run(['curl','-fsSL','--retry','3','--max-time','300',url,'-o',str(part)],check=True)
  b=part.read_bytes();git=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();assert len(b)==row['size']==pins[n]['bytes'] and git==row['sha']==pins[n]['git_sha'] and sha(b)==pins[n]['sha256'],n;part.rename(p)
  return {'name':n,'url':url,'bytes':len(b),'git_sha':git,'sha256':sha(b)}
 with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex:records=list(ex.map(fetch,rows))
 checked=set()
 for line in (out/'SHA256SUMS.txt').read_text().splitlines():
  h,n=line.split('  ',1);assert safe(n) and '/' not in n and n not in checked and n!='SHA256SUMS.txt';assert sha((out/n).read_bytes())==h;checked.add(n)
 assert checked==set(pins)-{'SHA256SUMS.txt'}
 counts={}
 for prefix,count in [('FIX',65),('TOOLS',51)]:
  manifest=json.loads((out/(prefix+'_EVIDENCE_MANIFEST.json')).read_text());expected=manifest if prefix=='FIX' else manifest['members']
  if prefix=='TOOLS':assert manifest['source_commit']==SOURCE and sha((out/'TOOLS_EVIDENCE.tar.xz').read_bytes())==manifest['archive_sha256']
  seen=set()
  with tarfile.open(out/(prefix+'_EVIDENCE.tar.xz')) as t:
   for x in t:
    assert x.isfile() and safe(x.name) and x.name not in seen
    b=t.extractfile(x).read();assert {'bytes':len(b),'sha256':sha(b)}==expected[x.name];seen.add(x.name)
  assert seen==set(expected) and len(seen)==count;counts[prefix]=count
 original=ROOT/'remote_snapshot_b40bc9b/package';unchanged={}
 original_rows=json.loads((original.parent/'FRESH_PACKAGE_DOWNLOAD_VERIFIED.json').read_text())['records']
 for n in sorted(x['filename'] for x in original_rows if x['filename']!='SHA256SUMS.txt'):
  b=(out/n).read_bytes();assert b==(original/n).read_bytes();unchanged[n]=sha(b)
 restore=json.loads((out/'REMOTE_SNAPSHOT_RESTORE_VERIFIED.json').read_text());assert restore['source_commit']==SOURCE and not restore['gameplay_acceptance']
 report={'status':'PASS_EARLY_RESTORE_RECEIPT_PUBLICATION_BYTES_ONLY_NOT_GAME','verified_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'commit':COMMIT,'source_commit':SOURCE,'files':len(records),'bytes':sum(x['bytes'] for x in records),'records':records,'sha256sums_entries':len(checked),'evidence_members_rehashed':counts,'source_all_16_non_sums_files_unchanged':unchanged,'new_full_tree_restore_repeated':False,'live_game_logs_accessed':False,'gameplay_acceptance':False,'game_started':False,'uploads':0}
 with (ROOT/'EARLY_PUBLICATION_VERIFIED.json').open('x') as f:json.dump(report,f,indent=2)
 print(json.dumps({k:v for k,v in report.items() if k!='records'},indent=2))
if __name__=='__main__':main()
