"""Small synthetic Python validator tests. No Godot, Catalog, Game, or real source-tree scan."""
from pathlib import Path
import hashlib
import json
import tempfile
from run_remote_lava_rebuy import (validate, require_frozen, verify_tree, scan_tree,
    validate_source_map, validate_paths, dump, TESTS, sha, write_new, NEW_TEST_METADATA, validate_restore_receipt)
from audit_lava_rebuy_attempt import classify_attempt


def rejected(fn, label):
    try: fn()
    except (ValueError, AssertionError, KeyError, FileNotFoundError, TypeError): return label
    raise AssertionError('Validator accepted negative case: ' + label)


def main():
    passed=[]
    # UNKNOWN is a hard refusal, not an implicit success or fallback to old validators.
    prior_status=NEW_TEST_METADATA['status'];NEW_TEST_METADATA['status']='UNKNOWN_SYNTHETIC_NEGATIVE'
    try:passed.append(rejected(require_frozen, 'unknown_new_metadata_fails_closed'))
    finally:NEW_TEST_METADATA['status']=prior_status
    require_frozen();passed.append('frozen_metadata_complete_not_execution')
    with tempfile.TemporaryDirectory(prefix='rebuy_synthetic_', dir=Path(__file__).parent) as temp:
        root=Path(temp)
        passed.append(rejected(lambda:validate('unknown_contract','',None,root),'unknown_label_refused'))
        passed.append(rejected(lambda:validate('lava_rebuy_real_matrix','DARKCREST_LAVA_REBUY_REAL_MATRIX_PASS cases=1 checks=1\nPASS fake\n',None,root),'fabricated_full_pass_without_scenario_refused'))
        passed.append(rejected(lambda:validate('lava_rebuy_content_contract','',None,root),'empty_pure_refused'))
        passed.append(rejected(lambda:validate('source_eot_contract','DARKCREST_SOURCE_EOT_CONTRACT passed=68 failed=0\n',68,root),'old_summary_without_pass_lines_refused'))
        passed.append(rejected(lambda:validate('source_eot_contract','PASS fake\nERROR: bad\nDARKCREST_SOURCE_EOT_CONTRACT passed=68 failed=0\n',68,root),'error_marker_refused'))
        bad={'passed':140,'failed':0,'failures':[],'scope':'detached sale context and authority rejection observations only','real_game_run':False,'live_capacity_tested':True,'partial_failure_live_injection':False}
        log=('PASS x\n'*140)+'DARKCREST_LAVA_SALE_CONTENT_CONTRACT '+json.dumps(bad)+'\n'
        passed.append(rejected(lambda:validate('lava_sale_content_contract',log,140,root),'old_sale_wrong_semantic_claim_refused'))
        passed.append(rejected(lambda:validate_source_map({'../escape':{'bytes':1,'sha256':'a'*64}},{'source_files':1,'source_bytes':1}),'unsafe_source_map_refused'))
        passed.append(rejected(lambda:validate_source_map({'x':{'bytes':True,'sha256':'a'*64}},{'source_files':1,'source_bytes':1}),'boolean_byte_count_refused'))
        a=root/'candidate';b=root/'restored_snapshot';a.mkdir();b.mkdir();(a/'x').write_bytes(b'original');(b/'x').write_bytes(b'original')
        # Exact single-tree restore contract, using only small synthetic metadata.
        restore={'status':'PASS_REMOTE_UNACCEPTED_SINGLE_TREE_SOURCE_RESTORE_BYTES_ONLY',
                 'source_commit':'a'*40,'source_map_sha256':'b'*64,'restored_tree':str(b),
                 'fresh_base_checkpoint_then_single_target_tree':True,'separate_runtime_copy_created':False,
                 'game_started':False,'gameplay_acceptance':False,
                 'restored':{'aggregate_sha256':'c'*64,'files':1,'bytes':8,'missing':[],'extra':[],'mismatched':[]}}
        def valid_restore(value):validate_restore_receipt(value,b,'a'*40,'b'*64,'c'*64,1,8)
        valid_restore(restore);passed.append('exact_single_tree_restore_metadata_positive')
        for field,bad,label in [
            ('status','PASS_REMOTE_UNACCEPTED_SOURCE_RESTORE_BYTES_ONLY','old_restore_status_refused'),
            ('fresh_base_checkpoint_then_single_target_tree',False,'missing_fresh_base_checkpoint_refused'),
            ('separate_runtime_copy_created',True,'separate_runtime_copy_refused'),
            ('restored_tree',str(a),'wrong_exact_restored_tree_path_refused')]:
            wrong=dict(restore);wrong[field]=bad
            passed.append(rejected(lambda:valid_restore(wrong),label))
        payload=b'original';expected={'x':{'bytes':len(payload),'sha256':sha(payload)}}
        agg=hashlib.sha256(b'x\0'+str(len(payload)).encode()+b'\0'+payload).hexdigest()
        require_a,_=verify_tree(a,expected,agg)
        assert require_a['matches'] is True
        passed.append('synthetic_full_source_scan_positive_not_gameplay')
        (b/'x').write_bytes(b'changed')
        observed,_=scan_tree(b,expected,agg);assert observed['matches'] is False and observed['mismatched']==['x']
        passed.append(rejected(lambda:verify_tree(b,expected,agg),'changed_source_refused'))
        passed.append(rejected(lambda:validate_paths(a,a,root),'same_source_roots_refused'))
        evidence=root/'independent_tests';evidence.mkdir()
        first=TESTS[0][0];(evidence/(first+'_STARTED.json')).write_text('{}');(evidence/(first+'.log')).write_text('started but no result')
        second=TESTS[1][0];write_new(evidence/(second+'_result.json'),{'process_started':True,'source_commit':'wrong'})
        third=TESTS[2][0];write_new(evidence/(third+'_PRECHECK.json'),{})
        rows,errors=classify_attempt(evidence,{}, {'source_commit':'a'*40}, b,{})
        assert rows[first]['classification']=='launch_or_execution_without_completion_receipt'
        assert rows[second]['classification']=='executed_validation_or_evidence_failed'
        assert rows[third]['classification']=='preflight_only_not_started'
        assert rows[TESTS[3][0]]['classification']=='omitted' and errors
        passed.append('audit_failure_preserves_executed_uncertain_preflight_and_omitted')
    result={'status':'PASS_SYNTHETIC_PREPARATION_CHECKS_NOT_GAMEPLAY','checks':len(passed),'labels':passed,
            'godot_started':False,'game_started':False,'real_source_tree_scanned':False,
            'new_test_metadata_still_unknown':False}
    print(json.dumps(result,sort_keys=True))


if __name__=='__main__':main()
