"""Small synthetic data only; no Game or real baseline restore."""
from pathlib import Path
import sys,tempfile,hashlib,json,gzip,tarfile,io
ROOT=Path(__file__).resolve().parent.parent;sys.path.insert(0,str(ROOT/'fresh_remote/snapshot_tools'))
import restore_low_disk as r
checks=[]
def ok(name,fn):fn();checks.append(name)
def reject(name,fn):
 try:fn()
 except (ValueError,FileNotFoundError,KeyError):checks.append(name);return
 raise AssertionError('Unexpected acceptance: '+name)
def records(data):return {n:{'bytes':len(b),'sha256':r.sha(b)} for n,b in data.items()}
def aggregate(data):
 h=hashlib.sha256()
 for n,b in sorted(data.items()):h.update(n.encode()+b'\0'+str(len(b)).encode()+b'\0'+b)
 return h.hexdigest()
for n in ['', '/a','../a','a/../b','a//b','./a','a/.','a\\b','a\0b']:
 assert not r.safe(n);checks.append('unsafe_path_'+repr(n))
reject('duplicate_json',lambda:r.load('{"a":1,"a":2}'))
reject('map_bool_length',lambda:r.validate_map({'x':{'bytes':True,'sha256':'0'*64}}))
reject('map_collision',lambda:r.validate_map(records({'a':b'a','a/b':b'b'})))
with tempfile.TemporaryDirectory(prefix='synthetic_restore_',dir=ROOT/'preparation') as td:
 w=Path(td);tree=w/'tree';tree.mkdir();basebytes={'keep.txt':b'keep','changed.txt':b'old','remove.txt':b'remove'};base=records(basebytes)
 for n,b in basebytes.items():(tree/n).write_bytes(b)
 ok('base_full_scan',lambda:r.scan(tree,base,aggregate(basebytes)))
 (tree/'extra').write_text('x');reject('scan_extra',lambda:r.scan(tree,base,aggregate(basebytes)));(tree/'extra').unlink()
 (tree/'sym').symlink_to(tree/'keep.txt');reject('scan_symlink',lambda:r.scan(tree,base,aggregate(basebytes)));(tree/'sym').unlink()
 (tree/'changed.txt').write_text('bad');reject('scan_bad_bytes',lambda:r.scan(tree,base,aggregate(basebytes)));(tree/'changed.txt').write_bytes(b'old')
 pkg=w/'package';pkg.mkdir();targetbytes={'keep.txt':b'keep','changed.txt':b'new','nested/new.txt':b'added'};target=records(targetbytes);delta={n:b for n,b in targetbytes.items() if base.get(n)!=target[n]}
 def make_tar(items):
  out=io.BytesIO()
  with tarfile.open(fileobj=out,mode='w:xz') as t:
   for n,b,kind in items:
    x=tarfile.TarInfo(n);x.size=len(b);x.type=kind;t.addfile(x,io.BytesIO(b))
  return out.getvalue()
 data=make_tar([(n,b,tarfile.REGTYPE) for n,b in delta.items()]);(pkg/'delta.tar.xz').write_bytes(data);(pkg/'SOURCE_MAP.json.gz').write_bytes(gzip.compress(r.enc(target)))
 m={'base_map_sha256':r.BASE_MAP,'base_content_commit':'5143e8fb41bc8332ce4ba196144172167a74318c','removed':['remove.txt'],'changed_files':{n:target[n] for n in delta},'source_map_sha256':r.sha(r.enc(target)),'source_files':len(target),'source_bytes':sum(x['bytes'] for x in target.values()),'archive':'delta.tar.xz','archive_bytes':len(data),'archive_sha256':r.sha(data),'aggregate_sha256':aggregate(targetbytes)}
 def put(): (pkg/'MANIFEST.json').write_bytes(r.enc(m))
 put();ok('validated_manifest_delta',lambda:r.target_and_delta(base,pkg))
 m['removed']=['missing'];put();reject('unknown_removal',lambda:r.target_and_delta(base,pkg));m['removed']=['remove.txt'];put()
 for label,entries in [('duplicate_member',[(n,b,tarfile.REGTYPE) for n,b in delta.items()]+[('changed.txt',b'new',tarfile.REGTYPE)]),('unsafe_member',[('../outside',b'x',tarfile.REGTYPE)]),('symlink_member',[('changed.txt',b'',tarfile.SYMTYPE)]),('missing_member',[('changed.txt',b'new',tarfile.REGTYPE)])]:
  bad=make_tar(entries);(pkg/'delta.tar.xz').write_bytes(bad);m['archive_bytes']=len(bad);m['archive_sha256']=r.sha(bad);put();reject(label,lambda:r.target_and_delta(base,pkg))
 (pkg/'delta.tar.xz').write_bytes(data);m['archive_bytes']=len(data);m['archive_sha256']=r.sha(data);put()
 ok('apply_in_new_synthetic_tree',lambda:r.apply_validated(tree,base,target,delta,m['removed'],w/'staged'))
 ok('final_full_scan',lambda:r.scan(tree,target,m['aggregate_sha256']))
 assert not (tree/'remove.txt').exists() and not (w/'staged').exists();checks.append('removal_and_no_staging_residue')
 (pkg/'SHA256SUMS.txt').write_text(''.join(r.sha(p.read_bytes())+'  '+p.name+'\n' for p in sorted(pkg.iterdir())))
 ok('full_package_sums',lambda:r.sums(pkg));(pkg/'unexpected').write_text('x');reject('package_extra',lambda:r.sums(pkg))
report={'status':'PASS_SYNTHETIC_ONLY_NOT_FULL_REAL_RESTORE','checks':len(checks),'names':checks,'game_started':False,'real_base_restore_executed':False,'source_modified':False,'tool_sha256':r.sha((ROOT/'fresh_remote/snapshot_tools/restore_low_disk.py').read_bytes())}
(ROOT/'preparation/LOW_DISK_SYNTHETIC_VERIFIED.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
