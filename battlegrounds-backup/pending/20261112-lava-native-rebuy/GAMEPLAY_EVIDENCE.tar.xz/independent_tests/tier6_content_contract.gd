extends "res://tests/darkcrest_tier6_20261112/content_contract.gd"
