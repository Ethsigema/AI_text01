extends "res://tests/darkcrest_lava_rebuy_20261112/real_matrix.gd"
