extends "res://tests/darkcrest_lava_20261112/content_contract.gd"
