# Active Darkcrest 普通Lava购买：只读安全设计审查

来源：develop_lava_followup_20261112/remote_snapshot_73ef3f4/restored_snapshot。未改源、未运行Game。这里只提出最小安全设计与负例，不声称购买已可用。

## 真实现有结构

OwnedPurchaseHost.command_preflight:15起，对普通gold buy先取得原报价，Prefix.create生成独立Game，bind_purchase_projection，再执行shadow.apply_command完整原命令，然后release；无shadow状态写回live。Prefix.create仅复制plain公开数据、库存、UID/RNG游标，新的私有hosts保持fresh，catalog为共享定义。Darkcrest.actual只检查Game脚本路径，因此真正shadow也满足actual，不能拿它当“不是投影”的权限证明。

Host.bind_purchase_projection:542当前要求live grants/spells和活动窗全空、board/等待空，仅复制shop/hand新鲜tier1,last_eot=-1 parent records到shadow本身的原unit引用。成熟source与Lava目标均不满足旧路径：command_error先拒非parent purchase，末尾还要求目标uid在parent records。应保留旧fresh购买分支，不改成通用shape通行证。

## 推荐最小新分支

限定此次目标为普通原生shop BG23_009；hand/board没有任何Lava；只有普通shop_origin成熟Darkcrest parents在场；无当前Darkcrest token、无spellcraft_waiting、无未完成delivery/cast/EOT/generation/play/sale窗口。原owner_error完整先过，仍无其他英雄/饰品/外来board listener。只准单次原buy命令及其原内部规范化buy，不能让“投影中”成为普遍owner豁免。

live mature parent先逐个验证原私有record/原对象/tier/last_eot/真实owner与完整合法形状；限定shop_origin==true，禁止generated nonshop origin。影子admission只重绑定到独立公开副本，不复制live record引用。可建立专用只读parent view，或明确标为projection-only的shadow records，必须由projection lifecycle门禁保证其仅供这次buy验证。tier/last_eot不能重置成fresh以掩盖成熟状态，也不改live成长。

live _grants/_spells可能保留已消费历史，因此“无当前token”不等于这两个字典为空；应检查其记录与真实hand/waiting/活动窗的一致性，未知/仍可使用的记录held。历史仅在live保留，不能把record、token、generation origins、delivery receipt、Lava _board/_pending/_sale_pending/_retired或weakref带入shadow。shadow这些应fresh，旧retired只在live保留。成熟来源允许购买不表示允许在shadow凭空补发Spellcraft。

原Lava shop offer需真实索引/原对象、唯一UID、正常shape/库存归属；不得等于live retiredUID（也不能靠shadow没有retired误放旧UID）。这是购买合法offer，不是Lava原生生成出生证明。买后真实hand→board仍走已有play凭证，新UID取得新的live record；买入不得直接发board许可。

## 必须reject

- live已在projection或shadow反向作为live；shadow非独立Game/私有Host/RNG或任何公开mutable容器共享；公开snapshot/游标不一致、原单位与副本引用相同。
- 任意未审nonshop parent、golden/triple、混入其他在场来源；Lava仍在hand/board或目标旧retiredUID；current token、待发/队列、活动窗口或未解释grant状态。
- 复制/替换parent record、错误owner、重复UID、修改tier/last_eot、把live grant/custody/nonce塞入影子、影子owner与command不匹配。
- 投影期间任何非buy命令，以及直接调用grant注册、delivery/cast/consume、generation、EOT、Lava play/sale等发证入口。只在command_error中限buy不能阻止直接helper入口；至少涉及parent成熟投影权限的入口必须明确识别projection-only，不可让same脚本actual为影子认证成长或发token。
- shadow来源/记录尝试用于live parent/play/cast/sale，或release后继续使用此前影子record；私有原对象与engine双绑定应拒绝。

## Release与失败路径

现OwnedPurchaseHost在bind返回错误时直接return，不调用release。因此bind必须先在局部构建并完整验证，最后一次性安装；若新逻辑先写target再失败，必须自身清理，不能假定上层会清。apply_command结果无论成功/失败，现代码都会release后再查结果/phase，这是正确顺序。

release只操作shadow，不清live历史/retired。清所有projection记录、短窗/receipts及新引入的只读admission；若新分支可能触及Lava helper，应验证其fresh并重置shadow helper，不留外泄board/retired权限。不要把普通live helper清空作为通用cleanup。清投影记录后旧shadow实体再调用受保护方法必须失败，不应仅删标志反而将其升级为普通有效实体。

## 有限测试与限制

先纯合同验证复制、错owner、同UID、跨engine、live↔shadow记录回用、直接helper调用、release后重用、bind半失败及命令替换。完整原native detached命令仍必须跑，不能只报价后跳过preflight。真实四人有限矩阵做成熟shop_origin source无token时买Lava→真实play/战斗→sell→另一原生shop新UID重购；各阶段验证live历史、retired和RNG/UID未被影子影响。若原seed无法提供新offer不能伪造shop，也不必为闭环扩大刷新组合。

目前是架构建议；准确可用历史grant条件和projection直接入口屏蔽需在实现diff及真实测试中确认，不能据此声称active购买或重新入场已验收。
