# Active Darkcrest 普通 Lava 购买 / 新 UID 重购：独立只读评估

输入：`develop_lava_followup_20261112/remote_snapshot_73ef3f4/restored_snapshot`。读软件工程技能后，只读本树及上一份 `develop_lava_followup_20261112/research/LAVA_PERMANENT_NEXT_ASSESSMENT.md`；本报告是唯一写入。不改源码、不运行 Godot/Game、不复制树，不触碰旧备份或失败空位链。下述路径行号均指本输入；“已验证 sale”来自父任务，本文不重报运行计数。

## 结论与最小范围

**优先普通 Lava 的 active 购买，以及真实卖出后购买另一原生商店对象、新 UID 的重购。它比 Mini 永久联动明显更窄，但绝不是新增一个 buy 白名单。** 新增的是既有原生购买与 Darkcrest 私有来源验证的兼容，不是新实现购买、卖出或 Lava 的永久能力。

建议第一版严格限定：现有无额外机制 Edwin 房间；真实普通 `BG31_920` 暗潮来源已在场（优先 1 只 shop-born，来源 tier 1–6 中仍允许后续 EOT 的区间）；购买前 board+hand 内 **0 只 Lava**；目标是当前真实 shop 中未修改普通 `BG23_009`，2/5、kept0、pool_count1；成功买后最多 1 只，之后复用现有 hand→board 和 sale。退役旧 UID 永久保留拒绝，不因买入同 card_id 擦除。可单列 2 暗潮源兼容，不默认扩大到生成暗潮父牌、金色、多 Lava、三连、附魔、Mini、外部塑造、保存恢复或空位链。

身份已按源码核对：`Sources.PARENTS = ["BG31_920", "BG31_920_G"]`。`BG36_508` 是 Tier4 机警的咒术师，不是暗潮，不更改 ID。

## 1. Source / public semantics

- 普通 Lava：`data/catalog_raw.json` 的 Tier2、2/5、纳迦；`data/catalog.json` 完整 `spellcraft_permanent,count=1`。在 `current_scope_manifest.json` 的 official+naga_overlay 中。独立 native 来源仍是 `research/bubble_crown_spellcraft/native/BG23_009.xml`；源链接为 `https://wiki.ifindhs.com/index.php?title=%E9%85%92%E9%A6%86%E6%88%98%E6%A3%8B/%E7%86%94%E5%B2%A9%E6%BD%9C%E4%BC%8F%E8%80%85&oldid=142997`。本次没联网更新来源。
- 暗潮 raw 基线的 supported=false/空 effects **不是当前运行结论**。`core/catalog.gd:12085-12087` 应用 `DarkcrestSources.apply_overlay`，当前 overlay revision 是 `darkcrest-normal-lava-native-sale-departure-candidate-20261112`。不可只读 raw 就把已验实现说成不存在。
- 新 shop 实体在 `_fill_shop` 内产生：`game.gd:9821-9859` 原 draw→`_unit`→pool ownership→原 shop 接收→append；`9982-10004` 在原 eligible 全域按实际库存抽样，**抽出时已 pool[id]-1**。`_unit:9066-9074` 走真实 factory；不能用复制旧售出实体、手写 uid 或 catalog 字典代替。
- 公开入口：`game.gd:2024-2027` Darkcrest command preflight；`2082-2083` 普通购买全命令投影；`3396-3407` 内部 `_buy` 再检查，之后完整现有链。
- 原生购买：`3550-3570` 索引/手牌/quote/资金；`3638-3667` 实际扣款、原 spend callbacks、shop.remove_at、leave_shop；`3677` 把 **同一原 shop 对象** `_add_hand`；`3694,3709` bought / bought_minions 各加1；`3705-3773` 原购买监听、三连、completion 都保留。普通无 modifier 默认价3由 `3843-3850` 决定，仍须读取实际 quote，不另写定价。
- 因库存已在出店 offer 时预占，**buy 本身不应再扣一次 Lava stock，也不分配新 UID**。在上述无额外 listener 房间，成功 buy 的 pool/spell_pool、next_uid、RNG 不变；shop→hand 原对象转移，原币/购买/消费计数如实变化。刷新产生新 offer 的 RNG/UID/库存变化须与 buy 分开观察。
- 当前已验 sale：`darkcrest_lava_play.gd:103-153` 基于原 native sale context，离场即删除该 `_board` custody 并记 `_retired[old_uid]`，成功时要求 gold+1/sold+1/Lava stock+1，原 hand、UID、RNG、spell_pool不变；late native failure 不宣称退款回滚。`preflight:37-45` 已拒 retired uid。新 offer / 新 UID 买入不会自动复活旧 record；实际公开 play 完成才生成新的 `_board[new_uid]`。

## 2. 三层真实缺口，购买投影是关键

### A. Live command admission

`darkcrest_host.gd:173-198`：active 包含 board/hand 中任意暗潮父牌或暗潮 token；buy 只允许普通 parent，否则 `darkcrest_other_purchase_held`。普通 Lava 放到手里后形状本已被 `hand_error` 接受，实际 play 已桥接，但 **active 状态下 buy 从未开放**。上一批 shop Lava 是在取得暗潮前购买，不证明本项成功。

### B. Detached whole-command projection authorization

`owned_purchase_host.gd:15-36` 为普通 gold buy 创建 detached Game，再执行 **同一个完整 public command**，成功后 live 才继续；这是付款前失败保证，不可针对 Lava 跳过。

`recruit_prefix_cursor.gd:22-92` 只深拷贝 plain public state 和独立 RNG cursor，明确不复制 pending context / 私有 issuance ledger。catalog 共享为只读定义，不是权限。于是 shadow 中的 parent/token 长得相同，不等于拥有 live 私有来源。

现 `darkcrest_host.gd:542-583` binder 仅 fresh 未 play 父卡购买：
1. `551` 要求 _grants/_spells/_cast/_delivery/_eot 全空；原暗潮一旦真实发过牌，历史记录仍在，不能“等 token 用掉”规避。
2. `552` board 和 Waiting 必须空；任何已出场暗潮都会失败。
3. `564-574` 只映射 shop/hand 的普通、tier1、last_eot=-1 父对象；无成熟 board 父、有效手牌 token、已过期/已用历史、Lava board/retired 映射。
4. `575` 还要求本次购买目标存在 parent records；Lava 永远不满足，即便前三项放开。
5. `561` 其他 owner 有 active 暗潮仍 hold，不能无意广开多 owner 投影。

因此先删 live buy hold 会随后撞 `darkcrest_post_grant_purchase_projection_held` / `darkcrest_nonfresh_purchase_projection_held`，不是实现成功。买入本身不触发塑造来源发牌，没必要为此把 live 发牌、cast、EOT 或 sale capability 全量拷进 shadow。

### C. 新 purchase 不能恢复旧 sale authority

sale `_retired` 有明确 cap128；买入新 UID 不应清理或复用旧 tombstone。新对象须是原 factory/真实 shop 接收产生、未出现在任何 owner zone 的 duplicate UID；具体 purchase 只转移其原对象。现 Lava custody 在实际 play 时绑定 owner/unit/UID/完整snapshot，不能在 purchase shadow 中预先写 live custody，更不能让 projection copy 成为下一次真实 play 的 actor。

## 3. 最小兼容设计建议（未实现）

1. **Live-only admission predicate**：精确 actual Game/host/owner/current command、真实 shop index/同对象和全局 UID 唯一性、完整 Lava source/shape/stock ownership、非 retired UID；购买前 Lava count==0，hand容量、普通 gold quote、现有 owner_error 均成功。拒绝任何未知额外 purchase program；不要拆除别的 host guard。
2. **单命令投影证据**：由已验证 live host 为这一次 buy 生成非序列化、限定 detached engine/owner/command/index/round/sequence 的投影只读证明。只映射该次 shadow 的确切 zone对象与值、现存普通暗潮的已验 tier/last_eot、手牌合法 token 的精确状态（若保留），以及目标 Lava offer 和退役拒绝事实。可用单独 projection-validation branch，而不是写 live issuance ledger；不得把任意 uid/同形复制当真。限定普通 shop-born 暗潮即可避免首版扩 generated-parent origin 桥。
3. **严禁全能 shadow**：该证明只允许同一次 `apply_command buy` 及内部 `_buy`，其余 play/cast/EOT/sell/Waiting/delivery 均不可借用；不能因为 projecting=true 全跳 owner_error。验证 exact public cursor、distinct engine/RNG、不可变 catalog；成功/失败都释放。返回只有验证结果，绝不把 shadow player/pool/RNG/receipt/custody拷回 live。
4. **保持真正的完整购买**：live 重验目标后仍走原 `_buy`，不另写扣币/发卡捷径、不手动加 stats 或避开 `_check_triples`。可在原买入调用边界观察实际 shop→hand receipt，但不要把影子“成功”当作 live 已付款。失败发生在付款后仍如实报告实际状态，不能凭 observer 作退款保证。
5. **后置证明**：核对 hand 中就是捕获的 offer、shop 仅移除该对象、board/现有token/暗潮tier/grant不变、币与原消费/购买计数正确、pool/spell_pool/UID/RNG不变。复用原 public Lava play→custody 与原 public sale→retirement。新 UID 仍走完整新 play，旧 UID 的 `_retired` 和旧对象拒绝不变。

第一版选“购买前无任何 Lava”既覆盖首次 active buy 又覆盖售后 rebuy，避免还得给 shadow 搬已有 Lava board custody。手牌中已生成 Lava 则明确 hold 本次买入，不等同于删掉随机输出候选。目标只是兼容可用状态，不改变随机分布。

## 4. 完整域 / 三连 / 库存 / RNG 边界

- 保留现有 `tests/darkcrest_tier6_20261112/real_matrix.gd` 的 ROOM6 **23个** current Naga/all 候选；它是该已验配置的完整暗潮可达域，不是全部最新版 catalog 的全玩法覆盖。不能为“找到 Lava”把 room/pool 只留暗潮+Lava，不能把不支持的候选从抽样后删掉或重抽。Tier2三正库存候选仍 `BG23_002, BG23_009, BG31_924`。
- 商店抽样是原 tavern tier eligible 域，不是暗潮 exact tier Naga抽样。预先 public upgrade 到6让真实 Tier5暗潮可出现；获取以后仍按原 paid roll / 原 round refresh 来找Lava，不伪造shop。Lava仅是要买的目标，其他真实 offer可以留下或按原刷新退库。
- `darkcrest_host.gd:392-410` 对任何暗潮施法先遍历完整正库存候选，任何可能输出会造成三连则在 RNG/stock/UID变更前拒绝。这条保持不变，不能为了购回Lava滤掉Lava候选。
- `game.gd:3746,7830-7869` 原 purchase 三连扫描仍执行。单Lava版本 pre-buy count==0 比“防第三只”更严格，第二只也不开放；不要把拒第二只当三连已经支持。暗潮父牌第三只限制及其他未知三连继承照旧。首版之外的另两只Lava、金色Lava及modified属性/attachment/used kept拒绝。
- 原售出只归还一个普通 copy；后续真实 refresh 可同时归还多张旧 offer并抽走多张新 offer，因此整次刷新不能只断言 `pool[Lava]-1`。逐条记录原 pool_draw 及最终 pool；buy单步应无二次扣库。卖出的实体不是可识别的一枚“物理牌库副本”，只说新抽出同 card_id，不说抽回同一对象。
- 新 UID 在原新 offer factory 时已经分配，不在 buy/play 时生成。重购若买的是售前已存在的另一 offer，只能证明“不同 UID 重购”，**不能**宣称“售后重新生成”。强验收应在 sale 后 public roll 实际生成新offer。
- 投影只能使用独立复制 RNG观测；不可推进/重置 live RNG、改 seed、改pool权重或next_uid。允许明确预定且有界的新房间seed计划，每个房间只走原public操作；不能在同局存档回滚抽牌或只公布成功输出假称全随机覆盖。
- 手牌满、资金不足、ready/非recruit、unsupported room modifiers、伪造/复用command、错owner/engine/index、retired UID、snapshot不匹配，均需付款前拒绝；原dispatcher正常拒绝日志与command sequence应单独按实际契约观察，不能盲目断言全部记录字节不变。无新增空位补发/满手消费玩法。

## 5. 最小实际测试建议（尚未运行，seed是否成功未知）

### 正向 1：首次 active buy + 售后新 factory UID rebuy，同一条真实链

1. 四玩家、现有 Edwin、不用技能，无anomaly/quest/reward/trinket；ROOM6原23域+现有Coin配置。沿既有公开升级/刷新准备真实暗潮与Lava offer共存。Coin若沿既有 `_unit(BG28_810)→_add_hand→public play` 资助，只能暗潮取得前用，并明确标注fixture，不能称整局天然获取。也可不用fixture、自然攒币但成本更高。
2. 公开 buy **普通暗潮 BG31_920**；公开 play，真实 Waiting发普通token，确保 **board非空且已有grant/token** 后再买Lava。这一顺序必须覆盖现在的两个projection hold，不能用“暗潮只在手里、从未发牌”的弱用例冒充。
3. public buy Lava：捕获原shop对象、UID、pool ownership、quote；验证原shop→原hand、gold - quote、bought/bought_minions +1、原spend计数正确、无live UID/RNG/stock变化；原暗潮私有tier/grant/token仍相同。再public play Lava，唯一新custody正确。
4. public sell Lava：重验已实现 gold+1/sold+1/pool+1、旧对象从全zones消失、old UID retired。之后只用 public roll / 自然下一轮收入找新offer。若起始fund10，买暗潮3、买Lava3、卖Lava+1后剩5，可负担至多2次1金币刷新并留3购买；不能失败后再用active Coin补预算。无自然目标就该seed无结果，换有界新房间，或在 tier<6 时走真实EOT拿下轮钱。
5. sale后生成的实际新Lava必须 `new_uid != old_uid`、`not is_same(new,old)`，新offer的出生发生在此次public refresh；公开buy→play、实际move→非空敌人combat→next recruit。旧退休记录仍在、旧对象/旧UID不能复活，新实体仍原2/5 kept0。
6. 新Lava可再public sell一次，得到第二条独立retirement。旧record不可被新record覆盖，retired数量准确+1，cap128保持原限，不做128次live耗尽宣称。

### 正向 2：成熟来源与后续完整随机域不受投影污染

另一个用例让暗潮已真实EOT成长至tier2/3，保留本轮真实token、上一轮已用/过期历史，再执行首次/售后buy；保证binder不是只能tier1。之后执行原完整域暗潮cast和下一次真实EOT，核对原token消费/来源tier/独立grant不变、不重发、不错误提升。若本用例手牌已有Lava则精确hold购买，而不是改随机结果。可在这批仍限定1父；若打开2父支持须加原source索引与两条独立成长票的真实用例。

### 拒绝与投影隔离

- 资金不足、满手、已有一只Lava再次buy、金色/modified/used Lava、原生不支持的modifier维持pre-debit hold；可真实取得的边界使用public取得，不向live zones灌坏实体。
- 单独 detached内容测试改shape/上下文/索引/序列/owner/engine/UID，不能写入live伪造成功。新投影在完成后不能调用play/EOT/sell，也不能把copy传给live Lava helper获得custody。每个拒绝比对真实pool/RNG/UID/币/zone对象及所有私有ledger；必要时只排除正常command审计增量。
- 以真实old sold引用调用只读preflight拒绝，以复制引用调用只读验证拒绝；不要为“证明能拒”把old实体重插到live board。确认新public play从新原对象创建新record，旧tombstone不动。
- 至少保留既有full-domain暗潮cast、原Lava play/EOT、sale和退役契约回归；本轮独立新用例不得重复旧初始化器然后把检查总数说成新增覆盖。测试源/日志/结果分别验证，不把check-only语法检查称Game验收。

## 6. 与 Mini 永久路线比较

Mini `BG23_000` / token `BG23_000t` 的来源合法且都已有完整原生程序，Lava第一张永久也早已实现，不需发明能力。但 active 暗潮混合仍有三个独立系统边界：Mini实际来源入场/EOT、非暗潮token Waiting/hand/target cast、Lava从2/5 kept0固定custody到永久buff/临时buff/下轮清除与reset的状态转移。上一报告的 A/B/C 在73ef3f4没有因新增sale而消失。

本次 rebuy 不需要任何新的目标法术、Waiting来源、buff、temporary层或回合计数语义；可复用现有 untouched Lava play/EOT/sale，新增主要是限定买入admission与单命令成熟暗潮投影。故它是更有限且可形成真实购买→作战→卖出→重购闭环的下一项。仍应称“普通未修改Lava购买兼容”，不能提升成Lava完整永久机制已验。

## 本次读取的关键源码 SHA-256

- `core/game.gd`: `62fc3191c86246c1b584ed4ab3fd9711f3c5c624434650a6c024d4b84745b3dc`
- `core/darkcrest_host.gd`: `2b449703f602f19bd24b4dc3a9721012b4b67f7dd649b80ffb47bab154cb8bb4`
- `core/darkcrest_lava_play.gd`: `cb82885d12989325ef980c845f38068bd62d0823efbd0c041b229ca50c62fa33`
- `core/owned_purchase_host.gd`: `1d8d6a09cf9be3f3ad7067c4ef3fd3b73ef7578adf640c7657c05fa1226fada6`
- `core/recruit_prefix_cursor.gd`: `73525b6481e32bea12af42ee13b2575185302f8ae7a415c0119a02de860f6900`
- `core/darkcrest_sources.gd`: `bfde94eac9dbaf747c6929e41078d87ceda8ec1bff0e754580bdca332cdaf080`

## 父任务后续收窄（准备runner时收到）

独立评估完成后，当前实现/测试改为成熟 shop-origin 暗潮、购买时无当前 token/Waiting/window；token存在是必须拒绝的负例，不实施本报告较宽的token投影建议。实际v3一房间只测一次新active买入：第一只Lava在暗潮取得前购买并留手，成熟后play/sell；再买另一售前已生成的真实shop offer、不同UID。它不证明首次active购买，也不证明售后refresh生成新offer。未来完整建议与本批实际验收范围应明确分开。测试仍有界真实shop搜索、原23候选域，资金无active Coin。
