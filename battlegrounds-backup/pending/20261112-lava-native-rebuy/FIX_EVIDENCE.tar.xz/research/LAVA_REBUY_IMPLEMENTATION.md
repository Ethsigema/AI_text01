# Narrow quiescent native Lava purchase candidate

Read preimage verified 27975 files, no mismatch, source73ef3f42. Six production files changed, no repin/upload/Game.

Host command_error admits only ordinary Lava via lava_purchase_error: actual original shop ref/unique UID, owned Lava zero, active ordinary shop-origin parent-only board, no current token/waiting/cast/delivery/EOT/Generation/play/sale window, owner_error unchanged, exact ordinary Lava2/5/kept0/poolcount int1, no retired target UID. Original gold quote/payment/listeners/hand transfer/triples stay native.

Historical grants are inspected as original parent refs plus legal delivered records. Historical spell records may be used or expired (old round usedfalse); either must be absent by object and UID across all player/ghost zones. No historical flags are mutated and no live grant/spell authority is copied.

Existing fresh-parent projection remains, plus a separate Lava mode allowing already-grown shop-origin parent scalar records. Full type-sensitive public cursor comparison (purchase_value_same) and matching shadow entity checks precede one-time installation. Only shadow-owned parent references enter its registry; no live helper/record reference is assigned. Whole OwnedPurchase shadow.apply_command remains untouched; no shadow state is returned to live. New shadow registry is observational for exactly the original/internal buy command.

_projection_only is permanent denial state: fresh/offered/grant/window/delivery/cast/consume/EOT, Generation actual, Lava actual, and direct Game._sell refuse. release clears projected records, generation/Lava helpers and command view but not taint. Released shadow command_error refuses; it cannot bind again. All potential bind failures precede installation. Parent/generation pure shape checks are not live authority.

API: lava_purchase_error(game,owner,offer), _purchase_history_error(game,owner,round), purchase_value_same(a,b,depth=0), existing bind_purchase_projection/release_purchase_projection. No new Lava birth/play receipt: successful buy produces native hand entity, original Game play must issue fresh custody. Old UID tombstones preserved; pre-existing second shop offer with distinct native UID qualifies, no claim it was newly manufactured after sale.

Test target: round3 natural5gold, frozen two native Lava offers, prior tokens expire; current token blocks buy until native cast3; buy/play/sell/rebuy/play then EOT/combat. Second owned body/golden/buff/triple/token/waiting remain held. Scope excludes generated Darkcrest parents, external mechanisms, odd-room fixes and six-after-EOT.

Validation so far: short Host/Lava/Generation syntax only, no actual native purchase test. Full behavior, hostile-state negatives and projection lifecycle tests remain pending.

## v2 review corrections
Projection engine checks use a WeakRef-typed predicate and reject malformed/missing engine without calling get_ref. purchase_detached_values recursively gathers all mutable containers from the full public-field bundle and rejects any cross-side reference intersection (including cross-field aliases), cycles, Objects and depth>128. It only validates detachment, not issuance. Binder also rejects shared live Generation/Lava helper objects. purchase_value_same now validates dictionary key types as well as recursively strict value types. Native sale operation begin rejects disposable host even if lower-level sale wrapper is invoked directly. V1 evidence retained; no global Sources.same changes; short Host syntax passed, no Game.

## v3 final freshness and test boundary
Binder additionally requires target Generation._host/_game null and target delivery_receipts empty, before installation. No broader reflection inspection added. V1/V2 SHA evidence retained; short Host syntax exit0. Current formal proposed case now buys first Lava before Darkcrest, later preserves a second native shop offer: mature source3, owned Lava purchase held, play/sell first, token-held negative then cast3, one active new-UID rebuy, play and EOT4. This would prove exactly one active purchase; second offer existed before sale, not a post-sale factory event. No actual Game test performed by this worker.

## v4 malformed projection fields
command_error validates WeakRef first, then owner strict int and both command payloads Dictionary before safe get comparisons. Missing/mistyped fields reject rather than throwing or matching missing fields to empty command. V1/V2/V3 preserved; short Host syntax exit0. No further scope additions; awaiting actual tests.
