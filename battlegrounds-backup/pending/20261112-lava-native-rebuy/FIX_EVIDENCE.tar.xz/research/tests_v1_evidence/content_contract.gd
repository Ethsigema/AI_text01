extends "res://tests/darkcrest_lava_sale_20261112/content_contract.gd"
# Detached purchase shape and released-projection refusal only, not live purchase.
func _initialize() -> void:
 check(Sources.proof_error().is_empty(),"complete_new_source_and_runtime_proof")
 var value={"gold":5,"pool":{"BG23_009":4},"nested":[1,true,"x",null]}
 check(Host.purchase_value_same(value,value.duplicate(true)),"exact_typed_purchase_snapshot")
 for field in ["gold","pool","nested"]:
  var missing=value.duplicate(true);missing.erase(field)
  check(not Host.purchase_value_same(value,missing) and not Host.purchase_value_same(missing,value),"missing_key_both_directions_"+field)
 for bad in [5.0,true,"5",null,[],{}]:
  var changed=value.duplicate(true);changed.gold=bad
  check(not Host.purchase_value_same(value,changed) and not Host.purchase_value_same(changed,value),"strict_scalar_type_"+str(bad))
 var changed=value.duplicate(true);changed.pool.BG23_009=4.0
 check(not Host.purchase_value_same(value,changed),"deep_pool_float_rejected")
 changed=value.duplicate(true);changed.nested[0]=1.0
 check(not Host.purchase_value_same(value,changed),"deep_array_float_rejected")
 changed=value.duplicate(true);changed.nested.reverse()
 check(not Host.purchase_value_same(value,changed),"deep_array_order_rejected")
 changed=value.duplicate(true);changed.extra=false
 check(not Host.purchase_value_same(value,changed),"extra_key_rejected")
 var opaque=RefCounted.new()
 check(not Host.purchase_value_same(opaque,opaque),"same_opaque_object_not_serialized_purchase_value")
 check(not Host.purchase_value_same({"x":opaque},{"x":opaque}),"nested_opaque_object_not_purchase_value")
 var nested={"leaf":1}
 for _i in range(130):nested={"next":nested}
 check(not Host.purchase_value_same(nested,nested),"over_depth_purchase_content_rejected")
 var cycle={};cycle.self=cycle
 check(not Host.purchase_value_same(cycle,cycle),"cyclic_purchase_content_rejected_without_recursing_forever")
 cycle.erase("self")
 var h=Host.new();var p={"id":0,"board":[],"hand":[],"shop":[]}
 var u={"card_id":"BG31_920","uid":"detached-parent"}
 var lava={"card_id":"BG23_009","uid":"detached-lava"}
 check(not h.lava_purchase_error({},p,lava).is_empty(),"fake_game_cannot_authorize_lava_purchase")
 check(not h.bind_purchase_projection({},{},0,{"type":"buy","index":0}).is_empty(),"fake_game_cannot_bind_projection")
 # This is a detached Host-only fixture; never set _projection_only on live Game.
 h._projection_only=true
 var before=[h._parents.duplicate(true),h._grants.duplicate(true),h._spells.duplicate(true)]
 check(not h.fresh({},u).is_empty(),"projection_cannot_issue_fresh_source")
 check(not h.offered(u).is_empty(),"projection_cannot_certify_shop_origin")
 check(not h.queue_error({},p,[u]).is_empty(),"projection_cannot_queue_grants")
 check(not h.register_grants({},p,[u]).is_empty(),"projection_cannot_register_grants")
 check(not h._window_error({},p,{}).is_empty(),"projection_cannot_bind_delivery_window")
 check(not h.cast_error({},p,{}).is_empty(),"projection_cannot_authorize_cast")
 check(not h.begin_cast({},p,0).is_empty(),"projection_cannot_begin_cast")
 check(not h.consume(p,{},{}).get("ok",true),"projection_cannot_consume_token")
 check(not h.end_error({},p).is_empty(),"projection_cannot_authorize_eot")
 check(not h.begin_eot({},p,{}).is_empty(),"projection_cannot_begin_eot")
 check(not h._eot_state_error({},p).is_empty(),"projection_cannot_execute_eot_state")
 check(not h._lava_play.preflight(h,{},p,lava).is_empty(),"unbound_projection_cannot_play_lava")
 check(not h._lava_play.sale_preflight(h,{},p,lava).is_empty(),"unbound_projection_cannot_sell_lava")
 check(not h._generation.begin(h,{},p).is_empty(),"unbound_projection_cannot_generate")
 check(Sources.same(before,[h._parents,h._grants,h._spells]) and h._cast.is_empty() and h._eot.is_empty() and h._delivery.is_empty() and h._generation._active.is_empty() and h._lava_play._pending.is_empty() and h._lava_play._sale_pending.is_empty(),"detached_rejections_issue_nothing")
 h.release_purchase_projection()
 check(h._projection_only,"release_does_not_promote_projection_to_live")
 check(not h.command_error({},p,{"type":"buy","index":0}).is_empty(),"released_projection_stays_held")
 print("DARKCREST_LAVA_REBUY_CONTENT_CONTRACT ",JSON.stringify({"passed":passed,"failed":failed,"failures":failures,"real_game_run":false,"scope":"detached typed purchase snapshots and projection authority refusal only","actual_purchase_proven":false}))
 quit(0 if failed==0 else 1)
