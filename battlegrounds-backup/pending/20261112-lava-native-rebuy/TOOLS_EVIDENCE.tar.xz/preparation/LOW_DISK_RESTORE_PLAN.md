# Low-disk complete remote restore and test plan (not executed)

Scope of this document is a proposed next-stage method. No dependencies were downloaded, no old restore scripts changed, and no new source was implemented by preparing it.

## Space and verified copies

Authorized cleanup targets only the two exact successful runtime copies in CLEANUP_PREFLIGHT.json. All immutable restores, candidates, baseline trees, packages, logs and failed/unaccepted work remain. After cleanup, copying the verified sale source into this stage's candidate uses about 1.63 GB allocated. From the prior 1.95 GB free plus about 3.27 GB reclaimed, the candidate should leave about 3.58 GB free. Fresh dependencies (~0.33 GB) plus one restored source tree (~1.63 GB) leave roughly 1.6 GB for evidence/cache/variation. Actual disk usage must be checked before download, restore, and testing.

## Actual fresh download and baseline restoration

1. In a new stage-only fresh_remote directory, freshly download original Release and all 24 fixed batch14 files at 5143e8fb41bc8332ce4ba196144172167a74318c. Download prior accepted sale metadata/package as required for provenance, and later all files from the newly published exact source commit. Pin URLs; verify lengths/Git blob SHA/SHA256/SUMS and every evidence member. Never substitute prior downloaded bytes for a claimed fresh download.
2. Invoke the UNMODIFIED fixed batch14 restore.py with fresh Release input, a new single destination (for example fresh_remote/work_source), and an external report. The reviewed script writes directly into the destination, builds payload bytes in memory, and does not create another extracted release tree. It refuses existing destinations.
3. Independently full-scan this actual baseline: exact paths, no symlinks/special files, each size/SHA, 27,920 files and aggregate 5ba04ef124fc78cf20e2a942a60589fb92dc76e6808155648226a534a4599e05. Save baseline receipt externally before applying any change. No additional retained fresh baseline tree is claimed.

## New explicit single-tree cumulative application tool, subject to review

The existing restore_increment.py cannot do this: it requires a nonexistent destination and copies all files. Do not overwrite it or misrepresent running it. Add a separate, clearly named low-disk applier after authorization and review; package its actual source, tests, and instructions with the new stage.

Its required contract:
- Accept only the exact NEW stage-owned working tree, bound to a completed current baseline receipt and canonical resolved path. Reject old restored_snapshot/restored_base, candidate, symlink, nested package or arbitrary existing paths. Exclusive common Game lock throughout.
- Before any mutation, rescan all actual baseline files and exact path set; verify canonical baseline map/aggregate, all new package bytes, manifest base linkage, target map construction, declared count/bytes/aggregate, complete changed/removed sets, and every delta archive member. Reject links, special files, duplicate/unsafe paths, unknown removals and extra members. Check enough free space for all changed bytes plus a reserve.
- Apply ONLY fully validated delta members, with atomic replacement from temporary files located on the same new tree filesystem. Remove only manifest-declared baseline files in this new temporary tree. Do not extract uncontrolled tar paths. Ensure no symlink ancestors. No touching older baseline trees or backups.
- Record application-start and completed status outside the tree. Any interruption leaves this one disposable tree explicitly incomplete, not a verified baseline or target; do not blindly retry/continue. Diagnose and rebuild only the new tree under authorized recovery steps; retained dependency bytes allow a deterministic rebuild.
- After application, reread every target file and exact path set and calculate target SHA aggregate; enforce manifest aggregate equality. Save a clear distinct PASS_FRESH_SINGLE_TREE_CUMULATIVE_RESTORE report, not the old two-tree restore status. Rehash once more independently before testing. Verify development candidate separately against the same fixed source map.

## Test the newly restored tree without a second runtime copy

After parent authorization, run one strictly serialized Game process directly from this fresh fixed-source tree, with wrappers/results/logs, HOME, cache, config and user data all OUTSIDE it. Preserve full baseline-then-target recovery receipts and exact commands. Before and after each agreed boundary, verify all source files, no extra generated files, and aggregate. Any mutation/cache added to source is a test-integrity failure, not silently ignored or removed.

This uses one remote-restored/tested tree, not two separate fresh immutable/runtime copies. Reports and README must say so. It preserves independence from the development candidate and reconstructibility from fixed remote dependencies, while avoiding the extra 1.63 GB runtime duplicate. Do not label two repeated scans of the same tree as two independently restored trees. No old immutable source or baseline is ever modified.

Pending: scope confirmation, new applier implementation/review and synthetic negative tests, frozen source upload, actual fresh downloads/recovery and Game. This document alone proves none of those steps.
