extends "res://tests/darkcrest_lava_permanent_20261112/real_matrix.gd"
