extends RefCounted
## Pinned Cursed Crystal revision. Partial holds and previous proof boundaries remain.
const REVISION: String="partial-37.0.2-timewarp_chimera_golden-rebuilt-20261107"
const ID: String="BG34_Giant_679_G"
const OVERLAY: String="data/patch_3702_timewarp_chimera_golden_overlay.json"
const FILE_SHA256: Dictionary={"data/patch_3702_timewarp_chimera_golden_overlay.json":"996e1cf62be64a30153e3fcb4b00b98af77b3b0c993c1477d8599e1ce92a9b29","research/patch_3702_timewarp_chimera_golden/BG34_Giant_679_G.native.xml":"c140a58be2cda960ae709fb5871f9bdcb9e1964260afb2ffe2bb346a392b342f","research/patch_3702_timewarp_chimera_golden/evidence.json":"6ebca050b3a278a45b500fb599590da77272e174cea588e0994528b955dc88c0","core/timewarp_chimera_host.gd":"05223d521e809b4f28a963108d1f4a6b4eec83347a618a36d05d8a969fd1e125","core/game.gd":"c7c954864167e12f272cff1c7ff9fa7d360e43cfd8ddd3846ddf26fd10a79381","core/combat.gd":"d341b6c2afd08018822ffbdb1399382c95c072916269425fdf8b50b8484683ca","core/kill_reward_host.gd":"5752f3f8e3a2de745496ddd665f8ea9d3fa2c399741bd975655fe261ecb40957","core/chimera_recruit_damage.gd":"d41f2c29632b0b7735ade6a9759b0929173fdd598336c8a390374e9558eb66ee","core/recruit_minion_damage.gd":"8cece15e79418812c15defe96525bd6d2cd5c07eabafe6c6f48c85623201d4ed"}
const RUNTIME_PATHS: Array=["core/patch_3702_timewarp_chimera_golden_sources.gd","core/catalog.gd","data/patch_3702_timewarp_chimera_golden_overlay.json","research/patch_3702_timewarp_chimera_golden/BG34_Giant_679_G.native.xml","research/patch_3702_timewarp_chimera_golden/evidence.json","core/timewarp_chimera_host.gd","core/game.gd","core/combat.gd","core/kill_reward_host.gd","core/chimera_recruit_damage.gd","core/recruit_minion_damage.gd"]
const EXPECTED_RAW: Dictionary={}
const EXPECTED_COMPILED: Dictionary={}
const EXPECTED_BASELINE: Dictionary={}
const EFFECTIVE_FIELDS: Dictionary={"attack":2,"health":16,"text":"每当本随从受到伤害，使每个类型的各一个友方随从永久获得+2/+1，触发两次。","supported":true,"effects":[{"type":"timewarp_chimera_received_each_type","source_id":"BG34_Giant_679_G","attack":2,"health":1,"count":2}],"keywords":[],"pool_supported":false,"default_pool":false,"coverage_text_sha256":"878fcf3aab914959bc2be2dbd5f6575a9a98b83bb4607e6b6192ec2c69c62ea3","implementation_status":"partial_combat_and_nonlethal_recruit_bridge","conditional_support":{"rule":"timewarp_chimera_combat_permanent_rebuilt_20261107","reason":"Combat damage and bounded nonlethal recruit damage supported. Natural Clefthoof end-turn packets use existing randomized maximum matching for ambiguous types, with projected RNG and authenticated commit. Artificial damage callers, lethal/protected packets, competing observers and natural acquisition remain partial."},"pool_blocker":"没有已确认的普通商店随从资格；衍生物、伙伴或时空扭曲内容需由对应机制生成，或显式配置自定义入店参数。","id":"BG34_Giant_679_G","card_code":"BG34_Giant_679_G","dbf_id":"129429","name":"时空扭曲奇美拉","kind":"minion","category":"随从","categories":["随从","时空扭曲"],"mechanisms":["时空扭曲"],"tier":3,"cost":null,"tribes":["全部"],"is_golden":true,"normal_id":"BG34_Giant_679","golden_id":null,"image":"","solo_eligible":true,"source_url":"https://github.com/HearthSim/hsdata","native_source_build":"37.0.2.256589"}
const EXPECTED_CURRENT: Dictionary={"attack":2,"health":16,"text":"每当本随从受到伤害，使每个类型的各一个友方随从永久获得+2/+1，触发两次。","supported":true,"effects":[{"type":"timewarp_chimera_received_each_type","source_id":"BG34_Giant_679_G","attack":2,"health":1,"count":2}],"keywords":[],"pool_supported":false,"default_pool":false,"coverage_text_sha256":"878fcf3aab914959bc2be2dbd5f6575a9a98b83bb4607e6b6192ec2c69c62ea3","implementation_status":"partial_combat_and_nonlethal_recruit_bridge","conditional_support":{"rule":"timewarp_chimera_combat_permanent_rebuilt_20261107","reason":"Combat damage and bounded nonlethal recruit damage supported. Natural Clefthoof end-turn packets use existing randomized maximum matching for ambiguous types, with projected RNG and authenticated commit. Artificial damage callers, lethal/protected packets, competing observers and natural acquisition remain partial."},"pool_blocker":"没有已确认的普通商店随从资格；衍生物、伙伴或时空扭曲内容需由对应机制生成，或显式配置自定义入店参数。","id":"BG34_Giant_679_G","card_code":"BG34_Giant_679_G","dbf_id":"129429","name":"时空扭曲奇美拉","kind":"minion","category":"随从","categories":["随从","时空扭曲"],"mechanisms":["时空扭曲"],"tier":3,"cost":null,"tribes":["全部"],"is_golden":true,"normal_id":"BG34_Giant_679","golden_id":null,"image":"","solo_eligible":true,"source_url":"https://github.com/HearthSim/hsdata","native_source_build":"37.0.2.256589"}

static func accepts_id(value: Variant) -> bool:
	return value is String and value==ID

static func same(actual: Variant,expected: Variant) -> bool:
	# JSON integral floats are admissible. Booleans/strings/fractions/nonfinite values are not numbers.
	if expected is int or expected is float:
		return (actual is int or actual is float) and not actual is bool and is_finite(float(actual)) and is_finite(float(expected)) and actual==floor(actual) and expected==floor(expected) and actual==expected
	if typeof(actual)!=typeof(expected): return false
	if expected is Dictionary:
		if actual.size()!=expected.size(): return false
		for key in expected:
			if not actual.has(key) or not same(actual[key],expected[key]): return false
		return true
	if expected is Array:
		if actual.size()!=expected.size(): return false
		for index in range(expected.size()):
			if not same(actual[index],expected[index]): return false
		return true
	return actual==expected

static func proof_error() -> String:
	# Startup-only disk proof. Hot source_error/program/get_card never calls this.
	for path in FILE_SHA256:
		if not FileAccess.file_exists("res://"+path) or FileAccess.get_sha256("res://"+path)!=FILE_SHA256[path]: return "partial_3702_timewarp_chimera_golden_evidence_changed:"+str(path)
	var packet: Variant=JSON.parse_string(FileAccess.get_file_as_string("res://"+OVERLAY))
	var expected_packet: Dictionary={"revision":REVISION,"cards":[{"id":ID,"expected_raw":EXPECTED_RAW,"expected_compiled":EXPECTED_COMPILED,"expected_baseline":EXPECTED_BASELINE,"effective_fields":EFFECTIVE_FIELDS}]}
	if not same(packet,expected_packet): return "partial_3702_timewarp_chimera_golden_changed_packet"
	var baseline: Dictionary=EXPECTED_RAW.duplicate(true);baseline.merge(EXPECTED_COMPILED,true)
	if not same(baseline,EXPECTED_BASELINE): return "partial_3702_timewarp_chimera_golden_invalid_baseline_derivation"
	baseline.merge(EFFECTIVE_FIELDS,true)
	if not same(baseline,EXPECTED_CURRENT) or str(EXPECTED_CURRENT.text).sha256_text()!=EXPECTED_CURRENT.coverage_text_sha256: return "partial_3702_timewarp_chimera_golden_invalid_current_derivation"
	return ""

static func input_error(decoded: Variant,path: String) -> String:
	# Called before generic numeric normalization. Historical input is authenticated in full.
	var expected: Dictionary={}
	if path=="res://data/catalog_raw.json": expected=EXPECTED_RAW
	elif path=="res://data/catalog.json": expected=EXPECTED_COMPILED
	if not decoded is Dictionary or not decoded.get("cards") is Array:
		return "partial_3702_timewarp_chimera_golden_missing_input:"+path if not expected.is_empty() else ""
	var matches: Array=[]
	for card in decoded.cards:
		if card is Dictionary and accepts_id(card.get("id")): matches.append(card)
	if expected.is_empty(): return "" if matches.is_empty() else "partial_3702_timewarp_chimera_golden_unexpected_input:"+path
	if matches.size()!=1: return "partial_3702_timewarp_chimera_golden_missing_or_duplicate_input:"+path
	return "" if same(matches[0],expected) else "partial_3702_timewarp_chimera_golden_changed_whole_input:"+path

static func apply_overlay(cards: Dictionary) -> String:
	if cards.has(ID): return "timewarp_chimera_golden_unexpected_existing_source"
	cards[ID]=EXPECTED_CURRENT.duplicate(true)
	return ""

static func source_error(card: Dictionary) -> String:
	# Small in-memory, typed, exact whole-current-row guard. No file access or hashing.
	if not accepts_id(card.get("id")): return "partial_3702_timewarp_chimera_golden_unknown_source"
	return "" if same(card,EXPECTED_CURRENT) else "partial_3702_timewarp_chimera_golden_changed_whole_effective_source"
