extends RefCounted
## Selected greater 914t source revision. Not a pool or cross-family admission grant.
const REVISION: String="partial-37.0.2-greater-nerglish-phrasebook-v1"
const ID: String="BG30_MagicItem_914t"
const OVERLAY: String="data/patch_3702_greater_phrasebook_overlay.json"
const FILE_SHA256: Dictionary={"data/patch_3702_greater_phrasebook_overlay.json":"b7f2efa3890a54626e3e8cbbc65481e8b4177c210d8d1daec16f50bb82166aa6","research/patch_3702_greater_phrasebook/source_evidence.json":"0141a4200b1e7f43981c1ed5871276263f25c29cf5ed957b0714f513566f4896","research/patch_3702_greater_phrasebook/official_greater_phrasebook_excerpt.html":"3ab81628a2ea69d62a584658fd28ec9d31fcc496884f90b379e42e7de1b624c3","research/patch_3702_greater_phrasebook/native/BG30_MagicItem_914t.xml":"35f7cce425cb6895f58ca08f64e8a80afdb508962609334c84570460c39b99a3","core/game.gd":"c7c954864167e12f272cff1c7ff9fa7d360e43cfd8ddd3846ddf26fd10a79381","core/mechanism_effects.gd":"2bf8270878cbac39508ddbc588607340a3686f650547d7d5e4260b8ec25c7496","core/room_config.gd":"5ad842f365651173c745f4210fb5c69e2f93b67893959c75f0931cacc0b1382d","core/current_scope.gd":"a1e8c5d0b2e434aa3c95cf61ce5b8734027c3df0666a63c8d07d8b24e9d94e64","core/trinket_offer_schedule.gd":"a0820faab3bc89c7e6deaf85916f8bb1af3eb09bbbf5ca3d00a94c07409f31ec","core/damage_listener_room.gd":"cd3c7d104698f51b8ddf6b627d1a753f442778d00adc0ddb9e3c5287b2ac8287","core/lobby_tribes.gd":"96b74fb21b8876353defb8e457d6ee0f3e888fea59c2f810eaf9a552adceea6a","core/patch_3702_membership_sources.gd":"8b4a4f4981553125213b1d3a0cc80f66d7f54b229dcb74329430e6e4a5654842","data/current_scope_manifest.json":"60ba04da35d3db6933f5177207f70e713da5efa2ebc0707c863a24248de2fcff","data/patch_3702_membership.json":"8c72c5c371d4566afce4839cc5f2f95ead1c133fda9324f72bd054b004fc3e9c","data/tribe_pool_requirements.json":"cfcb116ed73f38ab77679ee9bb6ccb2c241f0e813b3f16a6fae3577cd956fde1","core/end_turn_category_room.gd":"3420a55c99ac4e538ef74890b6b0c7d37b5ec935f7f57ba902c9e40cc93c6e30","core/rule_gates.gd":"ba6b2237f9b0d99022e79d1805de16e1455d9895329d2a62e15ac5f5fc5cc655","core/patch_3702_murloc_phrasebook_sources.gd":"9f9048d6ac8a464fa7bb8a15d87d36dd1392b3783bc9231268cba3a9150bf26e","data/patch_3702_murloc_phrasebook_overlay.json":"c674d8181c8e099046b88d32791e9191e038d03fe5a5ae806e335e975ed756fe"}
const RUNTIME_PATHS: Array=["core/patch_3702_greater_phrasebook_sources.gd","data/patch_3702_greater_phrasebook_overlay.json","research/patch_3702_greater_phrasebook/source_evidence.json","research/patch_3702_greater_phrasebook/official_greater_phrasebook_excerpt.html","research/patch_3702_greater_phrasebook/native/BG30_MagicItem_914t.xml","core/game.gd","core/mechanism_effects.gd","core/room_config.gd","core/current_scope.gd","core/trinket_offer_schedule.gd","core/damage_listener_room.gd","core/lobby_tribes.gd","core/patch_3702_membership_sources.gd","data/current_scope_manifest.json","data/patch_3702_membership.json","data/tribe_pool_requirements.json","core/end_turn_category_room.gd","core/rule_gates.gd","core/patch_3702_murloc_phrasebook_sources.gd","data/patch_3702_murloc_phrasebook_overlay.json"]

static func accepts_id(greater_phrasebook_identity: Variant) -> bool:
	return greater_phrasebook_identity is String and greater_phrasebook_identity==ID

static func same(greater_phrasebook_actual: Variant,greater_phrasebook_expected: Variant) -> bool:
	# JSON parses numbers as floats; accept only finite integral numeric equality.
	# In particular, booleans, fractional values and strings are never numbers.
	if greater_phrasebook_expected is int or greater_phrasebook_expected is float:
		return (greater_phrasebook_actual is int or greater_phrasebook_actual is float) and not greater_phrasebook_actual is bool and is_finite(float(greater_phrasebook_actual)) and is_finite(float(greater_phrasebook_expected)) and greater_phrasebook_actual==floor(greater_phrasebook_actual) and greater_phrasebook_expected==floor(greater_phrasebook_expected) and greater_phrasebook_actual==greater_phrasebook_expected
	if typeof(greater_phrasebook_actual)!=typeof(greater_phrasebook_expected): return false
	if greater_phrasebook_expected is Dictionary:
		if greater_phrasebook_actual.size()!=greater_phrasebook_expected.size(): return false
		for greater_phrasebook_key in greater_phrasebook_expected:
			if not greater_phrasebook_actual.has(greater_phrasebook_key) or not same(greater_phrasebook_actual[greater_phrasebook_key],greater_phrasebook_expected[greater_phrasebook_key]): return false
		return true
	if greater_phrasebook_expected is Array:
		if greater_phrasebook_actual.size()!=greater_phrasebook_expected.size(): return false
		for greater_phrasebook_index in range(greater_phrasebook_expected.size()):
			if not same(greater_phrasebook_actual[greater_phrasebook_index],greater_phrasebook_expected[greater_phrasebook_index]): return false
		return true
	return greater_phrasebook_actual==greater_phrasebook_expected

static func normalize(greater_phrasebook_value: Variant) -> Variant:
	if greater_phrasebook_value is float and is_finite(greater_phrasebook_value) and greater_phrasebook_value==floor(greater_phrasebook_value) and greater_phrasebook_value>=-9007199254740991 and greater_phrasebook_value<=9007199254740991: return int(greater_phrasebook_value)
	if greater_phrasebook_value is Array:
		var greater_phrasebook_items: Array=[]
		for greater_phrasebook_item in greater_phrasebook_value: greater_phrasebook_items.append(normalize(greater_phrasebook_item))
		return greater_phrasebook_items
	if greater_phrasebook_value is Dictionary:
		var greater_phrasebook_fields: Dictionary={}
		for greater_phrasebook_key in greater_phrasebook_value: greater_phrasebook_fields[greater_phrasebook_key]=normalize(greater_phrasebook_value[greater_phrasebook_key])
		return greater_phrasebook_fields
	return greater_phrasebook_value

static func proof_error() -> String:
	for greater_phrasebook_path in FILE_SHA256:
		if not FileAccess.file_exists("res://"+greater_phrasebook_path) or FileAccess.get_sha256("res://"+greater_phrasebook_path)!=FILE_SHA256[greater_phrasebook_path]: return "partial_3702_greater_phrasebook_evidence_changed:"+str(greater_phrasebook_path)
	return ""

static func packet() -> Dictionary:
	if not proof_error().is_empty(): return {}
	var greater_phrasebook_packet: Variant=JSON.parse_string(FileAccess.get_file_as_string("res://"+OVERLAY))
	if not greater_phrasebook_packet is Dictionary or greater_phrasebook_packet.get("revision")!=REVISION or not greater_phrasebook_packet.get("cards") is Array or greater_phrasebook_packet.cards.size()!=1: return {}
	var greater_phrasebook_row: Variant=greater_phrasebook_packet.cards[0]
	if not greater_phrasebook_row is Dictionary or not accepts_id(greater_phrasebook_row.get("id")): return {}
	for greater_phrasebook_field in ["expected_raw","expected_compiled","expected_baseline","effective_fields"]:
		if not greater_phrasebook_row.get(greater_phrasebook_field) is Dictionary: return {}
	return normalize(greater_phrasebook_row)

static func input_error(greater_phrasebook_input: Variant,greater_phrasebook_path: String) -> String:
	var greater_phrasebook_field: String=""
	if greater_phrasebook_path=="res://data/catalog_raw.json": greater_phrasebook_field="expected_raw"
	elif greater_phrasebook_path=="res://data/catalog.json": greater_phrasebook_field="expected_compiled"
	if not greater_phrasebook_input is Dictionary or not greater_phrasebook_input.get("cards") is Array:
		return "partial_3702_greater_phrasebook_missing_input:"+greater_phrasebook_path if not greater_phrasebook_field.is_empty() else ""
	var greater_phrasebook_matches: Array=[]
	for greater_phrasebook_card in greater_phrasebook_input.cards:
		if greater_phrasebook_card is Dictionary and accepts_id(greater_phrasebook_card.get("id")): greater_phrasebook_matches.append(greater_phrasebook_card)
	if greater_phrasebook_field.is_empty():
		return "partial_3702_greater_phrasebook_unexpected_input:"+greater_phrasebook_path if not greater_phrasebook_matches.is_empty() else ""
	if greater_phrasebook_matches.size()!=1: return "partial_3702_greater_phrasebook_missing_or_duplicate_input:"+greater_phrasebook_path
	var greater_phrasebook_row: Dictionary=packet()
	if greater_phrasebook_row.is_empty(): return "partial_3702_greater_phrasebook_missing_or_changed_packet"
	return "" if same(greater_phrasebook_matches[0],greater_phrasebook_row[greater_phrasebook_field]) else "partial_3702_greater_phrasebook_changed_whole_input:"+greater_phrasebook_path

static func apply_overlay(greater_phrasebook_cards: Dictionary) -> String:
	var greater_phrasebook_row: Dictionary=packet()
	if greater_phrasebook_row.is_empty(): return "partial_3702_greater_phrasebook_missing_or_changed_packet"
	if not greater_phrasebook_cards.has(ID) or not same(greater_phrasebook_cards[ID],greater_phrasebook_row.expected_baseline): return "partial_3702_greater_phrasebook_changed_whole_baseline"
	var greater_phrasebook_merged: Dictionary=greater_phrasebook_cards[ID].duplicate(true)
	greater_phrasebook_merged.merge(greater_phrasebook_row.effective_fields,true)
	if str(greater_phrasebook_merged.text).sha256_text()!=greater_phrasebook_merged.coverage_text_sha256: return "partial_3702_greater_phrasebook_changed_text_digest"
	greater_phrasebook_cards[ID]=greater_phrasebook_merged
	return ""

static func source_error(greater_phrasebook_card: Dictionary) -> String:
	if not accepts_id(greater_phrasebook_card.get("id")): return "partial_3702_greater_phrasebook_unknown_source"
	var greater_phrasebook_row: Dictionary=packet()
	if greater_phrasebook_row.is_empty(): return "partial_3702_greater_phrasebook_missing_or_changed_packet"
	var greater_phrasebook_expected: Dictionary=greater_phrasebook_row.expected_baseline.duplicate(true)
	greater_phrasebook_expected.merge(greater_phrasebook_row.effective_fields,true)
	# Preserve the entire source, including original flags, category and provenance.
	# This check never promotes support and continues through Catalog's old gates.
	return "" if same(greater_phrasebook_card,greater_phrasebook_expected) else "partial_3702_greater_phrasebook_changed_whole_effective_source"
