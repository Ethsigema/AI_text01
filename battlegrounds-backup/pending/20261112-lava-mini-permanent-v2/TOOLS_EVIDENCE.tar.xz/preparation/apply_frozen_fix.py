from pathlib import Path
import datetime,fcntl,hashlib,json,shutil
r=Path(__file__).resolve().parents[1]; p=r/'candidate'; evidence=r/'evidence'
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
def save(name,data):
    (evidence/name).write_text(json.dumps(data,indent=2)+'\n')
with (r.parent/'develop_empty_ghost_20261112/.independent_full_game.lock').open('r') as lock:
    fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    assert (r/'preparation/CANDIDATE_PREIMAGE_VERIFIED.json').exists()
    assert not (evidence/'APPLIED_NATIVE_KEY_FIX_V2.json').exists()
    evidence.mkdir(exist_ok=True)
    helper=json.loads((r/'research/MINI_NATIVE_KEY_V5_FROZEN_SHA256.json').read_text())
    tests=json.loads((r/'research/TESTS_V2_FROZEN_SHA256.json').read_text())
    changes={}
    for name,expected in helper['files'].items():
        src=r/'implementation_overlay'/name; dst=p/name
        assert sha(src)==expected and sha(dst)==helper['preimage_sha256']
        changes[name]={'before':sha(dst),'after':expected};shutil.copyfile(src,dst)
    for name,record in tests['records'].items():
        src=r/'tests_overlay'/name;dst=p/'tests/darkcrest_lava_permanent_20261112'/name
        assert src.stat().st_size==record['bytes'] and sha(src)==record['sha256']
        changes[dst.relative_to(p).as_posix()]={'before':sha(dst),'after':record['sha256']};shutil.copyfile(src,dst)
    old='darkcrest-mini-first-permanent-candidate-20261112'
    new='darkcrest-mini-native-key-repair-candidate-20261112'
    for name in ['core/darkcrest_sources.gd','data/darkcrest_overlay.json']:
        dst=p/name;s=dst.read_text();assert s.count(old)==1
        before=sha(dst);dst.write_text(s.replace(old,new));changes[name]={'before':before,'after':sha(dst)}
    shutil.copyfile(r/'preparation/CANDIDATE_PREIMAGE_SOURCE_SHA256.json',r/'PREIMAGE_HASHES.json')
    save('APPLIED_NATIVE_KEY_FIX_V2.json',{'status':'UNACCEPTED_FIX_APPLIED_NO_GAME','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'changes':changes,'old_failed_source_untouched':True,'authority_or_comparator_widened':False})
    print(json.dumps({'applied':len(changes),'status':'UNACCEPTED_FIX_APPLIED_NO_GAME'},indent=2))
