"""Exact frozen-test JSON/log validator examples, never gameplay or execution proof.

All full scenario values below are deliberately synthetic detached JSON. No live
entity is created, mutated, or sent to Godot. Old matrix initializers never run.
"""
from pathlib import Path
from copy import deepcopy
import json
import tempfile
import run_remote_lava_permanent as r


def rejected(fn,label):
    try:fn()
    except (ValueError,AssertionError,KeyError,TypeError,FileNotFoundError):return label
    raise AssertionError('Validator accepted synthetic negative: '+label)


def full_fixture():
    marker_lines=['PASS '+name for name,count in r.PERMANENT_FULL_MARKERS.items() for _ in range(count)]
    marker_lines+=['PASS public_darkcrest_play_u30','PASS synthetic_unpinned_dynamic_funding_count']
    n=len(marker_lines)
    log='DARKCREST_LAVA_PERMANENT_MATRIX_LOAD_BEGIN\n'+'\n'.join(marker_lines)+'\nDARKCREST_LAVA_PERMANENT_REAL_MATRIX_PASS cases=1 casts=2 combats=3 checks='+str(n)+'\n'
    diagnostic={'native_factory_preview':True,'actual_token_issuance':False,'uid_allocated':False,'zone_inserted':False,
                'shape_error':'','key_types':[{'key':key,'key_type':pair[0],'value_type':pair[1]} for key,pair in r.NATIVE_PREVIEW_TOP_TYPES.items()],
                'base_key_types':[{'key':key,'key_type':pair[0],'value_type':pair[1]} for key,pair in r.NATIVE_PREVIEW_BASE_TYPES.items()]}
    log='MINI_NATIVE_PREVIEW_KEY_TYPES '+json.dumps(diagnostic)+'\n'+log
    row={'native_preview_diagnostic':diagnostic,'scope':r.NEW_TEST_METADATA['scope'],'seed':20261120,'checks':n-1,
         'acquisitions':[{'id':'BG23_000','uid':'u10','rolls':0,'source_owned':False},
                         {'id':'BG23_009','uid':'u20','rolls':100,'source_owned':False}],
         'mini_uid':'u10','lava_uid':'u20','darkcrest_uid':'u30','darkcrest_final_tier':4,
         'casts':[{'round':number,'source_uid':'u10','token_uid':uid,'target_uid':'u20',
                   'attack_before':before,'attack_after':after,'health':5,'kept':1}
                  for number,uid,before,after in [(1,'u40',2,4),(2,'u50',4,6)]],
         'combats':[{'round':number,'target_uid':'u20','combat_start':{'uid':'u20','card_id':'BG23_009',
                     'kind':'minion','attack':attack,'health':5,'max_health':5,'golden':False},
                     'recruit_attack':attack,'recruit_health':5,'recruit_kept':0}
                    for number,attack in [(1,4),(2,6),(3,6)]],
         'unused_token_expiry':{'old_token_uid':'u60','new_token_uid':'u70','cast_count_before':20,
                   'cast_count_after':20,'attack':6,'kept':0,'round':4},
         'coin_pre_source_fixture':True,'entirely_natural_game':False,'same_turn_second_cast_tested':False,
         'buffed_sale_rebuy_opened':False,'old_matrices_repeated':False}
    return row,log,n


def main():
    passed=[]
    original_actual_count=r.NEW_TEST_METADATA['pure_checks']
    assert original_actual_count in [None,344]
    r.NEW_TEST_METADATA['pure_checks']=344  # Synthetic test contract only, not an observed runtime result.
    row,log,n=full_fixture()
    with tempfile.TemporaryDirectory(prefix='permanent_schema_synthetic_',dir=Path(__file__).parent) as directory:
        root=Path(directory);path=root/r.NEW_TEST_METADATA['scenario_file']
        def check_full(value,text=log):
            if text==log and 'native_preview_diagnostic' in value:
                text='MINI_NATIVE_PREVIEW_KEY_TYPES '+json.dumps(value['native_preview_diagnostic'])+'\n'+'\n'.join(text.splitlines()[1:])+'\n'
            path.write_text(json.dumps(value))
            return r.validate('lava_permanent_real_matrix',text,None,root)
        count,observed=check_full(row)
        assert count==n and observed==row
        passed.append('synthetic_two_cast_three_combat_unused_expiry_exact_schema_positive_NOT_GAMEPLAY')
        wrong=deepcopy(row);wrong['cases']=[{}]
        passed.append(rejected(lambda:check_full(wrong),'old_cases_array_schema_refused'))
        mutations=[
            (['checks'],n,'JSON_checks_must_be_final_PASS_count_minus_one'),
            (['checks'],True,'boolean_check_count_refused'),
            (['seed'],20261121,'wrong_seed_refused'),
            (['scope'],'all Spellcraft supported','overbroad_scope_refused'),
            (['darkcrest_final_tier'],3,'old_source_tier_refused'),
            (['coin_pre_source_fixture'],False,'coin_fixture_cannot_be_hidden'),
            (['entirely_natural_game'],True,'false_natural_game_claim_refused'),
            (['same_turn_second_cast_tested'],True,'unproven_same_turn_second_cast_claim_refused'),
            (['buffed_sale_rebuy_opened'],True,'unproven_buffed_sale_claim_refused'),
            (['old_matrices_repeated'],True,'legacy_matrix_claim_refused'),
            (['mini_uid'],'u20','same_minion_UID_refused'),
            (['mini_uid'],'fixture-1','non_native_UID_refused'),
            (['acquisitions',0,'source_owned'],True,'active_Mini_acquisition_not_tested'),
            (['acquisitions',0,'rolls'],81,'Mini_roll_bound_refused'),
            (['acquisitions',1,'rolls'],101,'Lava_roll_bound_refused'),
            (['acquisitions',1,'rolls'],True,'boolean_roll_count_refused'),
            (['acquisitions',1,'uid'],'u10','mismatched_acquisition_UID_refused'),
            (['casts',1,'round'],1,'same_turn_second_cast_not_the_scenario'),
            (['casts',1,'source_uid'],'u30','Darkcrest_cannot_be_claimed_Mini_token_source'),
            (['casts',1,'target_uid'],'u10','non_Lava_target_refused'),
            (['casts',1,'attack_before'],2,'second_cast_chain_refused'),
            (['casts',1,'attack_after'],8,'wrong_permanent_attack_refused'),
            (['casts',1,'health'],7,'unrequested_health_buff_refused'),
            (['casts',1,'kept'],0,'missing_kept1_refused'),
            (['casts',1,'token_uid'],'u40','copied_used_token_UID_refused'),
            (['combats',2,'round'],2,'duplicate_combat_round_refused'),
            (['combats',2,'recruit_attack'],2,'lost_permanent_attack_refused'),
            (['combats',2,'recruit_kept'],1,'missing_native_reset_refused'),
            (['combats',0,'combat_start','attack'],2,'combat_copy_must_carry_buff'),
            (['combats',0,'combat_start','golden'],True,'golden_Lava_not_in_scope'),
            (['combats',0,'combat_start','card_id'],'BG23_000','wrong_combat_copy_refused'),
            (['unused_token_expiry','cast_count_after'],21,'unused_expiry_cannot_increment_casts'),
            (['unused_token_expiry','new_token_uid'],'u60','regrant_must_have_new_UID'),
            (['unused_token_expiry','old_token_uid'],'u50','unused_token_cannot_be_previously_used_token'),
            (['unused_token_expiry','round'],3,'expiry_requires_third_combat_round4_recruit'),
            (['unused_token_expiry','new_token_uid'],'u35','nonmonotone_regrant_UID_refused'),
        ]
        for keys,value,label in mutations:
            wrong=deepcopy(row);target=wrong
            for key in keys[:-1]:target=target[key]
            target[keys[-1]]=value
            passed.append(rejected(lambda:check_full(wrong),label))
        for key,value,label in [
            ('native_factory_preview',False,'native_preview_required'),
            ('actual_token_issuance',True,'preview_cannot_claim_actual_issuance'),
            ('uid_allocated',True,'preview_cannot_claim_allocated_UID'),
            ('zone_inserted',True,'preview_cannot_claim_zone_insertion'),
            ('shape_error','darkcrest_mini_full_native_child_shape_required','failed_native_shape_cannot_pass')]:
            wrong=deepcopy(row);wrong['native_preview_diagnostic'][key]=value
            passed.append(rejected(lambda:check_full(wrong),label))
        for field in ['key_types','base_key_types']:
            wrong=deepcopy(row);wrong['native_preview_diagnostic'][field].pop()
            passed.append(rejected(lambda:check_full(wrong),'missing_complete_native_type_entry_'+field))
            wrong=deepcopy(row);wrong['native_preview_diagnostic'][field][1]=deepcopy(wrong['native_preview_diagnostic'][field][0])
            passed.append(rejected(lambda:check_full(wrong),'duplicate_native_type_entry_'+field))
            wrong=deepcopy(row);wrong['native_preview_diagnostic'][field][0]['key_type']=True
            passed.append(rejected(lambda:check_full(wrong),'boolean_not_variant_type_enum_'+field))
        for key in ['max_health','expires_at_end_turn','base_unit']:
            wrong=deepcopy(row)
            next(x for x in wrong['native_preview_diagnostic']['key_types'] if x['key']==key)['key_type']=4
            passed.append(rejected(lambda:check_full(wrong),'wrong_String_instead_of_StringName_'+key))
        wrong=deepcopy(row)
        next(x for x in wrong['native_preview_diagnostic']['base_key_types'] if x['key']=='max_health')['key_type']=21
        passed.append(rejected(lambda:check_full(wrong),'base_literal_max_health_remains_String'))
        mismatch=log.replace('"native_factory_preview": true','"native_factory_preview": false',1)
        passed.append(rejected(lambda:check_full(row,mismatch),'diagnostic_log_and_JSON_must_match'))
        duplicated='MINI_NATIVE_PREVIEW_KEY_TYPES '+json.dumps(row['native_preview_diagnostic'])+'\n'+log
        passed.append(rejected(lambda:check_full(row,duplicated),'duplicate_native_preview_diagnostic_log_refused'))
        for field in row:
            wrong=deepcopy(row);wrong.pop(field)
            passed.append(rejected(lambda:check_full(wrong),'missing_top_field_'+field))
        wrong=deepcopy(row);wrong['combats'].pop()
        passed.append(rejected(lambda:check_full(wrong),'old_two_combat_draft_refused'))
        wrong=deepcopy(row);wrong['casts'].append(deepcopy(wrong['casts'][0]))
        passed.append(rejected(lambda:check_full(wrong),'third_cast_refused'))
        for text,label in [
            (log.replace('combats=3','combats=2'),'old_two_combat_marker_refused'),
            (log+'DARKCREST_LAVA_PERMANENT_REAL_MATRIX_PASS cases=1 casts=2 combats=3 checks='+str(n)+'\n','duplicate_full_summary_refused'),
            (log+'PASS extra\n','PASS_count_extra_refused'),
            (log.replace('PASS unused_original_token_native_expiry_observed_not_cast','PASS replaced_critical_marker'),'missing_critical_expiry_marker_refused'),
            (log.replace('PASS public_darkcrest_play_u30','PASS public_darkcrest_play_u31'),'wrong_actual_source_play_UID_refused'),
            (log+'SCRIPT ERROR: synthetic\n','script_error_with_PASS_refused')]:
            passed.append(rejected(lambda:check_full(row,text),label))
        pure_lines=['PASS '+name for name,count in r.PERMANENT_PURE_MARKERS.items() for _ in range(count)]
        pure_lines+=['PASS synthetic_additional_detached_shape_check']*(344-len(pure_lines))
        pure={'passed':344,'failed':0,'failures':[],'real_game_run':False,
              'scope':r.PERMANENT_PURE_SCOPE,'actual_provenance_proven':False}
        def pure_log(value):return '\n'.join(pure_lines)+'\nDARKCREST_LAVA_PERMANENT_CONTENT_CONTRACT '+json.dumps(value)+'\n'
        assert r.validate('lava_permanent_content_contract',pure_log(pure),344,root)==(344,None)
        passed.append('synthetic_pure_344_schema_positive_NOT_RUNTIME_PROOF')
        for field,value,label in [('passed',343,'wrong_actual_pure_count_refused'),('failed',True,'boolean_pure_failure_count_refused'),
                                 ('failures',['x'],'pure_failures_refused'),('real_game_run',True,'pure_cannot_claim_Game'),
                                 ('actual_provenance_proven',True,'pure_cannot_claim_provenance'),('scope','actual play','wrong_pure_scope_refused')]:
            wrong=dict(pure);wrong[field]=value
            passed.append(rejected(lambda:r.validate('lava_permanent_content_contract',pure_log(wrong),344,root),label))
        altered=pure_log(pure).replace('PASS fake_empty_flush_close_cannot_self_sign_ready','PASS replaced_critical_guard')
        passed.append(rejected(lambda:r.validate('lava_permanent_content_contract',altered,344,root),'missing_flush_authority_refusal_marker_refused'))
        original=r.NEW_TEST_METADATA['pure_checks'];r.NEW_TEST_METADATA['pure_checks']=None
        try:passed.append(rejected(lambda:r.validate('lava_permanent_content_contract',pure_log(pure),344,root),'UNKNOWN_pure_count_never_defaults_to_pass'))
        finally:r.NEW_TEST_METADATA['pure_checks']=original
    r.NEW_TEST_METADATA['pure_checks']=original_actual_count
    print(json.dumps({'status':'PASS_SYNTHETIC_EXACT_SCHEMA_VALIDATION_NOT_GAMEPLAY','checks':len(passed),'labels':passed,
                      'game_started':False,'godot_started':False,'source_tree_copied':False,'production_edited':False,
                      'full_positive_is_fabricated_detached_JSON_only':True,'new_actual_Game_count_not_assumed':True,'actual_pure_count_not_inferred_from_synthetic':True},sort_keys=True))


if __name__=='__main__':main()
