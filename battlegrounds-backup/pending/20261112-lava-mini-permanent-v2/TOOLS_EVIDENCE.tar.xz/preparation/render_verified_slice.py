"""Pure Chinese evidence renderer. No reads, writes, Game or upload at import."""
import json
import run_remote_lava_permanent as runner


def render_slice(summary,audit,final,scenario,commit):
 from packaging_common import outcome_metadata
 outcome=outcome_metadata(summary,audit,final)
 assert all(x.get('source_commit')==commit for x in [summary,audit]+([final] if final else []))
 if outcome=='failure':
  assert scenario is None
  classes={key:value['classification'] for key,value in audit['tests'].items()}
  executed=[key for key,value in audit['tests'].items() if value.get('process_started') is True]
  omitted=[key for key,value in audit['tests'].items() if value['classification']=='omitted']
  not_started=[key for key,value in audit['tests'].items() if value['classification'] in ['omitted','preflight_only_not_started','launch_failed_not_executed']]
  uncertain=[key for key,value in audit['tests'].items() if value['classification']=='launch_or_execution_without_completion_receipt']
  validated={key:value['revalidated_checks'] for key,value in audit['tests'].items() if value['classification']=='executed_validated'}
  assert all(type(n) is int and n>0 for n in validated.values())
  first=runner.TESTS[0][0]
  prefix='本轮首次完整 Game 失败，后续 9 份纯合同均未运行，不能计为通过。\n\n' if classes[first]=='process_failed' and len(omitted)==9 else ''
  detail='\n'.join('- '+key+'：'+value for key,value in classes.items())
  return f'''# 本修复批测试未获验收

源码：{commit}。本次实际尝试失败或未完成，不把未运行、结果不明或证据不足项目计为通过。

{prefix}已确认启动 {len(executed)} 项；明确未启动 {len(not_started)} 项；其中完全未运行 {len(omitted)} 项；启动或完成状态待确认 {len(uncertain)} 项。已由审计验证的检查数仅为 {validated}。

预冻结纯合同 344 项仅属此前局部检查，不自动算作本轮通过。原生 preview 只是同 Game/Catalog 的脱离区域工厂形状诊断，不是实际发牌或永久效果验收。

错误记录：{summary.get('error')}

逐测试分类：
{detail}

原日志与每次源哈希结果保留；来源是否完整须看原始 audit/trees，不因打包而升级为通过。失败源码与此前 517a547eebad779a65189fa67b845f82d5ec6886 / 9d6ad450f4c5ad287b49612c9c2ba3de399cc67b 证据均不改写。修复需另建候选。此页不表示玩法成功、默认启用或全量验收。
'''
 assert isinstance(scenario,dict)
 full=final['tests']['lava_permanent_real_matrix'];assert full['verified_scenario_fields']==scenario
 checks=full['passed_checks'];assert type(checks) is int and checks>0
 pure={key:value['passed_checks'] for key,value in final['tests'].items() if key!='lava_permanent_real_matrix'}
 expected={label:count for label,_,_,count in runner.TESTS[1:]}
 assert pure==expected and all(type(n) is int for n in pure.values()) and sum(pure.values())==3061
 assert len(scenario['casts'])==2 and len(scenario['combats'])==3 and scenario['darkcrest_final_tier']==4
 assert [(x['attack_before'],x['attack_after'],x['health'],x['kept']) for x in scenario['casts']]==[(2,4,5,1),(4,6,5,1)]
 assert [(x['recruit_attack'],x['recruit_health'],x['recruit_kept']) for x in scenario['combats']]==[(4,5,0),(6,5,0),(6,5,0)]
 expiry=scenario['unused_token_expiry'];assert expiry['old_token_uid']!=expiry['new_token_uid'] and expiry['cast_count_before']==expiry['cast_count_after'] and expiry['attack']==6 and expiry['kept']==0
 assert scenario['coin_pre_source_fixture'] is True and scenario['entirely_natural_game'] is False and scenario['same_turn_second_cast_tested'] is False
 diagnostic=scenario['native_preview_diagnostic'];runner.validate_native_preview(diagnostic,'MINI_NATIVE_PREVIEW_KEY_TYPES '+json.dumps(diagnostic)+'\n')
 assert audit['status']=='PASS_POST_ATTEMPT_SOURCE_AND_EVIDENCE_AUDIT'
 return f'''# 已验证的有限玩法：暗潮与迷你、熔岩兼容修复

源码：{commit}。

同一原始 Game/Catalog 的工厂 preview 已核对完整键类型，max_health 与 expires_at_end_turn 的原生 StringName 键与修复后的形状一致。preview 不分配 UID、不入手、不构成真实令牌发放证明。实际验收仍来自其后的原始 Mini 上场、Waiting 发牌、两次施法与三次非空战斗。

暗潮在场，单个普通迷你原生发出三叉戟，连续两轮分别对同一个普通熔岩潜伏者施放本轮第一张法术。实际身材 2/5 → 4/5 → 6/5。下轮招募 kept 重置为 0，永久攻击保留。第三轮特意不使用三叉戟，旧 UID 到期且不增加施法计数，随后真实发出不同 UID 的新票；熔岩仍为 6/5、kept 0，暗潮独立成长至 4 级。

原熔岩永久效果算法早已存在，本批是有限 Darkcrest 兼容与原生键类型修复，不是新写永久算法。

实际测试：Game {checks} 项，新纯合同 344 项，加上 8 份既有纯合同 2717 项，共 {checks+3061} 项。仅运行一个新远端完整恢复树；候选与恢复树在测试后分别完整核验。这不是两个 runtime，也不是重复运行旧 Game 矩阵。

使用公开披露的暗潮激活前 Coin 夹具，不称为无夹具自然对局。第二个 Mini、同轮第二次施法、其他目标、buff 后出售/重买、金色与多 Lava 等仍未开放或未验证；不代表默认启用、完整卡池或全游戏验收。

旧失败 source 517a547eebad779a65189fa67b845f82d5ec6886 与失败证据 9d6ad450f4c5ad287b49612c9c2ba3de399cc67b 保留不动。本页不能替代原始日志、源 SHA 与最终远端发布回读核验。
'''
