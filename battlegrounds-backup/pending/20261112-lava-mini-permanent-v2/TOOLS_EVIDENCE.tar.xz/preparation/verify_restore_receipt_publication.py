"""Fresh-download bytes-only restore publication at an explicit fixed commit. Never Game or upload."""
import subprocess,concurrent.futures
from packaging_common import *

def main():
 ap=parser(__doc__);ap.add_argument('--publication',type=Path,default=ROOT/'RESTORE_RECEIPT_PUBLICATION.json');a=ap.parse_args()
 r,source,folder,m,expected,d=context(a)
 pub=read(a.publication);local=read(ROOT/'RESTORE_RECEIPT_UPLOAD_METADATA.json');files=local['records']
 assert re.fullmatch('[0-9a-f]{40}',pub['commit']) and pub['commit']!=source
 assert pub['source_commit']==local['source_commit']==source and pub.get('remote_folder',pub.get('folder'))==folder
 assert len(files)==len({row['name'] for row in files})>0
 out=ROOT/('restore_receipt_remote_'+pub['commit']);out.mkdir(exist_ok=False)
 def fetch(row):
  n=row['name'];assert safe(n) and '/' not in n and re.fullmatch('[0-9a-f]{64}',row['sha256']) and re.fullmatch('[0-9a-f]{40}',row['git_sha'])
  url=f"https://raw.githubusercontent.com/Ethsigema/AI_text01/{pub['commit']}/{folder}/{n}"
  p=out/n;part=Path(str(p)+'.partial')
  subprocess.run(['curl','-fsSL','--retry','3','--connect-timeout','30','--max-time','300',url,'-o',str(part)],check=True)
  b=part.read_bytes();assert len(b)==row['bytes'] and sha(b)==row['sha256'] and hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==row['git_sha'];part.rename(p)
  return {**row,'url':url}
 with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:records=list(pool.map(fetch,files))
 checked=set()
 for line in (out/'SHA256SUMS.txt').read_text().splitlines():
  h,n=line.split('  ',1);assert safe(n) and '/' not in n and n not in checked and n!='SHA256SUMS.txt';assert sha((out/n).read_bytes())==h;checked.add(n)
 assert checked=={row['name'] for row in files}-{'SHA256SUMS.txt'}
 immutable={}
 for row in d['records']:
  n=row['filename']
  if n=='SHA256SUMS.txt':continue
  b=(out/n).read_bytes();assert b==(r/'package'/n).read_bytes() and sha(b)==row['sha256'];immutable[n]=sha(b)
 archives={}
 for f in out.glob('*.tar.xz'):
  meta={'archive_sha256':m['archive_sha256'],'members':m['changed_files']} if f.name==m.get('archive') else read(out/(f.name.removesuffix('.tar.xz')+'_MANIFEST.json'))
  archives[f.name]=verify_archive(f.read_bytes(),meta)
 assert 'FIX_EVIDENCE.tar.xz' in archives and 'TOOLS_EVIDENCE.tar.xz' in archives and 'GAMEPLAY_EVIDENCE.tar.xz' not in archives
 validate_restore_shape(read(out/'REMOTE_SNAPSHOT_RESTORE_VERIFIED.json'),r,m,source)
 report={'status':'PASS_EARLY_RESTORE_RECEIPT_PUBLICATION_BYTES_ONLY_NOT_GAME','verified_at_utc':runner.utc(),
         'commit':pub['commit'],'source_commit':source,'remote_folder':folder,'files':len(records),
         'bytes':sum(row['bytes'] for row in records),'records':records,'sha256sums_entries':len(checked),
         'evidence_members_rehashed':archives,'source_all_non_sums_files_unchanged':immutable,
         'new_full_tree_restore_repeated':False,'live_game_logs_accessed':False,'gameplay_acceptance':False,'game_started':False,'uploads':0}
 put(ROOT/'EARLY_PUBLICATION_VERIFIED.json',enc(report))
if __name__=='__main__':main()
