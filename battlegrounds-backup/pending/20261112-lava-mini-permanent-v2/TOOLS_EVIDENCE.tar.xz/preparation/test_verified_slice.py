"""Synthetic renderer checks, not gameplay. No actual logs or package creation."""
import copy,json
from render_verified_slice import render_slice,runner
from test_permanent_schema_synthetic import full_fixture
labels=[x[0] for x in runner.TESTS];commit='a'*40
scenario,_,_=full_fixture()
s={'source_commit':commit,'runtime_mode':runner.RUNTIME_MODE,'two_runtime_copies':False,'status':'TESTS_VALIDATED_SOURCE_INTEGRITY_PASS','error':None,'validated_tests':labels}
a={'source_commit':commit,'runtime_mode':runner.RUNTIME_MODE,'two_runtime_copies':False,'runner_suite_accepted':True,'status':'PASS_POST_ATTEMPT_SOURCE_AND_EVIDENCE_AUDIT','tests':{key:{'classification':'executed_validated','process_started':True,'revalidated_checks':count if count else 123} for key,_,_,count in runner.TESTS}}
f={'source_commit':commit,'status':runner.FINAL_STATUS,'tests':{t[0]:{'passed_checks':t[3]} for t in runner.TESTS},'full_game_processes':1,'full_game_acceptance':False,'default_pool_promoted':False,'native_preview_is_actual_issuance':False}
f['tests'][labels[0]]={'passed_checks':123,'verified_scenario_fields':scenario}
assert '3184' in render_slice(s,a,f,scenario,commit)
checks=['synthetic_success_dynamic_full_plus_pure3061']
for name,mut in [('missing_test',lambda x:x[2]['tests'].pop(labels[-1])),('wrong_commit',lambda x:x[0].update(source_commit='b'*40)),('unvalidated',lambda x:x[1]['tests'][labels[0]].update(classification='omitted')),('wrong_cast_count',lambda x:x[3]['casts'].pop()),('wrong_pure_count',lambda x:x[2]['tests'][labels[-1]].update(passed_checks=1)),('claimed_natural',lambda x:x[3].update(entirely_natural_game=True)),('preview_claims_issuance',lambda x:x[3]['native_preview_diagnostic'].update(actual_token_issuance=True))]:
 x=copy.deepcopy([s,a,f,scenario]);mut(x)
 try:render_slice(*x,commit)
 except (AssertionError,ValueError):checks.append(name)
 else:raise AssertionError('accepted '+name)
fs={**s,'status':'FAILED_OR_INCOMPLETE_ATTEMPT','error':'synthetic failure','validated_tests':[]}
fa={**a,'runner_suite_accepted':False,'status':'FAIL_POST_ATTEMPT_AUDIT','tests':{key:{'classification':'omitted','process_started':False} for key in labels}}
fa['tests'][labels[0]]={'classification':'process_failed','process_started':True}
text=render_slice(fs,fa,None,None,commit)
assert '后续 9 份纯合同均未运行' in text and '明确未启动 9 项' in text
checks.append('first_full_failure_exact_nine_omitted_not_passed')
partial=copy.deepcopy(fa);partial['tests'][labels[0]]={'classification':'executed_validated','process_started':True,'revalidated_checks':123};partial['tests'][labels[1]]={'classification':'process_failed','process_started':True}
text=render_slice(fs,partial,None,None,commit)
assert '后续 9 份纯合同均未运行' not in text and '明确未启动 8 项' in text and '123' in text
checks.append('later_pure_failure_does_not_misstate_nine_omitted')
uncertain=copy.deepcopy(fa);uncertain['tests'][labels[0]]={'classification':'launch_or_execution_without_completion_receipt','process_started':None}
text=render_slice(fs,uncertain,None,None,commit);assert '待确认 1 项' in text and '已确认启动 0 项' in text
checks.append('uncertain_start_not_claimed_executed_or_passed')
try:render_slice({**fs,'status':'NOT_RUN'},fa,None,None,commit)
except AssertionError:checks.append('no_attempt_rejected')
else:raise AssertionError('accepted unrun')
print(json.dumps({'status':'PASS_SYNTHETIC_RENDERER_ONLY','passed':len(checks),'checks':checks,'read_live_logs':False,'game_started':False,'package_created':False},indent=2))
