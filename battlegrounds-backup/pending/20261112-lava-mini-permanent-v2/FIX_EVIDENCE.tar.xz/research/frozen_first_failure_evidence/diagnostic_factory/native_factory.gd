extends "res://tests/darkcrest_lava_permanent_20261112/content_contract.gd"
func differences(a: Variant,b: Variant,path: String="") -> Array:
 var out: Array=[]
 if typeof(a)!=typeof(b):
  out.append({"path":path,"actual_type":type_string(typeof(a)),"expected_type":type_string(typeof(b)),"actual":a,"expected":b});return out
 if a is Dictionary:
  for k in a:
   if not b.has(k):out.append({"path":path+"/"+str(k),"extra_actual":a[k]})
  for k in b:
   if not a.has(k):out.append({"path":path+"/"+str(k),"missing_expected":b[k]})
   else:out.append_array(differences(a[k],b[k],path+"/"+str(k)))
 elif a is Array:
  if a.size()!=b.size():out.append({"path":path,"actual_length":a.size(),"expected_length":b.size()})
  else:
   for i in range(a.size()):out.append_array(differences(a[i],b[i],path+"/"+str(i)))
 elif a!=b:out.append({"path":path,"actual":a,"expected":b})
 return out
func _initialize() -> void:
 var engine=load("res://core/game.gd").new()
 print("DIAGNOSTIC Game.new complete; no start or commands")
 var cat=load("res://core/catalog.gd").new();cat.load_catalog()
 engine.catalog=cat
 engine.state.round=1
 print("DIAGNOSTIC actual Catalog loaded; round1 only fixture")
 var card: Dictionary=cat.get_card("BG23_000t")
 var unit: Dictionary=engine._unit(card)
 var factory: Dictionary=unit.duplicate(true)
 unit.is_spellcraft=true;unit.expires_at_end_turn=true
 var expected: Dictionary=child_fixture();expected.uid=unit.get("uid","")
 var result={"status":"FACTORY_DIAGNOSTIC_NOT_WAITING_AUTHORITY","no_start":true,"round_fixture":1,"source":card,"factory":factory,"waiting_flags_only":unit,"expected_from_existing_pure_fixture":expected,"differences":differences(unit,expected),"actual_shape_error":MiniHost.token_shape_error(engine._darkcrest_host,engine,unit)}
 var file=FileAccess.open(get_script().resource_path.get_base_dir()+"/FACTORY_DIAGNOSTIC.json",FileAccess.WRITE)
 if file==null:quit(2);return
 file.store_string(JSON.stringify(result,"  "));file.close()
 print("DIAGNOSTIC_DIFF ",JSON.stringify(result.differences))
 print("DIAGNOSTIC_SHAPE ",result.actual_shape_error)
 quit(0)
