# Factory-only diagnostic, not gameplay or Waiting authority

Fixed source: remote_snapshot_517a547/single_tree_restore/restored_snapshot, commit517a547eebad779a65189fa67b845f82d5ec6886.

One explicitly authorized run holds the shared independent-full-game lock; verifies no existing godot process; writes complete per-file source hashes before and after; external HOME/XDG; 360s timeout and4GiB RSS soft limit. Calls Game.new and real Catalog.load_catalog, sets only diagnostic state.round=1, invokes native _unit for actual BG23_000t. It does not start a room, issue commands, queue or deliver a token, modify a hand, or establish any private grant ledger. Adds the two ordinary Waiting flags to the diagnostic body only for shape comparison.

Expected fixture is read from the existing pure test, whose manual schema matches the validator; this is intentionally not independent proof of factory behavior. `FACTORY_DIAGNOSTIC.json` records native values and the production shape validator result. The original recursive diff reports value types but does not report dictionary KEY types; JSON serialization loses String/StringName key distinction. This limitation was identified after the process compiled and started Catalog loading. Do not interpret an empty diff as strict-key-type equality. No second run is implied or authorized by this file.
