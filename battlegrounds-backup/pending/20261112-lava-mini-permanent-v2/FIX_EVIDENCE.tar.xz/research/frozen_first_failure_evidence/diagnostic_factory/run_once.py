from pathlib import Path
import subprocess,os,fcntl,time,hashlib,json,signal
root=Path.cwd(); d=root/'develop_lava_permanent_20261112/diagnostic_factory'; src=root/'develop_lava_permanent_20261112/remote_snapshot_517a547/single_tree_restore/restored_snapshot'
def hashes():
 return {str(p.relative_to(src)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(src.rglob('*')) if p.is_file()}
def write(n,v): (d/n).write_text(json.dumps(v,indent=2,sort_keys=True))
with (root/'develop_empty_ghost_20261112/.independent_full_game.lock').open('a') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 live=subprocess.run(['pgrep','-x','godot'],capture_output=True,text=True)
 assert live.returncode==1,live.stdout
 before=hashes();write('SOURCE_BEFORE.json',before)
 env=os.environ.copy()
 for key in ['HOME','XDG_CONFIG_HOME','XDG_DATA_HOME','XDG_CACHE_HOME']:
  path=d/key;path.mkdir(exist_ok=True);env[key]=str(path)
 log=(d/'native_factory.log').open('wb'); start=time.monotonic(); maximum=0;reason='exited'
 p=subprocess.Popen(['godot','--headless','--path',str(src),'--script',str(d/'native_factory.gd')],stdout=log,stderr=subprocess.STDOUT,env=env,start_new_session=True)
 print('ACTUAL_DIAGNOSTIC_PID',p.pid,flush=True)
 while p.poll() is None:
  try:rss=int(Path('/proc',str(p.pid),'statm').read_text().split()[1])*os.sysconf('SC_PAGE_SIZE')
  except (OSError,ValueError,IndexError):rss=0
  maximum=max(maximum,rss)
  if time.monotonic()-start>360 or rss>4*1024**3:
   reason='timeout360' if time.monotonic()-start>360 else 'RSS4GiBsoftlimit';os.killpg(p.pid,signal.SIGTERM)
   try:p.wait(timeout=3)
   except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
   break
  time.sleep(.5)
 log.close();after=hashes();write('SOURCE_AFTER.json',after)
 result={'exit':p.returncode,'reason':reason,'seconds':time.monotonic()-start,'maximum_rss':maximum,'files':len(before),'source_unchanged':before==after,'diagnostic_not_gameplay':True}
 write('RUN_RESULT.json',result);print(json.dumps(result),flush=True)
 assert before==after
