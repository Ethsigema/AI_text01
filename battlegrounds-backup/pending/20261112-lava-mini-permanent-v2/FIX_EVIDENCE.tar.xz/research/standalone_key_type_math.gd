extends SceneTree
func _initialize():
 var native: Dictionary={"health":1}
 native.max_health=native.health
 native.expires_at_end_turn=true
 var literal: Dictionary={"health":1,"max_health":1,"expires_at_end_turn":true}
 for k in native:
  print("native ",k," typeof=",typeof(k))
 for k in literal:
  print("literal ",k," typeof=",typeof(k))
 quit()
