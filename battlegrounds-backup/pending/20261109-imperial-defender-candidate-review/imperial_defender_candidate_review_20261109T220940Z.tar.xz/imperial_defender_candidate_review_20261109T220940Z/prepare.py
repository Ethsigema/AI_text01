from pathlib import Path
import ast, difflib, hashlib, json, resource

resource.setrlimit(resource.RLIMIT_AS,(128*1024*1024,128*1024*1024))
H=Path(__file__).resolve().parent
R=H.parent/'historical_tools_batch14_20261109T191857Z/runtime'
BASE=json.loads((R.parent/'SOURCE_MAP.json').read_text())
historical='research/imperial_defender_native_recovery/candidates/tools/imperial_defender_patterns.py'
inputs=[historical,'research/imperial_defender_native_recovery/integration_manifest.json',
 'research/imperial_defender_native_recovery/shared_manifest.json',
 'research/imperial_defender_native_recovery/shared_changes.patch',
 'research/imperial_defender_native_recovery/raw_rows.json',
 'research/imperial_defender_native_recovery/programs.json',
 'research/imperial_defender_native_recovery/expected_compiled.json',
 'research/imperial_defender_native_recovery/native_quantities.json',
 'research/imperial_defender_native_recovery/native/BG22_HERO_007_Buddy.xml',
 'research/imperial_defender_native_recovery/native/BG22_HERO_007_Buddy_G.xml',
 'core/imperial_defender_sources.gd','core/phase_undead_army_sources.gd','core/pool_identity.gd']
pins={}
for rel in inputs:
 p=R/rel;b=p.read_bytes();pin=hashlib.sha256(b).hexdigest()
 assert pin==BASE[rel]['sha256'] and len(b)==BASE[rel]['bytes']
 d=H/'original_inputs'/rel;d.parent.mkdir(parents=True,exist_ok=True)
 if d.exists():assert d.read_bytes()==b
 else:d.write_bytes(b)
 assert d.stat().st_ino!=p.stat().st_ino
 pins[rel]={'bytes':len(b),'sha256':pin}
 if rel.startswith('core/'):
  d=H/'gd_minimal'/rel;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(b)
s=(R/historical).read_text();assert hashlib.sha256(s.encode()).hexdigest()=='397ce11d0ed60fb99bf6388941067ec71080fdbdd46344c216a2b4abf67cbb56'
old='''def compile_card(card, cards):
    if not isinstance(card, dict) or card.get("id") not in SOURCE_IDS:
        return None
    if card != RAW[card["id"]] or any(cards.get(identity) != RAW[identity] for identity in SOURCE_IDS):
        return None
    return deepcopy(EXPECTED[card["id"]])
'''
new='''def same(a, b):
    """Type-aware equality for this family's fixed, finite RAW rows."""
    if type(a) in (int, float) and type(b) in (int, float):
        return a == b
    if type(a) is not type(b):
        return False
    if isinstance(a, dict):
        return a.keys() == b.keys() and all(same(a[key], b[key]) for key in a)
    if isinstance(a, list):
        return len(a) == len(b) and all(same(x, y) for x, y in zip(a, b))
    return a == b


def compile_card(card, cards):
    if not isinstance(card, dict) or card.get("id") not in SOURCE_IDS or not isinstance(cards, dict):
        return None
    if not same(card, RAW[card["id"]]) or any(not same(cards.get(identity), RAW[identity]) for identity in SOURCE_IDS):
        return None
    return deepcopy(EXPECTED[card["id"]])
'''
assert s.count(old)==1;candidate=s.replace(old,new)
d=H/'candidate/tools/imperial_defender_patterns.py';d.parent.mkdir(parents=True,exist_ok=True);d.write_text(candidate)
patch=''.join(difflib.unified_diff(s.splitlines(keepends=True),candidate.splitlines(keepends=True),fromfile='a/tools/imperial_defender_patterns.py',tofile='b/tools/imperial_defender_patterns.py'))
(H/'candidate/strict_equality_correction.patch').write_text(patch)
def literals(text):
 t=ast.parse(text);v={}
 for n in t.body:
  if isinstance(n,ast.Expr) and isinstance(n.value,ast.Constant) and isinstance(n.value.value,str):continue
  assert isinstance(n,(ast.Assign,ast.ImportFrom,ast.FunctionDef)),type(n).__name__
  if isinstance(n,ast.ImportFrom):assert n.module=='copy' and [x.name for x in n.names]==['deepcopy']
  if isinstance(n,ast.Assign):
   assert len(n.targets)==1 and isinstance(n.targets[0],ast.Name)
   v[n.targets[0].id]=ast.literal_eval(n.value)
 return v
a=literals(s);b=literals(candidate);assert a==b and set(a)=={'SOURCE_IDS','RAW','EXPECTED'}
ids=list(a['SOURCE_IDS']);cases=[]
def add(which,identity,path,op,**extra):
 label=f'{len(cases):04d}:{which}:{identity}:{op}:'+'.'.join(map(str,path))
 cases.append({'label':label,'target':which,'identity':identity,'path':path,'op':op,**extra})
def walk(value,path):
 yield path,value
 if isinstance(value,dict):
  for k,v in value.items():yield from walk(v,path+[k])
 elif isinstance(value,list):
  for i,v in enumerate(value):yield from walk(v,path+[i])
for identity in ids:
 add('card',identity,[],'canonical')
 add('card',identity,[],'id_only')
 add('card',identity,[],'invalid_root',value=None)
 add('card',identity,[],'invalid_root',value=[])
 add('card',identity,[],'invalid_root',value='invalid')
 add('cards',identity,[],'invalid_root',value=None)
 add('cards',identity,[],'invalid_root',value=[])
 add('cards',identity,[],'extra_unrelated')
 for which in ('card','mapping'):
  for path,value in walk(a['RAW'][identity],[]):
   if path:add(which,identity,path,'delete')
   if isinstance(value,bool):
    add(which,identity,path,'bool_to_int')
    add(which,identity,path,'bool_to_float')
    add(which,identity,path,'toggle_bool')
   elif isinstance(value,(int,float)):
    add(which,identity,path,'numeric_float')
    add(which,identity,path,'numeric_int')
    add(which,identity,path,'number_delta')
    add(which,identity,path,'number_string')
    if value in (0,1):add(which,identity,path,'number_bool')
    # Non-finite values are generated in each runner, never serialized as JSON.
    if path==['tier']:
     add(which,identity,path,'nan');add(which,identity,path,'pos_inf');add(which,identity,path,'neg_inf')
   elif isinstance(value,str):add(which,identity,path,'change_string')
   elif value is None:add(which,identity,path,'null_to_false')
   elif isinstance(value,dict):add(which,identity,path,'extra_key')
   elif isinstance(value,list):
    add(which,identity,path,'append_item')
    if len(value)>1:add(which,identity,path,'reverse_list')
 # Explicit absent/malformed companion card must fail even when the supplied card is pristine.
 for dep in ids:
  add('cards',identity,[dep],'delete')
  add('cards',identity,[dep],'invalid_member')
cases.append({'label':'mapping-keys-unrelated-string','target':'cards','identity':ids[0],'path':[],'op':'extra_unrelated'})
(H/'CASES.json').write_text(json.dumps(cases,ensure_ascii=False,indent=2)+'\n')
(H/'INPUT_PINS.json').write_text(json.dumps(pins,indent=2)+'\n')
(H/'gd_minimal/project.godot').write_text('[application]\nconfig/name="Imperial equality isolated review"\n[rendering]\nrenderer/rendering_method="gl_compatibility"\n')
result={'historical_tool_sha256':hashlib.sha256(s.encode()).hexdigest(),
 'candidate_sha256':hashlib.sha256(candidate.encode()).hexdigest(),'candidate_bytes':len(candidate.encode()),
 'patch_sha256':hashlib.sha256(patch.encode()).hexdigest(),'cases':len(cases),
 'literal_constants_unchanged':True,'only_import':'copy.deepcopy',
 'gd_script_count':3,'new_candidate_not_original_restoration':True,
 'not_latest_published_version':True,'not_installed':True,
 'max_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
(H/'PREPARATION.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
