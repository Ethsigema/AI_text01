from pathlib import Path
from copy import deepcopy
import ast, hashlib, json, resource, sys, types

resource.setrlimit(resource.RLIMIT_AS,(128*1024*1024,128*1024*1024));sys.dont_write_bytecode=True
H=Path(__file__).resolve().parent
def load(path):
 s=path.read_text();t=ast.parse(s)
 for n in t.body:
  if isinstance(n,ast.Expr):assert isinstance(n.value,ast.Constant) and isinstance(n.value.value,str)
  elif isinstance(n,ast.Assign):ast.literal_eval(n.value)
  elif isinstance(n,ast.ImportFrom):assert n.module=='copy' and [x.name for x in n.names]==['deepcopy']
  else:assert isinstance(n,ast.FunctionDef)
 m=types.ModuleType(path.stem);exec(compile(t,str(path),'exec'),m.__dict__);return m
old=load(H/'original_inputs/research/imperial_defender_native_recovery/candidates/tools/imperial_defender_patterns.py')
new=load(H/'candidate/tools/imperial_defender_patterns.py')
def frozen(x):return json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':'))
assert frozen(old.RAW)==frozen(new.RAW) and frozen(old.EXPECTED)==frozen(new.EXPECTED)
def mutate(value,case):
 op=case['op'];path=case['path']
 if op=='canonical':return value
 if op=='invalid_root':return deepcopy(case['value'])
 if op=='id_only':return {'id':value['id']}
 if op=='extra_unrelated':value['not-a-source']={'id':'not-a-source'};return value
 if op=='invalid_member':value[path[0]]=None;return value
 parent=value
 for part in path[:-1]:parent=parent[part]
 old_value=parent[path[-1]] if path else value
 if op=='delete':del parent[path[-1]];return value
 if op=='bool_to_int':updated=int(old_value)
 elif op=='bool_to_float':updated=float(old_value)
 elif op=='toggle_bool':updated=not old_value
 elif op=='numeric_float':updated=float(old_value)
 elif op=='numeric_int':updated=int(old_value)
 elif op=='number_delta':updated=old_value+1
 elif op=='number_string':updated=str(old_value)
 elif op=='number_bool':updated=bool(old_value)
 elif op=='change_string':updated=old_value+'__changed__'
 elif op=='null_to_false':updated=False
 elif op=='extra_key':updated=deepcopy(old_value);updated['__extra__']=True
 elif op=='append_item':updated=deepcopy(old_value);updated.append('__extra__')
 elif op=='reverse_list':updated=list(reversed(old_value))
 elif op=='nan':updated=float('nan')
 elif op=='pos_inf':updated=float('inf')
 elif op=='neg_inf':updated=float('-inf')
 else:raise AssertionError(op)
 if path:parent[path[-1]]=updated
 else:value=updated
 return value
results=[];cases=json.loads((H/'CASES.json').read_text());failures=[]
for case in cases:
 identity=case.get('supplied_identity',case['identity']);card=deepcopy(new.RAW[identity]);cards=deepcopy(new.RAW)
 if case['target']=='card':card=mutate(card,case)
 elif case['target']=='mapping':cards[case['identity']]=mutate(cards[case['identity']],case)
 else:cards=mutate(cards,case)
 before=frozen([card,cards]);outputs={};errors={}
 for label,module in [('old',old),('new',new)]:
  try:outputs[label]=module.compile_card(card,cards)
  except Exception as e:outputs[label]=None;errors[label]=type(e).__name__
  assert before==frozen([card,cards]),(case['label'],label,'mutated_input')
 output=outputs['new'];accepted=output is not None
 if accepted:assert frozen(output)==frozen(new.EXPECTED[identity]),case['label']
 assert 'new' not in errors,(case['label'],errors)
 results.append({'label':case['label'],'new_accept':accepted,'old_accept':outputs['old'] is not None,
                 'old_error':errors.get('old'),'inputs_unchanged':True,'output_exact':True if accepted else None})
 # Static reasoning predicts these alias changes are the defect, now checked on both entry surfaces.
 if case['op'] in ('bool_to_int','bool_to_float','number_bool'):
  assert not accepted and outputs['old'] is not None,(case,errors)
for identity in new.SOURCE_IDS:
 card=deepcopy(new.RAW[identity]);cards=deepcopy(new.RAW);before=frozen([card,cards,new.RAW,new.EXPECTED])
 a=new.compile_card(card,cards);b=new.compile_card(card,cards)
 assert a is not b and a['effects'] is not b['effects'] and a['effects'] is not new.EXPECTED[identity]['effects']
 a['effects'][0]['__test__']=True
 assert frozen(b)==frozen(new.EXPECTED[identity])
 assert before==frozen([card,cards,new.RAW,new.EXPECTED])
 assert b['default_pool'] is False and b['pool_supported'] is False
 assert b['implementation_status']=='partial_implementation_supported_pending_unified_validation'
canonical={i:new.compile_card(deepcopy(new.RAW[i]),deepcopy(new.RAW)) for i in new.SOURCE_IDS}
(H/'CANDIDATE_OUTPUTS.json').write_text(json.dumps(canonical,ensure_ascii=False,indent=2)+'\n')
report={'case_count':len(cases),'candidate_accepted':sum(x['new_accept'] for x in results),
 'old_accepted':sum(x['old_accept'] for x in results),'old_exceptions':sum(x['old_error'] is not None for x in results),
 'old_accept_new_reject':sum(x['old_accept'] and not x['new_accept'] for x in results),
 'new_accept_old_reject':sum(x['new_accept'] and not x['old_accept'] for x in results),
 'all_candidate_outputs_exact':True,'all_inputs_unchanged':True,'deepcopy_isolation_passed':True,
 'normal_golden_partial_pool_flags_preserved':True,'results':results,
 'max_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
(H/'PYTHON_REPORT.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k!='results'},indent=2))
