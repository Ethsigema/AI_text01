extends SceneTree
const Source=preload("res://core/imperial_defender_sources.gd")
class MiniCatalog extends RefCounted:
	var cards: Dictionary={}
	func get_card(identity): return cards.get(identity,{})
func _init():
	var normal: String=Source.IDS[0]
	var golden: String=Source.IDS[1]
	var base: Dictionary={}
	for identity in Source.IDS:
		base[identity]=Source.RAW[identity].duplicate(true)
		base[identity].merge(Source.EXPECTED[identity],true)
	var records: Array=[]
	for label in ["canonical","swapped_pair","normal_under_both_keys","golden_under_both_keys"]:
		var raw: Dictionary=Source.RAW.duplicate(true)
		var compiled: Dictionary=base.duplicate(true)
		if label=="swapped_pair":
			raw[normal]=Source.RAW[golden].duplicate(true)
			raw[golden]=Source.RAW[normal].duplicate(true)
			compiled[normal]=base[golden].duplicate(true)
			compiled[golden]=base[normal].duplicate(true)
		elif label=="normal_under_both_keys":
			raw[golden]=Source.RAW[normal].duplicate(true)
			compiled[golden]=base[normal].duplicate(true)
		elif label=="golden_under_both_keys":
			raw[normal]=Source.RAW[golden].duplicate(true)
			compiled[normal]=base[golden].duplicate(true)
		var raw_accepted: bool=true
		var source_accepted: bool=true
		for identity in Source.IDS:
			raw_accepted=raw_accepted and Source.raw_source_error(raw[identity]).is_empty()
			source_accepted=source_accepted and Source.source_error(compiled[identity]).is_empty()
		var cat=MiniCatalog.new();cat.cards=compiled
		records.append({"label":label,"actual_raw_functions_accept_all_rows":raw_accepted,"actual_source_functions_accept_all_rows":source_accepted,"actual_closure_error":Source.closure_error(cat),"full_catalog_identity_guard_examined":false})
	var path: String=OS.get_cmdline_user_args()[0]
	var f=FileAccess.open(path,FileAccess.WRITE);f.store_string(JSON.stringify(records,"\t")+"\n");f.close()
	print(JSON.stringify(records))
	quit()
