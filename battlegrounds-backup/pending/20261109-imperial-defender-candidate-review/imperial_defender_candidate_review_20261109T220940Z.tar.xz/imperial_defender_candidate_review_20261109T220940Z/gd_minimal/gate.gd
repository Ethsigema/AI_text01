extends SceneTree

const Source=preload("res://core/imperial_defender_sources.gd")

class MiniCatalog extends RefCounted:
	var cards: Dictionary={}
	func get_card(identity):
		return cards.get(identity,{})

func _init():
	call_deferred("_run")

func _key(container: Variant,key: Variant)->Variant:
	return int(key) if container is Array else key

func _mutate(value: Variant,entry: Dictionary)->Variant:
	var op: String=entry.op
	var path: Array=entry.path
	if op=="canonical": return value
	if op=="invalid_root": return entry.value.duplicate(true) if entry.value is Array or entry.value is Dictionary else entry.value
	if op=="id_only": return {"id":value.id}
	if op=="extra_unrelated":
		value["not-a-source"]={"id":"not-a-source"}
		return value
	if op=="invalid_member":
		value[path[0]]=null
		return value
	var parent: Variant=value
	for at in range(path.size()-1): parent=parent[_key(parent,path[at])]
	var key: Variant=_key(parent,path[-1]) if not path.is_empty() else null
	var prior: Variant=parent[key] if not path.is_empty() else value
	if op=="delete":
		if parent is Array: parent.remove_at(int(key))
		else: parent.erase(key)
		return value
	var changed: Variant=null
	match op:
		"bool_to_int": changed=int(prior)
		"bool_to_float": changed=float(prior)
		"toggle_bool": changed=not prior
		"numeric_float": changed=float(prior)
		"numeric_int": changed=int(prior)
		"number_delta": changed=prior+1
		"number_string": changed=str(prior)
		"number_bool": changed=bool(prior)
		"change_string": changed=prior+"__changed__"
		"null_to_false": changed=false
		"extra_key":
			changed=prior.duplicate(true)
			changed["__extra__"]=true
		"append_item":
			changed=prior.duplicate(true)
			changed.append("__extra__")
		"reverse_list":
			changed=prior.duplicate(true)
			changed.reverse()
		"nan": changed=NAN
		"pos_inf": changed=INF
		"neg_inf": changed=-INF
		_: assert(false,"Unknown mutation: "+op)
	if not path.is_empty(): parent[key]=changed
	else: value=changed
	return value

func _admitted(card: Variant,cards: Variant)->bool:
	if not card is Dictionary or not cards is Dictionary: return false
	if not Source.raw_source_error(card).is_empty(): return false
	for identity in Source.IDS:
		var row: Variant=cards.get(identity)
		if not row is Dictionary or not Source.raw_source_error(row).is_empty(): return false
	return true

func _run():
	var folder: String=ProjectSettings.globalize_path("res://").path_join("..").simplify_path()
	var cases: Array=JSON.parse_string(FileAccess.get_file_as_string(folder.path_join("CASES.json")))
	var python_report: Dictionary=JSON.parse_string(FileAccess.get_file_as_string(folder.path_join("PYTHON_REPORT.json")))
	var outputs: Dictionary=JSON.parse_string(FileAccess.get_file_as_string(folder.path_join("CANDIDATE_OUTPUTS.json")))
	var failures: Array=[]
	var results: Array=[]
	var accepted_count: int=0
	var historical_mismatches: int=0
	var closure_checks: int=0
	for index in range(cases.size()):
		var entry: Dictionary=cases[index]
		var identity: String=entry.get("supplied_identity",entry.identity)
		var card: Variant=Source.RAW[identity].duplicate(true)
		var cards: Variant=Source.RAW.duplicate(true)
		if entry.target=="card": card=_mutate(card,entry)
		elif entry.target=="mapping": cards[entry.identity]=_mutate(cards[entry.identity],entry)
		else: cards=_mutate(cards,entry)
		var before: String=JSON.stringify([card,cards])
		var accepted: bool=_admitted(card,cards)
		var py: Dictionary=python_report.results[index]
		if py.label!=entry.label or py.new_accept!=accepted: failures.append({"label":entry.label,"kind":"candidate_python_gd_admission","python":py.new_accept,"gd":accepted})
		if py.old_accept!=accepted: historical_mismatches+=1
		if before!=JSON.stringify([card,cards]): failures.append({"label":entry.label,"kind":"gd_raw_gate_changed_inputs"})
		if accepted:
			accepted_count+=1
			var catalog=MiniCatalog.new()
			for source_id in Source.IDS:
				var row: Dictionary=card.duplicate(true) if source_id==identity else cards[source_id].duplicate(true)
				if not Source.same(outputs[source_id],Source.EXPECTED[source_id]): failures.append({"label":entry.label,"kind":"python_output_differs_from_actual_gd_expected"})
				row.merge(outputs[source_id],true)
				catalog.cards[source_id]=row
				var source_issue: String=Source.source_error(row)
				if not source_issue.is_empty(): failures.append({"label":entry.label,"kind":"gd_compiled_source_error","error":source_issue})
			var closure_issue: String=Source.closure_error(catalog)
			if not closure_issue.is_empty(): failures.append({"label":entry.label,"kind":"gd_current_closure_error","error":closure_issue})
			closure_checks+=1
		results.append({"label":entry.label,"gd_accept":accepted,"matches_candidate":py.new_accept==accepted})
	var report: Dictionary={"case_count":cases.size(),"accepted":accepted_count,"rejected":cases.size()-accepted_count,"candidate_mismatches":failures.size(),"historical_acceptance_mismatches":historical_mismatches,"accepted_actual_source_and_closure_checks":closure_checks,"failures":failures,"results":results,"full_game_loaded":false,"full_catalog_loaded":false,"save_loaded":false,"godot_version":Engine.get_version_info()}
	var args: PackedStringArray=OS.get_cmdline_user_args()
	var output_path: String=args[0] if args.size()>0 else folder.path_join("GODOT_REPORT.json")
	var file=FileAccess.open(output_path,FileAccess.WRITE)
	file.store_string(JSON.stringify(report,"\t")+"\n")
	file.close()
	print("Cases ",cases.size(),"; accepted ",accepted_count,"; mismatches ",failures.size(),"; historical differences ",historical_mismatches)
	quit(0 if failures.is_empty() else 1)
