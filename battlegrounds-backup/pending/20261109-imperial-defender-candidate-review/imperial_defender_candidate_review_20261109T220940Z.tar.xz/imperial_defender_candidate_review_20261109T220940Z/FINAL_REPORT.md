# 皇家守护者：新修正候选评估，继续暂缓安装

## 结论

已经形成一份独立的新修正稿，证明它修正了历史Python工具的bool/数值混同问题。但不能宣称它与当前GD全部准入边界严格等价，因此按要求继续暂缓，未安装到现有源码树，345条原参考范围缺口没有减少。

这不是历史原样恢复，也不是找到了最新发布版本。没有为追求“全通过”削弱原来的键身份校验，没有修改当前GD、RAW、EXPECTED、普通/金色关系或partial及卡池状态。

## 来源与变更

目标为tools/imperial_defender_patterns.py，覆盖普通/金色皇家守护者BG22_HERO_007_Buddy及BG22_HERO_007_Buddy_G。

- 历史整本SHA256：397ce11d0ed60fb99bf6388941067ec71080fdbdd46344c216a2b4abf67cbb56。
- research/imperial_defender_native_recovery中的integration_manifest.json、shared_manifest.json均pin住该整本；shared_changes.patch的完整新增段精确重建相同字节。
- 新修正稿19,475 bytes，SHA256：bf3fffeaa2efe948fda69fe88b829f07353713e753de6a7e21cc093748c86a3b。
- 新补丁SHA256：2571eb5a312a30efa6f51f77ce3b7b17fc2bde55c0bfbaf8adab99024cbbf5be。精确前向及反向应用均通过，无模糊上下文。

修改仅增加类型敏感的递归same比较，用它替代card及cards来源行的普通Python相等，并对非字典cards安全返回None。原SOURCE_IDS、RAW、EXPECTED所有字面量保持不变，仅依赖Python标准库copy.deepcopy，没有新增项目依赖。

比较器说明限定为此家族固定RAW。RAW的72个数值叶子均为1到5,754的整数；不宣称通用Python/Godot大整数、任意浮点边界、自定义对象或循环结构语义一致。

## 已验证的窄范围修正

2,353个主测试覆盖传入card和cards来源行中的字段缺失、额外字段、数组变化、字符串变化、bool与0/1替换、等值int/float、非有限数值、普通/金色缺失、错误根类型及无关额外来源。

- 候选接受293项、拒绝2,060项，逐项符合实际GD raw_source_error组合检查在这些输入上的结果。
- 60项历史bool/数值混同反例由原版接受改为候选拒绝。
- 4项原版会抛出异常的非字典cards改为安全拒绝。
- 所有被接受的Python输出与原EXPECTED精确相同，输入不变、返回值深复制隔离通过，partial/default_pool/pool_supported标记未变。
- 对293项被接受输入，把实际Python输出合并到独立MiniCatalog，再调用当前GD source_error及closure_error，均通过。
- Godot 4.6.3主测试两次串行报告相同。最终主运行峰值75,996 KiB；便携复跑峰值76,556 KiB，低于192 MiB停止阈值。

这些是固定来源及隔离编译输出的验证，不是实际完整Catalog构建、宿主机制或游戏行为验收。非有限数值测试触发Godot的JSON.stringify将NaN显示为null的预期警告，已保留日志；没有SCRIPT ERROR或Godot ERROR。Python输入不变检查保留了非有限值类型区别。

## 阻止严格等价结论的3项结构反例

补充了4项完整映射结构测试，一项规范输入，以及以下3项反例：

1. 交换普通、金色两键对应的完整来源行。
2. 两键都指向普通来源行。
3. 两键都指向金色来源行。

候选对三项都拒绝，这是保留的原Python规则：cards[identity]必须匹配该identity的RAW。

当前GD的raw_source_error根据行内card.id验证来源，没有绑定外部映射键；source_error也按行内id验证。实际GD closure_error在本次MiniCatalog结构反例上均返回空字符串。该结果已做两次实际Godot复跑，报告一致。

因此，主测试的2,353项匹配只能证明测试范围内的修正，不能证明任意来源映射都严格等价。也不能仅凭此隔离反例断言完整游戏存在漏洞：完整Catalog或上游构建流程可能另有身份约束，本轮没有执行或全面证明那条路径。

不通过放宽候选的键身份要求来消除差异。下一步需要证明实际调用链强制维护键与行内id的一致性，或者由项目维护者明确决定统一哪一种契约；在此之前保留修正稿，不安装。

## 依赖与边界

- 当前GD最小预载图仅3个真实脚本：imperial_defender_sources.gd、phase_undead_army_sources.gd、pool_identity.gd，未使用重写的来源校验器。
- 当前Imperial RUNTIME_PATHS逐项检查，除目标工具仍缺失外，其余路径均存在并匹配已知源码树哈希；它们不等于均已执行验证。
- 完整驱动、catalog构建、Imperial宿主、施法监听器、Game/Combat和存档兼容未测试。将来安装工具仍可能改变Catalog执行指纹。
- 13份选定原始输入及独立副本哈希在结束时再次匹配；没有全量重哈希整个游戏树，未冒充全项目验收。
- 没有网络，没有访问被取消的下载，没有改旧备份，没有安装XML候选。4份原核验证据和2份SOURCE_CONTRACT的缺失状态未改变。

## 证据与复现

- FINAL_VERIFICATION.json：明确的暂缓结论、补丁往返及源文件复核。
- PYTHON_REPORT.json、GODOT_first.json、GODOT_repeat.json：主测试明细。
- MAPPING_PYTHON.json、MAPPING_GD.json、MAPPING_COMPARISON.json：结构反例和复跑记录。
- DEPENDENCY_SCOPE.json、NUMERIC_DOMAIN.json：依赖与数值范围。
- original_inputs/：保留的历史原件、manifest、原patch和实际GD输入。
- candidate/：独立新修正稿及修正patch，不能直接视为已批准安装项。
- REPLAY_RESULT.json：从12份最小输入复制到全新目录后完成的独立便携复跑。

需要复跑时，在解包目录执行python -B replay_to_new.py /一个不存在的新目录。它仅复制已pin住的12份测试输入，在新目录运行Python和最小Godot测试，并保留三项已知映射差异；不需要完整源码树，不安装任何工具。prepare.py和verify_candidate.py涉及原源码树来源检查，不能拿缺少该树的环境冒充重新核验了原树。

最终状态：窄范围修正已证明；严格全域等价、运行集成及安装继续暂缓。
