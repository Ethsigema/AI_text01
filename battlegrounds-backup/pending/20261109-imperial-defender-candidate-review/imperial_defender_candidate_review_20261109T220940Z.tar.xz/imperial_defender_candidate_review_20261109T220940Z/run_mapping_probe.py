from pathlib import Path
import ast, copy, hashlib, json, os, resource, subprocess, time, types

H=Path(__file__).resolve().parent
env=os.environ.copy()
for k,s in [('HOME','isolated_home'),('XDG_CACHE_HOME','isolated_cache'),('XDG_DATA_HOME','isolated_data'),('XDG_CONFIG_HOME','isolated_config')]:env[k]=str(H/s)
env['GODOT_SILENCE_ROOT_WARNING']='1'
def available_kib():
 return int(next(x for x in Path('/proc/meminfo').read_text().splitlines() if x.startswith('MemAvailable:')).split()[1])
def bound():
 resource.setrlimit(resource.RLIMIT_AS,(2*1024**3,2*1024**3));resource.setrlimit(resource.RLIMIT_CORE,(0,0))
assert available_kib()>=1024*1024
runs=[]
for run in ('first','repeat'):
 start=time.monotonic();peak=0
 with (H/f'MAPPING_{run}.stdout.log').open('w') as out,(H/f'MAPPING_{run}.stderr.log').open('w') as err:
  p=subprocess.Popen(['/usr/local/bin/godot','--headless','--path',str(H/'gd_minimal'),'--script','res://mapping_probe.gd','--',str(H/f'MAPPING_GD_{run}.json')],stdout=out,stderr=err,env=env,preexec_fn=bound)
  while p.poll() is None:
   try:
    for line in Path(f'/proc/{p.pid}/status').read_text().splitlines():
     if line.startswith('VmRSS:'):peak=max(peak,int(line.split()[1]))
   except FileNotFoundError:pass
   if peak>192*1024 or available_kib()<640*1024 or time.monotonic()-start>45:p.kill();p.wait();raise RuntimeError('resource guard stopped mapping probe')
   time.sleep(.01)
 assert p.returncode==0
 assert 'ERROR:' not in (H/f'MAPPING_{run}.stderr.log').read_text()
 runs.append({'run':run,'exit_code':p.returncode,'peak_rss_kib':peak,'seconds':round(time.monotonic()-start,3)})
gd=json.loads((H/'MAPPING_GD_first.json').read_text());assert gd==json.loads((H/'MAPPING_GD_repeat.json').read_text())
(H/'MAPPING_GD.json').write_text(json.dumps(gd,indent=2)+'\n')
candidate=H/'candidate/tools/imperial_defender_patterns.py';b=candidate.read_bytes();tree=ast.parse(b)
for node in tree.body:
 if isinstance(node,ast.Assign):ast.literal_eval(node.value)
 elif isinstance(node,ast.ImportFrom):assert node.module=='copy'
 elif isinstance(node,ast.Expr):assert isinstance(node.value,ast.Constant) and isinstance(node.value.value,str)
 else:assert isinstance(node,ast.FunctionDef)
m=types.ModuleType('candidate');exec(compile(tree,str(candidate),'exec'),m.__dict__)
n,g=m.SOURCE_IDS;results=[]
for label in ['canonical','swapped_pair','normal_under_both_keys','golden_under_both_keys']:
 cards=copy.deepcopy(m.RAW)
 if label=='swapped_pair':cards[n],cards[g]=copy.deepcopy(cards[g]),copy.deepcopy(cards[n])
 elif label=='normal_under_both_keys':cards[g]=copy.deepcopy(cards[n])
 elif label=='golden_under_both_keys':cards[n]=copy.deepcopy(cards[g])
 results.append({'label':label,'candidate_normal_accept':m.compile_card(copy.deepcopy(m.RAW[n]),cards)is not None,'candidate_golden_accept':m.compile_card(copy.deepcopy(m.RAW[g]),cards)is not None})
(H/'MAPPING_PYTHON.json').write_text(json.dumps(results,indent=2)+'\n')
report={'candidate_sha256':hashlib.sha256(b).hexdigest(),'runs':runs,'godot_repeat_identical':True,'cases':4,'expected_mapping_identity_divergences':3,'new_candidate_not_installed':True}
(H/'MAPPING_COMPARISON.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
