"""Replay only the isolated tests in a new directory, never in a project tree."""
from pathlib import Path
import hashlib, json, shutil, subprocess, sys

H=Path(__file__).resolve().parent
assert len(sys.argv)==2,'Provide one nonexistent destination directory'
destination=Path(sys.argv[1]).resolve();assert not destination.exists(),'Destination must not exist'
manifest=json.loads((H/'REPLAY_INPUTS.json').read_text());destination.mkdir(parents=True)
for rel,pin in manifest.items():
 source=H/rel;b=source.read_bytes();assert len(b)==pin['bytes'] and hashlib.sha256(b).hexdigest()==pin['sha256']
 target=destination/rel;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(b)
 assert source.stat().st_ino!=target.stat().st_ino
for script in ('test_python.py','run_godot.py','run_mapping_probe.py'):
 subprocess.run([sys.executable,'-B',str(destination/script)],check=True)
py=json.loads((destination/'PYTHON_REPORT.json').read_text());gd=json.loads((destination/'GODOT_first.json').read_text())
assert py['case_count']==2353 and py['candidate_accepted']==293 and py['old_accept_new_reject']==60
assert gd['candidate_mismatches']==0 and gd['historical_acceptance_mismatches']==60
assert json.loads((destination/'GODOT_repeat.json').read_text())==gd
mapping=json.loads((destination/'MAPPING_GD.json').read_text());pymapping=json.loads((destination/'MAPPING_PYTHON.json').read_text())
for g,p in zip(mapping,pymapping):
 assert g['label']==p['label'] and not g['actual_closure_error']
 assert p['candidate_normal_accept']==p['candidate_golden_accept']==(p['label']=='canonical')
report={'status':'PASS_ISOLATED_REPLAY_WITH_KNOWN_IDENTITY_DIVERGENCES_PRESERVED','destination':str(destination),
 'copied_files':len(manifest),'source_tree_required':False,'source_tree_modified':False,
 'primary_cases':2353,'primary_mismatches':0,'historical_alias_counterexamples':60,
 'additional_mapping_cases':4,'mapping_identity_divergences':3,
 'strict_equivalence_proven':False,'candidate_installation_approved':False}
(destination/'REPLAY_RESULT.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
