from pathlib import Path
import ast, hashlib, json, re, resource

resource.setrlimit(resource.RLIMIT_AS,(128*1024*1024,128*1024*1024))
H=Path(__file__).resolve().parent;R=H.parent/'historical_tools_batch14_20261109T191857Z/runtime'
target='tools/imperial_defender_patterns.py'
original=(H/'original_inputs/research/imperial_defender_native_recovery/candidates/tools/imperial_defender_patterns.py').read_bytes()
candidate=(H/'candidate'/target).read_bytes()
def patch_sections(b):
 lines=b.decode().splitlines(keepends=True);sections=[];i=0
 while i<len(lines):
  if lines[i].startswith('--- ') and i+1<len(lines) and lines[i+1].startswith('+++ '):
   old=lines[i][4:].strip();new=lines[i+1][4:].strip();j=i+2
   while j<len(lines) and not lines[j].startswith('--- '):j+=1
   sections.append((old,new,lines[i+2:j]));i=j
  else:i+=1
 return sections
def apply(source,body,reverse=False):
 src=source.decode().splitlines(keepends=True);out=[];pos=0;i=0
 while i<len(body):
  line=body[i];m=re.match(r'^@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@',line)
  assert m,line[:80];a,ac,b,bc=int(m[1]),int(m[2] or 1),int(m[3]),int(m[4] or 1)
  if reverse:a,ac,b,bc=b,bc,a,ac
  start=a-1 if ac else a;assert start>=pos
  out.extend(src[pos:start]);old=[];new=[];i+=1
  while i<len(body) and not body[i].startswith('@@ '):
   s=body[i];i+=1
   assert s[0] in ' +-'
   prefix=s[0]
   if reverse:prefix={'-':'+','+':'-',' ':' '}[prefix]
   if prefix in ' -':old.append(s[1:])
   if prefix in ' +':new.append(s[1:])
  assert len(old)==ac and len(new)==bc
  assert src[start:start+ac]==old,'Exact context mismatch'
  out.extend(new);pos=start+ac
 out.extend(src[pos:]);return ''.join(out).encode()
historical_patch=H/'original_inputs/research/imperial_defender_native_recovery/shared_changes.patch'
sec=next(x for x in patch_sections(historical_patch.read_bytes()) if x[1] in ('b/'+target,target))
assert sec[0]=='/dev/null';assert apply(b'',sec[2])==original
correction=H/'candidate/strict_equality_correction.patch';secs=patch_sections(correction.read_bytes());assert len(secs)==1
assert apply(original,secs[0][2])==candidate;assert apply(candidate,secs[0][2],True)==original
pins=json.loads((H/'INPUT_PINS.json').read_text());assert len(pins)==13
for rel,v in pins.items():
 for path in [R/rel,H/'original_inputs'/rel]:
  b=path.read_bytes();assert len(b)==v['bytes'] and hashlib.sha256(b).hexdigest()==v['sha256']
assert not (R/target).exists()
current=(R/'core/imperial_defender_sources.gd').read_text();match=re.search(r'^const RUNTIME_PATHS: Array=(.*)$',current,re.M);paths=json.loads(match[1]);base=json.loads((R.parent/'SOURCE_MAP.json').read_text());runtime=[]
for rel in paths:
 p=R/rel;record={'path':rel,'exists':p.is_file(),'executed_in_review':rel in ['core/imperial_defender_sources.gd']}
 if p.is_file():
  b=p.read_bytes();record.update({'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()});assert record['sha256']==base[rel]['sha256']
 runtime.append(record)
tree=ast.parse(candidate);imports=[]
for n in ast.walk(tree):
 if isinstance(n,ast.ImportFrom):imports.append(n.module)
assert imports==['copy']
catalog_path=R/'core/catalog.gd';b=catalog_path.read_bytes();assert hashlib.sha256(b).hexdigest()==base['core/catalog.gd']['sha256']
catalog_refs=[{'line':i,'text':l} for i,l in enumerate(b.decode().splitlines(),1) if 'ImperialSources' in l and ('RUNTIME_PATHS' in l or 'preload(' in l)]
dependency={'tool_python_imports':imports,'new_python_dependencies_added':[],
 'gd_preload_graph':{'core/imperial_defender_sources.gd':['core/phase_undead_army_sources.gd','core/pool_identity.gd'],'core/phase_undead_army_sources.gd':['core/pool_identity.gd'],'core/pool_identity.gd':[]},
 'current_runtime_paths':runtime,'current_missing_runtime_paths':[x['path'] for x in runtime if not x['exists']],
 'catalog_sha256':hashlib.sha256(b).hexdigest(),'catalog_fingerprint_references':catalog_refs,
 'complete_driver_host_game_integration_tested':False,'native_evidence_bytes_verified_but_not_runtime_executed':True}
(H/'DEPENDENCY_SCOPE.json').write_text(json.dumps(dependency,indent=2)+'\n')
gd=json.loads((H/'GODOT_first.json').read_text());assert gd==json.loads((H/'GODOT_repeat.json').read_text())
assert gd['candidate_mismatches']==0 and gd['case_count']==2353
py=json.loads((H/'PYTHON_REPORT.json').read_text());assert py['old_accept_new_reject']==60
maps=json.loads((H/'MAPPING_GD.json').read_text());pymaps=json.loads((H/'MAPPING_PYTHON.json').read_text())
assert len(maps)==len(pymaps)==4
for g,p in zip(maps,pymaps):
 assert g['label']==p['label'] and g['actual_raw_functions_accept_all_rows'] and g['actual_source_functions_accept_all_rows'] and not g['actual_closure_error']
 assert p['candidate_normal_accept']==p['candidate_golden_accept']==(p['label']=='canonical')
result={'status':'NARROW_CORRECTION_DEMONSTRATED_STRICT_EQUIVALENCE_AND_INSTALLATION_DEFERRED',
 'original_sha256':hashlib.sha256(original).hexdigest(),'candidate_sha256':hashlib.sha256(candidate).hexdigest(),
 'historical_creation_patch_exact':True,'new_correction_patch_forward_reverse_exact':True,
 'all_13_original_input_files_unchanged':True,'candidate_not_installed':True,
 'primary_mutation_cases':2353,'primary_python_gd_mismatches':0,'godot_repeat_exact':True,
 'historical_bool_numeric_counterexamples_fixed':60,'historical_bad_mapping_exceptions_now_rejected':4,
 'additional_mapping_probes':4,'key_identity_counterexamples_to_universal_equivalence':3,
 'preserved_stricter_key_identity_check':True,'no_weakened_GD_or_source_data':True,
 'game_full_catalog_save_tested':False,'max_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
(H/'FINAL_VERIFICATION.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
