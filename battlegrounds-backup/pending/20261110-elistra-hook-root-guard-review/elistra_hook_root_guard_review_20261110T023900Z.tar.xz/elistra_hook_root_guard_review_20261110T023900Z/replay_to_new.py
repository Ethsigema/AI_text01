from pathlib import Path
import hashlib,json,resource,subprocess,sys
resource.setrlimit(resource.RLIMIT_AS,(128*1024**2,128*1024**2))
H=Path(__file__).resolve().parent
if len(sys.argv)!=2:raise SystemExit('Usage: python replay_to_new.py /absolute/new/directory')
D=Path(sys.argv[1]).resolve();assert not D.exists();D.mkdir(parents=True)
pins=json.loads((H/'REPLAY_INPUTS.json').read_text())
for rel,pin in pins.items():
 p=Path(rel);assert not p.is_absolute() and '..' not in p.parts
 b=(H/rel).read_bytes();assert len(b)==pin['bytes'] and hashlib.sha256(b).hexdigest()==pin['sha256'];q=D/p;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(b)
for script in ['test_guard.py','verify_results.py']:
 r=subprocess.run([sys.executable,str(D/script)],capture_output=True,text=True);(D/(script+'.stdout.log')).write_text(r.stdout);(D/(script+'.stderr.log')).write_text(r.stderr);assert r.returncode==0,(script,r.stderr)
for rel,pin in pins.items():assert hashlib.sha256((D/rel).read_bytes()).hexdigest()==pin['sha256']
for rel in ['PROBE_RESULT.json','VERIFIED_RESULTS.json']:
 a=json.loads((H/rel).read_text());b=json.loads((D/rel).read_text());a.pop('max_rss_kib');b.pop('max_rss_kib');assert a==b,rel
report={'input_files':len(pins),'equal_reports_except_rss':['PROBE_RESULT.json','VERIFIED_RESULTS.json'],'new_directory':str(D),'input_hashes_unchanged':True,'no_godot_or_full_driver_run':True,'max_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss};(D/'REPLAY_RESULT.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
