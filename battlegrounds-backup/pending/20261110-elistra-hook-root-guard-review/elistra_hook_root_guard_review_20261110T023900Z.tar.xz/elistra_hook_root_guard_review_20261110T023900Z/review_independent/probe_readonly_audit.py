import resource
resource.setrlimit(resource.RLIMIT_AS, (128 * 1024**2, 128 * 1024**2))
import ast
import collections
import hashlib
import json
from pathlib import Path

W = Path('/workspace/scratch/dd4f12b08ec0')
H = W / 'elistra_hook_root_guard_review_20261110T023900Z'
D = Path(__file__).resolve().parent
I = H / 'inputs'
SOURCE_PREFIX = 'elistra_redirect_correction_review_20261110T021700Z/'
seen = {}
checks = 0

def check(ok, label):
    global checks
    assert ok, label
    checks += 1

def read(path):
    b = path.read_bytes()
    seen[str(path.relative_to(W))] = {'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest()}
    return b.decode('utf-8')

def frozen(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=False)

check(hashlib.sha256((D/'review.md').read_bytes()).hexdigest() == '3170936166cbef182cee27797b298cb673ddac95f18323a05d840146966a073a', 'original review unchanged')
probe = read(H/'test_guard.py')
probe_tree = ast.parse(probe)
result = json.loads(read(H/'PROBE_RESULT.json'))
check(seen[str((H/'test_guard.py').relative_to(W))]['sha256']=='717f43a0156325cf41f3fd89ec0c7c083978924bc24b83970ac41ad2fa6154ad', 'final probe code pin')
check(seen[str((H/'PROBE_RESULT.json').relative_to(W))]['sha256']=='1b2d700b60712f953e3777279db5c56a47a20c60a083e40bcc24c73321efd853', 'final main result pin')
patch = read(H/'PROPOSED_LOCAL_GUARD.patch')
original = read(H/'ORIGINAL_FOUR_NODES.py')
guarded = read(H/'PROPOSED_GUARDED_FRAGMENT.py')
proposal = json.loads(read(H/'PROPOSAL_MANIFEST.json'))
pins = json.loads(read(H/'INPUT_PINS.json'))
for source, pin in pins.items():
    check(source.startswith(SOURCE_PREFIX), 'source input prefix')
    relative = source[len(SOURCE_PREFIX):]
    read(I/relative)
    check(seen[str((I/relative).relative_to(W))] == pin, 'snapshot input pin: '+relative)

source = read(I/'prior_snapshot/original_inputs/research/elistra_redirect_native_recovery/candidates/tools/build_effect_catalog.py')
check(hashlib.sha256(source.encode()).hexdigest() == '260f3d719d16e0ccc5c3c8527427a0b3e44e0ca69c61b9a6efad2f393c511ebc', 'historical driver fixed pin')
tree = ast.parse(source)
emit = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'emit')
loop = next(n for n in tree.body if isinstance(n, ast.For) and isinstance(n.iter, ast.Name) and n.iter.id == 'ELISTRA_REDIRECT_IDS')
pos = tree.body.index(loop)
nodes = [emit, loop, *tree.body[pos+1:pos+3]]
check([(type(n).__name__, n.lineno, n.end_lineno) for n in nodes] == [('FunctionDef',559,559),('For',3275,3281),('Assign',3282,3282),('Expr',3283,3283)], 'four original source nodes')
check(original == '\n\n'.join(ast.get_source_segment(source, n) for n in nodes)+'\n', 'original four-node text exact')
guard = "if not isinstance(cards,dict):\n raise TypeError('elistra_redirect_invalid_cards_root')\n"
check(guarded == original.replace('for identity in ELISTRA_REDIRECT_IDS:', guard+'for identity in ELISTRA_REDIRECT_IDS:', 1), 'guarded text adds only exact root guard')
a = ast.parse(original)
b = ast.parse(guarded)
check(len(a.body) == 4 and len(b.body) == 5, 'node counts four/five')
check(ast.dump(a, include_attributes=False) == ast.dump(ast.Module(body=[b.body[0],*b.body[2:]],type_ignores=[]), include_attributes=False), 'all four original AST nodes unchanged')
lines = source.splitlines(keepends=True)
expected_patch = '--- a/tools/build_effect_catalog.py\n+++ b/tools/build_effect_catalog.py\n@@ -3273,6 +3273,8 @@\n'+''.join(' '+x for x in lines[3272:3274])+''.join('+'+x for x in guard.splitlines(keepends=True))+''.join(' '+x for x in lines[3274:3278])
check(patch == expected_patch, 'patch exact six-line historical context and two-line addition')
check(hashlib.sha256(guarded.encode()).hexdigest() == proposal['guarded_fragment_sha256'], 'guarded fragment manifest hash')
check(hashlib.sha256(patch.encode()).hexdigest() == proposal['proposal_patch_sha256'], 'patch manifest hash')
check(proposal['complete_modified_driver_created'] is False, 'manifest declares no whole-driver creation')
controls_node = next(n for n in probe_tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='controls' for t in n.targets))
check(isinstance(controls_node.value,ast.List) and len(controls_node.value.elts)==10, 'probe has ten supplementary controls')
check("'out_key_insertion_order':list(ns['out'])" in probe, 'probe directly records output mapping insertion order')
# Inspect probe text/AST only. No import, compile, exec, or call of inspected code.
for needle in ["assert a==b,(case['label'],seed)", "b['message']=='elistra_redirect_invalid_cards_root'", "b['identity_bound'] is None", "if seed=='seeded':assert IDS[0] not in aout", "assert old['hook_error']==a['error']", "assert frozen(aout)==frozen(prior['hook_output_pool'][old['hook_outputs_index']])", "for path,b in fixtures.items():assert (R/path).read_bytes()==b"]:
    check(needle in probe, 'probe assertion present: '+needle)

cases = json.loads(read(I/'CASES.json'))
prior = json.loads(read(I/'PYTHON_REPORT.json'))
check(len(cases)==len(prior['results'])==len(result['results'])==886, '886 aligned cases')
ids = ('BGS_205','TB_BaconUps_306')
initial_order = ['unrelated', ids[1], ids[0]]
pool = result['output_pool']
counts = collections.Counter()
root_counts = collections.Counter()
invalid = []
for index,(case,old,entry) in enumerate(zip(cases,prior['results'],result['results'])):
    check(case['label']==old['label']==entry['label'], 'case labels aligned')
    check(case['regime']==entry['regime'], 'case regimes aligned')
    invalid_root_case = case['regime']=='mapping_root' and case['op']=='invalid_root' and not isinstance(case['value'],dict)
    check(entry['cards_is_dict'] is (not invalid_root_case), 'reported root class agrees with mutation domain')
    check(set(entry['seeds']) == {'empty','seeded'}, 'both seed records')
    if invalid_root_case:
        check(entry['root_type']==type(case['value']).__name__, 'invalid root runtime type')
        root_counts[entry['root_type']]+=1
        invalid.append({'label':entry['label'],'type':entry['root_type'],'value':case['value']})
    for seed,record in entry['seeds'].items():
        x,y=record['baseline'],record['guarded']
        initial = {} if seed=='empty' else {ids[0]:{'prior_source':ids[0]},ids[1]:{'prior_source':ids[1]},'unrelated':{'keep':['exact']}}
        for version in (x,y):
            check(type(version['out_index']) is int and 0<=version['out_index']<len(pool), 'valid output pool reference')
            check(len(version['out_key_insertion_order'])==len(set(version['out_key_insertion_order'])) and set(version['out_key_insertion_order'])==set(pool[version['out_index']]), 'recorded insertion-order keys match output membership')
            unchanged=frozen([pool[version['out_index']],version['ordered_ids']])==frozen([initial,initial_order])
            check(version['state_unchanged'] is unchanged, 'state flag recomputed from stored values')
        if not invalid_root_case:
            check(x==y, 'dict complete record equality')
            check(record['equivalent_for_dict_root'] is True, 'dict equivalence flag')
            counts['dict_state_and_trace_equal']+=1
        else:
            check(x['error']=='AttributeError' and not x['calls'] and x['identity_bound']==ids[0], 'baseline invalid root precompiler failure')
            check(y['error']=='TypeError' and y['message']=='elistra_redirect_invalid_cards_root' and not y['calls'] and y['identity_bound'] is None, 'guard explicit rejection before compiler and loop')
            check(y['state_unchanged'] and pool[y['out_index']]==initial and y['ordered_ids']==initial_order, 'invalid root preserves hook input state')
            check(record['equivalent_for_dict_root'] is False, 'non-dict never labeled equivalent')
            check(y['out_key_insertion_order']==list(initial), 'invalid root preserves mapping insertion order')
            expected_old=dict(initial);expected_old.pop(ids[0],None)
            check(pool[x['out_index']]==expected_old and x['ordered_ids']==initial_order and x['out_key_insertion_order']==list(expected_old), 'baseline removes only first target')
            if seed=='seeded':
                check(x['state_unchanged'] is False, 'seeded partial mutation recorded')
                counts['partial_pop_avoided_seeded']+=1
            counts['explicit_root_rejections']+=1
        if seed=='empty':
            historical=old['versions']['candidate']
            check(historical['hook_error']==x['error'], 'legacy baseline error agreement')
            check(historical['hook_accepted_ids']==sorted(pool[x['out_index']]), 'legacy baseline target ids agreement')
            check(frozen(prior['hook_output_pool'][historical['hook_outputs_index']])==frozen(pool[x['out_index']]), 'legacy baseline output agreement')
            check(all(call['same_mapping_value'] for call in x['calls']), 'baseline uses actual mapping row')
check(dict(counts)==result['counts']=={'dict_state_and_trace_equal':1756,'explicit_root_rejections':16,'partial_pop_avoided_seeded':8}, 'recomputed summary counts')
check(root_counts=={'NoneType':2,'list':2,'int':2,'str':2}, 'four invalid root types twice each')
check(result['cases']==886 and result['dict_root_cases']==878 and result['legacy_exception_cases']==8, 'summary case counts')
check(result['comparisons']==1772 and result['hook_fragment_executions']==3544, 'main matrix count scope')
check(result['extra_control_fragment_executions']==20 and result['total_fragment_executions_this_run']==3564 and result['output_mapping_key_insertion_order_checked'] is True, 'final count and insertion-order summary')
extras={e['label']:e for e in result['extra_controls']}
check(len(extras)==10, 'ten unique control records')
for label,entry in extras.items():
    x,y=entry['baseline'],entry['guarded']
    if entry['is_dict']:
        check(x==y, 'dict control behavior unchanged: '+label)
    else:
        check(y['error']=='TypeError' and y['message']=='elistra_redirect_invalid_cards_root' and not y['calls'] and y['identity_bound'] is None, 'non-dict control explicit rejection: '+label)
        check(y['state_unchanged'] and pool[y['out_index']]=={ids[0]:{'prior_source':ids[0]},ids[1]:{'prior_source':ids[1]},'unrelated':{'keep':['exact']}} and y['ordered_ids']==initial_order, 'non-dict control state preserved: '+label)
        check(y['out_key_insertion_order']==[ids[0],ids[1],'unrelated'], 'non-dict control preserves mapping insertion order: '+label)
mapping=extras['mapping_proxy_not_dict']
check(mapping['baseline']['error'] is None and len(mapping['baseline']['calls'])==2 and pool[mapping['baseline']['out_index']]=={'unrelated':{'keep':['exact']}} and mapping['baseline']['ordered_ids']==['unrelated'], 'mapping proxy baseline silently drops both targets')
bad=extras['dict_bad_get']
check(bad['baseline']==bad['guarded'] and bad['guarded']['error']=='RuntimeError' and bad['guarded']['message']=='controlled_bad_get' and not bad['guarded']['state_unchanged'], 'bad get remains explicit and partially mutating')
check(extras['ordinary_dict_subclass']['is_dict'] and extras['ordinary_dict_subclass']['baseline']==extras['ordinary_dict_subclass']['guarded'], 'plain dict subclass preserved')
module=ast.parse(read(I/'candidate/tools/elistra_redirect_patterns.py'))
proof_node=next(n for n in module.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='PROOF_SHA256' for t in n.targets))
for relative,digest in ast.literal_eval(proof_node.value).items():
    read(H/'fixture_root'/relative)
    check(seen[str((H/'fixture_root'/relative).relative_to(W))]['sha256']==digest,'current fixture restored: '+relative)
P=W/'elistra_root_guard_portable_replay_20261110T025000Z'
replay_inputs=json.loads(read(H/'REPLAY_INPUTS.json'))
check(len(replay_inputs)==18, 'eighteen final replay input files')
for relative,pin in replay_inputs.items():
    for directory in (H,P):
        read(directory/relative)
        check(seen[str((directory/relative).relative_to(W))]==pin, 'final replay input byte/hash match: '+str(directory.name)+'/'+relative)
for filename in ('PROBE_RESULT.json','VERIFIED_RESULTS.json'):
    main=json.loads(read(H/filename))
    replay=json.loads(read(P/filename))
    main.pop('max_rss_kib',None)
    replay.pop('max_rss_kib',None)
    check(main==replay, 'recorded portable report equals final main except RSS: '+filename)
check(seen[str((P/'PROBE_RESULT.json').relative_to(W))]['sha256']=='5a552e0211d9c5a0108e4f80e7e1ad835f90ecfb1d96927bb1a937e6fb2d8d16', 'final portable result pin')
replay_meta=json.loads(read(P/'REPLAY_RESULT.json'))
check(replay_meta['input_files']==18 and replay_meta['new_directory']==str(P) and replay_meta['input_hashes_unchanged'] is True, 'portable result identifies final directory and input count')
output={
 'status':'READONLY_CODE_AND_RECORDED_RESULT_REVIEW_NOT_RUNTIME_RERUN_OR_DRIVER_ACCEPTANCE',
 'memory_limit_bytes':128*1024**2,
 'review_assertions_passed':checks,
 'reviewer_ran_target_probe':False,
 'reviewer_ran_driver_compiler_hook_or_godot':False,
 'historical_cases':886,
 'dictionary_cases':878,
 'dictionary_comparisons':counts['dict_state_and_trace_equal'],
 'non_dictionary_case_records':8,
 'explicit_root_rejections':counts['explicit_root_rejections'],
 'seeded_partial_pop_avoided':counts['partial_pop_avoided_seeded'],
 'main_matrix_fragment_executions_recorded':3544,
 'supplementary_controls_recorded':10,
 'supplementary_fragment_executions_recorded':20,
 'total_fragment_executions_recorded':3564,
 'invalid_root_types':dict(root_counts),
 'invalid_cases':invalid,
 'trace_scope':'compile_proxy calls only, not all possible external calls or every Python operation',
 'ordering_scope':'ordered_ids and separately recorded out_key_insertion_order both compared in final baseline/guard records',
 'final_replay_directory':str(P.relative_to(W)),
 'final_replay_input_files_verified':18,
 'final_replay_reports_equal_except_rss':['PROBE_RESULT.json','VERIFIED_RESULTS.json'],
 'rollback_scope':'invalid-root guard preserves this hook entry out/ordered_ids only; no full-driver rollback',
 'input_pins':seen,
 'review_max_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
}
(D/'PROBE_READONLY_AUDIT.json').write_text(json.dumps(output,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in output.items() if k not in ('input_pins','invalid_cases')},ensure_ascii=False,indent=2))
