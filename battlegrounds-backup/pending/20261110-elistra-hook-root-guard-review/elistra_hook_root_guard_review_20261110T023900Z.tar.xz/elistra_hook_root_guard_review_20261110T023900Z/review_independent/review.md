# Elistra 根类型守卫独立静态复核

结论：同意把 `if not isinstance(cards,dict): raise TypeError('elistra_redirect_invalid_cards_root')` 作为仅针对 Elistra 局部 hook 的最小、明确拒绝式防护候选。应插入原 driver 第 3274 行注释之后、第 3275 行 `for` 之前。不能把它称为完整 driver 的安全整合、全流程输入校验或统一运行验收通过。本次未修改或执行原 driver，也未修改或执行独立 compiler 候选。

## 输入与范围

- 原 driver：`historical_tools_batch14_20261109T191857Z/runtime/research/elistra_redirect_native_recovery/candidates/tools/build_effect_catalog.py`
  - SHA-256：`260f3d719d16e0ccc5c3c8527427a0b3e44e0ca69c61b9a6efad2f393c511ebc`
- 独立 compiler 候选：`elistra_redirect_correction_review_20261110T021700Z/candidate/tools/elistra_redirect_patterns.py`
  - SHA-256：`5117ad6bf7e755be6063d3538aa541e6633ca1091e163e247a5427a06c74e2ab`
- 两项输入 pin 均已逐字节核对。历史 262 / 新 886 case 中 8 次异常、实为四类根各重复两次，是父任务提供的审查背景，不是本次重新运行的结果。
- 本次执行 `python -I -B static_review.py`，先设 RLIMIT_AS = 128 MiB，再做静态 AST 检查及独立两行类型守卫断言，共 31 项通过。未 import 或执行任何历史 driver、compiler、hook 片段、Game、Combat、Catalog、Godot；未联网、下载或操作旧存档、私聊、凭据、缓存。

## 精确原片段

原 driver 第 3274–3283 行，保存在 `original_hook.txt`；SHA-256 为 `7614a191359431988616b20efb7072b93878504a76b8782c7399aa4952cf5c0b`。

```python
# Independent complete Elistra actual attack-target replacement.
for identity in ELISTRA_REDIRECT_IDS:
 out.pop(identity,None)
 c=cards.get(identity)
 compiled=compile_elistra_redirect(c,cards,root=R)
 if compiled is not None:
  metadata={k:v for k,v in compiled.items() if k not in ('effects','keywords','coverage_rule')}
  emit(c,compiled['effects'],compiled['keywords'],rule=compiled['coverage_rule'],**metadata)
ordered_ids=[identity for identity in ordered_ids if identity not in ELISTRA_REDIRECT_IDS]
ordered_ids.extend(identity for identity in ELISTRA_REDIRECT_IDS if identity in out)
```

建议仅增加：

```python
# Independent complete Elistra actual attack-target replacement.
if not isinstance(cards,dict): raise TypeError('elistra_redirect_invalid_cards_root')
for identity in ELISTRA_REDIRECT_IDS:
```

完整局部建议片段在 `proposed_guarded_hook.txt`，SHA-256 为 `6d65a5e741b96965bde9b6d8ad276cd283b7770a02da8f183acd35003f43a300`。AST 比较确认只新增一个顶层 `If`，原三个顶层语句（for、顺序过滤赋值、顺序 extend）逐项结构相同。没有创建完整候选 driver。

## 实际 cards 契约

1. 原 driver 第 531 行直接构造 `cards={c['id']:c for c in raw}`，这是标准 Python `dict`。整份 driver 的静态 AST 中，`cards` 只有这一处直接 Store / Del 绑定；第 533 行已使用 `cards.values()`，第 720 行已使用 `cards.items()`。本结论不假设能证明所有外部函数绝无任意动态全局修改。
2. 候选 `compile_card` 的第一条判定已有 `not isinstance(cards,dict)` 并对其返回 `None`，但旧 hook 先执行 `cards.get`，所以 None、list、int、str 的根在进入 compiler 前就失败。此次新检查在 hook 的入口补足明确根契约，并非修改 compiler 接受范围。
3. 候选 `SOURCE_IDS` 为 `('BGS_205', 'TB_BaconUps_306')`。driver 无通配导入，未发现 `dict`、`isinstance` 或 `TypeError` 的直接赋值、删除、for 目标或导入覆盖；还检查了插入点前函数 / 类定义、异常名称与 match 模式绑定，没有遮蔽。
4. 所有 `isinstance(cards, dict)` 为真的输入，新增条件为假，原 hook 语句和顺序不变。包括空字典、缺失目标键、错误行值、dict 子类；这些输入仍交由既有逻辑处理。守卫不进行补值、转换、深复制或重新排序。特殊 dict 子类的重载 `.get()` 风险也没有被此守卫消除。
5. 非 dict 的 Mapping、具有 `.get()` 的自定义对象也被明确拒绝。此行为比旧 hook 的偶然 duck typing 严格，但符合生产字典构造与候选 compiler 的既有 `isinstance(..., dict)` 契约。它不是通用 Mapping 兼容性修复。

## 四类根及部分副作用

在输入 `out` 为正常字典、候选 source tuple 如上时：

- 旧 hook 对 `None`、`[]`、`0`、`'invalid'` 均先执行第一轮 `out.pop('BGS_205', None)`，再在 `cards.get` 处抛 `AttributeError`。如果普通目标原本存在，先被删除；如果不存在则没有实际删除。金色目标尚未遍历，compiler 未调用，两条 `ordered_ids` 语句也未执行。
- 新守卫对四类根均先抛 `TypeError`，错误消息固定为 `elistra_redirect_invalid_cards_root`。任何 Elistra `out.pop`、compiler、emit、顺序修改均不可达。保留 hook 进入时 `out` 与 `ordered_ids` 的状态，而非清除部分目标后失败。
- 这只消除了该 hook 对无效根的局部首轮副作用，不回滚此前 driver 已做的工作，不保证更早函数没有副作用，也不使后续执行原子化。
- 异常类别与文案有意改变，是需要对调用方说明的可观察差异。失败后状态不能被误当作成功的新产物，调用方也不能捕获并吞掉 TypeError 后宣称成功。
- driver 在进入该 hook 很久以前已依赖字典方法，因此孤立测试注入无效根不等于证明生产完整 driver 会在该行首先出错。守卫的位置是 Elistra 局部边界，不是全局入口。

## 为什么两个静默方案不能直接称为安全整合

仅静态比较，未实施、未执行以下方案。

- `c=cards.get(identity) if isinstance(cards,dict) else None`：仍先删除每个目标。对于无效根，候选 compiler 返回 `None`，随后两个目标都可能从 `out` 与顺序中被移除，局部 hook 无明确失败信号。它把整体根损坏降格成逐卡不可编译，改变诊断与控制流。后续 driver 是否还会失败未运行，不能据此称其成功修复。
- 非 dict 时跳过整个 loop：如果继续执行现有顺序清理和重加，会从 `out` 中保留并重新加入旧目标，且未做本次来源校验；如果连顺序部分也跳过，同样保留旧目标及旧顺序。它不能区分失败与已复核产物，也没有建立合法替代结果。
- 两者都可能避免这一个 `.get` 异常，但避免异常本身不是正确性或完整接线证明。需要产品语义另行授权并测试才可采用；本次最小方案应保留明确失败。

## 判定边界

推荐该局部守卫进入独立片段的后续验证。四类异常应断言明确拒绝、零 compiler / emit 调用、hook 局部 `out` 和 `ordered_ids` 未变；合法字典应与原 hook 对照。该候选不扩展来源、卡池、支持标记或运行时能力。完整 driver 安装、catalog 生成、Game / Combat / Godot 执行及统一验收均未进行，不能从 31 项静态 / 守卫断言外推通过。
