# 父任务终版实际片段探针的只读复核补充

结论：终版代码、记录结果、历史输入、四个真实 AST 节点及局部 patch 相互一致，可以支持“该局部根类型守卫提前明确拒绝非 dict 根，并保持现有字典根片段行为”的结论。本复核未运行父探针或被测代码，不构成独立运行复现，更不代表整个 driver / Game / Combat / Catalog / Godot 通过或事务原子性成立。

原 `review.md` 及原五份静态审查文件保持不变。本补充使用终版主目录 `elistra_hook_root_guard_review_20261110T023900Z` 和终版便携目录 `elistra_root_guard_portable_replay_20261110T025000Z`，不采用旧便携目录作为终版证据。

## 核对方式

运行自写 `probe_readonly_audit.py`，仅解析 Python AST、读取 JSON / patch / fixture 的字节、核对 SHA-256，以及对已记录结果做独立一致性断言。没有导入或执行目标 probe、driver、compiler、hook、Godot，也没有写入父任务目录、旧成果、fixture 或输入。进程内存限制 128 MiB，本次最大 RSS 73,712 KiB。

共通过 21,465 项逐记录、引用、计数及 pin 一致性断言。这是对记录的检查次数，不是新增测试用例或新增运行次数。机器结果见 `PROBE_READONLY_AUDIT.json`，其中包含实际读取文件的完整 hash 与尺寸。

## 精确来源与改动

- 历史 driver SHA-256 仍为 `260f3d719d16e0ccc5c3c8527427a0b3e44e0ca69c61b9a6efad2f393c511ebc`。
- 候选 compiler SHA-256 仍为 `5117ad6bf7e755be6063d3538aa541e6633ca1091e163e247a5427a06c74e2ab`。
- 原片段逐字对应第 559 行 emit、第 3275–3281 行 Elistra for、第 3282 行 ordered_ids 赋值、第 3283 行 extend，四节点文本及 AST 一致。
- 守卫片段仅新增第 3275 行 for 之前的两行 if / raise；原四节点 AST 未变。
- patch 六行旧上下文与历史 driver 原文完全相符，只增加根类型 if / TypeError 两行。未创建或安装完整修改版 driver。

终版关键 pin：

- `test_guard.py`：`717f43a0156325cf41f3fd89ec0c7c083978924bc24b83970ac41ad2fa6154ad`
- 主 `PROBE_RESULT.json`：`1b2d700b60712f953e3777279db5c56a47a20c60a083e40bcc24c73321efd853`
- `PROPOSED_GUARDED_FRAGMENT.py`：`0080f09b652a29e9c050254e5b5c925824095bda51f39b0075f7c995334321be`
- `PROPOSED_LOCAL_GUARD.patch`：`cd2b42cda6dd9488721967ed67818f47e11228d424267be6a40fc36a974ae7af`
- 终版便携 `PROBE_RESULT.json`：`5a552e0211d9c5a0108e4f80e7e1ad835f90ecfb1d96927bb1a937e6fb2d8d16`

## 逐记录复核结果

1. 886 个 case 的标签、顺序与原先报告对齐。878 个是字典根样本，包括有效来源及各类负例，不能统称为 878 次成功编译。
2. 两种 seed 下共 1,756 组字典根 baseline / guarded 返回记录完全相同，包含输出内容、`ordered_ids`、单独记录的 `out_key_insertion_order`、compiler 调用记录、错误类别 / 消息、状态标记及循环 identity。
3. 八个非 dict case 确为四种根 `None`、`[]`、`0`、`'invalid'`，每种重复两次。两 seed 合计 16 条 guarded 记录均明确 `TypeError('elistra_redirect_invalid_cards_root')`，compiler 调用为零，循环 identity 未绑定，局部 out 内容 / 插入顺序与 ordered_ids 均保留。
4. seeded 的八条旧 hook 记录均已移除首目标 BGS_205，保留金色目标与无关项；guarded 保留进入片段时的全部状态。empty seed 的旧 pop 因目标不存在没有实际删除，不应混称 16 次实际删除均被回滚。
5. empty seed 的 886 条 baseline 输出及错误与历史报告逐条相同。
6. 十项补充控制中，普通 dict 子类与 baseline 完全相同；mappingproxy 的旧 hook 调用 compiler 两次，删除两项目标并静默继续，新守卫明确拒绝；坏 `.get()` dict 子类仍保留原 `RuntimeError('controlled_bad_get')` 及首目标已删的行为，没有掩盖或修复其它错误。
7. 4 份本地 proof fixture 当前字节与既有 pin 相符。

这里的调用轨迹指 `compile_proxy` 所记录的 compiler 调用，不是全面外部工具调用或所有 Python 操作跟踪。

## 顺序核对的终版改进

初版使用 `frozen(sort_keys=True)` 去重输出，单独只能证明内容相等及 `ordered_ids` 相等，不能独立证明 out 字典插入顺序。父任务已在终版 `run` 直接保存 `list(ns['out'])`，并让 `a == b` 比较包含该字段。本次对终版逐条核对了字段存在、键成员及 baseline / guarded 一致性；无效根还独立比对进入片段时的插入顺序。此处初版的证据缺口已在终版补齐。

## 计数与便携复核边界

- 主矩阵：886 case × 2 seed × 2 版本 = 3,544 次片段执行。
- 补充控制：10 × 2 版本 = 20 次。
- 每轮合计 3,564 次，不把控制混入 886 个历史 case。
- 终版便携目录的 18 项输入逐文件尺寸和 SHA-256 与主目录白名单相同；`PROBE_RESULT.json`、`VERIFIED_RESULTS.json` 的记录在仅排除 `max_rss_kib` 后相同。本复核读取的是父任务的两轮记录，没有第三次运行目标脚本。

这是局部 fail-fast 证据。八个原异常 case 被提前拒绝，不是转成编译成功；不回滚 driver 前序副作用，不承诺整个 driver 原子性，不证明安装、生成 catalog 或游戏运行验收通过。守卫仍接受 dict 子类，后续 `.get()`、compiler 或 emit 失败时仍可能出现既有部分状态。

## 交付白名单

最新 `REVIEW_MANIFEST.json` 列出本目录全部九项白名单：原五项静态成果、三项补充成果与 manifest 本身。manifest 对八项 payload 保存尺寸及 SHA-256，自身不做递归 hash；其外部 SHA-256 随最终报告提供。没有把父探针或完整 driver 复制进本目录。
