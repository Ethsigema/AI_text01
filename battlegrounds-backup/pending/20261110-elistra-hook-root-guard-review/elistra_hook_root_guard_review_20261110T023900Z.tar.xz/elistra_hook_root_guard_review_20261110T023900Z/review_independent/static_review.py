import ast
import hashlib
import json
import pathlib
import resource

resource.setrlimit(resource.RLIMIT_AS, (128 * 1024 * 1024, 128 * 1024 * 1024))
BASE = pathlib.Path('/workspace/scratch/dd4f12b08ec0')
HERE = pathlib.Path(__file__).resolve().parent
DRIVER = BASE / 'historical_tools_batch14_20261109T191857Z/runtime/research/elistra_redirect_native_recovery/candidates/tools/build_effect_catalog.py'
MODULE = BASE / 'elistra_redirect_correction_review_20261110T021700Z/candidate/tools/elistra_redirect_patterns.py'
PINS = {
    DRIVER: '260f3d719d16e0ccc5c3c8527427a0b3e44e0ca69c61b9a6efad2f393c511ebc',
    MODULE: '5117ad6bf7e755be6063d3538aa541e6633ca1091e163e247a5427a06c74e2ab',
}
checks = []
def check(condition, label):
    assert condition, label
    checks.append(label)
for path, digest in PINS.items():
    check(hashlib.sha256(path.read_bytes()).hexdigest() == digest, f'input pin: {path.relative_to(BASE)}')
text = DRIVER.read_text()
root = ast.parse(text, filename=str(DRIVER))
module = ast.parse(MODULE.read_text(), filename=str(MODULE))
loops = [node for node in root.body if isinstance(node, ast.For) and isinstance(node.iter, ast.Name) and node.iter.id == 'ELISTRA_REDIRECT_IDS']
check(len(loops) == 1, 'one top-level Elistra loop')
loop = loops[0]
check((loop.lineno, loop.end_lineno) == (3275, 3281), 'exact loop line span')
index = root.body.index(loop)
following = root.body[index + 1:index + 3]
check(isinstance(following[0], ast.Assign) and following[0].lineno == 3282, 'ordering list reassignment follows loop')
check(isinstance(following[1], ast.Expr) and following[1].lineno == 3283, 'ordering extend follows reassignment')
check(ast.unparse(loop.body[0]) == 'out.pop(identity, None)', 'out.pop is first loop operation')
check(ast.unparse(loop.body[1]) == 'c = cards.get(identity)', 'cards.get follows first removal')
check(ast.unparse(loop.body[2]) == 'compiled = compile_elistra_redirect(c, cards, root=R)', 'compiler runs only after root lookup')
card_binds = [node for node in ast.walk(root) if isinstance(node, ast.Name) and isinstance(node.ctx, (ast.Store, ast.Del)) and node.id == 'cards']
check(len(card_binds) == 1 and card_binds[0].lineno == 531, 'sole direct cards write is at line 531')
assignment = next(node for node in root.body if isinstance(node, ast.Assign) and node.lineno == 531)
check(isinstance(assignment.value, ast.DictComp), 'actual cards root constructed by dict comprehension')
check(not any(isinstance(node, ast.ImportFrom) and any(alias.name == '*' for alias in node.names) for node in ast.walk(root)), 'no wildcard imports in driver')
for builtin in ('dict', 'isinstance', 'TypeError'):
    assigned = [node for node in ast.walk(root) if isinstance(node, ast.Name) and isinstance(node.ctx, (ast.Store, ast.Del)) and node.id == builtin]
    imported = [alias for node in ast.walk(root) if isinstance(node, (ast.Import, ast.ImportFrom)) for alias in node.names if (alias.asname or alias.name.split('.')[0]) == builtin]
    check(not assigned and not imported, f'guard builtin not directly overwritten/imported: {builtin}')
    named_binders = [node for node in ast.walk(root) if getattr(node, 'lineno', 0) < loop.lineno and ((isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef, ast.ExceptHandler, ast.MatchAs, ast.MatchStar)) and getattr(node, 'name', None) == builtin) or (isinstance(node, ast.MatchMapping) and node.rest == builtin))]
    check(not named_binders, f'guard builtin has no definition/exception/pattern binding before hook: {builtin}')
source_id_node = next(node for node in module.body if isinstance(node, ast.Assign) and any(isinstance(target, ast.Name) and target.id == 'SOURCE_IDS' for target in node.targets))
ids = ast.literal_eval(source_id_node.value)
check(ids == ('BGS_205', 'TB_BaconUps_306'), 'normal/golden source tuple order pinned')
compiler = next(node for node in module.body if isinstance(node, ast.FunctionDef) and node.name == 'compile_card')
check(isinstance(compiler.body[0], ast.If) and 'not isinstance(cards, dict)' in ast.unparse(compiler.body[0].test), 'candidate already excludes non-dict cards root')
original = '\n'.join(text.splitlines()[3273:3283]) + '\n'
guard = "if not isinstance(cards,dict): raise TypeError('elistra_redirect_invalid_cards_root')\n"
proposed = original.replace('for identity in ELISTRA_REDIRECT_IDS:\n', guard + 'for identity in ELISTRA_REDIRECT_IDS:\n', 1)
original_ast = ast.parse(original)
proposed_ast = ast.parse(proposed)
check(len(original_ast.body) == 3 and len(proposed_ast.body) == 4, 'guard adds exactly one top-level AST statement')
check(ast.dump(original_ast, include_attributes=False) == ast.dump(ast.Module(body=proposed_ast.body[1:], type_ignores=[]), include_attributes=False), 'original loop and ordering AST retained exactly')
check(isinstance(proposed_ast.body[0], ast.If) and isinstance(proposed_ast.body[0].body[0], ast.Raise), 'new statement explicitly raises before loop')
# Do not execute either historical source, the compiler, or these hook fragments.
# Exercise only an independent two-line contract function with no side effects.
def require_dict(cards):
    if not isinstance(cards, dict):
        raise TypeError('elistra_redirect_invalid_cards_root')
    return cards
for label, value in [('None', None), ('[]', []), ('0', 0), ("'invalid'", 'invalid')]:
    try:
        require_dict(value)
    except TypeError as exc:
        check(str(exc) == 'elistra_redirect_invalid_cards_root', f'explicit rejection: {label}')
    else:
        raise AssertionError(f'missing rejection: {label}')
for label, value in [('empty dict', {}), ('validly typed malformed row dict', {'BGS_205': None}), ('ordinary dict', {'x': {'id': 'x'}})]:
    check(require_dict(value) is value, f'dict identity preserved: {label}')
class OrdinaryDictSubclass(dict):
    pass
value = OrdinaryDictSubclass()
check(require_dict(value) is value, 'dict subclass remains accepted')
(HERE / 'original_hook.txt').write_text(original)
(HERE / 'proposed_guarded_hook.txt').write_text(proposed)
result = {
    'scope': 'static AST inspection plus standalone guard contract assertions only; no driver/module/hook execution',
    'memory_limit_bytes': 128 * 1024 * 1024,
    'checks_passed': len(checks),
    'checks': checks,
    'input_sha256': {str(path.relative_to(BASE)): digest for path, digest in PINS.items()},
    'original_hook_sha256': hashlib.sha256(original.encode()).hexdigest(),
    'proposed_guarded_hook_sha256': hashlib.sha256(proposed.encode()).hexdigest(),
    'source_ids': list(ids),
    'original_loop_lines': [loop.lineno, loop.end_lineno],
    'original_ordering_lines': [3282, 3283],
}
(HERE / 'static_result.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, ensure_ascii=False, indent=2))
