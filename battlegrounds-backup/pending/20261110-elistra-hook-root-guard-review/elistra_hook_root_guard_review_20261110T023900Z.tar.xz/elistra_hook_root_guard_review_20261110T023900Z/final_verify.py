from pathlib import Path
import hashlib,json,resource
resource.setrlimit(resource.RLIMIT_AS,(128*1024**2,128*1024**2))
H=Path(__file__).resolve().parent;W=H.parent;R=W/'historical_tools_batch14_20261109T191857Z/runtime';P=W/'elistra_redirect_correction_review_20261110T021700Z'
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for data in iter(lambda:f.read(1024*1024),b''):h.update(data)
 return h.hexdigest()
def check(p,pin):
 p=p.resolve();assert p.is_relative_to(W.resolve());assert p.stat().st_size==pin['bytes'] and sha(p)==pin['sha256'],str(p)
inputs=json.loads((H/'INPUT_PINS.json').read_text())
for rel,pin in inputs.items():check(W/rel,pin);check(H/'inputs'/Path(*Path(rel).parts[1:]),pin)
review=json.loads((H/'review_independent/PROBE_READONLY_AUDIT.json').read_text())['input_pins']
for rel,pin in review.items():check(W/rel,pin)
old=json.loads((P/'FINAL_VERIFICATION.json').read_text())['old_archives'];old[P.name+'.tar.xz']='0d743ad1e5c15305adccf46032276ab59dc09fb034d6ca3bc2525a6555c2da5f'
for rel,digest in old.items():assert sha(W/rel)==digest
boundary={'core/catalog.gd':'5ba81a78d4924e4596dada5cb8f1a9ad5877d7bed6c7d350ca370d8bff955a72','core/game.gd':'84ea17caff1c22d082badf6118f8fdde02e35616d4d156b28430b02313504410','core/elistra_redirect_sources.gd':'1ba1f47dcf21e814476fd634bf143a0e36eede3956399fb78ee377e86ca4199d','research/elistra_redirect_native_recovery/candidates/tools/build_effect_catalog.py':'260f3d719d16e0ccc5c3c8527427a0b3e44e0ca69c61b9a6efad2f393c511ebc'}
for rel,digest in boundary.items():assert sha(R/rel)==digest
assert sha(R.parent/'SOURCE_MAP.json')=='7fec8d69e82de8bfcb7373549951f9456671b5c3980135d6ec6f983a3daf5ed7'
replay=json.loads((H/'REPLAY_INPUTS.json').read_text())
for rel,pin in replay.items():check(H/rel,pin)
scope=json.loads((W/'historical_tools_batch15_20261109T195018Z/REMAINING_SCOPE.json').read_text())['remaining_targets'];assert len(scope)==345 and all(not (R/rel).exists() for rel in scope)
assert not (R/'evidence/portable_legacy/CardDefs.Bacon_latest.xml').exists()
assert sha(P/'candidate/tools/elistra_redirect_patterns.py')=='5117ad6bf7e755be6063d3538aa541e6633ca1091e163e247a5427a06c74e2ab'
result={'status':'SELECTED_INPUTS_RUNTIME_BOUNDARIES_AND_OLD_ARCHIVES_UNCHANGED','independent_review_input_records':len(review),'input_records':len(inputs),'replay_inputs':len(replay),'runtime_boundary_files':boundary,'old_archives':old,'remaining_missing':345,'XML_not_installed':True,'proposal_not_installed':True,'complete_modified_driver_not_created':True,'full_tree_rehash_claim':False,'full_driver_game_combat_catalog_godot_save_run':False,'network_used':False,'max_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
(H/'FINAL_VERIFICATION.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
