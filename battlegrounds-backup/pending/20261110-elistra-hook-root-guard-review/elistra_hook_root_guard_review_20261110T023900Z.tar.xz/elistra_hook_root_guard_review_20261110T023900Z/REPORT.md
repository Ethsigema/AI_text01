# 艾丽斯特拉历史 hook 根类型守卫：只读调查

## 结论

八项异常均能在这个局部片段内改为一致、提前、可识别的拒绝，避免先删掉首项旧输出才异常。它们仍是编译失败，不是把坏输入变成成功结果。

八个case实际只有四种根值：None、空list、整数0、字符串invalid，各在两个来源标签下重复一次。原hook固定先访问BGS_205，不因为case标签是金色就先处理金色；八项均在调用compile_card之前失败。

建议在原历史driver第3274行注释之后、第3275行for之前增加：

    if not isinstance(cards,dict):
     raise TypeError('elistra_redirect_invalid_cards_root')

本轮只保存独立提议片段和精确上下文hunk，没有生成完整修改版driver，没有应用补丁或安装任何文件。不把局部拒绝行为称为完整驱动、Game或存档验收。

## 为什么放在循环之前

原代码每次先out.pop(identity,None)，再cards.get(identity)。非字典根在第一次get抛AttributeError，此时第一个旧target可能已经删除；ordered_ids还没更新，工具函数也未调用。

守卫在for之前抛明确TypeError，片段中的out、其key插入顺序、ordered_ids和编译器调用都未开始变化。保留旧out只是失败时不进一步破坏本段状态，不能把它当作可发布结果。完整驱动前序阶段可能已发生的修改不回滚，也没有声称整体事务性或原子性。

历史driver第531行通过字典推导式生成cards，已保存工具候选本来也要求isinstance(cards,dict)。独立静态审查没有发现dict、isinstance、TypeError在该源码中的赋值、for目标、导入绑定等遮蔽，也没有import *。这支持此固定版本的局部守卫，不代替未知依赖或整条运行过程验证。

## 精确来源及未改变部分

- 历史driver SHA256：260f3d719d16e0ccc5c3c8527427a0b3e44e0ca69c61b9a6efad2f393c511ebc。
- 本次调用的是已有独立工具候选，SHA256：5117ad6bf7e755be6063d3538aa541e6633ca1091e163e247a5427a06c74e2ab。没有继续修改该候选。
- 原emit（559行）、Elistra for（3275–3281行）及两条ordered_ids语句（3282–3283行）按原文提取。提议只在其中新增一个if，原四节点AST不变。
- 提议片段SHA256：0080f09b652a29e9c050254e5b5c925824095bda51f39b0075f7c995334321be。
- 精确hunk SHA256：cd2b42cda6dd9488721967ed67818f47e11228d424267be6a40fc36a974ae7af。

hunk仅针对这个历史driver的已核对上下文；当前正式driver仍缺失，不能把它直接当成当前安装补丁。旧工具原件、原patch两处XML头粘连、新工具候选及旧备份全部保留不改。

## 正反例结果

沿用上轮886项样例，以未加守卫和加守卫两份片段分别运行。每项测试空out、已有两个旧target及无关项两种状态：

- 878项字典根 × 两状态 = 1756组，输出内容、out字典key插入顺序、ordered_ids、编译器调用轨迹、错误/消息及记录的状态完全一致。
- 这里包括规范双行、等值数值等正例，也包括内容不合法或proof不匹配的字典根。不能把878项全部说成合法卡牌；结论是这些字典路径的原有接受/拒绝行为未变。
- 八项非字典根 × 两状态 = 16次均抛TypeError，消息固定为elistra_redirect_invalid_cards_root，编译器调用次数为0。
- 已有out的八次反例中，原片段先删掉BGS_205、保留金色旧项再异常；守卫片段保持本段状态未变并明确失败。
- 空out情况下原片段的pop无实际删除，但仍把循环identity绑定到BGS_205后才失败；提前守卫连这个步骤也未执行。
- 原886项未守卫片段的输出/异常逐项与上轮封存结果一致。

每轮矩阵有1772组对比，即3544次片段执行；另10项控制共20次，合计3564次片段执行。样例编号不是穷尽输入空间证明。

额外控制包括规范dict、空dict、普通dict子类、mappingproxy、bool/float/tuple/bytes及故意get失败的dict子类：

- 普通dict子类保留原行为，没有误用type(cards) is dict将它排除。
- mappingproxy不是dict。原hook会调用工具，工具拒绝后删掉两个旧target并继续；新守卫提前抛TypeError。这是对非dict根明确收紧，不是“所有旧非dict行为都相同”。与实际字典构造及工具输入契约一致，但真实流程兼容仍未验证。
- 带故意失败get方法的dict子类仍抛原RuntimeError，仍可能发生原有首项pop。守卫只解决根类型，不包围吞掉其他异常，也不宣称任意Python对象都安全。

## 为什么不直接静默继续

把get改成“不是dict就None”可能使两项旧输出都被删掉后继续，以缺失输出掩盖错误根；跳过整个循环可能保留尚未复核的旧输出。二者都不能仅凭“不再抛AttributeError”认定安全整合。

在完整驱动未闭合时，明确抛错比假装空输入继续更符合当前校验边界。上层仍必须尊重失败，不能捕获后拿保留下来的out当成功产物。没有替完整驱动决定新的恢复策略。

## 重放、独立审查和保护范围

初版探针比较ordered_ids但未单列out字典插入顺序。独立审查指出这一计数/顺序口径后，终版增加out_key_insertion_order字段并重跑；初版脚本、结果和清单保存在initial_probe_before_order_check，未删除。

终版以18个白名单输入建立全新便携目录，再次执行探针和核验。两份完整结果仅排除实测RSS峰值后相同，输入hash未变。Python均限制128MiB，探针峰值约19MiB，单轮约3秒；没有启动Godot、Game、Combat、完整Catalog或完整driver。

只对独立fixture变更文件并最终回读恢复；没有触碰取消的下载、网络、旧存档、私聊、凭据或缓存。当前正式工具/driver未安装，345项缺口与XML未安装边界不变。

独立审查完成31项静态/守卫断言与21465项逐记录、引用、计数及pin检查，核对终版out插入顺序及便携重放。这些是审查断言数，不是新增case或新增运行次数；审查没有执行目标探针。

原件、46项独立审查输入、来源输入和14份旧归档在末尾复核保持原值。不是全树重新验收，也不解决四份全局原核验证据及两份全局合同缺口。

## 交付物

PROPOSED_GUARDED_FRAGMENT.py与PROPOSED_LOCAL_GUARD.patch是待审局部提议；ORIGINAL_FOUR_NODES.py保留原片段。PROBE_RESULT.json包含逐样例记录，VERIFIED_RESULTS.json汇总关键断言。review_independent保留独立审查，REPLAY_INPUTS.json/replay_to_new.py只向新目录重放。

结论维持：可封存此局部提前拒绝方案，当前不安装。需要完整、同版本驱动及依赖后，才能讨论上层错误报告和整合流程；不推断真实Game可达性。
