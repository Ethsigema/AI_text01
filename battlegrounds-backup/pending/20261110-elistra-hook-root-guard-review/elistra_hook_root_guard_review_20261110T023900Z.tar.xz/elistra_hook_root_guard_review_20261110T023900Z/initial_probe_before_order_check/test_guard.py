from pathlib import Path
from copy import deepcopy
import collections,hashlib,json,resource,sys,types
resource.setrlimit(resource.RLIMIT_AS,(128*1024**2,128*1024**2));sys.dont_write_bytecode=True
H=Path(__file__).resolve().parent;I=H/'inputs';R=H/'fixture_root';F='research/elistra_redirect_native_recovery/'
sys.path.insert(0,str(I));from mutations import mutate,frozen
p=I/'candidate/tools/elistra_redirect_patterns.py';assert hashlib.sha256(p.read_bytes()).hexdigest()=='5117ad6bf7e755be6063d3538aa541e6633ca1091e163e247a5427a06c74e2ab'
m=types.ModuleType('unchanged_tool_candidate');m.__file__=str(p);exec(compile(p.read_text(),str(p),'exec'),m.__dict__)
RAW=json.loads((I/'GD_CONSTANTS.json').read_text())['RAW'];IDS=m.SOURCE_IDS;fixtures={path:(I/'fixture_root'/path).read_bytes() for path in m.PROOF_SHA256}
for path in fixtures:(R/path).parent.mkdir(parents=True,exist_ok=True)
def reset():
 for path,b in fixtures.items():
  p=R/path
  if p.is_dir():p.rmdir()
  p.write_bytes(b)
def setup(case):
 reset();identity=case['identity'];cards=deepcopy(RAW);regime=case['regime'];rows=deepcopy(RAW)
 if regime=='detached':pass # Exact hook never receives the detached direct-call parameter.
 elif regime=='coupled':cards[identity]=mutate(cards[identity],case)
 elif regime=='companion':
  target=next(i for i in IDS if i!=identity);cards[target]=mutate(cards[target],case)
 elif regime=='mapping_root':cards=mutate(cards,case)
 elif regime in ['coherent_raw_file','raw_file_only']:
  rows[identity]=mutate(rows[identity],case);(R/F/'raw_rows.json').write_text(json.dumps(rows,ensure_ascii=False))
  if regime=='coherent_raw_file':cards=deepcopy(rows)
 elif regime=='bad_raw_file':
  op=case['op'];p=R/F/'raw_rows.json'
  if op=='missing_raw':p.unlink()
  elif op=='malformed_json':p.write_text('{')
  elif op=='null_json':p.write_text('null')
  elif op=='list_json':p.write_text('[]')
  elif op=='raw_whitespace':p.write_bytes(p.read_bytes()+b'\n')
  elif op=='raw_json_equivalent':p.write_text(json.dumps(rows,ensure_ascii=False,separators=(',',':')))
  elif op=='raw_directory':p.unlink();p.mkdir()
  else:
   if op=='missing_identity':del rows[identity]
   elif op=='nonrow_identity':rows[identity]=None
   elif op=='array_member':rows[identity]=[]
   p.write_text(json.dumps(rows))
 elif regime=='bad_proof':
  p=R/case['proof_path']
  if case['op']=='proof_changed':p.write_bytes(p.read_bytes()+b'\n')
  else:p.unlink()
 else:raise AssertionError(regime)
 return cards
codes={n:compile((H/f).read_text(),n,'exec') for n,f in [('baseline_hook','ORIGINAL_FOUR_NODES.py'),('guarded_hook','PROPOSED_GUARDED_FRAGMENT.py')]}
output_pool=[];indexes={}
def intern(value):
 key=frozen(value)
 if key not in indexes:indexes[key]=len(output_pool);output_pool.append(deepcopy(value))
 return indexes[key]
def run(name,cards,seed):
 out={} if seed=='empty' else {IDS[0]:{'prior_source':IDS[0]},IDS[1]:{'prior_source':IDS[1]},'unrelated':{'keep':['exact']}}
 ordered=['unrelated',*reversed(IDS)];before=frozen([out,ordered]);unrelated=out.get('unrelated');calls=[]
 ns={'cards':cards,'out':out,'ordered_ids':ordered,'ELISTRA_REDIRECT_IDS':IDS,'hashlib':hashlib,'R':R}
 def compile_proxy(card,mapping,root):
  calls.append({'key':ns['identity'],'row_id':card.get('id') if isinstance(card,dict) else None,'same_mapping_value':isinstance(mapping,dict) and card is mapping.get(ns['identity'])})
  return m.compile_card(card,mapping,root=root)
 ns['compile_elistra_redirect']=compile_proxy
 error=None;message=None
 try:exec(codes[name],ns)
 except Exception as e:error=type(e).__name__;message=str(e)
 assert out.get('unrelated') is unrelated
 return {'error':error,'message':message,'out_index':intern(ns['out']),'ordered_ids':ns['ordered_ids'],'calls':calls,'state_unchanged':frozen([ns['out'],ns['ordered_ids']])==before,'identity_bound':ns.get('identity')},ns['out']
cases=json.loads((I/'CASES.json').read_text());prior=json.loads((I/'PYTHON_REPORT.json').read_text());results=[];counts=collections.Counter()
for index,case in enumerate(cases):
 cards=setup(case);before=frozen(cards);entry={'label':case['label'],'regime':case['regime'],'cards_is_dict':isinstance(cards,dict),'root_type':type(cards).__name__,'seeds':{}}
 for seed in ['empty','seeded']:
  a,aout=run('baseline_hook',cards,seed);b,bout=run('guarded_hook',cards,seed);assert frozen(cards)==before
  if isinstance(cards,dict):
   assert a==b,(case['label'],seed);counts['dict_state_and_trace_equal']+=1
  else:
   assert a['error']=='AttributeError' and not a['calls']
   assert b['error']=='TypeError' and b['message']=='elistra_redirect_invalid_cards_root' and not b['calls'] and b['state_unchanged'] and b['identity_bound'] is None
   if seed=='seeded':assert IDS[0] not in aout and IDS[1] in aout and IDS[0] in bout and IDS[1] in bout and not a['state_unchanged'];counts['partial_pop_avoided_seeded']+=1
   counts['explicit_root_rejections']+=1
  if seed=='empty':
   old=prior['results'][index]['versions']['candidate'];assert old['hook_error']==a['error'];assert sorted(aout)==old['hook_accepted_ids'];assert frozen(aout)==frozen(prior['hook_output_pool'][old['hook_outputs_index']]);assert all(c['same_mapping_value'] for c in a['calls'])
  entry['seeds'][seed]={'baseline':a,'guarded':b,'equivalent_for_dict_root':isinstance(cards,dict) and a==b}
 results.append(entry)
reset()
# Supplementary local root-domain controls. No full driver, no external side effects.
class PlainDict(dict):pass
class BadGetDict(dict):
 def get(self,*args):raise RuntimeError('controlled_bad_get')
controls=[('canonical_dict',lambda:deepcopy(RAW)),('empty_dict',dict),('ordinary_dict_subclass',lambda:PlainDict(deepcopy(RAW))),('mapping_proxy_not_dict',lambda:types.MappingProxyType(deepcopy(RAW))),('true',lambda:True),('false',lambda:False),('float',lambda:1.0),('tuple',tuple),('bytes',lambda:b'x'),('dict_bad_get',lambda:BadGetDict(deepcopy(RAW)))]
extra=[]
for label,factory in controls:
 cards=factory();a,_=run('baseline_hook',cards,'seeded');b,_=run('guarded_hook',cards,'seeded')
 if isinstance(cards,dict):assert a==b
 else:assert b['error']=='TypeError' and b['state_unchanged'] and not b['calls']
 if label=='mapping_proxy_not_dict':assert a['error'] is None and not a['state_unchanged'] and len(a['calls'])==2
 if label=='dict_bad_get':assert b['error']=='RuntimeError' and not b['state_unchanged']
 extra.append({'label':label,'is_dict':isinstance(cards,dict),'baseline':a,'guarded':b})
for path,b in fixtures.items():assert (R/path).read_bytes()==b
summary={'status':'LOCAL_FAIL_FAST_ROOT_GUARD_EVIDENCE_NOT_DRIVER_ACCEPTANCE','cases':len(results),'unique_invalid_roots':['NoneType','list','int','str'],'legacy_exception_cases':8,'dict_root_cases':sum(x['cards_is_dict'] for x in results),'comparisons':len(results)*2,'hook_fragment_executions':len(results)*4,'counts':dict(counts),'legacy886_baseline_hook_outputs_and_errors_identical':True,'seed_names':['empty','seeded'],'all_dict_root_output_order_call_trace_and_error_behavior_identical':True,'guarded_errors_remain_explicit_not_compile_success':True,'invalid_root_tool_calls':0,'snapshot_fixtures_restored':True,'results':results,'extra_controls':extra,'output_pool':output_pool,'max_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
(H/'PROBE_RESULT.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:v for k,v in summary.items() if k not in ['results','extra_controls','output_pool']},indent=2))
