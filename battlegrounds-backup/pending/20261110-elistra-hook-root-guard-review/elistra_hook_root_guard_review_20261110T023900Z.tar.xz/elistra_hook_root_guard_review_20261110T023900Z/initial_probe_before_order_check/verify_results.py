from pathlib import Path
import ast,hashlib,json,resource
resource.setrlimit(resource.RLIMIT_AS,(128*1024**2,128*1024**2))
H=Path(__file__).resolve().parent;I=H/'inputs';F='research/elistra_redirect_native_recovery/'
r=json.loads((H/'PROBE_RESULT.json').read_text());assert len(r['results'])==r['cases']==886
assert r['dict_root_cases']==878 and r['counts']=={'dict_state_and_trace_equal':1756,'explicit_root_rejections':16,'partial_pop_avoided_seeded':8}
assert r['comparisons']==1772 and r['hook_fragment_executions']==3544 and len(r['extra_controls'])==10
for row in r['results']:
 for seed,pair in row['seeds'].items():
  a,b=pair['baseline'],pair['guarded']
  if row['cards_is_dict']:assert a==b and pair['equivalent_for_dict_root']
  else:
   assert a['error']=='AttributeError' and b['error']=='TypeError' and b['message']=='elistra_redirect_invalid_cards_root'
   assert not a['calls'] and not b['calls'] and b['state_unchanged'] and b['identity_bound'] is None
   assert row['root_type'] in r['unique_invalid_roots']
assert sum(not x['cards_is_dict'] for x in r['results'])==8
assert all(x['guarded']['error']=='TypeError' and x['guarded']['state_unchanged'] for x in r['extra_controls'] if not x['is_dict'])
for rel,pin in json.loads((H/'INPUT_PINS.json').read_text()).items():
 p=I/Path(*Path(rel).parts[1:]);b=p.read_bytes();assert len(b)==pin['bytes'] and hashlib.sha256(b).hexdigest()==pin['sha256']
meta=json.loads((H/'PROPOSAL_MANIFEST.json').read_text());source=(I/'prior_snapshot/original_inputs'/F/'candidates/tools/build_effect_catalog.py').read_text();assert hashlib.sha256(source.encode()).hexdigest()==meta['historical_driver_sha256']
a=ast.parse((H/'ORIGINAL_FOUR_NODES.py').read_text());b=ast.parse((H/'PROPOSED_GUARDED_FRAGMENT.py').read_text());assert len(a.body)==4 and len(b.body)==5
assert [ast.dump(x,include_attributes=False) for x in a.body]==[ast.dump(x,include_attributes=False) for x in [b.body[0],*b.body[2:]]]
assert ast.dump(b.body[1],include_attributes=False)==ast.dump(ast.parse("if not isinstance(cards,dict):\n raise TypeError('elistra_redirect_invalid_cards_root')\n").body[0],include_attributes=False)
for rel,key in [('PROPOSED_GUARDED_FRAGMENT.py','guarded_fragment_sha256'),('PROPOSED_LOCAL_GUARD.patch','proposal_patch_sha256')]:assert hashlib.sha256((H/rel).read_bytes()).hexdigest()==meta[key]
lines=(H/'PROPOSED_LOCAL_GUARD.patch').read_text().splitlines(keepends=True)[3:];assert ''.join(x[1:] for x in lines if not x.startswith('+'))==''.join(source.splitlines(keepends=True)[3272:3278])
for p in (I/'fixture_root').rglob('*'):
 if p.is_file():assert (H/'fixture_root'/p.relative_to(I/'fixture_root')).read_bytes()==p.read_bytes()
summary={'status':'LOCAL_GUARD_PROBE_VERIFIED_EXPLICIT_REJECTION_NOT_COMPILER_SUCCESS','retained_cases':886,'ordinary_dict_root_cases':878,'dict_seeded_comparisons_identical':1756,'target_invalid_cases':8,'unique_invalid_root_types':r['unique_invalid_roots'],'root_guard_rejections_two_seeds':16,'seeded_partial_pop_prevented':8,'extra_controls':10,'arbitrary_dict_get_failure_not_hidden':True,'guard_never_invokes_compiler_on_invalid_root':True,'literal_driver_context_verified':True,'no_full_modified_driver_created':True,'no_installation':True,'no_full_driver_game_godot_save_run':True,'max_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
(H/'VERIFIED_RESULTS.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
