from pathlib import Path
import ast,hashlib,json,difflib,resource
resource.setrlimit(resource.RLIMIT_AS,(128*1024**2,128*1024**2))
H=Path(__file__).resolve().parent;W=H.parent;P=W/'elistra_redirect_correction_review_20261110T021700Z';F='research/elistra_redirect_native_recovery/'
files=['candidate/tools/elistra_redirect_patterns.py','mutations.py','CASES.json','GD_CONSTANTS.json','PYTHON_REPORT.json','CANDIDATE_MANIFEST.json','prior_snapshot/original_inputs/'+F+'candidates/tools/build_effect_catalog.py']
files += [str(p.relative_to(P)) for p in (P/'fixture_root').rglob('*') if p.is_file()]
pins={}
for rel in files:
 b=(P/rel).read_bytes();d=H/'inputs'/rel;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(b);assert d.stat().st_ino!=(P/rel).stat().st_ino;pins[str(P.relative_to(W)/rel)]={'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
source=(H/'inputs/prior_snapshot/original_inputs'/F/'candidates/tools/build_effect_catalog.py').read_text();assert hashlib.sha256(source.encode()).hexdigest()=='260f3d719d16e0ccc5c3c8527427a0b3e44e0ca69c61b9a6efad2f393c511ebc'
tree=ast.parse(source);emit=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='emit');hook=next(n for n in tree.body if isinstance(n,ast.For) and isinstance(n.iter,ast.Name) and n.iter.id=='ELISTRA_REDIRECT_IDS');pos=tree.body.index(hook);nodes=[emit,hook,*tree.body[pos+1:pos+3]]
original='\n\n'.join(ast.get_source_segment(source,n) for n in nodes)+'\n';guard="if not isinstance(cards,dict):\n raise TypeError('elistra_redirect_invalid_cards_root')\n";guarded=original.replace('for identity in ELISTRA_REDIRECT_IDS:',guard+'for identity in ELISTRA_REDIRECT_IDS:',1)
(H/'ORIGINAL_FOUR_NODES.py').write_text(original);(H/'PROPOSED_GUARDED_FRAGMENT.py').write_text(guarded)
# A proposal hunk at the exact historical insertion point, not a regenerated or installable driver.
lines=source.splitlines(keepends=True);loc=hook.lineno-1
patch='--- a/tools/build_effect_catalog.py\n+++ b/tools/build_effect_catalog.py\n@@ -3273,6 +3273,8 @@\n'+''.join(' '+x for x in lines[3272:3274])+''.join('+'+x for x in guard.splitlines(keepends=True))+''.join(' '+x for x in lines[3274:3278])
(H/'PROPOSED_LOCAL_GUARD.patch').write_text(patch)
# Verify the proposal contexts/insertions in memory without writing a complete modified driver.
patchlines=patch.splitlines(keepends=True)[3:];before=''.join(x[1:] for x in patchlines if not x.startswith('+'));after=''.join(x[1:] for x in patchlines if not x.startswith('-'))
assert before==''.join(lines[3272:3278]);assert after==''.join(lines[3272:3274])+guard+''.join(lines[3274:3278])
manifest={'status':'READONLY_INVESTIGATION_WITH_LOCAL_PROPOSED_FRAGMENT_NOT_INSTALLED_DRIVER','historical_driver_sha256':hashlib.sha256(source.encode()).hexdigest(),'tool_candidate_sha256':'5117ad6bf7e755be6063d3538aa541e6633ca1091e163e247a5427a06c74e2ab','original_nodes':[{'kind':type(n).__name__,'first':n.lineno,'last':n.end_lineno} for n in nodes],'insert_before_original_line':3275,'guarded_fragment_sha256':hashlib.sha256(guarded.encode()).hexdigest(),'proposal_patch_sha256':hashlib.sha256(patch.encode()).hexdigest(),'proposal_hunk_exact_context':True,'complete_modified_driver_created':False,'meaning':'Explicit rejection before this hook modifies state; still an exception, not compilation success.'}
(H/'INPUT_PINS.json').write_text(json.dumps(pins,indent=2)+'\n');(H/'PROPOSAL_MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps(manifest,indent=2))
