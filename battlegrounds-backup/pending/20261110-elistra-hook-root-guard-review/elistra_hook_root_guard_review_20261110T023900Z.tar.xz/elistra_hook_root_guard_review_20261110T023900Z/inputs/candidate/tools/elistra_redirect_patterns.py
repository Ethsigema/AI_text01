"""Independent complete native Elistra normal/golden, no gameplay execution."""
from pathlib import Path
from copy import deepcopy
import hashlib,json
ROOT=Path(__file__).resolve().parents[1]
SOURCE_IDS=('BGS_205', 'TB_BaconUps_306')
EXPECTED={'BGS_205': {'id': 'BGS_205', 'supported': True, 'effects': [{'type': 'before_friendly_taunt_attack_redirect', 'source_id': 'BGS_205'}], 'keywords': ['divine_shield', 'reborn'], 'coverage_rule': 'elistra_complete_native_attack_redirect_v1', 'coverage_text_sha256': '2f77dc6c3de07c85aef1788f75016133c141fd00199f9de2798d13997e0d8522', 'default_pool': False, 'pool_supported': False, 'implementation_status': 'partial_implementation_pending_unified_validation', 'conditional_support': {'rule': 'elistra_single_attack_redirect_partial_v1', 'reason': 'Independent retained build225000 BGS_205/DBF66835 and native golden TB_BaconUps_306/DBF66840; reciprocal pair, native T7 8/8 and16/16, absent COST and race, direct Divine Shield/Reborn tags, Taunt referenced only. Both complete texts independently say the same single attack replacement, without golden extra attack/repeat/charge. Existing legal initial target selection runs first; a selected friendly Taunt is replaced by the one actual active non-Taunt Elistra before the sole real declaration. The same actual physical defender continues through original attack, retaliation, pre-hit neighbours, cleave, Rally, kill attribution and after-attack pipeline, never an invented damage packet or second attack. Original and replacement UID/side/combat_id are retained in a distinct receipt. Spent Shield and Reborn use ordinary damage/death/clean-native-base handling, with fresh real summon identity; no per-combat redirect limit is invented. Exact source/program and clean native base are checked in catalog/factory/save/hand/combat/summon paths. Multiple physical redirect sources, self-Taunt and replacement-Elistra-itself-has-Taunt chains (not the required original Taunt target), source Stealth, fixed-defender/Worgen priority, relevant defender-attacked listeners and relevant Matador replacement layers remain precise pre-declaration holds, never silently filtered by card ID. Holds may follow initial RNG or existing preselection multiplication; no whole-attack rollback claimed. Native T7 owned/generated identity remains T7, ordinary pool support/defaults false. No current-rotation or official hidden ordering claim. Static-only candidate, pending unified runtime acceptance.'}}, 'TB_BaconUps_306': {'id': 'TB_BaconUps_306', 'supported': True, 'effects': [{'type': 'before_friendly_taunt_attack_redirect', 'source_id': 'TB_BaconUps_306'}], 'keywords': ['divine_shield', 'reborn'], 'coverage_rule': 'elistra_complete_native_attack_redirect_v1', 'coverage_text_sha256': '2f77dc6c3de07c85aef1788f75016133c141fd00199f9de2798d13997e0d8522', 'default_pool': False, 'pool_supported': False, 'implementation_status': 'partial_implementation_pending_unified_validation', 'conditional_support': {'rule': 'elistra_single_attack_redirect_partial_v1', 'reason': 'Independent retained build225000 BGS_205/DBF66835 and native golden TB_BaconUps_306/DBF66840; reciprocal pair, native T7 8/8 and16/16, absent COST and race, direct Divine Shield/Reborn tags, Taunt referenced only. Both complete texts independently say the same single attack replacement, without golden extra attack/repeat/charge. Existing legal initial target selection runs first; a selected friendly Taunt is replaced by the one actual active non-Taunt Elistra before the sole real declaration. The same actual physical defender continues through original attack, retaliation, pre-hit neighbours, cleave, Rally, kill attribution and after-attack pipeline, never an invented damage packet or second attack. Original and replacement UID/side/combat_id are retained in a distinct receipt. Spent Shield and Reborn use ordinary damage/death/clean-native-base handling, with fresh real summon identity; no per-combat redirect limit is invented. Exact source/program and clean native base are checked in catalog/factory/save/hand/combat/summon paths. Multiple physical redirect sources, self-Taunt and replacement-Elistra-itself-has-Taunt chains (not the required original Taunt target), source Stealth, fixed-defender/Worgen priority, relevant defender-attacked listeners and relevant Matador replacement layers remain precise pre-declaration holds, never silently filtered by card ID. Holds may follow initial RNG or existing preselection multiplication; no whole-attack rollback claimed. Native T7 owned/generated identity remains T7, ordinary pool support/defaults false. No current-rotation or official hidden ordering claim. Static-only candidate, pending unified runtime acceptance.'}}}
PROOF_SHA256={'research/elistra_redirect_native_recovery/native_source_manifest.json': '1da0b7e14824f3dbd9afd3b02840439cc78a9930ae9c0c0b085661105b50357d', 'research/elistra_redirect_native_recovery/native/BGS_205.xml': '5e6fc102b8a90b10a591773c4264756d44db2e72441796f3db04e0a15f3d2252', 'research/elistra_redirect_native_recovery/native/TB_BaconUps_306.xml': '241c5c76e32a04208bb64e04b095adc380096bf81eba3ac23b7c72b4b5ddc03e', 'research/elistra_redirect_native_recovery/raw_rows.json': 'e94544aeae79ae363083b3cee4d9cb84ccb89811a56e60edda869d755a0dea5a'}
def same(a,b):
    """Match the current GD Exact.same on the JSON-shaped source domain."""
    if type(a) in (int,float) and type(b) in (int,float): return a==b
    if type(a) is not type(b): return False
    if isinstance(a,dict):
        return len(a)==len(b) and all(key in b and same(value,b[key]) for key,value in a.items())
    if isinstance(a,list):
        return len(a)==len(b) and all(same(x,y) for x,y in zip(a,b))
    return a==b

def compile_card(card,cards,root=ROOT):
    if not isinstance(card,dict) or not isinstance(cards,dict) or type(card.get('id')) is not str or card['id'] not in SOURCE_IDS: return None
    try:
        root=Path(root)
        raw_bytes=None
        for path,digest in PROOF_SHA256.items():
            proof=root/path
            if not proof.is_file(): return None
            data=proof.read_bytes()
            if hashlib.sha256(data).hexdigest()!=digest: return None
            if path=='research/elistra_redirect_native_recovery/raw_rows.json': raw_bytes=data
        rows=json.loads(raw_bytes.decode('utf-8'))
    except (OSError,TypeError,ValueError,UnicodeError):
        return None
    if not same(card,rows[card['id']]): return None
    if any(not same(cards.get(identity),rows[identity]) for identity in SOURCE_IDS): return None
    return {k:deepcopy(v) for k,v in EXPECTED[card['id']].items() if k not in ('id','supported','coverage_text_sha256')}
