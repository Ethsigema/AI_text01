"""Restore exact runtime bytes only; does not execute Godot or grant acceptance."""
from pathlib import Path
import argparse, hashlib, json, shutil

def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def safe(root,name):
 p=Path(name)
 if p.is_absolute() or '..' in p.parts: raise ValueError('unsafe relative path: '+name)
 q=root/p
 if q.is_symlink(): raise ValueError('symlink forbidden: '+str(q))
 return q

def validate(package, baseline):
 manifest=json.loads((package/'PACKAGE_MANIFEST.json').read_text())
 for n,v in manifest['files'].items():
  p=safe(package,n)
  assert p.is_file() and sha(p)==v['sha256'] and p.stat().st_size==v['size'],n
 old=json.loads((package/'BASE_RUNTIME_MANIFEST.json').read_text())
 mapping={n:(safe(baseline,n),v['sha256']) for n,v in old['files'].items()}
 for n,(p,h) in mapping.items(): assert p.is_file() and sha(p)==h,('baseline',n)
 for layer in ['ashen','tidecaller']:
  changes=json.loads((package/layer/'DELTA_MANIFEST.json').read_text())['runtime_changes']
  for n,v in changes.items():
   safe(package,n)
   if v['change']=='new': assert n not in mapping,n
   else: assert n in mapping and mapping[n][1]==v['before_sha256'],('preimage',layer,n)
   p=safe(package/layer/'files',n)
   assert p.is_file() and sha(p)==v['after_sha256'],('delta',layer,n)
   mapping[n]=(p,v['after_sha256'])
 expected=json.loads((package/'FINAL_RUNTIME_MAP.json').read_text())
 assert {n:h for n,(_,h) in mapping.items()}==expected['files']
 return mapping

def main():
 a=argparse.ArgumentParser();a.add_argument('--baseline',type=Path,required=True);a.add_argument('--output',type=Path);o=a.parse_args()
 package=Path(__file__).resolve().parent;mapping=validate(package,o.baseline)
 if o.output:
  if o.output.exists(): raise ValueError('output must not exist')
  o.output.mkdir(parents=True)
  for n,(src,h) in sorted(mapping.items()):
   dst=safe(o.output,n);dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dst);assert sha(dst)==h
 print(json.dumps({'runtime_files_verified':len(mapping),'output':str(o.output) if o.output else None,'godot_executed':False,'gameplay_acceptance':False}))
if __name__=='__main__': main()
