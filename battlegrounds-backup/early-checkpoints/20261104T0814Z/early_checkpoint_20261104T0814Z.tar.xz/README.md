# Ashen and Tidecaller early source checkpoint

This is a small recoverable development checkpoint, not a playable release or fresh Godot acceptance. It contains new reconstructed Ashen and Shamanic Tidecaller 37.0.2 source layers and authenticated native/official references. No new engine run, compilation, gameplay, save/load or replay pass is claimed. Twilight is not included.

Dependency: restore the backed-up reciprocal Murcules source chain first. The 27,146 runtime files must exactly match BASE_RUNTIME_MANIFEST.json. The full baseline starts at commit 6fa7ee37aeea8c6af34b9d58e9b8dff312dd45ce; the latest Murcules archive SHA256 is 841e4d4cdeec1bfc6c08e2090a701fe8bc4abdfa3ea55acc7d296d1bf7cbe2fb.

Review restore_checkpoint.py before running it. Run `python3 restore_checkpoint.py --baseline /path/to/restored_murcules` to validate package hashes, baseline runtime hashes and sequential preimages without creating a runtime. Add `--output /path/to/new_nonexistent_directory` to restore source bytes into a new directory. It never overwrites an existing target and never invokes Godot. Apply Ashen before Tidecaller; never apply the Tide Catalog file directly over the older baseline.

The resulting runtime map has 27,158 files. Historical reports remain historical; current gameplay acceptance is zero until fresh tests are completed. Naga and existing exclusion/hold rules remain unchanged. Full game completion cannot be calculated from this checkpoint.

PACKAGE_MANIFEST.json covers every other member by size and SHA256. FINAL_RUNTIME_MAP.json describes the intended composed runtime. Archive readback verification and the external archive hash are separate delivery records.
