# Reconstructed Ashen 37.0.2 source candidate

This is a new bounded candidate built against the immutable restored Murcules baseline. It is not a byte-for-byte recovery of the lost Ashen candidate. No former source seal, execution fingerprint, test result, native save or acceptance is inherited.

Apply only the ten relative paths listed in DELTA_MANIFEST.json from files/ to a new copy of the exact baseline after verifying every before/after SHA-256. Never copy source_research/, review/, superseded_proposals/ or author scripts into the production project. The preserved superseded damage-room proposal is excluded from the manifest and has no application authority.

The two affected identities are BG32_873 and BG32_873_G. Native 37.0.2.256589 definitions independently establish 4/8 with temporary Tavern +1/+2 and 8/16 with +2/+4, respectively. Both retain hero-damage rewind. Official patch prose independently confirms normal Ashen values; golden values come from the native entity.

The source overlay authenticates complete raw and compiled records before numeric normalization and checks both complete merged preimages before committing either update. Only top-level attack, health, text, effects and coverage_text_sha256 are changed. Historical workbook fields, source rows, audit metadata and all support/pool/partial holds remain intact. The unchanged recruit hero-damage host already consumes the program quantities.

The Lucky Egg adapter authenticates the historical expectation file and the complete original expectation for each of the two Ashen IDs. It replaces only attack, health and effects in a private expectation copy. It does not rewrite the historical manifest, add eligible targets or establish provider gameplay acceptance.

Damage-room code is entirely unchanged. An isolated recruit hero-damage room does not necessarily activate its received-damage closure, but the mixed active received-listener domain remains subject to its pre-existing unprofiled-capability hold. No room admission rule was weakened.

Source packet: source_research/CardDefs.Bacon.37.0.2.256589.xml, SHA-256 103890e791863c743dd4b873e4cb789b711543ba839f923f677ebba6d672ff5a. Native source: https://raw.githubusercontent.com/HearthSim/hsdata/31b034c26f24b8a66ece845ffd03c1ca397b9a02/CardDefs.Bacon.xml. Official notes: https://hearthstone.blizzard.com/en-us/news/24307311/3702-patch-notes. Fresh official HTML differs from the old page hash; no match to that historical HTML is claimed.

STATIC_CHECKS.json records author static checks and Python predicate-model mutations, not GDScript execution. Independent review is recorded separately under review/. No Godot engine, recovered script, native gameplay, save/load, replay, GUI or current execution-fingerprint test was run by this reconstruction task. Native execution must use a new staging copy and fresh test evidence.
