extends RefCounted
## Reconstructed bounded source revision. No gameplay, pool or admission credit.
const IDS: Array=["BG32_873","BG32_873_G"]
const PATH: String="data/patch_3702_ashen.json"
const TARGET_PATH: String="research/lucky_egg_rebuilt/target_contracts.json"
const FILE_SHA256: Dictionary={"data/patch_3702_ashen.json":"d404d45955c9fec952e4ed6425d82e9baf61eca342c21b81ae3446b44f6a5330","research/patch_3702_ashen/BG32_873.xml":"04a4b89390c1eba61a5524b5ab863254e8584c5b3bdfd6580183b4dd46a163c8","research/patch_3702_ashen/BG32_873_G.xml":"27a6309a8ad8a75f01cfe5099bfceb89d8665f2e9530138e0b0822acc9a4b738","research/patch_3702_ashen/official_ashen_excerpt.html":"c233e798d083018fb439fa1d88d488352f85089fd3b2d379326cf430e6b8977c","research/patch_3702_ashen/source_evidence.json":"5dff78109c3149fdd5ce224c8a699bc01ca1d9aa96a98857abdabcea32822643","research/lucky_egg_rebuilt/target_contracts.json":"606972d71a69b424a44f9a3ef02669d09158e1eaa5f70822e08ae8a936405ec5"}
const RUNTIME_PATHS: Array=["core/patch_3702_ashen_sources.gd","data/patch_3702_ashen.json","research/patch_3702_ashen/BG32_873.xml","research/patch_3702_ashen/BG32_873_G.xml","research/patch_3702_ashen/official_ashen_excerpt.html","research/patch_3702_ashen/source_evidence.json","research/lucky_egg_rebuilt/target_contracts.json"]
static func proof_error() -> String:
	for path in FILE_SHA256:
		if FileAccess.get_sha256("res://"+path)!=FILE_SHA256[path]: return "partial_3702_ashen_evidence_changed:"+str(path)
	return ""
static func same(a: Variant,b: Variant) -> bool:
	if b is int or b is float:
		return (a is int or a is float) and not a is bool and is_finite(float(a)) and is_finite(float(b)) and a==b
	if typeof(a)!=typeof(b): return false
	if b is Dictionary:
		if a.size()!=b.size(): return false
		for key in b:
			if not a.has(key) or not same(a[key],b[key]): return false
		return true
	if b is Array:
		if a.size()!=b.size(): return false
		for index in range(b.size()):
			if not same(a[index],b[index]): return false
		return true
	return a==b
static func _packet() -> Dictionary:
	if FileAccess.get_sha256("res://"+PATH)!=FILE_SHA256[PATH]: return {}
	var parsed: Variant=JSON.parse_string(FileAccess.get_file_as_string("res://"+PATH))
	return parsed if parsed is Dictionary else {}
static func raw_error(card: Dictionary,path: String) -> String:
	if card.get("id") not in IDS: return ""
	var data: Dictionary=_packet()
	if data.is_empty(): return "partial_3702_ashen_packet_changed"
	var expected: Dictionary={}
	if path=="res://data/catalog_raw.json": expected=data.expected_raw[card.id]
	elif path=="res://data/catalog.json": expected=data.expected_compiled[card.id]
	else: return "partial_3702_ashen_unexpected_source:"+path
	return "" if same(card,expected) else "partial_3702_ashen_exact_old_record_changed:"+str(card.id)
static func apply_overlay(cards: Dictionary) -> String:
	var issue: String=proof_error()
	if not issue.is_empty(): return issue
	var data: Dictionary=_packet()
	if data.is_empty(): return "partial_3702_ashen_packet_changed"
	# Authenticate both complete preimages before creating or committing a write.
	for id in IDS:
		if not cards.get(id) is Dictionary or not same(cards[id],data.expected_merged[id]): return "partial_3702_ashen_exact_old_record_changed:"+id
	var prepared: Dictionary={}
	for id in IDS:
		var card: Dictionary=cards[id].duplicate(true)
		var revised: Dictionary=data.effective_fields[id]
		card.attack=int(revised.attack);card.health=int(revised.health)
		card.text=revised.text;card.coverage_text_sha256=revised.coverage_text_sha256
		card.effects=revised.effects.duplicate(true)
		for effect in card.effects:
			effect.attack=int(effect.attack);effect.health=int(effect.health)
		prepared[id]=card
	for id in IDS: cards[id]=prepared[id]
	return ""
static func lucky_egg_expectation(id: String,original: Dictionary) -> Dictionary:
	# Never rewrite the historical provider file or change the eligible domain.
	if id not in IDS: return {"ok":true,"error":"","expected":original.duplicate(true)}
	var issue: String=proof_error()
	if not issue.is_empty(): return {"ok":false,"error":issue}
	var data: Dictionary=_packet()
	if data.is_empty() or not same(original,data.expected_lucky_egg[id]): return {"ok":false,"error":"partial_3702_ashen_lucky_egg_old_expectation_changed:"+id}
	var expected: Dictionary=original.duplicate(true)
	var revised: Dictionary=data.effective_fields[id]
	expected.attack=int(revised.attack);expected.health=int(revised.health)
	expected.effects=revised.effects.duplicate(true)
	for effect in expected.effects:
		effect.attack=int(effect.attack);effect.health=int(effect.health)
	return {"ok":true,"error":"","expected":expected}
