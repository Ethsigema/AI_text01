extends RefCounted
const AshenShop=preload("res://core/ashen_turn_shop.gd")
const Underling=preload("res://core/underling_host.gd")
const Archimonde=preload("res://core/archimonde_discount_sources.gd")
const RewinderPortrait=preload("res://core/rewinder_portrait_host.gd")
const NextDiscount=preload("res://core/next_spell_discount.gd")
const ThresholdDamage = preload("res://core/threshold_damage_listeners.gd")
const AttackGains = preload("res://core/attack_gain_listeners.gd")
const Stats = preload("res://core/bulk_recruit_effects.gd")
const TYPE: String = "after_recruit_hero_damage"
const PROGRAMS: Dictionary = {"BG26_174":[{"type":"after_recruit_hero_damage","source_id":"BG26_174","event":"hero_damaged","scope":"self","tribe":"","rewind":true,"temporary":false,"attack":0,"health":2}],"BG26_174_G":[{"type":"after_recruit_hero_damage","source_id":"BG26_174_G","event":"hero_damaged","scope":"self","tribe":"","rewind":true,"temporary":false,"attack":0,"health":4}],"BG26_523":[{"type":"after_recruit_hero_damage","source_id":"BG26_523","event":"hero_damaged","scope":"all_friendly","tribe":"恶魔","rewind":false,"temporary":false,"attack":4,"health":4}],"BG26_523_G":[{"type":"after_recruit_hero_damage","source_id":"BG26_523_G","event":"hero_damaged","scope":"all_friendly","tribe":"恶魔","rewind":false,"temporary":false,"attack":8,"health":8}],"BG32_873":[{"type":"after_recruit_hero_damage","source_id":"BG32_873","event":"hero_damaged","scope":"shop","tribe":"","rewind":true,"temporary":true,"attack":1,"health":2}],"BG32_873_G":[{"type":"after_recruit_hero_damage","source_id":"BG32_873_G","event":"hero_damaged","scope":"shop","tribe":"","rewind":true,"temporary":true,"attack":2,"health":4}],"BG34_Giant_300":[{"type":"after_recruit_hero_damage","source_id":"BG34_Giant_300","event":"hero_damaged","scope":"all_friendly","tribe":"恶魔","rewind":true,"temporary":false,"attack":0,"health":1}],"BG34_Giant_300_G":[{"type":"after_recruit_hero_damage","source_id":"BG34_Giant_300_G","event":"hero_damaged","scope":"all_friendly","tribe":"恶魔","rewind":true,"temporary":false,"attack":0,"health":2}],"BG_GVG_100":[{"type":"after_recruit_hero_damage","source_id":"BG_GVG_100","event":"hero_damaged","scope":"self","tribe":"","rewind":false,"temporary":false,"attack":2,"health":2}],"TB_BaconUps_101":[{"type":"after_recruit_hero_damage","source_id":"TB_BaconUps_101","event":"hero_damaged","scope":"self","tribe":"","rewind":false,"temporary":false,"attack":4,"health":4}]}
const SOURCES: Dictionary = {"BG26_174":{"id":"BG26_174","card_code":"BG26_174","dbf_id":"100949","name":"灵魂回溯者","kind":"minion","category":"随从","tier":2,"attack":4,"health":2,"cost":null,"tribes":["恶魔"],"is_golden":false,"normal_id":null,"golden_id":"BG26_174_G","text":"在你的英雄受到伤害后，回溯该伤害并使本随从获得+2生命值。","keywords":[]},"BG26_174_G":{"id":"BG26_174_G","card_code":"BG26_174_G","dbf_id":"100950","name":"灵魂回溯者","kind":"minion","category":"随从","tier":2,"attack":8,"health":4,"cost":null,"tribes":["恶魔"],"is_golden":true,"normal_id":"BG26_174","golden_id":null,"text":"在你的英雄受到伤害后，回溯该伤害并使本随从获得+4生命值。","keywords":[]},"BG26_523":{"id":"BG26_523","card_code":"BG26_523","dbf_id":"99228","name":"提克迪奥斯","kind":"minion","category":"随从","tier":5,"attack":4,"health":4,"cost":null,"tribes":["恶魔"],"is_golden":false,"normal_id":null,"golden_id":"BG26_523_G","text":"在你的英雄受到伤害后，使你的恶魔获得+4/+4。","keywords":[]},"BG26_523_G":{"id":"BG26_523_G","card_code":"BG26_523_G","dbf_id":"99229","name":"提克迪奥斯","kind":"minion","category":"随从","tier":5,"attack":8,"health":8,"cost":null,"tribes":["恶魔"],"is_golden":true,"normal_id":"BG26_523","golden_id":null,"text":"在你的英雄受到伤害后，使你的恶魔获得+8/+8。","keywords":[]},"BG32_873":{"id":"BG32_873","card_code":"BG32_873","dbf_id":"121687","name":"灰烬腐蚀者","kind":"minion","category":"随从","tier":4,"attack":4,"health":8,"cost":null,"tribes":["恶魔"],"is_golden":false,"normal_id":null,"golden_id":"BG32_873_G","text":"在你的英雄受到伤害后，回溯该伤害并使酒馆中的随从在本回合中获得+1/+2。","keywords":[]},"BG32_873_G":{"id":"BG32_873_G","card_code":"BG32_873_G","dbf_id":"121688","name":"灰烬腐蚀者","kind":"minion","category":"随从","tier":4,"attack":8,"health":16,"cost":null,"tribes":["恶魔"],"is_golden":true,"normal_id":"BG32_873","golden_id":null,"text":"在你的英雄受到伤害后，回溯该伤害并使酒馆中的随从在本回合中获得+2/+4。","keywords":[]},"BG34_Giant_300":{"id":"BG34_Giant_300","card_code":"BG34_Giant_300","dbf_id":"127539","name":"时空扭曲回溯者","kind":"minion","category":"随从","tier":3,"attack":5,"health":4,"cost":null,"tribes":["恶魔"],"is_golden":false,"normal_id":null,"golden_id":"BG34_Giant_300_G","text":"在你的英雄受到伤害后，回溯该伤害并使你的恶魔获得+1生命值。","keywords":[]},"BG34_Giant_300_G":{"id":"BG34_Giant_300_G","card_code":"BG34_Giant_300_G","dbf_id":"127540","name":"时空扭曲回溯者","kind":"minion","category":"随从","tier":3,"attack":10,"health":8,"cost":null,"tribes":["恶魔"],"is_golden":true,"normal_id":"BG34_Giant_300","golden_id":null,"text":"在你的英雄受到伤害后，回溯该伤害并使你的恶魔获得+2生命值。","keywords":[]},"BG_GVG_100":{"id":"BG_GVG_100","card_code":"BG_GVG_100","dbf_id":"105208","name":"漂浮观察者","kind":"minion","category":"随从","tier":3,"attack":4,"health":4,"cost":null,"tribes":["恶魔"],"is_golden":false,"normal_id":null,"golden_id":"TB_BaconUps_101","text":"每当你的英雄在你的回合受到伤害，便获得+2/+2。","keywords":[]},"TB_BaconUps_101":{"id":"TB_BaconUps_101","card_code":"TB_BaconUps_101","dbf_id":"60403","name":"漂浮观察者","kind":"minion","category":"随从","tier":3,"attack":8,"health":8,"cost":null,"tribes":["恶魔"],"is_golden":true,"normal_id":"BG_GVG_100","golden_id":null,"text":"每当你的英雄在你的回合受到伤害，便获得+4/+4。","keywords":[]}}
const RUNTIME_PATHS: Array = ["core/future_shop_buff_recovery.gd","research/future_shop_buff_recovery/contract.json","core/ashen_turn_shop.gd","research/ashen_future_shop_revision/contract.json","core/hero_damage_stat_projection.gd","research/hero_damage_reactions_revision/contract.json","core/bulk_hero_damage_recruit.gd","tools/bulk_hero_damage_patterns.py","research/bulk_hero_damage_sources/raw_rows.json","research/bulk_hero_damage_sources/programs.json","research/bulk_hero_damage_sources/expected_compiled.json","research/bulk_hero_damage_sources/native_quantities.json"]

static func program_for(identity: String) -> Array:
	if Underling.Sources.accepts_id(identity): return Underling.Sources.program_for(identity)
	return Archimonde.program_for(identity) if Archimonde.accepts_id(identity) else PROGRAMS.get(identity,[])

static func claimed(unit: Dictionary) -> bool:
	if Underling.Sources.claimed(unit): return true
	if Archimonde.claimed(unit): return true
	if PROGRAMS.has(unit.get("card_id",unit.get("id",""))): return true
	for effect in unit.get("effects",[]):
		if effect is Dictionary and effect.get("type")==TYPE: return true
	return false

static func effect_error(effect: Dictionary) -> String:
	if effect.get("type")==Underling.Sources.TYPE or Underling.Sources.accepts_id(effect.get("source_id")): return Underling.Sources.effect_error(effect)
	if effect.get("type")==Archimonde.TYPE or Archimonde.accepts_id(effect.get("source_id")): return Archimonde.effect_error(effect)
	return "" if PROGRAMS.has(effect.get("source_id")) and effect==PROGRAMS[effect.source_id][0] else "bulk_hero_damage_non_native_program"

static func unit_error(unit: Dictionary) -> String:
	if Underling.Sources.claimed(unit): return Underling.Sources.unit_error(unit)
	if Archimonde.claimed(unit): return Archimonde.unit_error(unit)
	if not claimed(unit): return ""
	var id: String=str(unit.get("card_id",unit.get("id","")))
	if not PROGRAMS.has(id) or unit.get("effects")!=PROGRAMS[id]: return "bulk_hero_damage_wrong_source_program"
	if unit.get("golden",unit.get("is_golden"))!=SOURCES[id].is_golden: return "bulk_hero_damage_wrong_variant"
	if unit.get("kind","minion")!="minion": return "bulk_hero_damage_wrong_kind"
	return ""

static func source_error(card: Dictionary) -> String:
	if Underling.Sources.claimed(card): return Underling.Sources.source_error(card)
	if Archimonde.claimed(card): return Archimonde.source_error(card)
	if not SOURCES.has(card.get("id")): return "bulk_hero_damage_unknown_source"
	for key in SOURCES[card.id]:
		if card.get(key)!=SOURCES[card.id][key]: return "bulk_hero_damage_source_changed:"+str(key)
	return unit_error(card)

static func _failure(issue: String) -> Dictionary:
	return {"ok":false,"error":issue}

static func _active(source: Dictionary) -> bool:
	return source.get("kind","minion")=="minion" and source.get("health",0)>0 and not source.get("silenced",false) and not source.get("abilities_disabled",false)

static func prepare(engine, player: Dictionary, amount: int, origin: String, initial_totals: Variant=null) -> Dictionary:
	# Retained recruit minions are not live combat-result damage listeners.
	var holy_layer: bool=engine.BoardAura.HolyVanguard.player_has_source(player)
	if (origin!="recruit_effect" and not holy_layer) or amount<=0 or not player.get("alive",true): return {"ok":true,"error":"","ticket":{}}
	var underling_domain_issue: String=Underling.damage_error(engine,player,amount,origin)
	if not underling_domain_issue.is_empty(): return _failure(underling_domain_issue)
	var sources: Array=[]
	for source in player.get("board",[]):
		if origin!="recruit_effect" or not claimed(source): continue
		var issue: String=unit_error(source)
		if not issue.is_empty(): return _failure(issue)
		if Underling.Sources.claimed(source):
			if Underling.active(source): sources.append(source)
		elif _active(source): sources.append(source)
	if sources.is_empty() and not holy_layer: return {"ok":true,"error":"","ticket":{}}
	if not sources.is_empty() and engine.state.phase not in ["recruit","end_turn"]: return _failure("bulk_hero_damage_origin_phase_unimplemented")
	if not player.get("health") is int or player.health<=0 or not player.get("armor",0) is int or player.get("armor",0)<0: return _failure("bulk_hero_damage_invalid_hero_stats")
	var absorbed: int=mini(int(player.get("armor",0)),amount)
	var health_lost: int=amount-absorbed
	var rewinds: bool=false
	var has_archimonde: bool=false
	for source in sources:
		if program_for(source.card_id)[0].rewind: rewinds=true
		if Archimonde.accepts_id(source.card_id): has_archimonde=true
	if rewinds and health_lost>=int(player.health): return _failure("bulk_hero_damage_lethal_rewind_branch_unimplemented")
	var ticket: Dictionary={"owner":player,"owner_id":player.id,"used":false,"phase":engine.state.phase,"round":engine.state.round,"health_before":player.health,"armor_before":player.get("armor",0),"health_after":int(player.health)-health_lost,"armor_after":int(player.get("armor",0))-absorbed,"damage":amount,"health_lost":health_lost,"armor_lost":absorbed,"board_before":player.board.duplicate(true),"shop_before":player.shop.duplicate(true),"records":[]}
	var discount_shadow: Dictionary={}
	if has_archimonde:
		var archimonde_closure_issue: String=Archimonde.closure_error(engine.catalog)
		if not archimonde_closure_issue.is_empty(): return _failure(archimonde_closure_issue)
		var discount_state_issue: String=NextDiscount.persistent_error(player,engine.catalog,engine.state.round,engine.state.phase)
		if not discount_state_issue.is_empty(): return _failure(discount_state_issue)
		discount_shadow=player.duplicate(true)
		ticket.discount_had_before=player.has(NextDiscount.STATE_KEY)
		ticket.discount_before=player.get(NextDiscount.STATE_KEY,{}).duplicate(true)
	var ashen_issue: String=AshenShop.persistent_error(player,int(engine.state.round))
	if not ashen_issue.is_empty(): return _failure(ashen_issue)
	var ashen_shadow: Dictionary=player.duplicate(true)
	ticket.ashen_had_before=player.has(AshenShop.KEY)
	ticket.ashen_before=player.get(AshenShop.KEY,{}).duplicate(true)
	var stat_shadow: Dictionary=engine.HeroDamageStats.begin(engine,player)
	if initial_totals!=null:
		if not initial_totals is Dictionary: return _failure("hero_damage_invalid_projected_totals")
		stat_shadow.totals=initial_totals.duplicate(true)
	if holy_layer:
		ticket.holy_health_layer=true
		stat_shadow.player.health=ticket.health_after;stat_shadow.player.armor=ticket.armor_after
		var holy_packet_issue: String=engine.BoardAuraRuntime.sync_player(stat_shadow.player,engine.catalog)
		if not holy_packet_issue.is_empty(): return _failure(holy_packet_issue)
	ticket.stat_before=engine.HeroDamageStats.view(stat_shadow.player,stat_shadow.totals)
	var identities: Dictionary={}
	for unit in player.board+player.shop:
		if not unit.get("uid") is String or unit.uid.is_empty() or identities.has(unit.uid): return _failure("bulk_hero_damage_duplicate_or_missing_uid")
		identities[unit.uid]=true
	for source in sources:
		var effect: Dictionary=program_for(source.card_id)[0]
		if holy_layer and effect.rewind:
			stat_shadow.player.health=ticket.health_before;stat_shadow.player.armor=ticket.armor_before
			var holy_rewind_issue: String=engine.BoardAuraRuntime.sync_player(stat_shadow.player,engine.catalog)
			if not holy_rewind_issue.is_empty(): return _failure(holy_rewind_issue)
		if Archimonde.accepts_id(source.card_id):
			var discount_had_before: bool=discount_shadow.has(NextDiscount.STATE_KEY)
			var discount_before: Dictionary=discount_shadow.get(NextDiscount.STATE_KEY,{}).duplicate(true)
			var discount_plan: Dictionary=NextDiscount.hero_damage_plan(discount_shadow,source,engine.state.round,engine.state.phase)
			if not discount_plan.ok: return _failure(str(discount_plan.error))
			discount_shadow[NextDiscount.STATE_KEY]=discount_plan.owner_state.duplicate(true)
			ticket.records.append({"source":source,"effect":effect,"targets":[],"discount_had_before":discount_had_before,"discount_before":discount_before,"discount_after":discount_plan.owner_state.duplicate(true),"discount_sequence":discount_plan.discount_sequence,"discount_total":discount_plan.amount})
			continue
		var portrait_vector: Dictionary=Underling.vector(source,effect,amount) if Underling.Sources.claimed(source) else RewinderPortrait.vector(engine,player,source,effect)
		if not portrait_vector.ok: return _failure(str(portrait_vector.error))
		var attack: int=int(portrait_vector.attack)
		var health: int=int(portrait_vector.health)
		var targets: Array=[]
		if effect.scope=="self": targets=[source]
		elif effect.scope=="shop":
			for unit in player.shop:
				if unit.get("kind","minion")=="minion": targets.append(unit)
		else:
			for unit in player.board:
				if unit.get("health",0)>0 and engine._tribe_match(unit,str(effect.tribe)): targets.append(unit)
		var record: Dictionary={"source":source,"effect":effect,"targets":[],"attack":attack,"health":health}
		var temporary_metadata: Dictionary={}
		if source.card_id in AshenShop.IDS:
			temporary_metadata=AshenShop.tag(int(engine.state.round))
			var ledger_issue: String=AshenShop.add(ashen_shadow,int(engine.state.round),attack,health)
			if not ledger_issue.is_empty(): return _failure(ledger_issue)
		record.temporary_metadata=temporary_metadata
		for target in targets:
			var current_shadow: Dictionary=AttackGains._find(stat_shadow.player.board+stat_shadow.player.shop,str(target.uid))
			if current_shadow.is_empty(): return _failure("hero_damage_projection_target_disappeared")
			var issue: String=Stats._additive_error(engine,current_shadow,attack,health)
			if not issue.is_empty(): return _failure(issue)
			var projected: Dictionary=engine.HeroDamageStats.step(engine,stat_shadow,str(target.uid),attack,health,bool(effect.temporary),temporary_metadata)
			if not projected.ok: return _failure(str(projected.error))
			record.targets.append({"unit":target,"before":projected.before,"after":projected.after,"state_before":projected.state_before,"state_after":projected.state_after})
		ticket.records.append(record)
	ticket.ashen_after=ashen_shadow.get(AshenShop.KEY,{}).duplicate(true)
	ticket.stat_after=engine.HeroDamageStats.view(stat_shadow.player,stat_shadow.totals)
	return {"ok":true,"error":"","ticket":ticket}

static func commit(engine, player: Dictionary, ticket: Dictionary) -> String:
	if ticket.is_empty(): return ""
	if ticket.get("used",true) or not is_same(ticket.get("owner"),player) or player.id!=ticket.owner_id or engine.state.phase!=ticket.phase or engine.state.round!=ticket.round: return "bulk_hero_damage_stale_context"
	if player.health!=ticket.health_after or player.get("armor",0)!=ticket.armor_after or player.board!=ticket.board_before or player.shop!=ticket.shop_before: return "bulk_hero_damage_stale_completion"
	if player.has(AshenShop.KEY)!=ticket.ashen_had_before or player.get(AshenShop.KEY,{})!=ticket.ashen_before: return "ashen_shop_stale_ledger"
	if ticket.has("discount_before") and (player.has(NextDiscount.STATE_KEY)!=ticket.discount_had_before or player.get(NextDiscount.STATE_KEY,{})!=ticket.discount_before): return "archimonde_discount_stale_completion"
	if ticket.get("holy_health_layer",false):
		var holy_packet_issue: String=engine.BoardAuraRuntime.sync_player(player,engine.catalog)
		if not holy_packet_issue.is_empty(): return holy_packet_issue
	if not engine.HeroDamageStats.same(engine.HeroDamageStats.view(player,engine._attack_gain_health_totals),ticket.stat_before): return "hero_damage_projection_stale_zones_or_private_totals"
	ticket.used=true
	var event_id: String="hero_damage:%s:%s:%s" % [engine.state.round,player.id,engine.events.size()]
	var observed: Dictionary={"player":player.id,"event_id":event_id,"damage":ticket.damage,"health_lost":ticket.health_lost,"armor_lost":ticket.armor_lost,"health_before":ticket.health_before,"armor_before":ticket.armor_before}
	var underling_bindings: Array=[]
	for record in ticket.records:
		if Underling.Sources.claimed(record.source): underling_bindings.append({"uid":record.source.uid,"id":record.source.card_id})
	if not underling_bindings.is_empty():
		observed.underling_sources=underling_bindings
		if int(ticket.armor_before)>0: observed.underling_armor_policy=Underling.Packet.ARMOR_POLICY
	engine._log("bulk_hero_damage_observed",observed)
	for record in ticket.records:
		var source: Dictionary=record.source
		var effect: Dictionary=record.effect
		if effect.rewind:
			# Restore this one actual damage event, not additive healing per source.
			player.health=ticket.health_before;player.armor=ticket.armor_before
			if ticket.get("holy_health_layer",false):
				var holy_rewind_issue: String=engine.BoardAuraRuntime.sync_player(player,engine.catalog)
				if not holy_rewind_issue.is_empty(): return holy_rewind_issue
			engine._log("bulk_hero_damage_rewind",{"player":player.id,"event_id":event_id,"source_uid":source.uid,"source_id":source.card_id,"health":player.health,"armor":player.armor})
		if effect.type==Archimonde.TYPE:
			if player.has(NextDiscount.STATE_KEY)!=record.discount_had_before or player.get(NextDiscount.STATE_KEY,{})!=record.discount_before: return "archimonde_discount_record_changed"
			player[NextDiscount.STATE_KEY]=record.discount_after.duplicate(true)
			engine._log("bulk_hero_damage_spell_discount",{"player":player.id,"event_id":event_id,"source_uid":source.uid,"source_id":source.card_id,"amount":effect.amount,"purchases":1,"discount_sequence":record.discount_sequence,"total":record.discount_total})
			continue
		var portrait_vector: Dictionary=Underling.vector(source,effect,int(ticket.damage)) if Underling.Sources.claimed(source) else RewinderPortrait.vector(engine,player,source,effect)
		if not portrait_vector.ok: return str(portrait_vector.error)
		if portrait_vector.attack!=record.attack or portrait_vector.health!=record.health: return "rewinder_portrait_actual_damage_vector_changed"
		var attack: int=int(record.attack)
		var health: int=int(record.health)
		for target_plan in record.targets:
			if not engine.HeroDamageStats.same(engine.HeroDamageStats.view(player,engine._attack_gain_health_totals),target_plan.state_before): return "hero_damage_projection_before_step_mismatch"
			var target: Dictionary=target_plan.unit
			if target!=target_plan.before: return "bulk_hero_damage_target_changed"
			engine._buff(target,attack,health)
			if engine.state.phase=="error": return "bulk_hero_damage_buff_failed"
			if effect.temporary:
				if not target.has("temporary_buffs"): target.temporary_buffs=[]
				var grant: Dictionary={"attack":attack,"health":health,"keywords":[]}
				grant.merge(record.temporary_metadata)
				target.temporary_buffs.append(grant)
			if target!=target_plan.after: return "bulk_hero_damage_shadow_mismatch"
			if not engine.HeroDamageStats.same(engine.HeroDamageStats.view(player,engine._attack_gain_health_totals),target_plan.state_after): return "hero_damage_projection_after_step_mismatch"
			engine._log("bulk_hero_damage_buff",{"player":player.id,"event_id":event_id,"source_uid":source.uid,"source_id":source.card_id,"target_uid":target.uid,"attack":attack,"health":health,"temporary":effect.temporary})
	if not engine.HeroDamageStats.same(engine.HeroDamageStats.view(player,engine._attack_gain_health_totals),ticket.stat_after): return "hero_damage_projection_complete_group_mismatch"
	if not ticket.ashen_after.is_empty(): player[AshenShop.KEY]=ticket.ashen_after.duplicate(true)
	return ""
