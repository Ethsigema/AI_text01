from pathlib import Path
import copy, hashlib, json, re, shutil, datetime
BASE=Path('/workspace/shared/recovery_restart_20261104T0750Z/restored_murcules_project')
ROOT=Path('/workspace/shared/recovery_restart_20261104T0750Z/rebuild_ashen_candidate')
OUT=ROOT/'files'; SRC=ROOT/'source_research'; IDS=['BG32_873','BG32_873_G']
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def dumps(x):return json.dumps(x,ensure_ascii=False,separators=(',',':'))
def read(p):return json.loads(p.read_text())
def write(p,text):
 p.parent.mkdir(parents=True,exist_ok=True)
 with p.open('x',encoding='utf-8') as f:f.write(text)
def jsonwrite(p,x):write(p,json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def const(text,name):
 m=re.search(r'^const '+re.escape(name)+r'\s*:\s*\w+\s*=\s*(.*)$',text,re.M)
 assert m,name
 return json.loads(m.group(1)),m
m=read(SRC/'source_manifest.json')
assert sha(SRC/'CardDefs.Bacon.37.0.2.256589.xml')==m['native_sha256']=='103890e791863c743dd4b873e4cb789b711543ba839f923f677ebba6d672ff5a'
raw={r['id']:r for r in read(BASE/'data/catalog_raw.json')['cards'] if r['id'] in IDS}
compiled={r['id']:r for r in read(BASE/'data/catalog.json')['cards'] if r['id'] in IDS}
lucky=read(BASE/'research/lucky_egg_rebuilt/target_contracts.json')
old={i:{**raw[i],**compiled[i]} for i in IDS}; fields={}; current={}
for i in IDS:
 s=m['entities'][i]; e=copy.deepcopy(compiled[i]['effects']);e[0]['attack']=s['grant_attack'];e[0]['health']=s['grant_health']
 fields[i]={'attack':s['attack'],'health':s['health'],'text':s['text_zhCN'],'effects':e,'coverage_text_sha256':s['coverage_text_sha256']}
 current[i]={**copy.deepcopy(old[i]),**fields[i]}
packet={'schema_version':1,'revision':'partial-37.0.2-ashen-reconstructed-20261104-v1','status':'new_source_candidate_no_engine_acceptance','ids':IDS,'expected_raw':raw,'expected_compiled':compiled,'expected_merged':old,'effective_fields':fields,'expected_lucky_egg':{i:lucky['targets'][i] for i in IDS},'preserved_holds':{'supported':'unchanged','default_pool':'unchanged false','pool_supported':'unchanged','conditional_support':'unchanged','implementation_status':'unchanged','damage_room_capability_rules':'unchanged; after_recruit_hero_damage remains unprofiled'},'scope':'Two Ashen identities only. Historical source files and nested raw fields are not changed. Existing gameplay host is untouched. Source evidence is not engine acceptance.'}
jsonwrite(OUT/'data/patch_3702_ashen.json',packet)
research=OUT/'research/patch_3702_ashen'
research.mkdir(parents=True,exist_ok=True)
for i in IDS:shutil.copyfile(SRC/(i+'.native.xml'),research/(i+'.xml'))
shutil.copyfile(SRC/'official_ashen_excerpt.html',research/'official_ashen_excerpt.html')
evidence={'schema_version':1,'status':'newly_retrieved_source_evidence_only','retrieved_at_utc':m['retrieved_at_utc'],'commit':m['commit'],'version':m['version'],'native_url':m['native_url'],'native_full_sha256':m['native_sha256'],'official_url':m['official_url'],'official_full_html_sha256':m['official_html_sha256'],'official_excerpt_sha256':sha(research/'official_ashen_excerpt.html'),'entities':m['entities'],'limits':m['scope_notes']+['Full source and HTML are retained with reconstruction evidence outside the runtime delta. Only extracted exact entities and the bounded official excerpt are required at runtime.','No old source seal, fingerprint, test counts or previous acceptance is inherited.','The entire damage-room module remains unchanged; after_recruit_hero_damage remains unprofiled.']}
jsonwrite(research/'source_evidence.json',evidence)
filesha={p.relative_to(OUT).as_posix():sha(p) for p in sorted(OUT.rglob('*')) if p.is_file()}
targetpath='research/lucky_egg_rebuilt/target_contracts.json';targetsha=sha(BASE/targetpath)
filesha[targetpath]=targetsha
runtime=['core/patch_3702_ashen_sources.gd']+list(filesha)
module='''extends RefCounted
## Reconstructed bounded source revision. No gameplay, pool or admission credit.
const IDS: Array=__IDS__
const PATH: String="data/patch_3702_ashen.json"
const TARGET_PATH: String="research/lucky_egg_rebuilt/target_contracts.json"
const FILE_SHA256: Dictionary=__SHA__
const RUNTIME_PATHS: Array=__RUNTIME__
static func proof_error() -> String:
	for path in FILE_SHA256:
		if FileAccess.get_sha256("res://"+path)!=FILE_SHA256[path]: return "partial_3702_ashen_evidence_changed:"+str(path)
	return ""
static func same(a: Variant,b: Variant) -> bool:
	if b is int or b is float:
		return (a is int or a is float) and not a is bool and is_finite(float(a)) and is_finite(float(b)) and a==b
	if typeof(a)!=typeof(b): return false
	if b is Dictionary:
		if a.size()!=b.size(): return false
		for key in b:
			if not a.has(key) or not same(a[key],b[key]): return false
		return true
	if b is Array:
		if a.size()!=b.size(): return false
		for index in range(b.size()):
			if not same(a[index],b[index]): return false
		return true
	return a==b
static func _packet() -> Dictionary:
	if FileAccess.get_sha256("res://"+PATH)!=FILE_SHA256[PATH]: return {}
	var parsed: Variant=JSON.parse_string(FileAccess.get_file_as_string("res://"+PATH))
	return parsed if parsed is Dictionary else {}
static func raw_error(card: Dictionary,path: String) -> String:
	if card.get("id") not in IDS: return ""
	var data: Dictionary=_packet()
	if data.is_empty(): return "partial_3702_ashen_packet_changed"
	var expected: Dictionary={}
	if path=="res://data/catalog_raw.json": expected=data.expected_raw[card.id]
	elif path=="res://data/catalog.json": expected=data.expected_compiled[card.id]
	else: return "partial_3702_ashen_unexpected_source:"+path
	return "" if same(card,expected) else "partial_3702_ashen_exact_old_record_changed:"+str(card.id)
static func apply_overlay(cards: Dictionary) -> String:
	var issue: String=proof_error()
	if not issue.is_empty(): return issue
	var data: Dictionary=_packet()
	if data.is_empty(): return "partial_3702_ashen_packet_changed"
	# Authenticate both complete preimages before creating or committing a write.
	for id in IDS:
		if not cards.get(id) is Dictionary or not same(cards[id],data.expected_merged[id]): return "partial_3702_ashen_exact_old_record_changed:"+id
	var prepared: Dictionary={}
	for id in IDS:
		var card: Dictionary=cards[id].duplicate(true)
		var revised: Dictionary=data.effective_fields[id]
		card.attack=int(revised.attack);card.health=int(revised.health)
		card.text=revised.text;card.coverage_text_sha256=revised.coverage_text_sha256
		card.effects=revised.effects.duplicate(true)
		for effect in card.effects:
			effect.attack=int(effect.attack);effect.health=int(effect.health)
		prepared[id]=card
	for id in IDS: cards[id]=prepared[id]
	return ""
static func lucky_egg_expectation(id: String,original: Dictionary) -> Dictionary:
	# Never rewrite the historical provider file or change the eligible domain.
	if id not in IDS: return {"ok":true,"error":"","expected":original.duplicate(true)}
	var issue: String=proof_error()
	if not issue.is_empty(): return {"ok":false,"error":issue}
	var data: Dictionary=_packet()
	if data.is_empty() or not same(original,data.expected_lucky_egg[id]): return {"ok":false,"error":"partial_3702_ashen_lucky_egg_old_expectation_changed:"+id}
	var expected: Dictionary=original.duplicate(true)
	var revised: Dictionary=data.effective_fields[id]
	expected.attack=int(revised.attack);expected.health=int(revised.health)
	expected.effects=revised.effects.duplicate(true)
	for effect in expected.effects:
		effect.attack=int(effect.attack);effect.health=int(effect.health)
	return {"ok":true,"error":"","expected":expected}
'''.replace('__IDS__',dumps(IDS)).replace('__SHA__',dumps(filesha)).replace('__RUNTIME__',dumps(runtime))
write(OUT/'core/patch_3702_ashen_sources.gd',module)
# Minimal exact-reader changes. No gameplay function body is rewritten.
f='core/bulk_hero_damage_recruit.gd';text=(BASE/f).read_text()
for n in ['PROGRAMS','SOURCES']:
 d,match=const(text,n)
 for i in IDS:
  if n=='PROGRAMS':
   assert d[i]==compiled[i]['effects'];d[i]=fields[i]['effects']
  else:
   assert all(old[i][k]==v for k,v in d[i].items())
   for k in ['attack','health','text']:d[i][k]=fields[i][k]
 text=text[:match.start(1)]+dumps(d)+text[match.end(1):]
write(OUT/f,text)
f='core/dark_gift_qualification.gd';text=(BASE/f).read_text();d,match=const(text,'FACTS')
for i in IDS:
 assert d[i]['effects']==compiled[i]['effects'];d[i]['effects']=fields[i]['effects']
text=text[:match.start(1)]+dumps(d)+text[match.end(1):];write(OUT/f,text)
def canonical(v):
 if v is None:return 'n'
 if isinstance(v,bool):return 'b1' if v else 'b0'
 if isinstance(v,int):return 'i'+str(v)+';'
 if isinstance(v,str):return 's'+str(len(v))+':'+v
 if isinstance(v,list):return 'a['+''.join(map(canonical,v))+']'
 if isinstance(v,dict):return 'd{'+''.join(canonical(k)+canonical(v[k]) for k in sorted(v))+'}'
 raise TypeError(type(v))
f='core/lucky_egg_sources.gd';text=(BASE/f).read_text();text=text.replace('extends RefCounted\n','extends RefCounted\nconst Patch3702Ashen=preload("res://core/patch_3702_ashen_sources.gd")\n',1)
oldline='\t\tvar expected: Dictionary=data.targets[id]\n';assert text.count(oldline)==1
text=text.replace(oldline,oldline+'\t\tif id in Patch3702Ashen.IDS:\n\t\t\tvar adapted: Dictionary=Patch3702Ashen.lucky_egg_expectation(id,expected)\n\t\t\tif not adapted.ok: return str(adapted.error)\n\t\t\texpected=adapted.expected\n');write(OUT/f,text)
f='core/catalog.gd';text=(BASE/f).read_text();text=text.replace('extends RefCounted\n','extends RefCounted\nconst Patch3702Ashen=preload("res://core/patch_3702_ashen_sources.gd")\n',1)
mark='\tvar fingerprints: PackedStringArray = []\n';assert text.count(mark)==1
text=text.replace(mark,mark+'\tvar patch_3702_ashen_issue: String=Patch3702Ashen.proof_error()\n\tif not patch_3702_ashen_issue.is_empty():\n\t\tload_errors.append(patch_3702_ashen_issue);return\n\tfor path in Patch3702Ashen.RUNTIME_PATHS:\n\t\tfingerprints.append(path+":"+FileAccess.get_file_as_string("res://"+path).sha256_text())\n')
mark='\t\t\t\tif not raw_card is Dictionary: continue\n';assert text.count(mark)==1
text=text.replace(mark,mark+'\t\t\t\tvar patch_3702_ashen_raw_issue: String=Patch3702Ashen.raw_error(raw_card,path)\n\t\t\t\tif not patch_3702_ashen_raw_issue.is_empty():\n\t\t\t\t\tload_errors.append(patch_3702_ashen_raw_issue);return\n')
mark='\tvar fairmount_overlay_issue: String=FairmountSources.apply_overlay(cards)\n';assert text.count(mark)==1
text=text.replace(mark,'\tvar patch_3702_ashen_overlay_issue: String=Patch3702Ashen.apply_overlay(cards)\n\tif not patch_3702_ashen_overlay_issue.is_empty():\n\t\tload_errors.append(patch_3702_ashen_overlay_issue);return\n'+mark);write(OUT/f,text)
manifest={'schema_version':1,'revision':packet['revision'],'status':'new_source_delta_pending_independent_static_review','baseline':str(BASE),'output':str(OUT),'no_engine_run':True,'historical_test_credit':0,'source_refs':{'native_url':m['native_url'],'native_sha256':m['native_sha256'],'official_url':m['official_url'],'official_html_sha256':m['official_html_sha256']},'damage_room_changed':False,'runtime_changes':{},'limits':['All prior holds and all gameplay host bodies are preserved.','Two new damage-room source proofs do not provide capability admission.','Native parse, gameplay, save/load, replay, negative execution and current fingerprint remain untested.','This is a newly reconstructed candidate, not byte recovery of the lost source seal.']}
for p in sorted(OUT.rglob('*')):
 if p.is_file():
  rel=p.relative_to(OUT).as_posix();oldpath=BASE/rel
  manifest['runtime_changes'][rel]={'change':'modified' if oldpath.exists() else 'new','before_sha256':sha(oldpath) if oldpath.exists() else None,'after_sha256':sha(p),'size':p.stat().st_size}
manifest['changed_file_count']=len(manifest['runtime_changes']);manifest['new_files']=sum(x['change']=='new' for x in manifest['runtime_changes'].values());manifest['modified_files']=sum(x['change']=='modified' for x in manifest['runtime_changes'].values())
jsonwrite(ROOT/'DELTA_MANIFEST.json',manifest)
jsonwrite(ROOT/'expected_effective_ashen.json',current)
print(json.dumps({'count':manifest['changed_file_count'],'new':manifest['new_files'],'modified':manifest['modified_files'],'manifest':str(ROOT/'DELTA_MANIFEST.json'),'damage_room_changed':False},indent=2))
