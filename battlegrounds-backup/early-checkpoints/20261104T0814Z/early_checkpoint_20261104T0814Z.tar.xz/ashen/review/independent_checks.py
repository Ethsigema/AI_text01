from pathlib import Path
import hashlib,json,re,copy,xml.etree.ElementTree as ET
P=Path('/workspace/shared/recovery_restart_20261104T0750Z/rebuild_ashen_candidate'); B=P.parent/'restored_murcules_project'; F=P/'files'
h=lambda b:hashlib.sha256(b).hexdigest()
manifest=json.loads((P/'DELTA_MANIFEST.json').read_text()); packet=json.loads((F/'data/patch_3702_ashen.json').read_text()); ids=packet['ids']; results=[]
def check(label,condition):
 assert condition,label
 results.append(label)
def const(path,name):
 text=path.read_text(); m=re.search(r'^const '+name+r'\s*:[^=]+?=\s*(.+)$',text,re.M); return json.loads(m[1])
files={str(p.relative_to(F)) for p in F.rglob('*') if p.is_file()}
check('Exactly manifest 10 files',files==set(manifest['runtime_changes']) and len(files)==10)
for f,m in manifest['runtime_changes'].items():
 check('Manifest after hash '+f,h((F/f).read_bytes())==m['after_sha256'])
 check('Manifest baseline hash '+f,h((B/f).read_bytes())==m['before_sha256'] if (B/f).exists() else m['before_sha256'] is None)
for f,names in [('core/bulk_hero_damage_recruit.gd',['PROGRAMS','SOURCES']),('core/dark_gift_qualification.gd',['TARGET_FACTS'])]:
 a=(B/f).read_text(); b=(F/f).read_text()
 changed=[]
 for name in names:
  # DarkGift constant discovered by its actual changed line rather than assumption.
  if not re.search(r'^const '+name+r'\b',a,re.M):
   name=next(re.match(r'const (\w+)',x).group(1) for x,y in zip(a.splitlines(),b.splitlines()) if x!=y)
  old=const(B/f,name); new=const(F/f,name)
  check(f+' '+name+' exactly two records',old.keys()==new.keys() and {k for k in old if old[k]!=new[k]}==set(ids))
  a=re.sub(r'^const '+name+r'\b.*$', '', a, flags=re.M); b=re.sub(r'^const '+name+r'\b.*$', '', b, flags=re.M)
 check(f+' all nonconstant code unchanged',a==b)
check('DamageRoom absent from delta', 'core/damage_listener_room.gd' not in files)
room=(B/'core/damage_listener_room.gd').read_text()
check('Baseline room has neither Ashen source pins nor recruit-hero-damage capability','BG32_873' not in room and 'after_recruit_hero_damage' not in room)
paths=re.search(r'for path in (\["res://data/catalog_raw.json".*?\]):', (F/'core/catalog.gd').read_text())[1]
merged={}; sightings={i:[] for i in ids}
for path in json.loads(paths):
 p=B/path.removeprefix('res://')
 if not p.exists():continue
 for row in json.loads(p.read_text()).get('cards',[]):
  if row.get('id') not in ids:continue
  i=row['id']; sightings[i].append(path)
  key='expected_raw' if path.endswith('catalog_raw.json') else 'expected_compiled'
  check('Exact full input '+i+' '+path,packet[key][i]==row)
  merged.setdefault(i,{}).update(copy.deepcopy(row))
  if 'coverage_text_sha256' in merged[i] and h(merged[i].get('text','').encode())!=merged[i]['coverage_text_sha256']:
   merged[i]['supported']=False; merged[i]['coverage_blocker']='源卡文已变化，须重新审核可执行效果。'
  if not merged[i].get('solo_eligible',True) or merged[i].get('latest_validation',{}).get('data_gate',False):merged[i]['supported']=False
  merged[i].setdefault('supported',False)
for i in ids:
 check('Exactly raw+compiled sightings '+i,len(sightings[i])==2)
 check('Merged preimage exact '+i,merged[i]==packet['expected_merged'][i])
 e=copy.deepcopy(merged[i]); e.update(packet['effective_fields'][i])
 check('Only permitted five effective fields '+i,set(packet['effective_fields'][i])=={'attack','health','text','effects','coverage_text_sha256'})
 check('Historical and hold fields preserved '+i,all(e[k]==merged[i][k] for k in merged[i] if k not in packet['effective_fields'][i]))
 check('Text digest '+i,h(e['text'].encode())==e['coverage_text_sha256'])
 targets=json.loads((B/'research/lucky_egg_rebuilt/target_contracts.json').read_text())
 check('LuckyEgg complete old target exact '+i,targets['targets'][i]==packet['expected_lucky_egg'][i])
for rel,digest in const(F/'core/patch_3702_ashen_sources.gd','FILE_SHA256').items():
 target=(F/rel) if (F/rel).exists() else (B/rel)
 check('Runtime evidence hard pin '+rel,target.exists() and h(target.read_bytes())==digest)
for rel in const(F/'core/patch_3702_ashen_sources.gd','RUNTIME_PATHS'):
 check('Fingerprint dependency exists '+rel,(F/rel).exists() or (B/rel).exists())
source=json.loads((P/'source_research/source_manifest.json').read_text())
for name,sha in source['artifact_sha256'].items():check('Full provenance hash '+name,h((P/'source_research'/name).read_bytes())==sha)
root=ET.parse(P/'source_research/CardDefs.Bacon.37.0.2.256589.xml').getroot()
for i in ids:
 entity=next(x for x in root.iter('Entity') if x.get('CardID')==i)
 extracted=ET.parse(F/'research/patch_3702_ashen'/f'{i}.xml').getroot()
 check('Extracted native entity exact semantic tree '+i,ET.tostring(entity).strip()==ET.tostring(extracted).strip())
 tags={t.get('name'):t for t in entity.findall('Tag')};e=packet['effective_fields'][i];fact=source['entities'][i]
 check('Native body '+i,int(tags['ATK'].get('value'))==e['attack'] and int(tags['HEALTH'].get('value'))==e['health'])
 text=tags['CARDTEXT'].find('zhCN').text.format(fact['grant_attack'],fact['grant_health'])
 check('Native rendered Chinese '+i,text==e['text'])
 check('Native effect quantities '+i,int(tags['TAG_SCRIPT_DATA_NUM_1'].get('value'))==e['effects'][0]['attack'] and int(tags['TAG_SCRIPT_DATA_NUM_2'].get('value'))==e['effects'][0]['health'])
check('Official excerpt contained in downloaded full HTML',(P/'source_research/official_ashen_excerpt.html').read_text().strip() in (P/'source_research/official_patch_3702.html').read_text())
(P/'review/independent_checks.json').write_text(json.dumps({'status':'passed','count':len(results),'checks':results},indent=2))
print('PASS',len(results))
