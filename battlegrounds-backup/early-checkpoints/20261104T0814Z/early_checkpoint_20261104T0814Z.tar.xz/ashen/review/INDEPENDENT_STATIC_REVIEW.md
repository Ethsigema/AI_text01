# Independent static review of reconstructed Ashen 37.0.2 delta

Result: no blocking defect found in the bounded static review. This is source/static review only, not native parsing, gameplay acceptance, recovery of a historical seal, or permission to lift any existing hold.

Reviewed final DELTA_MANIFEST.json SHA-256: 6aec556bacffa1d2da5f6cc671a6f14291e6b4f61629746cf92a7652f632311a. Scope is exactly 10 files: 6 new and 4 modified. The earlier 11-file proposal is superseded and is not approved by this review.

## Findings

- DamageListenerRoom is absent from the final delta. The immutable baseline has neither Ashen source pins nor an after_recruit_hero_damage capability clause. It must remain unchanged; superseded pin proposals have no application or acceptance credit.
- Both complete raw records and both complete compiled records equal their immutable baseline inputs. Independent reconstruction of the catalog input merge finds exactly the raw and compiled sightings per ID and reproduces both expected_merged records. The overlay is placed after that source-input loop, before downstream source/whole-program checks. Inspection of the intervening source-metadata/identity/final-source/hero-value stages found no Ashen-targeted mutation. The later catalog value override data does not mention Ashen.
- The raw guard runs before numeric normalization. Its recursive exact equality rejects missing/extra keys, unequal values, type substitution (apart from intentional int/float equality), and nonfinite numbers. Unexpected input paths claiming either target ID fail closed.
- apply_overlay verifies all pinned evidence and both complete merged preimages before preparing either write. It duplicates both records, changes only attack, health, text, coverage_text_sha256, and effects, then commits both. There is no mutation of either original before all checks pass. Both numeric effect fields are converted to integers. No unrelated metadata, support flag, pool flag, partial-state explanation, or historical source field is changed.
- BulkHeroDamage PROGRAMS changes only attack in the two Ashen effects (2 to 1, 4 to 2); SOURCES changes only attack, health, and text in those same IDs. All other records and all function bodies are byte-identical.
- DarkGift FACTS changes only effects for the same two IDs; all other facts and function bodies are byte-identical.
- LuckyEgg adapts only the two Ashen IDs. It authenticates the entire original target_contracts.json through the hard pin, then the exact old per-ID expectation. It duplicates the expectation and changes only attack, health, and effects. The original provider file, pair/domain mapping, all unrelated expectations, and target validation body otherwise remain unchanged.
- The new helper's listed evidence hashes match the actual files, including immutable LuckyEgg expectations. All added fingerprint dependencies resolve in the intended baseline-plus-delta tree.
- Manual GDScript inspection found no obvious syntax/control-flow error in the new helper or inserted callsites. No native parser or engine was invoked; this is not evidence of successful GDScript compilation or runtime typing.

## Independent evidence

The newly authored review/independent_checks.py reads data and source text only. It does not import or execute candidate or recovered project scripts. Its final results are in independent_checks.json. Checks cover the final manifest, baseline hashes, semantic record scope, exact input records and merged preimages, hold preservation, hard pins, dependency existence, complete downloaded artifact hashes, exact XML entity extraction, native body/effect quantities, rendered Chinese texts, and presence of the official excerpt in the downloaded HTML.

Native source URL: https://raw.githubusercontent.com/HearthSim/hsdata/31b034c26f24b8a66ece845ffd03c1ca397b9a02/CardDefs.Bacon.xml

Full native SHA-256: 103890e791863c743dd4b873e4cb789b711543ba839f923f677ebba6d672ff5a

Official URL: https://hearthstone.blizzard.com/en-us/news/24307311/3702-patch-notes

Downloaded official HTML SHA-256: ec92b700fcce10ee8ebdec83b3b44e16e1d8c5f332a63f8ba1a1938e585a24b9

Official excerpt SHA-256: c233e798d083018fb439fa1d88d488352f85089fd3b2d379326cf430e6b8977c

Normal entity SHA-256: 04a4b89390c1eba61a5524b5ab863254e8584c5b3bdfd6580183b4dd46a163c8

Golden entity SHA-256: 27a6309a8ad8a75f01cfe5099bfceb89d8665f2e9530138e0b0822acc9a4b738

Normal body is 4/8 with this-turn shop +1/+2; golden body is 8/16 with this-turn shop +2/+4. Both preserve hero-damage rewind. Golden values are native-entity evidence, not an assertion that official prose explicitly states golden values. Local source files were inspected independently; no fresh network retrieval was performed in this review.

## Limits and residual holds

No Godot engine, native GDScript parser, recovered script, gameplay test, mutation execution in GDScript, save/load, replay, actual catalog load, compatibility suite, current runtime fingerprint, or source seal was produced. Python data reconstruction is not Godot execution. The source-only delta does not prove damage event ordering, lethal rewind, future offers, cross-family compatibility, or DamageListenerRoom admission. Existing default_pool=false, partial_pending_unified_validation, conditional-support limitations, and room holds remain required. Historical tests carry zero credit for this reconstructed delta. Full native and official source downloads remain external reconstruction evidence; runtime hashes pin the bounded exact entities/excerpt/evidence packet, as expressly designed.
