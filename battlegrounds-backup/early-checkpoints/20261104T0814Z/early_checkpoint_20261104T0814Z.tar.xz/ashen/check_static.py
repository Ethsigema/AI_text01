from pathlib import Path
import copy, hashlib, json, re, math, xml.etree.ElementTree as ET
R=Path('/workspace/shared/recovery_restart_20261104T0750Z/rebuild_ashen_candidate');O=R/'files';B=Path('/workspace/shared/recovery_restart_20261104T0750Z/restored_murcules_project');ids=['BG32_873','BG32_873_G'];checks=[]
def check(name,value):
 assert value,name
 checks.append(name)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def data(p):return json.loads(p.read_text())
def constant(p,n):
 m=re.search(r'^const '+re.escape(n)+r'\s*:\s*\w+\s*=\s*(.*)$',p.read_text(),re.M);assert m,n
 return json.loads(m[1])
m=data(R/'DELTA_MANIFEST.json');p=data(O/'data/patch_3702_ashen.json');old=p['expected_merged'];new=data(R/'expected_effective_ashen.json')
actual={x.relative_to(O).as_posix() for x in O.rglob('*') if x.is_file()};check('exact ten-file inventory',actual==set(m['runtime_changes']) and len(actual)==10)
for rel,entry in m['runtime_changes'].items():
 check('delta hash '+rel,sha(O/rel)==entry['after_sha256'])
 check('baseline preimage '+rel,(sha(B/rel) if (B/rel).is_file() else None)==entry['before_sha256'])
 check('regular file '+rel,not (O/rel).is_symlink())
module=O/'core/patch_3702_ashen_sources.gd'
for rel,digest in constant(module,'FILE_SHA256').items():check('runtime evidence pin '+rel,sha(O/rel if (O/rel).exists() else B/rel)==digest)
check('module fingerprinted',module.relative_to(O).as_posix() in constant(module,'RUNTIME_PATHS'))
full=(R/'source_research/CardDefs.Bacon.37.0.2.256589.xml').read_bytes();check('full native packet hash',hashlib.sha256(full).hexdigest()=='103890e791863c743dd4b873e4cb789b711543ba839f923f677ebba6d672ff5a')
for id in ids:
 entity=(O/f'research/patch_3702_ashen/{id}.xml').read_bytes();check('exact native entity extraction '+id,entity.strip() in full)
 root=ET.fromstring(entity);tags={t.attrib.get('name'):t for t in root.findall('Tag')};expected=(4,8,1,2) if id==ids[0] else (8,16,2,4)
 check('native body '+id,(int(tags['ATK'].attrib['value']),int(tags['HEALTH'].attrib['value']))==expected[:2])
 check('native dbf identity '+id,root.attrib['ID']==old[id]['dbf_id'])
 check('new body and effect '+id,(new[id]['attack'],new[id]['health'],new[id]['effects'][0]['attack'],new[id]['effects'][0]['health'])==expected)
 check('effective text hash '+id,hashlib.sha256(new[id]['text'].encode()).hexdigest()==new[id]['coverage_text_sha256'])
 check('only five top-level effective fields '+id,{k for k in old[id] if old[id][k]!=new[id][k]}=={'attack','health','text','effects','coverage_text_sha256'})
 check('entire historical fields preserved '+id,all(new[id][k]==old[id][k] for k in ['raw_fields','fields','field_status','provenance','occurrences','images','source_urls','mode_evidence']))
 check('all inherited holds preserved '+id,all(new[id].get(k)==old[id].get(k) for k in ['supported','default_pool','pool_supported','conditional_support','implementation_status','excluded','coverage_gate','coverage_blocker']))
check('original raw and compiled files not in delta','data/catalog_raw.json' not in actual and 'data/catalog.json' not in actual)
check('unchanged game and Ashen host','core/game.gd' not in actual and 'core/ashen_turn_shop.gd' not in actual)
check('unchanged membership and Naga scopes',not any(x in actual for x in ['data/current_scope_manifest.json','data/tribe_pool_requirements.json','core/patch_3702_membership_sources.gd']))
for file,names in [('core/bulk_hero_damage_recruit.gd',['PROGRAMS','SOURCES']),('core/dark_gift_qualification.gd',['FACTS'])]:
 for n in names:
  before=constant(B/file,n);after=constant(O/file,n);check('only Ashen entries '+n,set(before)==set(after) and {k for k in before if before[k]!=after[k]}==set(ids))
  for id in ids:
   if n=='PROGRAMS':check('exact program '+id,after[id]==new[id]['effects'])
   elif n=='SOURCES':check('exact source facts '+id,all(after[id][k]==new[id][k] for k in after[id]))
   else:check('DarkGift only effect '+id,{k for k in before[id] if before[id][k]!=after[id][k]}=={'effects'} and after[id]['effects']==new[id]['effects'])
 before=(B/file).read_text();after=(O/file).read_text()
 for n in names:
  pat=r'^const '+n+r'\s*:\s*\w+\s*=.*$';before=re.sub(pat,'CONST',before,flags=re.M);after=re.sub(pat,'CONST',after,flags=re.M)
 check('all function bodies unchanged '+file,before==after)
check('damage room module wholly unchanged','core/damage_listener_room.gd' not in actual)
check('damage room capability hold still closed','after_recruit_hero_damage' not in (B/'core/damage_listener_room.gd').read_text())
f='core/lucky_egg_sources.gd';a=(B/f).read_text();z=(O/f).read_text();z=z.replace('const Patch3702Ashen=preload("res://core/patch_3702_ashen_sources.gd")\n','');z=z.replace('\t\tif id in Patch3702Ashen.IDS:\n\t\t\tvar adapted: Dictionary=Patch3702Ashen.lucky_egg_expectation(id,expected)\n\t\t\tif not adapted.ok: return str(adapted.error)\n\t\t\texpected=adapted.expected\n','')
check('LuckyEgg only bounded adapter call',a==z)
check('provider manifest not rewritten','research/lucky_egg_rebuilt/target_contracts.json' not in actual)
# These semantic model checks test the intended predicates, not GDScript execution.
def same(a,b):
 if type(b) in (int,float):return type(a) in (int,float) and math.isfinite(a) and math.isfinite(b) and a==b
 if type(a)!=type(b):return False
 if type(b)==dict:return set(a)==set(b) and all(same(a[k],b[k]) for k in b)
 if type(b)==list:return len(a)==len(b) and all(same(x,y) for x,y in zip(a,b))
 return a==b
def apply_model(cards):
 for id in ids:
  if type(cards.get(id)) is not dict or not same(cards[id],old[id]):return False
 prepared={id:{**copy.deepcopy(cards[id]),**copy.deepcopy(p['effective_fields'][id])} for id in ids}
 cards.update(prepared);return True
mutation_count=0
for id in ids:
 for key,value in [('attack',True),('health',False),('tier','4'),('effects',[]),('conditional_support',{}),('default_pool',True),('raw_fields',{}),('text','changed'),('pool_supported',not old[id]['pool_supported']),('dbf_id',121687),('id',id+'x'),('is_golden',1),('attack',float('nan')),('health',float('inf'))]:
  cards=copy.deepcopy(old);cards[id][key]=value;before=copy.deepcopy(cards);accepted=apply_model(cards);check('semantic-model reject '+id+':'+key+':'+str(mutation_count),not accepted and repr(cards)==repr(before));mutation_count+=1
 cards=copy.deepcopy(old);cards[id]['unexpected']=0;before=copy.deepcopy(cards);check('semantic-model reject extra key '+id,not apply_model(cards) and cards==before);mutation_count+=1
 cards=copy.deepcopy(old);del cards[id]['health'];before=copy.deepcopy(cards);check('semantic-model reject missing key '+id,not apply_model(cards) and cards==before);mutation_count+=1
cards=copy.deepcopy(old);cards['unrelated']={'id':'unrelated','custom':'preserved'};check('semantic-model applies both correct rows',apply_model(cards) and all(cards[i]==new[i] for i in ids) and cards['unrelated']=={'id':'unrelated','custom':'preserved'})
check('semantic-model repeated overlay rejects without mutation',not apply_model(cards) and all(cards[i]==new[i] for i in ids))
for id in ids:
 original=copy.deepcopy(p['expected_lucky_egg'][id]);adapted=copy.deepcopy(original)
 for k in ['attack','health','effects']:adapted[k]=copy.deepcopy(p['effective_fields'][id][k])
 check('LuckyEgg exact three fields changed '+id,{k for k in original if original[k]!=adapted[k]}=={'attack','health','effects'})
 bad=copy.deepcopy(original);bad['tier']=5;check('semantic-model LuckyEgg old expectation rejects '+id,not same(bad,p['expected_lucky_egg'][id]))
report={'status':'passed_author_static_and_semantic_model_checks','check_count':len(checks),'checks':checks,'mutation_model_cases':mutation_count,'delta_manifest_sha256':sha(R/'DELTA_MANIFEST.json'),'no_engine_executed':True,'gdscript_executed':False,'limits':['Python semantic models do not execute or verify GDScript semantics.','No gameplay, native save/load, replay, fingerprint or prior acceptance credit.','Independent reviewer report is separate.']}
(R/'STATIC_CHECKS.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:report[k] for k in ['status','check_count','mutation_model_cases','delta_manifest_sha256']},indent=2))
