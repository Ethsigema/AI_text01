# Reconstructed Tidecaller source delta

Status: source files and exact preimages are frozen for independent review. The 282 author static/Python reference checks pass. Independent Tidecaller review, Godot parsing, native behavior tests and shared regressions remain pending. There is no inherited acceptance from the lost original Tidecaller candidate or earlier spell/Ashen/Murcules runs.

## Layer order and scope

1. Read-only restored base: `../restored_murcules_project`.
2. Reviewed Ashen delta: `../rebuild_ashen_candidate/files`, bound by its final manifest and source seal.
3. This Tidecaller delta: `files/`, with exactly ten files: four modified, six new.

`DELTA_MANIFEST.json` authenticates every payload and its effective preimage. Catalog and Dark Gift use Ashen preimages; adjacent-target listeners and damage-listener room use restored-base preimages. No runtime materialization, engine execution, pointer mutation, archive or upload was performed.

The normal/golden pair BG36_704/BG36_704_G becomes 6/9 and 12/18. A qualifying actual Murloc-targeted spell grants owned board and hand Murlocs +3/+4 or +6/+8 once. Existing game and RecruitHand writers are unchanged. The overlay authenticates both complete historical rows before changing either; its current-source guard binds immutable identity and effective fields. Historical raw/provider records, Naga, excluded Aberrations, extras and provider/composition holds remain unchanged.

The dependent changes are exactly the two Tidecaller PROGRAMS entries, two FACTS effects entries, and two independently derived damage proof hashes. Catalog receives only the four narrow Tidecaller hooks and preserves the reviewed Ashen additions. No generic numeric normalization or blanket repinning was introduced.

## Current evidence

- Full native XML SHA256: `103890e791863c743dd4b873e4cb789b711543ba839f923f677ebba6d672ff5a`.
- Fresh whole official page SHA256: `ec92b700fcce10ee8ebdec83b3b44e16e1d8c5f332a63f8ba1a1938e585a24b9`. This is not the lost original page hash.
- Current native and official input files: `../rebuild_ashen_candidate/source_research/`.
- Runtime source evidence: `files/research/patch_3702_tidecaller/source_evidence.json`.
- Author checks: `preparation/check_tidecaller_layer.py` and `preparation/STATIC_CHECKS.json`, 282 checks. These are static and Python reference checks, not GDScript execution.
- `SOURCE_DELTA_SEAL.json` binds the final source manifest, unchanged payload bytes, author checks and exact reviewed Ashen prerequisite. It does not assert independent Tidecaller approval.
- `SOURCE_REVIEW_HANDOFF.json` provides exact paths and hashes for review and later runner preparation.

The initial preparation plan and read-only input snapshot are retained as historical planning records. Their pending-input wording and provisional overlap count are superseded by the final manifest: only Catalog and Dark Gift overlap the corrected Ashen delta. The draft manifest is retained, and the author report binds it; final runtime payload bytes are identical.

## Required fresh validation

Independent source review must authenticate the current native/official data, atomic overlay, numeric boundary, immutable identity, all dependency substitutions and preservation of the Ashen preimages. Fresh native validation must then cover Catalog loading/fingerprint, normal and golden public recruit lifecycle behavior, board/hand recipient and control behavior, qualifying and rejected casts, conservation, full native save/load and combat replay, plus synthetic guard mutations and stale-fingerprint rejection. Existing shared spell/Ashen/Murcules regressions require fresh runs against the exact final combined source when used for acceptance. Historical successes do not transfer.

No complete card-identity claim, production runtime fingerprint, runtime file-count seal, promotion or test acceptance is made by this source-only packet. If another effect is composed, all source and test evidence must be re-bound to the resulting exact bytes.
