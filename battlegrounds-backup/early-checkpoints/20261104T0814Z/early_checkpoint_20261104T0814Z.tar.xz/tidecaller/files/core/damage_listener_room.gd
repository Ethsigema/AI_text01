extends RefCounted
const Nefarian=preload("res://core/nefarian_hero.gd")
const Brukan=preload("res://core/brukan_elements_sources.gd")
const HighestBattlefield=preload("res://core/highest_battlefield_trace.gd")
## First damage-received production closure. Native identities and complete
## programs are pinned below; a digest is necessary, never a capability grant.
## No data-supplied proof/allow_unknown flag, model certificate, or catalog-wide
## reachability shortcut is accepted. Paths retain actual side and source.
const Registry = preload("res://core/damage_listener_registry.gd")
const DamageResourceAdapter = preload("res://core/damage_resource_host.gd")
const Volcanic = preload("res://core/volcanic_visitor_sources.gd")
const LobbyTribes = preload("res://core/lobby_tribes.gd")
const StartingHero = preload("res://core/hero_starting_units.gd")
const Intrinsic = preload("res://core/beetle_growth_room.gd")
const FIELD: String = "damage_received_listeners"
const POLICY: String = "damage-received-six-closed-room-v1;positive-packets;native-uid-only;frozen-ghost-discard-1"
const MAX_DEPTH: int = 48
const MAX_NODES: int = 20000
const ROOTS: Array = ["enabled_minions","enabled_spells","enabled_heroes","enabled_anomalies","enabled_trinkets","enabled_quests","enabled_rewards"]
const STATIC_KEYWORDS: Array = ["taunt","divine_shield","windfury","venomous","poisonous","immunity_while_attacking","reborn"]
const ORCAS: Array = ["BG34_312","BG34_312_G"]
const PUPPIES: Array = ["BG29_800","BG29_800_G"]
const SUMMONERS: Array = ["BG_BOT_218", "TB_BaconUps_041", "BG29_801", "BG29_801_G", "BG_BRM_006", "TB_BaconUps_030"]
const FIXED_BUFFS: Array = ["battlecry_buff","spell_buff","hero_buff","end_turn_buff","end_turn_recruit_buff","start_combat_buff","deathrattle_buff","on_friendly_death_buff","on_attacked_buff","on_shield_lost_buff","on_friendly_summon_buff","buff"]
const RESOURCES: Array = ["battlecry_gold","spell_gold","hero_gold","on_buy_gold","on_sell_gold","battlecry_free_rolls","spell_free_rolls","battlecry_upgrade_discount","spell_upgrade_discount","hero_start_free_rolls","hero_upgrade_gold","hero_buy_gold"]
const SUMMONS: Array = ["battlecry_summon","deathrattle_summon","summon"]
const GENERATED: Array = ["battlecry_add_card","spell_add_card","hero_add_card","on_sell_add_card","deathrattle_add_card","add_card"]
const IDENTITY_TYPES: Array = ["after_tavern_refresh_multiply","spell_set","battlecry_set","set_stats","literal_set","spell_multiply","start_combat_multiply","on_attack_multiply","multiply","copy","copy_stats","stat_copy","hero_make_golden","spell_shop_make_golden","spell_prize_golden_return","spell_prize_return_minion","hero_steal","spell_prize_steal_tavern","spell_steal_shop","battlecry_devour","battlecry_devour_board","end_turn_devour","on_play_devour","deathrattle_summon_history","magnetic"]
const HAND_SUMMONS: Array = ["deathrattle_summon_from_hand","after_friendly_death_summon_self_from_hand"]
const WRAPPERS: Array = ["rally","avenge","on_friendly_death","on_friendly_summon","on_play_effect","on_spell_effect","mechanism_trigger","choose_one"]
const PROOF_FIELDS: Array = ["id","kind","text","effects","keywords","tribes","is_golden","normal_id","golden_id","attack","health","tier","cost"]

static func schema_error(options: Dictionary) -> String:
	return "damage_received_listeners 必须为明确布尔值。" if not options.get(FIELD,false) is bool else ""

static func fingerprint_fragment(options: Dictionary) -> String:
	return POLICY if options.get(FIELD,false) == true else ""

static func _identity(card: Dictionary) -> String:
	var identity: Variant = card.get("card_id",card.get("id",""))
	return identity if identity is String else ""

static func _card(catalog, identity: String) -> Dictionary:
	var value: Variant = {}
	if catalog is Dictionary: value = catalog.get(identity,{})
	elif catalog is Object and is_instance_valid(catalog) and catalog.has_method("get_card"): value = catalog.get_card(identity)
	return value if value is Dictionary else {}

static func _same(a: Variant, b: Variant) -> bool:
	if typeof(a) != typeof(b): return false
	if a is Dictionary:
		if a.size()!=b.size(): return false
		for key in a:
			if not b.has(key) or not _same(a[key],b[key]): return false
		return true
	if a is Array:
		if a.size()!=b.size(): return false
		for i in range(a.size()):
			if not _same(a[i],b[i]): return false
		return true
	return a==b

static func _canonical(value: Variant) -> String:
	if value is Dictionary:
		var keys: Array = value.keys(); keys.sort()
		var encoded: String = "d{"
		for key in keys: encoded+=_canonical(key)+_canonical(value[key])
		return encoded+"}"
	if value is Array:
		var encoded: String = "a["
		for child in value: encoded+=_canonical(child)
		return encoded+"]"
	if value==null: return "n"
	if value is bool: return "b1" if value else "b0"
	if value is int: return "i"+str(value)+";"
	if value is String: return "s"+str(value.length())+":"+value
	return "INVALID_TYPE"

static func _integer(value: Variant, minimum: int = 0, maximum: int = 9007199254740991) -> bool:
	return value is int and value>=minimum and value<=maximum

static func _keys(value: Dictionary, allowed: Array) -> bool:
	for key in value:
		if key not in allowed: return false
	return true

static func _append(errors: Array[String], issue: String) -> void:
	if not issue.is_empty() and issue not in errors: errors.append(issue)

static func _state() -> Dictionary:
	return {"cards":[],"nodes":[],"queue":[],"seen":{},"errors":[],"active":false,"count":0,"room":false,"pool_ids":null}

static func _error(state: Dictionary, issue: String) -> void:
	if issue not in state.errors: state.errors.append(issue)

static func _bound(state: Dictionary, depth: int, path: String) -> bool:
	state.count+=1
	if depth>MAX_DEPTH or int(state.count)>MAX_NODES:
		_error(state,"Damage closure exceeds finite depth/node bound at "+path)
		return false
	return true

static func _enqueue(identity: Variant, state: Dictionary, side: int, path: String, zone: String, depth: int) -> void:
	if not identity is String or identity.is_empty(): _error(state,"Missing fixed dependency at "+path); return
	if not _bound(state,depth,path): return
	var key: String = str(side)+":"+zone+":"+identity
	if not state.seen.has(key):
		state.seen[key]=true
		state.queue.append({"id":identity,"side":side,"path":path+" → "+identity,"zone":zone,"depth":depth})

static func _add(card: Variant, state: Dictionary, catalog, side: int, path: String, zone: String, depth: int = 0) -> void:
	if not _bound(state,depth,path): return
	if not card is Dictionary: _error(state,"Reachable source is not a complete object at "+path); return
	var entry: Dictionary = {"card":card,"side":side,"path":path,"zone":zone}
	state.cards.append(entry)
	var identity: String = _identity(card)
	if identity in Registry.SOURCE_IDS or DamageResourceAdapter.claimed(card): state.active=true
	if not card.get("effects",[]) is Array: _error(state,"Malformed complete effects at "+path); return
	_walk(card.get("effects",[]),entry,state,catalog,path+".effects",[],depth+1)
	for field in ["base_unit","_base"]:
		if card.has(field): _add(card[field],state,catalog,side,path+"."+field,"base",depth+1)
	# Walk every alternative executable container before reporting its gate.
	for field in ["inherited_effects","transferred_effects","external_effects","battlecry","deathrattle","attachments","enchantments"]:
		if card.has(field) and not _same(card[field],[]):
			_error(state,"Unreviewed inherited/capture container at "+path+"."+field)
			_walk(card[field],entry,state,catalog,path+"."+field,[],depth+1)
	if card.get("golden_id") is String and not card.golden_id.is_empty():
		_enqueue(card.golden_id,state,side,path+".genuine_triple","golden",depth+1)

static func _walk(value: Variant, owner: Dictionary, state: Dictionary, catalog, path: String, parents: Array, depth: int) -> void:
	if not _bound(state,depth,path): return
	if value is Array:
		for i in range(value.size()): _walk(value[i],owner,state,catalog,path+"[%d]"%i,parents,depth+1)
	elif value is Dictionary:
		var ancestry: Array = parents.duplicate()
		if value.has("type"):
			if not value.type is String: _error(state,"Malformed effect type at "+path)
			else:
				state.nodes.append({"owner":owner,"effect":value,"path":path,"parents":parents.duplicate()})
				ancestry.append(value.type)
				if value.type == Registry.TYPE or value.type in DamageResourceAdapter.TYPES: state.active=true
				if value.type in ["spell_discover","hero_discover","battlecry_discover_minion","battlecry_conditional_discover","on_sell_discover_minion"]:
					_discover(value,owner,state,catalog,path,depth+1)
				elif value.type in ["battlecry_random_card","on_sell_random_card","spell_fill_hand","battlecry_add_shop"]:
					_error(state,"Unproved dynamic generation closure at "+path)
				if value.type==Brukan.TYPE: _enqueue(Brukan.CHILD,state,owner.side,path+".brukan_earth","generated",depth+1)
				if value.type==StartingHero.TYPE:
					for identity in StartingHero.effect_dependency_ids(value): _enqueue(identity,state,owner.side,path+".hero_start","generated",depth+1)
		for key in value:
			var child: Variant = value[key]
			var child_path: String = path+"."+str(key)
			if key in ["unit","base_unit"]:
				_add(child,state,catalog,owner.side,child_path,"generated",depth+1)
			elif key in ["card_id","normal_id","golden_id","target_catalog_id"] and child!=null and child!="":
				_enqueue(child,state,owner.side,child_path,"generated_hand" if value.get("type") in GENERATED+[DamageResourceAdapter.TYPE] else "generated",depth+1)
			elif key in ["card_ids","minion_ids","spell_ids","generated_ids"]:
				if not child is Array: _error(state,"Incomplete generated identity list at "+child_path)
				else:
					for identity in child: _enqueue(identity,state,owner.side,child_path,"generated_hand",depth+1)
			if key in ["unit","base_unit"]: continue
			if child is Array or child is Dictionary: _walk(child,owner,state,catalog,child_path,ancestry,depth+1)
			elif child is String and not _card(catalog,child).is_empty() and key not in ["card_id","normal_id","golden_id","target_catalog_id","source_id","resource_source"]:
				_enqueue(child,state,owner.side,child_path,"generated",depth+1)

static func _discover(effect: Dictionary, owner: Dictionary, state: Dictionary, catalog, path: String, depth: int) -> void:
	# Only configured eligible sources can be discover candidates. An omitted
	# list is not an empty proof, and the unrelated catalog is never swept.
	if not state.pool_ids is Array:
		_error(state,"Discover requires complete configured damage_listener_pool_ids at "+path)
		return
	for identity in state.pool_ids:
		if not identity is String: _error(state,"Malformed discover pool identity at "+path); continue
		var card: Dictionary = _card(catalog,identity)
		if card.is_empty(): _error(state,"Missing discover dependency: "+identity); continue
		if effect.has("tier") and _integer(effect.tier,1,6) and card.get("tier")!=effect.tier: continue
		if not _matches(effect,card): continue
		_enqueue(identity,state,owner.side,path+".discover","generated_hand",depth+1)

static func _drain(state: Dictionary, catalog) -> void:
	while not state.queue.is_empty() and int(state.count)<=MAX_NODES:
		var next: Dictionary = state.queue.pop_front()
		var card: Dictionary = _card(catalog,next.id)
		if card.is_empty(): _error(state,"Missing reachable dependency: "+next.path); continue
		_add(card,state,catalog,next.side,next.path,next.zone,next.depth)

static func _room_graph(config: Dictionary, catalog) -> Dictionary:
	var state: Dictionary = _state(); state.room=true
	var preview: Dictionary = LobbyTribes.preview(config,catalog)
	state.pool_ids=preview.get("enabled_minions")
	if not preview.get("ok",false):
		for issue in preview.get("errors",[]): _error(state,str(issue))
	var disabled: Variant = config.get("disabled_ids",[])
	if not disabled is Array: _error(state,"disabled_ids must be an Array"); disabled=[]
	for root in ROOTS:
		var ids: Variant = preview.get(root,[]) if root in ["enabled_minions","enabled_spells"] else config.get(root,[])
		if not ids is Array: _error(state,"Room roots must be complete arrays: "+root); continue
		for identity in ids:
			if identity not in disabled: _enqueue(identity,state,-1,root,"pool",0)
	if config.get("selected_hero","")!="": _enqueue(config.selected_hero,state,-1,"selected_hero","hero",0)
	if config.get("native_prizes",false):
		if not config.get("enabled_prizes",[]) is Array: _error(state,"enabled_prizes must be an Array")
		else:
			for identity in config.get("enabled_prizes",[]):
				if identity not in disabled: _enqueue(identity,state,-1,"enabled_prizes","reward",0)
	if config.get("native_buddies",false):
		var bindings: Variant = catalog.get("buddy_bindings") if catalog is Object else {}
		if not bindings is Dictionary: _error(state,"Missing native buddy bindings")
		else:
			for hero in config.get("enabled_heroes",[]):
				if hero in disabled: continue
				var identity: Variant = bindings.get(hero,{}).get("buddy_id")
				if identity!=null: _enqueue(identity,state,-1,"native_buddy("+str(hero)+")","generated_hand",0)
	# Genuine normal→golden acquisition stays available. Each exact built-in
	# reward is checked; configured discover roots already include all tiers.
	for tier in range(1,7): _add(Intrinsic.intrinsic_reward(tier),state,catalog,-1,"intrinsic_triple[%d]"%tier,"intrinsic")
	_add(Intrinsic.intrinsic_pouch(),state,catalog,-1,"intrinsic_empty_tier_pouch","intrinsic")
	_drain(state,catalog)
	return state

static func _ancestor(catalog, supplied):
	if supplied!=null: return supplied
	if catalog is Object and is_instance_valid(catalog): return catalog.get("source_catalog")
	return null

static func _custom_entry_error(entry: Variant) -> String:
	if not entry is Dictionary or entry.size()!=3 or not _keys(entry,["tier","cost","copies"]): return "Incomplete CustomShop projection"
	if not _integer(entry.get("tier"),1,6) or not _integer(entry.get("cost"),0,99) or not _integer(entry.get("copies"),1,99): return "Unbounded CustomShop projection"
	return ""

static func _effective_tier(catalog, ancestor, identity: String) -> Dictionary:
	var actual: Dictionary = _card(catalog,identity)
	var canonical: Dictionary = _card(ancestor,identity)
	if canonical.is_empty() or actual.is_empty(): return {"error":"Missing projected source: "+identity}
	if actual.has("custom_shop_override"):
		var issue: String = _custom_entry_error(actual.custom_shop_override)
		if not issue.is_empty(): return {"error":issue}
		if canonical.get("is_golden",false): return {"error":"Golden source cannot be a direct shop override"}
		return {"error":"","tier":actual.custom_shop_override.tier}
	if actual.has("custom_shop_derived_from"):
		if not actual.custom_shop_derived_from is String or canonical.get("normal_id")!=actual.custom_shop_derived_from: return {"error":"Unproved derived golden projection"}
		var normal: Dictionary = _card(catalog,actual.custom_shop_derived_from)
		var issue: String = _custom_entry_error(normal.get("custom_shop_override"))
		if not issue.is_empty() or normal.get("golden_id")!=identity: return {"error":"Missing genuine normal-to-golden override"}
		return {"error":"","tier":normal.custom_shop_override.tier}
	return {"error":"","tier":canonical.get("tier")}

static func _project_embedded(value: Variant, catalog, ancestor, depth: int = 0) -> String:
	if depth>MAX_DEPTH: return "Projected source nesting exceeds finite bound"
	if value is Array:
		for child in value:
			var issue: String = _project_embedded(child,catalog,ancestor,depth+1)
			if not issue.is_empty(): return issue
	elif value is Dictionary:
		if value.get("card_id") is String and value.has("attack") and value.has("health"):
			var effective: Dictionary = _card(catalog,value.card_id)
			if effective.has("custom_shop_override") or effective.has("custom_shop_derived_from"):
				var projected: Dictionary = _effective_tier(catalog,ancestor,value.card_id)
				if not str(projected.error).is_empty(): return str(projected.error)
				value.tier=projected.tier
		for child in value.values():
			var issue: String = _project_embedded(child,catalog,ancestor,depth+1)
			if not issue.is_empty(): return issue
	return ""

static func _ordinary_definition(catalog, identity: String, supplied = null) -> Dictionary:
	var actual: Dictionary = _card(catalog,identity)
	var ancestor: Variant = _ancestor(catalog,supplied)
	if ancestor==null:
		if actual.has("custom_shop_override") or actual.has("custom_shop_derived_from") or actual.has("source_shop_fields"): return {"error":"CustomShop projection lacks its canonical source catalog"}
		return {"error":"","canonical":actual,"effective":actual}
	var canonical: Dictionary = _card(ancestor,identity)
	if canonical.is_empty(): return {"error":"Missing canonical ordinary source: "+identity}
	var expected: Dictionary = canonical.duplicate(true)
	if actual.has("custom_shop_override"):
		var issue: String = _custom_entry_error(actual.custom_shop_override)
		if not issue.is_empty(): return {"error":issue}
		if canonical.get("is_golden",false): return {"error":"Direct golden CustomShop source is unproved"}
		expected.source_shop_fields={"tier":canonical.get("tier"),"cost":canonical.get("cost"),"pool_supported":canonical.get("pool_supported",false)}
		expected.custom_shop_override=actual.custom_shop_override.duplicate(true)
		expected.tier=actual.custom_shop_override.tier
		expected.cost=actual.custom_shop_override.cost
		expected.pool_supported=true
	elif actual.has("custom_shop_derived_from"):
		var projected: Dictionary = _effective_tier(catalog,ancestor,identity)
		if not str(projected.error).is_empty(): return {"error":projected.error}
		expected.source_shop_fields={"tier":canonical.get("tier"),"cost":canonical.get("cost"),"pool_supported":false}
		expected.custom_shop_derived_from=actual.custom_shop_derived_from
		expected.tier=projected.tier
	var issue: String = _project_embedded(expected.get("effects",[]),catalog,ancestor)
	if not issue.is_empty(): return {"error":issue}
	if not _same(actual,expected): return {"error":"Changed ordinary source outside exact CustomShop projection: "+identity}
	return {"error":"","canonical":canonical,"effective":actual}

## Complete source proof. Runtime additive stats/ordinary keywords may differ,
## but native text/tribes/effects/golden identity and every base stay intact.
static func _source_error(entry: Dictionary, catalog, source_catalog = null) -> String:
	var actual: Dictionary = entry.card
	var identity: String = _identity(actual)
	if identity in ["__triple_reward","__triple_gold_pouch"]: return Intrinsic.intrinsic_error(actual)
	var card: Dictionary = _card(catalog,identity)
	if card.is_empty(): return "Missing canonical complete source: "+identity
	if identity in [Brukan.CHILD,Brukan.CHILD_G]:
		var child_issue: String=Brukan.source_error(card)
		if not child_issue.is_empty(): return child_issue
		if actual.has("id") and not actual.has("card_id"): return Brukan.source_error(actual)
		if actual.get("effects",[])!=[] or actual.get("tribes")!=["元素"] or actual.get("golden",false)!=card.get("is_golden"): return "Changed native Brukan elemental runtime program"
		return ""
	if identity in [Nefarian.HERO,Brukan.HERO]:
		var hero_issue: String=Nefarian.source_error(card) if identity==Nefarian.HERO else Brukan.source_error(card)
		if not hero_issue.is_empty(): return hero_issue
		if source_catalog!=null:
			var canonical: Dictionary=_card(source_catalog,identity)
			hero_issue=Nefarian.source_error(canonical) if identity==Nefarian.HERO else Brukan.source_error(canonical)
			if not hero_issue.is_empty(): return hero_issue
		return "" if _same(actual,card) else "Changed native damage Hero complete source"
	if identity in DamageResourceAdapter.IDS:
		return DamageResourceAdapter.source_error(actual,card,entry.zone=="base")
	if identity in Registry.SOURCE_IDS+Registry.TOKEN_IDS:
		var issue: String = Registry.source_closure_error(catalog,identity,source_catalog)
		if not issue.is_empty(): return issue
		if actual.has("id") and not actual.has("card_id"): return Registry.card_error(Registry.canonical_card(catalog,identity,source_catalog))
		if entry.zone=="board" and actual.has("_combat_id") and not actual.has("base_unit"):
			# Host-created fixed tokens retain _prepare's printed _base. Never
			# accept a missing base or treat live additive stats as that base.
			if not actual.get("_base") is Dictionary: return "Missing printed combat token base"
			var printed: Dictionary = Registry.template_for(catalog,identity,source_catalog)
			for field in printed:
				if not _same(actual._base.get(field),printed[field]): return "Changed printed combat token base: "+str(field)
			return Registry.runtime_unit_error(actual,catalog,false,source_catalog)
		return Registry.runtime_unit_error(actual,catalog,entry.zone=="board" or entry.zone=="hand",source_catalog)
	var definition: Dictionary = _ordinary_definition(catalog,identity,source_catalog)
	if not str(definition.error).is_empty(): return str(definition.error)
	card=definition.canonical
	var effective: Dictionary = definition.effective
	if not card.get("supported",false): return "Unsupported reachable source: "+identity
	if not actual.get("effects") is Array: return "Missing complete runtime effects: "+identity
	var proof: Dictionary = {}
	for field in PROOF_FIELDS: proof[field]=card.get(field)
	if not PINNED_PROGRAMS.has(identity) or _canonical(proof).sha256_text()!=PINNED_PROGRAMS[identity]: return "No unchanged complete native-program proof: "+identity
	for field in ["effects","tribes"]:
		if not _same(actual.get(field,[]),effective.get(field,[])): return "Changed native "+field+": "+identity
	if actual.has("text") and actual.text!=card.get("text"): return "Changed native text: "+identity
	if actual.has("kind") and actual.kind!=card.get("kind"): return "Changed native kind: "+identity
	if actual.has("golden") and actual.golden!=card.get("is_golden"): return "Changed native golden identity: "+identity
	if actual.has("is_golden") and actual.is_golden!=card.get("is_golden"): return "Changed native golden identity: "+identity
	if not actual.get("keywords",[]) is Array: return "Malformed keyword program: "+identity
	for keyword in actual.get("keywords",[]):
		if keyword not in STATIC_KEYWORDS: return "Unprofiled keyword capability: "+str(keyword)
	return ""

## Reviewed clause proofs bound exact fields, payloads and execution phases.
## Source hashing alone NEVER marks a clause safe. Unknown clauses fail closed.
static func _clause_error(node: Dictionary) -> String:
	var e: Dictionary = node.effect
	var t: String = str(e.get("type",""))
	var identity: String = _identity(node.owner.card)
	if identity in ["__triple_reward","__triple_gold_pouch"]: return Intrinsic.intrinsic_error(node.owner.card)
	if t==Nefarian.TYPE:
		return "" if identity==Nefarian.HERO and _same(e,Nefarian.EFFECT) else "Changed native Nefarian damage clause"
	if t==Brukan.TYPE:
		return Brukan.effect_error(e) if identity==Brukan.HERO else "Inherited Brukan Hero clause"
	if t in DamageResourceAdapter.TYPES:
		if identity not in DamageResourceAdapter.IDS: return "Inherited/non-native damage resource descriptor"
		return DamageResourceAdapter.Sources.wrapper_error(node.owner.card,e)
	if identity in DamageResourceAdapter.CHILDREN and DamageResourceAdapter.Sources.same(node.owner.card.get("effects"),DamageResourceAdapter.CHILDREN[identity]) and DamageResourceAdapter.Sources.same([e],DamageResourceAdapter.CHILDREN[identity]): return ""
	if t==Registry.TYPE:
		if identity not in Registry.SOURCE_IDS: return "Inherited/non-native damage_received descriptor"
		return Registry.effect_error(e)
	if t=="start_combat_stats" and e.get("mode")=="native_highest_battlefield":
		return HighestBattlefield.program_error(node.owner.card,e)
	if t in FIXED_BUFFS:
		if not _keys(e,["type","scope","attack","health","tribe","target_tribe","recipient_tribe","tribeless","require_keyword","exclude_keyword","exclude_self","count","repeat","zone","golden","allow_shop","temporary","keyword","permanent","combat_only","attack_from","health_from","attack_multiplier","health_multiplier"]): return "Unreviewed additive capture/observer field"
		if not _integer(e.get("attack",0)) or not _integer(e.get("health",0)): return "Only nonnegative literal additive stats are reviewed"
		if e.get("scope","self" if t in ["on_friendly_death_buff","on_attacked_buff"] else "all_friendly") not in ["self","target","all","all_friendly","all_other","other_friendly","random_friendly","random_other","leftmost","rightmost","rightmost_friendly","adjacent","summoned"]: return "Unreviewed additive selector"
		for key in ["attack_from","health_from"]:
			if e.has(key) and ("on_friendly_summon" not in node.parents or e[key] not in ["source_attack","source_max_health","summoned_attack","summoned_health"]): return "Unreviewed dynamic additive read"
		for key in ["attack_multiplier","health_multiplier"]:
			if e.has(key) and not _integer(e[key],1,3): return "Unreviewed dynamic additive coefficient"
		if e.get("zone","board")!="board" or e.get("temporary",false): return "Unreviewed temporary/off-board additive layer"
	elif t in RESOURCES:
		if not _keys(e,["type","amount","tribe","temporary"]) or not _integer(e.get("amount",0)): return "Unreviewed literal recruit economy clause"
	elif t=="economy":
		if not _keys(e,["type","buy_cost","roll_cost","upgrade_extra"]): return "Unreviewed economy field"
		for key in ["buy_cost","roll_cost","upgrade_extra"]:
			if e.has(key) and not _integer(e[key],-99,99): return "Invalid economy scalar"
	elif t in SUMMONS:
		if not _keys(e,["type","card_id","unit","count"]) or not _integer(e.get("count",1),1,7): return "Unreviewed summon capture/count program"
		if not e.get("unit") is Dictionary and not e.get("card_id") is String: return "Fixed summon dependency is incomplete"
	elif t == "spellcraft":
		# Reviewed fixed grant for this complete native family only. Waiting,
		# hand expiry and source cancellation remain the existing host policy.
		if identity not in Volcanic.PARENT_IDS: return "Unreviewed Spellcraft source in damage closure"
		# _graph_errors authenticates every complete source and CustomShop
		# projection before clause checks; do not re-interpret a live base as
		# native tier 4 here. This node must be the entire exact grant program.
		if not _same(node.owner.card.get("effects"),Volcanic.program_for(identity)) or not _same([e],Volcanic.program_for(identity)):
			return "Changed complete Volcanic Spellcraft program"
	elif t in GENERATED:
		if not _keys(e,["type","card_id","count"]) or not e.get("card_id") is String or not _integer(e.get("count",1),1,7): return "Unreviewed generated-hand clause"
	elif t in ["deathrattle_damage","on_friendly_death_damage"]:
		if not _keys(e,["type","target","amount","tribe"]) or not _integer(e.get("amount"),1): return "Unreviewed in-wave damage fields"
		if e.get("target","random_enemy") not in ["random_enemy","highest_health_enemy","all_enemies","all"]: return "Unknown in-wave damage selector"
	elif t=="start_combat_damage":
		if not _keys(e,["type","amount","amount_from","tribe","target","shots"]): return "Unreviewed start-shot fields"
		if e.get("target")!="random_enemy" or e.get("amount_from","") not in ["","count_tribe"]: return "Unknown start-shot target/scalar"
		if not _integer(e.get("shots",1),1,7): return "Unbounded start-shot count"
	elif t=="on_attack_damage":
		if not _keys(e,["type","amount","target"]) or e.get("target")!="defender_and_neighbors" or not _integer(e.get("amount"),1): return "Unreviewed pre-hit damage"
	elif t=="damage":
		if "rally" not in node.parents or not _keys(e,["type","scope","amount","exclude_self"]): return "Unreviewed recursive damage action"
		if not _integer(e.get("amount"),1) or e.get("scope") not in ["all_friendly","all_enemies","all","random_enemy"]: return "Unreviewed Rally damage selector"
	elif t in WRAPPERS:
		if not _keys(e,["type","effect","effects","options","count","tribe","scope","every","threshold","exclude_self","source_id","times","combat_only","limit","require_deathrattle"]): return "Unreviewed wrapper field"
		if not e.get("effect") is Dictionary and not e.get("effects") is Array and not e.get("options") is Array: return "Incomplete nested executable program"
	elif t in ["board_aura","mechanism_owner_aura"]:
		if not _keys(e,["type","source_id","scope","tribe","attack","health","attack_per_owner_tier","max_tier","duration"]): return "Unreviewed managed aura field"
		for key in ["attack","health","attack_per_owner_tier"]:
			if not _integer(e.get(key,0)): return "Unreviewed managed aura scalar"
	elif t in ["battlecry_keyword","spell_keyword","hero_keyword","deathrattle_keyword","end_turn_keyword"]:
		if not _keys(e,["type","scope","tribe","keyword","keywords","allow_shop","temporary","count","exclude_self"]): return "Unreviewed keyword grant"
		var keywords: Variant = e.get("keywords",[e.get("keyword","")])
		if not keywords is Array or keywords.is_empty(): return "Missing keyword payload"
		for keyword in keywords:
			if keyword not in STATIC_KEYWORDS: return "Unreviewed keyword grant capability"
	elif t=="on_damage_survived":
		if not _keys(e,["type","keyword","limit"]) or e.get("keyword")!="divine_shield" or not _integer(e.get("limit"),1,2): return "Unreviewed survival response"
	elif t=="deathrattle_repeat":
		if not _keys(e,["type","mode","multiplier","extra"]): return "Unreviewed death-repeat fields"
		if not ((e.get("mode")=="set" and _integer(e.get("multiplier"),2,3)) or (e.get("mode")=="extra" and _integer(e.get("extra"),1,2))): return "Unbounded death-repeat program"
	elif t=="battlecry_repeat":
		if not _keys(e,["type","multiplier"]) or not _integer(e.get("multiplier"),2,3): return "Unreviewed Battlecry repeat"
	elif t=="quest_counter":
		if not _keys(e,["type","counter"]) or e.get("counter") not in ["bought_minions","battlecries_played","spells","turns_ended_with_gold","gold_spent","rolls","sold","combat_attacks","combat_deaths","combat_summons","combat_deathrattles","friendly_deaths","summoned_minions","deathrattles_triggered"]: return "Unreviewed quest observer"
	elif t==StartingHero.TYPE:
		return StartingHero.validate_effect(e)
	elif t=="hero_immune_while_on_board":
		if not _keys(e,["type"]): return "Unreviewed hero immunity fields"
	elif t in IDENTITY_TYPES+HAND_SUMMONS+["trigger_deathrattle","on_attack_cleave","deathrattle_beetle_native","battlecry_beetle_native"]:
		# These are only classified after unchanged complete-source proof. Their
		# intersecting source/side/tribe witnesses are rejected below.
		return ""
	else: return "No reviewed complete capability proof for "+t
	for key in ["count","times","repeat","every","threshold","limit"]:
		if e.has(key) and not _integer(e[key],1,32): return "Unbounded invocation scalar: "+key
	for key in ["exclude_self","temporary","permanent","allow_shop","tribeless","golden","combat_only"]:
		if e.has(key) and not e[key] is bool: return "Malformed Boolean: "+key
	return ""

static func _same_side(a: int, b: int) -> bool:
	return a<0 or b<0 or a==b

static func _tribe(tribe: String) -> String:
	return {"beast":"野兽","BEAST":"野兽","mech":"机械","MECHANICAL":"机械","murloc":"鱼人","MURLOC":"鱼人","demon":"恶魔","DEMON":"恶魔","undead":"亡灵","UNDEAD":"亡灵","pirate":"海盗","PIRATE":"海盗"}.get(tribe,tribe)

static func _matches(e: Dictionary, card: Dictionary) -> bool:
	if e.get("tribeless",false) and not card.get("tribes",[]).is_empty(): return false
	for key in ["tribe","target_tribe","recipient_tribe"]:
		if not e.has(key): continue
		if not e[key] is String: return true # malformed selector cannot prove disjointness
		var tribe: String = _tribe(e[key])
		if tribe not in ["","all","ALL","全部"] and tribe not in card.get("tribes",[]) and "全部" not in card.get("tribes",[]): return false
	return true

static func _recipient(node: Dictionary, family: Dictionary) -> bool:
	if node.effect.get("type") not in ["hero_steal","spell_prize_steal_tavern","spell_steal_shop"] and not _same_side(node.owner.side,family.side): return false
	if node.effect.get("scope","")=="summoned" and "on_friendly_summon" in node.parents: return false
	if node.effect.get("scope","")=="self" and _identity(node.owner.card)!=_identity(family.card): return false
	return _matches(node.effect,family.card)

static func _hits(node: Dictionary, family: Dictionary) -> bool:
	var e: Dictionary = node.effect
	var source_side: int = node.owner.side
	var target_side: int = family.side
	var target: String = str(e.get("target",e.get("scope","random_enemy")))
	if source_side<0 or target_side<0: return true
	if target in ["all","all_minions"]: return true
	if target in ["all_friendly","self","all_other"]: return source_side==target_side
	return source_side!=target_side

static func _in_wave(node: Dictionary) -> bool:
	return node.effect.get("type") in ["deathrattle_damage","on_friendly_death_damage",DamageResourceAdapter.COUNTER_TYPE]

static func _is_damage(node: Dictionary) -> bool:
	return node.effect.get("type") in ["deathrattle_damage","on_friendly_death_damage","start_combat_damage","on_attack_damage","on_attack_cleave","damage",DamageResourceAdapter.COUNTER_TYPE]

static func _co_lethal(state: Dictionary, family: Dictionary) -> String:
	for node in state.nodes:
		if not _is_damage(node) or not _hits(node,family): continue
		if _in_wave(node) or node.effect.get("type") in ["on_attack_cleave","on_attack_damage"] or node.effect.get("scope",node.effect.get("target","")) in ["all","all_enemies","all_friendly"]: return node.path
	return ""

static func _anchor(entry: Dictionary) -> bool:
	if "reborn" in entry.card.get("keywords",[]): return true
	for effect in entry.card.get("effects",[]):
		if effect is Dictionary and effect.get("type") in ["deathrattle_summon","deathrattle_summon_history","deathrattle_summon_from_hand","deathrattle_beetle_native"]: return true
	return false

static func _token(family: Dictionary, catalog) -> Dictionary:
	for effect in family.card.get("effects",[]):
		if effect.get("type")==Registry.TYPE: return _card(catalog,str(effect.get("target_catalog_id","")))
	return {}

## Explicit initial implementation limits for Orca's new group action. A native
## damage text is broader than this host domain; these are not official rules.
static func _orca_interaction_errors(state: Dictionary, errors: Array[String]) -> void:
	var families: Array=state.cards.filter(func(entry): return _identity(entry.card) in ORCAS)
	for family in families:
		for flag in ["silenced","abilities_disabled"]:
			if family.card.get(flag,false)!=false: _append(errors,"Orca inactive source remains gated: "+family.path+"."+flag)
		for node in state.nodes:
			var t: String=str(node.effect.get("type",""))
			var witness: String=node.path+" → "+family.path
			if t in ["battlecry_damage","spell_damage","hero_damage","end_turn_damage","recruit_damage","damage_minion"] or ((t.contains("damage") or t.contains("cleave")) and not _is_damage(node) and t not in [Registry.TYPE,"on_damage_survived",Nefarian.TYPE]+DamageResourceAdapter.TYPES): _append(errors,"Orca recruit/unreviewed minion-damage dispatch remains held: "+witness)
			if t in IDENTITY_TYPES and _same_side(node.owner.side,family.side): _append(errors,"Orca group recipient capture/SET/multiply/copy/transform remains held: "+witness)
			if t in ["on_shield_lost_buff","on_damage_survived","on_attacked_buff","on_friendly_summon_buff","on_friendly_summon","on_friendly_death_buff","on_attack_buff","on_stat_gain","on_attack_gain","on_health_gain"] and _same_side(node.owner.side,family.side): _append(errors,"Orca unreviewed Shield/damage/stat observer combination remains held: "+witness)

static func _interaction_errors(state: Dictionary, catalog, errors: Array[String]) -> void:
	var families: Array = state.cards.filter(func(entry): return _identity(entry.card) in Registry.SOURCE_IDS)
	for family in families:
		var id: String = _identity(family.card)
		if "reborn" in family.card.get("keywords",[]): _append(errors,"Source retained-enchantment Reborn boundary: "+family.path)
		for node in state.nodes:
			var e: Dictionary = node.effect
			var t: String = str(e.get("type",""))
			var witness: String = node.path+" → "+family.path
			if _in_wave(node) and _hits(node,family):
				_append(errors,"Repeated in-wave pending-body target is unproved (multiple copies/repeats/queued corpses): "+witness+" ["+str(e.get("target","random_enemy"))+"]")
				if id in SUMMONERS:
					for corpse in state.cards:
						if _same_side(corpse.side,family.side) and _anchor(corpse):
							_append(errors,"Unfinished same-side corpse insertion anchor: "+witness+" → later "+corpse.path)
			if t=="trigger_deathrattle" and "rally" in node.parents:
				for producer in state.nodes:
					if producer.effect.get("type")=="deathrattle_damage" and _same_side(producer.owner.side,node.owner.side) and _hits(producer,family): _append(errors,"Living Rally Deathrattle can repeat damage before outer cleanup: "+node.path+" → "+producer.path+" → "+family.path)
			if t in IDENTITY_TYPES and _recipient(node,family): _append(errors,"Source capture/SET/multiply/copy/transform/ownership boundary: "+witness)
			if t in HAND_SUMMONS and _same_side(node.owner.side,family.side) and _matches(e,family.card): _append(errors,"Source hand-summon persistence boundary: "+witness)
			if t in ["battlecry_keyword","spell_keyword","hero_keyword","deathrattle_keyword","end_turn_keyword"] and (e.get("keyword")=="reborn" or "reborn" in e.get("keywords",[])) and _recipient(node,family): _append(errors,"Source Reborn grant boundary: "+witness)
			if id not in SUMMONERS: continue
			var token: Dictionary = _token(family,catalog)
			if t in ["on_friendly_summon","on_friendly_summon_buff"] and _same_side(node.owner.side,family.side) and _matches(e,token):
				var lethal_path: String = _co_lethal(state,family)
				if not lethal_path.is_empty(): _append(errors,"Pending matching summon observer: "+lethal_path+" → "+family.path+" → "+node.path+" ("+_identity(token)+")")
				var action: Dictionary = e.get("effect",e)
				if (int(action.get("health",0))>0 or action.has("health_from")) and action.get("scope","") not in ["self","summoned"] and _matches(action,family.card): _append(errors,"Received summon can feed Health back into pending bodies: "+witness)
			if t=="on_shield_lost_buff" and _same_side(node.owner.side,family.side) and e.get("scope","self")!="self" and _matches(e,token): _append(errors,"Shield-loss/received summons have intersecting recipients or capacity: "+witness)
			if t=="on_attack_cleave" and _hits(node,family): _append(errors,"Cleave can expose multiple received summon/capacity order: "+witness)
			if t=="damage" and e.get("scope") in ["all","all_enemies","all_friendly"] and _hits(node,family): _append(errors,"Multi-recipient Rally/received summon order unproved: "+witness)
			if t=="on_attack_damage" and _hits(node,family): _append(errors,"Neighbor pre-hit/received summon target order unproved: "+witness)

static func _graph_errors(state: Dictionary, catalog, options: Dictionary) -> Array[String]:
	var errors: Array[String] = []
	_append(errors,schema_error(options))
	if not errors.is_empty(): return errors
	if not state.active:
		if options.get(FIELD,false):
			for issue in state.errors: _append(errors,str(issue))
		return errors
	if not options.get(FIELD,false): return ["受伤响应默认关闭；请明确开启 damage_received_listeners，再验证所选来源及组合。"]
	if options.get("beetle_growth",false):
		for entry in state.cards:
			if _identity(entry.card) in Registry.SOURCE_IDS and _identity(entry.card) not in ORCAS+PUPPIES: _append(errors,"Received-summon/Beetle combined owner lifecycle remains unconnected.")
	for issue in state.errors: _append(errors,str(issue))
	for entry in state.cards:
		var issue: String = _source_error(entry,catalog,options.get("damage_listener_source_catalog"))
		if not issue.is_empty(): _append(errors,entry.path+": "+issue)
	if not errors.is_empty(): return errors
	_orca_interaction_errors(state,errors)
	if not errors.is_empty(): return errors
	for node in state.nodes:
		var issue: String = _clause_error(node)
		if not issue.is_empty(): _append(errors,node.path+": "+issue)
	if not errors.is_empty(): return errors
	_interaction_errors(state,catalog,errors)
	return errors

static func room_errors(config: Dictionary, catalog) -> Array[String]:
	return _graph_errors(_room_graph(config,catalog),catalog,config)

static func reachable_cards(config: Dictionary, catalog) -> Array:
	return _room_graph(config,catalog).cards.map(func(entry): return entry.card)

static func errors_for_units(units: Array, catalog, options: Dictionary = {}) -> Array[String]:
	var state: Dictionary = _state()
	state.pool_ids=options.get("damage_listener_pool_ids")
	for i in range(units.size()): _add(units[i],state,catalog,0,"units[%d]"%i,"board" if units[i] is Dictionary and units[i].has("uid") else "catalog")
	_drain(state,catalog)
	return _graph_errors(state,catalog,options)

static func errors_for_cards(cards: Array, catalog, options: Dictionary = {}) -> Array[String]:
	return errors_for_units(cards,catalog,options)

static func card_error(card: Dictionary, catalog, options: Dictionary = {}) -> String:
	var errors: Array[String] = errors_for_units([card],catalog,options)
	return "" if errors.is_empty() else errors[0]

static func combat_errors(left: Array, right: Array, options: Dictionary) -> Array[String]:
	var state: Dictionary = _state()
	var catalog: Variant = options.get("damage_listener_catalog",{})
	state.pool_ids=options.get("damage_listener_pool_ids")
	for side in range(2):
		var prefix: String = "left" if side==0 else "right"
		var board: Array = left if side==0 else right
		for i in range(board.size()): _add(board[i],state,catalog,side,prefix+".board[%d]"%i,"board")
		for suffix in ["hand","sources"]:
			var zone: Variant = options.get(prefix+"_"+suffix,[])
			if not zone is Array: _error(state,"Missing complete actual "+prefix+"_"+suffix); continue
			for i in range(zone.size()): _add(zone[i],state,catalog,side,prefix+"."+suffix+"[%d]"%i,suffix)
	_drain(state,catalog)
	return _graph_errors(state,catalog,options)

static func combat_error(left: Array, right: Array, options: Dictionary) -> String:
	var errors: Array[String] = combat_errors(left,right,options)
	return "" if errors.is_empty() else errors[0]

static func saved_error(state: Dictionary, catalog, room: Dictionary = {}) -> String:
	for group in ["players","ghosts"]:
		if not state.get(group,[]) is Array: return "Malformed damage-listener saved owner array"
		for owner in state.get(group,[]):
			if not owner is Dictionary: return "Malformed damage-listener saved owner"
			var cards: Array = []
			for zone in ["board","hand","shop","mechanism_reward_queue"]:
				if not owner.get(zone,[]) is Array: return "Malformed damage-listener saved "+zone
				cards.append_array(owner.get(zone,[]))
			for field in ["hero","anomaly","trinket","quest","reward"]:
				if owner.get(field) is Dictionary: cards.append(owner[field])
			var options: Dictionary = room.duplicate(true)
			options.damage_listener_pool_ids=LobbyTribes.preview(room,catalog).get("enabled_minions",[])
			var errors: Array[String] = errors_for_units(cards,catalog,options)
			if not errors.is_empty(): return errors[0]
	return ""

# Immutable baseline source-program digests, generated once from the stopped
# baseline's merged native definitions. These do not expand capability scope.
const PINNED_PROGRAMS: Dictionary = {
	"BG34_318": "7f639ed31bc73c543c1e6635a252f29caab107f85a4fb6235a98c1ddeeec9b0a",
	"BG34_318_G": "c2b232d0c3b09d719aafa1f930dac0174feab60d74c5e3fe610f8c6edd2787b4",
	"BG30_117": "e2e92ee7ac1c3d596f0d22cedf1a02475b79399bbef905108d0a8105ebc709ec",
	"BG30_117_G": "d0869b2a00829c15bc5dcaf05d1934e3b2f3ec701ebcaeb461422b858da04377",
	"BG30_117t": "6a553a57915b66c978084a2e15887713c3cb653745094577e4ffeae8d0b79c15",
	"BG30_117_Gt": "35cb043874f64722b3e9d7a14862c03ef02fffc97c171ecc0fd2135edc705276",
	"BG30_117t2": "80870454677321fd7a53f492d51b89fc0adf2783bf4ff7585f56a56ebcf61e74",
	"BG30_117t3": "f97ef4a8e0b3318c5b887feaad7f3888e0e2d4fd5a4a5d648c9a6a61bf973abb",
	"BG30_117_Gt2": "12d79ce0e4f8c8c3e80685c155759072556ad8adac0110f05576db3b5e54a778",
	"BG30_117_Gt3": "8e73ed265cada37fe3c1f1237a9f141085ce845ad721692214d96cfea16c564f",
	"110298": "94c0885da04da7af4b97265bd7a4caa93e883dc50799b626eab871d6373fa980",
	"110300": "8f5426c284bf9f092f0c7cd750c41720878c30973ac2b05724a33eaf2f807eeb",
	"110350": "bbfd7db8a73fb0210e26ea9f53831db154ec9e9d6b5dbab4c80be4ea9da6e408",
	"BG19_010": "5e2993b4b38d56281b3ea168dbfe3e6bcdbed02fb1a633ab04480fe188232e7c",
	"BG19_010_G": "e1548e87b39a6f1e19a18e21a50995112de38505d85bcf116d6ad1d5a727a043",
	"BG19_010_Gt": "9835d89b4893ed91e7805197c4d2640552910515c834dc729e830bf1bf161bac",
	"BG19_010t": "e105d0656bc60c149165513f053924d80ce3b7ee760905928ad17c0762acd037",
	"BG20_100": "a5b1e943cd861c4e8037f69a82947c99d36f9ead3a38c1f545d0b33c5ea10822",
	"BG20_100_G": "29a7ac4ae7638c2c5c37014c9fd263af4c186ef34b2e62fd3520a9239e4e9c02",
	"BG20_101": "0363b9d93998059560f253608eff6e28f1b1c5a45e3b28555dc77923d44c8a5c",
	"BG20_101_G": "d9d86fae32c42f5d4010d0d350171a79542931626041b69d2e3b195318973d92",
	"BG20_102": "509fe63d11ca9c8de01f62a47fa6ed04f2571e343564983136639be2a3ebacf7",
	"BG20_102_G": "b6264035c84c7106e4aa4eb7b04227ddb63f019caed0e64fc28e653a1126c867",
	"BG20_103": "a63e7a321c0219884a7db8796d21d0928e7da9e93121de9218d373851baa9f8d",
	"BG20_103_G": "20e1d9a49963853294ef79f88255d2b083fa138f4cee1d97d18daf1a3837c52b",
	"BG20_105": "372ec96b296bc9368f2ededaf017335e6060bc7f91e8fce4b34f777087364685",
	"BG20_105_G": "9c3eb9842dfee1183de3a73854597fefaa3adf89cb914811021f4af6700a8596",
	"BG20_106": "bf1c8976035fabf7c0c769d7369ddc56b31c70572f92f8aaf5dcd672045d4791",
	"BG20_106_G": "c8c337fa645e67d2cba29335a35c544511cdb975880aaa7cbd8d3587552e9ace",
	"BG20_201": "5e46421405f43e76e8f4ca5e92319c83e549e4330c7f91e091c55deab3c26653",
	"BG20_201_G": "5477b8e4517c8092699649fa4722e4f79ce267596f80e1b0864967d7a4f7ecde",
	"BG20_203": "31287d4d78e76f3faddc873d464e09b8e8147220b02f9f56c725b2074b8e4d67",
	"BG20_203_G": "5dd01ef9b80d9c0278031f34c407d43bfca47e02bdc91b737deacdb460971f65",
	"BG20_204": "731ae7461ffa6fb971f9f292fa921c16420c2fddc557f3b9ebed69851c9ebdc8",
	"BG20_204_G": "5562ddbb52727721274f7da57a98bc4dc5a78ab365f2a420801eb1f1b42cf603",
	"BG20_205": "8588eb204699f86fa229149877a2562c5ef41bd32d5c2f2a17574c8713060fa8",
	"BG20_205_G": "9ecf3c9c0c00b45b8f3c230c59ab3fb30ba7f64bd5e54b9430379ff0f70c2c8f",
	"BG20_207": "2edd822577dbe8fad3cc0872652889b54cfcb550f7cc35438d46870cf5690db7",
	"BG20_207_G": "a66f63d6f81d812f7120cbce5c76989a0d463eed9e58cbf403c993b277f24308",
	"BG20_210": "f7dc07ccdb8a07eca0c1d3f6377d97100ea250deb9016ee3b6ff26341b9906cc",
	"BG20_210_G": "7c738972757cddebcc26bad57e00328eac32c08b3ff8633ade1f1781bba53e03",
	"BG20_301": "8e9f4986a05227f366c65b2f4bc628c4a185dd3725bd401bf93aea026184404f",
	"BG20_301_G": "785c174d3d152629c9206b5502f70666b8334f5de4af706cf6adc2452ad1423b",
	"BG20_302": "e93646066b11a960b15bd9bd9e73007afab1ff6da58a9fc9b0dced31c57d4632",
	"BG20_302_G": "4a7de723b7bda06f191af08e74971a055e5b97f361b95bcd2b03a277bd6c4756",
	"BG20_303": "3f51859e5cbbc4d7d779cfa6c41f7be77dc7c5afd683d4eb9b353ee0b1890140",
	"BG20_303_G": "acc0544474a53bb554ce35bb072c7c956fa4c27b80f40bebb4103b7fba82e894",
	"BG20_GEM": "4d6ed4edb8ea70ae8647f59b5fb6dfba560f362d5755e6f8ec79816662a65c36",
	"BG20_HERO_101": "ebdb0767775a9df2b5d496ea6cce4386d6827597e723c218d385969f6b849915",
	"BG20_HERO_102": "9115d0ab4787112cbf7e9763a77edcfab05f5ece3daafc5d826c747e6415e05f",
	"BG20_HERO_103": "70af027249a4b655e0a7725defe46d2d55a936e7febcb3873c8153f43dc54480",
	"BG20_HERO_282_Buddy": "516cd2c2bd974676e78455f4be2080a355cb576a64aa62aec55546ba7fdf58e9",
	"BG20_HERO_282_Buddy_G": "5b05cd797230f7b304337d66708ff203aab4e37c74f305aba89185aebf281d9e",
	"BG21_000": "cfdba3a461e6e01cb434aeed65d5d401a585455dc4262a071ba69efc277ec7ae",
	"BG21_000_G": "bcdf3fa15ec7ea8b045d3b135e46aa5aa2c7527c32b600ec34b4d6f1e8c11175",
	"BG21_001": "9d8f75c0b08fb59cb669b71aedd3509d6c4f688428ef3ae39f57c2f6bc3dd523",
	"BG21_001_G": "c1fe714195c79453f86213d7d8fec8c82e08e4e39d918451a270166ff6d2f85a",
	"BG21_002": "edc61e5e893714d4dccad72b5bee6d57766936f29413b1aaedc137b9af126efa",
	"BG21_002_G": "ab7ad70d269dcee146b7e2630647c692811fb406c2f2c668b6df980e3698ca29",
	"BG21_004": "823b8d68244d9425ea91169f1ee69c908f21f1a937649ad78e514752a85d7a0b",
	"BG21_004_G": "6a24bf1c288e6fcc91426142a527e840bf2de9232699293e5d73d7d39a5f33b4",
	"BG21_005": "6756f2cfba25b9791bae0bb1b9d5b4ced78e95ff7f0a23c1c4767a2c802669f7",
	"BG21_005_G": "776b5048190b9a74d867dea7e05af6c7c5e7599c6238fe3d016976843b979da3",
	"BG21_006": "ded0892825a9f59d96aca40c3096fa7d8e6d6850b566870a80087bd8b3f0e528",
	"BG21_006_G": "b6bab58475a9ce568f9a7e038cf87031e7517971613b571e5d55f8ab96d019ce",
	"BG21_008": "15d275eefa276701607aec370c06bf2bb888c8eec1d0f18c0d28e75c45e808e3",
	"BG21_008_G": "d2e8efe4d31a83f776e42a90efa69a4ec700482aa9a8b24ad8c7bdecf0376860",
	"BG21_010": "cce3a8f526f95a361d4cc309e0314e49c7afc68e19ecea925b1e0d6c905863df",
	"BG21_010_G": "b14c757cd4038ce86702996d885a5d20157f9cd58897e2845156e19e6cd39148",
	"BG21_014": "717eb002d91f98c022565ef857516d6af24cd10a275f189c4e0659326e96d850",
	"BG21_014_G": "c6119ddce733d0e2af2dbce2b87a649af8615336f48c31ed78119dcab3e4a33a",
	"BG21_016": "b997fb744166499785711f801eb5ad37d86c08028e29c4ed200800c7a8a06b64",
	"BG21_016_G": "5f201fbf98a5a67dad986a87a8097d4d4fcaf9217a540ca92bdb900ae9fde1be",
	"BG21_017": "37bfed7c07dc963e038110d5ef7bbd1a05445aa33ff6141902251f2a16eb7992",
	"BG21_017_G": "064272237cd9e8b4c5f3afbb7bc3372c267ea228e6d1e8a96c80509f76fadfc3",
	"BG21_020": "56e264c7fedac52e8bf8944cb4877083e6107aa4f7352918a470bffd5906131c",
	"BG21_020_G": "b13c3dfae8c47da417cd03def1ad2c1b4067d5230f0116ff781d8538e1e46b84",
	"BG21_021": "87cc1b0197257133605808ba0235b0e2f136d63174478427e91bd7f1cedd99f5",
	"BG21_021_G": "32346f2514cefc40e7cd08a7af9e91ca70ab8abd62b33f12bc3035897bf26db7",
	"BG21_022": "acf1b4d041d42f90ac299423282505cb31e8a691220422e423cf822817bfe442",
	"BG21_022_G": "c5fb24ecd26560bd3a5c7be2f3716e68e9843d7446e4f02448626ae0e9bc7b77",
	"BG21_023": "2d6d228ca6b0a61351bf093e85d2a41dfd9540c708ee7ed880fe409696c9bb18",
	"BG21_023_G": "260daa231a668a0439aa6b24f13b9ca47b9420f0cc80803cea7680394ced6e05",
	"BG21_027": "eeaeb161e414f50f59fa989ed546068834084a09f25766bfc770ae24d156593a",
	"BG21_027_G": "9e2ee7d30395f8b5a061c1f0be4793c6b323c0ac14c943a6d809d4728a1447ce",
	"BG21_029": "dadebd213d37b91b7850797ed067a2d89873728f043098d7bb0240bd8e172aba",
	"BG21_029_G": "68e3974f48d70d92727fc8f03efb7eeebbbc9696ceeb82751a886b378008c774",
	"BG21_039": "8be181779cadc5690af4a53713ba81147d0b954e265e90397102ca4faa3a9fae",
	"BG21_039_G": "86086c8f6e7b1c11c09b0987e3f87c2a9c65fe1bc5b2f8227e905ec375e105c1",
	"BG21_040": "b31e15458d85bdbfdf98f4efad3a758d9b067349912635698436e2b23284c3f5",
	"BG21_040_G": "eb5a9901aa84958c35e50d7c1dffc6990dbf7ff43772c7b67ee7f4fe65e8f9bd",
	"BG21_HERO_030": "b81120c9814b037b230c532a7034b18875db7d068f4c2c20e0491d15eb3dfc77",
	"BG21_HERO_030t": "e3943140a835817abf7de111fad0794d0743f716256247418a7030fbf52332a1",
	"BG21_HERO_030t_G": "b8365dc74605580588b5a82bf6d1dea32826db11f440b6e68f02b314db965e45",
	"BG22_001t2": "426fc7cff31f56ecf672e17a60c06fb119b1155aac9151d8f7e1e2c1a1d8d592",
	"BG22_001t2_G": "162f6c81100c7d1b9abd6efcbb900636c28d09bfc0c838c94495ccb86660c599",
	"BG22_202": "0792c2c36aea6eb97499e1d46db95a0ed42734e37cdb261292490792aabd45da",
	"BG22_202_G": "a0b628f5dcd89b2c3ba6fe7a712b953b47df46c98aead405ee4a8658c0341571",
	"BG22_401": "20c8cf15dfd9b9fead6b21d0025991e93d3d75fa9c6b64c19d65a8eed1e2c848",
	"BG22_401_G": "1488a06ddb95c22fab848bcbd0ad702cae748c242fba695e5bd1b711c2f23f44",
	"BG22_HERO_002_Buddy": "b54962c2f8383b9eee511e6ab9d983515b496e63ca7dd3009464bff30a04ae22",
	"BG22_HERO_002_Buddy_G": "10675e3b2411e17008eec44ee8c00431573256dcf02651336c71fe91ac910d77",
	"BG22_HERO_003_Buddy": "3bae6ab7385e02cde65cb5081fd1c8c603961c6f14b20258d1516dd8ab992ef3",
	"BG22_HERO_003_Buddy_G": "b57ce821caead86a494f1d22226a71f5d49fcca2fbbd0a86ac6841d96a604d67",
	"BG22_HERO_305t": "1ca5cfe20b2ec33d6bd92f1c2b5a7386b671dc513bcb50e72c66940cfd00e6b5",
	"BG22_HERO_305t_G": "0951e424d5d9d23226e58f64c2af197e25c40ca8131e3c4d6f25d795aa38b3c3",
	"BG23_000": "39a9b40c0a4e5f909d10b606319304affb49fee16211a9ec7fd674dcce4e5d1a",
	"BG23_000_G": "e0038bf513228885cd420345d56d68f23407816f0ac098af384f1684ed0d8f5a",
	"BG23_000_Gt": "eaefda3827849afe714655dfa2cf52f6c702526960106eb02fcf7580e501e497",
	"BG23_000t": "c1e42393309536eee6d6e509569066d3dff18cc55994520d83c72c2c2386d4cd",
	"BG23_001": "cf8d1718814cf2bbf8192dd473b495b658ce077dcd58ca95be03c8132b92b4d3",
	"BG23_001_G": "3916fce5b0ad1d348d219339dbdd921eea92fbaa7b3544fc013a2cf9f79c2584",
	"BG23_002": "2cf647b2dca3eea38f5c3a59c5a098f3b5ae2969d013d21a014bdec89c3bf07f",
	"BG23_002_G": "fd840e5ea2fb753f1757f8602877b9f5ef09b26848ac02d1ce71b96f9fad73e6",
	"BG23_003": "8f6e33701c70720f95efa96f26656f35795851a26a866d425086e925bd34e513",
	"BG23_003_G": "7a0575fa4df9bd1729078ccde8d074f8673a22b25f6a6b9b467803b017444b80",
	"BG23_004": "3664b634e3979b6450bfcbc8eb159ba0f716da0b2eb90e4d18a40ed254515ec8",
	"BG23_004_G": "dfef9a0f8cb52d3aac2f85138aba291de67fe9e759af3f8fe72a43e5ab6c7d3a",
	"BG23_004_Gt": "a35dc7905719bdaf0af042551eb3b63e19d39a6a30a0ba2d7c0fe3a4e7c95d3d",
	"BG23_004t": "9bdf73b57b8220fa8d92fd9ee5c3239e809e45337b97e0afdf62eb6216c6a4a7",
	"BG23_006": "ce96b88eb2e4e9a305f30f12d7b7b738c7fca6ef8d282632906f14cd01bc270a",
	"BG23_006_G": "d7390cf64a43b7bb3a192b79a7be5c8d4e0cd782b9b9c9e50327ba57f17d68de",
	"BG23_006_Gt": "e4fb6df59360c0cd813fbfda15ab593b694c0ea549d9bb0b30a4f8f5b78cbb5a",
	"BG23_006t": "edd992e5e6d909bb7a2978519843161fe66ce88963f3300bb4cd7de36023ef0d",
	"BG23_007": "792bd3103826dffa5d13b3646a7c7ff2b3bf35e82493bc24994429f3574ec34d",
	"BG23_007_G": "efc58fcbec8ecc36b9f615b0b77e0a068a9980b0a5a96f1db3e43475a5e7ee05",
	"BG23_007_Gt": "9eb631e9f5828be6254f70a674fdfd206b16ff5f52e9f40729043723459f1575",
	"BG23_007t": "3c5d315b75168728a073d3f3f9f91e9281a713e380217389cd9f3203f17c2bc5",
	"BG23_008": "2b87458af32b5c1c2b8b741f5e8ce2f072685c22174a7e961731703ed5895c36",
	"BG23_008_G": "84fda5a852a6ebc6497c17319e1f58db0f832371fdae8cbbca424b637ddfb7da",
	"BG23_008_Gt": "7e371fbfced135c02cc949e87001b8b40a53c95dceda52b9c5fcd7e561bf33e1",
	"BG23_008t": "e17e21b5e6d4b0ceff6646dd9b7c6b148b84d7e5532190b85f83b7280374e675",
	"BG23_009": "dfe0cd3915476fd9469d8bdd57a4fa1c739d5e4ab884486ab77fe7997c974e5b",
	"BG23_009_G": "0ee5de898a32d5a7239a00ed622377110666b937a0aeb95a8aeb9d7bb7a91e08",
	"BG23_010": "782ff4d7bf7ab737d88c65d04fd6da84eac7b9b6b76e5e70affcc7d057548227",
	"BG23_010_G": "6af800b0c3a9f3a2e93b05bd9647fc98e455a26fb4799126c513b05373c415f0",
	"BG23_011": "7719cfb5981b4ace57a98858148f08a18a67c4524f0cdb4e6a40fb56cfc91018",
	"BG23_011_G": "50e502178f668af8137ac646637e23c819823661d16b3f2f338befc265a4ef5b",
	"BG23_011_Gt": "1a2dea46540462a7742832616018458d5618ca14c69f9a70b8ab8850f7c0ea4f",
	"BG23_011t": "731fe7c315e5db8b7d115e79dc9da11330777f27c9d3644b7a7ed9906a92b0fa",
	"BG23_012": "c80225e105f97977f02a05279913cddb7f19aeba490b81829a373f60f038182a",
	"BG23_012_G": "567cdd5d92b6449dc23e21a117d26a72b99ad4789214037a7bebcdb644141211",
	"BG23_013": "e8ae716b067330ba6694deb3de1508e9a0039c2158b606e5f7413ad66c80855b",
	"BG23_013_G": "4d4e5b0893fd238627b391084fed213d1c4f740c9189c4f2f6bb9fbc1d3584ec",
	"BG23_015": "9af11acbc54fbbbf1a443d2f50402e93ba07d0784c9f8bcfe65a04e3eab266a7",
	"BG23_015_G": "0cdbe575fc2f876a3e68a00791ed2461945bac270ae02e3878e915019b1939c3",
	"BG23_015_Gt": "57eb712db4a0bf6a99f3b7cb34cea161013d93893963afa4b53de784e7119148",
	"BG23_015t": "038cbb616c060a9dad10c4f1031c025ddde60f8e737451c5cb3775cf91a2f90a",
	"BG23_018": "62ad15adac71a682e096211c3de94d12ff65a3c17f9cdf9dcfcb0c1e46121ce9",
	"BG23_018_G": "06b15bb6e0a76826aa8747318a9b429e7089833f22ca9b38c8edd293618b285c",
	"BG23_190": "90a20b65bbf04ebf37d5d2982efedfefbac137222e78684d0276e548d3a44ec7",
	"BG23_190_G": "5f2e25202d59cba25a31e79d55441835f95b84dff0956459dc53a4ca4138e1fe",
	"BG23_192": "85925b4aae7dd7c1362ee666303c68a73e5ed4ee1ffe91f27ddcc400cc8f70ef",
	"BG23_192_G": "a6951f48aee65cf06397d49505a7c4ace1fbbcc3ae04c00c30c73512cdcb5fb0",
	"BG23_318": "bf92904fa3b0492863c98ec21cc1133cb146ef132a87f047bb6db9fb82a4d8c6",
	"BG23_318_G": "16bd75c97b25e133cb8ad64d0a5560153cb444d2a2f84139c1bd5a4018a632c6",
	"BG23_352": "ab2596cab404295c87ad92524f7aab0cba79b3842b4a46dacab590ccfd9fa1f8",
	"BG23_352_G": "955d2e0b0734990aaeab5aa0f4e2f4c24f8c6f74a2ed605f8e8e8c86da19632f",
	"BG23_357": "2c875048faf88d6c4e553b5b3c8f04b1a645fd5078b3aa1eee990f78345f13c9",
	"BG23_357_G": "dda47427c01f59b032d20c52f09028f3bc6d40b1195bfd413d2cb46f6915983b",
	"BG23_361": "0254a1cf2bfb3b5f37756664da35bbd10236036c1680595eab75591183234bf8",
	"BG23_361_G": "10eac9a19fd309b22cfc898e1863a9185ed2edef5c87f280fe5111021ab2d1ae",
	"BG23_362": "b3c6f4586343a5b556910b74ce593bad51a9bd7ddb7c886b4e665fff41693826",
	"BG23_362_G": "235e706026a7cffec96042b2e2fd285c6e2efe54707d945094cce7c8ed77a8b6",
	"BG23_HERO_201pt": "1d7f91df9e82842b736240ad336cf57b472df9678f1482f0a9e3c771f3940c4f",
	"BG23_HERO_201pt2": "22ea8b1337d3a8206a63848bdb1823715a3698e7f046ce2188361100a67341f2",
	"BG23_HERO_201pt2_G": "253fccccef29062d9274aa40895803a1b2b77d3cdd4dc02c9a1f3aa0cf35d227",
	"BG23_HERO_201pt3": "8acac364e227954b77897dd8714f448fba81e8dcbd933510741da471dae7ebbb",
	"BG23_HERO_201pt3_G": "068a94ca41764da62185e9747aacecb5288f428d5a9c781778560062dd114b81",
	"BG23_HERO_201pt4": "a25e8c753bef240066c458abc3ae181994b96ff7b79080f140229246a56fb7ae",
	"BG23_HERO_201pt4_G": "99be3f20c264cde67db38b79a10c1f095cfacd1ee72fc02fa45c557ea685ce32",
	"BG23_HERO_201pt5": "d18e0dd1c195347880b9ce6fc4391dc93b5e8bff94776c42ab42e5d85b229964",
	"BG23_HERO_201pt5_G": "a62033dcbadebce54524041f3b2053f53e955c4104a568fcc10e80605a3b790f",
	"BG23_HERO_201pt6": "3c1e410f1aa633c723d13efba8d28dd67018eca9e91d862b96c0bd91516e1b07",
	"BG23_HERO_201pt6_G": "9fc2b0b3f520be1ae942dc342940bfc267641771a5c495064d154112c392a35c",
	"BG23_HERO_201pt_G": "3c0b5dbbe65b3e0dae39bf976741118bf1dffa3640a1eeaf8753abc510f3540a",
	"BG23_HERO_305": "4f3577b5d6e6384952e71a29132bdf0e86236531adcde48e1129016f85317af4",
	"BG24_004": "035a9966d6d5854ef84e7902b39d158fb602464e2458b4f48b8766b3e4ac4339",
	"BG24_004_G": "178183e05de62df38e2d48711c601a0b648aa514ccc5e0b02c905a95d75c1bc8",
	"BG24_009": "f9f3c2c8230153ca08e6b150097e9c50034d5b1b2adf9fcd5682c0fa52339be5",
	"BG24_009_G": "bc19d2b3f0a1c7b4c089882b4adcab6cfe1a49bf278e326ffe7c66139a95dde1",
	"BG24_012": "cb43f1b50401d68a4a81cbd23231a8d70a7f71bdecde49a0efb6f6743d9e8ba2",
	"BG24_012_G": "0bc5b78558c78102781023cc17d1d88ed2fa0042512d985f191c3522a25f6b6e",
	"BG24_018": "0d0fb645fc34588ac483f4c406c2586ba8c3157bea3801adcdf5fb20d7b743ba",
	"BG24_018_G": "e0a292cab5817c930d9ebcd9d7c69607235017ab1a26d3d15f29011d74b60aba",
	"BG24_020": "6c4b458b38ee584c86750441c9faabbcbe649e96fb9b175494db6cef8bbdef8f",
	"BG24_020_G": "f1961f9f86ed4451cd2312e8aa2c2400cca6bd99c9187ab9541e9f5675915c9c",
	"BG24_022": "118b6f50236bc977f3038dad0f03b534504dd176a5531b0c7245f24ca4993ea7",
	"BG24_022_G": "4edd90e9ff552fc758ae69de80b8526200fd9af38e9ed569c7b7b18325224b7e",
	"BG24_023": "7242087e95e2bd06271010de0563382024c69650be40abfca8d916548814e373",
	"BG24_023_G": "eda4dcf34380c775357e3188c755af8c410215158cc022feb52e0f06b778a436",
	"BG24_500": "a15b88193969dffddc64c36473809212c5a0eb7dbe0b23eb2b746540bbebf97c",
	"BG24_500_G": "47df4700a627202f1d145a0d72ea6a412feb532267c89910b10f87e2f6d870ce",
	"BG24_707": "2ff2dc5b75ec86e876e00233c1ba8b58c78924aced6b23aca96587cebae1d7ce",
	"BG24_707_G": "6e15e3ced818b4f41435b1b8fb0c0e49f140c92007a97040fcb02ec21e4080d7",
	"BG24_708": "0b03f2adfae3bd155ead6e5cbe4480904f08463aa38e46c09719ae4228bc65ad",
	"BG24_708_G": "a4f6351d982d94bc29f82569fd99f2575d6b3c3bfbbed6e642281384acfdfcd2",
	"BG24_712": "5fcb4805d530c1e47ca23fce5dcfa0336a76bdd1cd7223117fe2d5aaa86292bc",
	"BG24_712_G": "e7da3279b9ca50a6b24d125874e74e2b63ec58dffe26f95db99aba5844c80049",
	"BG24_HERO_100_Buddy_Gt": "af7e555ffcf1a030939ec1ca9fb244e497c97faab10211d5a6e558f400ab9dfb",
	"BG24_HERO_100_Buddyt": "c0f3399d9dfd102087e0f00797d822e2c0a13a3f8a02e4e7f032f095c54dc010",
	"BG24_HERO_204_Buddy": "5713772481691e21ac2e6c14dd12bb3f83aa313f7936ccf52e749c9d4a300163",
	"BG24_HERO_204_Buddy_G": "61e58a21b5be8a90610759bf7755ae67cd4f6e1b43193ffe96215bd9b9c0c27e",
	"BG24_Quest_112": "3b6f2d5bde8ce7eb59c3f1954e29dda8bcb170fc8428d43c3929f74b1fc00c6c",
	"BG24_Quest_120": "88b4c3bbb794b350a0b9ad2cfcabce723335ea5ef3fb4ac4b59d1752c7641298",
	"BG24_Quest_124": "a767f2833dcc14ea313cecd2b5f42bf3197e0663db3ef9fd939fbab480f63475",
	"BG24_Quest_126": "c4aaf5a8f73f130fb2dd8410bfcb002ef46184345c4f23599cce4b00edf90307",
	"BG24_Quest_151": "7802ef0e789babbb85403a8bc0be3e0bd30e88dc1c5fe6b050838c17b9af65d2",
	"BG24_Quest_311": "d06816e2e34c61a5a779c0fc900b1dc11379f2ad562654fa5466eddc6935e41d",
	"BG24_Quest_313": "e53cbfa6fabdd2113d7cadf2281725d3b136e5cf1628aaec9284a92840bf008d",
	"BG24_Quest_351": "25506c921b144099a0fe5e34f1fb9c68191e5f230a04cb23d4908d399902038b",
	"BG24_Quest_352": "b9d72d614f7f14cd3541aff8628244683b8baba31ad937931b0d93f24410dccb",
	"BG24_Reward_128": "5f796af2f90325255f071b537d4c434d08054ddb40b324eb6a74c3619ee1287c",
	"BG24_Reward_131": "4667573c36f0d47cfe2c18fb20f624d50123c304f09defe7f3880bb699bb019b",
	"BG24_Reward_136": "c376934e1489b75ea1b1cff835239dc59049195b5bb62ba8a4c474843d8fbea5",
	"BG24_Reward_305": "0ec78f0ea2872a8e559cf83fa470f407b66da1d23f7fb445c996f380d8003fc5",
	"BG24_Reward_308": "8e8e3109b9d1d0d9b23fce03640d8f785c76b9e941e12f88c7cf1a4ef3f6138c",
	"BG24_Reward_312": "40b359756b1f67675ae49c1bc613d605d8547385b7903fe559c4c5eaeee7e6f1",
	"BG24_Reward_331": "9e03b5cc4e8cbc8d5f02e954163fab4a8e3a850f961ff84dc56d6df9bd3b7ea2",
	"BG24_Reward_361": "dd97f07ac087eddad8f1eaf22776c5f6ddcf6ea6043e8faa352f43315f393450",
	"BG24_Reward_708": "4f73b48c9893e632cdd5660eb435ed0e62af13e2ea12a488a10bdb7c44b42f15",
	"BG24_Reward_712": "fbd2b581233cb5a83367fc2065336c57f599c79cfe4aa50ac698741f0c4c09a7",
	"BG25_001": "5921917486cdb4a1a807a3a06f12b97a040b1062fc9aeb72f388c3395d6bde66",
	"BG25_001_G": "fb981ebd5ccaee2dae9167cf2ac40711c3a2a6d6c5dc13baab093d4de354e6df",
	"BG25_003": "a7f9dce06ac8cc9feaa431ce68f76851b02748c4a993ee02c21139867f6f6872",
	"BG25_003_G": "2149d0d7a50a61506777750c44cd351785953cfd5ad31fbb1e21a2655b59298b",
	"BG25_004": "cc226bc1b22f8e6a28fa1fb87b31c63ccde9b950610dfa5b84703ca81b65091c",
	"BG25_004_G": "8a8fae98f072e0fa1df9f79bc66f20ca40efa96a6b1fb5bee7d59362173a496b",
	"BG25_007": "b92ea59dee7f0007b9528c79894bf436d7affb67aa262e51680bd0c61340169a",
	"BG25_007_G": "3e7fff3a35a7f816af9bee040622cd12878a9b1f163113b9b491b263c2979188",
	"BG25_010": "284a1f752561e5819e355e97531ec9fe2b788247be56fde6be542cb8ba7538d0",
	"BG25_010_G": "95ea5dcd295af870ce0de7f840b1bcb976aa2091af867c254ba01793f4cfe45b",
	"BG25_010_Gt": "0654364c7a75f36d4f311afbf2c7b77391466e22ef35227f19708ae13b915560",
	"BG25_010t": "9785a8edd497e2a5c847cbd58660fa1e438b17e431ff1a8df7528171086c1ad1",
	"BG25_011": "9c200fb2d5b43153a8f8ef58d0625c868bf22fc7be9286b1b36694f8b8356e11",
	"BG25_011_G": "cafbdf6710a0e85981f3a80bd201a387969d6686d05d1c60e6bbe7d8030f8b23",
	"BG25_016": "b9944936301e631df9152d09bbcfa265109280815ab0400aa8c997398e9c36bf",
	"BG25_016_G": "cb4e34ecac74f3b42c8eeb237dc409bdc13932587792dec323370423173547b7",
	"BG25_022": "8980d6ff5c1a6aed15494fe7f8afaef5bf312dd36326d43d7b881d3f449da429",
	"BG25_022_G": "45d0b38e4c8208e283cf7f1b54530ad89236724864cf3c6e8b00c7b397280ec2",
	"BG25_032": "4342b365311d011eb28ae7162f7a2bfb32b8456d81c59bee04b1d535d841b097",
	"BG25_032_G": "ec7c7a07ce38343454b1015f45dab8ec352ec6ef0bb5fe53110f9148763eea60",
	"BG25_041": "7fc15b759e82caeab6cf4850a2c2218d37f5fff9e1d56725bdd9ddd9b77642b7",
	"BG25_041_G": "e71ae7c1d10715bf88add32b67f8743eba31b5a1fe833b3360c09b8b3a409f64",
	"BG25_042": "f5168e3add3bbfd3f8af5a1f522e1f0c6aee7ec0a767d3009cdec1062b4b741a",
	"BG25_042_G": "3605b1abbf61ae26f397e708ec811d6b867208ee41f10ac3a70dcd3629f4133f",
	"BG25_046": "5678ad65353ee475455f257c3bee05715c39e8b134e28b3948bbeb7e05f5cd5a",
	"BG25_046_G": "e2a0376c66e98144adf85c74590db3208d68b738c1ea372b2c5cd352c20123f6",
	"BG25_050": "9106ecf4a77d4766f9c8f8fa3dbbb70708628eaa0c8acad9addbf5fcbd4a1dda",
	"BG25_050_G": "6dbb36a79f5becc57b16088475b31b57eaf5451b633e5e000a56a241aa6ad41d",
	"BG25_309": "fe33b60b7f30d7c98f97f0e97cef77aebb6a145a6a82db1b4bf675ea45f761b2",
	"BG25_309_G": "4853df561279b2c38485a9a2e7e5e76ed4aebf5be1b3d79757be1d49b279414e",
	"BG25_309_Gt": "199d32d41c0fdf815aac13eb1443a76ec3d64c7b74f6ff214b7b23c358af5990",
	"BG25_309t": "a4fd6b8201d688c3fe8825b11b12360c43cffbbe4ceffa92a5a700d426a4c850",
	"BG25_354": "3d88f5989d0bb3eb45a325f990ede24520da2dfd5dd9e380f74617d8b0955f32",
	"BG25_354_G": "82de4fa5c082961fd4e5bf3a910f62a7b5143a4bb2b0fef337a75929cb247261",
	"BG25_807t": "5ef09aa1eb3613d1778f57753a120992ff58e11d3876286530423258d29314f9",
	"BG25_807t2": "9ab86734d16cdbd8787ac76a6a9196442941606607b180376d4c28849c5ebbdc",
	"BG25_807t2_G": "73d80e8524ddc968c2021d51240ca78bf783164c91bf9780bac1124d0c708651",
	"BG25_807t3": "43fc346022cab41e615145b31045f21d88367361ed7f45e9a64fb43329762d08",
	"BG25_807t3_G": "31f1cf1802b8e01f5fbeecd26ac405c22d3e731b96a73486f80bb80294c227bf",
	"BG25_807t4": "d6a803a5af4a309c13a3ba0302bc456b55e345894f3f91f0cc770cec43de1b29",
	"BG25_807t4_G": "c2dd45a2433df01f76b305bded9d7f285f5d11a53dbf174b913b7acb5a918357",
	"BG25_807t_G": "caaa7a26aac34998ceb3cc96ab1d5a4b8494a0f400f7fb74601fe883c52d0ab3",
	"BG25_HERO_103_Buddy": "3cb6d473f6e0851a139401a63ca3beae0cf51527c96048572f90ca21650d8b15",
	"BG25_HERO_103_Buddy_G": "f1701e873bf209b2fb8d0cf0ae179a119956955ee1c9d6c294a1092a8c4a8736",
	"BG26_001": "ba67ac1cc96249c4366cfda380e534f22b2103393ed0fb49b04916ae59ee8ffd",
	"BG26_001_G": "167454e42cf8e8c76bf6edacee8d94442d9200e6c29a5a02abb70322da2133c0",
	"BG26_135": "b2864bb61937f0acc0efa9614e8d603f72da7a5b89a30d4f167e655003d1030a",
	"BG26_135_G": "745d81b39e2e159b9f9888c5d8f4e5496ac6a370b8df7ee6883463c5ed133723",
	"BG26_137": "b602937c6af960f7bbc916af9f1c6d08621d3fec9fa8f40e432aded018b4c9a5",
	"BG26_137_G": "d77bda3fbeee873ea534ba3f710d17e3553a02e3b8e74917f637f0ef4f9d6bc4",
	"BG26_146": "9cc5c81345319ae4499e1cca97be91b01993d013872fa34e64b76042d141a2ea",
	"BG26_146_G": "407793bd0c159f3c5c8ac4d0542c9ff9512f21720748ed126768e138ded2a31f",
	"BG26_162": "68a0c6b464110ee39b5a44334ece0b245750c76f841bee65d76c39ec2a973caf",
	"BG26_162_G": "8a790f27a3f2dcd9024273cb441b4511af50915b4e5f3493c60a55a9b1874306",
	"BG26_172": "c1975e1f58aa5e63c44e81b47f8223d0cfd2bdcc2c6a66f431695daf2c0e53e3",
	"BG26_172_G": "91302e37228bdf84757e4bf40a9f5211cca8591e3d38fc3eab2c5c5fa09a9a67",
	"BG26_354": "ed19f2bbefcdea6d6ded12b6268e63f37a679abd3b9269b234c8eb23adbd81f1",
	"BG26_354_G": "641f1d52da796e87a6b9198e0b5ef75166e2b0fa4adf071aeb26b543047df6b3",
	"BG26_356": "7834fbe7cf146537c52bd454ca3621b1e6993c869c87fb720172bfafa9977ef7",
	"BG26_356_G": "6a1ef2cb897210d761102b4d4be69a21bba32f5a3194f8dc790e8db900383b1b",
	"BG26_360": "e1ab5a014da675339874c72d88775c8baea21d7bd95f6c07ce079c9622899602",
	"BG26_360_G": "3638b3dc81e465fd2f35f80a5f9a3df444a23b310ea792fb6c3855b7d81cf0ea",
	"BG26_361": "3035f12ead34b86a65a75d0712ddbaac86e98981d099223bd0c417ed7da1b328",
	"BG26_361_G": "c9688ece50805e5f2419b0f299f824be1e616fefc2e72c2ca43452e8d4747bd6",
	"BG26_370": "ee981c053affff6ff463b1ce87d95299323016b233ba8e457f8897e5b2fb9a5c",
	"BG26_370_G": "ad22b7a2a307bb170dfbd8404f9ed70ae50224a7cdbbc1a7ef1e3825a303b49b",
	"BG26_522": "16671b96e7b90eae344566f9549b3bee3ff79857180d9d8ae67b1acce7843e46",
	"BG26_522_G": "690692b2551394da20a6743d30d935f58b86e907dc6ac8602bbf75a9cb874150",
	"BG26_528": "f99e46fc74c83bfd1fea2a08b050a95393c45ca1bb6d186ed171065abf172df0",
	"BG26_528_G": "3243fbd29768f81e37d2ed3da6068ce26b0d7f27443af21023cffc00f664f769",
	"BG26_800": "bb802ca6a3362d5731ebef8ac7e61a3ea3c9da110e0fff946a74c955a362b1b0",
	"BG26_800_G": "5416339c446ceafeb1eae2b7b8104cc659199aed5ff87d97fc2ed3ed81c45f1e",
	"BG26_800_Gt": "033970819acb1c7a7365772634768c5322ce97aaa7e7386d0086a79f815685c2",
	"BG26_800t": "79027a75c396c9881e0ebd86f702ab2564d9fc5b2e47c3f95e01217791d84a6e",
	"BG26_802": "6305b865bb7edc981019fe6e6fef03673ed929bb26c581d4b0c61ded2966024d",
	"BG26_802_G": "a943981decd003988467fe7872e3c06f0722e52dce950c8862a72a396a5b35cf",
	"BG26_803_Gt": "e9a31ebefbb6407388b9258de2fa6cc55519f3a34e77ff2322851a9b8191e69c",
	"BG26_803t": "67217235745e658f12fb48616db321e1de1c9fe1b0b894ac74de1b4a8dacc89f",
	"BG26_805": "b93e9a836b70d8a95d0fe45b04124bd7fe963a67e23aec5bd18056d2b2d7d850",
	"BG26_805_G": "acd86f7f4e0854dcbac54c4ee486abfb9c68edd8879ab5f7488752c57f688448",
	"BG26_888": "99a5f18e159dbc19a12b4dda0c3a30dbdb027bc9b9dbaa4c40bcf3ec8c883e99",
	"BG26_888_G": "117cce01c24ef3deb74f9cb369b79767073b71b14aed17bbeb28ac424d1a8d6b",
	"BG26_963": "61ee4859ce5f58d30cea43fc77ec4be78d987c4a2c954b92180e2c84ac8fe38d",
	"BG26_963_G": "6e3dc2912ee99bf9c38758e3318dcdcfb29b366d655b5878cbdedd91aa50142d",
	"BG26_969": "f73f8e7c7159c76eecbe0d16ffb46862cb653559b3b0006682fe6ff4a3b3ced4",
	"BG26_969_G": "3bc8dab18aa5db0cb0411097e2d0e029970f50744159138abe3bfef3064ac0a8",
	"BG26_GIL_513": "b9579aa9586258932a0e704dc8f39c241b37ccb2a352d265fe9dc37cb2612990",
	"BG26_HERO_101": "de087102b335523c1871119f43930452c12305aff35f669cb51e7190a1c1fc5b",
	"BG26_HERO_102": "843aba630766f6ed88b8495babd73e22f110fde03265052d93264580bbccd062",
	"BG26_ICC_026": "52d83a4ee214aee673f46ba9591817fb9bdc45449ea737b1ff7d089d9213fac5",
	"BG26_ICC_028": "885d9f57af78d2fc93e22cd89c17117c978b015d44c4d01193c0f0c3e594b825",
	"BG26_ICC_705": "960c4a2c57ae903568de03045a5486d98dcddd76227554fe06a2dfd58958e7f4",
	"BG26_ICC_705_G": "2557875f9c6b31790ab8b534f0dc76a96b12889df1fd59cb114bf1202f7a5204",
	"BG26_ICC_901": "4e7a6b184c820835041f5c4da5214b35d60d1a8fe26a43e596d10fe1376d43d7",
	"BG26_ICC_901_G": "57eb0676d47b2d930ca3a428d7b2edc1af696b81387846cc8cb80cc7d8c21e78",
	"BG26_LOOT_534": "b9c19c4ad4edd114dd1a9ba5962053a9af3843dcdf01871d74684ed1f3351b40",
	"BG26_OG_248": "78919960be7956998cc747ffe40cb86b103f12fe1797bef398d892a0b3b7cc66",
	"BG26_RLK_824": "bc9e1030cfb2c60ac0b34e9f7d1996ddc57f6dc3dd5ae5690842a87895b49f06",
	"BG26_RLK_833": "fbc894137a106fffcb64d988b862bede4baec36c9c1e857d07ed4c02027aa499",
	"BG27_000": "5de185bde41599d33ecb12f7f3efa4d412260ada5207e9423199e1a5514d6a7a",
	"BG27_000_G": "7410ab69f998c7ef42a7c8d8f2a6960d5698c731f8a94c5d473bab86b6ce1947",
	"BG27_002": "e3a52be39130daa5142c5fc581b17ff47a7552afa081aadbe482abfce98e0765",
	"BG27_002_G": "629a5537df174061d85508da61a195b40e862d284f76e100267bd67f4cad0cbe",
	"BG27_002t": "a58b37c4642f5d7bbd2c0afe6e3455ef7d0009f51ec3bc940046384598e8cf34",
	"BG27_004_Gt2": "2d2ad486684e4fab49bb0c766f49f4684bffc6512b9bf1655250d885aa2f0d57",
	"BG27_004t2": "b6cf46e0ea1f5fe993dda6be305f37a68dc74252d17a8261da6a2634ba4cbe92",
	"BG27_005": "5fd7c651b66911cbefb1b9ba0bdbe6190163a8680094b89783c487e6c7594e51",
	"BG27_005_G": "027155c30d0089b0903dc81a34d23ba1eae9af0fd784a0dfffb31e5b28411f23",
	"BG27_006": "8ecf35573f4bc079477f5ebe06e72ad1e582ef08e752bb57d7abee65a8b7ed55",
	"BG27_006_G": "7b3c7dc3624ce8b834e65ed22d6cd8bfe63c57231b8a03fe6839184465d9e2f1",
	"BG27_008_Gt": "cdd469af66b836d5c21f7fecbd09592c1efa4e68a6a8c7527d578b6670e19c69",
	"BG27_008_Gt2": "7d6aa5f64876ccfce81cc72051195d4892ee95eb82105a989f55660af5ce28ec",
	"BG27_008t": "205eb16f0979b14c395ed5f5468762bab654f7c7c8856c1302aed57fd5d0fbee",
	"BG27_008t2": "bd331c490c6eb1ccf7786a8553e8a47ef31171c7d51dc7b96fc1b7530d5f4890",
	"BG27_010": "83e7d49aad6971220f18082aa78a542c737d68b739f586e39e5b5b6e5fa94e83",
	"BG27_010_G": "be1bd3909cd340cc179bb77fee50533d9cf0388cd3ff7953c37a807c7dcb3985",
	"BG27_013": "ae2ff02baa905d9fdacf3870b9659f6be547cc9e9c8b936ea2e41b2c8a7f0e17",
	"BG27_013_G": "c6b7fb88febe50fd30af32d1e6d62dcf004a6c1df2281c3e7c9bd356b9207441",
	"BG27_014": "150057ed4aeda6e7497fc22155f4237a2b79ac2a7d0ed3e0129853d54a466e5c",
	"BG27_014_G": "82477e67c3a7bf9a36c417b37711ccdf14ba1a35ea7d33f55315ad7c5da6f545",
	"BG27_016": "806a5fb83f6545cd47358108d6be97fa328dc4693b540e3995e473fb22b501b4",
	"BG27_016_G": "ee357de029b9b3d8c19f0598ee996b2b9da92c418c2535c3dc405565aa3c9484",
	"BG27_017": "ece7e914aa21e232438ed61447de13564339cfaef53399423e37f1c5b56f89f4",
	"BG27_017_G": "81a31adc9a3308a9d198c300db353f2b2ee1d46d4cbf91295406952529c3876b",
	"BG27_021": "009ab3d93fb66b9390bbbb4d7d2b2a37bf4a2fdcd69115a090f55caa151d4659",
	"BG27_021_G": "bfc75a10d42385c914b5308b37ce611db211221946b7af929d13e35fd7ed88bc",
	"BG27_030": "0cad878bde07cc9bf4cc14e0f9307c75feef6b46254647d8998d36801030c486",
	"BG27_030_G": "fbd5744d3bab9c3098e72b0a41083666beaa0002a62bd5c0a1c681dd70a02eef",
	"BG27_084_Gt": "4b1161d26406729be0288b1bea26f666c71fdf38cfc69b96763e3e365aa3a047",
	"BG27_084_Gt2": "8e5f4a1163151f3c4f15aa81bfec563b878ff25d1e35cad1f5e2bafdff2dfa8f",
	"BG27_084t": "6c82ec04e9b1f41b6eb1390a641a52a381f1e5732dc37b5060dc51132645c415",
	"BG27_084t2": "90ac69ca9616c56a342008b4812deefe8491d16a092249738427f1a80654d8ee",
	"BG27_508": "f27f0bc62cae39807e43a366ba5c6e14bb10456f433a84f7a475ebe36bb36004",
	"BG27_508_G": "eea9843b3e2082113c5cdb1a6353477a47655eb58485e9d02ff4bbd9c2cbd617",
	"BG27_509": "2ac7c253b5a67d693eb410275371225e7a2e8f59b311d9bae82b960481203baa",
	"BG27_509_G": "1cc83caabe30bdac3d90f03bd993e2b29798770f563427a1f51379e7708b3875",
	"BG27_518": "d79be1b624f0376ca9c00c84492a813c88384d1556b4b26a4307abc6e6850da4",
	"BG27_518_G": "7039497c7de1eccb7e32dec5c72c753bfe4e23940766b7000528cf64c4b4c3f2",
	"BG27_555": "cae89ee94261f7fe754c4a5dc2ea5dee784a31363c9c94f2f031e48c5a675b64",
	"BG27_555_G": "20f24b8220fff0e6a730392b31755465707b21d03e8847d3b982f10b11a760c8",
	"BG27_822": "9fe37c3ec900b743caee7f0c5dd483b831f31187cfc36af885a9b5b3cf249c0f",
	"BG27_822_G": "2855178ca764fb4439ffc8468d02cd5237c116eec9ea540e23865cf6f0f929c5",
	"BG27_Anomaly_000": "b3cb74c4b8320c924480761ee0046bc26295298be4065b29598b8ec8b13563b6",
	"BG27_Anomaly_001": "d5cc643861b52926add5b84c591531e7f6c2906d97b41264c057a60443605701",
	"BG27_Anomaly_002": "b0f16116b35b15b60f656e09bd83cd8604adcaf94421c83eed0ccf8ff6245bbf",
	"BG27_Anomaly_300": "d6f529b3c9600276e60c8a58da7ed9e451e98cdf22626b692c2cc88e05bc7fcc",
	"BG27_Anomaly_303": "a6c881defaf187247c4f55f32abc6a855ff090de90747c8225c425064e6e4d32",
	"BG27_Anomaly_502": "ab55cb0dfe44f12769f127349cf902ae55eaf6faab25cd3171d7561600e2175a",
	"BG27_Anomaly_561": "1019ae29b98c39ff5428336e04d9a770b0889d69a3b6108409e238dad4d691ac",
	"BG27_Anomaly_717": "f2695a484368e0e46c09a89d1cd96ac4445c60ee7de527766a418006a3332dec",
	"BG27_Anomaly_719": "9963b2808cb7812fb4ee50029062e8314bf200fc6888e042eddfa8bfa207e89d",
	"BG27_Anomaly_726": "2a09db30f31eba62326351981c33b0056cbb12a4f9de689fb293408873708c14",
	"BG27_Anomaly_750": "54b64776900946ba5cf7425be8b2f922e087bbd56288b057a15d87ffeb51ecb3",
	"BG27_Anomaly_830": "584e5eae2d10cec25c1e87ef9673627e69f38e5e31b0fdfb7e1f5517cb0f3743",
	"BG27_Anomaly_Prizes2": "c81f4b5901eba3c1f16e2b4ad33808fd53e77eb386e348af2777b769ac66a724",
	"BG27_Quest_800": "7ddf98d0cd8b4c62c548ee7f75e754568cf9a05c29e0c581d247d6f44842a09a",
	"BG27_Reward_503": "42e26a7574fefd6854dd7a1cd9e0f08cecb579b7c612ec834897de2dfa72c1e6",
	"BG27_Reward_804": "8924cff89ba1dba5bcd5430c652123d669987eed65dd147bd180588ebccaa8df",
	"BG27_Reward_808": "b9d9341452ea3283350a4b3d0dbb1285d35c1bbb59521b61f15d71a9b2e3f2bd",
	"BG27_Reward_809": "60db2f3d69033340d02ba26e5da6ad85861e4e56df1bcf82ea2a881da2fff796",
	"BG27_Reward_811": "dbc94353b6fecce5825c6231d04199fa7785c4f99a82292f19ea0640fbf9abc7",
	"BG27_Reward_814": "5b436b47fdadd7177bb77d45f3c64414d93ab29ce2aa2aebc43bd9959348b0ff",
	"BG27_Reward_815": "a761f12c37b874a8a82f573a96ed2437ceead2596613e9f8706472e8ad8c1222",
	"BG28_168": "729420bba16dfbe41a14855a2954ce6487b8965dd48e0f68c48432b1d8aaee0d",
	"BG28_169": "2ac1ddf4858bfe146bb68ef35d462ec7adb7bf64f80d74f422594e53b3ffa520",
	"BG28_300": "465fa073608a46b783de9cc09649ce5388c7656f01afadf9c73176813f52d5eb",
	"BG28_300_G": "6354e6b37a7652d4b9cfe178813510b9e0ef3ae5fe099c6f7f1151f9a4b9d231",
	"BG28_304": "14cb95a9cc3c3782777c5482e7b636083c52aaf0b554ab532d011b661b47eddb",
	"BG28_304_G": "646dffc2eb224b844a27a53f3b123cd2e6b19da6b4a8d709a7204dfad1c0aa3b",
	"BG28_306": "f00c9d275ff8fed51c35d7be0b7bb86265a35b6a15a2915906c1bba0ef6925c0",
	"BG28_306_G": "459463c03bdfc3d1937dcb44f7bfb1d01c7fcdc20b20a13128852950c07671d1",
	"BG28_309": "58e6955306699c69558629d1cea2e8e736538502ca06c45e495725b8d434860b",
	"BG28_309_G": "6cacb82654a1eee8762b547868e9f52716345ca1cf397b8c76ca2d1d45be60c1",
	"BG28_403": "c37f6e9c54578e1a84c3455fca759574adc2ac1207ca916326d2a21cb8018010",
	"BG28_403_G": "36570bf3b04c6e34e961999ec6dc90c699cf77132477e88fd1e8dd711e50a30d",
	"BG28_500": "de37efb67de4d19fe452e94180ebc19ed543a03695350d6874bab828aa732cb9",
	"BG28_503": "24a7f15dc10e2c58c1edc3dde688d411c9688685f7799008c8293b61a387baef",
	"BG28_507": "2cda81c4f377ecdc9bf53ab1764b5bfc53ee7715a06efb27c1876e027d7d1cd9",
	"BG28_509": "298556d8050e19c4ef0139c878a7819733a58b8b630a9b0477e98354cf2f7dda",
	"BG28_512": "5f2be386e1f392c420e7cce76620a1bd6bd8a1cfa190ad4c034a581b61cbc821",
	"BG28_513": "8ec9d5ba6df84e557d406f6d0fccde85797ebcec09d5d19ca566a23b520e1178",
	"BG28_520": "d4c850eaacb308f53f20ce1a46eb084674949d47b31e9423f0d70d6553cb6a18",
	"BG28_551": "76d72ba5f1f7bad82c1967af088f25d380bff5eda6a0c8b3fff5b65300ee24c7",
	"BG28_551_G": "b1541a43e76b9310376ec26d23c33ccb07d61d85bf3dff839888409059acfe98",
	"BG28_590": "0bfb8a3d9c579dd8fe6716877e8bb8e66a7cae876c63d250261e9099c34f3cd3",
	"BG28_590_G": "c49c6127d1dce503bfe194b2427129ede2330c5cd0dc44724a1c23834a5d21b1",
	"BG28_593": "ab9819daf6ed8562e138a1ef729d4d4ed56fb5caafa4be3cc9fcb19641637382",
	"BG28_593_G": "53e788470e0bd70652210cffbe9112c5458aac74c4aee8d04f40c8baae65cd36",
	"BG28_597": "27d5a75238702f7ff7afe70d871da39c177f2e63061efc949d122e00e5983f89",
	"BG28_597_G": "ba7bcf035a46b8382cb49e77bf60bcf25b8f042cc76a1a93a7e5410a950be8ef",
	"BG28_603t": "0f36743a00d5e620b38a2461a353b8d1352406dab1f3b841da0b9c43c98e7d94",
	"BG28_603t_G": "d3af4154f85e81a0af8b52c7f9d75036a550ea7a91f0ba2bb9bd2c7a4fad8c0d",
	"BG28_630": "a534b6cbc7803b4d199f171927a42ca2d626dbff413bdf03cb007adb87bdb6ae",
	"BG28_630_G": "51470bbf69ecff91a0f2cd35570d1648035aa1658560944defdabdff61f48fd3",
	"BG28_634": "d6cc7de32d28f8993cc80df35123a980299fc777d268d3a6be1b01cf94b94b92",
	"BG28_634_G": "5af6150789398ba38b0492191ca6dafcfbd5724e87d6ae59b5bc6787b5e8ae68",
	"BG28_667": "0133b1019773148e4d270e69b737999a02035269c3a4ebb0bc65f0300d633254",
	"BG28_667_G": "11b37e661cfcebcf844b7c241720630d44fd5076f2cadda6a0b6e357cdde1d1f",
	"BG28_800": "ae750d9b21e7be32bd51bc87ed381b48856b1b89b706e1435e178dc98d4170af",
	"BG28_805": "78c0e7fba15f26a2dfa560b3c1011969881361cbad64e1d73b02b14a90ede56f",
	"BG28_810": "d3b57d0f751c782c88e108764ff5143245cd8fd195347a4d1087c2b70777af51",
	"BG28_814": "223b4b8b12f847d135b9f718fbc0949f16748437edeab224b6e8d4071ff0bd38",
	"BG28_821": "f9b0a3ccf6fffe95221d0505189bfbc478bcb735b7142b8dbc6663f940315b57",
	"BG28_825": "a2e74a490f6b693212738b932d5e3a6f89e0a5a79cff71a6f59aac3d4803c6c6",
	"BG28_827": "8c0e2b775b7171b39c0170ebaa25f39c28fa4d6b24a82907055cb49ad0fde5a9",
	"BG28_830": "0e7a2108c2feb002721da47a23bf99686c39b5d7b61a2269bb6c65ca8563b030",
	"BG28_838": "a38f147195fb44bcad491be924821ef2facc824a5e918975a0e70e0d941a27e3",
	"BG28_843": "12f2ec894b0d3409ada5e5e3ca20f087f56d1c33b4694ce42be7111be6b7d21e",
	"BG28_845": "3738ba774e72f6a3ae8e1da49b7dc07b52a96099079d29a6e72f11e9fd9a0bba",
	"BG28_885": "74772e9d7c151910a7a57c1f5f1e8d2ab5892e15e83e7cd6bddbb70b67efbe72",
	"BG28_886": "601d93d689c7a9e280c2b06bcfb616ded3e186cd00b1fe685a502ace885c8c3c",
	"BG28_888": "55958c5ad2748d85d924ba12a5973ec4886e547ce7542d291ead82d91c16fa5b",
	"BG28_897": "326ab5b57f04b9b29ea8d0c04a8acd86206a53a9d71bfe418697a5f0212f5ab2",
	"BG28_955": "fabb886f8e74aa5a769c742490ab033ab62dcc4ad3142ea4e3054fc9b3eca8b5",
	"BG28_966": "0f3c7f8afc14cdae02f763af6cc4fdb06b433e698150ec616dd282b4e905dca1",
	"BG28_HERO_400": "f015593ceb14929b8b8d0e9e51ef930ca300c70c9e98baa7e37cee357bd0e368",
	"BG28_HERO_800": "b947be13a402d0b672d99273d2004dd73375e3dcf9284d37abb922c0ae6af75b",
	"BG29_100_G": "8239185e77908a2a6804dec110eccf038068c9db62ba4a060a98a371bb4a94f9",
	"BG29_120": "5da98e8c2385ddf6f019b8c99ad1da3fea91a319416fb585e71482dbbc37fe2f",
	"BG29_120_G": "8b574df2b117b0e29e3f96c57fe8afd7c6f92bee727c3251d92722b94483eb60",
	"BG29_140": "4b5d4f30a5e0d0e9d62fdec34e1b33cb75b5c71caad87aa653741f696792cf28",
	"BG29_140_G": "dfb1130f22002a6da1b40c51bea6eef9af22375d9ad8aeab14f74d4b59903032",
	"BG29_502": "82955f0c2ca2eb5a6573b433fba5649d2fd8841da0f5aa4c6138f9344a4b95e0",
	"BG29_502_G": "89f614acaa3a29a14821c2453f6fd8ea9e2da2d9de4119b016c088a5910c522f",
	"BG29_611": "b0e45f95329c2270401e1f5db37f3565cefe374c09d8b68349c6c09b70ba0eb4",
	"BG29_611_G": "5e352b04b83ffa2c48ee79b83e5c0f51592b4d6b58ba7b896ae1a849c7563785",
	"BG29_801_Gt": "9516fb0ce80ac4afa81d5663abc0e8d376fb27429aab471712f520cf902ffd15",
	"BG29_801t": "bc16b5fc190a920756639330a00d0cc06a78a06d0bee04f7690e7c5645e2be79",
	"BG29_803": "b6a0824d97aa24dbbfab325021438c6a3a81425335acd0e091151168faaee786",
	"BG29_803_G": "42d259bfe60eda7395418890868f8141dc256b29eb5fe8938cf3b01fd2a33010",
	"BG29_809": "48503a502fa6d774113b2cb5b3dc7a9e3480bfd4132d97ceb3229c0c6dbca27b",
	"BG29_809_G": "73fc1164c064df790004112b102ef0e565ecb756312e32d0c0a7c643bb8f370d",
	"BG29_810": "ea77c1d4f7a96c330623caa254f354e6cf682158294e9fa4f8b950508e567742",
	"BG29_810_G": "a8506b48b92bfb3d8ec7f3ff66afd2fa22159ab1ca8ffbbc15a3b424a337855e",
	"BG29_814": "4db8f179cdfae81b39eb40f8f0d7cf67e51b4614ce41a4e792ee2550c1fc2b08",
	"BG29_814_G": "5b35ca55ca5d588ebd008f12dcd4ea2b418be658331decdb55659a7f4311ae52",
	"BG29_816": "35184f613ad7509eb7ef0588cbb70662d38af652ef080fcedc49105a19b52e4f",
	"BG29_816_G": "460b1648fa48a03105c202f7912bc0e5b01b26aff82fffafa4b27b36aba10229",
	"BG29_840": "200527aac47830205b394cadd819c11f57a0c78255daadbad9bf089bfd3124ec",
	"BG29_840_G": "9eaa57f7b347c60c517ac0eb9a2240281b62ff66d56a23702a28f54c92131511",
	"BG29_841": "9ee5f828929991cd681ad56e975a6df7a5fc14ef4e20d8d9a3bd3f19721f38f3",
	"BG29_841_G": "356f9d41814e50e6a235b84f5cf4c2424e048bf4ce4a140ea8b06effd7addb28",
	"BG29_843": "5b67586ae00b7249daf585095350f3cd4f34727a07a649b4af17b0415a70d1b1",
	"BG29_843_G": "b1edbb030cb77a849d7c2623f4efc89ab7ad82745477f1bdc2d10089c708becf",
	"BG29_845": "36713dc26d93ad386e0eb1556f07563562f2211134fb1d8c70ff1a9d9018c604",
	"BG29_845_G": "ab9eac2c8bf609d010deab263929a86058fdf694be0e80ab37221578110ce5b9",
	"BG29_863": "114a27f5ada910abbcfc5dae4fb04ebfd2b8fe4f8f72762955e7d8c6e0b2de9b",
	"BG29_863_G": "352d578b8911ff1d873b72eb77997cee9b6e9df93c4c0f1c3aa17fe69cd9cdf2",
	"BG29_864_Gt": "c6905e1b1c4da884ec79337c20e3d1a6b6c682126712131f9bf4775f31e89907",
	"BG29_864t": "204d88638c81bf06daa455fe83ac1c9e6360765e362bd2681fbb4e6ed0edfcd8",
	"BG29_873": "e519dbd594b03c11ed70890030d0f47f046adeb4c575258de827bfcf6f2c7246",
	"BG29_873_G": "7637af9fdc7c58170f7b69fd7ea03ea368f4d7cc9260f619726d8873996c9a82",
	"BG29_875_Gt": "e3821da6c52bb27b4a80df4a76475d266b378c271a4a0822e783998abb83d619",
	"BG29_875t": "fcad85ea046dd54e23208b40b9b19793a1099a45d5df64288749198bc0caed30",
	"BG29_888": "d89ed84d789214552a23ba908ac615cd5664954c55102f821f81105e91bb38af",
	"BG29_888_G": "70d2cf4d0584f70fb9ad77c85ad408950123f024057dcef0351e8866fa5448b4",
	"BG30_009": "b1702ff55cd99f186a7b9f08ea68c91017ffc0f1eaad70776b6cdfd089d18043",
	"BG30_009_G": "15b032d9be5709677039d0d01e1d738cc582bb465c03cb2d300a2b166dc19179",
	"BG30_110": "bdc6f041a9bbbe6180028d838226e1e1236e06a83163673892cfea27caeb410f",
	"BG30_110_G": "28fce464b68f62ec94e5669ccd478c4fb9a8d07aa1cc66a612e3a950f38a4459",
	"BG30_111": "0ea4a8d5332e76fade98f202a71f03d7aa43ba6ff2025abfec148e84967dc0f6",
	"BG30_111_G": "88ab802391f64282d2379f8da250d081f40558ece92865592a279e486babed0e",
	"BG30_120": "022f3c86a95c82a63fdfabcaf8e4ad265d47d1ac73f499362aa29c31b51a369b",
	"BG30_120_G": "e305d6e33ecf73b16c3e83233812eaf1d395c2e606555bfbdd342c713b86f9c3",
	"BG30_122": "a861687ee074de100d79fc86ec12bfe904936b077bbeab45f79fc5eca17a9035",
	"BG30_122_G": "55e0aee0b5a61c26993e73454b14d227e8af5a3ee41c14daccaf21998f9acf6a",
	"BG30_123": "14a727141741cb918495f58e5d36f53976665283b33782be2fadf5d0c2c3dfda",
	"BG30_123_G": "96fabfbfd0f322c6a6f3763ea50358123de33cf55edf49222f387efc85eebd87",
	"BG30_123_Gt": "2cb956c1f6843a6e87af7013dc475b3e4a21c92815c67948f4ff86d0e0972593",
	"BG30_123_Gt2": "3dde9391a8bb0e14ed4e95f4c8a61001b4ef83a6ab7a29d664dba5deaf8a4ecc",
	"BG30_123t": "1c4b62a314f8dac6f804c32cc3a32a6802b0d078727a5a34be305604d8e750c3",
	"BG30_123t2": "b2cb5e9b2306d11c3fb8c0b0ed9fb8cd9af6413393fdc81339e345b0266f7e5a",
	"BG30_125": "e76558df51d098d51e3ebbcd5af56872127ca2827f8805db7ba26d461a6a55e9",
	"BG30_125_G": "e49e1b295ad111dc3aeb7b6304fa8243e62580ef607cbee650ce9a7b5411b029",
	"BG30_127": "776fdaa2881cd0dd3f19b027bb0445ee029b9bb47b0ddcc24566f70492d1a291",
	"BG30_127_G": "513b0eb890179a074b2bbb3de6bbd95a5d8a87be7537ced10aad8141b2f7cfe6",
	"BG30_128": "5d3e4f858f70ab8eeb6e13141204d435ff043f1147288d8286c66d90c07da3cd",
	"BG30_128_G": "41ac76b05fb07767b7cff0aef3f55f105ae8d2c12a791619a3af663d5ba00e98",
	"BG30_756": "63f5ea84e238fa05cded536516910ddcabfd89ae5b9cb0329536c6748d8b3c26",
	"BG30_756_G": "50445020a167bdb568323101dd87a6be0444ee427aa00962cfc66c30c50784f6",
	"BG30_850": "6a8626df96579008c548dec2a7616ee95720c246c2d4a87c3ab4873b57e1f76f",
	"BG30_850_G": "e7955f148f87f1ecb7b6728ee385080dd87d0865624908dcf247e79f58e3a211",
	"BG30_MagicItem_403": "159c2e39f4440bb0de5de4fb33b9914f21b940bab377605021e9abca52254e52",
	"BG30_MagicItem_414": "5e12b67bb6cca632f920e7b411b63b53e5c8a183008eaed5ef588ef075a8b11a",
	"BG30_MagicItem_414t": "b21e7cb58a138594190675c0c6ed3edf0d985d9acac2fc7827dffc298857fec9",
	"BG30_MagicItem_422": "cbf41b494e8c300232171775fba8f0ca475fa470735ce2fe7af04e73f9d5b1bc",
	"BG30_MagicItem_422t": "8764a05e4ae1a7fed8931b7f95542625115154690d14287ca47980517317f3fb",
	"BG30_MagicItem_441": "42000e526d5ceb6bdb8ab0eaddd751c8d528527fbcf78dbff26b1e767ab172d3",
	"BG30_MagicItem_442t": "135890d1810c2975610fafeb541f432213a472bcbcebbc9fb81080c3f5b0d6aa",
	"BG30_MagicItem_442t_G": "23e6ffc47592c06294a58263b5be38bc677f6abfc850597d25fd0fd873463fd7",
	"BG30_MagicItem_542": "0f7b215fb1314d6044dee744b80bb2195b8e0ead22cd235d02edba299956c35d",
	"BG30_MagicItem_544": "e254e4f7c5b6a254510b4d23c1b50e8977a18790c62a7d5c540c1fee956c3a07",
	"BG30_MagicItem_544t": "d9170bceb1fda5531af0b05dee50e8ba9b3637c125e047d1900ea8057c587efa",
	"BG30_MagicItem_547": "1291411831bad7767bfe8ac23b1747a35a18b80787915712b9d2aa502c3e215d",
	"BG30_MagicItem_547t": "26c3c243470886da4d385a90cc5976138a7c8e5c083b82e071ce339409b9bfe6",
	"BG30_MagicItem_705": "55a1369c97efa9fd0abff0da9f3d4906346343b59dd1e8c38a8e9632dca6642f",
	"BG30_MagicItem_714t": "579873d07c51b69e201e35b903536e887c0621ecdcd2afd380f5ad11521322fd",
	"BG30_MagicItem_841t": "02c5f90a1614a5b767b7a466edbaafc0b81a810b338a421e3c12673440ab14d1",
	"BG30_MagicItem_843t": "97b1d36f5dbe7c5af3cffdb9eac0db0a6c1580628f8c37067d04a7fb00e082c2",
	"BG30_MagicItem_847": "4c5338058b62b37467bbc15af7847280e75748e618c16b20bac9c374ca4e8e13",
	"BG30_MagicItem_880": "7dc3825e0038c9fc07e922b4ec958efebd797ad1fc5f1db635f29f370fdc3f4f",
	"BG30_MagicItem_880t": "a1d8f975c94258e9ce6bf8dbbab585d77ff7939f5c8cde22e3df24d8c9a5348b",
	"BG30_MagicItem_900": "104ea2e9b9301d66e58e9b1acd58c0fb62bd1a7c9f798233d0d7d833a1f1313a",
	"BG30_MagicItem_900t": "b45ef111a6e8cd7fff0a9aaff6a1459161a2f9464b4a2bc87abc1db97f391e64",
	"BG30_MagicItem_902": "71d5f3209bbb3f8dc2418b351e69da5388d93d9d1dcbde1d984779eafe4ecd4a",
	"BG30_MagicItem_914": "0c593afa38c4d58bbfa98ba30442b1df2c198239924a598e641b40eacc777115",
	"BG30_MagicItem_914t": "c6443e78205d9615961cfc6d74accaa5ecce14b7dd36847741bdb12590ba8b38",
	"BG30_MagicItem_924": "bec8f3b11a8b3313b8930604e814c870b1c7c931683f0c59b55769bf1dcd6d30",
	"BG30_MagicItem_924t": "6727d07f3a5817f60df00f53e55c0926cccd35cff13b04a10dc5a979b22139d6",
	"BG30_MagicItem_962": "89320bcd7bdf8742e1808283e1ba7c8c36883a7fe8ba9a75aa4301642485159c",
	"BG30_MagicItem_970": "775bcd24f387cd0759ee1c6709de4bd3e9ba52a51ee3c487d45c01351dfe4f4e",
	"BG30_MagicItem_970t": "a07f430e781dfac393663db17f1b90fc3ec4dfc694fb081e7349b42c96ca8f36",
	"BG30_MagicItem_979": "8adc516928c5fb0965e024f61d71fceafd6a25beaa975a31b4349a5b4c619174",
	"BG30_MagicItem_984": "72c48c77180331c50bb8724c9fb0d6f9b36e5359bc416065cb21114e7afcf0fb",
	"BG30_MagicItem_984t": "01a1382eced1fa19a1a82ef9788d295e09bee11207a2ec2ebfe457ca6d881481",
	"BG30_MagicItem_986": "8b0a676622a8eea634a334ef214baa26a7e141c4f508a559e3b231d8f2b83074",
	"BG30_MagicItem_988": "971c494986ae26ab066449acddbfd1ee01faff4921edd6d0b7a41302dd4cabfd",
	"BG30_MagicItem_988t": "82db955669dc0a0763ac1f296524b73c483d255d963fe73d38741e5730bab6d4",
	"BG30_MagicItem_989": "2daf4e3bb8835094e3cd373dac3a754f2b52448f2e494d3ed12e6529ad84bdf1",
	"BG30_MagicItem_989t": "3e8af5b43b7788a2e06454bf790198a8777e5eb5175794285d6e1f7419b927ea",
	"BG30_MagicItem_992t": "a09dbeb7f137955f24bf8caf16c42fa9bc57cc3cb7b729a130df753e78aa348e",
	"BG30_MagicItem_996": "a6a2bb4d910484bef322a9f66a4dd584238e79e66473916396b88d2380f46756",
	"BG31_126": "dc0791ff5300d4538382439f7a6f9343dc0f8a5a660ba5ec0043670a08be242c",
	"BG31_126_G": "fc29147751237a853a717729dbdac6b9efd29d7e4fcfb2feb58db93765cec4fa",
	"BG31_144": "7f2ec6c5bdd8c71c13620369c7503e2ee8019d78aeb295b5fd9277d5d904198f",
	"BG31_144_G": "8882b7da9ef347f038cd6394e6699fad881ab61656e7458b54bbb0b8ec4fb5a6",
	"BG31_170": "f57d73e18ef82f59310361a47c5898d44c1d14430c3d431aa0826884eda08e20",
	"BG31_170_G": "b7332b49ef2ed8695f97ee25a24d5db707675759bef435b53b00869f716d1273",
	"BG31_171_Gt": "8ec4f10ae6a737d383d40627ca5282be09a7cd98475ee1ba264087cdddd5fa6e",
	"BG31_171t": "3309304d6ea3ede6aef0c8429574fbc186f578af61b29efc9074c5c86a7caca5",
	"BG31_320": "e2f54a092728ddc7268196f498709e75dbb19b6e9d2b4572e17407655f924fc6",
	"BG31_320_G": "685b20bf10b7e2aaedd2cd8f4fa172ee84c6c04f2502e9a85d4764e64a95adc8",
	"BG31_320_Gt": "34f845f81c194f7ed30d656c4470e1a60b5c6401986c803807f0ba9a572b179e",
	"BG31_320t": "35834211e0629aa3574eaae0df62ad2b5292debdbc98828e8ff16a744e8fa2a3",
	"BG31_325_Gt": "f82dd00ddcd40ad4fa0b38fac123973e374c465e34ba9feac1a04ad6f8e450f3",
	"BG31_325t": "15813841ec075a429cac06c14f6938f233dfc350309ccabaec2f0a9f854bd217",
	"BG31_326t": "fa41362208e95d01e2d6f045e64df3e458378a8980b61248893b469fdf45ed93",
	"BG31_326t2": "b9d4a49e13109b0c6783535f8b8c508a26e19d20529749db0ba5e3c52b8d0886",
	"BG31_330": "fd1a338605732c665b0d6819d3e7441dd1ddc3cc99daafa6a3dc404ddd9bd749",
	"BG31_330_G": "f267c6de45ead1dfacda6a8d8e5a685bbf8520b1a1f0ac717f8fe68f4136dfc0",
	"BG31_360": "b4f44840e4390cffcf5e81fc3f4be395fcb6b39e554c346010f9b48c1a7f3c2f",
	"BG31_360_G": "90b6ab40c92506538beee09ed36ee7fff6913ebca662b07f17d2c17a6b153395",
	"BG31_369": "1bbc70544fbb8ea9b962ff438e7e761edee130f4ffa8c461621f334da4959b79",
	"BG31_369_G": "77d6776a900488d0e07545969d30ac0805e2cd260574108f6626c6bc40631b55",
	"BG31_801": "bf80e0d56db3a7ceb3c51266e7510b1c5967e7b3e5590f22bce8eca2b0124b6c",
	"BG31_801_G": "20ae3168eba7bc667243477a512ca4e476b0b8b89577771330dfd7195c3d52fe",
	"BG31_803": "e8d45c5bec90e5a6acd667fb004b27486b60619de508553b654edcb190873f8a",
	"BG31_803_G": "e576321078e7a2193765742bfebcc39841a2befdb80dbe731818a6965691205d",
	"BG31_807": "9fc26918ce0d931f1eeef171f0cb8fb19a411d9d062e0f5584475a126389cb00",
	"BG31_807_G": "f1109633b47e18983dd4a019d05d8bead80c3e8773cb98da2b92e053173fbb65",
	"BG31_809": "d881c03d73efeacd2fc456504d4051359423b08b4436195bb8149651ba841e56",
	"BG31_809_G": "00470fbab54684aadf48a05e250af0866e4c3803a4f14de037c69524be4bd6d8",
	"BG31_815": "a36e25d13c90e2d9df65391cb4f3c1e6cde89d01d4d557c82123d3903db9a8c0",
	"BG31_815_G": "6c4d76534079b44a97b8ea4f0946b7d03400d60490bc149f1dd87218967c41ab",
	"BG31_822": "0cfc20dcc059223073b49e26ff1f080ec0295e30ac3b6cb974bdd657d216e4f0",
	"BG31_822_G": "24ee1086e6ea857e2f5c8a620680bbd2bb4cd702b3488ebfcf284c23acec3a0a",
	"BG31_825": "19c519391276404ba8126fc106b8b76cabee571d351b20dd465117b358b4609d",
	"BG31_825_G": "d359460ea0e8bc8f979d71b74514b2f60dc65c035e0307058c755b4955ce901b",
	"BG31_825_Gt": "223e0c9a8004095966459f8edef2f37b0251500995201fcf100136510e535498",
	"BG31_825_Gt2": "a835277a9e64c6f9a8b8cabd9bf1e15a19f63d2e418e98d69a2c18917134e669",
	"BG31_825t": "19a762fcee89aa4b970f60e53ecf644c2b30acc37899f6ecc52332079ef970c9",
	"BG31_825t2": "1417bb0875487b4567ee58e72f3f67cdeb08e7790ba152636773e8369b42cf2c",
	"BG31_843": "cc4a83ddc8df8bc891550629587a2e3ffacfdec696f7a7048eaab0cd4c6af21e",
	"BG31_843_G": "cd5a06cfa8929ab35e1b0fdc78a01b678f83bb6f1fa36abcffbed3c3c312eb20",
	"BG31_851_Gt": "62526a0b1815e6a88c664b826f15c27d7a400811e0e7537b657928ca0f97c6ab",
	"BG31_851_Gt2": "c795c122571ca659592a85698833aff385f375dc269907cacd79a1f8c1a5c8d0",
	"BG31_851t": "4996f0dcd1ce3f6384b545dbc0c10ada1a6ea36812e8149bbeb7dab510ce5df1",
	"BG31_851t2": "3c057bef29fb75a6b3af68a444b7def1bfd579b0ff0f171b20ffec7b4db5d9a9",
	"BG31_859": "282792d3e471f0e820fec2ee1dd6d1b1d1bc90a1779ff1fca3857f6767c25999",
	"BG31_859_G": "516d4b3152e70c916dfe8deb2d3cd8578371a7886f404ffac020648bdf2fde36",
	"BG31_874": "509dcd181a345770104868c93c5db1e6e1b064ad88128b5a0490bc42ac7747d0",
	"BG31_874_G": "7ec1cfa16d079493154ce37e76b8112d4063c6f520d8224db8661a110d43ce04",
	"BG31_880t": "388bbeffcfbe39df5677e6dba48991376df8880c7559ff13f08670cfcc0124f2",
	"BG31_880t2": "17f283ade5ab65efde13cd73f29b19477bd3f2dcfd1ab9d383aa63462ab0a636",
	"BG31_881t": "b0a1447377a22320817a6fbdd87e021e4da843b5104133499861e8fb4f93df65",
	"BG31_886t": "91bc3849246bcebb1512cc37043e26ccc913ab08824dd59aa896411687d079c7",
	"BG31_886t2": "3b0d78a3a0f13e73f9ccb8cf3ba6278fbf70db73ad503412e8d75ed5ef2e573b",
	"BG31_891": "4a686870fc1b03548a69c418935778581999ebd7b1b9c92768ceabcb223def9f",
	"BG31_893": "4dede38f7a3dc886f67f091b9ae83d1d04dcf6e5ccbe20d7d7fdb77d963389b9",
	"BG31_Anomaly_105": "2a19f65e7c189e394c40b4558729a271acab5a6ca3f116750703c3ff398ca312",
	"BG31_Anomaly_111": "b5ee185c1e49624ef776f31827122fb1176964c03f85f47480cd6c2e7aa5133b",
	"BG31_Anomaly_116": "0270105c349be6ff87891766e61f678a4958d1bd51e0d87201364dc92ffd6f3b",
	"BG31_HERO_003": "c1039e3fb4d2744c6a09069ea1de51f557d2a1248f4ade9c5ecc080134665967",
	"BG31_HERO_006": "9bdb8d51305fcadf225bd476caa897a6e04fc929cd8c6f1709498fb30fce6c91",
	"BG31_HERO_006_Buddy": "2f0b1ecfdc5a16171c77aafe40ab40839ed09768911a55328a58256c6df9ed9b",
	"BG31_HERO_006_Buddy_G": "a0134a57d162714445ea6a94fd4652f38db21b57749a1db24be795c46ccc1189",
	"BG31_HERO_801pt": "fe22b28e578d1fb81f6aee1f55228d1d6fa61c86593ed6f6d270323b39bb993d",
	"BG31_HERO_801pt_G": "c2bba1913b52ac690a2bbe92b41a336167bb91af9d7cc9bc31d5059a6ec6d685",
	"BG32_111": "7dcb56d4642fad07a30d32a79749bbea646fb802b6bce090020b5b079a4e9e63",
	"BG32_111_G": "a506799aa29db9ae561d6cf61ef1b4e631483b2f42c3eb9e17c894bf3a6141de",
	"BG32_170": "8fbe191f1a856a35b38d477118f05d90d4f349c57d053d6d0bbbf24e8860f1a4",
	"BG32_170_G": "b6577e0a7ff28fc8e335ce2d658ee2f41e701a48ae0662786544e522561f6880",
	"BG32_171": "d44c4238d91301e862f07fc5bf1c365e4a0d8736096f24de0cd30a0a03b870bf",
	"BG32_171_G": "b470dbafd0ae076823a5f786e51a58ee933ac9a117609198481b3366b8b2085e",
	"BG32_201_Gt": "d4a9b0b1c4c4601838a06f95f5b42cdfa1f6e57533ec2802c9fddeffa55896d1",
	"BG32_201t": "e452ffc90914c5bee9b2563e5c0bc54dad447217ad57021132d05950adc7ffcb",
	"BG32_235": "05b1f85e07ddabf5fda6b0657ac600ea838d83b85de319faf4ecb8e4a36efe69",
	"BG32_235_G": "88003920a8fdfc7d4843b3cd22069a23b0f63dff8e45441f25c10af3882fc078",
	"BG32_331": "e0063d786d3966512cb4a0d05fc138c1b7ee73d8f13958719a9c4124caca630f",
	"BG32_331_G": "2ae78b3b44ac3daf04ae55bb372d733b1f45b64769ccedd1235fe7426d4d8e03",
	"BG32_336": "2fc9738f163121d6b293b1069199d21e0be1d7815a9331d753241285afe3e042",
	"BG32_336_G": "9a759f7ce74e0f8cbff841e4cd7b7f90cf7e461117057c5d7af1797da6175a69",
	"BG32_337": "94c5d4fc724a13531c34d300ee749ba6bf9cc7b67b747e5db050136552f8f16b",
	"BG32_430t": "b97be603492add58c4865fafb020015932248f050e01e60a3c20b726b2ad36f2",
	"BG32_430t_G": "78c4e8819dc90eeeeb5569cac8b45ee4b49058286eb2dbfe896db79c3cc2b354",
	"BG32_814": "334ebfaf53896040e748dbb2e0d8a46b73980ba34863030aa755c703067c85f3",
	"BG32_815": "95496fa7f44fa92b19ab392851cb9d6b28bf5d76066b98a47d2c3a517a1e3bf5",
	"BG32_820": "69ee5b7d2c9f658aa915c291e5f8a748884f001161e5068276ab7cc137046bd4",
	"BG32_820_G": "19549c503ce66bc2cd73f229dfc9ab6b94719e40439c04b6b47bab6981ec264b",
	"BG32_824": "a4d10a72fa6d8880f4ad77fc1fe4b3970f6dfd5697e010eb30237859c046c120",
	"BG32_824_G": "81c4f6e2d4f0de885161065ed7ec4ecac138a2bef24b207bdb21d41d70839bfb",
	"BG32_843": "b46f0b4269a14006a67d204f36260fe6daded623a21afe4969dfc03bbe84378c",
	"BG32_843_G": "dfb16172e616ca13f9fdc867404a9118ecbb068be02f25e3bd373c4fc6741308",
	"BG32_844": "e712495bb812ee822afde0e1f274420ff798509dcb6d210c386bbe142ab77dcb",
	"BG32_844_G": "8fca59fc8c48fc0304ecf40b022f90aa83c09313b69871b4c4e230da10b392ad",
	"BG32_846": "11df04f6c072b09e6d2ba35ebd5ca272e81f0758fcb83c908bdd0e6c6a17948b",
	"BG32_846_G": "374de8ac0f47df5ecb0cdf7c2a440f23b46fec244545381b304229559d2facfd",
	"BG32_860": "6a2a24fc580217c97dfb7788ee5c5901f2f6a51af000faabe0d36fea91ef2d27",
	"BG32_860_G": "b25073765419fa3ccb0117f1ed56cb66b63e07d8792f6bfb89cd2fa2a1799a21",
	"BG32_869": "075e0698a01f90fa5b2c535ae389ebccba5c3119a8e9ed8f34c51cc87c74dd45",
	"BG32_869_G": "7818c692043fe370d4276a4936588737f51b60379c36c800f5bf91ff360a75a8",
	"BG32_891": "6d6852fc953a0120156a0752466b28bfe2642aeee7b0b486cc7c8c1c043443c6",
	"BG32_891_G": "a9316be08cb27cde85dd0edbc8063df2cd6d661dc70f5b5c7bf03f89f39230cd",
	"BG32_HERO_001": "609d252b9fc81a7c2f9bfed2a392f0fe1cb4233673100ecae9be11dc6e462793",
	"BG32_MagicItem_111": "62e106d95884ea454bb2859c8dacad362d96c44fbd8262f2c27cf4313f9853b7",
	"BG32_MagicItem_205t": "2537cb41728c3e9f0b5e4527f46ceb702b3e7140c6692c68e77495b3a3d46e13",
	"BG32_MagicItem_230": "cd943362dffc48bfe345a3d760e398deabeda291a2f069fa84154ac593810229",
	"BG32_MagicItem_231": "ab1ec379db55a81d60496e9edb755246e06a54df097ac0f60032d95bc0844121",
	"BG32_MagicItem_231t": "77c3ecf243d21bc64fa25f786b43f26703d5a0a235b85c8483609df50194264e",
	"BG32_MagicItem_276": "cb711504fa691d1571028ccfa6d1cf456fef021df430b8152c116e1e770c25b4",
	"BG32_MagicItem_281": "6956c3388c94150841812d178f5c1825fc683bf24873f742250b1380b29dcc31",
	"BG32_MagicItem_360": "5d0992bef0538ee8ca4f58a392c8521abb1ff00346a73471c7b76a10e468f092",
	"BG32_MagicItem_888": "796d3c789c318b5f34a96b921d356918ef496f07bf7b3a6d996c76edd877d649",
	"BG32_MagicItem_893": "184ff026d06faa9bb0ff9d02ee89b40a8b0da956d66de0a9bb706f0978273d30",
	"BG32_MagicItem_944": "c5cec47061e4bbd9eaeb9a67bb7c5dc022057f4c0781b4ca88780b90bca3fcf6",
	"BG32_MagicItem_954": "b021f027743a8099478a87988633f863a117043a541c7c506b68c9a9f52d57eb",
	"BG33_101": "ca42c4a9390347207c1431cadc0fdbc12b89d48144b21a7cc595c5926d55fb34",
	"BG33_114": "5adb629bf66337c249bd5ec0ba084c49384c3662089bf7aa249b83bdcdda0581",
	"BG33_114_G": "f2c526c289e823641147fbb87551d58b11b2dc159666b66e6837d76b2a670a2c",
	"BG33_115": "30382fb3fa3fa35bc34d15467398b604404273547f14b2ac76c4c8f13af748ce",
	"BG33_115_G": "ae1f6b4537c31d85d6cbe2e099e14c38f4ac00b1e6ab61f77ad0d0f1e645e256",
	"BG33_157": "c46df4a0eef3f04a3313a5e0b85cb580aed7a4c389f70ba07f0cee8210ed7204",
	"BG33_157_G": "af06499fb91beb12da2cf7fa5edfc58226a1ccb0236f9955c404171c81f9d0ac",
	"BG33_241": "2b553fb092b132ab6bf9cf25fcad742760e591d26c2469f09fbedcfa4f3c1657",
	"BG33_241_G": "b2562a103b9cda2ef8385f3eff578f6ad5cbaee7350550b45d0c54f5d61077f8",
	"BG33_244": "9c3278cd6848b6f8c23f0b5d9981ed826237e323e108a6caca9a4ab49e0616a0",
	"BG33_244_G": "adee7a829f8dbb8f5e71e86ef2fcff585e69f861cbce66d5300a8e0c05c111ee",
	"BG33_245": "6b4285ad21b5ac8654a40ff9535c54fbd2f7ae79aab2cd6c3a5ba679d953fc72",
	"BG33_245_G": "08cfb511d596e23c66bc106c4a5baff38110a97620db736f7d626d8c20394ab4",
	"BG33_247": "1de48fec3a39182aa7b575e3237363235df9513fab17c7e434218f255e171350",
	"BG33_247_G": "1e505d07a10042fc64ed7c23c569c78897c37d913e54dc90d9fadac7a3419067",
	"BG33_248": "1c493a93deb1ac96289deb0139652743af58d498101c00c2e0e0ef6b9e56708d",
	"BG33_300": "1a946e8bfaa16c9be377531bf97a9a2e8796bf7bc72e2a3188864575b3afae56",
	"BG33_300_G": "45d90b4bd27e891bfdba91bdc4504e1408731bf87784f5ca12a8cb316d122c82",
	"BG33_315": "7e0927d79e6c7a89b00bc906fbb59b3494e7916104875e0a065bd57d1f3b840b",
	"BG33_315_G": "fd49b98f7261a94d4e180f622b29866045de324304a1c1a1578212a46ab1ee58",
	"BG33_318": "84f32973c360997e9897c3d97a958694ab9903178413ebece9ebd1a0729e4a41",
	"BG33_318_G": "e3e4db7284286216ba61c21745b3f0e84bd017a70671275907273553cd9f020e",
	"BG33_325": "4032cabffe4d6cc55569a5b611add62f29acc3d59cd441d9c007514538a5fc31",
	"BG33_325_G": "7377fbeb31897fb2679008e05a8947efde7ca493d00bc85a93db02a61d13d75b",
	"BG33_801": "1c2796500f465c79a5105bbfdd1746e1528ccb08f4e80e654f6530d9e8aaf7c6",
	"BG33_801_G": "7b9a9585929dc0975021a1049edb4b168324b70626909fc92427ffc116239871",
	"BG33_807": "3dfab4f1cddd0b1dd2ce9cc4b3eae6ffa956e83f2512b0ada1fda6f9e54e7f4d",
	"BG33_807_G": "7c7defc7b26349b8c5aa03bad996cfb4d335a8297acb246b7fcedb02948a29a3",
	"BG33_809": "32cd3225ae01a6664ff24522fd22ffb5f214fcc07312801f36334d6d4e761140",
	"BG33_809_G": "8f4d87070d0e7ce96035935e696f273a61125a8d2d9a990361be0d374a1e479e",
	"BG33_811": "025fdeb5d69cd571e39bc9f28a30ff2df5fb25d174996d10576468426f09395a",
	"BG33_812": "8b97ed9e26e15e911a50329cc6ff7845a0389fdabfcb0bbd0c536f7b763d6e67",
	"BG33_813": "9022779d647ac72add4bc6a74f072315db7e1a3cd47f591f7977d66d84c3e15c",
	"BG33_815": "4a56b48d78912922609c0958177847063d1c8d4ab32b50ddf221d6e3c1d0db35",
	"BG33_817": "a323f34a1cb877f9de3002af2316eaf22c0184af4a4fc49041a5f1ea3fa76529",
	"BG33_826": "dfbe7f7e69fb07388efa1488b33c2ab11331688159ecbdba4b8ffe262cf72386",
	"BG33_826_G": "4dd9d64d5e3947aa7a02a4e5999c9ba7125e7d715fd003739be3a891c7366aa0",
	"BG33_827": "c6ffff8ad12d341f823c6dd09ede0d7f6de4297f4f070a289c0b6a4cd42b8db8",
	"BG33_827_G": "7cc6ad91d48e28ec8ce482618e4daf4ca6807e0b383d18b533c1381abaf58df8",
	"BG33_830": "d678f5a023caecedd92b65ee280d28cd65bfe7264ffad39caca45ce74f5c101d",
	"BG33_830_G": "46d32ca2fb63ce9b07747fc594e9eff3aa98fa2f67e927b91f31769abbaab63c",
	"BG33_841": "0ab0f20d76bd8524dc90ac4a7fee534a7f5945fb8afb46d045cf6fdfc64f485a",
	"BG33_841_G": "b8b45ae019ebaf9c99f640c8bc9076907112d08996f7fb6ac55ca84033e3a72d",
	"BG33_845": "33d89cfff8f7d30c770ab38aa05ed3c3092267c31c790c4abff6bb4289f59803",
	"BG33_845_G": "716ff077a432b61813c3f72cc5d4e7623eb79ed10e0df92cb1b30408dff23954",
	"BG33_870": "b8069f3b465ccd31330a4642fc6b6f41471781e8c357a508840dfec98c46a0c0",
	"BG33_870_G": "03e726ad64dacd34231f3ecd98e08b76137e7879f1941f41d6109025b67a6d54",
	"BG33_895": "53591055bcd3c522b16cc2eb25cd747e62ba80aa203119ee54461189680a014c",
	"BG33_895_G": "418cc5b7d235c020003650941a712b2f710b1495fd8906a0cc83be304770a959",
	"BG33_896": "41057a1cb7618731718c1ce8f9dd129c7028225a605d50628ca5e8a484c57c31",
	"BG33_896_G": "40d24bf64499f0e315def3b59b8fe815880408429f2a402662df471dae5fb6fc",
	"BG33_898": "2fe8ef9c4cbd43c0a1ee89c128ad24baa3f4a26228468d08749362be862953b6",
	"BG33_Reward_012": "dda0722b58b1fd1c329ef4699266d90032f60e821ff824385482f21564d99f39",
	"BG33_Reward_012t": "255cd9c0ada8fb05f69802e41ed7bef735b7ee22da00fb254e0fd51d04813c6c",
	"BG34_140": "4ccc81967931271d0da47f532d86450d0837d327dabef92b77a6c2e81b47fd90",
	"BG34_140_G": "e48282768b1640a6be2cd88af2f5f8ae28482263c047a2c5cec0c78b9f4af4ec",
	"BG34_142": "b95541aed53e2f86e9454e8d460d3df53ab974cf0bc200dcdd4a5bf5d9437485",
	"BG34_142_G": "93181ce982af0b8c8ae53e1a886fe70b31d88d01f088c697e3c9580bdb4253f1",
	"BG34_145": "03aaacdc16b1d11d8cc041cffed212defc7449d17ccbdb24e1b3e40cce08519b",
	"BG34_145_G": "69f1d46a8deebd5c39fc56a2a4d31120479110a41eb7fed6ffa3d04d55911e6e",
	"BG34_230": "4fcd9f9b8456e62bb667a422ac9c6d5ef830b0360ebf0dbdc68a19ca39eeb1fd",
	"BG34_230_G": "d326861a49958b6271e1063afacd15adb4be841bbc62f295b5dec01d3d6a2780",
	"BG34_322": "169297055813b8aae9140b5dd859df0d7bfaa26d9eab82a6403dc166e0623119",
	"BG34_322_G": "2a63f2633dd34d872af11f2494e1d0002ae1ae7d5fc35cadbfb94f7c50d157e7",
	"BG34_407": "ce0acbf50cef02f8ace5907cf65872ec83e8fe66f87bd471519646799f0aefb3",
	"BG34_407_G": "788c06aa6498e276164e235935eb5c5bc043afb3aa09032de09474821a1b3523",
	"BG34_407_Gt": "0d399a04edc3600763b2827939e6802db858767c9a10a91eacf70e432003dd76",
	"BG34_407t": "e3a68d85b44c15bec9ef73f5b0ec3c7c3f16801ca0ff9ca31f61c1df32284313",
	"BG34_500": "54a508596df06426a421dca8afbc6b60856301024fd9abfdd7c2ed6e2573850e",
	"BG34_500_G": "0bbe658212d5988d520fe9aa1ba7be6294fc9f2ab4fcbaad7e6f8f61f88d4802",
	"BG34_523": "65b0a29350f19b783acff774d9dcfae5029e1a2cc4b0bba2c04e52d60c4b9562",
	"BG34_523_G": "c2e135bf043f514a60d4e823bb0786606624da0dac9e3963d5002b4e91c69657",
	"BG34_630_Gt": "03409ba4ecc310c1cf82ceb08d42100f7652fe44ad13bce83c8eb986adf1f160",
	"BG34_630t": "e92c0e41918fddd5101396927132e62a876af3ea48e64e38280eb74fcb4637bf",
	"BG34_635_Gt": "af3918a7fb44d97aacd082b60f496b767cf0b4d871c600a24e3e87bfbd1cdf73",
	"BG34_635t": "1009a5c5eae22901b0e8e73efadaf493f16f903e68f03b923ecdd06166614a24",
	"BG34_636_Gt": "358268d3823c02ded96150bf85e6ebbae1b59f57df6ffef58e559a9958c1416c",
	"BG34_636t": "e730bd884c74aca940ea499fd94f722b68724f46139159c1bf805862e3e47ff3",
	"BG34_637_Gt": "6ee160f862b69b8c198f0276341c3cd5994e1009ee22c3fb39a034f053140d61",
	"BG34_637t": "434207d80f88dde95bc9eb3a8ce6293cfcd00ff390683b7342d2eab096c244d5",
	"BG34_638_Gt": "566f64dd5f50572df7810bf6d0329f2ad4eb06f6131463dce6acca52b57ffaaa",
	"BG34_638t": "a153cbd85b7a1c1405dcf1e65a881c94c8c3d220fb919b9019dd20508dd47262",
	"BG34_641": "705b864c0614050f7f3f2490ac650de76116ec6c6e56b75aa7639575d2fb5ec2",
	"BG34_641_G": "452e45c90fa196531481e209529d1d94b28eddc70c2cffca3acd707d5cc75401",
	"BG34_691": "f5051dd3e5d1af83e067d731f8b53f434909ef5118ef1d6910cf60403a5a0474",
	"BG34_691_G": "3ec5eb049cb8d22553c2d3cfa7aea6736d8116626e93e260e081d680091997fa",
	"BG34_990": "3cedb9210448b5c98db490a89a125eea3be2d57de7512b6c8c37d638a4b5be69",
	"BG34_Giant_001": "3bacbec8c3c6de308f061e15319e743c9149986bb4774c0b45c12aaff779ec00",
	"BG34_Giant_001_G": "4026a2a1455bffb90f6bf20b4d0882c3ba65fceb69e20a3c79f56845ec3141b9",
	"BG34_Giant_007": "c072eeb15e0f133c621b0271301e5afdec0307c589d320bf025e756135714d8f",
	"BG34_Giant_007_G": "a4fafc8c781a1c2eb6b9b6efc34d283d7c1a4d0fe1e5d928103f64f084a8fcdc",
	"BG34_Giant_012": "518a851044bcce0dfe066f4f81395cc663effe11971eba2abbd5e3da076453e4",
	"BG34_Giant_012_G": "dff3176da592cc93ea9a2d2a1c44fda8dcdec7b68055ff0e8b40d62d85e6dc35",
	"BG34_Giant_015": "c978700e798621b470aead0e9d9153b4bf3db5bd2f0e14a7011d9811186ad110",
	"BG34_Giant_015_G": "1c9235ac30f79821c928ae4791591bb8ee1ce49ae7b0a84622f984b50ce3b3a3",
	"BG34_Giant_021": "900bdb0595903f2e99c06508ee22161f9029328c3e318cf1826361a359407f53",
	"BG34_Giant_021_G": "c4c83997e44c88e2d4f66d0a4e2f9dfe338d7ac48f21b9714c74a35136cc1108",
	"BG34_Giant_029": "3d747aa653388e8f214a84dc6ca6f8d1ff09c5ba06d8ff92d15bdaadfff3ba17",
	"BG34_Giant_029_G": "5dc9302ff8775daedd8c2ce434f9b080ab1fa8a1e8b3e2d4c4228416103e8f49",
	"BG34_Giant_032": "0ea88ecff9ff0345844a232cc801c2d232981b2cf3cb00d2819d7a197b3a5f19",
	"BG34_Giant_032_G": "27741773e08f25218a3be32e25126638f98c1e4ba39bf1fb46d77cf60df7e37f",
	"BG34_Giant_035": "5d18ef0c6a3feb73714fc7d8388739485f9128bca718ed84e135df4a02f642b3",
	"BG34_Giant_035_G": "fd99c4039727d98790677c9693f827480a5a79eda4e04242cb9a5c120ab71575",
	"BG34_Giant_035t": "4bcb1fb365df1876bf6fada2d6726f45883518dcfb1692f0fb2c27fbb1388210",
	"BG34_Giant_035t_G": "e7607dc208c36e5974b346764cdd7fbe4a8b020f7cfce4008e4f9114928749b2",
	"BG34_Giant_065": "ccec2f72340ad5e27e765600fb9d562ee20a0f8056cce0def453e6702b3f610c",
	"BG34_Giant_065_G": "c3ae43682ff53c539c55fcc210051dcfcc55a0300ed3925e20e229f28de6f13f",
	"BG34_Giant_071": "0cf47ceb45460524cb6cac725eb98ab968b555c94a0ea6aa326e614ca642e3ea",
	"BG34_Giant_071_G": "421db1ae1b6f1b34e89a7fdce45f6709b8fd4cd15875269fb4b55b1b4e8cb61d",
	"BG34_Giant_110": "3cc0d24a02e60435f0d705208347e81cf44525147f3ff1f9c4b291d008b8173a",
	"BG34_Giant_110_G": "0a1a26c4e4cf1f244684d15e77ba9322b24bba1d8a1c416aabdf725aa97c10e6",
	"BG34_Giant_205": "c09c72fa35f2476c4206a217921a0145a637c53d690c204c701b442f5af32b5c",
	"BG34_Giant_205_G": "7c217cb9a7f0a1e2622967c5f6faed1e806fd362030968f049da7942f79d4ca0",
	"BG34_Giant_209": "e2cd9c6deee29640e9051ec91e83a9d3ffc8156261c37cbd4a12e1048c5f64fb",
	"BG34_Giant_209_G": "db7da56a2dfc8303105e9864d40952b9d810cdc854ffc256c3754d070023c290",
	"BG34_Giant_210": "1cd41e5101a1c1163c226747692a5fe5f85111c55d9a33214edf7740b235fe85",
	"BG34_Giant_210_G": "8401c73497c2ae8fa4934efb68c7006be2e7e2179911a87dbc98a949b2d39f05",
	"BG34_Giant_210_Gt": "7cf8b5d2f4f0fd02dcc12817fd1f576ab99b80b4fae541bf99184f9d650249ff",
	"BG34_Giant_210t": "612bce7c6a241a2fc9257edae64da3b319ab4544409a08df1ef2d1c189afbc32",
	"BG34_Giant_212": "47519464c79e1431b93ef6a64cd7ea00061c6d4303011310b88efe4e8908ea85",
	"BG34_Giant_212_G": "d426b6d91bf2f1b59fcd2b6db5caf9b6d25524124ced0e6dfd3a6a069aa711a5",
	"BG34_Giant_212_Gt": "1bbb09aa5adca3f163dbecf8197ed88b7a24e2eaa3178eb8c112a5694e6c59de",
	"BG34_Giant_212t": "c808e4ad8b5fdcb74cfdca8a90cc0e8ba219661f554644f9593159e8b156e32c",
	"BG34_Giant_310": "8ce6578acb8b09976dd316ee95a870a6617b72176fb5689a96a6f2ec345637ae",
	"BG34_Giant_310_G": "adbc0ca8ea81bc9de973272c47a8134906f2c125ad8e12e6d96936d203ba9d40",
	"BG34_Giant_321": "842cbdc0396df90b2d6f942320bb065d6299868682d1ddf5d74563c4d2548bfb",
	"BG34_Giant_321_G": "5f1c3348b9e4669583188c0ad4afdec3bbe93de90eedca44fcab80768f793ee3",
	"BG34_Giant_581": "92cacbd1686d0b88bbb7ffe33a2384825d17b381a63130689f36f77b85a95b38",
	"BG34_Giant_581_G": "c041f527d026c00cac649a95f0c3119acd3cd729e5f531378a442b1c278f0200",
	"BG34_Giant_583_Gt": "d834497c96ddfd4fdb7c42cc29bcae31fc71f768f9e7220e73e0aa5937d8cae4",
	"BG34_Giant_583t": "7d6107e924c655935b18d732ade115a3b15230f8faf2cd36b9d4b0ee0ae7755d",
	"BG34_Giant_588": "5cd629978fa8f43c2de05a1609215be7ab897f40339e909979c564b1ae9c9c0e",
	"BG34_Giant_588_G": "1e99766661c6b28ea53e3b9287dc142855d4610a25f114426adf45bd67213c8a",
	"BG34_Giant_597": "2e93a80474dcf415a7bf38a0df458895bcd7a7e67ad5b433c8ed579e02fe87db",
	"BG34_Giant_597_G": "31b3d4de00ada0d681a3c081487ec1e31a2012f11b112da8965958bda656205f",
	"BG34_Giant_604": "72ce70bbd9c040e5dc839fcbb3e63dbe1ea1ee73c71834d3101df90056ab0ee8",
	"BG34_Giant_604_G": "b9064b8670e6c61a1078ac09789df10dc89ad0b45b1181c062c5b500670b3339",
	"BG34_Giant_610_Gt": "49f7556d7c19c08efdbfc9cfdbfcbf4d9585a7d2278279ba54930f02d392297c",
	"BG34_Giant_610t": "55386b7b569666ffcc78abffe0303759324f53d150e754d41228089130eb6890",
	"BG34_PreMadeChamp_002": "9564635251ea8357ec830bcecb5b493a7060e2f49c0b3bdf70f7fa8193964f6f",
	"BG34_PreMadeChamp_002_G": "b42c0428d8b962b762c5908e7113254f36511abac22a179b4a33f91baa82625b",
	"BG34_PreMadeChamp_011": "f7df870302991a59e355ad6421c613b92fbfd59e55e1dff811c00fd8b8e1afab",
	"BG34_PreMadeChamp_011_G": "c1307a9c743ca743eb8fbab1b479be57bc34d05cef316fcaaa72f17cbab89d8e",
	"BG34_PreMadeChamp_020": "62a6ce41e9931448085ff7998b8569e01d837c04713399eda87dfbb6b6667ddb",
	"BG34_PreMadeChamp_020_G": "283c4b32e31dc6028bfaa6255cbcde1245f6234507deeaef66129d72fd8795c8",
	"BG34_PreMadeChamp_022": "706c8908d18dccce2a6c7bd77b2217e60244b4615d915a9c482f1e47a5a26432",
	"BG34_PreMadeChamp_022_G": "72609519339170d898a22ebaa5cfd36521fc5121705f8a80fb27787d3c441b0b",
	"BG34_PreMadeChamp_049": "650f37b861373e0098b63227ee462bd3491232e770b52659c46682497dc2e586",
	"BG34_PreMadeChamp_049_G": "8fb38657ba1d5a870d5621131af654953aae700880e358a6a4424497f1999622",
	"BG34_PreMadeChamp_058": "7c31281bf497c7a49aec9ebf60a4727037eeab976b0732c7950ec001dba80268",
	"BG34_PreMadeChamp_058_G": "df12f0cce8d25518a2020bdc06c3c194063e180c5e8307d0232a96c39bf9576b",
	"BG34_Treasure_906": "1b42a3392d66011c671a43ed970d3b1b8627ccf7167b25b9979b42bea1fc4604",
	"BG34_Treasure_932": "9c6b645eb2378d8634e4dd99569f4c10cb48931588a5425396ab473fd1a85468",
	"BG34_Treasure_990": "42326e25520d775d33c09826a39ba0e3a4e89854fc21246c3580c077aae44996",
	"BG34_Treasure_990_G": "ef36e6fcfda695c94fd47ad076a5ca9d4f8afa9f1e0527d5b9b90035382d95a8",
	"BG35_143": "57d3b03af6e2954e0402fe5a1b38fd630ce13a9f66e46406ae5662548c092227",
	"BG35_143_G": "7dfe5d2e9aac7d2d81777b0708e60abf4f1c4689cdf6e67245209227bea27147",
	"BG35_149": "280ccaf0c8b708eb626ec76c84280018bcece467def934d2a2e6547fc789de69",
	"BG35_701": "a9da9332d6b88d0beabba837f40f4d19f1561ed07ed30ee9ae3a5577db673bd2",
	"BG35_701_G": "626b3e6cdc417cd8bd56b0a9701392b4a0488a6ce99334b4625a136de6305009",
	"BG35_922": "c4563039a952bb69572ad51c6b9e74c6ef96ae1bc9d083666ab4e58beec6886b",
	"BG35_MagicItem_710": "81299fda7ba1be5ef33a4592a01d0a38f1647eb8e3d1bcae3d40ce74b870bcea",
	"BG35_MagicItem_711": "97daada388a794fdf34d14a10e703de86449956a92b49496268169775e3482eb",
	"BG35_MagicItem_754": "b86f213927689013d9b60b517f0db9425379bdfa6e8c34494986dbc942f3e9b4",
	"BG35_MagicItem_814": "80c43b0d232f125cabb837cc425672a6a418c378dce2130500ba01609fc1984f",
	"BG35_MagicItem_852": "35a436d771d8bd38d6fab7b52ea1f7ffb5da3752cc65e5737ac466c308c1d0a2",
	"BG35_MagicItem_862": "3e8fe1c106ebad71a107033bf6631cba2908abcd7448a67b97c559f836e2f190",
	"BG36_200": "54c559d62abd6312a82383317f502a7f91cb0e1bc6dbe18a5cb06f6f5ad3c13a",
	"BG36_200_G": "1787bdcca97f8f3af758543d93b4a4b6f459dea78675b4fc6f82a75d938ea1f6",
	"BG36_200_Gt": "dc039acc046cef5bd61696bfb8071b00d7b6d2dd12b4880ac1f010a83ad33c02",
	"BG36_200t": "9fcfbc6ce24473a55eb5288970eb9729966965971cef1a8739e66009ad836555",
	"BG36_207": "0262d971899d0168ebcf9e784c8154bf81dff815f5a7c79c83621625579b8e65",
	"BG36_207_G": "5092c51b88f0dd6e1dd1f2dc797a99c81b4e33108a5d13a9add2ff387ff24599",
	"BG36_246": "e4a24bf0a3d389a5a9c7bd140fe50339bf7ecefafdcc3b5a63b5589cb237e22a",
	"BG36_330": "c72dccd1ff1197c6fbf7326ac234964e9be94fc822dada380793f3c6eb0a0aa2",
	"BG36_330_G": "93535d5623e04ec57a6c9e56c844ea86674ed7e659ee3a85091fbf0441774e21",
	"BG36_330_Gt": "8b639602debc1fc13b6dea22736d1cc020c2702ec4e4ed3c26a3636ddb9cb461",
	"BG36_330_Gt2": "3b322c00597119a77f5959604900f4291cb9195d66a14fb99411162fb9dbc8bc",
	"BG36_330t": "be2b07a39a4ea3d895708e1443cf3484767879a9ccc3ad3dbc7b315dc128866e",
	"BG36_330t2": "fc550ad90a8eafaa74721a09581b78a4307c525c7c619a11ae1ab341e4445ecf",
	"BG36_332_Gt2": "f485643d6ddbd2cadc788f7e3d12080e681002976ee777ab1047150cc31206f0",
	"BG36_332t2": "8ae4acd244dd5c77e498c0a54180b43e6bc3b6138ce5ad0590247275f0f725fe",
	"BG36_346": "059339a78a9e09e1347d4553178b7d22ef876d4374ecb576868ab749f576cd4a",
	"BG36_346_G": "2f4d7cdf365c7e1f1707bcb532801f8cb2f0c9ee6a6186c48bae84e3611c8726",
	"BG36_624": "1ebae6dbdc1ff4a3cd386483f32178888378d18b7c4ddc5c1b366b515beded5c",
	"BG36_703": "86fca359be0bf8d94ec400d028647b6206a9c794e287b72c4f36c171f587e9a2",
	"BG36_703_G": "6be17acb81f740b022690b964ef3067ce4394f6bd0417605de86076e78371d8e",
	"BG36_704": "efa3e1d910964dd4e4afe3de084a5cdcfe13d42585363ba84d1069bd58d766ff",
	"BG36_704_G": "137b2145d8b3c59c918d0767f64f8e0b4465f6aeb07c3b555a07254ccbaae9dd",
	"BG36_854": "44c3e25de9c95499e0bfb3f1a5ee0a6f137ef2b414e0294a6b2474c6f8359f89",
	"BG36_854_G": "0f5d65ae83ed0feb062f5fa75ec62886040ea35a1fcf71584ac5442d2005d112",
	"BG36_884": "c46f6ccb696dfb758cb5a66c8c436cefdac05e9cb2a523a21c65a31d3fd68d8f",
	"BG36_MagicItem_213": "f1ad8dc8a79d3cd62b46e7197591fed8572fc605b551bdf4f63c91a62f99b6a4",
	"BG36_MagicItem_220": "f216a54f31787086455c1cd9d3f71e5fdcd80e10cbee711640d2063cdabae539",
	"BG36_MagicItem_300": "3383d43a5ec1bde7565fc031aea92bbd66fbc60f76f4eb5c1cc3ab0108fcd8ed",
	"BG36_MagicItem_307": "94cfd083f98f4bdfe6cfbd68624bafc8df21c065248f42381a8741b9a071076f",
	"BG36_MagicItem_361": "bc8e8d79ad3a61ad3a4e0ba8f40b6a3de43decc0b4a0cb9e867536f7e8acb759",
	"BG36_MagicItem_372": "a56fbf4a89b79b317a03c2d85bf6ae3c15060695903f889642d297f7254953da",
	"BG36_MagicItem_424": "6741f0041fed0a3ca98e0ab055ffd044472e7f4978ecc604258eed3f8aca64c8",
	"BG36_MagicItem_800": "23d5e17d3711ce2b54ddd3a5611aab50db7a9206d4523abd83dc7c348877b40e",
	"BGFYM_002t": "c68ca899837737c2620344bc9fcb18dfc5d912f11ec3214367e4966db2e52850",
	"BGFYM_002t_G": "fae9fc99dc0cae28091018beeafdc32ff74cd28b9f2b471701cedecfef575575",
	"BGS_001": "f600311cdf345a4e6b9ac8094822dda9d0f3b19123d2a5191439668b2a4b335b",
	"BGS_002": "86885ab80d8b85b4d61d6d208a7f93469cf135c268de8dd1566fadae655b396f",
	"BGS_004": "777ca37e72485c1cebd9cfadc53658b7b3bce73690de1e11f2cc6c6791ce7a2a",
	"BGS_009": "4b1bdf5b8fa5055f63a400474d2d45500b4e105ce2fb87b0a708dbb892ff4b9a",
	"BGS_010": "7dcbaa0bb42a1e54b907d9be4c03027d43dbe0d11817101324c99452b2318611",
	"BGS_012": "0ab00c8d2499fd76537e8fc6b839cbd97b4108d464b3bb72ce23e5953d57ef0d",
	"BGS_014": "f6d7782dfcda71bd8cb97eabae68f21724e7a74faedd7fb3aa2419916897073a",
	"BGS_017": "b4da80c2f0340e7b56f862de3e90ad2d02bc0f85d4ee8bd65c6f1916d3f3054f",
	"BGS_019": "57e83176cdaf8217140b2de6bea92632265210cbeca6d79d3c3ffaef2139f75f",
	"BGS_020": "01a27cb24b1434ead92c05ce70b506e3de8390cd6992a94e3b2bd3c37d8a7a06",
	"BGS_021": "7ab4b0e7caef175a412c8f391910c4d6e49cabf770c729f70e22a9505f2b7711",
	"BGS_022": "09248ff81730fff0c3fd198249e37656e2c9d4de5df3e3c11e6d9abd9afc8514",
	"BGS_027": "f86491c5f2ee879973817873c02cc965239385260f39f56ec1937c93fb6d6f31",
	"BGS_028": "477d27220fc1d76e125c34d4860cc4e3006b91407f6f804b003dc0135035ad85",
	"BGS_030": "19358acbd6e68c4b3818b687284c9cd677ef21183174d40ab46c6c0c106fec76",
	"BGS_034": "cd40ea28fb62d2fd2277e8656922714df53fa08cc1a189be73bc6a1bc9181fe4",
	"BGS_036": "63804833cc0f5b67f34777a285592768dda7f4e7c40043603ce6b8d39fee1e5e",
	"BGS_037": "b02bba672fb7db30acc1719fbf9c1478ff4c294da70ddaf48477bbdecaaf471e",
	"BGS_038": "1067ef0b4766fac8a04577b908495902756234b095bd73a60a5c726bd6edf615",
	"BGS_039": "351ad86ca26b8c55f0a675c4b328d10923467b657a765d9edc7e560b6f358971",
	"BGS_040": "5eec6065b8a6bd81af3732420f8535bbd864292132b75e3c68fcf07f3d6cb9ae",
	"BGS_041": "a48509832d4484516ba6fe9c60d6b4ce21eb162c8abf99d567debf91649d02d8",
	"BGS_045": "bc3325fb7e8d98a028e68e16bca8a171cfaaa1df98bffe7c095be9f0371bb6cf",
	"BGS_047": "4a6bfbbdf8d64abd2f8bc41ad7d79d8779daaaf58c5356d0d1d7b01cc1f1f6dc",
	"BGS_048": "8f647362154ad483f00b34598574fff9827973ec0bae61fcd1ca027a673cd6c9",
	"BGS_049": "a244847d8655948b59ba406c3ca29ea47526d3eaf484f8a0b47af61c8d03e819",
	"BGS_053": "d8caca38ca88ffc0f93d03c8986ca1e966983bc76598b8d7faea3002111a7f4c",
	"BGS_055": "0f58055fc33f42889f68fe29cfeeae4c76c3b7ed34269b0ed5b8bb528ae5523b",
	"BGS_056": "856119edd53c8311eedfa0c4d13dbd675cf05df23ef3c44f11fc6e243a68af13",
	"BGS_061t": "bc62213513654590fb1b491a8689134d3a923b2b1ef97c5361ec72a267c972ba",
	"BGS_066": "2ba372d3e0cfd0c5f1f7d670d9ba56c14af9b6b746495f3b2c435cf869c1a4a0",
	"BGS_071": "4f21183d9d606ae956728d73a5f2a70a3fc0f3fd6f2d832be82e27b7b86f4bdc",
	"BGS_072": "b3d338a307fcbf861b493bad07e8ff77906dfeecd78ae19b61c74608044e1073",
	"BGS_075": "9d8867b2019f162e5e4b3af733bf4b36c50a01c3ff18dbac8f02178c4030db44",
	"BGS_078": "3944bf5c454594d4b7a5dbf5b25f7db26b600edb10622ea9a1f535fccd60ddd6",
	"BGS_082": "88a749600aa2cb78e8968bdbac3f60412a1061c44327f5bb2543991f5e5afc03",
	"BGS_083": "4fa1f05a75706697d207a39207a39c82b8c44abfe68e7f5702e1ab7cda5658ef",
	"BGS_100": "477d64eb7b892f2b6bd2945261f23d259458fe687083b12396a680ff32fa4167",
	"BGS_104": "0ddc7e321d61b72e4372c0b4a1965bff9640af7cf1218a53c0983795ae14fa77",
	"BGS_105": "a59849750854ad6efcb4b88c735caa4813c6ab5451a2e18799d1739b5bccfdc7",
	"BGS_106": "b34bd211b014772c63e1e40dd9bb872b24d805659dabd4f97d9511768d7e1f7a",
	"BGS_110": "7bd3fa11539b75ce58b97c22c20e4ba94b102d757177a2117bab5ba2c7312081",
	"BGS_112": "2064a6d661c33cf724152dce8ef7fc9d30a5342a290a0c51ff755eabbab3028c",
	"BGS_115": "58361ef745be74924fc70d57609c5726526b0b324fe0e97830e6993edc3363b6",
	"BGS_115t": "32abc58c3c87bf621535a1f336f256032ba5eac8ca749227c8f5eda0d8e096c2",
	"BGS_115t_G": "2c98dce45c94f066c1c7561ecc6172740e80a6a7abdfa3b9a396f4f19abdd64b",
	"BGS_116": "9320813ee85b0635efc5ba5a7559b6acc22f4739f944116c82ceda7324bebde0",
	"BGS_119": "b45c56ab383b420da9c2fc9df0cfe18df52afd9f4a9593a0e0e1a81a7332a722",
	"BGS_120": "0af7af80ee2f39adbecf1f49acedaca4e5fa483e506560f6a3a890ee9fdb43c5",
	"BGS_122": "e93452470a6de1fe2c033369b59c716844be803f20fc8e9ab0b42ddab0744d10",
	"BGS_123": "08dbef7de677042e9f2354bdacdad41be063f86aff466e6045d1c360d6500338",
	"BGS_124": "930804dddfdd92a575d79c6e09b8c121fd551475326beb2d42c45e9a0afe5f97",
	"BGS_127": "9ccef1bdb0965035da52e5c3c551c8f042051008f5b49f2f2cb58e2ed6ae82e1",
	"BGS_128": "3fbf09f3564d1e41908e54ad49fd81516f34a3f61936846f6fdaa2abd73e10fe",
	"BGS_131": "9a46cd29d947b2e044a0325f593079dd49c77c3d41030608b48b2ad26c513f9b",
	"BGS_200": "cc3ecd6a197d2bbd6e023cd5ca8532f6cd6fc4f6ba732daab03483880e63c6f3",
	"BGS_200t": "dc5498542b01a7a9654b29f13d8c9457578c87bc50b72a53a142e51ec0bcdb6b",
	"BGS_202": "86bfe045e893e2e27611b2ba9a97f7322522296d60b96d96f2f28c59312accab",
	"BGS_204": "af92eef8bc0ccfdc44402fcd877169465589691363da90dff8f60467aca7fb28",
	"BGS_Treasures_000": "b292df6ed2bc5c6816ecdba119da2af48dfbcb941c59cdd34653b940e469dad7",
	"BGS_Treasures_001": "00dde9af9ca1da016595b6a0540020b587dabf2f5e2212886facb1c42e10cb7a",
	"BGS_Treasures_004": "2037728ec3f2d680c52ef2baeaf31112c27bb39acc305d1ff60adfdcb4488f0e",
	"BGS_Treasures_009": "ef3dd1727d3a56a1faf7a034fb1cdee1ea974e9a5087d1aa7b470c18970e82a3",
	"BGS_Treasures_012": "cf53cf0b9d03a7d2081e405efad3607d19edd02bca066255293e8e155f77b595",
	"BGS_Treasures_013": "4bae3656d3a1f15364daefb7e3a714425d86564c7734990dd5caf2dfd7d6d774",
	"BGS_Treasures_014": "954469da6af041f71a96f930732da5707588fc6cb984281aa51d08118de14205",
	"BGS_Treasures_015": "eeaaf33ceef6f0c95ab00e4f79761d412a10804ecb93902d89910d8f09e344d8",
	"BGS_Treasures_016": "0dc345350863dc09e45620e87361d5377c7d865978a4cd3acb27c7a39be796ba",
	"BGS_Treasures_018": "9beffa40ca4cd14641fd0c13d4566ffa757ced6693991dcb8d6e6ebf76a43227",
	"BGS_Treasures_019": "448394f546bf0dbf6fbd0576a2230a712de22cbf025caa22e043cb7ead589fd0",
	"BGS_Treasures_022": "c0a8eeac2807140f410dae27722fa49eb44415de8214d6315481809d2d6c114c",
	"BGS_Treasures_023": "1e431a0bf483f20b478f1c33652df7d2b065a520d99c4c89a23063091c3bc955",
	"BGS_Treasures_025": "65c5a04ad4f3b01cc32d82748bb66b03b92d74fea25ef3754c858f539c0a33c7",
	"BGS_Treasures_026": "6de6070db2521c34ee6bfe6a8ec0ed082845c89edd39a58490d659f472905650",
	"BGS_Treasures_028": "4b32763230b05a256e95b2dc182a2f9e9a44c482a683da72f4db127dc4c3f56d",
	"BGS_Treasures_029": "a12ee9f86589abbcfdc45ad26572daabbc4394c3d108f057cc0f84aef349aded",
	"BGS_Treasures_030": "f543fefc749af54ba4796d8f27602ddb9908b0cf2b8c2affb1641fe7c9301508",
	"BGS_Treasures_034": "f8b1b0798321d20b6c669ad708a825be0580260cb1b06fdc23e3fe8dda937f2d",
	"BGS_Treasures_037": "98e52b6b1efa033e7167db1958d236f8229fcc4758b0dcb2fc3059675011655a",
	"BGS_Treasures_039": "9f197f192c98038bfd074764bd49d3ba69826ad02f5b5cbea9387d9508cfa137",
	"BGS_Treasures_040": "e138a681843dfaefb04a33fc1b779f52e2241f2e01549c1724bf9cbbc72f59c1",
	"BGS_Treasures_104": "1ee585bff434b167567de870ba27b4183e30af27b42957b030a2311ed84be41a",
	"BGS_Treasures_110": "f85add1f6bcea603c7a660b612edd7ba2c35c7ddde152713dfb159766f9752cb",
	"BG_AT_069": "04026df71ecffc1bf6ae3477aba4eee21e70d5a0dc8040e9ce76518d3a0c3164",
	"BG_AT_069_G": "3e81901f96d16ef4a43f230f01d662baef289a8b92e8af45c9cecf581fd5e59a",
	"BG_AV_309": "979fbd2adc4cf514413003bd530d55f0da1cc20a1cfb3cb663e9d4069a75167d",
	"BG_AV_309_G": "b34d743b7c993a47790d15fb47e8ba4584adcb28d46bee0b32035f7b1fbf3045",
	"BG_AV_309_Gt": "72b2065c1befd4d89b402e04116358cb57fcc73565badfdde3d24a7349b16ee3",
	"BG_AV_309t": "81c4bf5dd24c51c59dc64e565aedb5abff7037cf8c44f104955b552f5c6da8d1",
	"BG_BOT_218t": "21e0ed564e9be9869814f41e6f5280180afb2d037d9303b2d7e905be1257fd9c",
	"BG_BOT_312": "0a7e61408b4753385a0c16e945157c91e58b015bd19a68bceb3dfb175b907d2a",
	"BG_BOT_312t": "f706b65d5dad5d4e64a4b0cba196920ad7745150d9d7c37fbaa351ddfcf0cc69",
	"BG_BOT_445": "01be916d87b923757f93cd3a4e903eaaa6162a8c3fded4ae28c130dc441adc71",
	"BG_BOT_445t": "06aa27cb3b7c42e9d4d446dd4f0721af566894106ef0e7a4656f01f9f9c4f6e7",
	"BG_BOT_563": "c19ce0ee6b3b61d6edfc31c488aa078f20f25a1273bd10955b588e633d857280",
	"BG_BOT_563_G": "335758ccb25003848d7ad0fa104e47b9da5e9992b44501c6511d98a436a9450a",
	"BG_BOT_606": "d039c5050cd0b6dfa033d24625696d0eb530263755ea028dece72e0757f50f1b",
	"BG_BOT_911": "915c307dcc0f191da4eb48165e39a255fcf5728137da16bf4d15c1214062a1c4",
	"BG_BRM_006t": "802ad9dc073a1ad5258cd277156f3074f3426b9200a4e01872cf40efa05bf806",
	"BG_BT_010": "4f2a7ff9640aef6c175310c7da2561d33fcfac90b401c9d02b4cc8872ecba128",
	"BG_CFM_315": "c36ce24cff276a050ff6503d4cfc7eed205d850c285b9bc79408f49d29a2294b",
	"BG_CFM_315t": "4bd05479be49a47d468d9db281d53a2777d71432c506a77a0484dadbc5220e52",
	"BG_CFM_316": "4a895e10735f444035bdad70bad5ab0121c6017198242230f3849bdaf190a270",
	"BG_CFM_316t": "7eed9ae5bc459fd98ccd9d9ae7a1329f8e0d113595695f01fa25a41789d6937e",
	"BG_CFM_610": "4606b9f26a167dd2d33949436ae8befb3b0ec0d8fde4064760bb0234d3d1d79c",
	"BG_CS2_065": "f57b42a0cfc2fca0d6f0f13e4ab90f29deaa621bd3009f46724f45eabb6a82e4",
	"BG_CS2_127": "718c26294226344093eab825d1feeebccd6df9e23e1be09dd16e5dbcbbbe69f8",
	"BG_CS2_127_G": "33072cbe2dd22477821e548b3b76c72c2ef41b7d2674c8b2ec59035f7a6dbe08",
	"BG_DAL_077": "286e70b115c1c53acd5d28f0eaf63a957cb7cef60b6532cfc04ae312f41f048e",
	"BG_DAL_775": "c2b0c97db67a57ffe5aa7ae2379a35c3eac975ec14fa46ae1159f3119653c1c5",
	"BG_DAL_775_G": "1968defa02306a7c71177d495097c1e8b5090f08b9c3d295cdb4036f066cf2a4",
	"BG_DEEP_015": "baab84fb2b7f25036a7b34faf0391a7ec78496246c23d1fcd10cbb6e7bcb046a",
	"BG_DEEP_015_G": "91c0f9274a081739eb9607ab5461248cd0d437086e63c1d7154f722dd0e61e3c",
	"BG_DMF_533": "ffb2be13f60232d4c76888468040977a406e03614d6e2ab175f11a68f3cfa571",
	"BG_DMF_533t": "ede5a00d5ce2e9ca1ebb1bf767741ba4cdf2c2cd33728224f815387365aeaace",
	"BG_DS1_070": "8094bf89e395df4898dbce4ffef3b3ef568e7411b33126b06234bfe922ebecb2",
	"BG_EX1_014t": "e0ec0515df407b17a7671f634f2e2467b69239bb9deeb4540a18e57a10822e11",
	"BG_EX1_093": "b924376e4a37401bf8db261bbe68d26e46b0584f86c33972758cf297060c2c10",
	"BG_EX1_103": "42ec48cf0addc516cfdb031f05e092ba2af7a7cd4b9c2389e004c155cefe033e",
	"BG_EX1_170": "fe977cd2fcbdb7c714641de3f123c3efd83bb70a994cfa42499151d30893646f",
	"BG_EX1_170_G": "7093bde8869c883c78f30f37e934b065ffe62731ffff26fb104ba398a87cd057",
	"BG_EX1_185": "0a10044dc1ec6d077232b9f9363256acb971cd7ce36a348ae65c17a71a60d310",
	"BG_EX1_506": "245f797c17963fcd451d2ad4ceb8175b917d09c16e019a92b2d8c8a01fe45f42",
	"BG_EX1_506a": "3bf45d2884af3a621ab31e55c4f63703adfdc6bea1fc1cd93d41881fcb3e8cc2",
	"BG_EX1_507": "c7512a241fbf4216d6a056b17ff9655c0da8b8efd5772964a3eb3a03374f39f3",
	"BG_EX1_509": "c3b51b74badcba821856a0436a1add8f51f2b0d491f157a1fb234b64338983cb",
	"BG_EX1_531": "e4a50f67b6b89a9fa190c42ca1df3208f517f4adf26243fbe46cac9e0f62644e",
	"BG_EX1_534": "28b9928c5373b1b10eb7f27dd5ccffcb6b7c36e60f1090996057a966e88da6d9",
	"BG_EX1_534t": "f9ecb8638a2b5ce5c02fc96215329e110928d620637001cafdc008c24cadd4f6",
	"BG_EX1_554t": "84bff513cd9932a7aea53eb5f33becc4cff576c08debeafb85db77fc9b0c427a",
	"BG_EX1_554t_G": "1135aeebd7f055153d1e7e2123241639bf2f2d058b211ba3e14de03d686d718b",
	"BG_EX1_556": "748073e5d04cf23b4e9a97daf508d79f563ee6934b2cc55e83e2532993240bda",
	"BG_EX1_finkle": "a5412ed2ef2112ecf1b4a41e553cc8d8632c2755360b18255accc516a078568f",
	"BG_FP1_010": "1ec102939967f6d2e5e9fc98d10680e0679221fd5e35b6e8a822533fced06ffd",
	"BG_FP1_014t": "d4295a5c91fffaedb6b2562f225dc590e96a437b1e83472118f0a92b0d940931",
	"BG_FP1_024": "af6ef21408ad6cab58bff01eabe8d82a7413d105b5f1ffb65c9ecce570e631d1",
	"BG_FP1_031": "a04afd0b06459c1f50ad955f3f4523b1e33534c9f59e3620253aa56d9a7ac85d",
	"BG_GIL_681": "7007b342ed3eb86280c8b5589ceffbb2ae610962035a257f79959e3ae70e4032",
	"BG_GIL_681_G": "58dff4ee2ecf525e11e23322fdae470e5eea7c4180d7f92056efa24def57ffdd",
	"BG_GVG_021": "3063455c588c13b65f7e2e43f75a80917f346637ad50b7c5a2d0174ae3be42c1",
	"BG_GVG_027": "03c87dda515fe7b743e08ac1b59c5abed222eab70c2fcbb3c92e68e26e14b923",
	"BG_GVG_048": "918fd54e902473752c4ec83e9e3af6cb99891e79b3d1a94561e5a216f915ea33",
	"BG_GVG_055": "678543e1d5fd97ed326a23eeabd328aa590591a785cd624f9c1e35b5e2e8f74d",
	"BG_GVG_085": "6f46d6ae9dd35cb75658f104259e04eed5e08a02b3a8487cff8b2d891ad07f13",
	"BG_GVG_085_G": "cfc907e90e3dfdf12cd1ceba29d3d2282e7ebdf3e21e3349220ef8e5028b5722",
	"BG_GVG_106": "77d0fbfdc77e43a314b43edd55e0d2c8fb6ae9879490c56d4f75822bd6a58207",
	"BG_GVG_113": "d65ddfd1cc9771afb1a4a65943d4e565da8d53de933c5aa5d84741bc89109174",
	"BG_ICC_026t": "c11ce34e5e421b406947fa87f2eb0bfa16cffa9356e5be23701f91320235416b",
	"BG_ICC_026t_G": "4fa760a749b05a87142c3a8a6665fcbc11906abf96ee445ea260e243f0cee61c",
	"BG_ICC_029": "a40ac74a77a586018d2792ff66319801f86fe0092a6c8710a7dcbe86d9941ca7",
	"BG_ICC_032": "f49c9e10cc7d01409a4cce33141d02a78e4d6528826bc6ac9c73f6a93039f6d3",
	"BG_ICC_038": "9859371b5cff98f73025c33fada49ad3e580d5ce71d2a21f422b462eba63af57",
	"BG_ICC_092": "78bb3b041e5a9f77c7de0268ff2569524317ad28d14b0b13eaf460c22972c78c",
	"BG_ICC_094": "038a4cec88e9fbf8aafb8462aa46f1c0859937ba187d21b28f15d2e7fc2d4fea",
	"BG_ICC_807": "1dd774ff7e54f6d0816da90c0b731b360a7e325edd64557b3e4c928d3dfe5b96",
	"BG_KAR_005": "7cb898f755e993eb4cf35177ca658b74b81e5908b07cb3e67dea262f082e8388",
	"BG_KAR_005a": "8c501e92a5f09f35fd617a5feba6d9ae00d23c788fa8b46e993621dcbab26be6",
	"BG_LOE_012": "d873fe881fc8ecfa47b1fe3ddc2cd639c61347a611f6c696d2f5b061bb2af0ec",
	"BG_LOE_077": "afc066c7bb1da380235b9e5534abebef8049802bd5e743b8928506d37476df63",
	"BG_LOOT_013": "7e38bb74e7c770ed1791dbbf77e319c6eeeb6ef0a7d9cdabea8fea7cec8461bd",
	"BG_LOOT_078": "abf245d0461a9979556c5a50d46d49f8c7b207dd32c89383c64462e3688b23b4",
	"BG_LOOT_368": "26a6cec82752b8d740d43d3a091f4fdafbea013c060bc09a4a6dba3a7a543fc1",
	"BG_NEW1_027": "d8c0f579a6c5d1d526339989c7995632388a0bcbddbbd9a6902e6561465fb6f5",
	"BG_NX2_050": "159c5f08ccc8658d4a28e9edf4451285688f63340dd52eb6485f28143cc08265",
	"BG_NX2_050_G": "f01cd6e1d4dec189fb0c76d3a81f186a87b0aea4a96b82a02c0a1ffe4f62aa58",
	"BG_OG_145": "1f0bbb17ecd969b9b2c50ea33f50560b1ef1c47c0d659371bc7c520d8ea07cfe",
	"BG_OG_145_G": "6415f009827b600451d4245457ac4f86f70fa167df311d46b8744834d73ce6a8",
	"BG_OG_216": "ebc23b5661c540886cd7f80b7baba7d0a143faa0d0cc002756f1385d8cfd1f2f",
	"BG_OG_216a": "78bc70de3839900817d4bfbb7caa8b0dfc1f599df2099727730116a850c35a88",
	"BG_OG_221": "29853bfdf2241ffd71b461d8cd34dba6f005ad7e27d73a4f89ce77dc384723e1",
	"BG_OG_256": "28dbec5b1825a332b7b04d394bdafbb87ac5f0888d44d5253c25ab898f94e4c4",
	"BG_RLK_833t": "0f3eafa80ba6e73b4b5c0dc5586b0184cc59b72f021d85c394ca6873648e2720",
	"BG_RLK_833t_G": "319d72c21d5da52ddd5868894818fcb4ab8102cbd6ccc35e34bd6acfecd940b6",
	"BG_RLK_957": "5e58b0a22f658af3d77517e684202ad52301cac434a5297d18314baba829d6f9",
	"BG_RLK_958": "28863f1ff9161a3207b6e39fbd96c2bb5cb3eab9e20c5b610cbc8648b5e16fa4",
	"BG_ULD_205": "f066a8e903629b2ae4c73a677dd69e27cdaa889f56a21f4b0a7a9a124584f171",
	"BG_ULD_217": "1c32f792bae3ada49efcf0cdc7318ba2d9c3d0e7ff859991b9a6caebb08cd428",
	"BG_ULD_275": "2a631230a0e683aa923da32f23e4c6c5b383e44957ee8c3cb41069ae018b9cfe",
	"BG_UNG_037": "d1f9dd22ca88b856506468e69c1c9ff14b66872864221f9c2785b12799f6334f",
	"BG_UNG_073": "f478fa11d09efdf143878e0c7be6cd2e7b207cc35779696f39399eee83d85766",
	"BG_YOD_026": "c573805dd2f78c2dd6d9b99f6374835569bff20ca6f70ebf0f83824d17b3588b",
	"BG_skele21": "dd6cc119e415ac55cbb65cabb9e01685a580c8ee6ed8d6dd7886a480e642f897",
	"CFM_816": "0d39e126f0a182ffeccd16cb2cf3bbe06aadb0ccc01c3642c2d790da74400f53",
	"EBG_Spell_014": "31bccd06a2cf3c913b9ee5d1d1fab410f771efb19717ebcf4e7c5251cf6c4ccf",
	"TB_BaconShop_HERO_01": "0c4f1a6db98bbad6d3a7fdb064d084501d3c46a49f9b45d8cc1e1436efe7788c",
	"TB_BaconShop_HERO_01_Buddy": "899f26a45fd624c716461018db31f98f6d6036459afcea3855dc804306969532",
	"TB_BaconShop_HERO_01_Buddy_G": "0674ffdb6c8caad5355c0a0ee8889767a96d9b4078fa9544cb7e9981f13a883c",
	"TB_BaconShop_HERO_10": "5e56b436083c9bad850d3e86fdf449b24582bee835e9e4631a518862b5a9efc7",
	"TB_BaconShop_HERO_10_Buddy": "0f7b5f5a726e520a2efc711d6caf43ffc390db4b9f692776f7569452f6103bd9",
	"TB_BaconShop_HERO_10_Buddy_G": "6aa8f0d2d48e347a56287021fd7d1eb856a82b074365c13db228c465397fc859",
	"TB_BaconShop_HERO_11_Buddy": "9a73508d5d09456a4a6934de9542e4d07ca26572d72d484101eba3450e06f245",
	"TB_BaconShop_HERO_11_Buddy_G": "44a04188d0e5b3cfed4d535ca7e521657d352746c65d222b5fd355277094ac95",
	"TB_BaconShop_HERO_15": "4d791124ccfdcda3400910431a98cf67686bde4865aeb19459bccfb19e3b8495",
	"TB_BaconShop_HERO_15_Buddy": "8ff14df735c3440528f8784526f9c8d97f54f138db7e3bdde668fa4a4677a694",
	"TB_BaconShop_HERO_15_Buddy_G": "fb340326b2620dce1658c5a33034af84a90211522d626c993b596b8d942dfe4d",
	"TB_BaconShop_HERO_22": "334806cbd93a7a611132dbf22b9c52fa354cfa330c1aadd9fe80eee2bcba7599",
	"TB_BaconShop_HERO_25": "87dba1698cb88c61f35fc8ad7bcb42048994c628e07077938562800ccdfa5d90",
	"TB_BaconShop_HERO_27": "ba8e990927cd5ba051ade14582635d7af9ae7f30ff630aba8f0012c7a2cb41d1",
	"TB_BaconShop_HERO_31": "5a32f5603e044db862f81a2fd5e1829d9e129e0a109307f96832dfa8fa25773c",
	"TB_BaconShop_HERO_33": "dc3eed5dc97cc33e59f04c9e752b45fb66648174aa0417616e4161af68cf0e5f",
	"TB_BaconShop_HERO_34": "b0a3ff4099c729caa7b4ed296fa98dc56730165cb39b1c9ff82ea7cfe4e715d0",
	"TB_BaconShop_HERO_39": "bbe81a27c6514ad1485b88042ca069fbe7515af7095066cd64fa46117c1dc4dd",
	"TB_BaconShop_HERO_41": "a4efd669148181c80b9622a0d979ddb18f958fb6ea8daa675a96a0807705d6a6",
	"TB_BaconShop_HERO_42": "bb05bf759c554efe6ae91e47f6042b4332bbe116120455ece20a50aa5e50f163",
	"TB_BaconShop_HERO_47": "5629995b4f24c21ab3377ea5cb859fc37a65e7176c77f0bf60d9819e0844f99c",
	"TB_BaconShop_HERO_49": "3a2893e57e4c9af068d3e4a596519249d95a574826a66a90d4439ecda04d04e4",
	"TB_BaconShop_HERO_52": "1b4be0c19ef589c508d2da081f7bef9ee876b60b7ec80605cac165ea52eb8c00",
	"TB_BaconShop_HERO_56": "440cac2023cb49ce50b4dd623ae5240edc6f826986f911baf2b2006b79acc559",
	"TB_BaconShop_HERO_57": "19d7be17ab09f395655e87f3cdd7524f1623eb7865647f42962265f3b14348ac",
	"TB_BaconShop_HERO_59": "6d46edd4856b33e0d593c718cca09b8c96e83e5bb9082c8abfcb01d2bbc350c4",
	"TB_BaconShop_HERO_60": "241edbf4f34ede03711c1340ead8f86b808dc39f7dbb588adfdfe8842876880c",
	"TB_BaconShop_HERO_64_Buddy": "090fc8bb73cb6c45f9ccddd18aefa69420e73eaf42b1792f31b1eff7bc5fef0e",
	"TB_BaconShop_HERO_64_Buddy_G": "e11a154c1e7e1683f8e0ca33b786440f7ca19506856d98d7cbd15dd1bd119a9e",
	"TB_BaconShop_HERO_68": "994d4ef24bc430cc96eb23dab3d2e90749631a22ecd65ba3e3741ff59ede0bf0",
	"TB_BaconShop_HERO_68_Buddy": "d5a8b9a0820368b80ba13cbae9fb589be3ff34fa1c8fe15380962fa5188677f3",
	"TB_BaconShop_HERO_68_Buddy_G": "7686139210a54ac5ccbadbd9219166dbd3946572a8526e86c2d127fba401397a",
	"TB_BaconShop_HERO_74": "b4b1b74a8fa746d5db8d75f2259254300217c8660740e4732bfa4558427b8b77",
	"TB_BaconShop_HERO_75": "e85cc0bc45f8e7ff2075ea728b2436cfa51938ecfa3be57fdf6267c06ab04bef",
	"TB_BaconShop_HERO_76": "2e622f573975238393b4aadc24772bb247b8e94f4ee1b7cc247c9bbfc6105063",
	"TB_BaconShop_HERO_78": "3ed8a0838e69ea88fc4f92f96a93777589e41178b1f7007b8239c2ae4a24591d",
	"TB_BaconShop_HERO_94": "50ac4da9198ec1710a197df45576a9f1784e4a510a00fbc1ae349cc612f58035",
	"TB_BaconShop_HERO_95": "bb01b00dd3b249de9448aeafd8b3b9e6cbcbadf8bc78fbf68e979c7ac2912953",
	"TB_BaconShop_HP_008a": "b6bb1e6f8e37c3fa91d92ca22598af0371ee0b728acfdcc9334526eb6c9b21f2",
	"TB_BaconShop_HP_033t": "a01dcc2c6e1a182c77384aeae5c34b827fe56259af1eeddbee4dd2a2c4841cb6",
	"TB_BaconShop_HP_033t_G": "52c47aefa80c482b0c25cbaeabe1a57adcbead2b7df5c17552ab64731284a6db",
	"TB_BaconShop_HP_033t_SKIN_A": "51d5d476bcafa1d93937aad269a1cc4fb8494642a21048c9399dfe24b7aef765",
	"TB_BaconShop_HP_033t_SKIN_A_G": "61be7ef2274ead9980e608e6ba2a14a79db577fb66fac0e08dcd9ea94b7eb92a",
	"TB_BaconShop_HP_033t_SKIN_B": "2c9740f09057b133bd52ded85ffea513f6708dbeaa3deef0e7f4b836fed8cce3",
	"TB_BaconShop_HP_033t_SKIN_B_G": "33f5d2b96e0004498174aab196314d8a5337de142095c4e0d7a229896886a532",
	"TB_BaconShop_HP_033t_SKIN_D": "4cd4a10bc49b6adf4750ad4603df8ab2fbbac4097f51a8254e4bd87167f16deb",
	"TB_BaconShop_HP_033t_SKIN_D_G": "85ccb0c2d6559e1c1073c58b3f217af0ce0ca6d94595ee2bf2336a031e3844e5",
	"TB_BaconUps_002": "8350cb4ba03faa72cfaca79b10763ae6d847bc87bb5949f9bf8369b5606e53d8",
	"TB_BaconUps_002t": "90e6ecd108194b7c24e11409aefe23185a80f6ddf4ba145334ebcd327b00add5",
	"TB_BaconUps_003": "34c57bf223acc86cdd26a5b2c955141681958604f9d59158f10930164ae75aa1",
	"TB_BaconUps_003t": "c7d333fffab55b1fda62078f7377627dc946feea09770a7d2a6381530717d547",
	"TB_BaconUps_004": "8f859222f4b8729bbb0a222bf4c230fae12237a96a80a5ccde4ee0ded65a1ea6",
	"TB_BaconUps_004t": "7496445730ada5bc6afd340b107aee30991c4f99cc1844a639d6b1afdb556cef",
	"TB_BaconUps_006": "ee0d29091ff1790ec6ee0c37f92e0075fbf680db88bab28ce547a1062b247588",
	"TB_BaconUps_006t": "dbc726ba624ee43ff4cdaf6fef92cb0196a3ca9325fd0d5dcff248554f2993a2",
	"TB_BaconUps_008": "0e42f8def94648ad3196af30b2c042d712e99b17476986a42c7f089792c25981",
	"TB_BaconUps_009": "60156ebe9b3a36f899c01ac8e6a50dcb78b34d6a639ff7864627e18de66130a9",
	"TB_BaconUps_011": "6c1f75e0ea301d2dec0044a67db01d769349b7382d72fa50a6052bbed0a99e97",
	"TB_BaconUps_014": "31278498470f2ccd16b2557200cb2a4740dd7856feb64c22d25c558971a4bfb5",
	"TB_BaconUps_025": "d63501e985ffdc9103f9f99bce6505cbfa5ca4aed1531d279872e7d1e12ae812",
	"TB_BaconUps_026": "2073ea78eece2ec8a23358e5bf0990021c37186735d661e27016824e78ed49ec",
	"TB_BaconUps_026t": "5e657cec6a8aac4f7e692c214ec4af06836f6382279404d3277fcc97fd54a204",
	"TB_BaconUps_027": "30b122622781a52dc4c85a7460397873a5bd181a2387429cee236c3c3d2fea84",
	"TB_BaconUps_027t": "9bf6a5ef7e8d97ba4bd752a89353be2983fb92b6f4e3aaa0b3fc76da0976c80a",
	"TB_BaconUps_028": "7189d0344bcdc6d0bd0eada252d9a5cbd3055c3d527bb64febbecb8c8bb2fd29",
	"TB_BaconUps_030t": "185e367da30418b103ccec5464eee1ec5eb8aba3823b6ddba736e385cedc003e",
	"TB_BaconUps_031": "1aab129b9632af489a6e21c4e586e54f8573271804813f5562a55eb5fce38325",
	"TB_BaconUps_032": "dd9d3787ab33090bf75075301896b57c6ae0c818af5bb3d696f59d7f7fdf5e7a",
	"TB_BaconUps_032t": "3b15642677784982136e89d16c66021bfeb15458c9ae0ecf45ec9481a4f14b80",
	"TB_BaconUps_041t": "3b1ac00e313b83c20e2aa5c66eb5baa09797ed773da21b36249d5ef3d1204271",
	"TB_BaconUps_043": "41c3f57755cf09ca0b764c6eafdae10fea2d2c2225de84f8ea156dcf111f0468",
	"TB_BaconUps_044": "b700122b1b5f7764f0586d0c5d452cbb93905e2c94a522d4ecaf4908f7155b73",
	"TB_BaconUps_045": "26b7df1d6c4ebcc6d9f9f4f6d6416f80df9956bfe50e89f1e39f33e8978b9d10",
	"TB_BaconUps_046": "b268f6b0016941af1430c884c3878d2843f0e1afc350ec445817fc731685d37a",
	"TB_BaconUps_049": "08275660985bb82df88e4ba7a484f27481277aa11a28e085bdea9db182aacf34",
	"TB_BaconUps_049t": "992e296283403618c5e83ff0ac914ed0ed807f50da34d338b3a1771196a1d314",
	"TB_BaconUps_053": "04a8a99f8cdd793b6006beeef87fd2ee612b3bffc65763b7ad8a4a5299c36872",
	"TB_BaconUps_055": "4339ebce2abb8d12b6bba3d4f6ff4cd99a7f98256e6d6c82cfe7509398e5efd5",
	"TB_BaconUps_059": "207cc3d51f3b72fc54d89f347ae277dc0be48a9a2a4c86b1a25b42acb7d5dba1",
	"TB_BaconUps_059t": "3fcd4e6c62a1483211ebe6182fce2bf6bd2e227497148867160e87a82637be85",
	"TB_BaconUps_060": "aed6c64a30a8ba6706b5b9031f0c8769d49a69c65cb8bf889dbeb5ae3a8189de",
	"TB_BaconUps_061": "eec55b21ae9fd64ed1b3fc7e84d44094b3ff6c541674f8f118fc19edc9c0f79e",
	"TB_BaconUps_062": "d4e1c3d5065bac66d3a5f71c682bea66a339fb17fa8c1358c05007f189134ee4",
	"TB_BaconUps_064": "d356ad750b590986107c501e16f20f7e0de2279efc413dcb883d8280cd468731",
	"TB_BaconUps_066": "4c15a7f13c49d7ed1cb2fb74ed0af4cbcd052056860bed82c57f48e171dc6c4a",
	"TB_BaconUps_068": "ab7a9e2e0b7e5c7141fcfb0e11c9f86f0456e3773f795dce0aa7d4a9310ee415",
	"TB_BaconUps_069": "8140851934044869a1970b367f2e0f0426626c9e8ac617b098b5af1216100e3d",
	"TB_BaconUps_070": "b7eca9e2a894641a835890bcf8060732944c6ae6353dc8732d6ecf7a189e3a13",
	"TB_BaconUps_072": "80e7e133c40100c55f6aaca84646b38d2cd021867f8e1bcf548cab146d20b9a0",
	"TB_BaconUps_074": "6eb0652cc9657caa523d62c43ba89f3d6ffd83c782637bcdab0ace4800e4d027",
	"TB_BaconUps_075": "9c0842b38a148f30b68164229310de6e17e584f5b72d4ae3b21677094f5215f9",
	"TB_BaconUps_077": "52e36840b2184cfb38869449aa552651533f3fdc937c9f339c4722edb55e879f",
	"TB_BaconUps_079": "57e62e7f9c19cce452c0be8638d5a0e8ca5fba74b04cb36a4f9feea413b57640",
	"TB_BaconUps_082": "b091c0045c0e08ab98193d255d15001143cb256f9d1169a54a633184de8ca02c",
	"TB_BaconUps_083": "32930ca1da1cb98e42498471e60c3a39841eaea909f7077d783ba4192ec79b87",
	"TB_BaconUps_086": "187ce33d756ecf11c7747eb93735b2aa88c624e7da8e135673f81eb0d251fc6a",
	"TB_BaconUps_087": "9069e4bd77ffb79dbcecb6a646f75c41dd4100b054f46df5cc1302ea572efa4e",
	"TB_BaconUps_089": "51d4482109ad44745fc4850231ff5f65b30c43683305be6dfb827fa1304e8352",
	"TB_BaconUps_090": "6d214f73e3a2621919e2935fd98d2f35d63b873ec103193a4b466408ba2e6e20",
	"TB_BaconUps_091": "8b9fd93004429a85404dd5cfa9d22af910bfd324ed2737dec8715e49b5554d8b",
	"TB_BaconUps_093": "16d2e1cc56aec79cb84938539306b56f9429158c074088bfdee338bf3f598830",
	"TB_BaconUps_093t": "4f9316c918978d55681f5e546c1d83da316ef6fdd3ba0693d726d5add147bd42",
	"TB_BaconUps_094": "9d81cc8a4b29e6f3668e60ddd9de055252b6ff62f872e369d8eaae89f93e6af1",
	"TB_BaconUps_099": "dade03148b4c85d18b18cb5b45976c4738b4e149c6a3b92e6e35816dc8fbcc4a",
	"TB_BaconUps_100": "c773a1f493df5b585d43dec2a1f0a5900847d44ca2ce77558b71d4465326fcbb",
	"TB_BaconUps_102": "f468cdb213fa1a441e325aeae9c464707bc812526e0a4ddd22a2229d07058267",
	"TB_BaconUps_106": "02dca339c3fa9ac8396be7760577e44bda74b25cd2054be8bebfa82f4cb57144",
	"TB_BaconUps_107": "dfd5d9583fa222f22504fd96b2dbbf6b757b07090fe1edc7fb1355fe6e38be15",
	"TB_BaconUps_108": "2939a83fd3d6f5a5fc66eca4f29295e5fe0d2ff2144f22cfd899d5e3e92c1c95",
	"TB_BaconUps_109": "9855a67e40004d391eb4d3917205062cedf51cb889448f78ff32b4383d9c6946",
	"TB_BaconUps_112": "d410146f6a59c0895226c80b43a77ef504d1c8c54c9d79d4a95a0c002ca8ffe0",
	"TB_BaconUps_113": "c512cb38d754b2d7d97e9c6f720cbb33bb8c16a6fc9066fe650c66bf7d5acb58",
	"TB_BaconUps_115": "0dc5a4262cbc381955d9be7674f94155e4b3e813b98e98f499ad10e40c01cc7c",
	"TB_BaconUps_118": "fac7bb7b7ae36a56b6fbd0db7230a14a6e3afc0af69c134667df8b19e75ae760",
	"TB_BaconUps_120": "69b7093a020c542c4097a157b1a0b775c9aa2ae64610389111a3fa52bf33b296",
	"TB_BaconUps_123": "88cb24a3b520371c749247b8464107b252cee19d5ea7d719639ee4debc36bd45",
	"TB_BaconUps_124": "52908c531592d7bb7e8e69ca7ce157dba26a9def07de0c5332a730fc4564fcd7",
	"TB_BaconUps_125": "f0699b851111561651b693656d7722fe63c450b7a567e6e9f6af22de87bbabdf",
	"TB_BaconUps_126": "2d8b291f1af8f62a99d4fab81d649f61fd08cda31beec2342cfcdc91e532a165",
	"TB_BaconUps_127": "0f94fd0dc56bac300d9311b82943df34a8efa305a15286ca8fa9409c6f245701",
	"TB_BaconUps_130": "577440114bb0bcf855448efd727d718b536c476230828600e64650ee3b535c74",
	"TB_BaconUps_133": "0568ae10d1f2b7d3bc86cefab6a945ec8b56d29bcf21c9d5d2669ab60272be6f",
	"TB_BaconUps_134": "3a2bdbe37da4b4513cdcc3a3bc6b55a56cb72e4e360b8e44aa353360fa668143",
	"TB_BaconUps_135": "764454b34a15a0b59621bbef73f4841707716ec0262d76f0299761a447964e47",
	"TB_BaconUps_136": "c904a312c326429f727448daeaffdbd969216c84ac759c2f696b6f6df12abcc7",
	"TB_BaconUps_138": "2fa4f8a72a84afceb38cf970f4bc1466e39e12cc095e7657b19a047dd9e969d3",
	"TB_BaconUps_139": "51d36dea7a2ad8e315917f741ed8b0e70972b46b41bf128e696e9bb1875c3475",
	"TB_BaconUps_140": "e44a355b5a27caa876d40a3958cc6a1d35d55667934fd5aaba6043c2daa9ec8b",
	"TB_BaconUps_141t": "cef349d6b21e55398a27c7b12e1f70eeb4046bffe228d3545c114119d4286b42",
	"TB_BaconUps_144": "1102722019d3a07578b6ebbd5d29fa60492f4d842fa33b542f2f1b09241ed6cd",
	"TB_BaconUps_145": "b44c879d5e9ac1b795b4637399923976768bcd25ebcbaddf73b31d558ebd5198",
	"TB_BaconUps_146": "02fa44d275b4bab157710b97c9a5fcc0c4fe5a2cf406025eed34fcb917cab4d7",
	"TB_BaconUps_147": "9fb312b8fc0d42bae4c8d5ba9fe1e30491b7d77035edb35dee04b3e58f8c3a5a",
	"TB_BaconUps_148": "39525ce25418c8f9444842ed88e0ef4b406796fbe1b00f54e7ef6027a0c0a356",
	"TB_BaconUps_149": "a4995198a326bac9b5d56d2d549a7e90518b349032a18631914d898a29b3ebd0",
	"TB_BaconUps_151": "9412fcf328cbc77feb48ab2916b67d50cbbc23daf3b502e650d2ba947ba961c9",
	"TB_BaconUps_152": "c3d8404a7c87d7f69756d72d87285b366133d39c4ef5e824a426c050d5d36031",
	"TB_BaconUps_153": "128960a1670264083a49ab129ff2bd54d285ccf8a3fb06a8fcba83d54661ae9d",
	"TB_BaconUps_154": "ef982c51977f6e5e2d53a47c9568f5add6db4f910dc900f0cf1009682a9f4a5f",
	"TB_BaconUps_155": "139e1aff1165ad880eda5e73ee25d09e1f0d4f1a57458ca828f5b8f0c35509be",
	"TB_BaconUps_156": "3eee43edc61343a73cbae5c20d280271eca888886a255ad80487d8530ccbff4e",
	"TB_BaconUps_159": "821e1831667e871f162a4e749c98ae8cccfdf39a02ca2d35269fba8265eb300a",
	"TB_BaconUps_160": "720c037ed732147f3b0f6b02652e579074e5fc7b19e86643c9e84241a4937b6a",
	"TB_BaconUps_161": "c88707f131fff544247c8d377cf13e1fa1626cc6cbf795c2040fffd01a91d7e3",
	"TB_BaconUps_162": "005818d6eeb58890504685630adf69daea20c48902501d7ca2e4df306a3c8548",
	"TB_BaconUps_163": "56e98509efa932f731872577ccbea9d66014cd0ce3b93c1875a827d67cd8f6d1",
	"TB_BaconUps_167": "a0e20efa512ec79ebd6aa1928044712b691f726b1fda0aeb7be79d5c5650a3f7",
	"TB_BaconUps_200": "00b888fa5f90db1dda81dcf07114956b1ea0d77511cf969462275cdb61ba0476",
	"TB_BaconUps_201": "f7b4720ab97633ba8c42f8eab5e90c3afddf9ae4c38a75cc52c83711d77e4e93",
	"TB_BaconUps_207": "b9147bfdea485bdac867709a59cb49dd6216ad2409fa958d303f5704f71ea522",
	"TB_BaconUps_250": "2ace57db97c15e93056949d0b8c73b3515a1503b85a2ef138941588f460bbf40",
	"TB_BaconUps_251": "76944e786372fcf5e3f23abc4c70be1a812f4abbce849eb4c2aa3ae0b71ce021",
	"TB_BaconUps_255": "360f8b4e663dd4a69bf4cc263636718e7538b0f4e5cab3ab822a8c4a8e993f37",
	"TB_BaconUps_256": "10f8a45d3b962f7c660a2ff23aac7a82c84b430a9f4749b06e3281d7da78109a",
	"TB_BaconUps_256t": "4f60701ab2534d68043e80b54481fd490fcb3d9a6f1bb2ddc565d965eb80ca35",
	"TB_BaconUps_258": "db127948f3066ebce0348d8f7de525e34e95cba142a331eeab59dc9c8af4da3f",
	"TB_BaconUps_302": "44c8483f861050c1359f302252506edcc1a100b61ca8c6a870cdab8d9d199369",
	"TB_BaconUps_303": "e6cfa35967d8ac0792f5b889a47c0b449a6ace5674fe2598ee37bd23641beea5",
	"TB_BaconUps_304": "e577b17d237fe903f0f5c8a076568975d3b193b0e94bae795f50a36fd901f150",
	"TB_BaconUps_309": "c01a8ec4ec4ebbcd0922d704531eb117a1f93c296b2ee38660b9f1d6b0e44625",
	"TB_BaconUps_309t": "83fdfe8be63221cf958b897908e2bde400bbbc4f7803a15df2e51549760234c0",
	"TB_Baconups_202": "74a5d150b5b1e3e110ede46307a9f3bff2da187d55b97cd359932f738f871c8d",
	"TB_Baconups_203": "3a716fb9d812a4bc0c48d42152ca543d796693e0d3854b808dc5330a46b8e3f9",
	"unverified_335686d22dc39a394d1f": "03da2b6ffb768c7d93d0c14b12bd46134313f53a59a67ce535ab533fa3114a11",
	"unverified_503ed2b06d44c8b9e63f": "cac847da3284b9b52d22e9569a9e12044c5a72d295226d736c42522d9aceb9fe",
	"unverified_9ba2ce238eb99f7455bd": "1d48e7e68cd06d8d6746e1573f39079dac9688c47d610f476357040732165800",
	"unverified_db1c5b1acdc028ce711b": "0ccd284a0c191ac58e4cfdc18c909b4257fbd13aa9078742556fa9de187d93e7",
}
