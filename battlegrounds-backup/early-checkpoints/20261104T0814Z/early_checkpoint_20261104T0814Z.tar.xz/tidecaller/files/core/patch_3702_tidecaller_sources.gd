extends RefCounted
## Newly reconstructed bounded source revision; historical evidence is not acceptance.
const REVISION: String="partial-37.0.2-tidecaller-reconstructed-20261104-v1"
const IDS: Array=["BG36_704","BG36_704_G"]
const IDENTITY_FIELDS: Array=["id","card_code","dbf_id","kind","name","tier","tribes","keywords","is_golden","normal_id","golden_id"]
const OVERLAY: String="data/patch_3702_tidecaller_overlay.json"
const FILE_SHA256: Dictionary={"data/patch_3702_tidecaller_overlay.json":"7faf77570d48c5ce0396163f44904732267d1b063799870a5d797fa79fe1116f","research/patch_3702_tidecaller/source_evidence.json":"98bd6e13302fe3023b4b19002bde3026edacc5b48af32189a45607545d81d96b","research/patch_3702_tidecaller/official_patch_tidecaller_excerpt.html":"175ee2676a4829f394d6b2c22158fda6cfc4ce3ced2299c6fbeb77c45a902007","research/patch_3702_tidecaller/native/BG36_704.xml":"782ce676db0dce7f47ccea03d34d288cbaa5b3f88905f627815398d8ea825a91","research/patch_3702_tidecaller/native/BG36_704_G.xml":"e6320d5aadbe9e9f9cce300ce78078fc2fe96fe1e7e228f38174fc01a66ac52f"}
const RUNTIME_PATHS: Array=["core/patch_3702_tidecaller_sources.gd","data/patch_3702_tidecaller_overlay.json","research/patch_3702_tidecaller/source_evidence.json","research/patch_3702_tidecaller/official_patch_tidecaller_excerpt.html","research/patch_3702_tidecaller/native/BG36_704.xml","research/patch_3702_tidecaller/native/BG36_704_G.xml","core/adjacent_target_listeners.gd","core/dark_gift_qualification.gd","core/damage_listener_room.gd"]
static func accepts_id(id: Variant) -> bool:
	return id is String and id in IDS
static func same(a: Variant,b: Variant) -> bool:
	# JSON numbers are floats while Catalog normalizes integral values to ints.
	# Compare finite integral numbers symmetrically, never accepting booleans.
	if b is int or b is float:
		return (a is int or a is float) and not a is bool and is_finite(float(a)) and is_finite(float(b)) and a==floor(a) and b==floor(b) and a==b
	if typeof(a)!=typeof(b): return false
	if b is Dictionary:
		if a.size()!=b.size(): return false
		for key in b:
			if not a.has(key) or not same(a[key],b[key]): return false
		return true
	if b is Array:
		if a.size()!=b.size(): return false
		for index in range(b.size()):
			if not same(a[index],b[index]): return false
		return true
	return a==b
static func normalize(value: Variant) -> Variant:
	if value is float and is_finite(value) and value==floor(value) and value>=-9007199254740991 and value<=9007199254740991: return int(value)
	if value is Array:
		var items: Array=[]
		for item in value: items.append(normalize(item))
		return items
	if value is Dictionary:
		var fields: Dictionary={}
		for key in value: fields[key]=normalize(value[key])
		return fields
	return value
static func proof_error() -> String:
	for path in FILE_SHA256:
		if not FileAccess.file_exists("res://"+path) or FileAccess.get_sha256("res://"+path)!=FILE_SHA256[path]: return "partial_3702_tidecaller_evidence_changed:"+str(path)
	return ""
static func packet() -> Dictionary:
	if not proof_error().is_empty(): return {}
	var value: Variant=JSON.parse_string(FileAccess.get_file_as_string("res://"+OVERLAY))
	if not value is Dictionary or value.get("revision")!=REVISION or not value.get("cards") is Array or value.cards.size()!=IDS.size(): return {}
	var result: Dictionary={}
	for row in value.cards:
		if not row is Dictionary or not accepts_id(row.get("id")) or result.has(row.id): return {}
		for key in ["expected_baseline","effective_fields"]:
			if not row.get(key) is Dictionary: return {}
		result[row.id]=normalize(row)
	return result
static func apply_overlay(cards: Dictionary) -> String:
	var rows: Dictionary=packet()
	if rows.size()!=IDS.size(): return "partial_3702_tidecaller_missing_or_changed_packet"
	var staged: Dictionary={}
	for id in IDS:
		# Authenticate both complete historical rows before changing either.
		if not cards.has(id) or not same(cards[id],rows[id].expected_baseline): return "partial_3702_tidecaller_changed_baseline:"+id
		var merged: Dictionary=cards[id].duplicate(true)
		merged.merge(rows[id].effective_fields,true)
		if str(merged.text).sha256_text()!=merged.coverage_text_sha256: return "partial_3702_tidecaller_changed_text_digest:"+id
		staged[id]=merged
	for id in IDS: cards[id]=staged[id]
	return ""
static func source_error(card: Dictionary) -> String:
	var id: Variant=card.get("id")
	if not accepts_id(id): return "partial_3702_tidecaller_unknown_source"
	var rows: Dictionary=packet()
	if rows.size()!=IDS.size(): return "partial_3702_tidecaller_missing_or_changed_packet"
	# Bind immutable identity facts without freezing later pool/display policy.
	for key in IDENTITY_FIELDS:
		if not card.has(key) or not same(card[key],rows[id].expected_baseline[key]): return "partial_3702_tidecaller_changed_identity:"+str(id)+":"+str(key)
	for key in rows[id].effective_fields:
		if not card.has(key) or not same(card[key],rows[id].effective_fields[key]): return "partial_3702_tidecaller_changed_effective_source:"+str(id)+":"+str(key)
	return ""
