"""Reconstructed Python-only fictional fixture tests; no native evidence credit."""
from copy import deepcopy as cp
import hashlib,json,unittest,sys
from pathlib import Path
sys.dont_write_bytecode=True
import postvalidate_ashen as v
FP='f'*64

def unit(uid,identity,golden=False):
    stats={v.ASHEN:(4,8),v.GOLD:(8,16),v.WEAVER:(1,4),v.DOOM:(2,1),v.CYCLE:(2,1),v.FORT:(0,1)};a,h=stats[identity]
    effects={v.DOOM:v.DOOM_EFFECT,v.WEAVER:v.WEAVER_EFFECT,v.CYCLE:[],v.FORT:v.FORT_EFFECT}.get(identity,[{'type':'after_recruit_hero_damage','source_id':identity,'event':'hero_damaged','scope':'shop','tribe':'','rewind':True,'temporary':True,'attack':2 if golden else 1,'health':4 if golden else 2}])
    return {'uid':uid,'card_id':identity,'kind':'spell' if identity==v.FORT else 'minion','tier':4 if identity in (v.ASHEN,v.GOLD) else 1,'attack':a,'health':h,'max_health':h,'effects':cp(effects),'tribes':['恶魔','纳迦'] if identity==v.DOOM else [],'keywords':['divine_shield','windfury'] if identity==v.CYCLE else [],'permanent_keywords':['divine_shield','windfury'] if identity==v.CYCLE else [],'temporary_buffs':[],'golden':golden,'pool_id':v.ASHEN if golden else identity,'pool_count':3 if golden else 1,'pool_kind':'spell' if identity==v.FORT else 'minion','cost':1 if identity==v.FORT else 0,'recruit_shop_aura_attack':0,'recruit_shop_aura_health':0,'spell_triggers':0,'blood_gems_received_turn':0,'spellcraft_kept':0}

def fake_case(case,golden):
    p={'id':0,'hero_id':v.HERO,'armor':0,'health':60,'gold':10,'tier':4,'ready':False,'frozen':False,'free_rolls':0,'discover':[],'hand':[unit('u1',v.GOLD if golden else v.ASHEN,golden),unit('u2',v.WEAVER),unit('u3',v.DOOM),unit('u4',v.DOOM)],'board':[],'shop':[unit('u5',v.DOOM),unit('u6',v.CYCLE),unit('u7',v.WEAVER),unit('u8',v.ASHEN),unit('u9',v.CYCLE),unit('u10',v.FORT)]}
    other={'id':1,'hero_id':v.HERO,'armor':0,'health':60,'gold':10,'tier':1,'ready':False,'frozen':False,'free_rolls':0,'discover':[],'hand':[],'board':[],'shop':[]}
    room={'enabled_minions':[v.ASHEN,v.WEAVER,v.DOOM,v.CYCLE],'enabled_spells':[v.FORT],'enabled_heroes':[v.HERO],'selected_hero':v.HERO,'damage_received_listeners':False,'shop_overrides':{},**{k:[] for k in ['enabled_anomalies','enabled_trinkets','enabled_quests','enabled_rewards','enabled_prizes']}}
    s={'schema_version':2,'rules_version':'sandbox-1','execution_fingerprint':FP,'room':room,'state':{'players':[p,other],'round':9,'phase':'recruit','command_sequence':1},'pool':{x:100 for x in [v.ASHEN,v.WEAVER,v.DOOM,v.CYCLE]},'spell_pool':{v.FORT:100},'rng_seed':'101','rng_state':'202','next_uid':11,'events':[],'command_log':[{'sequence':1,'round':9,'player':0,'command':{'type':'buy','index':0},'origin':'human'}],'last_combats':[]}
    for u in p['hand']+p['shop']:(s['spell_pool'] if u['pool_kind']=='spell' else s['pool'])[u['pool_id']]-=u['pool_count']
    setup=cp(s);roles=list(v.ROLES)
    if golden:roles[1:1]=['reward','pouch']
    rows=[];tape=[];doom_ids=[];board_uid='';hand_uid='';frozen_uid=''
    def new_uid():
        x='u'+str(s['next_uid']);s['next_uid']+=1;return x
    def event(kind,**kw):s['events'].append({'type':kind,'round':s['state']['round'],**kw})
    def idx(z,identity=None,uid=None):return next(i for i,u in enumerate(p[z]) if (u['card_id']==identity if identity else u['uid']==uid))
    def append(cmd,label,before,player=0):
        s['state']['command_sequence']+=1;s['command_log'].append({'sequence':s['state']['command_sequence'],'round':s['state']['round'],'player':player,'command':cp(cmd),'origin':'human'});event('command',player=player,action=cmd['type'])
        rows.append({'scenario':case,'label':label,'player':player,'command':cp(cmd),'result':{'ok':True},'before_round':before['state']['round'],'after_round':s['state']['round'],'phase':'recruit','expected_ok':True,'replay':False,'before_snapshot':before,'after_snapshot':cp(s)})
    def roll(bonus):
        for u in p['shop']:(s['spell_pool'] if u['pool_kind']=='spell' else s['pool'])[u['pool_id']]+=u['pool_count']
        p['shop']=[];a,h=bonus
        for identity in [v.WEAVER,v.CYCLE,v.DOOM,v.ASHEN,v.CYCLE,v.FORT]:
            u=unit(new_uid(),identity);(s['spell_pool'] if identity==v.FORT else s['pool'])[identity]-=1
            if identity!=v.FORT and a:
                for k,d in [('attack',a),('health',h),('max_health',h)]:u[k]+=d
                u['temporary_buffs'].append({'attack':a,'health':h,'keywords':[],v.MARK:s['state']['round']});event('ashen_shop_future_offer_buff',player=0,target_uid=u['uid'],attack=a,health=h)
            p['shop'].append(u)
        p['gold']-=1;s['rng_state']=str(int(s['rng_state'])+1)
    for role in roles:
        before=cp(s)
        if role in ['source','weaver','cycle','doom1','doom2','doom3']:
            identity={'source':v.GOLD if golden else v.ASHEN,'weaver':v.WEAVER,'cycle':v.CYCLE}.get(role,v.DOOM);i=idx('hand',identity);cmd={'type':'play','index':i,'position':len(p['board'])};u=p['hand'].pop(i);p['board'].append(u)
            if role=='source' and golden:p['hand'].append({'uid':new_uid(),'card_id':'__triple_reward','effects':[{'type':'spell_discover','tier':5}],'kind':'spell'})
            if role.startswith('doom'):
                doom_ids.append(u['uid']);n=int(role[-1]);a,h=(2,4) if golden else (1,2);eid='packet'+str(n);event('bulk_hero_damage_observed',player=0,event_id=eid,damage=1,health_lost=1,armor_before=0,armor_lost=0,health_before=p['health']);event('bulk_hero_damage_rewind',player=0,event_id=eid,source_uid='u1',source_id=v.GOLD if golden else v.ASHEN,health=p['health'],armor=0)
                for target in p['shop']:
                    if target['kind']=='spell':continue
                    for k,d in [('attack',a),('health',h),('max_health',h)]:target[k]+=d
                    target['temporary_buffs'].append({'attack':a,'health':h,'keywords':[],v.MARK:9});event('bulk_hero_damage_buff',player=0,event_id=eid,source_uid='u1',source_id=v.GOLD if golden else v.ASHEN,target_uid=target['uid'],attack=a,health=h,temporary=True)
                p[v.LEDGER]={'round':9,'attack':n*a,'health':n*h};w=next(x for x in p['board'] if x['card_id']==v.WEAVER)
                for k in ['attack','health','max_health']:w[k]+=2
                ds=p.setdefault(v.DISCOUNT,{'version':1,'issued':0,'entries':{}});ds['issued']=n;ds['entries'][str(n)]={'source_id':v.DOOM,'source_uid':u['uid'],'granted_round':9,'amount':1,'purchases':1,'remaining':1};event('next_spell_discount_granted',player=0,source_uid=u['uid'],source_id=v.DOOM,amount=1,purchases=1)
        elif role in ('reward','pouch'):
            i=idx('hand','__triple_reward' if role=='reward' else '__triple_gold_pouch');cmd={'type':'play','index':i};p['hand'].pop(i)
            if role=='reward':p['hand'].append({'uid':new_uid(),'card_id':'__triple_gold_pouch','effects':[{'type':'spell_gold','amount':3}],'kind':'spell'});event('triple_empty_pouch',player=0)
            else:p['gold']+=3
        elif role.startswith('buy_'):
            identity={'buy_doom':v.DOOM,'buy_cycle':v.CYCLE,'buy_fortify':v.FORT}.get(role);i=idx('shop',identity) if identity else next(i for i,u in enumerate(p['shop']) if u['kind']=='minion');cmd={'type':'buy','index':i};u=p['shop'].pop(i);p['hand'].append(u)
            if role=='buy_fortify':u['pool_count']=0;s['spell_pool'][v.FORT]+=1;p[v.DISCOUNT]['entries']={}
            else:p['gold']-=3
            if role=='buy_cycle':board_uid=u['uid']
            if role=='buy_hand':hand_uid=u['uid']
        elif role.startswith('sell_'):
            uid='u1' if role=='sell_source' else doom_ids[int(role[-1])-1];i=idx('board',uid=uid);cmd={'type':'sell','index':i};u=p['board'].pop(i);p['gold']+=1;s['pool'][u['pool_id']]+=u['pool_count']
        elif role=='fortify':
            i=idx('hand',v.FORT);j=idx('board',uid=board_uid);cmd={'type':'play','index':i,'target':j,'target_zone':'board'};p['hand'].pop(i);u=p['board'][j];u['health']+=3;u['max_health']+=3;u['keywords'].append('taunt');u['permanent_keywords'].append('taunt')
        elif role.startswith('roll_'):cmd={'type':'roll'};roll((6,12) if golden else (3,6))
        else:cmd={'type':'freeze'};p['frozen']=True;frozen_uid=p['shop'][0]['uid']
        append(cmd,role,before);tape.append({'player':0,'command':cp(cmd),'label':role,'expected_ok':True})
    active=cp(s);original=cp(rows);replay=[]
    for r in original:r['replay']=True;r['label']='replay: '+r['label'];replay.append(r)
    for player in (1,0):
        before=cp(s)
        if player==1:s['state']['players'][1]['ready']=True
        else:
            s['state']['round']+=1;s['last_combats']=[{'winner':0,'synthetic_fixture':True}]
            for z in ('hand','board','shop'):
                for u in p[z]:
                    if u.get('kind','minion')!='minion':continue
                    for b in u['temporary_buffs']:
                        for k,d in [('attack',b['attack']),('health',b['health']),('max_health',b['health'])]:u[k]-=d
                    u['temporary_buffs']=[]
            p['frozen']=False;p['gold']=10;s['state']['players'][1]['ready']=False
        append({'type':'end_turn'},'expiry'+str(player),before,player)
    last=cp(s);before=cp(s);roll((0,0));append({'type':'roll'},'fresh_next_turn',before);expired=cp(s);final_rows=rows[:len(roles)]+replay+rows[len(roles):];events=active['events'][len(setup['events']):]
    evidence={'case':case,'round':9,'source_uid':'u1','golden':golden,'damage_packets':3,'discount_grants':3,'current_vector':[6,12] if golden else [3,6],'future_rolls':2,'packet_receipts':[e for e in events if e['type']=='bulk_hero_damage_observed'],'discount_receipts':[e for e in events if e['type']=='next_spell_discount_granted'],'recipients':{'hand':hand_uid,'board':board_uid,'shop':frozen_uid},'native_save_stages':list(v.STAGES),'replay_commands':len(roles),'last_recruit_snapshot':last}
    docs={'setup':setup,'active':active,'active_replay':cp(active),'expired':expired};meta={stage:{'path':'/fictional-unit-fixture/'+case+'_'+stage+'.json','sha256':hashlib.sha256(json.dumps(d,sort_keys=True).encode()).hexdigest(),'bytes':len(json.dumps(d,sort_keys=True).encode())} for stage,d in docs.items()};rp={'scenario':case,'setup':meta['setup']['path'],'active':meta['active']['path'],'replayed':meta['active_replay']['path'],'commands':tape,'fields':list(v.FIELDS),'byte_identical':True};return final_rows,evidence,docs,meta,rp

def fixture():
    report={'observation_schema_version':2,'status':'passed_narrow_rebuild_v2_only','failures':0,'failure_snapshots':[],'completed_cases':list(v.CASES),'required_cases':list(v.CASES),'execution_fingerprint':FP,'checks':[],'commands':[],'loads':[],'combats':[],'case_evidence':[],'replays':[],'held':['mixed received-damage rooms','full identity and whole patch acceptance']};ctx={'execution_fingerprint':FP,'source_manifest_sha256':'e'*64,'save_fields':list(v.FIELDS),'native_save_documents':{},'native_save_metadata':{}}
    for i,case in enumerate(v.CASES):
        rows,e,docs,meta,rp=fake_case(case,bool(i));report['commands']+=rows;report['case_evidence'].append(e);report['replays'].append(rp);ctx['native_save_documents'][case]=docs;ctx['native_save_metadata'][case]=meta
        for stage in v.STAGES:
            report['loads'].append({'scenario':case,'label':stage,**meta[stage],'native_original':True,'fields':list(v.FIELDS)})
            for label in ('native save','saving does not mutate engine','fresh native load')+tuple('native roundtrip '+f for f in v.FIELDS):report['checks'].append({'scenario':case,'label':stage+': '+label,'passed':True})
    report['counts']={k:len(report[k]) for k in ('checks','commands','loads','combats')};report['counts']['cases']=2;return report,{'expected_status':'passed_narrow_rebuild_v2_only'},ctx

class RescueTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.original=fixture()
    def setUp(self):self.r,self.c,self.x=cp(self.original)
    def bad(self):
        with self.assertRaises(v.ValidationError):v.validate(self.r,self.c,self.x)
    def test_01_positive_fictional_fixture(self):self.assertEqual([x['active_commands'] for x in v.validate(self.r,self.c,self.x)['cases']],[18,20])
    def test_02_no_input_mutation(self):old=cp((self.r,self.c,self.x));v.validate(self.r,self.c,self.x);self.assertEqual((self.r,self.c,self.x),old)
    def test_03_v1_rejected(self):self.r.pop('observation_schema_version');self.bad()
    def test_04_missing_snapshot(self):self.r['commands'][0].pop('before_snapshot');self.bad()
    def test_05_missing_native_fields(self):self.x['native_save_documents'][v.CASES[0]]['setup'].pop('rng_state');self.bad()
    def test_06_wrong_active_tape(self):self.r['replays'][0]['commands'][2]['command']['type']='roll';self.bad()
    def test_07_duplicate_replay(self):self.r['commands'][18]['replay']=False;self.bad()
    def test_08_wrong_actual_gold(self):self.r['commands'][6]['after_snapshot']['state']['players'][0]['gold']+=1;self.bad()
    def test_09_wrong_uid_transfer(self):self.r['commands'][9]['after_snapshot']['state']['players'][0]['hand'][-1]['uid']='u999';self.bad()
    def test_10_extra_zone_mutation(self):self.r['commands'][15]['after_snapshot']['state']['players'][0]['hand'][0]['attack']+=1;self.bad()
    def test_11_sale_erases_ledger(self):self.r['commands'][15]['after_snapshot']['state']['players'][0].pop(v.LEDGER);self.bad()
    def test_12_wrong_grant_vector(self):self.r['commands'][2]['after_snapshot']['state']['players'][0]['shop'][0]['attack']+=1;self.bad()
    def test_13_wrong_packet_armor(self):self.r['case_evidence'][0]['packet_receipts'][0]['armor_before']=1;self.bad()
    def test_14_wrong_discount_source(self):self.r['case_evidence'][0]['discount_receipts'][0]['source_uid']='u999';self.bad()
    def test_15_frozen_snapshot_missing(self):self.r['case_evidence'][0].pop('last_recruit_snapshot');self.bad()
    def test_16_frozen_expiry_tamper(self):self.r['case_evidence'][0]['last_recruit_snapshot']['state']['players'][0]['shop'][0]['attack']+=1;self.bad()
    def test_17_lost_permanent_taunt(self):self.r['case_evidence'][0]['last_recruit_snapshot']['state']['players'][0]['board'][-1]['permanent_keywords'].remove('taunt');self.bad()
    def test_18_load_wrong_hash(self):self.r['loads'][0]['sha256']='0'*64;self.bad()
    def test_19_load_false_native(self):self.r['loads'][0]['native_original']=False;self.bad()
    def test_20_counts_inconsistent(self):self.r['counts']['commands']+=1;self.bad()
    def test_21_labels_not_enough(self):self.r['commands']=[];self.r['counts']['commands']=0;self.bad()
    def test_22_missing_source_fixture(self):self.x['native_save_documents'][v.CASES[0]]['setup']['state']['players'][0]['hand'][0].pop('effects');self.bad()
    def test_23_capability_expansion(self):self.x['native_save_documents'][v.CASES[0]]['setup']['room']['damage_received_listeners']=True;self.bad()
    def test_24_fingerprint_mismatch(self):self.x['execution_fingerprint']='0'*64;self.bad()
    def test_25_bool_not_integer(self):self.r['counts']['cases']=True;self.bad()
    def test_26_missing_context(self):self.x.pop('source_manifest_sha256');self.bad()
    def test_27_native_replay_difference(self):self.x['native_save_documents'][v.CASES[0]]['active_replay']['rng_state']='404';self.bad()
    def test_28_old_source_rejected(self):self.x['native_save_documents'][v.CASES[0]]['setup']['state']['players'][0]['hand'][0]['effects'][0]['attack']=2;self.bad()
    def test_29_missing_field_receipt(self):self.r['checks'].pop();self.r['counts']['checks']-=1;self.bad()
    def test_30_measured_harness_contract_recovery(self):
        h=Path(__file__).resolve().parent
        for result in ['HARNESS_RECONSTRUCTION_RESULTS.json','CONTRACT_RECONSTRUCTION_RESULTS.json']:
            data=json.loads((h/result).read_text());data=data.get('files',data)
            for name,row in data.items():self.assertEqual(hashlib.sha256((h/name).read_bytes()).hexdigest(),row['reference_sha256'])
    def direct(self,index,role,change):
        row=cp(self.r['commands'][index]);change(row);source,bases=v.fixture_facts(self.x['native_save_documents'][v.CASES[0]]['setup'],False)
        with self.assertRaises(v.ValidationError):v.active_step(row,role,FP,source,bases,(1,2),None)
    def test_31_direct_wrong_payment(self):self.direct(6,'buy_doom',lambda r:r['after_snapshot']['state']['players'][0].__setitem__('gold',999))
    def test_32_direct_source_sale(self):self.direct(15,'sell_source',lambda r:r['after_snapshot']['state']['players'][0].pop(v.LEDGER))
    def test_33_direct_hand_mutation(self):self.direct(15,'sell_source',lambda r:r['after_snapshot']['state']['players'][0]['hand'][0].__setitem__('attack',999))
    def test_34_direct_double_grant(self):self.direct(16,'roll_after',lambda r:r['after_snapshot']['state']['players'][0]['shop'][0]['temporary_buffs'].append(cp(r['after_snapshot']['state']['players'][0]['shop'][0]['temporary_buffs'][0])))
    def test_35_direct_wrong_source(self):
        def change(r):next(e for e in r['after_snapshot']['events'] if e['type']=='bulk_hero_damage_rewind')['source_id']=v.GOLD
        self.direct(2,'doom1',change)
    def test_36_direct_lost_permanent_taunt(self):self.direct(13,'fortify',lambda r:r['after_snapshot']['state']['players'][0]['board'][-1]['permanent_keywords'].remove('taunt'))
    def test_37_observer_only_identity(self):
        h=Path(__file__).resolve().parent;s=(h/'ashen_lifecycle_public_v2.gd').read_text();old=(h/'ashen_lifecycle_public.gd').read_text();self.assertEqual(s.count('game.apply_command('),old.count('game.apply_command('));self.assertEqual(s.count('game.save_to(path)'),old.count('game.save_to(path)'));self.assertIn('receipt.before_snapshot = before',s);self.assertIn('receipt.after_snapshot = snapshot()',s);self.assertIn('var last_recruit_snapshot: Dictionary = snapshot()',s)
if __name__=='__main__':unittest.main(verbosity=2)
