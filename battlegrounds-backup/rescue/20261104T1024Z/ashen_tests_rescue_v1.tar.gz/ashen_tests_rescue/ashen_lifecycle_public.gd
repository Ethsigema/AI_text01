extends SceneTree
## NEW reconstruction, not recovered original bytes. Preparation only until reviewed seal.
## No synthetic game mutation: all acquisition, gold, damage, buffs and turns are public commands.
const OUTPUT = "user://ashen_lifecycle_public_report.json"
const ASHEN = "BG32_873"
const GOLDEN = "BG32_873_G"
const WEAVER = "BGS_004"
const DOOM = "BG31_330"
const CYCLONE = "BGS_119"
const PATCHWERK = "TB_BaconShop_HERO_34"
const FORTIFY = "BG28_503"
const LEDGER = "ashen_turn_shop_bonus"
const MARK = "ashen_turn_shop_round"
const DISCOUNT = "next_spell_discount_state"
const CASES = ["normal_ashen_lifecycle", "golden_ashen_lifecycle"]
const FIELDS = ["schema_version", "rules_version", "execution_fingerprint", "room", "state", "pool", "spell_pool", "rng_seed", "rng_state", "next_uid", "events", "command_log", "last_combats"]
const UPGRADE_PRICES = [0,5,7,8,11,11,0]
var game_script: GDScript
var room_script: GDScript
var catalog: RefCounted
var game: RefCounted
var stock_baseline: Dictionary = {}
var scenario: String = "source_contracts"
var failures: int = 0
var acquiring: bool = true
var recording: bool = false
var replaying: bool = false
var tape: Array = []
var report: Dictionary = {"schema_version":1,"status":"not_run","execution_fingerprint":"","checks":[],"commands":[],"loads":[],"replays":[],"combats":[],"failure_snapshots":[],"completed_cases":[],"required_cases":CASES,"case_evidence":[],"scope":"NEW isolated 37.0.2 Ashen ordinary and genuinely tripled golden, armor-zero recruit packets only","held":["final source and harness binding unresolved before review","historical acceptance is not carried","mixed received-damage rooms","armor absorption and mixed armor health packets","arbitrary damage sources","lethal rewind","temporary-buffed triples","full identity and whole patch acceptance","GUI","exhaustive RNG","synthetic guards have no gameplay credit"]}

func check(ok: bool, label: String, detail: Variant = null) -> bool:
	report.checks.append({"scenario":scenario,"label":label,"passed":ok,"detail":detail})
	print("BASIC_CHECK ", scenario, " | ", label, " | ", ok)
	if not ok:
		failures += 1
		if game != null and not game.state.is_empty(): report.failure_snapshots.append({"scenario":scenario,"label":label,"snapshot":snapshot()})
		persist()
	return ok

func persist() -> void:
	var file: FileAccess = FileAccess.open(OUTPUT,FileAccess.WRITE)
	if file != null: file.store_string(JSON.stringify(report,"  "))

func owner(player: int = 0) -> Dictionary:
	return game.state.players[player]

func snapshot() -> Dictionary:
	return {"schema_version":game_script.SAVE_VERSION,"rules_version":game_script.RULES_VERSION,"execution_fingerprint":game.catalog.execution_fingerprint,"room":game.room.duplicate(true),"state":game.state.duplicate(true),"pool":game.pool.duplicate(true),"spell_pool":game.spell_pool.duplicate(true),"rng_seed":str(game.rng.seed),"rng_state":str(game.rng.state),"next_uid":game.next_uid,"events":game.events.duplicate(true),"command_log":game.command_log.duplicate(true),"last_combats":game.last_combats.duplicate(true)}

func index_uid(zone: String, uid: String, player: int = 0) -> int:
	for i in range(owner(player)[zone].size()):
		if owner(player)[zone][i].get("uid") == uid: return i
	return -1

func index_card(zone: String, identity: String, player: int = 0) -> int:
	for i in range(owner(player)[zone].size()):
		if owner(player)[zone][i].get("card_id") == identity: return i
	return -1

func unit(zone: String, uid: String, player: int = 0) -> Dictionary:
	var i: int = index_uid(zone,uid,player)
	return {} if i < 0 else owner(player)[zone][i]

func command(cmd: Dictionary, label: String, player: int = 0, expect_ok: bool = true) -> bool:
	if recording: tape.append({"player":player,"command":cmd.duplicate(true),"label":label,"expected_ok":expect_ok})
	var before: Dictionary = snapshot()
	var result: Dictionary = game.apply_command(player,cmd)
	report.commands.append({"scenario":scenario,"label":label,"player":player,"command":cmd.duplicate(true),"result":result.duplicate(true),"before_round":before.state.round,"after_round":game.state.round,"phase":game.state.phase,"expected_ok":expect_ok,"replay":replaying})
	if not check(result.get("ok",false) == expect_ok,label + ": expected command result",result): return false
	if not expect_ok:
		if not check(not str(result.get("error","")).is_empty(),label + ": explicit error returned"): return false
		return check(snapshot() == before,label + ": rejected command leaves every persisted field unchanged")
	if not check(game.state.phase != "error",label + ": no engine error phase"): return false
	if not check(game.state.command_sequence == before.state.command_sequence + 1 and game.command_log.size() == before.command_log.size() + 1,label + ": one real command receipt; no bot actions"): return false
	return check(stock_totals() == stock_baseline,label + ": complete native stock conservation")

func buy_minion(identity: String, player: int = 0, uid: String = "") -> String:
	var index: int = index_card("shop",identity,player) if uid.is_empty() else index_uid("shop",uid,player)
	if not check(index >= 0,"real minion offer exists " + identity): return ""
	var offered: Dictionary = owner(player).shop[index].duplicate(true)
	var before_gold: int = owner(player).gold
	var before_pool: Dictionary = game.pool.duplicate(true)
	var before_hand: int = owner(player).hand.size()
	if not check(offered.get("pool_id") == identity and offered.get("pool_count") == 1,"offered minion has native stock entitlement"): return ""
	if not command({"type":"buy","index":index},"buy minion " + identity,player): return ""
	var acquired: Dictionary = unit("hand",offered.uid,player)
	if not check(owner(player).gold == before_gold-3 and owner(player).hand.size() == before_hand+1 and not acquired.is_empty() and index_uid("shop",offered.uid,player) == -1,"buy pays three and moves original UID once"): return ""
	if not check(game.pool == before_pool and acquired.get("pool_count") == 1,"buy does not debit reserved minion stock twice"): return ""
	return offered.uid

func play_minion(uid: String, player: int = 0) -> bool:
	var index: int = index_uid("hand",uid,player)
	if not check(index >= 0,"real acquired minion in hand"): return false
	var before: Dictionary = unit("hand",uid,player).duplicate(true)
	var gold: int = owner(player).gold
	var board_size: int = owner(player).board.size()
	if not command({"type":"play","index":index,"position":board_size},"play acquired minion",player): return false
	var after: Dictionary = unit("board",uid,player)
	if not check(not after.is_empty() and index_uid("hand",uid,player) == -1 and owner(player).board.size() == board_size+1 and owner(player).gold == gold,"play moves original UID once without payment"): return false
	for field in ["card_id","attack","health","max_health","keywords","temporary_buffs","permanent_keywords","pool_id","pool_count"]:
		if not check(after.get(field) == before.get(field),"played minion preserves acquired " + field): return false
	return true

func stock_totals() -> Dictionary:
	var totals: Dictionary = {}
	for identity in game.pool: totals["minion:"+str(identity)] = game.pool[identity]
	for identity in game.spell_pool: totals["spell:"+str(identity)] = game.spell_pool[identity]
	for player in game.state.players:
		for body in player.board + player.hand + player.shop:
			var count: int = int(body.get("pool_count",0))
			if count == 0: continue
			var kind: String = "spell" if body.get("pool_kind","") == "spell" else "minion"
			var key: String = kind+":"+str(body.get("pool_id",""))
			totals[key] = int(totals.get(key,0)) + count
	return totals

func zone_by_uid(zone: String, player: int = 0) -> Dictionary:
	var output: Dictionary = {}
	for body in owner(player)[zone]: output[body.uid] = body.duplicate(true)
	return output

func matching_events(entries: Array, name: String, field: String = "", value: Variant = null, name_field: String = "event") -> Array:
	var found: Array = []
	for entry in entries:
		if entry.get(name_field,"") == name and (field.is_empty() or entry.get(field) == value): found.append(entry)
	return found

func refresh_player(player: int) -> bool:
	var before = owner(player).duplicate(true)
	var cost = 0 if before.free_rolls > 0 else 1
	if not command({"type":"roll"},"real paid bounded acquisition roll",player): return false
	return check(owner(player).gold == before.gold-cost and owner(player).board == before.board and owner(player).hand == before.hand,"refresh pays native price and leaves owned cards alone")

func acquire(identity: String, player: int = 0) -> String:
	for _step in range(60):
		if index_card("shop",identity,player)>=0 and owner(player).gold>=3: return buy_minion(identity,player)
		if owner(player).gold>=4:
			if not refresh_player(player): return ""
		elif not advance(): return ""
	check(false,"bounded real purchase unavailable; no synthetic offer",identity)
	return ""

func advance() -> bool:
	var round_before: int = game.state.round
	var hp_before: Array = [owner().health,owner(1).health,owner().armor,owner(1).armor]
	if acquiring and not check(owner().board.is_empty() and owner(1).board.is_empty(),"acquisition combat starts with both actual boards empty"): return false
	if not owner(1).ready:
		if not command({"type":"end_turn"},"ready real opponent",1): return false
	if not command({"type":"end_turn"},"resolve actual end_turn"): return false
	if not check(game.state.round==round_before+1 and game.state.phase=="recruit" and owner().alive and owner(1).alive and not owner().ready,"actual combat returns to next active recruit"): return false
	if not check(game.last_combats.size()==1 and game.last_combats[0].get("error","")=="","one successful full Game combat"): return false
	if acquiring:
		var c: Dictionary=game.last_combats[0]
		if not check(c.winner==-1 and c.left.is_empty() and c.right.is_empty() and hp_before==[owner().health,owner(1).health,owner().armor,owner(1).armor],"acquisition ties preserve both hero resources without resetting anything"): return false
		if not check(c.log.filter(func(e): return e.get("event") in ["attack","damage","death","hand_buff"]).is_empty(),"no unrelated acquisition combat hazard"): return false
	report.combats.append({"scenario":scenario,"round":round_before,"acquisition":acquiring,"replay":replaying,"result":game.last_combats[0].duplicate(true)})
	return true

func buy_true_triple_player(identity: String,golden_id: String,player: int) -> String:
	var originals: Array=[]
	for _i in range(2):
		var uid: String=acquire(identity,player)
		if uid.is_empty(): return ""
		originals.append(uid)
	for _step in range(60):
		if index_card("shop",identity,player)>=0 and owner(player).gold>=3: break
		if owner(player).gold>=4:
			if not refresh_player(player): return ""
		elif not advance(): return ""
	var i: int=index_card("shop",identity,player)
	if not check(i>=0 and owner(player).gold>=3,"real affordable third normal offer for owner "+str(player)): return ""
	var offered: Dictionary=owner(player).shop[i].duplicate(true)
	var before: Dictionary=snapshot()
	if not command({"type":"buy","index":i},"actual third paid normal purchase",player): return ""
	var gi: int=index_card("hand",golden_id,player)
	if not check(gi>=0 and owner(player).gold==before.state.players[player].gold-3 and game.pool==before.pool,"real owner-specific triple payment and reserved stock"): return ""
	var golden: Dictionary=owner(player).hand[gi]
	if not check(golden.golden and golden.pool_id==identity and golden.pool_count==3,"native golden has three-copy stock entitlement"): return ""
	for uid in originals+[offered.uid]:
		if not check(index_uid("hand",uid,player)<0 and index_uid("board",uid,player)<0 and index_uid("shop",uid,player)<0,"each genuine ordinary UID consumed once for exact owner"): return ""
	var triples: Array=[]
	for event in game.events.slice(before.events.size()):
		if event.get("type")=="triple": triples.append(event)
	if not check(triples.size()==1 and triples[0].player==player and triples[0].card_id==golden_id,"one new triple receipt attributed to actual owner"): return ""
	if not check(owner(1-player).hand==before.state.players[1-player].hand and owner(1-player).board==before.state.players[1-player].board,"tripling one owner never consumes the other owner's cards"): return ""
	return golden.uid

func cast_fortify_player(spell_uid: String,target_uid: String,player: int) -> bool:
	var i: int=index_uid("hand",spell_uid,player)
	var target: int=index_uid("board",target_uid,player)
	if not check(i>=0 and target>=0 and unit("hand",spell_uid,player).card_id==FORTIFY,"Fortify binds genuine acquired source and owner target UIDs"): return false
	var before: Dictionary=snapshot()
	var old_body: Dictionary=unit("board",target_uid,player).duplicate(true)
	if not command({"type":"play","index":i,"target":target,"target_zone":"board"},"cast purchased Fortify on actual owner board",player): return false
	if not check(index_uid("hand",spell_uid,player)<0 and owner(player).hand.size()==before.state.players[player].hand.size()-1 and owner(player).gold==before.state.players[player].gold and owner(player).stats.spells==before.state.players[player].stats.spells+1 and game.spell_pool==before.spell_pool,"one actual cast consumes source without extra cost or stock return"): return false
	var expected_body: Dictionary=old_body.duplicate(true)
	expected_body.health+=3
	expected_body.max_health+=3
	if "taunt" not in expected_body.keywords: expected_body.keywords.append("taunt")
	if not expected_body.has("permanent_keywords"): expected_body.permanent_keywords=[]
	if "taunt" not in expected_body.permanent_keywords: expected_body.permanent_keywords.append("taunt")
	return check(unit("board",target_uid,player)==expected_body,"actual Fortify is exact +0/+3 and permanent Taunt, with every other field preserved")

func native_roundtrip(stage: String) -> String:
	var before: Dictionary = snapshot()
	var path: String = "user://ashen_rebuild_" + scenario + "_" + stage + ".json"
	if not check(not FileAccess.file_exists(path),stage + ": native save path is fresh"): return ""
	if not check(game.save_to(path) == OK,stage + ": native save"): return ""
	if not check(snapshot() == before,stage + ": saving does not mutate engine"): return ""
	var restored: RefCounted = game_script.new()
	if not check(restored.load_from(path,catalog) == OK,stage + ": fresh native load"): return ""
	game = restored
	var after: Dictionary = snapshot()
	if not check(before.size() == 13 and after.size() == 13,stage + ": exact thirteen-field snapshot domain"): return ""
	for field in FIELDS:
		if not check(before[field] == after[field],stage + ": native roundtrip " + field): return ""
	var bytes: PackedByteArray = FileAccess.get_file_as_bytes(path)
	report.loads.append({"scenario":scenario,"label":stage,"path":ProjectSettings.globalize_path(path),"sha256":FileAccess.get_sha256(path),"bytes":bytes.size(),"native_original":true,"fields":FIELDS.duplicate()})
	persist()
	return path

func configure(label: String) -> bool:
	scenario = label
	acquiring = true
	recording = false
	replaying = false
	tape = []
	var config = room_script.new()
	config.reset(catalog)
	config.data.bot_count = 1
	config.data.seed = 2026110407
	config.data.enabled_minions = [ASHEN,WEAVER,DOOM,CYCLONE]
	config.data.enabled_spells = [FORTIFY]
	config.data.enabled_heroes = [PATCHWERK]
	config.data.selected_hero = PATCHWERK
	config.data.tribe_mode = "all"
	config.data.damage_received_listeners = false
	for key in ["enabled_anomalies","enabled_trinkets","enabled_quests","enabled_rewards","enabled_prizes"]: config.data[key] = []
	var damage_room: GDScript = load("res://core/damage_listener_room.gd")
	# READ-ONLY inspection of the FULL native closure, including intrinsic rewards and golden dependencies.
	var graph: Dictionary = damage_room._room_graph(config.data,catalog)
	if not check(not graph.active and graph.errors.is_empty() and graph.queue.is_empty(),"entire reachable room graph is inactive and error-free",{"active":graph.active,"errors":graph.errors,"cards":graph.cards.size(),"nodes":graph.nodes.size()}): return false
	if not check(config.data.damage_received_listeners == false,"received-listener capability is not expanded"): return false
	var issues = config.validate(catalog)
	if not check(issues.is_empty(),"ordinary RoomConfig validation accepts bounded room",issues): return false
	game = game_script.new()
	var result: Dictionary = game.start(config.data,catalog)
	if not check(result.get("ok",false),"ordinary Game start accepts validated room",result): return false
	stock_baseline = stock_totals()
	return check(owner().armor == 0 and owner(1).armor == 0 and owner().board.is_empty() and owner(1).board.is_empty(),"real Patchwerk starts armor-zero with empty boards")

func reach_tier_four() -> bool:
	var tier_entered_round: int = 1
	for _step in range(30):
		if owner().tier == 4: return true
		var tier: int = owner().tier
		var expected: int = maxi(0,int(UPGRADE_PRICES[tier])-(int(game.state.round)-tier_entered_round))
		if not check(owner().upgrade_cost == expected,"independently computed native upgrade quote"): return false
		if owner().gold >= expected:
			var gold: int = owner().gold
			if not command({"type":"upgrade"},"paid native tier advancement"): return false
			if not check(owner().tier == tier+1 and owner().gold == gold-expected,"one native tier and exact upgrade payment"): return false
			tier_entered_round = game.state.round
		elif not advance(): return false
	return check(false,"tier-four acquisition bound exhausted; no credit")

func ready_shop() -> bool:
	var minions: int = 0
	for body in owner().shop:
		if body.get("kind","minion") == "minion": minions += 1
	return index_card("shop",DOOM)>=0 and index_card("shop",CYCLONE)>=0 and index_card("shop",FORTIFY)>=0 and minions>=3

func prepare_setup(golden: bool) -> Dictionary:
	if not reach_tier_four(): return {}
	var source: String = buy_true_triple_player(ASHEN,GOLDEN,0) if golden else acquire(ASHEN)
	if source.is_empty(): return {}
	var weaver: String = acquire(WEAVER)
	var doom_a: String = acquire(DOOM)
	var doom_b: String = acquire(DOOM)
	if weaver.is_empty() or doom_a.is_empty() or doom_b.is_empty(): return {}
	for _step in range(90):
		if ready_shop() and game.state.round >= 7:
			var frozen: Dictionary = zone_by_uid("shop")
			if not command({"type":"freeze"},"freeze actual setup offers"): return {}
			if not check(owner().frozen,"native setup shop freeze engaged"): return {}
			if not advance(): return {}
			if not check(owner().gold==10 and ready_shop() and zone_by_uid("shop")==frozen,"frozen setup offers survive empty-board combat with ten real Gold"): return {}
			var source_body: Dictionary = unit("hand",source)
			if not check(source_body.card_id==(GOLDEN if golden else ASHEN) and source_body.attack==(8 if golden else 4) and source_body.health==(16 if golden else 8) and source_body.pool_id==ASHEN and source_body.pool_count==(3 if golden else 1),"genuine source retains native body and stock entitlement"): return {}
			if not check(owner().hand.size()==4 and not owner().has(LEDGER) and not owner().has(DISCOUNT),"setup contains only four genuine held fixtures and no earned ledgers"): return {}
			return {"source":source,"weaver":weaver,"dooms":[doom_a,doom_b],"round":game.state.round}
		if owner().gold>=1:
			if not refresh_player(0): return {}
		elif not advance(): return {}
	check(false,"ready-shop search bound exhausted; no invented offer")
	return {}

func sell_uid(uid: String, label: String) -> bool:
	var i: int = index_uid("board",uid)
	if not check(i>=0,label + ": genuine owned board UID exists"): return false
	var body: Dictionary = unit("board",uid).duplicate(true)
	var before: Dictionary = snapshot()
	if not command({"type":"sell","index":i},label): return false
	return check(index_uid("board",uid)<0 and index_uid("hand",uid)<0 and owner().gold==int(before.state.players[0].gold)+1 and game.pool[body.pool_id]==int(before.pool[body.pool_id])+int(body.pool_count),label + ": original UID removed, exact Gold and native stock return")

func mark_total(body: Dictionary) -> Dictionary:
	var value: Dictionary = {"attack":0,"health":0,"count":0}
	for buff in body.get("temporary_buffs",[]):
		if buff.has(MARK):
			value.attack += int(buff.attack)
			value.health += int(buff.health)
			value.count += 1
	return value

func verify_shop_bonus(attack: int, health: int, label: String) -> bool:
	var minion_count: int = 0
	var spell_count: int = 0
	for body in owner().shop:
		var amount: Dictionary = mark_total(body)
		if body.get("kind","minion") != "minion":
			spell_count += 1
			if not check(amount.attack==0 and amount.health==0 and amount.count==0,label+": actual spell excluded"): return false
			continue
		minion_count += 1
		var canonical: Dictionary = catalog.get_card(body.card_id)
		if not check(body.attack==canonical.attack+attack and body.health==canonical.health+health and body.max_health==canonical.health+health and amount.attack==attack and amount.health==health,label+": exact base plus earned vector for "+str(body.uid)): return false
		for buff in body.get("temporary_buffs",[]):
			if not check(buff.get(MARK)==game.state.round and buff.get("keywords")==[],label+": temporary grant has current-round provenance"): return false
	return check(minion_count>0 and spell_count==1,label+": nonvacuous native minion and spell domains")

func trigger(uid: String,source: String,n: int,attack: int,health: int) -> bool:
	var before: Dictionary = snapshot()
	var offers: Dictionary = zone_by_uid("shop")
	var others: Dictionary = owner(1).duplicate(true)
	if not check(owner().armor==0 and owner().health>1 and unit("hand",uid).card_id==DOOM,"trigger "+str(n)+": real ordinary Demon and armor-zero packet precondition"): return false
	if not play_minion(uid): return false
	var events: Array = game.events.slice(before.events.size())
	var packets: Array = matching_events(events,"bulk_hero_damage_observed","player",0,"type")
	var rewinds: Array = matching_events(events,"bulk_hero_damage_rewind","source_uid",source,"type")
	var grants: Array = matching_events(events,"bulk_hero_damage_buff","source_uid",source,"type")
	var discounts: Array = matching_events(events,"next_spell_discount_granted","source_uid",uid,"type")
	if not check(packets.size()==1 and packets[0].damage==1 and packets[0].health_lost==1 and packets[0].armor_before==0 and packets[0].armor_lost==0 and packets[0].health_before==before.state.players[0].health,"trigger "+str(n)+": one real health-loss packet before rewind",packets): return false
	if not check(rewinds.size()==1 and rewinds[0].event_id==packets[0].event_id and rewinds[0].source_id==unit("board",source).card_id and rewinds[0].health==before.state.players[0].health and owner().health==before.state.players[0].health and owner().armor==0,"trigger "+str(n)+": native same-packet rewind and source provenance"): return false
	var targets: Array = []
	for offered_uid in offers:
		var old: Dictionary = offers[offered_uid]
		var now: Dictionary = unit("shop",offered_uid)
		if old.get("kind","minion") != "minion":
			if not check(now==old,"trigger "+str(n)+": current spell unchanged"): return false
			continue
		targets.append(offered_uid)
		var expected: Dictionary = old.duplicate(true)
		expected.attack += attack; expected.health += health; expected.max_health += health
		var grant: Dictionary = {"attack":attack,"health":health,"keywords":[]}
		grant[MARK] = game.state.round
		expected.temporary_buffs.append(grant)
		if not check(now==expected,"trigger "+str(n)+": exact current offer grant "+str(offered_uid)): return false
		var receipts: Array = matching_events(grants,"bulk_hero_damage_buff","target_uid",offered_uid,"type")
		if not check(receipts.size()==1 and receipts[0].event_id==packets[0].event_id and receipts[0].player==0 and receipts[0].source_id==unit("board",source).card_id and receipts[0].attack==attack and receipts[0].health==health and receipts[0].temporary,"trigger "+str(n)+": unique source owner packet target receipt"): return false
	if not check(not targets.is_empty() and grants.size()==targets.size(),"trigger "+str(n)+": grant domain equals actual minion offers"): return false
	var ledger: Dictionary = {"round":game.state.round,"attack":n*attack,"health":n*health}
	if not check(owner().get(LEDGER)==ledger,"trigger "+str(n)+": exact accumulated owner ledger"): return false
	var discount_state: Dictionary = owner().get(DISCOUNT,{})
	if not check(discounts.size()==1 and discounts[0].player==0 and discounts[0].source_id==DOOM and discounts[0].amount==1 and discounts[0].purchases==1 and discount_state.get("issued")==n and discount_state.get("entries",{}).size()==n,"trigger "+str(n)+": independent discount receipt and ledger count"): return false
	if not check(owner(1)==others,"trigger "+str(n)+": unrelated owner completely unchanged"): return false
	for old_hand in before.state.players[0].hand:
		if old_hand.uid!=uid and not check(unit("hand",old_hand.uid)==old_hand,"trigger "+str(n)+": unrelated held minion excluded"): return false
	for old_board in before.state.players[0].board:
		var now_board: Dictionary = unit("board",old_board.uid)
		if old_board.card_id==WEAVER:
			if not check(now_board.attack==old_board.attack+2 and now_board.health==old_board.health+2 and now_board.max_health==old_board.max_health+2 and mark_total(now_board)==mark_total(old_board),"trigger "+str(n)+": Weaver receives only its independent permanent effect"): return false
		elif not check(now_board==old_board,"trigger "+str(n)+": unrelated board and Ashen source excluded"): return false
	return verify_shop_bonus(n*attack,n*health,"trigger "+str(n))

func future_roll(attack: int,health: int,label: String) -> bool:
	var before: Dictionary = snapshot()
	var old: Dictionary = zone_by_uid("shop")
	if not check(owner().free_rolls==0 and owner().gold>=1,label+": actual paid refresh precondition"): return false
	if not refresh_player(0): return false
	var new_events: Array = game.events.slice(before.events.size())
	var grants: Array = matching_events(new_events,"ashen_shop_future_offer_buff","player",0,"type")
	var minions: int = 0
	for body in owner().shop:
		if not check(not old.has(body.uid),label+": genuinely new offered UID"): return false
		if body.get("kind","minion") != "minion": continue
		minions += 1
		var receipts: Array = matching_events(grants,"ashen_shop_future_offer_buff","target_uid",body.uid,"type")
		if not check(receipts.size()==1 and receipts[0].attack==attack and receipts[0].health==health and receipts[0].round==game.state.round and mark_total(body).count==1,label+": exactly one owner-round future offer grant"): return false
	if not check(grants.size()==minions and minions>0,label+": complete future grant receipt domain"): return false
	var stable: Dictionary = snapshot()
	if not verify_shop_bonus(attack,health,label): return false
	return check(snapshot()==stable,label+": repeated read-only inspection never double-applies")

func buy_fortify_with_discounts() -> String:
	var i: int = index_card("shop",FORTIFY)
	if not check(i>=0 and owner().get(DISCOUNT,{}).get("entries",{}).size()==3,"three genuine discount entries precede Fortify purchase"): return ""
	var offered: Dictionary = owner().shop[i].duplicate(true)
	var before: Dictionary = snapshot()
	if not check(offered.cost==1 and offered.pool_kind=="spell" and offered.pool_count==1,"native Fortify cost one and reserved stock"): return ""
	if not command({"type":"buy","index":i},"buy genuine Fortify for zero Gold"): return ""
	if not check(owner().gold==before.state.players[0].gold and not unit("hand",offered.uid).is_empty() and unit("hand",offered.uid).pool_count==0 and game.spell_pool[FORTIFY]==int(before.spell_pool[FORTIFY])+1,"zero-cost Fortify moves real UID and releases reservation once"): return ""
	if not check(owner()[DISCOUNT].issued==3 and owner()[DISCOUNT].entries.is_empty(),"one qualifying purchase consumes all three genuine one-purchase discounts"): return ""
	return offered.uid

func redeem_real_golden_reward() -> bool:
	var i: int = index_card("hand","__triple_reward")
	if not check(i>=0 and owner().hand[i].effects==[{"type":"spell_discover","tier":5}],"genuine golden play creates actual tier-five triple reward"): return false
	var before: Dictionary = snapshot()
	var uid: String = owner().hand[i].uid
	if not command({"type":"play","index":i},"redeem actual golden triple reward"): return false
	var pouches: Array = matching_events(game.events.slice(before.events.size()),"triple_empty_pouch","player",0,"type")
	var pi: int = index_card("hand","__triple_gold_pouch")
	if not check(index_uid("hand",uid)<0 and pouches.size()==1 and owner().discover.is_empty() and pi>=0,"true-empty configured tier produces one native gold pouch"): return false
	var pouch_uid: String = owner().hand[pi].uid
	if not check(owner().hand[pi].effects==[{"type":"spell_gold","amount":3}],"native compensation pouch is exact three Gold"): return false
	var gold: int = owner().gold
	if not command({"type":"play","index":pi},"cast actual compensation gold pouch"): return false
	return check(owner().gold==gold+3 and index_uid("hand",pouch_uid)<0,"actual golden reward pays exactly three Gold once")

func verify_expired(zone: String,uid: String,active: Dictionary,attack: int,health: int) -> bool:
	var now: Dictionary = unit(zone,uid)
	if not check(not now.is_empty() and now.uid==uid,"expiry "+zone+": original recipient UID retained"): return false
	if not check(now.attack==active.attack-attack and now.health==active.health-health and now.max_health==active.max_health-health and mark_total(now)=={"attack":0,"health":0,"count":0},"expiry "+zone+": exact temporary vector and metadata removed"): return false
	for field in ["card_id","pool_id","pool_count","keywords","permanent_keywords","effects"]:
		if not check(now.get(field)==active.get(field),"expiry "+zone+": native permanent field preserved "+field): return false
	return true

func lifecycle(golden: bool) -> bool:
	if not configure(CASES[1] if golden else CASES[0]): return false
	var setup: Dictionary = prepare_setup(golden)
	if setup.is_empty(): return false
	var setup_path: String = native_roundtrip("setup")
	if setup_path.is_empty(): return false
	var setup_snapshot: Dictionary = snapshot()
	acquiring = false
	recording = true
	var source: String = setup.source
	var attack: int = 2 if golden else 1
	var health: int = 4 if golden else 2
	if not play_minion(source): return false
	if golden and not redeem_real_golden_reward(): return false
	if not play_minion(setup.weaver): return false
	if not check(not owner().has(LEDGER),"source played before Weaver so no unintended initial damage grant"): return false
	for i in range(2):
		if not trigger(setup.dooms[i],source,i+1,attack,health): return false
		if not sell_uid(setup.dooms[i],"sell spent ordinary Doom Prophet "+str(i+1)): return false
	var third: String = buy_minion(DOOM)
	if third.is_empty() or not trigger(third,source,3,attack,health): return false
	if not sell_uid(third,"sell third spent ordinary Doom Prophet"): return false
	var board_uid: String = buy_minion(CYCLONE)
	if board_uid.is_empty() or not play_minion(board_uid): return false
	var hand_uid: String = ""
	for body in owner().shop:
		if body.get("kind","minion")=="minion":
			hand_uid = buy_minion(body.card_id,0,body.uid)
			break
	if not check(not hand_uid.is_empty() and hand_uid!=board_uid,"two distinct genuinely bought recipients cover hand and board"): return false
	if not check(mark_total(unit("hand",hand_uid)).attack==3*attack and mark_total(unit("hand",hand_uid)).health==3*health and mark_total(unit("board",board_uid)).attack==3*attack and mark_total(unit("board",board_uid)).health==3*health,"purchase and play preserve complete earned temporary vectors"): return false
	var fortify: String = buy_fortify_with_discounts()
	if fortify.is_empty() or not cast_fortify_player(fortify,board_uid,0): return false
	if not future_roll(3*attack,3*health,"future offers before source sale"): return false
	var active_ledger: Dictionary = owner()[LEDGER].duplicate(true)
	var current_shop: Dictionary = zone_by_uid("shop")
	var held: Dictionary = unit("hand",hand_uid).duplicate(true)
	var boarded: Dictionary = unit("board",board_uid).duplicate(true)
	if not sell_uid(source,"sell actual Ashen source"): return false
	if not check(owner()[LEDGER]==active_ledger and zone_by_uid("shop")==current_shop and unit("hand",hand_uid)==held and unit("board",board_uid)==boarded,"source sale preserves earned ledger and every existing recipient grant"): return false
	if not future_roll(3*attack,3*health,"future offers after source sale"): return false
	var frozen_uid: String = ""
	for body in owner().shop:
		if body.get("kind","minion")=="minion": frozen_uid=body.uid;break
	if not check(not frozen_uid.is_empty() and frozen_uid!=hand_uid and frozen_uid!=board_uid,"third distinct genuine recipient covers frozen shop"): return false
	if not command({"type":"freeze"},"freeze genuinely buffed final offers"): return false
	if not check(owner().frozen and index_uid("board",source)<0 and owner()[LEDGER]==active_ledger,"active state has real freeze, absent source and retained turn ledger"): return false
	recording = false
	var active: Dictionary = snapshot()
	var recipients: Dictionary = {"hand":unit("hand",hand_uid).duplicate(true),"board":unit("board",board_uid).duplicate(true),"shop":unit("shop",frozen_uid).duplicate(true)}
	var active_path: String = native_roundtrip("active")
	if active_path.is_empty(): return false
	if not check(snapshot()==active,"active native save/load preserves full state with no duplicate grants"): return false
	var restored: RefCounted = game_script.new()
	if not check(restored.load_from(setup_path,catalog)==OK,"replay loads original setup into another fresh Game"): return false
	game = restored
	if not check(snapshot()==setup_snapshot,"replay setup preserves all thirteen persisted fields"): return false
	replaying = true
	for step in tape:
		if not command(step.command,"replay: "+step.label,step.player,step.expected_ok): return false
	replaying = false
	var replay_snapshot: Dictionary = snapshot()
	for field in FIELDS:
		if not check(replay_snapshot[field]==active[field],"deterministic public-command replay "+field): return false
	var replay_path: String = native_roundtrip("active_replay")
	if replay_path.is_empty(): return false
	if not check(FileAccess.get_file_as_bytes(active_path)==FileAccess.get_file_as_bytes(replay_path),"active and replay original native saves are byte-identical"): return false
	report.replays.append({"scenario":scenario,"setup":ProjectSettings.globalize_path(setup_path),"active":ProjectSettings.globalize_path(active_path),"replayed":ProjectSettings.globalize_path(replay_path),"commands":tape.duplicate(true),"fields":FIELDS.duplicate(),"byte_identical":true})
	if not advance(): return false
	var expired_totals: Dictionary = game.BulkHeroDamage.AshenShop.totals(owner(),int(game.state.round))
	if not check(game.state.round==int(setup.round)+1 and expired_totals=={"round":game.state.round,"attack":0,"health":0} and int(owner().get(LEDGER,{}).get("round",-1))<int(game.state.round),"next turn expires owner Ashen ledger after source sale"): return false
	if not verify_expired("hand",hand_uid,recipients.hand,3*attack,3*health): return false
	if not verify_expired("board",board_uid,recipients.board,3*attack,3*health): return false
	if not verify_expired("shop",frozen_uid,recipients.shop,3*attack,3*health): return false
	var permanent: Dictionary = unit("board",board_uid)
	if not check(permanent.card_id==CYCLONE and permanent.attack==2 and permanent.health==4 and permanent.max_health==4 and permanent.keywords==["divine_shield","windfury","taunt"] and permanent.permanent_keywords==["divine_shield","windfury","taunt"],"Fortify permanent 2/4 Taunt survives together with native Shield and Windfury"): return false
	if not refresh_player(0): return false
	if not verify_shop_bonus(0,0,"fresh next-turn shop has no previous-turn bonus"): return false
	var expired_path: String = native_roundtrip("expired")
	if expired_path.is_empty(): return false
	var active_events: Array = active.events.slice(setup_snapshot.events.size())
	var actual_packets: Array = matching_events(active_events,"bulk_hero_damage_observed","player",0,"type")
	var actual_discounts: Array = matching_events(active_events,"next_spell_discount_granted","player",0,"type")
	var actual_rolls: Array = tape.filter(func(step): return step.command.type=="roll")
	if not check(actual_packets.size()==3 and actual_discounts.size()==3 and actual_rolls.size()==2,"exact active-stage semantic counts from actual native events and command tape"): return false
	report.case_evidence.append({"case":scenario,"round":setup.round,"source_uid":source,"golden":golden,"damage_packets":actual_packets.size(),"discount_grants":actual_discounts.size(),"current_vector":[active_ledger.attack,active_ledger.health],"future_rolls":actual_rolls.size(),"packet_receipts":actual_packets,"discount_receipts":actual_discounts,"recipients":{"hand":hand_uid,"board":board_uid,"shop":frozen_uid},"native_save_stages":["setup","active","active_replay","expired"],"replay_commands":tape.size()})
	report.completed_cases.append(scenario)
	persist()
	return true

func finish() -> void:
	if failures==0:
		check(report.completed_cases==CASES,"all two declared lifecycle cases completed")
		check(report.loads.size()==8,"exactly eight fresh original native saves and roundtrips")
		check(report.replays.size()==2,"one complete deterministic native replay per case")
	report.status = "passed_narrow_rebuild_only" if failures==0 and report.completed_cases==CASES and report.loads.size()==8 else "failed_or_incomplete_no_credit"
	report.failures = failures
	report.counts = {"checks":report.checks.size(),"commands":report.commands.size(),"loads":report.loads.size(),"combats":report.combats.size(),"cases":report.completed_cases.size()}
	persist()
	print("ASHEN_REBUILD_PUBLIC_TERMINAL ",JSON.stringify(report))
	quit(0 if report.status=="passed_narrow_rebuild_only" else 1)

func _initialize() -> void:
	var expected: String = ""
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--expected-fingerprint="): expected=arg.trim_prefix("--expected-fingerprint=")
	if "--reviewed-ashen-rebuild" not in OS.get_cmdline_user_args() or expected.length()!=64:
		print("ASHEN_REBUILD_HOLD: reviewed source/harness seal and independent actual catalog fingerprint are required")
		quit(2);return
	game_script=load("res://core/game.gd")
	room_script=load("res://core/room_config.gd")
	catalog=load("res://core/catalog.gd").new()
	catalog.load_catalog()
	if not check(catalog.load_errors.is_empty(),"fresh candidate Catalog loads without errors",catalog.load_errors): finish();return
	report.execution_fingerprint=catalog.execution_fingerprint
	if not check(catalog.execution_fingerprint==expected,"actual catalog fingerprint equals independently reviewed lane result"): finish();return
	for identity in [ASHEN,GOLDEN]:
		var golden: bool = identity==GOLDEN
		var card: Dictionary = catalog.get_card(identity)
		var effect: Dictionary = {"type":"after_recruit_hero_damage","source_id":identity,"event":"hero_damaged","scope":"shop","tribe":"","rewind":true,"temporary":true,"attack":2 if golden else 1,"health":4 if golden else 2}
		if not check(card.attack==(8 if golden else 4) and card.health==(16 if golden else 8) and card.tier==4 and card.effects==[effect] and card.is_golden==golden,"exact latest native Ashen body and program "+identity): finish();return
	var cyclone: Dictionary = catalog.get_card(CYCLONE)
	if not check(cyclone.attack==2 and cyclone.health==1 and cyclone.effects==[] and cyclone.keywords==["divine_shield","windfury"],"independent Cyclone 2/1 native Shield and Windfury fixture"): finish();return
	var doom: Dictionary = catalog.get_card(DOOM)
	if not check(doom.attack==2 and doom.health==1 and doom.tribes==["恶魔","纳迦"] and doom.effects==[{"type":"battlecry_next_tavern_spell_discount","source_id":DOOM,"scope":"owner","family":"tavern_spell_cost","mode":"subtract","amount":1,"purchases":1}],"independent Doom Prophet 2/1 Demon Naga and one-discount fixture"): finish();return
	for golden in [false,true]:
		if not lifecycle(golden): finish();return
	finish()
