# Ashen tests rescue after second workspace loss

Only files under this directory are written. No engine is run and the parent's
/tmp/recovery_restart_20261104T0855Z directory is not modified. All files are
reconstructed from complete material still present in this worker's conversation.
Their freshly computed hashes must be distinguished from the recorded reference
hashes in RESCUE_STATUS.json. Matching a reference hash must be actually measured;
absence of a match is not claimed as byte-faithful restoration.

V1 was independently statically audited, but never engine-run. V2's independent
static audit was interrupted by loss and remains incomplete. Prior Python test
counts do not constitute current test outcomes or native acceptance.

The v2 report-only observer adds full actual 13-field before/after snapshots to
active/replay/expiry command receipts, not adaptive acquisition. It also retains
the actual next-recruit snapshot before refreshing away frozen offers. This is
an offline evidence improvement, not an identified game defect. The pure-data
postvalidator must be separately sealed and actually invoked by the final runner;
exceptions fail the lane and preserve the entire report/evidence.
