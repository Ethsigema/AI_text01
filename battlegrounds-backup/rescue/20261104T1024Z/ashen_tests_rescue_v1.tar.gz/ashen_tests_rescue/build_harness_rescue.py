"""Read-only checked surviving helper + reconstructed body; write only beside this script."""
from pathlib import Path
import argparse,hashlib,json
H=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('--helper',required=True);args=p.parse_args();helper=Path(args.helper)
raw=helper.read_bytes();digest=hashlib.sha256(raw).hexdigest()
assert digest=='9d828ddf264e534554fc1cf522268c8ad45c1ea5b4d1576b91a86ca360d301a0',(str(helper),digest)
functions={x.split('(',1)[0]:'func '+x.rstrip()+'\n\n' for x in raw.decode().split('\nfunc ')[1:]}
names=['check','persist','owner','snapshot','index_uid','index_card','unit','command','buy_minion','play_minion','stock_totals','zone_by_uid','matching_events','refresh_player','acquire','advance','buy_true_triple_player','cast_fortify_player']
s=''.join(functions[n] for n in names).replace(' and no_removed_identity()','')
s=s.replace('"phase":game.state.phase})','"phase":game.state.phase,"expected_ok":expect_ok,"replay":replaying})')
s=s.replace('func command(cmd: Dictionary, label: String, player: int = 0, expect_ok: bool = true) -> bool:\n','func command(cmd: Dictionary, label: String, player: int = 0, expect_ok: bool = true) -> bool:\n\tif recording: tape.append({"player":player,"command":cmd.duplicate(true),"label":label,"expected_ok":expect_ok})\n')
s=s.replace('\t\tfor e in c.log:\n\t\t\tif not check(e.get("event") not in ["attack","damage","death","hand_buff"],"no unrelated acquisition combat hazard"): return false','\t\tif not check(c.log.filter(func(e): return e.get("event") in ["attack","damage","death","hand_buff"]).is_empty(),"no unrelated acquisition combat hazard"): return false')
s=s.replace('"acquisition":acquiring,"result":','"acquisition":acquiring,"replay":replaying,"result":')
head='''extends SceneTree
## NEW reconstruction, not recovered original bytes. Preparation only until reviewed seal.
## No synthetic game mutation: all acquisition, gold, damage, buffs and turns are public commands.
const OUTPUT = "user://ashen_lifecycle_public_report.json"
const ASHEN = "BG32_873"
const GOLDEN = "BG32_873_G"
const WEAVER = "BGS_004"
const DOOM = "BG31_330"
const CYCLONE = "BGS_119"
const PATCHWERK = "TB_BaconShop_HERO_34"
const FORTIFY = "BG28_503"
const LEDGER = "ashen_turn_shop_bonus"
const MARK = "ashen_turn_shop_round"
const DISCOUNT = "next_spell_discount_state"
const CASES = ["normal_ashen_lifecycle", "golden_ashen_lifecycle"]
const FIELDS = ["schema_version", "rules_version", "execution_fingerprint", "room", "state", "pool", "spell_pool", "rng_seed", "rng_state", "next_uid", "events", "command_log", "last_combats"]
const UPGRADE_PRICES = [0,5,7,8,11,11,0]
var game_script: GDScript
var room_script: GDScript
var catalog: RefCounted
var game: RefCounted
var stock_baseline: Dictionary = {}
var scenario: String = "source_contracts"
var failures: int = 0
var acquiring: bool = true
var recording: bool = false
var replaying: bool = false
var tape: Array = []
var report: Dictionary = {"schema_version":1,"status":"not_run","execution_fingerprint":"","checks":[],"commands":[],"loads":[],"replays":[],"combats":[],"failure_snapshots":[],"completed_cases":[],"required_cases":CASES,"case_evidence":[],"scope":"NEW isolated 37.0.2 Ashen ordinary and genuinely tripled golden, armor-zero recruit packets only","held":["final source and harness binding unresolved before review","historical acceptance is not carried","mixed received-damage rooms","armor absorption and mixed armor health packets","arbitrary damage sources","lethal rewind","temporary-buffed triples","full identity and whole patch acceptance","GUI","exhaustive RNG","synthetic guards have no gameplay credit"]}

'''
payload=head+s+(H/'lifecycle_body.gd.inc').read_text();(H/'ashen_lifecycle_public.gd').write_text(payload)
# Exact observation-only transformation retained from the previous preparation.
v2=payload.replace('user://ashen_lifecycle_public_report.json','user://ashen_lifecycle_public_report_v2.json').replace('user://ashen_rebuild_','user://ashen_rebuild_v2_').replace('ASHEN_REBUILD_PUBLIC_TERMINAL','ASHEN_REBUILD_V2_PUBLIC_TERMINAL').replace('passed_narrow_rebuild_only','passed_narrow_rebuild_v2_only').replace('"schema_version":1,"status":"not_run"','"schema_version":1,"observation_schema_version":2,"status":"not_run"')
old='\treport.commands.append({"scenario":scenario,"label":label,"player":player,"command":cmd.duplicate(true),"result":result.duplicate(true),"before_round":before.state.round,"after_round":game.state.round,"phase":game.state.phase,"expected_ok":expect_ok,"replay":replaying})'
new='\tvar receipt: Dictionary = {"scenario":scenario,"label":label,"player":player,"command":cmd.duplicate(true),"result":result.duplicate(true),"before_round":before.state.round,"after_round":game.state.round,"phase":game.state.phase,"expected_ok":expect_ok,"replay":replaying}\n\t# Observation only. Lifecycle, replay and expiry get full native snapshots; acquisition retains its audited direct assertions.\n\tif not acquiring:\n\t\treceipt.before_snapshot = before\n\t\treceipt.after_snapshot = snapshot()\n\treport.commands.append(receipt)'
assert v2.count(old)==1;v2=v2.replace(old,new)
old='\tif not advance(): return false\n\tvar expired_totals:';assert v2.count(old)==1;v2=v2.replace(old,'\tif not advance(): return false\n\tvar last_recruit_snapshot: Dictionary = snapshot()\n\tvar expired_totals:')
old='"native_save_stages":["setup","active","active_replay","expired"],"replay_commands":tape.size()}';assert v2.count(old)==1;v2=v2.replace(old,'"native_save_stages":["setup","active","active_replay","expired"],"replay_commands":tape.size(),"last_recruit_snapshot":last_recruit_snapshot}')
(H/'ashen_lifecycle_public_v2.gd').write_text(v2)
refs={'ashen_lifecycle_public.gd':'d1ba67614943be0209b247318cf98d57dedd78d2090f13cb37c291d012ef4865','ashen_lifecycle_public_v2.gd':'551f97f2513123453d4933118e0278095de70468462588b6dfad647edab4360f'}
result={'surviving_helper':{'path':str(helper),'sha256':digest},'files':{}}
for name,expected in refs.items():
    data=(H/name).read_bytes();actual=hashlib.sha256(data).hexdigest();result['files'][name]={'bytes':len(data),'sha256':actual,'reference_sha256':expected,'measured_match':actual==expected};print(name,len(data),actual,'MATCH',actual==expected)
(H/'HARNESS_RECONSTRUCTION_RESULTS.json').write_text(json.dumps(result,indent=2)+'\n')
