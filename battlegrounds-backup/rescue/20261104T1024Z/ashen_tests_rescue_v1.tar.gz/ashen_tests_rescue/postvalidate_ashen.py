"""Reconstructed pure-data Ashen v2 validator after second workspace loss.
This is new rescue text; compare its actual SHA with the old recorded reference.
No engine, file IO or network is used by validate(). Inputs are never mutated.
"""
from collections import Counter
from copy import deepcopy
import json,re
CASES=('normal_ashen_lifecycle','golden_ashen_lifecycle')
FIELDS=('schema_version','rules_version','execution_fingerprint','room','state','pool','spell_pool','rng_seed','rng_state','next_uid','events','command_log','last_combats')
ASHEN='BG32_873'; GOLD='BG32_873_G'; WEAVER='BGS_004'; DOOM='BG31_330'; CYCLE='BGS_119'; FORT='BG28_503'; HERO='TB_BaconShop_HERO_34'
LEDGER='ashen_turn_shop_bonus'; MARK='ashen_turn_shop_round'; DISCOUNT='next_spell_discount_state'
STAGES=('setup','active','active_replay','expired')
ROLES=('source','weaver','doom1','sell_doom1','doom2','sell_doom2','buy_doom','doom3','sell_doom3','buy_cycle','cycle','buy_hand','buy_fortify','fortify','roll_before','sell_source','roll_after','freeze')
TYPES=('play','play','play','sell','play','sell','buy','play','sell','buy','play','buy','buy','play','roll','sell','roll','freeze')
DOOM_EFFECT=[{'type':'battlecry_next_tavern_spell_discount','source_id':DOOM,'scope':'owner','family':'tavern_spell_cost','mode':'subtract','amount':1,'purchases':1}]
WEAVER_EFFECT=[{'type':'on_play_effect','tribe':'恶魔','hero_damage':1,'count':1,'effect':{'type':'spell_buff','scope':'self','attack':2,'health':2}}]
FORT_EFFECT=[{'type':'spell_buff','scope':'target','attack':0,'health':3,'allow_shop':True,'temporary':False},{'type':'spell_keyword','scope':'target','keyword':'taunt','allow_shop':True,'temporary':False}]
class ValidationError(ValueError): pass

def need(condition,message):
    if not condition: raise ValidationError(message)
def req(value,key,where):
    need(isinstance(value,dict),where+': expected object');need(key in value,where+': missing '+str(key));return value[key]
def eq(a,b,message):
    need(json.dumps(a,sort_keys=True,separators=(',',':'),allow_nan=False)==json.dumps(b,sort_keys=True,separators=(',',':'),allow_nan=False),message)
def integer(x,where,minimum=0):
    need(type(x) is int and x>=minimum,where+': expected bounded integer');return x
def owner(s,index=0):
    players=req(req(s,'state','snapshot'),'players','state');need(isinstance(players,list) and len(players)==2,'exact two-player native state required');return players[index]
def zone(p,name):
    z=req(p,name,'owner');need(isinstance(z,list),'zone must be an array: '+name)
    for u in z:need(isinstance(u,dict) and isinstance(u.get('uid'),str) and re.fullmatch(r'u[1-9][0-9]*',u['uid']),'native UID missing/malformed in '+name)
    need(len({u['uid'] for u in z})==len(z),'duplicate UID in '+name);return z
def pick(z,uid,where):
    a=[u for u in z if u.get('uid')==uid];need(len(a)==1,where+': missing/duplicate original UID '+str(uid));return a[0]
def indexed(p,z,cmd):
    i=integer(req(cmd,'index','command'),'command.index');bodies=zone(p,z);need(i<len(bodies),'command index outside actual '+z);return bodies[i]
def snapshot(s,fp,where):
    need(isinstance(s,dict) and set(s)==set(FIELDS),where+': exact thirteen native fields required');eq(s['execution_fingerprint'],fp,where+': fingerprint')
    need(isinstance(s['command_log'],list) and isinstance(s['events'],list) and isinstance(s['last_combats'],list),where+': native histories missing')
    for p in s['state']['players']:
        all_u=[]
        for name in ('hand','board','shop'):all_u.extend(u['uid'] for u in zone(p,name))
        need(len(all_u)==len(set(all_u)),where+': same UID in multiple owner zones')
    return s
def marks(u,round_number=None):
    buffs=req(u,'temporary_buffs','minion');need(isinstance(buffs,list),'temporary ledger must be array');chosen=[]
    for b in buffs:
        need(isinstance(b,dict),'temporary grant must be object')
        if MARK in b:
            integer(b[MARK],'grant round');integer(req(b,'attack','grant'),'grant attack');integer(req(b,'health','grant'),'grant health');eq(req(b,'keywords','grant'),[],'Ashen must not grant keywords')
            if round_number is not None:eq(b[MARK],round_number,'grant round mismatch')
            chosen.append(b)
    return sum(x['attack'] for x in chosen),sum(x['health'] for x in chosen),len(chosen)
def event_rows(events,kind,**fields):return [e for e in events if e.get('type')==kind and all(e.get(k)==v for k,v in fields.items())]
def stock(s):
    total={'minion:'+k:integer(v,'pool stock') for k,v in s['pool'].items()};total.update({'spell:'+k:integer(v,'spell stock') for k,v in s['spell_pool'].items()})
    for p in s['state']['players']:
        for z in ('board','hand','shop'):
            for u in zone(p,z):
                n=integer(u.get('pool_count',0),'unit entitlement')
                if n:
                    key=('spell:' if u.get('pool_kind')=='spell' else 'minion:')+req(u,'pool_id','reserved card');total[key]=total.get(key,0)+n
    return total
def common_command(row,fp,previous=None):
    need(row.get('expected_ok') is True and req(row,'result','command row').get('ok') is True,'native command must genuinely succeed')
    before=snapshot(req(row,'before_snapshot','command row'),fp,'before_snapshot');after=snapshot(req(row,'after_snapshot','command row'),fp,'after_snapshot')
    if previous is not None:eq(before,previous,'adjacent full native snapshots must chain exactly')
    eq(row['before_round'],before['state']['round'],'before-round receipt');eq(row['after_round'],after['state']['round'],'after-round receipt');eq(row['phase'],after['state']['phase'],'phase receipt');eq(before['room'],after['room'],'room cannot change during command')
    need(after['state']['phase']=='recruit','actual command must return active recruit');eq(after['state']['command_sequence'],before['state']['command_sequence']+1,'one actual command sequence');eq(after['command_log'][:-1],before['command_log'],'native command history prefix')
    last=after['command_log'][-1];eq(last['command'],row['command'],'native command log binds actual command');eq(last['player'],row['player'],'native command player');eq(last['sequence'],after['state']['command_sequence'],'native command sequence receipt');eq(last['origin'],'human','no hidden bot actions')
    eq(after['events'][:len(before['events'])],before['events'],'native event history prefix');eq(stock(after),stock(before),'complete native stock conservation');return before,after,after['events'][len(before['events']):]
def plain_zones(before,after,except_zones=()):
    for z in ('hand','board','shop'):
        if z not in except_zones:eq(zone(after,z),zone(before,z),'complete unchanged '+z+' zone')
def buffed(u,a,h,round_number):
    out=deepcopy(u)
    for field,delta in [('attack',a),('health',h),('max_health',h)]:out[field]=req(out,field,'buff target')+delta
    out['temporary_buffs'].append({'attack':a,'health':h,'keywords':[],MARK:round_number});return out

def fixture_facts(setup,golden):
    p=owner(setup);eq(p['hero_id'],HERO,'actual configured hero');eq(p['armor'],0,'armor-zero fixture');eq(owner(setup,1)['hero_id'],HERO,'actual opponent hero');eq(owner(setup,1)['armor'],0,'opponent armor-zero');eq(p['tier'],4,'native tier four');eq(p['gold'],10,'native setup ten Gold');eq(p['board'],[],'empty setup board');eq(owner(setup,1)['board'],[],'empty opponent board');need(LEDGER not in p and DISCOUNT not in p,'setup must have no pre-earned ledgers')
    hand=zone(p,'hand');need(len(hand)==4,'four genuine setup fixtures');ids=Counter(u['card_id'] for u in hand);eq(dict(ids),{GOLD if golden else ASHEN:1,WEAVER:1,DOOM:2},'exact actual setup fixture multiset');source=next(u for u in hand if u['card_id'] in (ASHEN,GOLD));a,h=(8,16) if golden else (4,8)
    eq([source['attack'],source['health'],source['max_health']],[a,h,h],'native source body');eq(source['pool_id'],ASHEN,'source ordinary pool identity');eq(source['pool_count'],3 if golden else 1,'genuine source entitlement');eq(source['golden'],golden,'native source variant')
    eq(source['effects'],[{'type':'after_recruit_hero_damage','source_id':source['card_id'],'event':'hero_damaged','scope':'shop','tribe':'','rewind':True,'temporary':True,'attack':2 if golden else 1,'health':4 if golden else 2}],'exact latest source program')
    weaver=next(u for u in hand if u['card_id']==WEAVER);eq(weaver['effects'],WEAVER_EFFECT,'independent Weaver program')
    for d in [u for u in hand if u['card_id']==DOOM]:eq([d['attack'],d['health'],d['max_health']],[2,1,1],'Doom native body');eq(d['effects'],DOOM_EFFECT,'Doom program');eq(d['tribes'],['恶魔','纳迦'],'Doom native tribes');eq(d['pool_count'],1,'ordinary Doom entitlement')
    cycles=[u for u in zone(p,'shop') if u['card_id']==CYCLE];need(cycles,'missing actual setup Cyclone fixture')
    for u in cycles:eq([u['attack'],u['health'],u['max_health'],u['keywords'],u['effects']],[2,1,1,['divine_shield','windfury'],[]],'independent Cyclone source facts')
    spells=[u for u in zone(p,'shop') if u['card_id']==FORT];need(len(spells)==1,'one actual setup Fortify');eq(spells[0]['effects'],FORT_EFFECT,'Fortify complete native program');eq(spells[0]['cost'],1,'Fortify native cost');return source['uid'],{ASHEN:(4,8),GOLD:(8,16),DOOM:(2,1),CYCLE:(2,1),WEAVER:(weaver['attack'],weaver['health'])}
def room_scope(s):
    r=s['room'];eq(r['enabled_minions'],[ASHEN,WEAVER,DOOM,CYCLE],'exact isolated minion room');eq(r['enabled_spells'],[FORT],'exact isolated spell room');eq(r['enabled_heroes'],[HERO],'exact isolated hero room');eq(r['selected_hero'],HERO,'selected native hero');eq(r['damage_received_listeners'],False,'no received-listener capability expansion')
    for k in ('enabled_anomalies','enabled_trinkets','enabled_quests','enabled_rewards','enabled_prizes'):eq(req(r,k,'room'),[],'no unreviewed room root '+k)
    eq(r['shop_overrides'],{},'no synthetic shop overrides')
def check_shop(p,bases,a,h,round_number,single=False):
    minions=0;spells=0
    for u in zone(p,'shop'):
        if u.get('kind','minion')!='minion':spells+=1;eq(u['card_id'],FORT,'only configured actual shop spell');eq(marks(u),(0,0,0),'no spell buff')
        else:
            minions+=1;need(u['card_id'] in bases,'unbound future-offer source fixture');ba,bh=bases[u['card_id']];eq([u['attack'],u['health'],u['max_health']],[ba+a,bh+h,bh+h],'future/current offered base plus vector');ma,mh,n=marks(u,round_number);eq((ma,mh),(a,h),'exact temporary vector')
            if single:eq(n,1 if a or h else 0,'exactly-once future grant')
    need(minions>0 and spells==1,'nonvacuous minion and spell domains')
def play_transfer(p,q,cmd,role,extra_hand=()):
    u=indexed(p,'hand',cmd);uid=u['uid'];expected_hand=[x for x in p['hand'] if x['uid']!=uid];additions=[x for x in q['hand'] if x['uid'] not in {y['uid'] for y in expected_hand}]
    eq([x for x in q['hand'] if x['uid'] in {y['uid'] for y in expected_hand}],expected_hand,'all unplayed held objects preserved');eq([x['card_id'] for x in additions],list(extra_hand),'only declared actual reward generated');need(uid not in {x['uid'] for x in q['hand']},'played UID leaves hand');need(len(q['board'])==len(p['board'])+1,'one actual board insertion');eq(cmd['position'],len(p['board']),'real append position');eq(q['board'][-1],u,'full played minion object preserved');return u

def damage_step(p,q,events,source_uid,ordinal,vector):
    a,h=vector;round_number=events[-1]['round'];packets=event_rows(events,'bulk_hero_damage_observed',player=0);need(len(packets)==1 and len(event_rows(events,'bulk_hero_damage_observed'))==1,'one real damage packet for each trigger');packet=packets[0]
    for k,val in {'damage':1,'health_lost':1,'armor_before':0,'armor_lost':0,'health_before':p['health']}.items():eq(req(packet,k,'packet'),val,'actual packet '+k)
    eq(p['armor'],0,'actual before armor zero');eq(q['armor'],0,'actual after armor zero');eq(q['health'],p['health'],'native rewind restores health');rewinds=event_rows(events,'bulk_hero_damage_rewind',source_uid=source_uid);need(len(rewinds)==1 and len(event_rows(events,'bulk_hero_damage_rewind'))==1,'one actual source rewind');eq(rewinds[0]['event_id'],packet['event_id'],'same-packet rewind');eq(rewinds[0]['player'],0,'rewind owner');eq(rewinds[0]['source_id'],pick(p['board'],source_uid,'source')['card_id'],'rewind exact source identity');eq(rewinds[0]['health'],p['health'],'exact native rewind health')
    grants=event_rows(events,'bulk_hero_damage_buff',source_uid=source_uid);eq(len(grants),len(event_rows(events,'bulk_hero_damage_buff')),'no foreign source grant receipts');expected=[]
    for u in p['shop']:
        if u.get('kind','minion')=='minion':
            expected.append(buffed(u,a,h,round_number));gr=[e for e in grants if e.get('target_uid')==u['uid']];need(len(gr)==1,'one source receipt per current minion')
            for k,val in {'player':0,'event_id':packet['event_id'],'attack':a,'health':h,'temporary':True,'source_id':pick(p['board'],source_uid,'source')['card_id']}.items():eq(req(gr[0],k,'grant'),val,'native grant '+k)
        else:expected.append(u)
    eq(q['shop'],expected,'complete shop changed exactly by per-minion current grants');eq(len(grants),sum(x.get('kind','minion')=='minion' for x in p['shop']),'no extra grant recipient');eq(q[LEDGER],{'round':round_number,'attack':ordinal*a,'health':ordinal*h},'earned owner ledger');expected_board=[]
    for u in p['board']:
        item=deepcopy(u)
        if item['card_id']==WEAVER:
            for f,d in [('attack',2),('health',2),('max_health',2)]:item[f]+=d
        expected_board.append(item)
    eq(q['board'][:-1],expected_board,'complete previous board only gets independent Weaver effect');doom=q['board'][-1];eq(doom['card_id'],DOOM,'ordinary actual triggering Demon');discounts=event_rows(events,'next_spell_discount_granted',source_uid=doom['uid']);need(len(discounts)==1 and len(event_rows(events,'next_spell_discount_granted'))==1,'one independent Doom discount receipt')
    for k,val in {'player':0,'source_id':DOOM,'amount':1,'purchases':1}.items():eq(discounts[0][k],val,'discount receipt '+k)
    ds=req(q,DISCOUNT,'owner');eq(sorted(ds),['entries','issued','version'],'complete discount state shape');eq(ds['version'],1,'native discount state version');eq(ds['issued'],ordinal,'native discount issued count');need(len(ds['entries'])==ordinal,'native discount entries count');prev=p.get(DISCOUNT,{}).get('entries',{});eq({k:val for k,val in ds['entries'].items() if k in prev},prev,'all previous discount entries preserved');added=[val for k,val in ds['entries'].items() if k not in prev];need(len(added)==1,'one new discount ledger entry');eq(added[0],{'source_id':DOOM,'source_uid':doom['uid'],'granted_round':round_number,'amount':1,'purchases':1,'remaining':1},'complete independent discount ledger entry');return packet,discounts[0]

def active_step(row,role,fp,source_uid,bases,vector,previous):
    before,after,events=common_command(row,fp,previous);p,q=owner(before),owner(after);cmd=row['command'];gold_delta=0
    eq(row['player'],0,'active commands are owner-zero only');eq(owner(after,1),owner(before,1),'entire unrelated owner unchanged');eq(after['state']['round'],before['state']['round'],'active sequence remains one turn');eq(q['health'],p['health'],'every active action preserves final rewound hero health');eq([p['armor'],q['armor']],[0,0],'entire active lane is armor-zero')
    for key in ('schema_version','rules_version','rng_seed'):eq(after[key],before[key],'stable '+key)
    if role in ('source','weaver','cycle','doom1','doom2','doom3'):
        u=play_transfer(p,q,cmd,role,['__triple_reward'] if role=='source' and u_is_golden(p,cmd) else []);wanted={'source':GOLD if u.get('golden') else ASHEN,'weaver':WEAVER,'cycle':CYCLE}.get(role,DOOM);eq(u['card_id'],wanted,'role binds actual played card')
        if role.startswith('doom'):damage_step(p,q,events,source_uid,int(role[-1]),vector)
        else:
            eq(q['board'][:-1],p['board'],'previous board unchanged by plain minion play');eq(q['shop'],p['shop'],'shop unchanged before/after plain play');need(not event_rows(events,'bulk_hero_damage_observed'),'no unintended damage packet');eq(q.get(LEDGER),p.get(LEDGER),'no unintended owner grant')
    elif role in ('reward','pouch'):
        u=indexed(p,'hand',cmd);identity='__triple_reward' if role=='reward' else '__triple_gold_pouch';eq(u['card_id'],identity,'actual golden reward source UID');eq(u['effects'],[{'type':'spell_discover','tier':5}] if role=='reward' else [{'type':'spell_gold','amount':3}],'actual golden reward program');kept=[x for x in p['hand'] if x['uid']!=u['uid']];eq([x for x in q['hand'] if x['uid'] in {y['uid'] for y in kept}],kept,'complete remaining reward hand');added=[x for x in q['hand'] if x['uid'] not in {y['uid'] for y in kept}];eq([x['card_id'] for x in added],['__triple_gold_pouch'] if role=='reward' else [],'one genuine reward transition');plain_zones(p,q,('hand',))
        if role=='reward':need(len(event_rows(events,'triple_empty_pouch',player=0))==1,'actual empty-tier pouch event');eq(q['discover'],[],'real tier-five discover is empty')
        else:gold_delta=3
    elif role.startswith('buy_'):
        u=indexed(p,'shop',cmd);uid=u['uid'];identities={'buy_doom':DOOM,'buy_cycle':CYCLE,'buy_fortify':FORT}
        if role in identities:eq(u['card_id'],identities[role],'actual purchased identity')
        else:need(u.get('kind','minion')=='minion','held recipient must be a genuine minion')
        eq(q['shop'],[x for x in p['shop'] if x['uid']!=uid],'exact original offered UID removed');acquired=deepcopy(u)
        for k in ('native_filtered_offer_price','native_bouncy_health_offer'):acquired.pop(k,None)
        acquired['recruit_shop_aura_attack']=0;acquired['recruit_shop_aura_health']=0
        if role=='buy_fortify':
            eq(u['cost'],1,'Fortify printed cost');eq(u['pool_kind'],'spell','native spell reservation');eq(u['pool_count'],1,'native spell entitlement');acquired['pool_count']=0;eq(q[DISCOUNT]['issued'],3,'discount issue history survives purchase');eq(q[DISCOUNT]['entries'],{},'all three genuine one-purchase discounts consumed');need(len(p[DISCOUNT]['entries'])==3,'three actual discounts before purchase');expect=deepcopy(before['spell_pool']);expect[FORT]+=1;eq(after['spell_pool'],expect,'spell stock released once')
        else:eq(u['pool_id'],u['card_id'],'native minion pool source');eq(u['pool_count'],1,'ordinary purchased entitlement');gold_delta=-3;eq(after['pool'],before['pool'],'reserved minion stock not debited twice')
        eq(q['hand'],p['hand']+[acquired],'complete native acquired object and existing hand');eq(q['board'],p['board'],'purchase board unchanged');eq(q.get(LEDGER),p.get(LEDGER),'purchase preserves earned ledger')
    elif role.startswith('sell_'):
        u=indexed(p,'board',cmd)
        if role=='sell_source':eq(u['uid'],source_uid,'actual source UID sold')
        else:eq(u['card_id'],DOOM,'only spent ordinary Doom sold')
        eq(q['board'],[x for x in p['board'] if x['uid']!=u['uid']],'complete exact sold-UID removal');plain_zones(p,q,('board',));gold_delta=1;expect=deepcopy(before['pool']);expect[u['pool_id']]+=u['pool_count'];eq(after['pool'],expect,'actual sale restores native entitlement');eq(q.get(LEDGER),p.get(LEDGER),'source sale preserves exact owner ledger');eq(q.get(DISCOUNT),p.get(DISCOUNT),'sale preserves actual discounts')
    elif role=='fortify':
        u=indexed(p,'hand',cmd);eq(u['card_id'],FORT,'genuine acquired Fortify cast');eq(cmd['target_zone'],'board','native Fortify target zone');target=integer(cmd['target'],'Fortify target');need(target<len(p['board']),'Fortify target exists');need(p['board'][target]['card_id']==CYCLE,'Fortify independently targets Cyclone');expected=deepcopy(p['board']);t=expected[target];t['health']+=3;t['max_health']+=3
        for key in ('keywords','permanent_keywords'):
            if 'taunt' not in t[key]:t[key].append('taunt')
        eq(q['board'],expected,'complete exact permanent Fortify board change');eq(q['hand'],[x for x in p['hand'] if x['uid']!=u['uid']],'genuine Fortify consumed once');eq(q['shop'],p['shop'],'Fortify shop exclusion');eq(after['spell_pool'],before['spell_pool'],'no second spell stock return')
    elif role in ('roll_before','roll_after'):
        eq(p['free_rolls'],0,'real paid roll, not free refresh');gold_delta=-1;plain_zones(p,q,('shop',));eq(q.get(LEDGER),p.get(LEDGER),'future refresh preserves owner ledger');old={u['uid'] for u in p['shop']};need(old.isdisjoint(u['uid'] for u in q['shop']),'all refreshed offers have genuinely new UIDs');a,h=vector;check_shop(q,bases,3*a,3*h,before['state']['round'],True);grants=event_rows(events,'ashen_shop_future_offer_buff',player=0);eq(len(grants),len(event_rows(events,'ashen_shop_future_offer_buff')),'no foreign future-offer grant');minions=[u for u in q['shop'] if u.get('kind','minion')=='minion'];eq(len(grants),len(minions),'complete future-offer event domain')
        for u in minions:
            rows=[e for e in grants if e.get('target_uid')==u['uid']];need(len(rows)==1,'one future grant per actual UID')
            for k,val in {'attack':3*a,'health':3*h,'round':before['state']['round']}.items():eq(rows[0][k],val,'future grant '+k)
        if role=='roll_after':need(source_uid not in {u['uid'] for u in p['board']+q['board']},'future bonus persists after actual source sale')
    elif role=='freeze':plain_zones(p,q);eq(p['frozen'],False,'before native freeze');eq(q['frozen'],True,'after native freeze');eq(q.get(LEDGER),p.get(LEDGER),'freeze preserves ledger')
    else:raise ValidationError('unreviewed active role '+role)
    eq(q['gold']-p['gold'],gold_delta,'exact actual Gold payment/income for '+role);return after

def u_is_golden(p,cmd):return indexed(p,'hand',cmd).get('golden') is True
def expired_unit(u,a,h):
    item=deepcopy(u);ma,mh,_=marks(item);eq((ma,mh),(a,h),'entire earned temporary vector before expiry');item['attack']-=a;item['health']-=h;item['max_health']-=h;item['temporary_buffs']=[x for x in item['temporary_buffs'] if MARK not in x]
    for k in ('spell_triggers','blood_gems_received_turn','spellcraft_kept','reborn_summon_used_turn'):
        if k in item:item[k]=0
    for k in ('limited_turn_merge_blocked_round','reborn_summon_merge_held'):item.pop(k,None)
    return item

def native_receipts(report,context,case,fp):
    docs=req(req(context,'native_save_documents','context'),case,'native_save_documents');meta=req(req(context,'native_save_metadata','context'),case,'native_save_metadata');eq(set_as_list(docs),sorted(STAGES),'all four actual native stages required');checks=Counter((r['scenario'],r['label']) for r in report['checks'] if r.get('passed') is True)
    for stage in STAGES:
        snapshot(req(docs,stage,case),fp,case+'/'+stage);rows=[r for r in report['loads'] if r.get('scenario')==case and r.get('label')==stage];need(len(rows)==1,'exact native original save receipt '+case+'/'+stage);r=rows[0];m=req(meta,stage,'native metadata');eq(r.get('native_original'),True,'native original flag');eq(r.get('fields'),list(FIELDS),'full native field receipt')
        for key in ('path','sha256','bytes'):eq(req(r,key,'load receipt'),req(m,key,'verified actual save metadata'),'actual save '+key)
        need(re.fullmatch('[0-9a-f]{64}',m['sha256']) is not None,'actual save SHA required');integer(m['bytes'],'save bytes',1)
        for label in ('native save','saving does not mutate engine','fresh native load')+tuple('native roundtrip '+f for f in FIELDS):eq(checks[(case,stage+': '+label)],1,'one genuine load comparison receipt '+stage+'/'+label)
    eq(docs['active'],docs['active_replay'],'complete all-thirteen-field native replay');eq(meta['active']['sha256'],meta['active_replay']['sha256'],'byte-identical native active/replay hashes');eq(meta['active']['bytes'],meta['active_replay']['bytes'],'byte-identical native active/replay size');return docs

def set_as_list(d):need(isinstance(d,dict),'stage map object required');return sorted(d)

def validate_case(report,context,case,golden,fp):
    docs=native_receipts(report,context,case,fp);setup=docs['setup'];active=docs['active'];room_scope(setup);source_uid,bases=fixture_facts(setup,golden);vector=(2,4) if golden else (1,2);roles=list(ROLES);types=list(TYPES)
    if golden:roles[1:1]=['reward','pouch'];types[1:1]=['play','play']
    n=len(roles);eq(n,20 if golden else 18,'independently fixed tape length');evidence=[x for x in report['case_evidence'] if x['case']==case];need(len(evidence)==1,'exact case evidence row');e=evidence[0];eq(e['source_uid'],source_uid,'actual source UID evidence');eq(e['golden'],golden,'case variant');eq(e['round'],setup['state']['round'],'case actual round');eq(e['current_vector'],[3*vector[0],3*vector[1]],'exact earned case vector');eq(e['native_save_stages'],list(STAGES),'case stage list');eq(e['replay_commands'],n,'fixed active tape count')
    replays=[x for x in report['replays'] if x['scenario']==case];need(len(replays)==1,'one replay record');rp=replays[0];tape=rp['commands'];eq([x['command']['type'] for x in tape],types,'independent exact active tape types');eq(rp['fields'],list(FIELDS),'all13 replay fields');eq(rp['byte_identical'],True,'byte identity receipt')
    for stage,key in [('setup','setup'),('active','active'),('active_replay','replayed')]:eq(rp[key],context['native_save_metadata'][case][stage]['path'],'replay uses actual native path')
    rows=[x for x in report['commands'] if x['scenario']==case and ('before_snapshot' in x or 'after_snapshot' in x)];need(len(rows)==2*n+3,'missing/excess complete lifecycle/replay/expiry command snapshots');original,replayed,expiry=rows[:n],rows[n:2*n],rows[2*n:];eq([x['replay'] for x in rows],[False]*n+[True]*n+[False]*3,'once-only replay observation order')
    for seq,again in ((original,False),(replayed,True)):
        previous=setup
        for step,row,role,kind in zip(tape,seq,roles,types):
            eq(row['command'],step['command'],'replay/original exact command dictionary');eq(row['player'],step['player'],'replay/original player');eq(step['expected_ok'],True,'no silently permitted rejection');eq(row['label'],('replay: ' if again else '')+step['label'],'exact native tape label/order');eq(row['command']['type'],kind,'fixed command type');previous=active_step(row,role,fp,source_uid,bases,vector,previous)
        eq(previous,active,'full trace terminal equals actual active native save')
    for a,b in zip(original,replayed):eq(a['before_snapshot'],b['before_snapshot'],'complete deterministic before snapshot replay');eq(a['after_snapshot'],b['after_snapshot'],'complete deterministic after snapshot replay')
    eq(active['events'][:len(setup['events'])],setup['events'],'setup/active event prefix');new=active['events'][len(setup['events']):];packets=event_rows(new,'bulk_hero_damage_observed',player=0);discounts=event_rows(new,'next_spell_discount_granted',player=0);eq(len(packets),3,'actual exactly three packets');need(len({p['event_id'] for p in packets})==3,'three distinct native packet IDs');eq(len(discounts),3,'actual exactly three discount grants');eq(e['packet_receipts'],packets,'case actual packet records');eq(e['discount_receipts'],discounts,'case actual discount records');eq([e['damage_packets'],e['discount_grants'],e['future_rolls']],[3,3,sum(x['command']['type']=='roll' for x in original)],'actual semantic count bindings');eq(e['future_rolls'],2,'exactly two actual paid future refreshes');eq([x['command']['type'] for x in expiry],['end_turn','end_turn','roll'],'exact expiry command sequence');eq([x['player'] for x in expiry],[1,0,0],'real ready/opponent/refresh sequence');prev=active
    for row in expiry:_,prev,_=common_command(row,fp,prev)
    eq(prev,docs['expired'],'native expired save equals actual post-refresh state');last=snapshot(req(e,'last_recruit_snapshot','case evidence'),fp,'actual next recruit observation');eq(last,expiry[1]['after_snapshot'],'actual after-combat next recruit observation');eq(last,expiry[2]['before_snapshot'],'same frozen snapshot before next-turn refresh');eq(last['state']['round'],setup['state']['round']+1,'genuine next recruit round');p,q=owner(active),owner(last);eq(p['frozen'],True,'actual active frozen shop');eq(q['frozen'],False,'native freeze resets after round');ledger=q.get(LEDGER);need(ledger is None or ledger['round']<last['state']['round'],'owner ledger must expire logically, not be current/future');recipients=req(e,'recipients','case evidence');eq(set_as_list(recipients),['board','hand','shop'],'all distinct expiry zones declared');need(len(set(recipients.values()))==3,'three genuinely distinct expiry recipients')
    for z,uid in recipients.items():old=pick(zone(p,z),uid,'active '+z);now=pick(zone(q,z),uid,'next recruit '+z);eq(now,expired_unit(old,3*vector[0],3*vector[1]),'complete '+z+' recipient expiry including permanent fields')
    cycle=pick(q['board'],recipients['board'],'permanent recipient');eq([cycle['card_id'],cycle['attack'],cycle['health'],cycle['max_health'],cycle['keywords'],cycle['permanent_keywords']],[CYCLE,2,4,4,['divine_shield','windfury','taunt'],['divine_shield','windfury','taunt']],'independent permanent Fortify survives exact temporary expiry');before,after=expiry[2]['before_snapshot'],expiry[2]['after_snapshot'];eq(owner(before)['free_rolls'],0,'next-turn roll is paid');eq(owner(after)['gold'],owner(before)['gold']-1,'actual next-turn roll payment');plain_zones(owner(before),owner(after),('shop',));check_shop(owner(after),bases,0,0,after['state']['round'],True);need(not event_rows(after['events'][len(before['events']):],'ashen_shop_future_offer_buff'),'no stale next-turn future grants')
    return {'case':case,'active_commands':n,'replayed_commands':n,'expiry_commands':3,'packets':3,'discounts':3,'future_rolls':2,'native_saves':4,'persisted_fields':13}

def validate(report,contract,context):
    """Return audited facts or raise ValidationError; never mutate any input."""
    try:
        need(isinstance(report,dict) and isinstance(contract,dict) and isinstance(context,dict),'report, contract and authenticated context are required objects');eq(report.get('observation_schema_version'),2,'v2 native observation receipts required; v1 labels are not substituted');eq(report.get('status'),'passed_narrow_rebuild_v2_only','narrow v2 status only');eq(report.get('failures'),0,'no native assertion failures');eq(report.get('failure_snapshots'),[],'no native failure evidence');eq(report.get('completed_cases'),list(CASES),'two exact ordered cases');eq(report.get('required_cases'),list(CASES),'two declared cases');fp=req(context,'execution_fingerprint','context');need(isinstance(fp,str) and re.fullmatch('[0-9a-f]{64}',fp),'fresh authenticated fingerprint required');eq(report['execution_fingerprint'],fp,'actual report fingerprint');seal=req(context,'source_manifest_sha256','context');need(isinstance(seal,str) and re.fullmatch('[0-9a-f]{64}',seal),'separate sealed source context required');eq(context['save_fields'],list(FIELDS),'runner native field contract')
        for key in ('checks','commands','loads','combats'):eq(report['counts'][key],len(req(report,key,'report')),'actual report count '+key)
        eq(report['counts']['cases'],2,'actual case count');eq(len(report['loads']),8,'eight actual original saves');eq(len(report['case_evidence']),2,'exact case evidence domain');eq(len(report['replays']),2,'exact replay domain');need(all(x.get('passed') is True for x in report['checks']),'all original native assertions must pass');mode=contract.get('mode',contract);eq(mode.get('expected_status'),'passed_narrow_rebuild_v2_only','validator bound only to v2 contract');need('mixed received-damage rooms' in report['held'] and 'full identity and whole patch acceptance' in report['held'],'sourceguard/whole-identity holds must remain explicit');results=[validate_case(report,context,c,bool(i),fp) for i,c in enumerate(CASES)]
        return {'status':'passed_pure_data_postvalidation_narrow_only','source_manifest_sha256':seal,'execution_fingerprint':fp,'cases':results,'claims_excluded':['new native execution','historical acceptance','synthetic source-guard acceptance','received-listener capability','full identity or whole patch acceptance']}
    except ValidationError:raise
    except (KeyError,TypeError,IndexError,ValueError,OverflowError) as exc:raise ValidationError('missing or malformed actual source/fixture/observation evidence: '+str(exc)) from exc
