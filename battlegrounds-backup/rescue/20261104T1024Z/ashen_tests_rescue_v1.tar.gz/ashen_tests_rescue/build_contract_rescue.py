"""Reconstruct recorded contracts; old absolute paths remain provenance only."""
from pathlib import Path
import json,hashlib
H=Path(__file__).resolve().parent
OLD=Path('/workspace/shared/recovery_restart_20261104T0750Z/rebuild_ashen_tests')
s=(H/'ashen_lifecycle_public.gd').read_text();fields=json.loads(s.split('const FIELDS = ',1)[1].split('\n',1)[0]);cases=json.loads(s.split('const CASES = ',1)[1].split('\n',1)[0])
base='''entire reachable room graph is inactive and error-free
received-listener capability is not expanded
ordinary RoomConfig validation accepts bounded room
ordinary Game start accepts validated room
real Patchwerk starts armor-zero with empty boards
frozen setup offers survive empty-board combat with ten real Gold
genuine source retains native body and stock entitlement
setup contains only four genuine held fixtures and no earned ledgers
source played before Weaver so no unintended initial damage grant
two distinct genuinely bought recipients cover hand and board
purchase and play preserve complete earned temporary vectors
three genuine discount entries precede Fortify purchase
zero-cost Fortify moves real UID and releases reservation once
one qualifying purchase consumes all three genuine one-purchase discounts
actual Fortify is exact +0/+3 and permanent Taunt, with every other field preserved
source sale preserves earned ledger and every existing recipient grant
third distinct genuine recipient covers frozen shop
active state has real freeze, absent source and retained turn ledger
active native save/load preserves full state with no duplicate grants
replay loads original setup into another fresh Game
replay setup preserves all thirteen persisted fields
active and replay original native saves are byte-identical
next turn expires owner Ashen ledger after source sale
Fortify permanent 2/4 Taunt survives together with native Shield and Windfury
exact active-stage semantic counts from actual native events and command tape'''.splitlines()
for n in range(1,4):
 for suffix in ['real ordinary Demon and armor-zero packet precondition','one real health-loss packet before rewind','native same-packet rewind and source provenance','grant domain equals actual minion offers','exact accumulated owner ledger','independent discount receipt and ledger count','unrelated owner completely unchanged','unrelated board and Ashen source excluded','Weaver receives only its independent permanent effect','nonvacuous native minion and spell domains']:base.append(f'trigger {n}: {suffix}')
for label in ['future offers before source sale','future offers after source sale']:
 for suffix in ['actual paid refresh precondition','complete future grant receipt domain','nonvacuous native minion and spell domains','repeated read-only inspection never double-applies']:base.append(f'{label}: {suffix}')
for zone in ['hand','board','shop']:
 base += [f'expiry {zone}: original recipient UID retained',f'expiry {zone}: exact temporary vector and metadata removed']
 for field in ['card_id','pool_id','pool_count','keywords','permanent_keywords','effects']:base.append(f'expiry {zone}: native permanent field preserved {field}')
for field in fields:base.append('deterministic public-command replay '+field)
for stage in ['setup','active','active_replay','expired']:
 for suffix in ['native save path is fresh','native save','saving does not mutate engine','fresh native load','exact thirteen-field snapshot domain']:base.append(stage+': '+suffix)
 for field in fields:base.append(stage+': native roundtrip '+field)
base.append('fresh next-turn shop has no previous-turn bonus: nonvacuous native minion and spell domains')
golden=['genuine golden play creates actual tier-five triple reward','true-empty configured tier produces one native gold pouch','native compensation pouch is exact three Gold','actual golden reward pays exactly three Gold once']
required={'source_contracts':['fresh candidate Catalog loads without errors','actual catalog fingerprint equals independently reviewed lane result','exact latest native Ashen body and program BG32_873','exact latest native Ashen body and program BG32_873_G','independent Cyclone 2/1 native Shield and Windfury fixture','independent Doom Prophet 2/1 Demon Naga and one-discount fixture']}
required[cases[0]]=base;required[cases[1]]=base+golden+['all two declared lifecycle cases completed','exactly eight fresh original native saves and roundtrips','one complete deterministic native replay per case']
mode={
 'kind':'public','script':'res://tests_rebuild/ashen_lifecycle_public.gd',
 'report_filename':'ashen_lifecycle_public_report.json','terminal':'ASHEN_REBUILD_PUBLIC_TERMINAL',
 'user_args':['--reviewed-ashen-rebuild','--expected-fingerprint={FRESH_REVIEWED_FINGERPRINT}'],
 'expected_status':'passed_narrow_rebuild_only','result_status':'fresh_narrow_ashen_lifecycle_only',
 'expected_report_fields':['schema_version','status','execution_fingerprint','checks','commands','loads','replays','combats','failure_snapshots','completed_cases','required_cases','case_evidence','scope','held','failures','counts'],
 'expected_counts':{'checks':{'minimum':400,'maximum':16000},'commands':{'minimum':82,'maximum':1800},'loads':8,'combats':{'minimum':4,'maximum':850}},
 'expected_checks':[],'required_checks_by_case':required,
 'allowed_check_scenarios':['source_contracts']+cases,'completed_cases_field':'completed_cases','expected_cases':cases,
 'expected_loads':[{'scenario':case,'label':stage} for case in cases for stage in ['setup','active','active_replay','expired']],
 'combat_replay_cases':[],'save_filename_glob':'ashen_rebuild_*.json','allowed_cleanup_resource_counts':[],
 'semantic_counts':[{'path':['case_evidence'],'measure':'length','expected':2},{'path':['replays'],'measure':'length','expected':2}]+[{'path':['case_evidence',i,k],'measure':'value','expected':val} for i in range(2) for k,val in [('damage_packets',3),('discount_grants',3),('future_rolls',2)]],
 'acquisition_limits':{'tier_upgrade_iterations':30,'acquire_iterations_per_identity':60,'true_triple_third_offer_iterations':60,'ready_shop_iterations':90,'native_room_max_rounds':100,'setup_boards':'both empty, actual combat tie, no resource mutation','normal_acquire_calls':4,'golden_acquire_calls':5,'golden_third_offer_searches':1,'exhaustion':'fail_no_credit'},
 'expected_rejected_commands':[],
 'command_check_suffixes':{'ok':[': expected command result',': no engine error phase',': one real command receipt; no bot actions',': complete native stock conservation'],'rejected':[': expected command result',': explicit error returned',': rejected command leaves every persisted field unchanged']},
 'report_assertions':[{'path':['case_evidence',i,'current_vector'],'expected':val} for i,val in enumerate([[3,6],[6,12]])]+[{'path':['case_evidence',i,'golden'],'expected':bool(i)} for i in range(2)]
}
contract={
 'status':'preparation_only_not_execution_authority','new_reconstruction':True,'historical_acceptance_carried':False,
 'candidate_manifest_sha256':'6aec556bacffa1d2da5f6cc671a6f14291e6b4f61629746cf92a7652f632311a',
 'reconstruction_notes_sha256':'4109fe6aa12e0ff080cc6ab7c0dec3907ff9617edb634ea0a68aa9fef4ee8f10',
 'payload_files':{'tests_rebuild/ashen_lifecycle_public.gd':{'path':str(OLD/'ashen_lifecycle_public.gd'),'sha256':hashlib.sha256((H/'ashen_lifecycle_public.gd').read_bytes()).hexdigest()}},'mode':mode,
 'unresolved_bindings':['Final combined candidate source seal and independent source review','Final harness independent review and exact payload binding','Fresh actual Catalog fingerprint and independently reviewed output','Fingerprint placeholder must be bound by verified runner injection, not a remembered value','Per-lane parent release; no engine has been run','Cleanup policy review: default strict diagnostic-clean; no historical resource count copied'],
 'engine_started':False,'native_save_count':0,'gameplay_credit':0
}
p=H/'harness_contract_v1.reference.json';p.write_text(json.dumps(contract,ensure_ascii=False,indent=2)+'\n')
c=json.loads(p.read_text());c['status']='observation_revision_v2_preparation_only';c['parent_harness_sha256']=hashlib.sha256((H/'ashen_lifecycle_public.gd').read_bytes()).hexdigest();c['payload_files']={'tests_rebuild/ashen_lifecycle_public_v2.gd':{'path':str(OLD/'harness_revision_v2/ashen_lifecycle_public_v2.gd'),'sha256':hashlib.sha256((H/'ashen_lifecycle_public_v2.gd').read_bytes()).hexdigest()}}
m=c['mode'];m['script']='res://tests_rebuild/ashen_lifecycle_public_v2.gd';m['report_filename']='ashen_lifecycle_public_report_v2.json';m['terminal']='ASHEN_REBUILD_V2_PUBLIC_TERMINAL';m['expected_status']='passed_narrow_rebuild_v2_only';m['result_status']='fresh_narrow_ashen_lifecycle_v2_only';m['save_filename_glob']='ashen_rebuild_v2_*.json';m['expected_report_fields'].append('observation_schema_version');m['report_assertions'].append({'path':['observation_schema_version'],'expected':2});c['unresolved_bindings'].append('Independent audit and separate seal of observation-only v2 plus actually invoked postvalidator')
(H/'harness_contract_v2.reference.json').write_text(json.dumps(c,ensure_ascii=False,indent=2)+'\n')
results={}
for name,ref in [('harness_contract_v1.reference.json','97dac26bc143cffce50c19e52b8f133fe0a3461f9fd59f3a96c852ef48891bbe'),('harness_contract_v2.reference.json','637ded16fc1b72e466ac2da2fad0003fd1e5671be754cc55c4d70090fe1e937d')]:
 p=H/name;actual=hashlib.sha256(p.read_bytes()).hexdigest();results[name]={'bytes':p.stat().st_size,'sha256':actual,'reference_sha256':ref,'measured_match':actual==ref,'old_absolute_paths':'provenance only; not a launch contract'};print(name,p.stat().st_size,actual,'MATCH',actual==ref)
(H/'CONTRACT_RECONSTRUCTION_RESULTS.json').write_text(json.dumps(results,indent=2)+'\n')
