"""Build only the ten-file source/provider delta. No engine or runtime copy."""
from common import *
import copy
import xml.etree.ElementTree as ET

assert not (C/'SOURCE_DELTA_SEAL.json').exists(),'Already frozen: create a new revision instead.'
mapping,design=validate_inputs()
def read(name):
    p=B/name
    assert sha(p)==mapping[name],name
    return p.read_text()
def write(name,value):
    p=D/name;p.parent.mkdir(parents=True,exist_ok=True)
    assert not p.is_symlink()
    p.write_bytes(value if isinstance(value,bytes) else value.encode())

raw={c['id']:c for c in json.loads(read('data/catalog_raw.json'))['cards']}
compiled={c['id']:c for c in json.loads(read('data/catalog.json'))['cards']}
four=json.loads(read(CONTRACT))
child_contract=json.loads(read(CHILD_CONTRACT))
source=read('core/spell_cast_listeners.gd')
portrait=read('core/azerite_portrait_sources.gd')
dark=read('core/dark_gift_qualification.gd')
programs=constant(source,'EXACT_EFFECTS')
children=constant(portrait,'CHILDREN')
child_programs=constant(portrait,'CHILD_PROGRAMS')
facts=constant(dark,'FACTS')
old_preimages=json.loads((DESIGN/'COMPLETE_OLD_PREIMAGES.json').read_text())
assert four['source_ids']==FOUR_IDS
historical_proofs={CONTRACT:CONTRACT_SHA,CHILD_CONTRACT:CHILD_CONTRACT_SHA}
for identity in FOUR_IDS:
    row=four['records'][identity]
    name='research/tavern_cast_four/'+row['entity_file']
    assert sha(B/name)==row['entity_sha256']==mapping[name]
    historical_proofs[name]=row['entity_sha256']
rows=[];entities={};prefix='research/patch_3702_azerite'
xml=XML.read_bytes();html=HTML.read_bytes()
for index,identity in enumerate(IDS):
    m=re.search(rb'<Entity\b[^>]*CardID="'+identity.encode()+rb'"[^>]*>.*?</Entity>',xml,re.S)
    assert m
    body=m[0];native=ET.fromstring(body)
    tags={t.attrib['name']:t.attrib.get('value') for t in native.findall('Tag')}
    assert native.attrib=={'CardID':identity,'ID':str(107939+index),'version':'2'}
    assert [int(tags[k]) for k in ['ATK','HEALTH','TECH_LEVEL','TAG_SCRIPT_DATA_NUM_1','TAG_SCRIPT_DATA_NUM_2']]==([6,6,5,3,3] if index==0 else [12,12,5,3,3])
    assert tags['CARDTYPE']=='4' and tags['CARDRACE']=='18'
    assert tags['BACON_TRIPLE_UPGRADE_MINION_ID' if index==0 else 'BACON_TRIPLED_BASE_MINION_ID']==str(107940 if index==0 else 107939)
    assert (tags.get('PREMIUM') is None and tags['IS_BACON_POOL_MINION']=='1') if index==0 else tags['PREMIUM']=='1'
    assert digest(body)==['e9b02b187c58aa25d31495e238e18c579d0b8396d08b485dde679c167dd04493','1c0caa7ca3e69051cf283a88905bc47d6f2250430240bfc097f0a028481e6ffd'][index]
    assert body==(DESIGN/(identity+'.native.xml')).read_bytes()
    zh=native.find("Tag[@name='CARDTEXT']/zhCN").text.format(3,3)
    en=native.find("Tag[@name='CARDTEXT']/enUS").text.format(3,3)
    assert ('twice' in en)==bool(index) and ('触发两次' in zh)==bool(index)
    repeat=2 if index else 1
    native_path=prefix+'/native/'+identity+'.xml';write(native_path,body)
    entities[identity]={'path':native_path,'sha256':digest(body),'bytes':len(body),'byte_range':[m.start(),m.end()],'attributes':native.attrib,'tags':tags,'rendered_zhCN':zh,'rendered_enUS':en,'literal_repeat':repeat}
    base=dict(copy.deepcopy(raw[identity]),**copy.deepcopy(compiled[identity]))
    assert len(raw[identity])==49 and len(compiled[identity])==10 and len(base)==55
    assert raw[identity]==old_preimages[identity]['complete_raw']==four['records'][identity]['source_row']
    assert compiled[identity]==old_preimages[identity]['complete_compiled'] and base==old_preimages[identity]['complete_merged']
    expected_old=[{'type':'on_spell_cast_buff','spell_filter':'tavern','scope':'shop','tribe':'元素','attack':4,'health':3,'repeat':repeat}]
    assert base['effects']==programs[identity]==child_programs[identity]==facts[identity]['effects']==expected_old
    assert children[identity]==child_contract['contracts'][identity]
    assert all(base[k]==v for k,v in children[identity].items())
    effective_effect=copy.deepcopy(expected_old);effective_effect[0]['attack']=3
    fields=copy.deepcopy(base['fields']);fields.update(attack=int(tags['ATK']),health=int(tags['HEALTH']),text=zh,updated_at='2026-11-03 Patch37.0.2.256589')
    field_status=copy.deepcopy(base['field_status'])
    for k in ['attack','health']:
        field_status[k].update(value=int(tags['ATK' if k=='attack' else 'HEALTH']),verification='confirmed_independent_37_0_2_native_entity',value_source=native_path)
    marker={'revision':REV,'client_version':'37.0.2.256589','native_commit':'31b034c26f24b8a66ece845ffd03c1ca397b9a02','native_entity_version':2,'native_path':native_path,'native_sha256':digest(body),'literal_repeat':repeat}
    effective={'attack':int(tags['ATK']),'health':int(tags['HEALTH']),'text':zh,'effects':effective_effect,'coverage_text_sha256':digest(zh),'fields':fields,'field_status':field_status,'patch_3702_azerite':marker}
    rows.append({'id':identity,'expected_raw':copy.deepcopy(raw[identity]),'expected_compiled':copy.deepcopy(compiled[identity]),'expected_baseline':base,'effective_fields':effective,'portrait_expected_baseline':copy.deepcopy(children[identity])})
    # The source table uses multiline JSON formatting. Replace only this row's
    # numeric program, not the whole constant or any listener writer code.
    pattern=r'(  "'+re.escape(identity)+r'": )(?P<program>\[.*?\n  \])'
    match=re.search(pattern,source,re.S);assert match and json.loads(match['program'])==expected_old
    revised=match['program'].replace('"attack": 4','"attack": 3')
    assert revised!=match['program'] and revised.count('"repeat": '+str(repeat))==1
    source=source[:match.start('program')]+revised+source[match.end('program'):]
    needle='"'+identity+'":'+enc(expected_old)
    # CHILDREN remains an exact historical literal; only CHILD_PROGRAMS changes.
    line=re.search(r'^const CHILD_PROGRAMS: Dictionary=.*$',portrait,re.M)
    assert line and line[0].count(needle)==1
    replacement=line[0].replace(needle,'"'+identity+'":'+enc(effective_effect))
    portrait=portrait[:line.start()]+replacement+portrait[line.end():]
    assert dark.count(enc(expected_old))==1
    dark=dark.replace(enc(expected_old),enc(effective_effect))

source=source.replace('extends RefCounted\n','extends RefCounted\nconst Patch3702Azerite=preload("res://core/patch_3702_azerite_sources.gd")\n',1)
needle='static func _tavern_four_row_error(card: Dictionary, identity: String, contract: Dictionary) -> String:\n'
assert source.count(needle)==1
source=source.replace(needle,needle+'\tif Patch3702Azerite.accepts_id(identity): return Patch3702Azerite.tavern_row_error(card,identity,contract)\n',1)
write('core/spell_cast_listeners.gd',source)
portrait=portrait.replace('extends RefCounted\n','extends RefCounted\nconst Patch3702Azerite=preload("res://core/patch_3702_azerite_sources.gd")\n',1)
needle='\tif identity not in CHILD_IDS or card.get("supported")!=true: return "azerite_portrait_child_unavailable"\n'
assert portrait.count(needle)==1
portrait=portrait.replace(needle,needle+'\tif Patch3702Azerite.accepts_id(identity): return Patch3702Azerite.portrait_child_error(card,CHILDREN[identity])\n',1)
write('core/azerite_portrait_sources.gd',portrait);write('core/dark_gift_qualification.gd',dark)

excerpt=re.search(rb'<p>Living Azerite</p>\s*<ul>.*?</ul>',html,re.S);assert excerpt
excerpt_path=prefix+'/official_patch_azerite_excerpt.html';write(excerpt_path,excerpt[0])
overlay_path='data/patch_3702_azerite_overlay.json'
dump(D/overlay_path,{'revision':REV,'status':'source_candidate_pending_fresh_acceptance','full_latest_patch':False,'historical_acceptance_credit':0,'cards':rows,'scope':'Two Living Azerite source identities only. Golden preserves two independent 3/3 repeats. Raw, compiled and merged old rows are separately authenticated; historical four-way and portrait contracts remain unchanged.'})
dependencies=set(historical_proofs)|{'core/catalog.gd','core/spell_cast_listeners.gd','core/azerite_portrait_sources.gd','core/dark_gift_qualification.gd','core/azerite_portrait_host.gd','core/sand_swirler_sources.gd','core/sand_swirler_cast_host.gd','core/native_spell_listener_stock.gd','core/czarina_portrait_sources.gd','core/game.gd','core/recruit_extensions.gd','core/factory_line_sources.gd','core/dark_gift_sources.gd','core/damage_listener_room.gd','core/lucky_egg_sources.gd','data/catalog_raw.json','data/catalog.json','data/source_catalog/minions.json','data/catalog_value_overrides.json','data/current_scope_manifest.json','data/tribe_pool_requirements.json','data/patch_3702_membership.json','research/lucky_egg_rebuilt/target_contracts.json','research/azerite_portrait/contract.json'}
for name in dependencies:assert sha(B/name)==mapping[name]
assert not any(x['id'] in IDS for x in json.loads(read('data/catalog_value_overrides.json'))['overrides'])
egg=json.loads(read('research/lucky_egg_rebuilt/target_contracts.json'));assert all(i not in egg['targets'] and i not in egg['pairs'] and i not in egg['pairs'].values() for i in IDS)
assert all(i not in read('core/damage_listener_room.gd') for i in IDS)
evidence_path=prefix+'/source_evidence.json'
dump(D/evidence_path,{'schema_version':1,'revision':REV,'status':'source_only_no_gameplay_or_provider_acceptance','baseline':str(B),'baseline_map':{'path':str(BASE_MAP),'sha256':BASE_MAP_SHA},'design':{'report_sha256':sha(DESIGN/'LIVING_AZERITE_DESIGN_REPORT.json'),'addendum_sha256':sha(DESIGN/'LIVING_AZERITE_DESIGN_ADDENDUM.json'),'complete_preimages_sha256':sha(DESIGN/'COMPLETE_OLD_PREIMAGES.json')},'native':{'url':'https://raw.githubusercontent.com/HearthSim/hsdata/31b034c26f24b8a66ece845ffd03c1ca397b9a02/CardDefs.Bacon.xml','path':str(XML),'sha256':sha(XML),'client_version':'37.0.2.256589','commit':'31b034c26f24b8a66ece845ffd03c1ca397b9a02','entities':entities},'official':{'url':'https://hearthstone.blizzard.com/en-us/news/24307311/3702-patch-notes','path':str(HTML),'sha256':sha(HTML),'excerpt_path':excerpt_path,'excerpt_sha256':digest(excerpt[0])},'historical_proofs':historical_proofs,'baseline_hashes':{p:mapping[p] for p in sorted(dependencies)},'dependency_decisions':{'four_way_source':'The original full contract and all four old native entities stay pinned. Only Azerite rows use the version adapter; Czarina old validation remains byte-identical. Old pre-admission support/default_pool/pool_supported gates stay exact.','portrait_child':'Historical CHILDREN stays byte-identical and is authenticated before only attack/health/text/effects substitutions. CHILD_PROGRAMS changes only the two attack4->3 values; repeat1/2 remains. Parent portrait source declarations and all host gates remain untouched.','generic_source_guard':'Immutable identity and bounded effective fields only. It does not authorize or freeze later stock policy changes.','unchanged_writers':'Actual hand-cast, source order, full-repeat preflight, per-repeat add_shop_bonus, future-offer inheritance and native stock writers are untouched.','unchanged_holds':'No portrait or Sand scope expansion; multi-portrait, unknown origin, inherited/transformed and automatic-domain holds stay unchanged.','historical_labels':'Unchanged host POLICY/inactive metadata may describe old4/3. Active host reads effect amounts. This source slice does not claim that held composition is current-engine accepted.','other_providers':'No damage registration or Lucky Egg target pin exists for this pair. Factory Line and separate Dark Gift source records pin unchanged identities/qualifications.'},'acceptance':{'engine_executed':False,'historical_credit':0,'new_complete_identity_credit':0,'full_latest_patch':False,'first_domain':'Plain unmodified Game, real hand Tavern spell, no portrait or Sand Swirler. Any observer is supplemental only.','unverified':['native parsing','plain public lifecycle','golden two writer events','native13-field save/load','replay','portrait and Sand compositions','other automatic origins']}})
proof_paths=[overlay_path,evidence_path,excerpt_path]+[entities[i]['path'] for i in IDS]
proofs={p:sha(D/p) for p in proof_paths};proofs.update(historical_proofs)
module=read('core/patch_3702_twilight_sources.gd')
module=module[:module.index('static func lucky_egg_target_error')]
module=module.replace('partial-37.0.2-twilight-reconstructed-20261104-v1',REV).replace('BG36_703','BG28_707').replace('patch_3702_twilight','patch_3702_azerite').replace('partial_3702_twilight','partial_3702_azerite')
module=module.replace('["expected_baseline","effective_fields","lucky_egg_expected_baseline"]','["expected_raw","expected_compiled","expected_baseline","effective_fields","portrait_expected_baseline"]')
needle='static func apply_overlay(cards: Dictionary) -> String:\n'
assert module.count(needle)==1
raw_helper='''static func raw_error(card: Dictionary,path: String) -> String:
	var id: Variant=card.get("id")
	if not accepts_id(id): return ""
	var rows: Dictionary=packet()
	if rows.size()!=IDS.size(): return "partial_3702_azerite_missing_or_changed_packet"
	var field: String=""
	if path=="res://data/catalog_raw.json": field="expected_raw"
	elif path=="res://data/catalog.json": field="expected_compiled"
	else: return "partial_3702_azerite_unexpected_source:"+path
	return "" if same(card,rows[id][field]) else "partial_3702_azerite_changed_input_record:"+str(id)+":"+field
'''
module=module.replace(needle,raw_helper+needle,1)
module+='''static func tavern_row_error(card: Dictionary,identity: String,contract: Dictionary) -> String:
	if not accepts_id(identity) or not same(card.get("id"),identity): return "partial_3702_azerite_wrong_tavern_identity"
	var rows: Dictionary=packet()
	if rows.size()!=IDS.size(): return "partial_3702_azerite_missing_or_changed_packet"
	var original: Variant=normalize(JSON.parse_string(FileAccess.get_file_as_string("res://research/tavern_cast_four/source_contract.json")))
	if not original is Dictionary or not same(contract,original): return "partial_3702_azerite_changed_whole_tavern_contract"
	if not same(contract.records[identity].source_row,rows[identity].expected_raw): return "partial_3702_azerite_changed_tavern_old_row"
	var issue: String=source_error(card)
	if not issue.is_empty(): return issue
	var expected: Dictionary=rows[identity].expected_baseline.duplicate(true)
	expected.merge(rows[identity].effective_fields,true)
	# Keep the original pre-admission policy and every historical source field.
	for key in expected:
		if not card.has(key) or not same(card[key],expected[key]): return "partial_3702_azerite_changed_tavern_row:"+identity+":"+str(key)
	# These three policy annotations were already permitted by the old closure.
	for key in card:
		if not expected.has(key) and key not in ["pool_blocker","coverage_blocker","coverage_gate"]: return "partial_3702_azerite_unknown_tavern_field:"+str(key)
	if not same(card.get("supported"),true) or not same(card.get("default_pool"),false) or not same(card.get("pool_supported"),false): return "partial_3702_azerite_changed_tavern_policy"
	return ""
static func portrait_child_error(card: Dictionary,historical_expected: Dictionary) -> String:
	var id: Variant=card.get("id")
	if not accepts_id(id) or not same(card.get("supported"),true): return "partial_3702_azerite_wrong_portrait_child"
	var rows: Dictionary=packet()
	if rows.size()!=IDS.size(): return "partial_3702_azerite_missing_or_changed_packet"
	if not same(historical_expected,rows[id].portrait_expected_baseline): return "partial_3702_azerite_changed_historical_portrait_child"
	var issue: String=source_error(card)
	if not issue.is_empty(): return issue
	var expected: Dictionary=historical_expected.duplicate(true)
	for key in ["attack","health","text","effects"]: expected[key]=rows[id].effective_fields[key]
	for key in expected:
		if not card.has(key) or not same(card[key],expected[key]): return "partial_3702_azerite_changed_portrait_child:"+str(id)+":"+str(key)
	return ""
'''
module_path='core/patch_3702_azerite_sources.gd'
runtime=[module_path]+list(proofs)+['core/spell_cast_listeners.gd','core/azerite_portrait_sources.gd','core/dark_gift_qualification.gd']
module=re.sub(r'^const FILE_SHA256: Dictionary=.*$',lambda _:'const FILE_SHA256: Dictionary='+enc(proofs),module,flags=re.M)
module=re.sub(r'^const RUNTIME_PATHS: Array=.*$',lambda _:'const RUNTIME_PATHS: Array='+enc(runtime),module,flags=re.M)
write(module_path,module)
cat=read('core/catalog.gd');assert 'Patch3702Azerite' not in cat
cat=cat.replace('extends RefCounted\n','extends RefCounted\nconst Patch3702Azerite=preload("res://core/patch_3702_azerite_sources.gd")\n',1)
needle='\tvar fingerprints: PackedStringArray = []\n';assert cat.count(needle)==1
cat=cat.replace(needle,needle+'\tvar azerite_patch_issue: String=Patch3702Azerite.proof_error()\n\tif not azerite_patch_issue.is_empty():\n\t\tload_errors.append(azerite_patch_issue);return\n\tfor path in Patch3702Azerite.RUNTIME_PATHS:\n\t\tfingerprints.append(path+":"+FileAccess.get_file_as_string("res://"+path).sha256_text())\n',1)
needle='\t\t\t\tvar patch_3702_ashen_raw_issue: String=Patch3702Ashen.raw_error(raw_card,path)\n';assert cat.count(needle)==1
cat=cat.replace(needle,'\t\t\t\tvar azerite_raw_issue: String=Patch3702Azerite.raw_error(raw_card,path)\n\t\t\t\tif not azerite_raw_issue.is_empty():\n\t\t\t\t\tload_errors.append(azerite_raw_issue);return\n'+needle,1)
needle='\tvar twilight_overlay_issue: String=Patch3702Twilight.apply_overlay(cards)\n';assert cat.count(needle)==1
cat=cat.replace(needle,'\tvar azerite_overlay_issue: String=Patch3702Azerite.apply_overlay(cards)\n\tif not azerite_overlay_issue.is_empty():\n\t\tload_errors.append(azerite_overlay_issue);return\n'+needle,1)
needle='func _validate_effects(effects: Variant, depth: int = 0, source: Dictionary = {}) -> String:\n';assert cat.count(needle)==1
cat=cat.replace(needle,needle+'\tif Patch3702Azerite.accepts_id(source.get("id")):\n\t\tvar azerite_issue: String=Patch3702Azerite.source_error(source)\n\t\tif not azerite_issue.is_empty(): return azerite_issue\n\t\tif depth!=0 or not Patch3702Azerite.same(effects,source.get("effects")): return "partial_3702_azerite_whole_program_required"\n',1)
write('core/catalog.gd',cat)
changes={}
for p in sorted(D.rglob('*')):
    if not p.is_file():continue
    name=p.relative_to(D).as_posix();old=B/name
    changes[name]={'change':'modified' if old.exists() else 'new','before_sha256':sha(old) if old.exists() else None,'after_sha256':sha(p),'size':p.stat().st_size}
assert len(changes)==10 and sum(x['change']=='modified' for x in changes.values())==4
validate_inputs()
dump(C/'DELTA_MANIFEST.json',{'schema_version':1,'revision':REV,'status':'prepared_source_pending_author_checks_and_independent_review','baseline':str(B),'baseline_map_sha256':BASE_MAP_SHA,'output':str(D),'runtime_changes':changes,'modified_files':4,'new_files':6,'no_engine_run':True,'historical_test_credit':0,'native_acceptance_credit':0,'new_complete_identity_credit':0,'full_latest_patch':False,'first_acceptance_domain':'Plain real hand Tavern spell, no portrait or Sand; golden must remain two independent3/3 repeats.'})
dump(C/'expected_effective_azerite.json',{r['id']:dict(copy.deepcopy(r['expected_baseline']),**copy.deepcopy(r['effective_fields'])) for r in rows})
print(enc({'files':len(changes),'manifest_sha256':sha(C/'DELTA_MANIFEST.json'),'engine_executed':False}))
