"""Read-only source identities and serialization helpers for the Azerite slice."""
from pathlib import Path
import hashlib, json, re
B = Path('/workspace/scratch/dd4f12b08ec0/recovery_restart_20261104T0855Z/reconstructed_twilight_runtime')
C = Path('/tmp/azerite_candidate_20261104T1013Z')
D = C / 'candidate_delta'
PACKET = B.parent / 'early_source/verified_source_packet'
XML = PACKET / 'CardDefs.Bacon.37.0.2.256589.xml'
HTML = PACKET / 'official_patch_3702.html'
DESIGN = Path('/tmp/review_rescue_20261104T0906Z/living_azerite_proposal')
BASE_MAP = Path('/tmp/godot_second_loss_20261104T0854Z/RESTORED_FINAL_RUNTIME_MAP.json')
BASE_MAP_SHA = 'fd6f6caa7368926cdc0f3874ea976518526fa6917d16ec9380a8d9b0fadb52b5'
REV = 'partial-37.0.2-living-azerite-v1'
IDS = ['BG28_707', 'BG28_707_G']
FOUR_IDS = IDS + ['BG28_741', 'BG28_741_G']
CONTRACT = 'research/tavern_cast_four/source_contract.json'
CONTRACT_SHA = 'e2a513de4f6fba19f942ad0790bdc9bb46b577c27544290db2e1785d86104882'
CHILD_CONTRACT = 'research/azerite_portrait/child_contract.json'
CHILD_CONTRACT_SHA = '14d86b12e83e6eff1988db6020f8a3f9594ba52c859227922bff1efebb6724e9'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
digest = lambda v: hashlib.sha256(v.encode() if isinstance(v,str) else v).hexdigest()
enc = lambda v: json.dumps(v,ensure_ascii=False,separators=(',',':'))
def dump(path,value):
    path.parent.mkdir(parents=True,exist_ok=True)
    assert not path.is_symlink()
    path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
def constant(text,name):
    m=re.search(r'^const '+name+r'(?:\s*:\s*(?:Dictionary|Array))?\s*=\s*',text,re.M)
    assert m,name
    return json.JSONDecoder().raw_decode(text[m.end():])[0]
def validate_inputs():
    expected={XML:'103890e791863c743dd4b873e4cb789b711543ba839f923f677ebba6d672ff5a',HTML:'ec92b700fcce10ee8ebdec83b3b44e16e1d8c5f332a63f8ba1a1938e585a24b9',BASE_MAP:BASE_MAP_SHA,DESIGN/'LIVING_AZERITE_DESIGN_REPORT.json':'571b42c8f45794773c4d03d380ddddf136d8c599a7a3b35b073ed55e385d3a1f',DESIGN/'LIVING_AZERITE_DESIGN_ADDENDUM.json':'e209d06ba86963b705f844ee4fbdaa368f23769a188f1e9e047f6ef120abcb58',DESIGN/'COMPLETE_OLD_PREIMAGES.json':'5a3eaf33414f7794dac1fec0cc2b70833907bd7763e825df466bee125c692a7d',B/CONTRACT:CONTRACT_SHA,B/CHILD_CONTRACT:CHILD_CONTRACT_SHA}
    for p,h in expected.items(): assert p.is_file() and not p.is_symlink() and sha(p)==h,str(p)
    mapping=json.loads(BASE_MAP.read_text())['files']
    report=json.loads((DESIGN/'LIVING_AZERITE_DESIGN_REPORT.json').read_text())
    for row in report['gate_inventory']:
        name=row['file'];assert sha(B/name)==row['sha256']==mapping[name],name
    return mapping,report
