extends RefCounted
const Patch3702Azerite=preload("res://core/patch_3702_azerite_sources.gd")
## Committed player spell casts only. The host owns authenticity and LTR ordering.
const Mechanisms = preload("res://core/mechanism_effects.gd")
const BloodGems = preload("res://core/blood_gems.gd")
const RecruitShop = preload("res://core/recruit_extensions.gd")
const PrizeBuffs = preload("res://core/prize_buff_effects.gd")
const EXACT_EFFECTS: Dictionary = {
  "BG27_005": [
    {
      "type": "on_spell_cast_buff",
      "spell_filter": "tavern",
      "scope": "all",
      "attack": 1,
      "health": 0,
      "repeat": 1
    }
  ],
  "BG27_005_G": [
    {
      "type": "on_spell_cast_buff",
      "spell_filter": "tavern",
      "scope": "all",
      "attack": 1,
      "health": 0,
      "repeat": 2
    }
  ],
  "BG34_Giant_015": [
    {
      "type": "on_spell_cast_buff",
      "spell_filter": "tavern",
      "scope": "all",
      "attack": 2,
      "health": 2,
      "repeat": 1
    }
  ],
  "BG34_Giant_015_G": [
    {
      "type": "on_spell_cast_buff",
      "spell_filter": "tavern",
      "scope": "all",
      "attack": 2,
      "health": 2,
      "repeat": 2
    }
  ],
  "BG33_826": [
    {
      "type": "on_spell_cast_buff",
      "spell_filter": "tavern",
      "scope": "self",
      "attack": 1,
      "health": 1,
      "repeat": 1
    }
  ],
  "BG33_826_G": [
    {
      "type": "on_spell_cast_buff",
      "spell_filter": "tavern",
      "scope": "self",
      "attack": 2,
      "health": 2,
      "repeat": 1
    }
  ],
  "BG34_PreMadeChamp_002": [
    {
      "type": "on_spell_cast_buff",
      "spell_filter": "all",
      "scope": "all",
      "attack": 2,
      "health": 2,
      "repeat": 1,
      "tribe": "野兽"
    }
  ],
  "BG34_PreMadeChamp_002_G": [
    {
      "type": "on_spell_cast_buff",
      "spell_filter": "all",
      "scope": "all",
      "attack": 4,
      "health": 4,
      "repeat": 1,
      "tribe": "野兽"
    }
  ],
  "BG28_551": [
    {
      "type": "on_spell_cast_buff",
      "spell_filter": "tavern",
      "scope": "each_type",
      "attack": 4,
      "health": 3,
      "repeat": 1
    }
  ],
  "BG28_551_G": [
    {
      "type": "on_spell_cast_buff",
      "spell_filter": "tavern",
      "scope": "each_type",
      "attack": 8,
      "health": 6,
      "repeat": 1
    }
  ],
  "BG34_Giant_205": [
    {
      "type": "on_spell_cast_buff",
      "spell_filter": "all",
      "scope": "each_type",
      "attack": 4,
      "health": 3,
      "repeat": 1
    }
  ],
  "BG34_Giant_205_G": [
    {
      "type": "on_spell_cast_buff",
      "spell_filter": "all",
      "scope": "each_type",
      "attack": 8,
      "health": 6,
      "repeat": 1
    }
  ],
  "BG28_667": [
    {
      "type": "on_spell_cast_buff",
      "spell_filter": "tavern",
      "scope": "random_other",
      "attack": 5,
      "health": 5,
      "repeat": 1,
      "count": 2
    }
  ],
  "BG28_667_G": [
    {
      "type": "on_spell_cast_buff",
      "spell_filter": "tavern",
      "scope": "random_other",
      "attack": 10,
      "health": 10,
      "repeat": 1,
      "count": 2
    }
  ],
  "BG31_173": [
    {
      "type": "on_spell_cast_buff",
      "spell_filter": "tavern",
      "scope": "random_friendly",
      "tribe": "机械",
      "count": 1,
      "attack": 3,
      "health": 2,
      "repeat": 1
    }
  ],
  "BG31_173_G": [
    {
      "type": "on_spell_cast_buff",
      "spell_filter": "tavern",
      "scope": "random_friendly",
      "tribe": "机械",
      "count": 1,
      "attack": 6,
      "health": 4,
      "repeat": 1
    }
  ],
  "BG34_521": [
    {
      "type": "on_spell_cast_buff",
      "spell_filter": "tavern",
      "scope": "random_friendly",
      "count": 3,
      "attack": 2,
      "health": 1,
      "repeat": 1
    }
  ],
  "BG34_521_G": [
    {
      "type": "on_spell_cast_buff",
      "spell_filter": "tavern",
      "scope": "random_friendly",
      "count": 3,
      "attack": 2,
      "health": 1,
      "repeat": 2
    }
  ],
  "BG28_707": [
    {
      "type": "on_spell_cast_buff",
      "spell_filter": "tavern",
      "scope": "shop",
      "tribe": "元素",
      "attack": 3,
      "health": 3,
      "repeat": 1
    }
  ],
  "BG28_707_G": [
    {
      "type": "on_spell_cast_buff",
      "spell_filter": "tavern",
      "scope": "shop",
      "tribe": "元素",
      "attack": 3,
      "health": 3,
      "repeat": 2
    }
  ],
  "BG28_741": [
    {
      "type": "on_spell_cast_buff",
      "spell_filter": "tavern",
      "scope": "all",
      "require_keyword": "divine_shield",
      "attack": 4,
      "health": 0,
      "repeat": 1
    }
  ],
  "BG28_741_G": [
    {
      "type": "on_spell_cast_buff",
      "spell_filter": "tavern",
      "scope": "all",
      "require_keyword": "divine_shield",
      "attack": 8,
      "health": 0,
      "repeat": 1
    }
  ]
}
const TYPE: String = "on_spell_cast_buff"
const TYPES: Array = [TYPE]
const MAX_STAT: int = 9223372036854775807
const TRIBES: Array = ["", "野兽", "恶魔", "龙", "元素", "机械", "鱼人", "纳迦", "海盗", "野猪人", "亡灵", "德莱尼", "畸变怪"]

static func on_event(engine, p: Dictionary, event: String, context: Dictionary = {}) -> void:
	if event != "spell_listener": return
	# A generated card, hero power, Choose One option, or minion-played gem is
	# not a player cast. Never infer a cast from an effect's spell-shaped data.
	if not context.get("real_cast") is bool or not context.real_cast: return
	if not context.get("origin") is String: return
	if not context.get("choice_branch", false) is bool or context.get("choice_branch", false): return
	if context.origin in ["generated", "hero_power", "choice_branch", "minion_gem"]: return
	if not context.get("spell") is Dictionary or not context.get("source") is Dictionary: return
	var spell: Dictionary = context.spell
	if not spell.get("kind") is String or spell.kind != "spell" or not _uid(spell) or not _uid(context.source): return
	if context.origin == engine.TimewarpedApples.ORIGIN:
		var apples_listener_issue: String=engine.TimewarpedApples.listener_error(engine,p,spell,context.source,context)
		if not apples_listener_issue.is_empty(): _fail(engine,apples_listener_issue);return
	elif context.origin == engine.Evolution.ORIGIN:
		var evolution_listener_issue: String=engine.Evolution.listener_error(engine,p,spell,context.source,context)
		if not evolution_listener_issue.is_empty(): _fail(engine,evolution_listener_issue);return
	elif context.origin == engine.Grimoire.ORIGIN:
		var grimoire_listener_issue: String=engine.Grimoire.listener_error(engine,p,spell,context.source,context)
		if not grimoire_listener_issue.is_empty(): _fail(engine,grimoire_listener_issue);return
	elif context.origin == engine.WindsSpend.ORIGIN:
		var winds_listener_issue: String=engine.WindsSpend.listener_error(engine,p,spell,context.source,context)
		if not winds_listener_issue.is_empty(): _fail(engine,winds_listener_issue);return
	elif context.origin == engine.PocketCyclone.ORIGIN:
		var pocket_cyclone_listener_issue: String=engine.PocketCyclone.listener_error(engine,p,spell,context.source,context)
		if not pocket_cyclone_listener_issue.is_empty(): _fail(engine,pocket_cyclone_listener_issue);return
	elif context.origin == engine.IceBlock.ORIGIN:
		var ice_listener_issue: String=engine.IceBlock.listener_error(engine,p,spell,context.source,context)
		if not ice_listener_issue.is_empty(): _fail(engine,ice_listener_issue);return
	elif context.origin == engine.CoralSpear.ORIGIN:
		var coral_listener_issue: String=engine.CoralSpear.listener_error(engine,p,spell,context.source,context)
		if not coral_listener_issue.is_empty(): _fail(engine,coral_listener_issue);return
	elif context.origin == engine.Mechanisms.MagneticRepair.ORIGIN:
		var repair_listener_issue: String=engine.Mechanisms.MagneticRepair.listener_error(engine,p,spell,context.source,context)
		if not repair_listener_issue.is_empty(): _fail(engine,repair_listener_issue);return
	elif context.origin==engine.Siren.ORIGIN:
		var siren_listener_issue: String=engine.Siren.listener_error(engine,p,spell,context.source,context)
		if not siren_listener_issue.is_empty(): _fail(engine,siren_listener_issue);return
	elif context.origin==engine.Queensguard.PlayerCast.ORIGIN:
		var queen_player_issue: String=engine.Queensguard.PlayerCast.listener_error(engine,p,spell,context.source,context)
		if not queen_player_issue.is_empty(): _fail(engine,queen_player_issue);return
	elif context.origin in [engine.OwnedRallyCast.ORIGIN,engine.OwnedRallyCast.RemovedQueen.ORIGIN]:
		var owned_rally_cast_issue: String=engine.OwnedRallyCast.listener_error(engine,p,spell,context.source,context)
		if not owned_rally_cast_issue.is_empty(): _fail(engine,owned_rally_cast_issue);return
	elif context.origin == engine.EmergencyGearblade.ORIGIN:
		var gearblade_listener_issue: String=engine.EmergencyGearblade.listener_error(engine,p,spell,context.source,context)
		if not gearblade_listener_issue.is_empty(): _fail(engine,gearblade_listener_issue);return
	elif context.origin == engine.CageyCast.ORIGIN:
		var cagey_cast_issue: String=engine.CageyCast.listener_error(engine,p,spell,context.source,context)
		if not cagey_cast_issue.is_empty(): _fail(engine,cagey_cast_issue);return
	elif context.origin == engine.LavishCape.ORIGIN:
		var cape_cast_issue: String=engine.LavishCape.listener_error(engine,p,spell,context.source,context)
		if not cape_cast_issue.is_empty(): _fail(engine,cape_cast_issue);return
	elif context.origin == engine.YoggCast.ORIGIN:
		var yogg_cast_issue: String=engine.YoggCast.listener_error(engine,p,spell,context.source,context)
		if not yogg_cast_issue.is_empty(): _fail(engine,yogg_cast_issue);return
	elif context.origin == engine.PrivateerCast.ORIGIN:
		var privateer_issue: String=engine.PrivateerCast.listener_error(engine,p,spell,context.source,context)
		if not privateer_issue.is_empty(): _fail(engine,privateer_issue);return
	elif context.origin == engine.Imperial.ORIGIN:
		var imperial_issue: String=engine.Imperial.listener_error(engine,p,spell,context.source,context)
		if not imperial_issue.is_empty(): _fail(engine,imperial_issue);return
	elif context.origin == engine.Lava.ORIGIN:
		var lava_issue: String=engine.Lava.listener_error(engine,p,spell,context.source,context)
		if not lava_issue.is_empty(): _fail(engine,lava_issue);return
	elif context.origin == engine.Cathedral.ORIGIN:
		var cathedral_issue: String=engine.Cathedral.listener_error(engine,p,spell,context.source,context)
		if not cathedral_issue.is_empty(): _fail(engine,cathedral_issue);return
	elif context.origin == engine.Balinda.ORIGIN:
		var balinda_issue: String=engine.Balinda.listener_error(engine,p,spell,context.source,context)
		if not balinda_issue.is_empty(): _fail(engine,balinda_issue);return
	elif context.origin == engine.HandGemRepeat.ORIGIN:
		var hand_gem_listener_issue: String=engine.HandGemRepeat.listener_error(engine,p,spell,context.source,context)
		if not hand_gem_listener_issue.is_empty(): _fail(engine,hand_gem_listener_issue);return
	elif context.origin == engine.ActivateGems.ORIGIN:
		var activate_gem_listener_issue: String=engine.ActivateGems.listener_error(engine,p,spell,context.source,context)
		if not activate_gem_listener_issue.is_empty(): _fail(engine,activate_gem_listener_issue);return
	elif context.origin == engine.DiscardCast.ORIGIN:
		var discard_cast_issue: String=engine.DiscardCast.listener_error(engine,p,spell,context.source,context)
		if not discard_cast_issue.is_empty(): _fail(engine,discard_cast_issue);return
	elif context.origin != "hand" or str(engine.state.get("phase", "")) != "recruit":
		_fail(engine, "自动或战斗玩家施法尚无已核实监听接线；不得静默忽略。")
		return
	if not p.get("board") is Array or p.board.size() > 7:
		_fail(engine, "施法监听战队格式无效。")
		return
	var live: Dictionary = {}
	var identities: Dictionary = {}
	for unit in p.board:
		if not unit is Dictionary or not _uid(unit) or identities.has(unit.uid):
			_fail(engine, "施法监听战队身份无效。")
			return
		identities[unit.uid] = true
		if not unit.get("kind") is String:
			_fail(engine, "施法监听战队实体类型无效。")
			return
		if unit.kind == "minion" and unit.uid == context.source.uid: live = unit
	if live.is_empty(): return
	if not live.get("effects") is Array:
		_fail(engine, "施法监听来源效果格式无效。")
		return
	for effect in live.effects:
		if not effect is Dictionary:
			_fail(engine, "施法监听来源效果格式无效。")
			return
		if not effect.get("type") is String:
			_fail(engine, "施法监听来源效果类型无效。")
			return
		if effect.type != TYPE: continue
		var issue: String = validate_effect(effect)
		if not issue.is_empty():
			_fail(engine, issue)
			return
		if effect.spell_filter == "tavern":
			if not spell.get("card_id") is String: continue
			if not Mechanisms._is_tavern_spell(engine,spell): continue
		if engine.RedeemerPortrait.applies(p,live,effect):
			var redeemer_issue: String=engine.RedeemerPortrait.resolve(engine,p,live,effect,context)
			if not redeemer_issue.is_empty(): _fail(engine,redeemer_issue);return
		elif engine.CzarinaPortrait.applies(p,live,effect):
			if not engine._czarina_cast_context.is_empty(): _fail(engine,"czarina_portrait_nested_listener_partial");return
			var czarina_ticket: Dictionary={"owner":p,"source":live,"effect":effect,"context":context,"round":engine.state.round,"sequence":engine.state.command_sequence,"used":false}
			engine._czarina_cast_context=czarina_ticket
			var czarina_issue: String=engine.CzarinaPortrait.resolve(engine,p,live,effect)
			engine._czarina_cast_context={}
			if not czarina_issue.is_empty(): _fail(engine,czarina_issue);return
			if czarina_ticket.used!=true: _fail(engine,"czarina_portrait_missing_actual_trigger");return
		elif engine.AzeritePortrait.handles(engine,p,live,effect,str(context.origin)):
			if not engine._azerite_cast_context.is_empty(): _fail(engine,"azerite_portrait_nested_listener_partial");return
			var azerite_ticket: Dictionary={"owner":p,"source":live,"effect":effect,"context":context,"round":engine.state.round,"sequence":engine.state.command_sequence,"used":false}
			engine._azerite_cast_context=azerite_ticket
			var azerite_issue: String=engine.AzeritePortrait.resolve(engine,p,live,effect)
			engine._azerite_cast_context={}
			if not azerite_issue.is_empty(): _fail(engine,azerite_issue);return
			if azerite_ticket.used!=true: _fail(engine,"azerite_portrait_missing_actual_trigger");return
		elif not _resolve(engine, p, live, effect): return

static func _resolve(engine, p: Dictionary, source: Dictionary, effect: Dictionary) -> bool:
	if effect.scope == "shop": return _resolve_shop(engine, p, effect)
	var candidates: Array = []
	for unit in p.board:
		if unit.get("kind") != "minion": continue
		if not unit.get("tribes") is Array:
			_fail(engine, "施法监听目标种族格式无效。")
			return false
		for tribe in unit.tribes:
			if not tribe is String or tribe not in TRIBES + ["全部", "all", "无", "无类型"]:
				_fail(engine, "施法监听目标含未知种族。")
				return false
		if effect.scope == "self" and unit.uid != source.uid: continue
		if effect.scope == "random_other" and unit.uid == source.uid: continue
		if effect.get("tribe", "") != "" and not engine._tribe_match(unit, effect.tribe): continue
		if effect.has("require_keyword"):
			if not unit.get("keywords") is Array:
				_fail(engine, "施法监听圣盾目标关键词格式无效。")
				return false
			for keyword in unit.keywords:
				if not keyword is String:
					_fail(engine, "施法监听圣盾目标关键词格式无效。")
					return false
			if effect.require_keyword not in unit.keywords: continue
		candidates.append(unit)
	var groups: Array = []
	for _repeat in range(int(effect.repeat)):
		var recipients: Array = candidates.duplicate()
		if effect.scope == "each_type":
			# The same maximum-matching implementation used by RecruitExtensions.
			# Empty source deliberately keeps a source that has acquired a tribe.
			recipients = _each_type_targets(engine, candidates)
		elif effect.scope in ["random_other", "random_friendly"]:
			recipients = []
			var remaining: Array = candidates.duplicate()
			for _i in range(mini(int(effect.count), remaining.size())):
				var selected: int = engine._random(remaining.size(), "spell_cast_other_target")
				recipients.append(remaining[selected])
				remaining.remove_at(selected)
		groups.append(recipients)
	# Preflight the entire trigger, including the second literal golden repeat.
	# RNG may advance on failure, but no target receives a partial trigger.
	var totals: Dictionary = {}
	for group in groups:
		var seen: Dictionary = {}
		for recipient in group:
			if not _uid(recipient) or seen.has(recipient.uid) or not _valid_stats(recipient):
				_fail(engine, "施法监听目标身份或属性无效。")
				return false
			seen[recipient.uid] = true
			if not totals.has(recipient.uid): totals[recipient.uid] = {"attack": 0, "health": 0}
			totals[recipient.uid].attack += int(effect.attack)
			totals[recipient.uid].health += int(effect.health)
			var total: Dictionary = totals[recipient.uid]
			if int(recipient.attack) > MAX_STAT - int(total.attack) or int(recipient.health) > MAX_STAT - int(total.health) or int(recipient.max_health) > MAX_STAT - int(total.health):
				_fail(engine, "施法监听增益超出安全整数范围；整组目标未修改。")
				return false
	# New shield recipients use the existing checked permanent-stat projection.
	# Previous eighteen source programs and selection behavior remain unchanged.
	if effect.has("require_keyword"):
		if not PrizeBuffs.Aura.integer(p.get("id")):
			_fail(engine, "施法监听圣盾目标缺少真实玩家。")
			return false
		for recipient in candidates:
			var checked: Dictionary = PrizeBuffs._unit_after(recipient, int(p.id), int(totals[recipient.uid].attack), int(totals[recipient.uid].health))
			if not checked.ok:
				_fail(engine, str(checked.error))
				return false
	for group in groups:
		for recipient in group:
			recipient.attack = int(recipient.attack)
			recipient.health = int(recipient.health)
			recipient.max_health = int(recipient.max_health)
			var discard_buff_proof: Dictionary=engine.DiscardCast.prepare_listener_buff(engine,p,source,recipient,int(effect.attack),int(effect.health))
			if not discard_buff_proof.ok: _fail(engine,str(discard_buff_proof.error));return false
			engine._buff(recipient, int(effect.attack), int(effect.health))
			if engine.state.get("phase") == "error": return false
			var discard_buff_issue: String=engine.DiscardCast.complete_listener_buff(engine,p,discard_buff_proof)
			if not discard_buff_issue.is_empty(): _fail(engine,discard_buff_issue);return false
	return true

static func _each_type_targets(engine, candidates: Array) -> Array:
	# Keep typeless sentinel labels out of the shared helper's type universe.
	# Match shallow views, then return the original live dictionary references.
	var views: Array = []
	var originals: Dictionary = {}
	for candidate in candidates:
		var tribes: Array = []
		for tribe in candidate.tribes:
			if tribe not in ["", "无", "无类型"]: tribes.append(tribe)
		if tribes.is_empty(): continue
		var view: Dictionary = candidate.duplicate()
		view.tribes = tribes
		views.append(view)
		originals[candidate.uid] = candidate
	var result: Array = []
	for selected in BloodGems.targets_each_type(engine, {"board": views}, {}, []):
		result.append(originals[selected.uid])
	return result

static func validate_effect(effect: Dictionary) -> String:
	if not effect.get("type") is String or effect.type != TYPE: return "未知施法监听效果类型。"
	var allowed: Array = ["type", "spell_filter", "scope", "attack", "health", "repeat"]
	if not effect.get("spell_filter") is String or effect.spell_filter not in ["tavern", "all"]: return "施法监听法术分类无效。"
	if not effect.get("scope") is String or effect.scope not in ["all", "self", "each_type", "random_other", "random_friendly", "shop"]: return "施法监听目标范围无效。"
	for key in ["attack", "health"]:
		if not _integer(effect.get(key), 0, 1000000): return "施法监听增益数值无效。"
	if not _integer(effect.get("repeat"), 1, 2): return "施法监听重复次数无效。"
	if effect.scope in ["random_other", "random_friendly"]:
		allowed.append("count")
		if not _integer(effect.get("count"), 1, 7): return "施法监听随机目标数无效。"
	if effect.scope in ["all", "random_friendly"]:
		allowed.append("tribe")
		if effect.has("tribe") and (not effect.tribe is String or effect.tribe not in TRIBES): return "施法监听种族无效。"
	if effect.scope == "shop":
		allowed.append("tribe")
		if not _same_source(effect, EXACT_EFFECTS.BG28_707[0]) and not _same_source(effect, EXACT_EFFECTS.BG28_707_G[0]): return "仅核实活化艾泽里特的完整酒馆元素程序。"
	if effect.has("require_keyword"):
		allowed.append("require_keyword")
		if not _same_source(effect, EXACT_EFFECTS.BG28_741[0]) and not _same_source(effect, EXACT_EFFECTS.BG28_741_G[0]): return "仅核实女沙皇的完整当前圣盾程序。"
	for key in effect:
		if key not in allowed: return "未知施法监听参数：" + str(key)
	return ""

static func _uid(unit: Dictionary) -> bool:
	return unit.get("uid") is String and not unit.uid.is_empty()

static func _integer(value: Variant, minimum: int, maximum: int) -> bool:
	return (value is int or value is float) and is_finite(float(value)) and value == floor(float(value)) and value >= minimum and value <= maximum

static func _stat(value: Variant, minimum: int) -> bool:
	if value is int: return value >= minimum
	return value is float and is_finite(value) and value >= minimum and value < 9223372036854775808.0 and value == floor(value)

static func _valid_stats(unit: Dictionary) -> bool:
	return _stat(unit.get("attack"), 0) and _stat(unit.get("health"), 1) and _stat(unit.get("max_health"), 1) and int(unit.max_health) >= int(unit.health)

static func _fail(engine, message: String) -> void:
	engine.state.phase = "error"
	engine._log("unsupported_effect", {"message": message})

static func source_error(card: Dictionary, catalog = null) -> String:
	if card.get("id", card.get("card_id", "")) in TAVERN_FOUR_IDS: return tavern_four_source_error(card, catalog)
	if card.get("id", card.get("card_id", "")) in RECIPIENT_IDS: return recipient_source_error(card, catalog)
	var claimed: bool = false
	for effect in card.get("effects",[]):
		if effect is Dictionary and effect.get("type")==TYPE: claimed=true
	if not claimed: return ""
	var id: String = str(card.get("id",card.get("card_id","")))
	if card.get("kind")!="minion" or not EXACT_EFFECTS.has(id): return "施法监听来源不是已核实的独立身份。"
	if card.get("effects")!=EXACT_EFFECTS[id]: return "施法监听完整效果与独立来源不符。"
	return ""

## Only the four include-source bindings use this stronger full-source closure.
## Runtime reads the same small pinned contract/Entities; no mutable cached state.
const RECIPIENT_IDS: Array = ["BG31_173", "BG31_173_G", "BG34_521", "BG34_521_G"]
const RECIPIENT_CONTRACT: String = "res://research/spell_recipient_four/source_contract.json"
const RECIPIENT_CONTRACT_SHA256: String = "a6af2a4913d30716c0f52c07fd004ce4f92c64919f27251d765d5c4eef3a5814"
const RECIPIENT_RULE: String = "spell_recipient_four_complete_native_v1"

static func _same_source(actual: Variant, expected: Variant) -> bool:
	if expected is int or expected is float:
		return (actual is int or actual is float) and is_finite(float(actual)) and actual == expected
	if typeof(actual) != typeof(expected): return false
	if expected is Dictionary:
		if actual.size() != expected.size(): return false
		for key in expected:
			if not actual.has(key) or not _same_source(actual[key], expected[key]): return false
		return true
	if expected is Array:
		if actual.size() != expected.size(): return false
		for index in range(expected.size()):
			if not _same_source(actual[index], expected[index]): return false
		return true
	return actual == expected

static func _recipient_row_error(card: Dictionary, identity: String, contract: Dictionary) -> String:
	var expected: Dictionary = contract.records[identity].source_row.duplicate(true)
	var correction: Dictionary = contract.source_override
	if identity == correction.id:
		expected.original_final_bg_fields = correction.original_fields.duplicate(true)
		expected.merge(correction.fields.duplicate(true), true)
		expected.final_bg_source_verification = correction.verification.duplicate(true)
	var compiled_fields: Array = ["supported", "effects", "keywords", "coverage_rule", "coverage_text_sha256", "coverage_source_text_sha256", "coverage_native_entity_sha256", "default_pool", "pool_supported", "pool_blocker", "coverage_blocker", "coverage_gate"]
	for key in expected:
		if key in ["supported", "effects", "keywords"]: continue
		if not card.has(key) or not _same_source(card[key], expected[key]): return "施法友方随机来源字段已变化：" + identity + "/" + str(key)
	for key in card:
		if not expected.has(key) and key not in compiled_fields: return "施法友方随机来源含未核实字段：" + str(key)
	if card.get("supported") != true or not card.get("supported") is bool: return "施法友方随机来源或配对未获支持。"
	if not _same_source(card.get("effects"), EXACT_EFFECTS[identity]) or not _same_source(card.get("keywords"), contract.keywords[identity]): return "施法友方随机完整效果或关键词不符。"
	if card.has("dependencies") or card.get("coverage_rule") != RECIPIENT_RULE: return "施法友方随机来源闭包未核实。"
	if not _same_source(card.get("default_pool"), false) or not _same_source(card.get("pool_supported"), false): return "施法友方随机来源尚未核实当前牌池。"
	if card.get("coverage_text_sha256") != str(expected.text).sha256_text(): return "施法友方随机卡文签名不符。"
	var mate: String = str(expected.normal_id if expected.normal_id != null else expected.golden_id)
	var texts: Dictionary = {}
	var entities: Dictionary = {}
	for source_id in [identity, mate]:
		var text: String = str(contract.records[source_id].source_row.text)
		if source_id == correction.id: text = str(correction.fields.text)
		texts[source_id] = text.sha256_text()
		entities[source_id] = contract.records[source_id].entity_sha256
	if not _same_source(card.get("coverage_source_text_sha256"), texts) or not _same_source(card.get("coverage_native_entity_sha256"), entities): return "施法友方随机配对签名不符。"
	return ""

static func recipient_source_error(card: Dictionary, catalog) -> String:
	if catalog == null: return "施法友方随机缺少完整配对目录。"
	var text: String = FileAccess.get_file_as_string(RECIPIENT_CONTRACT)
	if text.sha256_text() != RECIPIENT_CONTRACT_SHA256: return "施法友方随机独立来源输入已变化。"
	var parsed: Variant = JSON.parse_string(text)
	if not parsed is Dictionary: return "施法友方随机独立来源格式无效。"
	var contract: Dictionary = parsed
	for identity in RECIPIENT_IDS:
		var record: Dictionary = contract.records[identity]
		var path: String = "res://" + str(record.entity_file)
		if not FileAccess.file_exists(path) or FileAccess.get_file_as_string(path).sha256_text() != record.entity_sha256: return "施法友方随机完整原生实体已变化。"
	var race: Dictionary = contract.race_map_source
	var race_path: String = "res://" + str(race.local_path)
	if not FileAccess.file_exists(race_path) or FileAccess.get_file_as_string(race_path).sha256_text() != race.sha256: return "施法友方随机种族来源已变化。"
	var identity: String = str(card.get("id", ""))
	if identity not in RECIPIENT_IDS: return "施法友方随机来源身份无效。"
	var source: Dictionary = contract.records[identity].source_row
	var mate: String = str(source.normal_id if source.normal_id != null else source.golden_id)
	for candidate in [card, catalog.get_card(mate)]:
		if not candidate is Dictionary or candidate.is_empty(): return "施法友方随机缺少独立配对来源。"
		var expected_id: String = identity if candidate == card else mate
		var issue: String = _recipient_row_error(candidate, expected_id, contract)
		if not issue.is_empty(): return issue
	return ""

## This uses the existing permanent shop ledger and refresh path. Preflight the
## complete trigger on a private player copy, including the later literal repeat,
## before the first live deposit. No partial ledger write is permitted on error.
static func _resolve_shop(engine, p: Dictionary, effect: Dictionary) -> bool:
	var issue: String = PrizeBuffs._map_error(p.get("recruit_shop_bonuses", {}))
	if not issue.is_empty():
		_fail(engine, issue)
		return false
	if not PrizeBuffs.Aura.integer(p.get("id")):
		_fail(engine, "酒馆施法监听缺少真实玩家身份。")
		return false
	for zone in ["hand", "board", "shop"]:
		if not p.get(zone) is Array:
			_fail(engine, "酒馆施法监听区域格式无效。")
			return false
	var shadow: Dictionary = p.duplicate(true)
	shadow.recruit_shop_bonuses = p.get("recruit_shop_bonuses", {}).duplicate(true)
	# Validate the old markers against the OLD ledger before adding anything:
	# the new deposit must never launder a previously-ahead applied marker.
	var old_issue: String = PrizeBuffs.shop_refresh_error(shadow)
	if not old_issue.is_empty():
		_fail(engine, old_issue)
		return false
	for unit in shadow.shop:
		if not unit is Dictionary or not _uid(unit):
			_fail(engine, "酒馆施法监听目标身份无效。")
			return false
		if unit.get("kind") != "minion": continue
		issue = PrizeBuffs._map_error(unit.get("recruit_shop_bonus_applied", {}))
		if not issue.is_empty():
			_fail(engine, issue)
			return false
		for tribe in unit.get("recruit_shop_bonus_applied", {}):
			if not shadow.recruit_shop_bonuses.has(tribe):
				_fail(engine, "酒馆施法监听含无来源的永久商店标记。")
				return false
	# Mirror the existing refresh aura step on the same private copy first. A
	# pending aura change must not hide an overflow before permanent deposits.
	var aura: Dictionary = {"attack":0,"health":0}
	if engine.has_method("hero_shop_aura_bonus"):
		aura = engine.hero_shop_aura_bonus(shadow).duplicate(true)
	for key in ["attack","health"]:
		if not PrizeBuffs.Aura.integer(aura.get(key)):
			_fail(engine, "酒馆施法监听商店光环格式无效。")
			return false
	for unit in shadow.board:
		if not unit.get("effects") is Array:
			_fail(engine, "酒馆施法监听战队程序格式无效。")
			return false
		for passive in unit.effects:
			if not passive is Dictionary or not passive.get("type") is String:
				_fail(engine, "酒馆施法监听战队效果格式无效。")
				return false
			if passive.type != "shop_aura_buff": continue
			for key in ["attack","health"]:
				if not PrizeBuffs.Aura.integer(passive.get(key,0)) or int(aura[key]) > MAX_STAT-int(passive.get(key,0)):
					_fail(engine, "酒馆施法监听商店光环累计超出安全范围。")
					return false
				aura[key] = int(aura[key])+int(passive.get(key,0))
	for index in range(shadow.shop.size()):
		var unit: Dictionary = shadow.shop[index]
		if unit.get("kind") != "minion": continue
		for key in ["attack","health"]:
			if not PrizeBuffs.Aura.integer(unit.get("recruit_shop_aura_"+key,0)):
				_fail(engine, "酒馆施法监听商店光环标记无效。")
				return false
		var adjusted: Dictionary = PrizeBuffs._unit_after(unit, int(p.id), int(aura.attack)-int(unit.get("recruit_shop_aura_attack",0)), int(aura.health)-int(unit.get("recruit_shop_aura_health",0)))
		if not adjusted.ok:
			_fail(engine, str(adjusted.error))
			return false
		shadow.shop[index] = adjusted.after
		shadow.shop[index].recruit_shop_aura_attack = int(aura.attack)
		shadow.shop[index].recruit_shop_aura_health = int(aura.health)
	var bonus: Dictionary = shadow.recruit_shop_bonuses.get("元素", {"attack":0,"health":0}).duplicate(true)
	for _repeat in range(int(effect.repeat)):
		for key in ["attack", "health"]:
			if int(bonus[key]) > MAX_STAT - int(effect[key]):
				_fail(engine, "酒馆施法监听累计超出安全整数范围；整组目标及账本未修改。")
				return false
			bonus[key] = int(bonus[key]) + int(effect[key])
		shadow.recruit_shop_bonuses["元素"] = bonus.duplicate(true)
		issue = PrizeBuffs.shop_refresh_error(shadow)
		if not issue.is_empty():
			_fail(engine, issue)
			return false
		var projected: Dictionary = PrizeBuffs._shop_plan(shadow, false)
		if not projected.ok:
			_fail(engine, str(projected.error))
			return false
		for update in projected.updates: shadow.shop[update.index] = update.after
	# All repeats are safe before the first write. Keep two native +4/+3 calls,
	# so existing host observation order and acquisition retention remain intact.
	for _repeat in range(int(effect.repeat)):
		RecruitShop.add_shop_bonus(engine, p, "元素", int(effect.attack), int(effect.health))
		if engine.state.get("phase") == "error": return false
	return true

const TAVERN_FOUR_IDS: Array = ["BG28_707", "BG28_707_G", "BG28_741", "BG28_741_G"]
const TAVERN_FOUR_CONTRACT: String = "res://research/tavern_cast_four/source_contract.json"
const TAVERN_FOUR_SHA256: String = "e2a513de4f6fba19f942ad0790bdc9bb46b577c27544290db2e1785d86104882"
const TAVERN_FOUR_RULE: String = "tavern_cast_four_complete_native_v1"

static func _tavern_four_row_error(card: Dictionary, identity: String, contract: Dictionary) -> String:
	if Patch3702Azerite.accepts_id(identity): return Patch3702Azerite.tavern_row_error(card,identity,contract)
	var expected: Dictionary = contract.records[identity].source_row
	var compiled_fields: Array = ["supported", "effects", "keywords", "coverage_rule", "coverage_text_sha256", "coverage_source_text_sha256", "coverage_native_entity_sha256", "default_pool", "pool_supported", "pool_blocker", "coverage_blocker", "coverage_gate"]
	for key in expected:
		if key in ["supported", "effects", "keywords"]: continue
		if not card.has(key) or not _same_source(card[key], expected[key]): return "酒馆施法四来源字段已变化：" + identity + "/" + str(key)
	for key in card:
		if not expected.has(key) and key not in compiled_fields: return "酒馆施法四来源含未核实字段：" + str(key)
	if not _same_source(card.get("supported"), true) or not _same_source(card.get("default_pool"), false) or not _same_source(card.get("pool_supported"), false): return "酒馆施法四来源支持或牌池策略不符。"
	if not _same_source(card.get("effects"), EXACT_EFFECTS[identity]) or not _same_source(card.get("keywords"), contract.keywords[identity]): return "酒馆施法四来源完整程序或关键词不符。"
	if card.get("coverage_rule") != TAVERN_FOUR_RULE or card.has("dependencies"): return "酒馆施法四来源闭包未核实。"
	if card.get("coverage_text_sha256") != str(expected.text).sha256_text(): return "酒馆施法四来源卡文签名不符。"
	var texts: Dictionary = {}
	var entities: Dictionary = {}
	for source_id in TAVERN_FOUR_IDS:
		texts[source_id] = str(contract.records[source_id].source_row.text).sha256_text()
		entities[source_id] = contract.records[source_id].entity_sha256
	if not _same_source(card.get("coverage_source_text_sha256"), texts) or not _same_source(card.get("coverage_native_entity_sha256"), entities): return "酒馆施法四来源完整配对签名不符。"
	return ""

static func tavern_four_source_error(card: Dictionary, catalog) -> String:
	if catalog == null: return "酒馆施法四来源缺少完整配对目录。"
	var text: String = FileAccess.get_file_as_string(TAVERN_FOUR_CONTRACT)
	if text.sha256_text() != TAVERN_FOUR_SHA256: return "酒馆施法四来源完整输入已变化。"
	var parsed: Variant = JSON.parse_string(text)
	if not parsed is Dictionary: return "酒馆施法四来源完整输入格式无效。"
	var contract: Dictionary = parsed
	var id: String = str(card.get("id", ""))
	if id not in TAVERN_FOUR_IDS: return "酒馆施法四来源身份无效。"
	for identity in TAVERN_FOUR_IDS:
		var record: Dictionary = contract.records[identity]
		var path: String = "res://research/tavern_cast_four/" + str(record.entity_file)
		if not FileAccess.file_exists(path) or FileAccess.get_file_as_string(path).sha256_text() != record.entity_sha256: return "酒馆施法四来源完整原件已变化。"
		var candidate: Dictionary = card if identity == id else catalog.get_card(identity)
		if candidate.is_empty(): return "酒馆施法四来源缺少完整独立配对。"
		var issue: String = _tavern_four_row_error(candidate, identity, contract)
		if not issue.is_empty(): return issue
	return ""
