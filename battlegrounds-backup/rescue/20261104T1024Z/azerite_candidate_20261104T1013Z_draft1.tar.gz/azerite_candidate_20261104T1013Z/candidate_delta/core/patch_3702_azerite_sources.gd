extends RefCounted
## Newly reconstructed bounded source revision; historical evidence is not acceptance.
const REVISION: String="partial-37.0.2-living-azerite-v1"
const IDS: Array=["BG28_707","BG28_707_G"]
const IDENTITY_FIELDS: Array=["id","card_code","dbf_id","kind","name","tier","tribes","keywords","is_golden","normal_id","golden_id"]
const OVERLAY: String="data/patch_3702_azerite_overlay.json"
const FILE_SHA256: Dictionary={"data/patch_3702_azerite_overlay.json":"24dac7f3a47f31ed2c3050d90a5fe771761788b1a8730045e475900cb16335ee","research/patch_3702_azerite/source_evidence.json":"e6b00c54d6b5ad6facc475e5961ed5ac185dc4a3a79ae153486c089d63af3786","research/patch_3702_azerite/official_patch_azerite_excerpt.html":"c9042629d0298c00a12d88f856462b8207cb07ec65404128bc8b241ea68e0d50","research/patch_3702_azerite/native/BG28_707.xml":"e9b02b187c58aa25d31495e238e18c579d0b8396d08b485dde679c167dd04493","research/patch_3702_azerite/native/BG28_707_G.xml":"1c0caa7ca3e69051cf283a88905bc47d6f2250430240bfc097f0a028481e6ffd","research/tavern_cast_four/source_contract.json":"e2a513de4f6fba19f942ad0790bdc9bb46b577c27544290db2e1785d86104882","research/azerite_portrait/child_contract.json":"14d86b12e83e6eff1988db6020f8a3f9594ba52c859227922bff1efebb6724e9","research/tavern_cast_four/BG28_707.xml":"1b985fbc2033a000802127afaaf26bc32f050f396ee34592d93ce668f7cf3c04","research/tavern_cast_four/BG28_707_G.xml":"b1c7b301045619519a356f04f7c809252fad09167c03ba5c2d9d8942d6ea012f","research/tavern_cast_four/BG28_741.xml":"8ca97cdb314af0e7d2b0a14c9d4bfedb6d1798e89aa73a6bc5e8c702ee12f3fb","research/tavern_cast_four/BG28_741_G.xml":"c947d5f3dc33bc1941e57cd123438ad6873bb41e11f62b3c021df97f8428b364"}
const RUNTIME_PATHS: Array=["core/patch_3702_azerite_sources.gd","data/patch_3702_azerite_overlay.json","research/patch_3702_azerite/source_evidence.json","research/patch_3702_azerite/official_patch_azerite_excerpt.html","research/patch_3702_azerite/native/BG28_707.xml","research/patch_3702_azerite/native/BG28_707_G.xml","research/tavern_cast_four/source_contract.json","research/azerite_portrait/child_contract.json","research/tavern_cast_four/BG28_707.xml","research/tavern_cast_four/BG28_707_G.xml","research/tavern_cast_four/BG28_741.xml","research/tavern_cast_four/BG28_741_G.xml","core/spell_cast_listeners.gd","core/azerite_portrait_sources.gd","core/dark_gift_qualification.gd"]
static func accepts_id(id: Variant) -> bool:
	return id is String and id in IDS
static func same(a: Variant,b: Variant) -> bool:
	# JSON numbers are floats while Catalog normalizes integral values to ints.
	# Compare finite integral numbers symmetrically, never accepting booleans.
	if b is int or b is float:
		return (a is int or a is float) and not a is bool and is_finite(float(a)) and is_finite(float(b)) and a==floor(a) and b==floor(b) and a==b
	if typeof(a)!=typeof(b): return false
	if b is Dictionary:
		if a.size()!=b.size(): return false
		for key in b:
			if not a.has(key) or not same(a[key],b[key]): return false
		return true
	if b is Array:
		if a.size()!=b.size(): return false
		for index in range(b.size()):
			if not same(a[index],b[index]): return false
		return true
	return a==b
static func normalize(value: Variant) -> Variant:
	if value is float and is_finite(value) and value==floor(value) and value>=-9007199254740991 and value<=9007199254740991: return int(value)
	if value is Array:
		var items: Array=[]
		for item in value: items.append(normalize(item))
		return items
	if value is Dictionary:
		var fields: Dictionary={}
		for key in value: fields[key]=normalize(value[key])
		return fields
	return value
static func proof_error() -> String:
	for path in FILE_SHA256:
		if not FileAccess.file_exists("res://"+path) or FileAccess.get_sha256("res://"+path)!=FILE_SHA256[path]: return "partial_3702_azerite_evidence_changed:"+str(path)
	return ""
static func packet() -> Dictionary:
	if not proof_error().is_empty(): return {}
	var value: Variant=JSON.parse_string(FileAccess.get_file_as_string("res://"+OVERLAY))
	if not value is Dictionary or value.get("revision")!=REVISION or not value.get("cards") is Array or value.cards.size()!=IDS.size(): return {}
	var result: Dictionary={}
	for row in value.cards:
		if not row is Dictionary or not accepts_id(row.get("id")) or result.has(row.id): return {}
		for key in ["expected_raw","expected_compiled","expected_baseline","effective_fields","portrait_expected_baseline"]:
			if not row.get(key) is Dictionary: return {}
		result[row.id]=normalize(row)
	return result
static func raw_error(card: Dictionary,path: String) -> String:
	var id: Variant=card.get("id")
	if not accepts_id(id): return ""
	var rows: Dictionary=packet()
	if rows.size()!=IDS.size(): return "partial_3702_azerite_missing_or_changed_packet"
	var field: String=""
	if path=="res://data/catalog_raw.json": field="expected_raw"
	elif path=="res://data/catalog.json": field="expected_compiled"
	else: return "partial_3702_azerite_unexpected_source:"+path
	return "" if same(card,rows[id][field]) else "partial_3702_azerite_changed_input_record:"+str(id)+":"+field
static func apply_overlay(cards: Dictionary) -> String:
	var rows: Dictionary=packet()
	if rows.size()!=IDS.size(): return "partial_3702_azerite_missing_or_changed_packet"
	var staged: Dictionary={}
	for id in IDS:
		# Authenticate both complete historical rows before changing either.
		if not cards.has(id) or not same(cards[id],rows[id].expected_baseline): return "partial_3702_azerite_changed_baseline:"+id
		var merged: Dictionary=cards[id].duplicate(true)
		merged.merge(rows[id].effective_fields,true)
		if str(merged.text).sha256_text()!=merged.coverage_text_sha256: return "partial_3702_azerite_changed_text_digest:"+id
		staged[id]=merged
	for id in IDS: cards[id]=staged[id]
	return ""
static func source_error(card: Dictionary) -> String:
	var id: Variant=card.get("id")
	if not accepts_id(id): return "partial_3702_azerite_unknown_source"
	var rows: Dictionary=packet()
	if rows.size()!=IDS.size(): return "partial_3702_azerite_missing_or_changed_packet"
	# Bind immutable identity facts without freezing later pool/display policy.
	for key in IDENTITY_FIELDS:
		if not card.has(key) or not same(card[key],rows[id].expected_baseline[key]): return "partial_3702_azerite_changed_identity:"+str(id)+":"+str(key)
	for key in rows[id].effective_fields:
		if not card.has(key) or not same(card[key],rows[id].effective_fields[key]): return "partial_3702_azerite_changed_effective_source:"+str(id)+":"+str(key)
	return ""
static func tavern_row_error(card: Dictionary,identity: String,contract: Dictionary) -> String:
	if not accepts_id(identity) or not same(card.get("id"),identity): return "partial_3702_azerite_wrong_tavern_identity"
	var rows: Dictionary=packet()
	if rows.size()!=IDS.size(): return "partial_3702_azerite_missing_or_changed_packet"
	var original: Variant=normalize(JSON.parse_string(FileAccess.get_file_as_string("res://research/tavern_cast_four/source_contract.json")))
	if not original is Dictionary or not same(contract,original): return "partial_3702_azerite_changed_whole_tavern_contract"
	if not same(contract.records[identity].source_row,rows[identity].expected_raw): return "partial_3702_azerite_changed_tavern_old_row"
	var issue: String=source_error(card)
	if not issue.is_empty(): return issue
	var expected: Dictionary=rows[identity].expected_baseline.duplicate(true)
	expected.merge(rows[identity].effective_fields,true)
	# Keep the original pre-admission policy and every historical source field.
	for key in expected:
		if not card.has(key) or not same(card[key],expected[key]): return "partial_3702_azerite_changed_tavern_row:"+identity+":"+str(key)
	# These three policy annotations were already permitted by the old closure.
	for key in card:
		if not expected.has(key) and key not in ["pool_blocker","coverage_blocker","coverage_gate"]: return "partial_3702_azerite_unknown_tavern_field:"+str(key)
	if not same(card.get("supported"),true) or not same(card.get("default_pool"),false) or not same(card.get("pool_supported"),false): return "partial_3702_azerite_changed_tavern_policy"
	return ""
static func portrait_child_error(card: Dictionary,historical_expected: Dictionary) -> String:
	var id: Variant=card.get("id")
	if not accepts_id(id) or not same(card.get("supported"),true): return "partial_3702_azerite_wrong_portrait_child"
	var rows: Dictionary=packet()
	if rows.size()!=IDS.size(): return "partial_3702_azerite_missing_or_changed_packet"
	if not same(historical_expected,rows[id].portrait_expected_baseline): return "partial_3702_azerite_changed_historical_portrait_child"
	var issue: String=source_error(card)
	if not issue.is_empty(): return issue
	var expected: Dictionary=historical_expected.duplicate(true)
	for key in ["attack","health","text","effects"]: expected[key]=rows[id].effective_fields[key]
	for key in expected:
		if not card.has(key) or not same(card[key],expected[key]): return "partial_3702_azerite_changed_portrait_child:"+str(id)+":"+str(key)
	return ""
