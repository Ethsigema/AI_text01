extends SceneTree
## NEW SECOND-LOSS RECONSTRUCTION. Review and sealed launch required. No native acceptance.
const OUTPUT = "user://tidecaller_lifecycle_public_report.json"
const TIDE = "BG36_704"
const GOLDEN = "BG36_704_G"
const TAD = "BG22_202"
const CYCLONE = "BGS_119"
const PATCHWERK = "TB_BaconShop_HERO_34"
const FORTIFY = "BG28_503"
const FORTIFY_PROGRAM = [{"type":"spell_buff","scope":"target","attack":0,"health":3,"allow_shop":true,"temporary":false},{"type":"spell_keyword","scope":"target","keyword":"taunt","allow_shop":true,"temporary":false}]
const CASES = ["normal_tidecaller_lifecycle","golden_tidecaller_lifecycle"]
const LABELS = ["non_murloc_control","shop_non_murloc_control","board_murloc","source_self","shop_murloc","repeat_board_murloc"]
const SAVE_LABELS = ["genuine setup immediately before actual targeted hand casts","first execution all six actual casts and permanent recipient grants native roundtrip","deterministic replay all six actual casts and permanent recipient grants native roundtrip","permanent next-turn result native roundtrip"]
const UPGRADE_PRICES = [0,5,7,8,11,11,0]
var game_script: GDScript
var room_script: GDScript
var catalog: RefCounted
var game: RefCounted
var stock_baseline: Dictionary = {}
var scenario: String = "source_contracts"
var failures: int = 0
var acquiring: bool = true
var tier_started: Array = [1,1]
var report: Dictionary = {"status":"not_run","reconstruction":"new_second_loss_20261104T0901Z_not_original_artifact","historical_acceptance_credit":0,"execution_fingerprint":"","checks":[],"commands":[],"loads":[],"combats":[],"casts":[],"failure_snapshots":[],"completed_cases":[],"required_cases":CASES,"counters_by_case":{},"held":["full pool gameplay acceptance","internal buff-call cardinality","combat secondary target listeners","historical original-file acceptance","arbitrary source composition"]}
func check(ok: bool, label: String, detail: Variant = null) -> bool:
	report.checks.append({"scenario":scenario,"label":label,"passed":ok,"detail":detail})
	print("BASIC_CHECK ", scenario, " | ", label, " | ", ok)
	if not ok:
		failures += 1
		if game != null and not game.state.is_empty(): report.failure_snapshots.append({"scenario":scenario,"label":label,"snapshot":snapshot()})
		persist()
	return ok

func persist() -> void:
	var file: FileAccess = FileAccess.open(OUTPUT,FileAccess.WRITE)
	if file != null: file.store_string(JSON.stringify(report,"  "))

func owner(player: int = 0) -> Dictionary:
	return game.state.players[player]

func snapshot() -> Dictionary:
	return {"schema_version":game_script.SAVE_VERSION,"rules_version":game_script.RULES_VERSION,"execution_fingerprint":game.catalog.execution_fingerprint,"room":game.room.duplicate(true),"state":game.state.duplicate(true),"pool":game.pool.duplicate(true),"spell_pool":game.spell_pool.duplicate(true),"rng_seed":str(game.rng.seed),"rng_state":str(game.rng.state),"next_uid":game.next_uid,"events":game.events.duplicate(true),"command_log":game.command_log.duplicate(true),"last_combats":game.last_combats.duplicate(true)}

func index_uid(zone: String, uid: String, player: int = 0) -> int:
	for i in range(owner(player)[zone].size()):
		if owner(player)[zone][i].get("uid") == uid: return i
	return -1

func index_card(zone: String, identity: String, player: int = 0) -> int:
	for i in range(owner(player)[zone].size()):
		if owner(player)[zone][i].get("card_id") == identity: return i
	return -1

func unit(zone: String, uid: String, player: int = 0) -> Dictionary:
	var i: int = index_uid(zone,uid,player)
	return {} if i < 0 else owner(player)[zone][i]

func command(cmd: Dictionary, label: String, player: int = 0, expect_ok: bool = true) -> bool:
	var before: Dictionary = snapshot()
	var result: Dictionary = game.apply_command(player,cmd)
	report.commands.append({"scenario":scenario,"label":label,"player":player,"command":cmd.duplicate(true),"result":result.duplicate(true),"before_round":before.state.round,"after_round":game.state.round,"phase":game.state.phase,"expected_ok":expect_ok})
	if not check(result.get("ok",false) == expect_ok,label + ": expected command result",result): return false
	if not expect_ok:
		if not check(not str(result.get("error","")).is_empty(),label + ": explicit error returned"): return false
		return check(snapshot() == before,label + ": rejected command leaves every persisted field unchanged")
	if not check(game.state.phase != "error",label + ": no engine error phase"): return false
	if not check(game.state.command_sequence == before.state.command_sequence + 1 and game.command_log.size() == before.command_log.size() + 1,label + ": one real command receipt; no bot actions"): return false
	return check(stock_totals() == stock_baseline,label + ": complete native stock conservation")

func roundtrip(label: String) -> bool:
	var before: Dictionary = snapshot()
	var path: String = "user://tidecaller_lifecycle_" + scenario + "_" + str(report.loads.size()+1) + ".json"
	var saved: int = game.save_to(path)
	if not check(saved == OK,label + ": native save",saved): return false
	if not check(snapshot() == before,label + ": saving does not mutate engine"): return false
	var restored: RefCounted = game_script.new()
	var loaded: int = restored.load_from(path,catalog)
	if not check(loaded == OK,label + ": fresh native load",loaded): return false
	game = restored
	var after: Dictionary = snapshot()
	for field in before:
		if not check(after[field] == before[field],label + ": native roundtrip " + field): return false
	report.loads.append({"scenario":scenario,"label":label,"path":ProjectSettings.globalize_path(path)})
	persist()
	return true

func buy_minion(identity: String, player: int = 0, uid: String = "") -> String:
	var index: int = index_card("shop",identity,player) if uid.is_empty() else index_uid("shop",uid,player)
	if not check(index >= 0,"real minion offer exists " + identity): return ""
	var offered: Dictionary = owner(player).shop[index].duplicate(true)
	var before_gold: int = owner(player).gold
	var before_pool: Dictionary = game.pool.duplicate(true)
	var before_hand: int = owner(player).hand.size()
	if not check(offered.get("pool_id") == identity and offered.get("pool_count") == 1,"offered minion has native stock entitlement"): return ""
	if not command({"type":"buy","index":index},"buy minion " + identity,player): return ""
	var acquired: Dictionary = unit("hand",offered.uid,player)
	if not check(owner(player).gold == before_gold-3 and owner(player).hand.size() == before_hand+1 and not acquired.is_empty() and index_uid("shop",offered.uid,player) == -1,"buy pays three and moves original UID once"): return ""
	if not check(game.pool == before_pool and acquired.get("pool_count") == 1,"buy does not debit reserved minion stock twice"): return ""
	return offered.uid

func play_minion(uid: String, player: int = 0) -> bool:
	var index: int = index_uid("hand",uid,player)
	if not check(index >= 0,"real acquired minion in hand"): return false
	var before: Dictionary = unit("hand",uid,player).duplicate(true)
	var gold: int = owner(player).gold
	var board_size: int = owner(player).board.size()
	if not command({"type":"play","index":index,"position":board_size},"play acquired minion",player): return false
	var after: Dictionary = unit("board",uid,player)
	if not check(not after.is_empty() and index_uid("hand",uid,player) == -1 and owner(player).board.size() == board_size+1 and owner(player).gold == gold,"play moves original UID once without payment"): return false
	for field in ["card_id","attack","health","max_health","keywords","temporary_buffs","permanent_keywords","pool_id","pool_count"]:
		if not check(after.get(field) == before.get(field),"played minion preserves acquired " + field): return false
	return true

func stock_totals() -> Dictionary:
	var totals: Dictionary = {}
	for identity in game.pool: totals["minion:"+str(identity)] = game.pool[identity]
	for identity in game.spell_pool: totals["spell:"+str(identity)] = game.spell_pool[identity]
	for player in game.state.players:
		for body in player.board + player.hand + player.shop:
			var count: int = int(body.get("pool_count",0))
			if count == 0: continue
			var kind: String = "spell" if body.get("pool_kind","") == "spell" else "minion"
			var key: String = kind+":"+str(body.get("pool_id",""))
			totals[key] = int(totals.get(key,0)) + count
	return totals

func zone_by_uid(zone: String, player: int = 0) -> Dictionary:
	var output: Dictionary = {}
	for body in owner(player)[zone]: output[body.uid] = body.duplicate(true)
	return output

func matching_events(entries: Array, name: String, field: String = "", value: Variant = null, name_field: String = "event") -> Array:
	var found: Array = []
	for entry in entries:
		if entry.get(name_field,"") == name and (field.is_empty() or entry.get(field) == value): found.append(entry)
	return found

func refresh_player(player: int) -> bool:
	var before = owner(player).duplicate(true)
	var cost = 0 if before.free_rolls > 0 else 1
	if not command({"type":"roll"},"real paid bounded acquisition roll",player): return false
	return check(owner(player).gold == before.gold-cost and owner(player).board == before.board and owner(player).hand == before.hand,"refresh pays native price and leaves owned cards alone")

func acquire(identity: String, player: int = 0) -> String:
	for _step in range(60):
		if index_card("shop",identity,player)>=0 and owner(player).gold>=3: return buy_minion(identity,player)
		if owner(player).gold>=4:
			if not refresh_player(player): return ""
		elif not advance(): return ""
	check(false,"bounded real purchase unavailable; no synthetic offer",identity)
	return ""

func advance() -> bool:
	var round_before: int = game.state.round
	var hp_before: Array = [owner().health,owner(1).health,owner().armor,owner(1).armor]
	if acquiring and not check(owner().board.is_empty() and owner(1).board.is_empty(),"acquisition combat starts with both actual boards empty"): return false
	if not owner(1).ready:
		if not command({"type":"end_turn"},"ready real opponent",1): return false
	if not command({"type":"end_turn"},"resolve actual end_turn"): return false
	if not check(game.state.round==round_before+1 and game.state.phase=="recruit" and owner().alive and owner(1).alive and not owner().ready,"actual combat returns to next active recruit"): return false
	if not check(game.last_combats.size()==1 and game.last_combats[0].get("error","")=="","one successful full Game combat"): return false
	if acquiring:
		var c: Dictionary=game.last_combats[0]
		if not check(c.winner==-1 and c.left.is_empty() and c.right.is_empty() and hp_before==[owner().health,owner(1).health,owner().armor,owner(1).armor],"acquisition ties preserve both hero resources without resetting anything"): return false
		for e in c.log:
			if not check(e.get("event") not in ["attack","damage","death","hand_buff"],"no unrelated acquisition combat hazard"): return false
	report.combats.append({"scenario":scenario,"round":round_before,"acquisition":acquiring,"result":game.last_combats[0].duplicate(true)})
	return true

func buy_true_triple_player(identity: String,golden_id: String,player: int) -> String:
	var originals: Array=[]
	for _i in range(2):
		var uid: String=acquire(identity,player)
		if uid.is_empty(): return ""
		originals.append(uid)
	for _step in range(60):
		if index_card("shop",identity,player)>=0 and owner(player).gold>=3: break
		if owner(player).gold>=4:
			if not refresh_player(player): return ""
		elif not advance(): return ""
	var i: int=index_card("shop",identity,player)
	if not check(i>=0 and owner(player).gold>=3,"real affordable third normal offer for owner "+str(player)): return ""
	var offered: Dictionary=owner(player).shop[i].duplicate(true)
	var before: Dictionary=snapshot()
	if not command({"type":"buy","index":i},"actual third paid normal purchase",player): return ""
	var gi: int=index_card("hand",golden_id,player)
	if not check(gi>=0 and owner(player).gold==before.state.players[player].gold-3 and game.pool==before.pool,"real owner-specific triple payment and reserved stock"): return ""
	var golden: Dictionary=owner(player).hand[gi]
	if not check(golden.golden and golden.pool_id==identity and golden.pool_count==3,"native golden has three-copy stock entitlement"): return ""
	for uid in originals+[offered.uid]:
		if not check(index_uid("hand",uid,player)<0 and index_uid("board",uid,player)<0 and index_uid("shop",uid,player)<0,"each genuine ordinary UID consumed once for exact owner"): return ""
	var triples: Array=[]
	for event in game.events.slice(before.events.size()):
		if event.get("type")=="triple": triples.append(event)
	if not check(triples.size()==1 and triples[0].player==player and triples[0].card_id==golden_id,"one new triple receipt attributed to actual owner"): return ""
	if not check(owner(1-player).hand==before.state.players[1-player].hand and owner(1-player).board==before.state.players[1-player].board,"tripling one owner never consumes the other owner's cards"): return ""
	return golden.uid

func acquire_fortify_player(player: int) -> String:
	for _step in range(40):
		var i: int=index_card("shop",FORTIFY,player)
		if i>=0 and owner(player).gold>=1:
			var offered: Dictionary=owner(player).shop[i].duplicate(true)
			var before: Dictionary=snapshot()
			if not check(offered.cost==1 and offered.tier==1 and offered.pool_kind=="spell" and offered.pool_count==1,"genuine Fortify cost, tier and reservation"): return ""
			if not command({"type":"buy","index":i},"buy real Fortify for exact owner",player): return ""
			var acquired: Dictionary=unit("hand",offered.uid,player)
			if not check(not acquired.is_empty() and acquired.pool_count==0 and owner(player).gold==before.state.players[player].gold-1 and game.spell_pool[FORTIFY]==before.spell_pool[FORTIFY]+1,"actual Fortify payment and reservation release"): return ""
			return offered.uid
		if owner(player).gold>=2:
			if not refresh_player(player): return ""
		elif not advance(): return ""
	check(false,"bounded real Fortify unavailable; never synthesize")
	return ""

func configure(golden: bool) -> bool:
	scenario = CASES[1 if golden else 0]
	acquiring = true
	tier_started = [1,1]
	var config = room_script.new()
	config.reset(catalog)
	config.data.bot_count = 1
	config.data.seed = 2026110411 if golden else 2026110410
	config.data.enabled_minions = [TIDE,TAD,CYCLONE]
	config.data.enabled_spells = [FORTIFY]
	config.data.enabled_heroes = [PATCHWERK]
	config.data.selected_hero = PATCHWERK
	config.data.damage_received_listeners = false
	for key in ["enabled_anomalies","enabled_trinkets","enabled_quests","enabled_rewards"]: config.data[key] = []
	var issues = config.validate(catalog)
	if not check(issues.is_empty(),"bounded current native room admission",issues): return false
	game = game_script.new()
	var result = game.start(config.data,catalog)
	if not check(result.get("ok",false),"fresh actual bounded Game starts",result): return false
	stock_baseline = stock_totals()
	if not check(not game.pool.has(GOLDEN),"golden never an ordinary shop pool identity"): return false
	return true

func reach_tiers() -> bool:
	for _step in range(30):
		for player in [0,1]:
			var wanted: int = 5 if player == 0 else 2
			if owner(player).tier >= wanted: continue
			var tier: int = int(owner(player).tier)
			var quote: int = maxi(0,UPGRADE_PRICES[tier]-(int(game.state.round)-int(tier_started[player])))
			if not check(owner(player).upgrade_cost == quote,"independent native tier-age upgrade quote"): return false
			if owner(player).gold < quote: continue
			var gold: int = owner(player).gold
			if not command({"type":"upgrade"},"real paid tier upgrade",player): return false
			if not check(owner(player).tier == tier+1 and owner(player).gold == gold-quote,"exact one tier and quoted payment"): return false
			tier_started[player] = game.state.round
		if owner().tier == 5 and owner(1).tier == 2: return true
		if not advance(): return false
	return check(false,"tier acquisition exhausted; no synthetic funds")

func source_program(golden: bool) -> Array:
	return [{"type":"on_target_spell_hand_buff","target_scope":"tribe","target_tribe":"鱼人","scope":"board_and_hand","tribe":"鱼人","attack":6 if golden else 3,"health":8 if golden else 4}]

func spell_offer_ready() -> bool:
	for _step in range(100):
		if index_card("shop",TAD) >= 0 and index_card("shop",CYCLONE) >= 0 and index_card("shop",FORTIFY) >= 0 and owner().gold >= 1: return true
		if owner().gold >= 2:
			if not refresh_player(0): return false
		elif not advance(): return false
	return check(false,"bounded shop target and sixth spell search exhausted")

func cast_one(spell_uid: String, source_uid: String, target_uid: String, zone: String, label: String, golden: bool) -> bool:
	var i: int = index_uid("hand",spell_uid)
	var ti: int = index_uid(zone,target_uid)
	if not check(i >= 0 and ti >= 0,"cast "+label+": exact real source and target UIDs"): return false
	var before: Dictionary = snapshot()
	var old: Dictionary = owner().duplicate(true)
	var spell: Dictionary = old.hand[i]
	var target: Dictionary = old[zone][ti]
	var trigger: bool = target.get("kind","minion") == "minion" and "鱼人" in target.get("tribes",[])
	if not check(spell.card_id == FORTIFY and spell.cost == 1 and spell.pool_count == 0 and spell.effects == FORTIFY_PROGRAM,"cast "+label+": genuine paid Fortify in hand"): return false
	var expected: Dictionary = old.duplicate(true)
	expected.hand.remove_at(i)
	var expected_target: Dictionary = expected[zone][ti]
	expected_target.health += 3
	expected_target.max_health += 3
	if "taunt" not in expected_target.keywords: expected_target.keywords.append("taunt")
	if not expected_target.has("permanent_keywords"): expected_target.permanent_keywords = []
	if "taunt" not in expected_target.permanent_keywords: expected_target.permanent_keywords.append("taunt")
	var eligible: Array = []
	for owned_zone in ["board","hand"]:
		for card in expected[owned_zone]:
			if card.get("kind","minion") == "minion" and "鱼人" in card.get("tribes",[]):
				eligible.append(card.uid)
				if trigger:
					card.attack += 6 if golden else 3
					card.health += 8 if golden else 4
					card.max_health += 8 if golden else 4
	if not check(eligible.size() == 3 and source_uid in eligible,"cast "+label+": exact three owned Murloc recipients"): return false
	var cmd: Dictionary = {"type":"play","index":i,"target":ti,"target_zone":zone}
	if not command(cmd,"actual targeted Fortify "+label): return false
	for key in ["board","hand","shop"]:
		if not check(owner()[key] == expected[key],"cast "+label+": whole "+key+" dictionaries match exact independent deltas",{"expected":expected[key],"actual":owner()[key].duplicate(true)}): return false
	if not check(owner().gold == old.gold and owner().stats.spells == old.stats.spells+1,"cast "+label+": consume once no additional gold one cast counter"): return false
	if not check(owner(1) == before.state.players[1],"cast "+label+": other owner entire state unchanged"): return false
	if not check(game.pool == before.pool and game.spell_pool == before.spell_pool,"cast "+label+": both native pools unchanged"): return false
	for card in owner().board+owner().hand:
		if not check(card.get("temporary_buffs",[]).is_empty(),"cast "+label+": empty temporary ledger"): return false
	report.casts.append({"scenario":scenario,"label":label,"spell_uid":spell_uid,"spell_id":FORTIFY,"source_uid":source_uid,"source_id":GOLDEN if golden else TIDE,"target_zone":zone,"target_uid":target_uid,"triggered":trigger,"grant_attack":(6 if golden else 3) if trigger else 0,"grant_health":(8 if golden else 4) if trigger else 0,"eligible_owned_uids":eligible,"expected_program_applications":1 if trigger else 0,"fortify_applications":1,"command_sequence":game.state.command_sequence,"command":cmd,"before_owned":old,"after_owned":owner().duplicate(true)})
	return true

func six_casts(setup: Dictionary, golden: bool) -> bool:
	var targets: Array = [setup.cyclone,setup.shop_cyclone,setup.tad,setup.source,setup.shop_tad,setup.tad]
	var zones: Array = ["board","shop","board","board","shop","board"]
	for i in range(6):
		if i == 5 and not check("taunt" in unit("board",setup.tad).keywords,"repeat target already has permanent Taunt"): return false
		if not cast_one(setup.spells[i],setup.source,targets[i],zones[i],LABELS[i],golden): return false
	return true

func next_turn() -> bool:
	var before: Dictionary = snapshot()
	if not owner().frozen and not command({"type":"freeze"},"freeze actual observed shop for permanence"): return false
	if not advance(): return false
	for player in [0,1]:
		for zone in ["board","hand"]:
			var expected: Array = before.state.players[player][zone].duplicate(true)
			for card in expected: card.blood_gems_received_turn = 0
			if not check(owner(player)[zone] == expected,"next turn owner "+str(player)+" whole "+zone+" permanent with native zero counter",{"expected":expected,"actual":owner(player)[zone].duplicate(true)}): return false
	for card in before.state.players[0].shop:
		var expected: Dictionary = card.duplicate(true)
		expected.blood_gems_received_turn = 0
		if not check(unit("shop",card.uid) == expected,"frozen real shop UID retains exact Fortify only"): return false
	for event in game.last_combats[0].log:
		if not check(event.get("event") != "combat_spell_completed","no combat secondary spell-target route claimed"): return false
	return true

func run_case(golden: bool) -> bool:
	if not configure(golden) or not reach_tiers(): return false
	var source: String = buy_true_triple_player(TIDE,GOLDEN,0) if golden else acquire(TIDE)
	var tad: String = acquire(TAD)
	var held_tad: String = acquire(TAD)
	var cyclone: String = acquire(CYCLONE)
	var held_cyclone: String = acquire(CYCLONE)
	var other_tad: String = acquire(TAD,1)
	if not check("" not in [source,tad,held_tad,cyclone,held_cyclone,other_tad],"all sources and controls genuinely purchased"): return false
	var spells: Array = []
	for _i in range(5):
		var spell: String = acquire_fortify_player(0)
		if spell.is_empty(): return false
		spells.append(spell)
	if not check(owner().hand.size() == 10 and index_card("hand","__triple_reward") == -1,"actual hand at ten before playing golden source reward"): return false
	if not spell_offer_ready(): return false
	var shop_tad: String = owner().shop[index_card("shop",TAD)].uid
	var shop_cyclone: String = owner().shop[index_card("shop",CYCLONE)].uid
	if not play_minion(cyclone) or not play_minion(source) or not play_minion(tad): return false
	var last_spell: String = acquire_fortify_player(0)
	if last_spell.is_empty(): return false
	spells.append(last_spell)
	var body: Dictionary = unit("board",source)
	if not check(body.attack == (12 if golden else 6) and body.health == (18 if golden else 9) and body.max_health == body.health and body.effects == source_program(golden),"genuine source has exact current body and program"): return false
	if not check(body.golden == golden and body.pool_id == TIDE and body.pool_count == (3 if golden else 1),"source exact native golden and stock entitlement"): return false
	var reward_i: int = index_card("hand","__triple_reward")
	if golden:
		if not check(reward_i >= 0 and owner().hand[reward_i].effects == [{"type":"spell_discover","tier":6}] and owner().hand.size() == 9,"true golden play creates preserved native tier6 reward"): return false
	elif not check(reward_i == -1 and owner().hand.size() == 8,"normal has no forged triple reward"): return false
	if not check(owner(1).hand.size() == 1 and owner(1).hand[0].uid == other_tad and owner(1).board.is_empty(),"other owner genuine held Tad control"): return false
	acquiring = false
	if not roundtrip(SAVE_LABELS[0]): return false
	var setup_path: String = report.loads[-1].path
	var before: Dictionary = snapshot()
	var setup: Dictionary = {"source":source,"tad":tad,"cyclone":cyclone,"shop_tad":shop_tad,"shop_cyclone":shop_cyclone,"spells":spells}
	if not six_casts(setup,golden) or not roundtrip(SAVE_LABELS[1]): return false
	var active: Dictionary = snapshot()
	if not next_turn(): return false
	var future: Dictionary = snapshot()
	var restored: RefCounted = game_script.new()
	if not check(restored.load_from(setup_path,catalog) == OK,"replay fresh load exact setup"): return false
	game = restored
	if not check(snapshot() == before,"replay restores full 13 persisted fields"): return false
	if not six_casts(setup,golden) or not roundtrip(SAVE_LABELS[2]): return false
	if not check(snapshot() == active,"six actual casts replay all 13 persisted fields"): return false
	if not next_turn() or not check(snapshot() == future,"actual next turn replay all 13 persisted fields"): return false
	if not roundtrip(SAVE_LABELS[3]): return false
	report.counters_by_case[scenario] = {"actual_hand_casts":12,"targeted_murloc_casts":8,"non_murloc_casts":4,"exact_owned_murloc_grants":24,"fortify_applications":12,"shop_target_casts":4,"self_target_casts":2,"repeat_target_casts":2,"native_roundtrips":4,"replay_comparisons":1}
	report.completed_cases.append(scenario)
	return true

func finish() -> void:
	report.status = "passed_narrow_new_reconstruction_only" if failures == 0 and report.completed_cases == CASES else "failed_or_incomplete_no_credit"
	report.failures = failures
	persist()
	print("TIDECALLER_LIFECYCLE_PUBLIC_TERMINAL ",JSON.stringify(report))
	quit(0 if report.status == "passed_narrow_new_reconstruction_only" else 1)

func _initialize() -> void:
	if "--reviewed-tidecaller-lifecycle" not in OS.get_cmdline_user_args():
		print("TIDECALLER_SECOND_LOSS_HOLD: independent review and sealed parent launch release required")
		quit(2);return
	game_script = load("res://core/game.gd")
	room_script = load("res://core/room_config.gd")
	catalog = load("res://core/catalog.gd").new()
	catalog.load_catalog()
	if not check(catalog.load_errors.is_empty(),"candidate Catalog clean",catalog.load_errors): finish();return
	report.execution_fingerprint = catalog.execution_fingerprint
	for golden in [false,true]:
		var card: Dictionary = catalog.get_card(GOLDEN if golden else TIDE)
		if not check(card.tier == 5 and card.attack == (12 if golden else 6) and card.health == (18 if golden else 9) and card.effects == source_program(golden),"current source exact normal or golden contract"): finish();return
		if not run_case(golden): finish();return
	finish()
