# Tidecaller second-loss rescue, 2026-11-04 09:01 UTC

This package is a NEW reconstruction after the second /workspace/shared loss. It is not a byte-for-byte recovery of the 08:07 harness or 08:46 validator. The available conversation contains detailed design, schemas and historical hashes, but not their full original source text. No original-file match may be inferred from equivalent behavior.

No Godot engine, public gameplay run, source mutation, native acceptance or historical acceptance credit is provided. The restored parent tree is read-only. The recovered Murcules helper is actual available source; new Tide files are generated here. The historical 42 negative Python fixtures and positive test passed before loss but their original source is unavailable. New tests must report their own actual counts.

Scope: two public-command cases, normal BG36_704 6/9 and genuinely tripled BG36_704_G 12/18; six targeted Fortify casts per execution and identical six-cast replay, 24 total. Fortify +0/+3 and permanent Taunt is independent from owned-board-and-hand Murloc +3/+4 or +6/+8. Board/shop non-Murloc controls, board Tad, self source, shop Tad, repeat already-Taunt Tad; opponent hand Tad unchanged. Full owned snapshots, 8 actual save/load boundaries with all 13 persisted fields, next-turn permanent result including explicit blood_gems_received_turn=0 initialization, stock conservation and public paid acquisition.

Required integration: independent review; separate sealed runner; fresh private XDG data dir; source manifest and native save-byte authentication; exact terminal/report/log/check consistency; sealed pure validator invocation and input nonmutation checks. The pure validator is supplementary and cannot establish complete paid acquisition from self-reported pass labels. Intracast opponent/pool checks and real purchases remain supported jointly by sealed harness source, native assertions and strict runner receipts. Aggregate vectors are not internal buff-call cardinality receipts. Existing combat secondary listeners remain held.

## Reproduce the new rescue artifacts

1. `PYTHONDONTWRITEBYTECODE=1 python build_harness.py`
2. `PYTHONDONTWRITEBYTECODE=1 python build_contract.py` (also updates the validator's canonical contract pin).
3. `PYTHONDONTWRITEBYTECODE=1 python test_tidecaller_report_validator.py`
4. `PYTHONDONTWRITEBYTECODE=1 python seal_rescue.py`

The new unit fixture is explicitly fabricated in memory. Its fictional metadata paths are never written or represented as native saves. The 42 new negative mutations reject altered reports/contexts; they do not prove gameplay or reproduce the historical test suite. Some mutations are caught by an earlier consistency guard, so the count is not a claim of 42 independently reached validator branches.

The generated harness has not been parsed by Godot. Static preparation is not launch permission. Independent review must check this new source and map the new contract to the separately sealed runner. This rescue contract uses the established validate(report, contract, context) API but is not byte/schema-identical to the lost contract. Do not replace an existing runner contract without review.

Adaptive acquisition budgets: normal at most 690 search/tier iterations; golden at most 810. Each may issue up to two public commands, plus bounded fixed setup/cast/replay commands. Declared upper bounds are 4,000 public commands, 2,000 combats, and 50,000 checks across both cases; exhaustion fails. These are preparation limits, not observed counts or inherited historical totals.
