"""New second-loss pure-data validator, never native gameplay evidence by itself.
No IO, no mutation. Native file authentication is the separately sealed runner's job.
"""
from copy import deepcopy
from collections import Counter
import json,hashlib,re
CASES=['normal_tidecaller_lifecycle','golden_tidecaller_lifecycle']
LABELS=['non_murloc_control','shop_non_murloc_control','board_murloc','source_self','shop_murloc','repeat_board_murloc']
SAVES=['genuine setup immediately before actual targeted hand casts','first execution all six actual casts and permanent recipient grants native roundtrip','deterministic replay all six actual casts and permanent recipient grants native roundtrip','permanent next-turn result native roundtrip']
FIELDS=['schema_version','rules_version','execution_fingerprint','room','state','pool','spell_pool','rng_seed','rng_state','next_uid','events','command_log','last_combats']
RECONSTRUCTION='new_second_loss_20261104T0901Z_not_original_artifact'
CONTRACT_SHA256='3c3bf6200814b81e714efdd887491a125d9a2d7377c7434491b2129f006da331'
FORTIFY=[{'type':'spell_buff','scope':'target','attack':0,'health':3,'allow_shop':True,'temporary':False},{'type':'spell_keyword','scope':'target','keyword':'taunt','allow_shop':True,'temporary':False}]
CAST_FIELDS={'scenario','label','spell_uid','spell_id','source_uid','source_id','target_zone','target_uid','triggered','grant_attack','grant_health','eligible_owned_uids','expected_program_applications','fortify_applications','command_sequence','command','before_owned','after_owned'}
LIMITATIONS=[
'Pure snapshots cannot independently prove complete paid acquisition or the original three purchased UIDs; sealed public harness/native assertions/strict runner receipts are required.',
'Per-cast opponent and native pools are not recorded as full snapshots; native setup/active boundaries are checked independently, while intracast isolation relies on sealed harness assertions.',
'First-execution next-turn full 13-field snapshot is not a separate saved artifact; the final replay equality assertion is required in the native harness.',
'Aggregate +3/+4 or +6/+8 is not a count of internal buff calls. expected_program_applications is a source-program expectation. Combat secondary listeners remain held.'
]
def require(ok,msg):
 if not ok: raise ValueError(msg)
def canonical(x):
 try:return json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False)
 except (TypeError,ValueError) as e:raise ValueError('non-finite or invalid JSON') from e
def equal(a,b):return canonical(a)==canonical(b)
def integer(x):return type(x) is int
def sha(x):return isinstance(x,str) and re.fullmatch('[0-9a-f]{64}',x) is not None
def program(golden):return [{'type':'on_target_spell_hand_buff','target_scope':'tribe','target_tribe':'鱼人','scope':'board_and_hand','tribe':'鱼人','attack':6 if golden else 3,'health':8 if golden else 4}]
def fish(card):return card.get('kind','minion')=='minion' and '鱼人' in card.get('tribes',[])
def zeroed(zone):
 out=deepcopy(zone)
 for card in out:card['blood_gems_received_turn']=0
 return out
def totals(doc):
 out={f'minion:{k}':v for k,v in doc['pool'].items()}
 out.update({f'spell:{k}':v for k,v in doc['spell_pool'].items()})
 for p in doc['state']['players']:
  for z in ['board','hand','shop']:
   for b in p[z]:
    n=b.get('pool_count',0);require(integer(n) and n>=0,'invalid stock entitlement')
    if n:
     key=('spell:' if b.get('pool_kind')=='spell' else 'minion:')+b['pool_id'];out[key]=out.get(key,0)+n
 return out
def bodies(doc):
 seen=[]
 for p in doc['state']['players']:
  for z in ('board','hand','shop'):
   require(isinstance(p[z],list),'native zone must be list')
   for u in p[z]:
    require(isinstance(u,dict) and isinstance(u.get('uid'),str) and u['uid'],'native body UID required');seen.append(u['uid'])
 require(len(seen)==len(set(seen)),'duplicate native zone UID')
def _validate(report,contract,context):
 """Validate supplementary observations. Returns zero standalone/native credit."""
 canonical([report,contract,context])
 require(hashlib.sha256(canonical(contract).encode()).hexdigest()==CONTRACT_SHA256,'contract seal mismatch')
 require(report.get('status')==contract['success'] and report.get('failures')==0,'failed/incomplete report')
 require(report.get('reconstruction')==RECONSTRUCTION and report.get('historical_acceptance_credit')==0,'reconstruction status mismatch')
 require(equal(report.get('completed_cases'),CASES) and equal(report.get('required_cases'),CASES),'two ordered cases required')
 fp=context.get('execution_fingerprint');require(sha(fp) and report.get('execution_fingerprint')==fp,'execution fingerprint mismatch')
 require(sha(context.get('source_manifest_sha256')),'source seal missing')
 require(equal(context.get('save_fields'),FIELDS),'13 field context required')
 for name in ('checks','commands','combats'):
  require(isinstance(report.get(name),list),'missing report '+name)
  lo,hi=contract['adaptive_bounds'][name];require(lo<=len(report[name])<=hi,'bounded '+name)
 require(all(c.get('passed') is True for c in report['checks']),'native check failed')
 counts=Counter((c.get('scenario'),c.get('label')) for c in report['checks'])
 for row in contract['mandatory_labels']:require(counts[(row['scenario'],row['label'])]==row['count'],'missing/duplicate semantic receipt '+row['label'])
 require(all(c.get('expected_ok') is True and c.get('result',{}).get('ok') is True for c in report['commands']),'rejected command')
 require(report.get('failure_snapshots')==[],'failure snapshot present')
 casts=report.get('casts');loads=report.get('loads')
 require(isinstance(casts,list) and len(casts)==24,'24 actual casts required')
 require(isinstance(loads,list) and len(loads)==8,'8 actual native loads required')
 require(equal([(x['scenario'],x['label']) for x in loads],[(c,s) for c in CASES for s in SAVES]),'native load order mismatch')
 docs=context.get('native_save_documents',{});meta=context.get('native_save_metadata',{})
 require(set(docs)==set(CASES) and set(meta)==set(CASES),'save case domain')
 paths=[]
 cast_commands=[x for x in report['commands'] if x.get('label','').startswith('actual targeted Fortify ')]
 require(len(cast_commands)==24,'cast command receipt count')
 for ci,case in enumerate(CASES):
  golden=ci==1;source_id='BG36_704_G' if golden else 'BG36_704';ga,gh=(6,8) if golden else (3,4)
  require(equal(report.get('counters_by_case',{}).get(case),contract['counters']),'exact counters')
  require(set(docs[case])==set(SAVES) and set(meta[case])==set(SAVES),'save stage domain')
  ds=[docs[case][s] for s in SAVES]
  for si,doc in enumerate(ds):
   require(set(doc)==set(FIELDS) and doc['execution_fingerprint']==fp,'complete native 13-field fingerprint')
   require(len(doc['state']['players'])==2,'two native players');bodies(doc)
   m=meta[case][SAVES[si]];path=m.get('path')
   require(isinstance(path,str) and path.startswith('/') and path==loads[ci*4+si]['path'],'native path metadata')
   require(sha(m.get('sha256')) and integer(m.get('bytes')) and m['bytes']>0,'native raw-byte metadata')
   paths.append(path)
   for f in ('schema_version','rules_version','room'):require(equal(doc[f],ds[0][f]),'immutable save field '+f)
  setup,active,replay,final=ds
  require(equal(active,replay),'six-cast full 13-field replay')
  require(all(equal(totals(d),totals(setup)) for d in ds),'complete stock conservation at saved boundaries')
  p=setup['state']['players'][0];other=setup['state']['players'][1]
  require(p['tier']==5 and not other['board'] and len(other['hand'])==1 and other['hand'][0]['card_id']=='BG22_202','setup tiers/opponent hand')
  sources=[u for u in p['board'] if u['card_id']==source_id];require(len(sources)==1,'one actual board source')
  source=sources[0];suid=source['uid']
  require(source.get('golden') is golden and source.get('pool_id')=='BG36_704' and source.get('pool_count')==(3 if golden else 1),'source genuine entitlement')
  require((source['attack'],source['health'],source['max_health'])==((12,18,18) if golden else (6,9,9)) and equal(source['effects'],program(golden)),'source body/program')
  for zone in ('board','hand'):
   for cid in ('BG22_202','BGS_119'):require(sum(u['card_id']==cid for u in p[zone])==1,'exact owned controls')
  spells=[u for u in p['hand'] if u['card_id']=='BG28_503'];require(len(spells)==6,'six real hand spells')
  rewards=[u for u in p['hand'] if u['card_id']=='__triple_reward'];require(len(rewards)==int(golden),'reward timing/domain')
  if golden:require(equal(rewards[0]['effects'],[{'type':'spell_discover','tier':6}]),'native tier6 reward')
  rows=casts[ci*12:ci*12+12];require(equal(rows[:6],rows[6:]),'full six/six cast replay')
  require(equal(rows[0]['before_owned'],p) and equal(rows[5]['after_owned'],active['state']['players'][0]),'casts bind actual save owner boundaries')
  require(equal(active['state']['players'][1],other),'opponent full state unchanged during casts')
  require(equal(setup['pool'],active['pool']) and equal(setup['spell_pool'],active['spell_pool']),'pools unchanged through six casts')
  require(active['state']['command_sequence']==setup['state']['command_sequence']+6,'six actual native sequence increments')
  require(equal(active['command_log'][:-6],setup['command_log']),'native command prefix')
  consumed=[];first_tad=None
  for k,row in enumerate(rows[:6]):
   require(set(row)==CAST_FIELDS and row['scenario']==case and row['label']==LABELS[k],'exact cast schema/order')
   before=row['before_owned'];after=row['after_owned'];cmd=row['command'];zone=row['target_zone']
   require(zone==(['board','shop','board','board','shop','board'][k]),'target zone')
   require(set(cmd)=={'type','index','target','target_zone'} and cmd['type']=='play' and cmd['target_zone']==zone,'actual targeted command')
   require(integer(cmd['index']) and integer(cmd['target']) and 0<=cmd['index']<len(before['hand']) and 0<=cmd['target']<len(before[zone]),'real source/target indices')
   spell=before['hand'][cmd['index']];target=before[zone][cmd['target']]
   require(spell['uid']==row['spell_uid'] and spell['card_id']==row['spell_id']=='BG28_503','consumed genuine spell UID')
   require(spell.get('cost')==1 and spell.get('pool_count')==0 and equal(spell.get('effects'),FORTIFY),'Fortify exact native two-leaf program')
   require(target['uid']==row['target_uid'] and target['card_id']==(['BGS_119','BGS_119','BG22_202',source_id,'BG22_202','BG22_202'][k]),'actual target card/UID')
   require(row['source_uid']==suid and row['source_id']==source_id,'source binding')
   trigger=k>=2;require(row['triggered'] is trigger and fish(target)==trigger,'real Murloc trigger')
   require(integer(row['grant_attack']) and integer(row['grant_health']) and (row['grant_attack'],row['grant_health'])==((ga,gh) if trigger else (0,0)),'exact normal/golden grant vector')
   require(type(row['expected_program_applications']) is int and row['expected_program_applications']==int(trigger) and type(row['fortify_applications']) is int and row['fortify_applications']==1,'expected program and Fortify cardinality')
   expected=deepcopy(before);del expected['hand'][cmd['index']]
   t=expected[zone][cmd['target']];t['health']+=3;t['max_health']+=3
   for key in ('keywords','permanent_keywords'):
    t.setdefault(key,[])
    if 'taunt' not in t[key]:t[key].append('taunt')
   eligible=[]
   for oz in ('board','hand'):
    for u in expected[oz]:
     if fish(u):
      eligible.append(u['uid'])
      if trigger:u['attack']+=ga;u['health']+=gh;u['max_health']+=gh
   require(len(eligible)==3 and equal(row['eligible_owned_uids'],eligible),'owned recipient domain')
   for oz in ('board','hand','shop'):require(equal(after[oz],expected[oz]),'whole '+oz+' exact bodies')
   require(after['gold']==before['gold'] and after['stats']['spells']==before['stats']['spells']+1,'one cast cost/counter')
   require(all(not u.get('temporary_buffs',[]) for oz in ('board','hand') for u in after[oz]),'permanent empty temporary ledgers')
   if k:require(equal(before,rows[k-1]['after_owned']),'cast trace continuity')
   if k==2:first_tad=target['uid']
   if k==3:require(target['uid']==suid,'self target exact UID')
   if k==5:require(target['uid']==first_tad and 'taunt' in target['keywords'] and 'taunt' in target.get('permanent_keywords',[]),'repeat same already-Taunt target')
   seq=setup['state']['command_sequence']+k+1;require(integer(row['command_sequence']) and row['command_sequence']==seq,'cast actual sequence')
   native=active['command_log'][-6+k]
   require(native=={'command':cmd,'origin':'human','player':0,'round':setup['state']['round'],'sequence':seq},'native actual command tail')
   for offset in (0,6):
    public=cast_commands[ci*12+offset+k]
    require(public['scenario']==case and public['label']=='actual targeted Fortify '+LABELS[k] and public['player']==0 and equal(public['command'],cmd),'public cast command binding')
   consumed.append(spell['uid'])
  require(len(set(consumed))==6,'six distinct spells consumed')
  require(final['state']['round']==active['state']['round']+1,'native next round')
  for player in (0,1):
   for zone in ('board','hand'):
    expected=zeroed(active['state']['players'][player][zone])
    require(equal(final['state']['players'][player][zone],expected),'next turn permanent '+zone)
    label=f'next turn owner {player} whole {zone} permanent with native zero counter'
    receipts=[x for x in report['checks'] if x['scenario']==case and x['label']==label]
    require(len(receipts)==2 and all(equal(x.get('detail',{}).get('expected'),expected) and equal(x.get('detail',{}).get('actual'),expected) for x in receipts),'actual next turn observed dictionaries')
  shop={u['uid']:u for u in final['state']['players'][0]['shop']}
  for u in zeroed(active['state']['players'][0]['shop']):require(equal(shop.get(u['uid']),u),'frozen actual shop body')
  combats=[x for x in report['combats'] if x.get('scenario')==case and x.get('acquisition') is False]
  require(len(combats)==2 and equal(combats[0],combats[1]) and equal(final['last_combats'],[combats[0]['result']]),'actual next turn combat replay')
  require(not combats[0]['result'].get('error') and all(x.get('event')!='combat_spell_completed' for x in combats[0]['result'].get('log',[])),'secondary combat route remains held')
 require(len(paths)==len(set(paths)),'eight unique native paths')
 return {'status':'passed_pure_data_tidecaller_postvalidation_only','observed_casts_checked':24,'native_save_documents_checked':8,'native_fields_per_save':13,'historical_acceptance_credit':0,'standalone_gameplay_credit':0,'execution_fingerprint':fp,'source_manifest_sha256':context['source_manifest_sha256'],'limitations':LIMITATIONS.copy()}

def validate(report,contract,context):
 """Return supplementary result or ValueError. Never modifies the inputs."""
 try:return _validate(report,contract,context)
 except (KeyError,TypeError,IndexError,AttributeError) as exc:raise ValueError("malformed or missing evidence: "+str(exc)) from exc
