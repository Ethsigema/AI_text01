"""Fabricated in-memory unit fixtures only. Never native evidence; no save files written."""
import unittest,json
from pathlib import Path
from copy import deepcopy
from tidecaller_report_validator import validate,CASES,LABELS,SAVES,FIELDS,FORTIFY,program,zeroed
ROOT=Path(__file__).resolve().parent

def fixture():
 contract=json.loads((ROOT/'harness_contract.json').read_text())
 fp='a'*64
 report=dict(status=contract['success'],failures=0,reconstruction=contract['reconstruction'],historical_acceptance_credit=0,execution_fingerprint=fp,completed_cases=CASES.copy(),required_cases=CASES.copy(),checks=[],commands=[],combats=[],casts=[],loads=[],failure_snapshots=[],counters_by_case={})
 context=dict(native_save_documents={},native_save_metadata={},execution_fingerprint=fp,save_fields=FIELDS.copy(),source_manifest_sha256='b'*64)
 def body(uid,cid,fish=False):
  return dict(uid=uid,card_id=cid,kind='minion',tribes=['鱼人'] if fish else ['元素'],attack=2,health=2,max_health=2,keywords=[],permanent_keywords=[],temporary_buffs=[],pool_id=cid,pool_count=1,effects=[],golden=False)
 for ci,case in enumerate(CASES):
  golden=ci==1;prefix=str(ci)+'_';source_id='BG36_704_G' if golden else 'BG36_704';ga,gh=(6,8) if golden else (3,4)
  source=body(prefix+'source',source_id,True);source.update(attack=12 if golden else 6,health=18 if golden else 9,max_health=18 if golden else 9,effects=program(golden),golden=golden,pool_id='BG36_704',pool_count=3 if golden else 1)
  tad=body(prefix+'tad','BG22_202',True);cyc=body(prefix+'cyclone','BGS_119');held=body(prefix+'held','BG22_202',True);heldcyc=body(prefix+'heldcyc','BGS_119');st=body(prefix+'st','BG22_202',True);sc=body(prefix+'sc','BGS_119');other=body(prefix+'other','BG22_202',True)
  spells=[dict(uid=prefix+'spell'+str(i),card_id='BG28_503',kind='spell',cost=1,pool_count=0,effects=deepcopy(FORTIFY)) for i in range(6)]
  hand=[held,heldcyc]+spells
  if golden:hand.append(dict(uid=prefix+'reward',card_id='__triple_reward',kind='spell',cost=0,effects=[dict(type='spell_discover',tier=6)]))
  owner=dict(tier=5,board=[cyc,source,tad],hand=hand,shop=[st,sc],gold=7,stats=dict(spells=0),health=60,armor=0,ready=False,frozen=False)
  enemy=dict(tier=2,board=[],hand=[other],shop=[],gold=7,stats=dict(spells=0),health=60,armor=0,ready=False,frozen=False)
  setup=dict(schema_version=1,rules_version='fixture-not-native',execution_fingerprint=fp,room={'fixture_only':True},state=dict(players=[deepcopy(owner),deepcopy(enemy)],round=20,command_sequence=100,phase='recruit'),pool={'BG36_704':4,'BG22_202':4,'BGS_119':4},spell_pool={'BG28_503':10},rng_seed='1',rng_state='2',next_uid=100,events=[],command_log=[],last_combats=[])
  active=deepcopy(setup);rows=[];cmds=[]
  target_uids=[cyc['uid'],sc['uid'],tad['uid'],source['uid'],st['uid'],tad['uid']]
  zones=['board','shop','board','board','shop','board']
  for k in range(6):
   old=deepcopy(owner);zone=zones[k];si=next(i for i,u in enumerate(old['hand']) if u['uid']==spells[k]['uid']);ti=next(i for i,u in enumerate(old[zone]) if u['uid']==target_uids[k]);cmd=dict(type='play',index=si,target=ti,target_zone=zone)
   del owner['hand'][si];target=owner[zone][ti];target['health']+=3;target['max_health']+=3
   for key in ('keywords','permanent_keywords'):
    if 'taunt' not in target[key]:target[key].append('taunt')
   eligible=[]
   for oz in ('board','hand'):
    for u in owner[oz]:
     if u.get('kind')=='minion' and '鱼人' in u.get('tribes',[]):
      eligible.append(u['uid'])
      if k>=2:u['attack']+=ga;u['health']+=gh;u['max_health']+=gh
   owner['stats']['spells']+=1
   rows.append(dict(scenario=case,label=LABELS[k],spell_uid=spells[k]['uid'],spell_id='BG28_503',source_uid=source['uid'],source_id=source_id,target_zone=zone,target_uid=target_uids[k],triggered=k>=2,grant_attack=ga if k>=2 else 0,grant_health=gh if k>=2 else 0,eligible_owned_uids=eligible,expected_program_applications=int(k>=2),fortify_applications=1,command_sequence=101+k,command=deepcopy(cmd),before_owned=old,after_owned=deepcopy(owner)))
   cmds.append(dict(scenario=case,label='actual targeted Fortify '+LABELS[k],player=0,command=deepcopy(cmd),result=dict(ok=True),before_round=20,after_round=20,phase='recruit',expected_ok=True))
   active['command_log'].append(dict(command=deepcopy(cmd),origin='human',player=0,round=20,sequence=101+k))
  active['state']['players'][0]=deepcopy(owner);active['state']['command_sequence']=106
  final=deepcopy(active);final['state']['round']=21
  for p in final['state']['players']:
   for zone in ('board','hand','shop'):p[zone]=zeroed(p[zone])
  result=dict(error='',log=[dict(event='fixture_not_native')],winner=0)
  final['last_combats']=[result]
  report['combats'] += [dict(scenario=case,round=20,acquisition=False,result=deepcopy(result)) for _ in range(2)]
  report['casts']+=rows+deepcopy(rows);report['commands']+=cmds+deepcopy(cmds)
  report['counters_by_case'][case]=deepcopy(contract['counters'])
  context['native_save_documents'][case]=dict(zip(SAVES,[setup,active,deepcopy(active),final]));context['native_save_metadata'][case]={}
  for i,s in enumerate(SAVES):
   path=f'/fabricated-unit-fixture-never-written/{ci}_{i}.json';report['loads'].append(dict(scenario=case,label=s,path=path));context['native_save_metadata'][case][s]=dict(path=path,sha256='c'*64,bytes=100)
 for r in contract['mandatory_labels']:
  detail=None
  if r['label'].startswith('next turn owner '):
   words=r['label'].split();player=int(words[3]);zone=words[5];d=context['native_save_documents'][r['scenario']][SAVES[3]]['state']['players'][player][zone];detail=dict(expected=deepcopy(d),actual=deepcopy(d))
  for _ in range(r['count']):report['checks'].append(dict(scenario=r['scenario'],label=r['label'],passed=True,detail=deepcopy(detail)))
 return report,contract,context

def setat(obj,path,val):
 for k in path[:-1]:obj=obj[k]
 obj[path[-1]]=val

def mutations():
 # Every mutation starts from the same fabricated consistent fixture. No native files.
 C=CASES[0];G=CASES[1];D=['native_save_documents',C];M=['native_save_metadata',C]
 return [
 ('contract tamper','c',['success'],'forged'),
 ('missing cast','r',['casts'],[]),
 ('wrong case','r',['casts',0,'scenario'],'foreign'),
 ('wrong order label','r',['casts',0,'label'],'source_self'),
 ('missing snapshot','r',['casts',0,'before_owned'],{}),
 ('wrong target UID','r',['casts',0,'target_uid'],'wrong'),
 ('wrong target zone','r',['casts',0,'target_zone'],'shop'),
 ('boolean index','r',['casts',0,'command','index'],True),
 ('non Murloc trigger','r',['casts',0,'triggered'],True),
 ('old symmetric vector','r',['casts',2,'grant_health'],3),
 ('gold half vector','r',['casts',14,'grant_attack'],3),
 ('double grant','r',['casts',2,'after_owned','board',1,'attack'],99),
 ('unknown unit field altered','r',['casts',0,'after_owned','board',1,'new_wrong_field'],1),
 ('shop source grant','r',['casts',4,'after_owned','shop',0,'attack'],99),
 ('hand non Murloc buff','r',['casts',2,'after_owned','hand',1,'attack'],99),
 ('cast charged twice','r',['casts',0,'after_owned','gold'],5),
 ('cast counted twice','r',['casts',0,'after_owned','stats','spells'],2),
 ('missing recipient','r',['casts',2,'eligible_owned_uids'],[]),
 ('temporary grant','r',['casts',2,'after_owned','board',1,'temporary_buffs'],[{'attack':3}]),
 ('replay row changed','r',['casts',6,'command_sequence'],999),
 ('wrong public command','r',['commands',0,'command','target'],999),
 ('failed native check','r',['checks',0,'passed'],False),
 ('missing semantic check','r',['checks'],[]),
 ('foreign fingerprint','x',['execution_fingerprint'],'d'*64),
 ('missing source seal','x',['source_manifest_sha256'],''),
 ('extra native field','x',D+[SAVES[0],'extra'],1),
 ('missing native document','x',D+[SAVES[0]],{}),
 ('foreign save path','x',M+[SAVES[0],'path'],'/foreign'),
 ('bad byte hash','x',M+[SAVES[0],'sha256'],'bad'),
 ('boolean byte count','x',M+[SAVES[0],'bytes'],True),
 ('wrong next round','x',D+[SAVES[3],'state','round'],22),
 ('lost next turn health','x',D+[SAVES[3],'state','players',0,'board',1,'health'],1),
 ('other owner changed','x',D+[SAVES[1],'state','players',1,'hand',0,'attack'],99),
 ('stock lost','x',D+[SAVES[3],'pool','BG36_704'],0),
 ('next turn missing zero','x',D+[SAVES[3],'state','players',0,'board',0,'blood_gems_received_turn'],None),
 ('replay RNG changed','x',D+[SAVES[2],'rng_state'],'999'),
 ('combat secondary route','r',['combats',0,'result','log'],[dict(event='combat_spell_completed')]),
 ('duplicate save label','r',['loads',1,'label'],SAVES[0]),
 ('wrong counter','r',['counters_by_case',C,'actual_hand_casts'],13),
 ('nonfinite value','r',['casts',0,'grant_health'],float('nan')),
 ('wrong native command sequence','x',D+[SAVES[1],'command_log',0,'sequence'],999),
 ('wrong golden reward','x',['native_save_documents',G,SAVES[0],'state','players',0,'hand',8,'effects'],[])
 ]

class ValidatorTests(unittest.TestCase):
 def test_positive_is_pure(self):
  r,c,x=fixture();before=deepcopy([r,c,x]);answer=validate(r,c,x)
  self.assertEqual([r,c,x],before);self.assertEqual(answer['observed_casts_checked'],24);self.assertEqual(answer['standalone_gameplay_credit'],0)
 def test_42_mutations(self):
  ms=mutations();self.assertEqual(len(ms),42)
  for name,which,path,val in ms:
   with self.subTest(name=name):
    r,c,x=fixture();setat(dict(r=r,c=c,x=x)[which],path,deepcopy(val))
    with self.assertRaises(ValueError):validate(r,c,x)
if __name__=='__main__':unittest.main(verbosity=2)
