from pathlib import Path
ROOT=Path(__file__).resolve().parent
src=(ROOT/'recovered_murcules_helper.gd').read_text()
funcs={p.split('(',1)[0]:'func '+p.rstrip()+'\n\n' for p in src.split('\nfunc ')[1:]}
names=['check','persist','owner','snapshot','index_uid','index_card','unit','command','roundtrip','buy_minion','play_minion','stock_totals','zone_by_uid','matching_events','refresh_player','acquire','advance','buy_true_triple_player','acquire_fortify_player']
body=''.join(funcs[n] for n in names)
body=body.replace(' and no_removed_identity()','').replace('user://murcules_deadkiller_','user://tidecaller_lifecycle_')
body=body.replace('"phase":game.state.phase})','"phase":game.state.phase,"expected_ok":expect_ok})')
(ROOT/'tidecaller_lifecycle_public.gd').write_text((ROOT/'harness_head.gd.in').read_text()+body+(ROOT/'harness_tail.gd.in').read_text())
