"""Recompute a local rescue seal; no engine, native execution, or external writes."""
from pathlib import Path
import ast,hashlib,json,subprocess,sys
R=Path(__file__).resolve().parent
HISTORICAL={
 'tidecaller_lifecycle_public.gd':'0e08c468dacff527918375092387749be7afea14c8f0c1cd0ab1fd17db03d4bd',
 'harness_contract.json':'b892a7d7a616fc1de72521d78ca4b12df2e5dabfe80f46a401d7b8eef44af413',
 'tidecaller_report_validator.py':'9b01df825cf008072dba7290a67640bedab187709c61a2d3355ab3b588f64d6d',
 'historical_supplement_manifest':'3bd55475016a3faf71e1fe342f574524a6677a64284a600930ff49730ed3148b',
 'historical_tests_manifest':'fb1446014f0ba4f152c457361f577beb7f7116589bb428eacd405f3a83f7315c',
 'historical_harness_review':'3dbb6972e08cf4a65f65e37eae2e8aa6a00e49574694e5648e0cdb3883b5ac27'}
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(name,obj):(R/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
checks=[]
def check(v,label):
 checks.append(dict(label=label,passed=bool(v)))
 if not v:raise SystemExit(label)
for p in R.glob('*.py'):ast.parse(p.read_text());check(True,'Python AST '+p.name)
a=R/'tidecaller_lifecycle_public.gd';c=R/'harness_contract.json';v=R/'tidecaller_report_validator.py'
old=[p.read_bytes() for p in (a,c,v)]
for script in ('build_harness.py','build_contract.py'):subprocess.run([sys.executable,str(R/script)],check=True,env={'PYTHONDONTWRITEBYTECODE':'1'})
check(old==[p.read_bytes() for p in (a,c,v)],'generators reproduce current exact bytes')
s=a.read_text();contract=json.loads(c.read_text())
check(digest(a)==contract['harness_sha256'],'contract binds actual new harness bytes')
check('game._' not in s and 'game.call(' not in s,'no private gameplay method calls')
check(' and no_removed_identity()' not in s,'removed Murcules-only guard not imported')
check('game.apply_command(player,cmd)' in s,'single centralized public command dispatch')
check('owner().gold =' not in s.replace('owner().gold ==',''),'no direct gold injection')
check('game.state.players =' not in s and 'game.pool =' not in s.replace('game.pool ==',''),'no state/pool setup injection')
check('range(30)' in s and 'range(60)' in s and 'range(40)' in s and 'range(100)' in s,'bounded adaptive acquisition loops')
check('originals+[offered.uid]' in s and 'actual third paid normal purchase' in s,'real third purchase and consumed normal UIDs source assertions retained')
check('whole "+key+" dictionaries match exact independent deltas' in s,'entire owned zone dictionary assertions')
check('blood_gems_received_turn = 0' in s,'explicit native next-turn counter transformation')
check('body.pool_count == (3 if golden else 1)' in s,'actual source entitlement check')
check('spell.effects == FORTIFY_PROGRAM' in s,'independent exact two-leaf Fortify program')
check(len(contract['save_fields'])==13 and contract['exact_casts']==24 and contract['exact_loads']==8,'declared new semantic boundaries')
write('STATIC_PREPARATION_CHECKS.json',dict(status='passed_new_static_source_checks_only',checks=checks,engine_run=False,parser_run=False,native_gameplay_credit=0))
comparison=[]
for name,sha in HISTORICAL.items():
 p=R/name;actual=digest(p) if p.is_file() else None
 comparison.append(dict(name=name,historical_sha256=sha,actual_new_sha256=actual,byte_match=actual==sha if actual else None,status='new_reconstruction_differs' if actual and actual!=sha else 'historical_only_original_bytes_unavailable'))
write('HISTORICAL_COMPARISON.json',dict(original_full_source_available=False,original_full_bytes_recovered=False,claim='New semantic reconstruction from retained design and recovered Murcules helper; never original acceptance.',files=comparison))
run=subprocess.run([sys.executable,str(R/'test_tidecaller_report_validator.py')],capture_output=True,text=True,env={'PYTHONDONTWRITEBYTECODE':'1'})
(R/'python_unit_test_output.txt').write_text(run.stdout+run.stderr)
if run.returncode!=0:raise SystemExit('Pure Python unit tests failed; no seal produced.')
write('PYTHON_TEST_RESULTS.json',dict(status='passed_new_pure_data_unit_tests_only',command='PYTHONDONTWRITEBYTECODE=1 python test_tidecaller_report_validator.py',test_methods=2,mutated_fixtures_rejected=42,positive_fixture_passed=True,input_nonmutation_passed=True,fixture_provenance='Fabricated in memory, no native save files written, not a gameplay observation.',engine_run=False,native_gameplay_credit=0,historical_acceptance_credit=0))
files=[]
for p in sorted(R.iterdir()):
 if p.is_file() and p.name!='RESCUE_MANIFEST.json':files.append(dict(path=p.name,bytes=p.stat().st_size,sha256=digest(p)))
write('RESCUE_MANIFEST.json',dict(schema='tidecaller_second_loss_rescue_v1',status='new_code_reconstruction_preparation_only',original_bytes_recovered=False,engine_run=False,native_acceptance=False,historical_acceptance_credit=0,source_tree_modified=False,api='validate(report, contract, context)',context_keys=['native_save_documents','native_save_metadata','execution_fingerprint','save_fields','source_manifest_sha256'],stage_key='Exact report.loads label, nested under scenario',files=files))
print(json.dumps({'files':len(files),'static_checks':len(checks),'harness_sha256':digest(a),'contract_sha256':digest(c),'validator_sha256':digest(v),'manifest_sha256':digest(R/'RESCUE_MANIFEST.json')},indent=2))
