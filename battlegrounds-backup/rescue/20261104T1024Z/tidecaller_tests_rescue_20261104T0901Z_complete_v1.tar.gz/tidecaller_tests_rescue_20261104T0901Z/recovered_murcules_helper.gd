extends SceneTree
## DRAFT ONLY. No engine execution or semantics acceptance is implied.
const OUTPUT = "user://murcules_deadkiller_public_report.json"
const MURC = "BG27_023"
const GOLDEN = "BG27_023_G"
const AVIATOR = "BG34_140"
const TAD = "BG22_202"
const CYCLONE = "BGS_119"
const GOLDEN_CYCLONE = "TB_BaconUps_159"
const PATCHWERK = "TB_BaconShop_HERO_34"
const FORTIFY = "BG28_503"
const FAMILY = "actual-self-kill-hand-buff-v1"
const RNG_PURPOSE = "actual_kill_hand_uniform_minion"
var game_script: GDScript
var room_script: GDScript
var catalog: RefCounted
var game: RefCounted
var stock_baseline: Dictionary = {}
var scenario = "draft_source_contract"
var failures = 0
var acquiring = true
var report = {"status":"not_run","checks":[],"commands":[],"loads":[],"combats":[],"failure_snapshots":[],"completed_cases":[],"scope":"conditional narrow Murcules reciprocal attack-wave candidate, actual public commands only","held":["official survival rule evidence gate pending","independent review and launcher seal pending","arbitrary attributed kills by a dead source","Timewarped Murcules and Morgl dead-source behavior","received-listener combinations","ghost settlement","generated hand recipients","full247 gameplay","official random distribution","inherited predecessor acceptance"]}
func check(ok: bool, label: String, detail: Variant = null) -> bool:
	report.checks.append({"scenario":scenario,"label":label,"passed":ok,"detail":detail})
	print("BASIC_CHECK ", scenario, " | ", label, " | ", ok)
	if not ok:
		failures += 1
		if game != null and not game.state.is_empty(): report.failure_snapshots.append({"scenario":scenario,"label":label,"snapshot":snapshot()})
		persist()
	return ok

func persist() -> void:
	var file: FileAccess = FileAccess.open(OUTPUT,FileAccess.WRITE)
	if file != null: file.store_string(JSON.stringify(report,"  "))

func owner(player: int = 0) -> Dictionary:
	return game.state.players[player]

func snapshot() -> Dictionary:
	return {"schema_version":game_script.SAVE_VERSION,"rules_version":game_script.RULES_VERSION,"execution_fingerprint":game.catalog.execution_fingerprint,"room":game.room.duplicate(true),"state":game.state.duplicate(true),"pool":game.pool.duplicate(true),"spell_pool":game.spell_pool.duplicate(true),"rng_seed":str(game.rng.seed),"rng_state":str(game.rng.state),"next_uid":game.next_uid,"events":game.events.duplicate(true),"command_log":game.command_log.duplicate(true),"last_combats":game.last_combats.duplicate(true)}

func index_uid(zone: String, uid: String, player: int = 0) -> int:
	for i in range(owner(player)[zone].size()):
		if owner(player)[zone][i].get("uid") == uid: return i
	return -1

func index_card(zone: String, identity: String, player: int = 0) -> int:
	for i in range(owner(player)[zone].size()):
		if owner(player)[zone][i].get("card_id") == identity: return i
	return -1

func unit(zone: String, uid: String, player: int = 0) -> Dictionary:
	var i: int = index_uid(zone,uid,player)
	return {} if i < 0 else owner(player)[zone][i]

func command(cmd: Dictionary, label: String, player: int = 0, expect_ok: bool = true) -> bool:
	var before: Dictionary = snapshot()
	var result: Dictionary = game.apply_command(player,cmd)
	report.commands.append({"scenario":scenario,"label":label,"player":player,"command":cmd.duplicate(true),"result":result.duplicate(true),"before_round":before.state.round,"after_round":game.state.round,"phase":game.state.phase})
	if not check(result.get("ok",false) == expect_ok,label + ": expected command result",result): return false
	if not expect_ok:
		if not check(not str(result.get("error","")).is_empty(),label + ": explicit error returned"): return false
		return check(snapshot() == before,label + ": rejected command leaves every persisted field unchanged")
	if not check(game.state.phase != "error",label + ": no engine error phase"): return false
	if not check(game.state.command_sequence == before.state.command_sequence + 1 and game.command_log.size() == before.command_log.size() + 1,label + ": one real command receipt; no bot actions"): return false
	return check(stock_totals() == stock_baseline,label + ": complete native stock conservation") and no_removed_identity()

func roundtrip(label: String) -> bool:
	var before: Dictionary = snapshot()
	var path: String = "user://murcules_deadkiller_" + scenario + "_" + str(report.loads.size()+1) + ".json"
	var saved: int = game.save_to(path)
	if not check(saved == OK,label + ": native save",saved): return false
	if not check(snapshot() == before,label + ": saving does not mutate engine"): return false
	var restored: RefCounted = game_script.new()
	var loaded: int = restored.load_from(path,catalog)
	if not check(loaded == OK,label + ": fresh native load",loaded): return false
	game = restored
	var after: Dictionary = snapshot()
	for field in before:
		if not check(after[field] == before[field],label + ": native roundtrip " + field): return false
	report.loads.append({"scenario":scenario,"label":label,"path":ProjectSettings.globalize_path(path)})
	persist()
	return true

func buy_minion(identity: String, player: int = 0, uid: String = "") -> String:
	var index: int = index_card("shop",identity,player) if uid.is_empty() else index_uid("shop",uid,player)
	if not check(index >= 0,"real minion offer exists " + identity): return ""
	var offered: Dictionary = owner(player).shop[index].duplicate(true)
	var before_gold: int = owner(player).gold
	var before_pool: Dictionary = game.pool.duplicate(true)
	var before_hand: int = owner(player).hand.size()
	if not check(offered.get("pool_id") == identity and offered.get("pool_count") == 1,"offered minion has native stock entitlement"): return ""
	if not command({"type":"buy","index":index},"buy minion " + identity,player): return ""
	var acquired: Dictionary = unit("hand",offered.uid,player)
	if not check(owner(player).gold == before_gold-3 and owner(player).hand.size() == before_hand+1 and not acquired.is_empty() and index_uid("shop",offered.uid,player) == -1,"buy pays three and moves original UID once"): return ""
	if not check(game.pool == before_pool and acquired.get("pool_count") == 1,"buy does not debit reserved minion stock twice"): return ""
	return offered.uid

func play_minion(uid: String, player: int = 0) -> bool:
	var index: int = index_uid("hand",uid,player)
	if not check(index >= 0,"real acquired minion in hand"): return false
	var before: Dictionary = unit("hand",uid,player).duplicate(true)
	var gold: int = owner(player).gold
	var board_size: int = owner(player).board.size()
	if not command({"type":"play","index":index,"position":board_size},"play acquired minion",player): return false
	var after: Dictionary = unit("board",uid,player)
	if not check(not after.is_empty() and index_uid("hand",uid,player) == -1 and owner(player).board.size() == board_size+1 and owner(player).gold == gold,"play moves original UID once without payment"): return false
	for field in ["card_id","attack","health","max_health","keywords","temporary_buffs","permanent_keywords","pool_id","pool_count"]:
		if not check(after.get(field) == before.get(field),"played minion preserves acquired " + field): return false
	return true

func stock_totals() -> Dictionary:
	var totals: Dictionary = {}
	for identity in game.pool: totals["minion:"+str(identity)] = game.pool[identity]
	for identity in game.spell_pool: totals["spell:"+str(identity)] = game.spell_pool[identity]
	for player in game.state.players:
		for body in player.board + player.hand + player.shop:
			var count: int = int(body.get("pool_count",0))
			if count == 0: continue
			var kind: String = "spell" if body.get("pool_kind","") == "spell" else "minion"
			var key: String = kind+":"+str(body.get("pool_id",""))
			totals[key] = int(totals.get(key,0)) + count
	return totals

func stat_delta(after: Dictionary, before: Dictionary, attack: int, health: int, label: String) -> bool:
	if not check(not after.is_empty() and after.uid == before.uid and after.attack == before.attack+attack and after.health == before.health+health and after.max_health == before.max_health+health,label + ": exact native stat delta and same UID"): return false
	for field in ["card_id","keywords","permanent_keywords","temporary_buffs","effects","base_unit"]:
		if not check(after.get(field) == before.get(field),label + ": unchanged " + field): return false
	return true

func zone_by_uid(zone: String, player: int = 0) -> Dictionary:
	var output: Dictionary = {}
	for body in owner(player)[zone]: output[body.uid] = body.duplicate(true)
	return output

func matching_events(entries: Array, name: String, field: String = "", value: Variant = null, name_field: String = "event") -> Array:
	var found: Array = []
	for entry in entries:
		if entry.get(name_field,"") == name and (field.is_empty() or entry.get(field) == value): found.append(entry)
	return found

func no_removed_identity() -> bool:
	if not check(not game.pool.has(AVIATOR) and not game.pool.has(AVIATOR+"_G") and not game.pool.has(GOLDEN),"actual stock excludes Aviator and golden ordinary entries"): return false
	for player in game.state.players:
		for body in player.shop + player.get("discover",[]):
			if not check(body.get("card_id",body.get("id","")) not in [AVIATOR,AVIATOR+"_G",GOLDEN],"native shop/discover never offers removed Aviator or golden Murcules"): return false
	return true

func configure(label: String, with_spell: bool = false, murloc_disabled: bool = false) -> bool:
	scenario = label
	acquiring = true
	var config = room_script.new()
	config.reset(catalog)
	config.data.bot_count = 1
	config.data.seed = 2026110403
	config.data.enabled_minions = [CYCLONE,MURC,TAD]
	config.data.enabled_spells = [FORTIFY] if with_spell else []
	config.data.enabled_heroes = [PATCHWERK]
	config.data.selected_hero = PATCHWERK
	config.data.damage_received_listeners = false
	for key in ["enabled_anomalies","enabled_trinkets","enabled_quests","enabled_rewards"]: config.data[key] = []
	if murloc_disabled:
		config.data.tribe_mode = "manual"
		config.data.selected_tribes = ["elemental"]
	var issues = config.validate(catalog)
	if not check(issues.is_empty(),"bounded current native room admission",issues): return false
	game = game_script.new()
	var result = game.start(config.data,catalog)
	if not check(result.get("ok",false),"fresh actual bounded Game starts",result): return false
	stock_baseline = stock_totals()
	if murloc_disabled:
		if not check(not game.pool.has(MURC) and not game.pool.has(TAD),"Murloc-disabled selected room excludes both fish from actual stock"): return false
	else:
		if not check(stock_baseline.get("minion:"+MURC)==15,"Murcules tier2 stock15 including actual reservations"): return false
	return no_removed_identity()

func reach_both_tier2() -> bool:
	for _step in range(12):
		for player in [0,1]:
			if owner(player).tier == 1 and owner(player).gold >= owner(player).upgrade_cost:
				var old_gold = owner(player).gold
				var price = owner(player).upgrade_cost
				if not check(price == maxi(0,5-(int(game.state.round)-1)),"independent first-upgrade discount quote"): return false
				if not command({"type":"upgrade"},"paid actual tier2 upgrade",player): return false
				if not check(owner(player).tier==2 and owner(player).gold==old_gold-price,"one native tier and exact payment"): return false
		if owner().tier==2 and owner(1).tier==2: return true
		if not advance(): return false
	return check(false,"tier2 acquisition exhausted; never pass on budget exhaustion")

func refresh_player(player: int) -> bool:
	var before = owner(player).duplicate(true)
	var cost = 0 if before.free_rolls > 0 else 1
	if not command({"type":"roll"},"real paid bounded acquisition roll",player): return false
	return check(owner(player).gold == before.gold-cost and owner(player).board == before.board and owner(player).hand == before.hand,"refresh pays native price and leaves owned cards alone")

func acquire(identity: String, player: int = 0) -> String:
	for _step in range(60):
		if index_card("shop",identity,player)>=0 and owner(player).gold>=3: return buy_minion(identity,player)
		if owner(player).gold>=4:
			if not refresh_player(player): return ""
		elif not advance(): return ""
	check(false,"bounded real purchase unavailable; no synthetic offer",identity)
	return ""

func advance() -> bool:
	var round_before: int = game.state.round
	var hp_before: Array = [owner().health,owner(1).health,owner().armor,owner(1).armor]
	if acquiring and not check(owner().board.is_empty() and owner(1).board.is_empty(),"acquisition combat starts with both actual boards empty"): return false
	if not owner(1).ready:
		if not command({"type":"end_turn"},"ready real opponent",1): return false
	if not command({"type":"end_turn"},"resolve actual end_turn"): return false
	if not check(game.state.round==round_before+1 and game.state.phase=="recruit" and owner().alive and owner(1).alive and not owner().ready,"actual combat returns to next active recruit"): return false
	if not check(game.last_combats.size()==1 and game.last_combats[0].get("error","")=="","one successful full Game combat"): return false
	if acquiring:
		var c: Dictionary=game.last_combats[0]
		if not check(c.winner==-1 and c.left.is_empty() and c.right.is_empty() and hp_before==[owner().health,owner(1).health,owner().armor,owner(1).armor],"acquisition ties preserve both hero resources without resetting anything"): return false
		for e in c.log:
			if not check(e.get("event") not in ["attack","damage","death","hand_buff"],"no unrelated acquisition combat hazard"): return false
	report.combats.append({"scenario":scenario,"round":round_before,"acquisition":acquiring,"result":game.last_combats[0].duplicate(true)})
	return true

func buy_true_triple_player(identity: String,golden_id: String,player: int) -> String:
	var originals: Array=[]
	for _i in range(2):
		var uid: String=acquire(identity,player)
		if uid.is_empty(): return ""
		originals.append(uid)
	for _step in range(60):
		if index_card("shop",identity,player)>=0 and owner(player).gold>=3: break
		if owner(player).gold>=4:
			if not refresh_player(player): return ""
		elif not advance(): return ""
	var i: int=index_card("shop",identity,player)
	if not check(i>=0 and owner(player).gold>=3,"real affordable third normal offer for owner "+str(player)): return ""
	var offered: Dictionary=owner(player).shop[i].duplicate(true)
	var before: Dictionary=snapshot()
	if not command({"type":"buy","index":i},"actual third paid normal purchase",player): return ""
	var gi: int=index_card("hand",golden_id,player)
	if not check(gi>=0 and owner(player).gold==before.state.players[player].gold-3 and game.pool==before.pool,"real owner-specific triple payment and reserved stock"): return ""
	var golden: Dictionary=owner(player).hand[gi]
	if not check(golden.golden and golden.pool_id==identity and golden.pool_count==3,"native golden has three-copy stock entitlement"): return ""
	for uid in originals+[offered.uid]:
		if not check(index_uid("hand",uid,player)<0 and index_uid("board",uid,player)<0 and index_uid("shop",uid,player)<0,"each genuine ordinary UID consumed once for exact owner"): return ""
	var triples: Array=[]
	for event in game.events.slice(before.events.size()):
		if event.get("type")=="triple": triples.append(event)
	if not check(triples.size()==1 and triples[0].player==player and triples[0].card_id==golden_id,"one new triple receipt attributed to actual owner"): return ""
	if not check(owner(1-player).hand==before.state.players[1-player].hand and owner(1-player).board==before.state.players[1-player].board,"tripling one owner never consumes the other owner's cards"): return ""
	return golden.uid

func acquire_fortify_player(player: int) -> String:
	for _step in range(40):
		var i: int=index_card("shop",FORTIFY,player)
		if i>=0 and owner(player).gold>=1:
			var offered: Dictionary=owner(player).shop[i].duplicate(true)
			var before: Dictionary=snapshot()
			if not check(offered.cost==1 and offered.tier==1 and offered.pool_kind=="spell" and offered.pool_count==1,"genuine Fortify cost, tier and reservation"): return ""
			if not command({"type":"buy","index":i},"buy real Fortify for exact owner",player): return ""
			var acquired: Dictionary=unit("hand",offered.uid,player)
			if not check(not acquired.is_empty() and acquired.pool_count==0 and owner(player).gold==before.state.players[player].gold-1 and game.spell_pool[FORTIFY]==before.spell_pool[FORTIFY]+1,"actual Fortify payment and reservation release"): return ""
			return offered.uid
		if owner(player).gold>=2:
			if not refresh_player(player): return ""
		elif not advance(): return ""
	check(false,"bounded real Fortify unavailable; never synthesize")
	return ""

func cast_fortify_player(spell_uid: String,target_uid: String,player: int) -> bool:
	var i: int=index_uid("hand",spell_uid,player)
	var target: int=index_uid("board",target_uid,player)
	if not check(i>=0 and target>=0 and unit("hand",spell_uid,player).card_id==FORTIFY,"Fortify binds genuine acquired source and owner target UIDs"): return false
	var before: Dictionary=snapshot()
	var old_body: Dictionary=unit("board",target_uid,player).duplicate(true)
	if not command({"type":"play","index":i,"target":target,"target_zone":"board"},"cast purchased Fortify on actual owner board",player): return false
	if not check(index_uid("hand",spell_uid,player)<0 and owner(player).hand.size()==before.state.players[player].hand.size()-1 and owner(player).gold==before.state.players[player].gold and owner(player).stats.spells==before.state.players[player].stats.spells+1 and game.spell_pool==before.spell_pool,"one actual cast consumes source without extra cost or stock return"): return false
	var expected_body: Dictionary=old_body.duplicate(true)
	expected_body.health+=3
	expected_body.max_health+=3
	if "taunt" not in expected_body.keywords: expected_body.keywords.append("taunt")
	if not expected_body.has("permanent_keywords"): expected_body.permanent_keywords=[]
	if "taunt" not in expected_body.permanent_keywords: expected_body.permanent_keywords.append("taunt")
	return check(unit("board",target_uid,player)==expected_body,"actual Fortify is exact +0/+3 and permanent Taunt, with every other field preserved")

func hand_domain(before: Dictionary) -> Array:
	var result: Array=[]
	for uid in before:
		if before[uid].get("kind","minion")=="minion": result.append(uid)
	return result

func player_for_side(combat: Dictionary,side: int) -> int:
	return int(combat.left_player if side==0 else combat.right_player)

func death_for(log: Array,uid: String) -> Dictionary:
	var found: Array=matching_events(log,"death","unit",uid)
	if not check(found.size()==1,"exactly one removed-death receipt for "+uid): return {}
	return found[0]

func lethal_for(log: Array,source: String,target: String) -> Dictionary:
	var found: Array=[]
	for e in log:
		if e.get("event")=="damage" and e.get("source")==source and e.get("target")==target and int(e.get("health",1))<=0: found.append(e)
	if not check(found.size()==1,"exactly one genuine lethal packet from source to victim"): return {}
	return found[0]

func verify_reciprocal_wave(source: String,victim: String) -> bool:
	var log: Array=game.last_combats[0].log
	var a: Dictionary=lethal_for(log,source,victim)
	var b: Dictionary=lethal_for(log,victim,source)
	var sd: Dictionary=death_for(log,source)
	var vd: Dictionary=death_for(log,victim)
	if a.is_empty() or b.is_empty() or sd.is_empty() or vd.is_empty(): return false
	var ai: int=int(a.get("attack_sequence",-1))
	if not check(ai>=0 and ai<log.size() and b.get("attack_sequence")==ai and a.sequence>ai and b.sequence>ai,"reciprocal fatal packets share one authentic attack exchange"): return false
	var attack: Dictionary=log[ai]
	var attack_kind: bool=a.kind=="attack" and b.kind=="retaliation" and attack.attacker==source and attack.target==victim
	var retaliation_kind: bool=a.kind=="retaliation" and b.kind=="attack" and attack.attacker==victim and attack.target==source
	if not check(attack.event=="attack" and (attack_kind or retaliation_kind),"opposite packet kinds and UIDs match the one actual attack receipt"): return false
	if not check(a.health_before>0 and b.health_before>0 and a.health<=0 and b.health<=0,"both reciprocal packets independently cross to lethal health"): return false
	if not check(vd.killer_id==a.source_combat_id and sd.killer_id==b.source_combat_id and a.sequence<vd.sequence and b.sequence<sd.sequence,"both removed deaths retain opposite source combat-ID attribution"): return false
	var earliest_death: int=mini(sd.sequence,vd.sequence)
	if not check(a.sequence<earliest_death and b.sequence<earliest_death,"both packets finish before either removal in this exchange"): return false
	for e in log:
		if int(e.sequence)>ai and int(e.sequence)<maxi(sd.sequence,vd.sequence) and e.get("event")=="attack":
			return check(false,"no second attack can interleave reciprocal removal")
	for e in log:
		if e.get("kill_hand_family")==FAMILY and e.get("source") in [source,victim]:
			if not check(e.sequence>sd.sequence and e.sequence>vd.sequence,"both same-wave source and victim are removed before grant"): return false
	return true

func verify_grants(before_hands: Array,expected: Array) -> bool:
	var combat: Dictionary=game.last_combats[0]
	var log: Array=combat.log
	var sources: Dictionary={}
	var counts: Dictionary={}
	var increments: Array=[{},{}]
	var eligible: Array=[hand_domain(before_hands[0]),hand_domain(before_hands[1])]
	for player in [0,1]:
		for uid in eligible[player]: increments[player][uid]=0
	for source in expected:
		sources[source.uid]=source
		counts[source.uid]=[]
	var rngs: Array=[]
	for e in log:
		if e.get("event")=="rng" and e.get("purpose")==RNG_PURPOSE: rngs.append(e)
	var used_rng: Array=[]
	var grant_count: int=0
	for e in log:
		if e.get("kill_hand_family")!=FAMILY: continue
		grant_count+=1
		if not check(e.event=="hand_buff" and sources.has(e.source),"grant belongs only to an expected actual Murcules source"): return false
		var source: Dictionary=sources[e.source]
		var player: int=int(source.owner)
		if not check(e.source_id==source.card_id and player_for_side(combat,e.side)==player and e.killed_uid in source.victims and e.killed_uid not in counts[source.uid],"source identity, exact owner and unique victim domain"): return false
		if not check(e.attack_delta==source.amount and e.health_delta==source.amount and e.permanent==true and e.target_uid in eligible[player],"exact +3/+3 or +6/+6 to genuine minion of same owner only"): return false
		var lethal: Dictionary=lethal_for(log,e.source,e.killed_uid)
		var death: Dictionary=death_for(log,e.killed_uid)
		if lethal.is_empty() or death.is_empty(): return false
		if not check(e.lethal_sequence==lethal.sequence and e.death_sequence==death.sequence and lethal.sequence<death.sequence and death.sequence<e.sequence and death.killer_id==lethal.source_combat_id,"grant links exact real lethal and removed-death evidence"): return false
		var source_deaths: Array=matching_events(log,"death","unit",e.source)
		if source_deaths.is_empty():
			if not check(not e.has("reciprocal_death"),"surviving-source grant does not claim dead-source timing branch"): return false
		else:
			var reciprocal: Dictionary=lethal_for(log,e.killed_uid,e.source)
			if reciprocal.is_empty() or not check(source_deaths.size()==1,"dead grant source has one real removal receipt"): return false
			var expected_timing: Dictionary={"scope":"murcules_reciprocal_plain_v1","attack_sequence":lethal.attack_sequence,"source_death_sequence":source_deaths[0].sequence,"source_lethal_sequence":reciprocal.sequence,"death_wave_size":2}
			if not check(e.get("reciprocal_death")==expected_timing,"narrow reciprocal receipt metadata matches independently verified attack, source lethal and source death"): return false
		var chosen_rng: Dictionary={}
		for r in rngs:
			if r.sequence>death.sequence and r.sequence<e.sequence: chosen_rng=r
		if not check(not chosen_rng.is_empty() and chosen_rng.sequence not in used_rng,"one distinct native recipient RNG before each grant"): return false
		if not check(chosen_rng.candidates==eligible[player] and chosen_rng.index>=0 and chosen_rng.index<eligible[player].size() and chosen_rng.choice==eligible[player][chosen_rng.index] and chosen_rng.choice==e.target_uid,"RNG domain is ordered exact owner hand-minion occurrences, skips spells and enemy UIDs"): return false
		used_rng.append(chosen_rng.sequence)
		increments[player][e.target_uid]+=source.amount
		counts[source.uid].append(e.killed_uid)
	for source in expected:
		var wanted: int=source.victims.size() if not eligible[source.owner].is_empty() else 0
		if not check(counts[source.uid].size()==wanted,"one grant per actual source kill iff that owner has a hand minion"): return false
	if not check(rngs.size()==grant_count and used_rng.size()==rngs.size(),"no recipient RNG for empty/spell-only hands or non-kills"): return false
	for player in [0,1]:
		if not check(zone_by_uid("hand",player).keys()==before_hands[player].keys(),"native settlement preserves exact owner hand UIDs/order including reward spells"): return false
		for uid in before_hands[player]:
			var old: Dictionary=before_hands[player][uid]
			if old.get("kind","minion")!="minion":
				var combat_hand_key: String="left_hand" if combat.left_player==player else "right_hand"
				var combat_spells: Array=[]
				for card in combat[combat_hand_key]:
					if card.get("uid")==uid: combat_spells.append(card)
				if not check(old.card_id=="__triple_reward" and combat_spells.size()==1 and combat_spells[0]==old,"combat golden reward spell is byte-exact unchanged"): return false
				# Actual Game end_turn includes the next recruit: BloodGems.start_turn
				# initializes this counter on every board/hand/shop card, even spells.
				# Project precisely that native transition; ignore no other field.
				var expected_spell: Dictionary=old.duplicate(true)
				expected_spell.blood_gems_received_turn=0
				if not check(unit("hand",uid,player)==expected_spell,"golden reward spell changes only by native next-turn zero counter"): return false
			else:
				if not stat_delta(unit("hand",uid,player),old,increments[player][uid],increments[player][uid],"owner "+str(player)+" exact settled hand delta"): return false
				var expected_card: Dictionary=old.duplicate(true)
				expected_card.attack+=increments[player][uid]
				expected_card.health+=increments[player][uid]
				expected_card.max_health+=increments[player][uid]
				if not check(unit("hand",uid,player)==expected_card,"only the three declared stat fields change in a plain held recipient"): return false
	return true

func source_expectation(uid: String,player: int,golden: bool,victims: Array) -> Dictionary:
	return {"uid":uid,"owner":player,"card_id":GOLDEN if golden else MURC,"amount":6 if golden else 3,"victims":victims}

func seal_setup_and_run() -> Dictionary:
	acquiring=false
	if not roundtrip("genuine setup saved immediately before actual combat"): return {}
	var saved: String=report.loads[-1].path
	var before: Dictionary=snapshot()
	if not advance(): return {}
	return {"path":saved,"before":before,"after":snapshot()}

func replay_and_finish_case(run: Dictionary) -> bool:
	var fresh: RefCounted=game_script.new()
	if not check(fresh.load_from(run.path,catalog)==OK,"fresh replay loads exact candidate native setup save"): return false
	game=fresh
	if not check(snapshot()==run.before,"replay restores all 13 persisted fields including exact candidate fingerprint/RNG"): return false
	if not advance() or not check(snapshot()==run.after,"same public end_turn sequence reproduces complete native 13-field outcome"): return false
	if not roundtrip("native settled candidate result roundtrip"): return false
	report.completed_cases.append(scenario)
	return true

func mutual_case(golden: bool,recipient_counts: Array) -> bool:
	if not configure(("golden" if golden else "normal")+"_mutual_"+str(recipient_counts[0])+"_"+str(recipient_counts[1])) or not reach_both_tier2(): return false
	var sources: Array=[]
	for player in [0,1]:
		var uid: String=buy_true_triple_player(MURC,GOLDEN,player) if golden else acquire(MURC,player)
		if uid.is_empty(): return false
		sources.append(uid)
	for player in [0,1]:
		for _i in range(recipient_counts[player]):
			if acquire(TAD,player).is_empty(): return false
	for player in [0,1]:
		if not play_minion(sources[player],player): return false
		var source: Dictionary=unit("board",sources[player],player)
		if not check(owner(player).board.size()==1 and source.attack==(10 if golden else 5) and source.health==(6 if golden else 3) and source.max_health==source.health,"unbuffed genuinely bought source alone on each board"): return false
		if not check(owner(player).hand.size()==recipient_counts[player]+(1 if golden else 0) and hand_domain(zone_by_uid("hand",player)).size()==recipient_counts[player],"only acquired recipients plus actual golden reward spell in each hand"): return false
	var hands: Array=[zone_by_uid("hand",0),zone_by_uid("hand",1)]
	var run: Dictionary=seal_setup_and_run()
	if run.is_empty(): return false
	var c: Dictionary=game.last_combats[0]
	if not check(c.winner==-1 and c.left.is_empty() and c.right.is_empty() and matching_events(c.log,"attack").size()==1 and matching_events(c.log,"damage").size()==2 and matching_events(c.log,"death").size()==2,"one reciprocal exchange removes both sources and ties actual combat"): return false
	if not verify_reciprocal_wave(sources[0],sources[1]): return false
	if not verify_grants(hands,[source_expectation(sources[0],0,golden,[sources[1]]),source_expectation(sources[1],1,golden,[sources[0]])]): return false
	return replay_and_finish_case(run)

func cyclone_case(golden: bool) -> bool:
	if not configure(("golden" if golden else "normal")+"_reciprocal_cyclone") or not reach_both_tier2(): return false
	var source: String=buy_true_triple_player(MURC,GOLDEN,0) if golden else acquire(MURC)
	var cyclone: String=buy_true_triple_player(CYCLONE,GOLDEN_CYCLONE,1) if golden else acquire(CYCLONE,1)
	var tad: String=acquire(TAD,1)
	var held: String=acquire(TAD)
	if source.is_empty() or cyclone.is_empty() or tad.is_empty() or held.is_empty(): return false
	if not play_minion(source) or not play_minion(cyclone,1) or not play_minion(tad,1): return false
	if not check(owner().board.size()==1 and owner(1).board.size()==2 and owner(1).board[0].uid==cyclone,"larger real opponent board forces first attacker Cyclone"): return false
	var hands: Array=[zone_by_uid("hand",0),zone_by_uid("hand",1)]
	var run: Dictionary=seal_setup_and_run()
	if run.is_empty(): return false
	var log: Array=game.last_combats[0].log
	var attacks: Array=matching_events(log,"attack")
	var shields: Array=matching_events(log,"shield_lost","target",cyclone)
	if not check(attacks.size()==2 and attacks[0].attacker==cyclone and attacks[1].attacker==cyclone and attacks[0].target==source and attacks[1].target==source,"actual two native Windfury strikes against lone source"): return false
	if not check(shields.size()==1 and shields[0].source==source and shields[0].sequence>attacks[0].sequence and shields[0].sequence<attacks[1].sequence,"first source retaliation only removes actual Divine Shield"): return false
	for e in log:
		if e.sequence<attacks[1].sequence and not check(e.get("event")!="death" and e.get("kill_hand_family")!=FAMILY and e.get("purpose")!=RNG_PURPOSE,"shield-blocked/nonlethal first exchange grants nothing and consumes no recipient RNG"): return false
	var result: Dictionary=game.last_combats[0]
	var remaining: Array=result.left+result.right
	if not check(remaining.size()==1 and remaining[0].uid==tad and matching_events(log,"death").size()==2,"only source and Cyclone die; unrelated Tad is sole combat survivor"): return false
	if not verify_reciprocal_wave(source,cyclone): return false
	if not verify_grants(hands,[source_expectation(source,0,golden,[cyclone])]): return false
	return replay_and_finish_case(run)

func survivor_case(retaliation: bool) -> bool:
	if not configure("normal_surviving_"+("retaliation_then_attack" if retaliation else "attack"),retaliation) or not reach_both_tier2(): return false
	var source: String=acquire(MURC)
	var filler: String="" if retaliation else acquire(CYCLONE)
	var victims: Array=[]
	for _i in range(2 if retaliation else 1):
		var victim: String=acquire(TAD,1)
		if victim.is_empty(): return false
		victims.append(victim)
	var held: String=acquire(TAD)
	var spell: String=acquire_fortify_player(0) if retaliation else ""
	if source.is_empty() or held.is_empty() or (retaliation and spell.is_empty()) or (not retaliation and filler.is_empty()): return false
	if not play_minion(source): return false
	if not filler.is_empty() and not play_minion(filler): return false
	if not spell.is_empty() and not cast_fortify_player(spell,source,0): return false
	for victim in victims:
		if not play_minion(victim,1): return false
	var hands: Array=[zone_by_uid("hand",0),zone_by_uid("hand",1)]
	var run: Dictionary=seal_setup_and_run()
	if run.is_empty(): return false
	var log: Array=game.last_combats[0].log
	if not check(matching_events(log,"death","unit",source).is_empty(),"ordinary survivor regression source really survives actual combat"): return false
	var kinds: Array=[]
	for e in log:
		if e.get("event")=="damage" and e.get("source")==source and e.get("health",1)<=0: kinds.append(e.kind)
	if not check(kinds==(["retaliation","attack"] if retaliation else ["attack"]),"ordinary survivor regression retains exact native kill kinds"): return false
	if not verify_grants(hands,[source_expectation(source,0,false,victims)]): return false
	return replay_and_finish_case(run)

func unrelated_case(golden: bool) -> bool:
	if not configure(("golden" if golden else "normal")+"_unrelated_killer") or not reach_both_tier2(): return false
	var source: String=buy_true_triple_player(MURC,GOLDEN,0) if golden else acquire(MURC)
	var cyclone: String=acquire(CYCLONE)
	var victim: String=acquire(TAD,1)
	var held: String=acquire(TAD)
	if source.is_empty() or cyclone.is_empty() or victim.is_empty() or held.is_empty(): return false
	if not play_minion(cyclone) or not play_minion(source) or not play_minion(victim,1): return false
	var hands: Array=[zone_by_uid("hand",0),zone_by_uid("hand",1)]
	var run: Dictionary=seal_setup_and_run()
	if run.is_empty(): return false
	var log: Array=game.last_combats[0].log
	var attacks: Array=matching_events(log,"attack")
	if not check(attacks.size()==1 and attacks[0].attacker==cyclone and attacks[0].target==victim,"larger left board and real order make unrelated Cyclone the sole killer"): return false
	if lethal_for(log,cyclone,victim).is_empty() or death_for(log,victim).is_empty(): return false
	if not verify_grants(hands,[source_expectation(source,0,golden,[])]): return false
	return replay_and_finish_case(run)

func nonlethal_case(golden: bool) -> bool:
	if not configure(("golden" if golden else "normal")+"_nonlethal_source_hit",true) or not reach_both_tier2(): return false
	var source: String=buy_true_triple_player(MURC,GOLDEN,0) if golden else acquire(MURC)
	var target: String=buy_true_triple_player(MURC,GOLDEN,1) if golden else acquire(MURC,1)
	var cyclone: String=acquire(CYCLONE)
	var held: String=acquire(TAD)
	var spells: Array=[]
	for _i in range(2 if golden else 1):
		var spell: String=acquire_fortify_player(1)
		if spell.is_empty(): return false
		spells.append(spell)
	if source.is_empty() or target.is_empty() or cyclone.is_empty() or held.is_empty(): return false
	if not play_minion(source) or not play_minion(cyclone) or not play_minion(target,1): return false
	for spell in spells:
		if not cast_fortify_player(spell,target,1): return false
	if not check(hand_domain(zone_by_uid("hand",1)).is_empty() and unit("board",target,1).health==(12 if golden else 6),"opponent has genuinely Fortified target and no eligible hand minions"): return false
	var hands: Array=[zone_by_uid("hand",0),zone_by_uid("hand",1)]
	var run: Dictionary=seal_setup_and_run()
	if run.is_empty(): return false
	var log: Array=game.last_combats[0].log
	var hits: Array=matching_events(log,"damage","source",source)
	if not check(hits.size()==1 and hits[0].target==target and hits[0].health==(2 if golden else 1) and hits[0].kind=="attack","source deals genuine nonlethal hit then dies, never kills"): return false
	if death_for(log,source).is_empty() or lethal_for(log,cyclone,target).is_empty(): return false
	if not verify_grants(hands,[source_expectation(source,0,golden,[]),source_expectation(target,1,golden,[source])]): return false
	return replay_and_finish_case(run)

func finish() -> void:
	report.status="passed_narrow_candidate_only" if failures==0 and report.completed_cases.size()==18 else "failed_or_incomplete_no_credit"
	report.failures=failures
	persist()
	print("MURCULES_DEADKILLER_PUBLIC_TERMINAL ",JSON.stringify(report))
	quit(0 if report.status=="passed_narrow_candidate_only" else 1)

func _initialize() -> void:
	if "--reviewed-murcules-deadkiller" not in OS.get_cmdline_user_args():
		print("MURCULES_DEADKILLER_DRAFT_HOLD: requires evidence, reviewed sealed successor and parent launch release")
		quit(2);return
	game_script=load("res://core/game.gd")
	room_script=load("res://core/room_config.gd")
	catalog=load("res://core/catalog.gd").new()
	catalog.load_catalog()
	if not check(catalog.load_errors.is_empty(),"candidate Catalog clean",catalog.load_errors): finish();return
	for identity in [MURC,GOLDEN]:
		var amount: int=3 if identity==MURC else 6
		var card: Dictionary=catalog.get_card(identity)
		if not check(card.effects==[{"type":"after_self_kill_hand_buff","source_id":identity,"requires_attack":false,"selection":"random","attack":amount,"health":amount}] and card.tier==2 and card.attack==(5 if identity==MURC else 10) and card.health==(3 if identity==MURC else 6),"pinned complete normal/golden program and printed body"): finish();return
	var tad_card: Dictionary=catalog.get_card(TAD)
	if not check(tad_card.tier==2 and tad_card.attack==2 and tad_card.health==2 and tad_card.keywords.is_empty() and tad_card.effects==[{"type":"on_sell_random_card","tribe":"鱼人","count":1}],"Tad is native combat-plain 2/2; never sell it"): finish();return
	for identity in [CYCLONE,GOLDEN_CYCLONE]:
		var cyclone_card: Dictionary=catalog.get_card(identity)
		if not check(cyclone_card.attack==(2 if identity==CYCLONE else 4) and cyclone_card.health==(1 if identity==CYCLONE else 2) and cyclone_card.effects.is_empty() and cyclone_card.keywords==["divine_shield","windfury"],"native Cyclone exact stats, shield and two-strike Windfury"): finish();return
	for golden in [false,true]:
		for counts in [[1,1],[0,0],[1,0],[0,1],[2,2]]:
			if not mutual_case(golden,counts): finish();return
		if not cyclone_case(golden) or not unrelated_case(golden) or not nonlethal_case(golden): finish();return
	for retaliation in [false,true]:
		if not survivor_case(retaliation): finish();return
	finish()
