from pathlib import Path
import json,hashlib
R=Path(__file__).resolve().parent
CASES=['normal_tidecaller_lifecycle','golden_tidecaller_lifecycle']
LABELS=['non_murloc_control','shop_non_murloc_control','board_murloc','source_self','shop_murloc','repeat_board_murloc']
SAVES=['genuine setup immediately before actual targeted hand casts','first execution all six actual casts and permanent recipient grants native roundtrip','deterministic replay all six actual casts and permanent recipient grants native roundtrip','permanent next-turn result native roundtrip']
FIELDS=['schema_version','rules_version','execution_fingerprint','room','state','pool','spell_pool','rng_seed','rng_state','next_uid','events','command_log','last_combats']
COUNTERS=dict(actual_hand_casts=12,targeted_murloc_casts=8,non_murloc_casts=4,exact_owned_murloc_grants=24,fortify_applications=12,shop_target_casts=4,self_target_casts=2,repeat_target_casts=2,native_roundtrips=4,replay_comparisons=1)
mandatory=[]
for case in CASES:
 for label in SAVES:
  for suffix in ['native save','saving does not mutate engine','fresh native load']+['native roundtrip '+f for f in FIELDS]: mandatory.append(dict(scenario=case,label=label+': '+suffix,count=1))
 for label in LABELS:
  for suffix in ['exact real source and target UIDs','genuine paid Fortify in hand','exact three owned Murloc recipients','whole board dictionaries match exact independent deltas','whole hand dictionaries match exact independent deltas','whole shop dictionaries match exact independent deltas','consume once no additional gold one cast counter','other owner entire state unchanged','both native pools unchanged']:
   mandatory.append(dict(scenario=case,label='cast '+label+': '+suffix,count=2))
 for player in (0,1):
  for zone in ('board','hand'):mandatory.append(dict(scenario=case,label=f'next turn owner {player} whole {zone} permanent with native zero counter',count=2))
 for label in ['repeat target already has permanent Taunt']:
  mandatory.append(dict(scenario=case,label=label,count=2))
 for label in ['replay fresh load exact setup','replay restores full 13 persisted fields','six actual casts replay all 13 persisted fields','actual next turn replay all 13 persisted fields']:
  mandatory.append(dict(scenario=case,label=label,count=1))
c=dict(schema='tidecaller_second_loss_rescue_contract_v1',status='new_preparation_never_run',historical_acceptance_credit=0,standalone_gameplay_credit=0,reconstruction='new_second_loss_20261104T0901Z_not_original_artifact',harness_sha256=hashlib.sha256((R/'tidecaller_lifecycle_public.gd').read_bytes()).hexdigest(),gate='--reviewed-tidecaller-lifecycle',terminal_prefix='TIDECALLER_LIFECYCLE_PUBLIC_TERMINAL ',report_filename='tidecaller_lifecycle_public_report.json',success='passed_narrow_new_reconstruction_only',cases=CASES,cast_labels=LABELS,save_labels=SAVES,save_fields=FIELDS,exact_casts=24,exact_loads=8,counters=COUNTERS,mandatory_labels=mandatory,adaptive_bounds=dict(checks=[len(mandatory),50000],commands=[24,4000],combats=[4,2000]),acquisition_limits=dict(tier_steps=30,minion_search=60,spell_search=40,final_offers=100),command_check_suffixes=['expected command result','no engine error phase','one real command receipt; no bot actions','complete native stock conservation'],expected_rejected_commands=[],runner_required='Authenticate sealed source, exact log/report bytes, native save bytes/current XDG paths, call pure validate(report,contract,context), assert inputs unchanged, recheck bytes. No historical or fabricated fixture gameplay credit.')
(R/'harness_contract.json').write_text(json.dumps(c,ensure_ascii=False,indent=2)+'\n')
print('contract canonical sha256',hashlib.sha256(json.dumps(c,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest())

validator=R/"tidecaller_report_validator.py"
if validator.exists():
 import re
 digest=hashlib.sha256(json.dumps(c,ensure_ascii=False,sort_keys=True,separators=(",",":"),allow_nan=False).encode()).hexdigest()
 validator.write_text(re.sub(r"CONTRACT_SHA256='[^']*'", "CONTRACT_SHA256='"+digest+"'",validator.read_text()))
