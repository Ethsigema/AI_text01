extends SceneTree
## NEW second-loss Catalog-only probe. No historical acceptance or save/gameplay credit.
const OUTPUT = "user://recovery_catalog_report.json"
var failures: int = 0
var report: Dictionary = {"status":"not_run","checks":[],"failures":0,"load_errors":[],"execution_fingerprint":"","gameplay_credit":0,"native_save_count":0}
func check(ok: bool,label: String) -> void:
	report.checks.append({"scenario":"catalog_fingerprint","label":label,"passed":ok})
	print("BASIC_CHECK catalog_fingerprint | ",label," | ",ok)
	if not ok: failures += 1
func _initialize() -> void:
	if "--reviewed-recovery-catalog" not in OS.get_cmdline_user_args():
		print("RECOVERY_CATALOG_HOLD: fresh reviewed release required")
		quit(2);return
	var source: GDScript = load("res://core/catalog.gd")
	check(source != null,"exact candidate Catalog script loads")
	if source != null:
		var catalog: RefCounted = source.new()
		catalog.load_catalog()
		report.load_errors = catalog.load_errors.duplicate(true)
		report.execution_fingerprint = catalog.execution_fingerprint
		check(catalog.load_errors.is_empty(),"actual candidate Catalog has no load errors")
		var expression: RegEx = RegEx.new()
		expression.compile("^[0-9a-f]{64}$")
		check(expression.search(str(catalog.execution_fingerprint)) != null,"actual candidate fingerprint is lowercase SHA256")
		catalog = null
		source = null
	report.failures = failures
	report.status = "observed_fingerprint_only_no_gameplay_credit" if failures == 0 else "failed_no_credit"
	var file: FileAccess = FileAccess.open(OUTPUT,FileAccess.WRITE)
	if file == null: quit(1);return
	file.store_string(JSON.stringify(report,"  "))
	file.close()
	print("RECOVERY_CATALOG_TERMINAL ",JSON.stringify(report))
	quit(0 if failures == 0 else 1)
