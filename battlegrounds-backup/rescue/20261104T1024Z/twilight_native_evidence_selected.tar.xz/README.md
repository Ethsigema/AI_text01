# Fresh Twilight native evidence

This package preserves selected raw evidence from the new Catalog probe and the completed normal/genuine-golden Twilight public lifecycle. It contains actual engine logs, native reports and save files, run result metadata and the unchanged original final/output seals.

Font caches and copied supporting input/review files are intentionally excluded and listed with their original hashes. This is not the complete original run directory: a verifier requiring every original sealed member must not be claimed to pass against this subset. PACKAGE_MANIFEST.json authenticates every included member; EVIDENCE_SELECTION.json records the selection. Exact source and control prerequisites are separately backed up.

The Twilight run passed 1,600 checks, 135 public command receipts, 28 casts and 12 native save/load paths across two cases. All 13 save fields and full replay were checked. It retained the explicitly declared exit cleanup warning and 176-resource error; it is not diagnostic-free. These are narrow lifecycle results, not full-game or complete-identity acceptance.
