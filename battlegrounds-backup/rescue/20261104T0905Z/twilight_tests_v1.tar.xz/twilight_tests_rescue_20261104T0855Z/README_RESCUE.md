# Twilight test rescue after the second workspace loss

This directory was reconstructed from the retained task conversation after /workspace/shared disappeared around 08:54 UTC. No Godot engine was run. The Twilight public harness has never had a native passing run.

Recovered in full:

- twilight_lifecycle_public.gd: all 466 lines. Actual recovered SHA256 bcc82dc69039a034678178cd7dd382441247acc94b368d15fd4aa7daa9e643d6 matches the recorded pre-loss harness SHA256 exactly.
- build_contract.py: complete preparation generator for the 2-case / 28-cast / 12-unique-save / 905-fixed-assertion contract. Total commands and combats remain bounded adaptive acquisition counts, never historical totals.
- harness_contract.json: generated against the actual /tmp rescue paths. Its digest differs solely because of those relocated absolute paths.
- historical_path_harness_contract.json: same recovered generated content with only the two absolute paths restored to their pre-loss values. Its actual SHA256 442648b5728f950a2cdb5dbfa169a405887901ebd078e1f2b67aa64565927fa4 matches the recorded pre-loss contract exactly. These old paths do not currently exist and this file is evidence for comparison, not the runnable contract.
- validate_twilight_report.py: complete pure-data postvalidator recovered from the retained conversation. Current SHA256 is recorded in the new rescue manifest; no independently retained historical digest was available to assert byte equality for this module.
- HISTORICAL_COMPARISON.json: historical digest leads, explicitly separated from current observations.

The binder MUST hash-bind the exact postvalidator and actual relocated contract, import the module and execute validate(report, contract) on the current sealed native report. Packaging or hashing the Python file without actually calling it is not sufficient. Sealed native execution, command assertions, fixed semantic counts and full save/replay obligations must also be enforced. Per-cast vectors alone do not prove acquisition, actual hand reordering, turn transitions or full replay.

Design remains normal and genuine-triple golden Twilight. Seven real Fortify casts per execution: other owned Murloc, shop Twilight, source self first grant, repeated grant, hand reordering after actual first recipient play, spells-only hand, then empty normal hand or retained genuine golden reward-only hand. Golden literal empty hand is intentionally not tested. The golden reward is produced only by the real golden source play, never fabricated, discarded or consumed just for setup. The source itself receives only independent Fortify 0/3 and Taunt. Grant vectors are9/9 or18/18 once as an observed aggregate, with internal call cardinality labelled a static source expectation.

Historical static reviews and native/source facts are provenance leads only. The complete pre-loss static review file, original TESTS_MANIFEST_DRAFT.json, SOURCE_ADMISSION.json and static test log are not recovered byte-for-byte here. Their historical digests and reported outcomes cannot substitute for fresh source binding and review. Re-check the recovered helpers against the newly restored baseline when it becomes available. No native result, fingerprint, promotion, or full identity/pool acceptance is asserted.
