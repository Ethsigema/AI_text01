"""Build a NEW unexecuted Twilight contract; never creates historical evidence."""
from pathlib import Path
import json, hashlib, re
HERE=Path(__file__).resolve().parent
SCRIPT=HERE/'twilight_lifecycle_public.gd'
s=SCRIPT.read_text()
constant=lambda key:json.loads(re.search(r'^const '+key+r' = (.+)$',s,re.M).group(1))
CASES=constant('CASES');CASTS=constant('CAST_LABELS');COUNTERS=constant('EXPECTED_COUNTERS')
IDS=['BG36_703','BG36_703_G']
FIELDS=['schema_version','rules_version','execution_fingerprint','room','state','pool','spell_pool','rng_seed','rng_state','next_uid','events','command_log','last_combats']
INITIAL={'candidate Catalog clean':1,'pinned complete Twilight normal and golden identity body and single-grant program':2,'pinned admitted native Tad control with uninvoked sale effect':1,'pinned admitted native non-Murloc recipient without recruit effects':1,'pinned Fortify two-leaf permanent health and Taunt program':1}
LOADS=['genuine setup immediately before actual targeted hand casts','first execution two exact hand grants before next-turn native roundtrip','first execution reordered hand recipient exact grant native roundtrip','deterministic replay two exact hand grants before next-turn native roundtrip','deterministic replay reordered hand recipient exact grant native roundtrip','permanent played and sold result native roundtrip']
COMMON={
'bounded native room admits actual current sources':1,'fresh actual native Game starts':1,'golden source is never an ordinary stock offer':1,
'genuine setup respects native ten-card hand capacity before playing minions':1,'genuine acquired source has exact 37.0.2 body and stock entitlement':1,'native genuine triple reward is retained without hand overflow':1,
'real paid hand order is preceding spell then two exact non-Murloc minions':1,'nonmatching controls are another owned Murloc and a distinct real shop source':1,
'preceding genuine spell is skipped and exact first of two minions selected':4,'real first-minion play makes exact second minion the next recipient':2,
'recipientless source cast has no hand-minion target':4,'real spells-only hand survives recipientless cast':2,
'actual cast consumes its purchased UID once without extra payment':14,'two Fortify leaves count as one real cast with unchanged reserved stock':14,'real command receipt binds exact selected target index and zone':14,"real casts never change another owner's native player state":14,
'selected board or shop target receives only Fortify health and Taunt':14,'source self never receives its own hand grant':10,
'one exact aggregate permanent Twilight hand grant, never one per spell leaf':6,'no unrelated or recipientless cast changes any remaining hand card':8,'second minion and preceding spell remain fully unchanged':4,'repeat self cast adds one grant without duplicate Taunt':2,
'actual public freeze is set':2,'next turn preserves every board field except explicit native zero counter initialization':2,'next turn preserves every hand field except explicit native zero counter initialization':2,'both real hand minions persist and permanent gain has no temporary ledger':2,'all stock remains conserved after real next-turn hand permanence':2,
'only genuinely acquired source or effect-free hand recipient is sold':6,'sale returns exact original stock entitlement once and pays one Gold':6,'all stock remains conserved after real source and recipient sales':2,
'fresh replay loads exact genuine setup save':1,'replay restores all 13 native persisted fields':1,'same actual public command sequence reproduces all 13 persisted fields':1,'exact fixed lifecycle counters match before any gameplay credit':1,
}
for label in CASTS:
 for suffix in [': actual acquired hand spell and actual selected minion exist',': independent board and exact source UID gate',': exactly the first remaining hand minion or no recipient',': exact complete board dictionaries after one cast',': exact complete hand dictionaries after one cast',': exact complete shop dictionaries after one cast']:
  COMMON[label+suffix]=2
for label in LOADS:
 for suffix in [': native save',': saving does not mutate engine',': fresh native load']:COMMON[label+suffix]=1
 for field in FIELDS:COMMON[label+': native roundtrip '+field]=1
NORMAL={**COMMON,'real normal final cast leaves empty hand without a grant':2}
GOLDEN={**COMMON,'real affordable third normal offer for owner 0':1,'real owner-specific triple payment and reserved stock':1,'native golden has three-copy stock entitlement':1,'each genuine ordinary UID consumed once for exact owner':3,'one new triple receipt attributed to actual owner':1,"tripling one owner never consumes the other owner's cards":1,'genuine tier-four golden play awards exact native tier-five reward':1,'genuine golden reward-only hand is retained without fabricated discard':2}
for counts,golden in [(NORMAL,False),(GOLDEN,True)]:
 counts.update({'real minion offer exists BG36_703':2 if golden else 1,'real minion offer exists BG22_202':1,'real minion offer exists BGS_119':2,'offered minion has native stock entitlement':5 if golden else 4,'buy pays three and moves original UID once':5 if golden else 4,'buy does not debit reserved minion stock twice':5 if golden else 4,'real affordable Fortify offer and free hand slot':7,'Fortify offer has one genuine spell-stock reservation':7,'spell purchase pays one and moves original UID once':7,'spell purchase releases exactly one reservation without touching minion stock':7,'real acquired minion in hand':6,'play moves original UID once without payment':6,'one real tier and exact payment':3})
 for field in ['card_id','attack','health','max_health','keywords','temporary_buffs','permanent_keywords','pool_id','pool_count']:counts['played minion preserves acquired '+field]=6
COMMAND_COUNTS={}
for case,golden in zip(CASES,[False,True]):
 values={'buy minion BG36_703':2 if golden else 1,'buy minion BG22_202':1,'buy minion BGS_119':2,'buy actual Fortify for one Gold':7,'play acquired minion':6,'sell real acquired minion':6,'pay actual tier upgrade':3}
 if golden:values['actual third paid normal purchase']=1
 for label in CASTS:values['cast actual Fortify '+label]=2
 COMMAND_COUNTS[case]=values
COUNTS={'source_contracts':INITIAL,CASES[0]:NORMAL,CASES[1]:GOLDEN}
minimum_checks=sum(sum(counts.values()) for counts in COUNTS.values())
report=json.loads(re.search(r'^var report: Dictionary = (.+)$',s,re.M).group(1).replace('"required_cases":CASES','"required_cases":'+json.dumps(CASES)))
checks_expanded={case:[label for label,n in counts.items() for _ in range(n)] for case,counts in COUNTS.items()}
receipt=['scenario','label','spell_uid','spell_id','source_uid','source_id','target_zone','target_uid','source_targeted','triggered','grant_attack','grant_health','remaining_hand_minion_uids','eligible_hand_uids','expected_program_applications','program_application_count_is_static_expectation','fortify_applications','command_sequence','command','before_owned','after_owned']
cast_contract={'total_cast_count':28,'count_per_case':14,'ordered_labels_per_case':CASTS*2,'ordered_target_zones_per_case':['board','shop','board','board','board','board','board']*2,'ordered_source_targeted_per_case':[False,False,True,True,True,True,True]*2,'ordered_triggered_per_case':[False,False,True,True,True,False,False]*2,'ordered_remaining_hand_minion_counts_per_case':[2,2,2,2,1,0,0]*2,'ordered_recipient_count_per_case':[0,0,1,1,1,0,0]*2,'source_ids_by_case':dict(zip(CASES,IDS)),'vectors_by_case':{CASES[0]:[9,9],CASES[1]:[18,18]},'spell_id':'BG28_503','recipient_id':'BGS_119','nonmatching_board_id':'BG22_202','nonmatching_shop_id':'BG36_703','fortify_applications':1,'expected_program_applications_on_source_target':1,'expected_program_applications_otherwise':0,'receipt_fields':receipt,'first_seven_cast_rows_equal_replay_seven':True,'notes':'triggered means a nonempty actual hand-grant domain; source_targeted separately records board-and-source-UID match, including recipientless casts. expected_program_applications is explicitly a static source expectation, not an observed internal callback receipt. Complete dictionaries establish exact aggregate vectors, not internal call counts.'}
projection=['scenario','label','source_id','target_zone','source_targeted','triggered','grant_attack','grant_health','expected_program_applications','program_application_count_is_static_expectation','fortify_applications']
sequence=[]
for case,identity,amount in zip(CASES,IDS,[9,18]):
 for i,label in enumerate(CASTS*2):
  targeted=cast_contract['ordered_source_targeted_per_case'][i];grants=cast_contract['ordered_triggered_per_case'][i]
  sequence.append({'scenario':case,'label':label,'source_id':identity,'target_zone':cast_contract['ordered_target_zones_per_case'][i],'source_targeted':targeted,'triggered':grants,'grant_attack':amount if grants else 0,'grant_health':amount if grants else 0,'expected_program_applications':int(targeted),'program_application_count_is_static_expectation':True,'fortify_applications':1})
contract={
'schema_version':1,'status':'new_reconstruction_prepared_not_run','not_original_artifact':True,'historical_acceptance_credit':0,
'harness_source':str(SCRIPT),'harness_sha256':hashlib.sha256(SCRIPT.read_bytes()).hexdigest(),'runtime_basename':SCRIPT.name,'gate_arg':'--reviewed-twilight-lifecycle','report_basename':'twilight_lifecycle_public_report.json','terminal_prefix':'TWILIGHT_LIFECYCLE_PUBLIC_TERMINAL ','success_status':'passed_narrow_new_reconstruction_only',
'expected_report_fields':list(report)+['failures'],'report_values':{'reconstruction':report['reconstruction'],'historical_acceptance_credit':0,'required_cases':CASES,'counters_by_case':{case:COUNTERS for case in CASES}},
'ordered_cases':CASES,'allowed_check_scenarios':list(COUNTS),'initial_scenario':'source_contracts','required_check_counts_by_scenario':COUNTS,'required_checks_by_case':checks_expanded,
'ordered_load_labels_per_case':LOADS,'expected_loads':[{'scenario':case,'label':label} for case in CASES for label in LOADS],'native_snapshot_fields':FIELDS,
'expected_counts':{'checks':{'minimum':minimum_checks,'maximum':50000},'commands':{'minimum':90,'maximum':4000},'loads':12,'combats':{'minimum':4,'maximum':2000}},
'semantic_counts':[{'path':['casts'],'measure':'length','expected':28}],
'required_command_types':['buy','play','roll','upgrade','end_turn','freeze','sell'],
'command_check_suffixes':{'ok':[': expected command result',': no engine error phase',': one real command receipt; no bot actions',': complete native stock conservation'],'rejected':[': expected command result',': explicit error returned',': rejected command leaves every persisted field unchanged']},'expected_rejected_commands':[],'required_command_label_counts_by_case':COMMAND_COUNTS,
'expected_counters_by_case':{case:COUNTERS for case in CASES},
'acquisition_limits':{'tier4_steps_per_case':30,'ordinary_acquire_steps_per_call':60,'third_copy_acquire_steps':60,'fortify_acquire_steps_per_call':60,'preacquired_fortify_per_case':6,'final_fortify_direct_purchase_per_case':1,'target_offer_steps_per_case':100,'normal_case_total_acquisition_steps_at_most':730,'golden_case_total_acquisition_steps_at_most':850,'derivation':'Normal: tier30 + four minion searches240 + six spell searches360 + offers100=730. Golden uses three source searches180 rather than60, so850. The1580 total iterations use at most two commands each except offer loops may additionally freeze once per iteration (at most200 extra); fixed setup and both lifecycles keep total below4000. At most1580 acquisition combats plus four replay-inclusive lifecycle combats is below2000. Minimum90 counts only mandatory 3 tier upgrades per case, 4/6 normal-copy minion purchases, seven spell purchases, two setup plays, and two repeats of seven casts, two recipient plays, two ready/end-turn commands and three sales. It excludes adaptive rolls, all acquisition end-turns and freezes. Assertions bounded separately at50000 and tied to all actual command receipts. These bounds are not predictions of native totals; every exhausted loop fails.'},
'cast_contract':cast_contract,'exact_sequences':[{'field':'casts','project':projection,'expected':sequence}],
'postvalidation_module':str(HERE/'validate_twilight_report.py'),'postvalidation_required':'Reconstruct complete zones per cast, bind consumed bought spell/source/target/recipient UIDs, compare first seven receipts with replay seven, and validate every successful command receipt assertion; aggregate scalar assertions alone are insufficient.',
'synthetic_lane':'Not supplied by this public reconstruction. Any later synthetic lane needs new sealed source/save inputs and zero gameplay credit; stale-save fixture must change the unique fingerprint in original raw bytes only.',
'prohibited':['direct Game state setup mutation','direct pool or RNG mutation','private gameplay callback or factory calls','baseline/source writes','hidden golden injection','discarding or consuming genuine triple reward to force golden empty hand','historical totals used as fresh acceptance'],
'not_covered':['full current pool acceptance','complete Twilight identity acceptance','adjacent combat listener and composition acceptance','Lucky Egg actual provider lifecycle','internal callback counts observed independently from source','multiple identical board source composition','Tidecaller plus Twilight interaction','golden empty hand','source transformation','minion copy or owner migration','buffed triples','old-save migration','official complete timing equivalence','lost original harness byte equivalence'],
'source_binding_status':'Pending final reviewed combined source seal and native fingerprint. No source or native acceptance is inferred from this contract.','review_required':True,'engine_started':False}
(HERE/'harness_contract.json').write_text(json.dumps(contract,indent=2,ensure_ascii=False)+'\n')
print(json.dumps({'status':'new_reconstruction_prepared_not_run','public_cases':CASES,'public_roundtrips':12,'public_casts':28,'minimum_required_checks':minimum_checks,'harness_sha256':contract['harness_sha256'],'contract_sha256':hashlib.sha256((HERE/'harness_contract.json').read_bytes()).hexdigest()},indent=2))
