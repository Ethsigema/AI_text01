"""Independent pure-data validator. Never runs an engine or grants acceptance alone."""
from collections import Counter
from copy import deepcopy
import json
from pathlib import Path


def require(ok, message):
    if not ok: raise ValueError(message)


def unique_bodies(bodies):
    require(isinstance(bodies,list),'zone must be a list')
    result={}
    for body in bodies:
        require(isinstance(body,dict) and isinstance(body.get('uid'),str) and body['uid'],'body needs UID')
        require(body['uid'] not in result,'duplicate UID within zone')
        result[body['uid']]=body
    return result


def integral(value): return isinstance(value,int) and not isinstance(value,bool)


def buff(body,attack,health):
    for key,delta in [('attack',attack),('health',health),('max_health',health)]:
        require(integral(body.get(key)),'stat must be native integral')
        body[key]+=delta


def verify_cast(row,contract,index,case):
    c=contract['cast_contract']
    require(set(row)==set(c['receipt_fields']),'cast exact receipt fields')
    require(row['scenario']==case and row['label']==c['ordered_labels_per_case'][index],'cast scenario and label')
    require(row['spell_id']==c['spell_id'] and row['source_id']==c['source_ids_by_case'][case],'cast source/spell identities')
    require(row['target_zone']==c['ordered_target_zones_per_case'][index],'cast target zone')
    before=row['before_owned'];after=row['after_owned']
    require(isinstance(before,dict) and isinstance(after,dict),'full owner snapshots required')
    zones={z:unique_bodies(before[z]) for z in ['board','hand','shop']}
    all_uids=[uid for z in zones.values() for uid in z]
    require(len(all_uids)==len(set(all_uids)),'owner UID uniqueness')
    spell=zones['hand'].get(row['spell_uid']);source=zones['board'].get(row['source_uid'])
    target=zones[row['target_zone']].get(row['target_uid'])
    require(spell is not None and spell.get('card_id')==c['spell_id'] and spell.get('kind')=='spell' and spell.get('pool_count')==0,'actual acquired consumed spell')
    require(source is not None and source.get('card_id')==row['source_id'] and source.get('kind')=='minion','real board source')
    require(target is not None and target.get('kind')=='minion','actual chosen minion target')
    expected={z:deepcopy(before[z]) for z in zones}
    expected['hand']=[body for body in expected['hand'] if body['uid']!=row['spell_uid']]
    selected=next(body for body in expected[row['target_zone']] if body['uid']==row['target_uid'])
    buff(selected,0,3)
    for field in ['keywords','permanent_keywords']:
        require(isinstance(selected[field],list),'keyword array')
        if 'taunt' not in selected[field]:selected[field].append('taunt')
    minions=[body for body in expected['hand'] if body.get('kind')=='minion']
    uids=[body['uid'] for body in minions]
    targeted=row['target_zone']=='board' and row['target_uid']==row['source_uid']
    recipients=minions[:1] if targeted else []
    eligible=[body['uid'] for body in recipients]
    require(type(row['source_targeted']) is bool and row['source_targeted']==targeted==c['ordered_source_targeted_per_case'][index],'source-target gate')
    require(type(row['triggered']) is bool and row['triggered']==bool(eligible)==c['ordered_triggered_per_case'][index],'grant trigger gate')
    require(row['remaining_hand_minion_uids']==uids and len(uids)==c['ordered_remaining_hand_minion_counts_per_case'][index],'remaining minion order')
    require(row['eligible_hand_uids']==eligible and len(eligible)==c['ordered_recipient_count_per_case'][index],'exact leftmost domain')
    require(all(body.get('card_id')==c['recipient_id'] for body in minions),'actual effect-free non-Murloc hand recipients')
    vector=c['vectors_by_case'][case] if recipients else [0,0]
    require([row['grant_attack'],row['grant_health']]==vector,'exact observed aggregate vector')
    for body in recipients:
        buff(body,*vector)
        require(body.get('temporary_buffs')==[],'permanent hand gain')
    for zone in expected:require(after.get(zone)==expected[zone],'complete '+zone+' mismatch')
    require(after.get('gold')==before.get('gold'),'no extra cast payment')
    require(after['stats']['spells']==before['stats']['spells']+1,'one outer spell count')
    require(row['program_application_count_is_static_expectation'] is True,'never treat static calls as observed')
    require(integral(row['expected_program_applications']) and row['expected_program_applications']==int(targeted),'static program expectation')
    require(row['fortify_applications']==1,'one independent Fortify application')
    require(integral(row['command_sequence']) and row['command_sequence']>0,'native command sequence')
    spell_i=next(i for i,b in enumerate(before['hand']) if b['uid']==row['spell_uid'])
    target_i=next(i for i,b in enumerate(before[row['target_zone']]) if b['uid']==row['target_uid'])
    require(row['command']=={'type':'play','index':spell_i,'target':target_i,'target_zone':row['target_zone']},'exact command indexes and zone')
    if row['label']=='nonmatching_board':require(target['card_id']==c['nonmatching_board_id'] and target['uid']!=source['uid'],'other owned Murloc control')
    if row['label']=='nonmatching_shop':require(target['card_id']==c['nonmatching_shop_id'] and target['uid']!=source['uid'],'distinct shop source control')
    if row['label'] in ['leftmost_after_spell','repeat_leftmost']:
        require(expected['hand'][0]['kind']=='spell' and len(minions)==2,'skip preceding genuine spell')
        require(expected['hand'][0]==zones['hand'][expected['hand'][0]['uid']],'preceding spell unchanged')
        require(minions[1]==zones['hand'][minions[1]['uid']],'second hand minion unchanged')
    if row['label']=='spells_only':require(expected['hand'] and all(b['kind']=='spell' for b in expected['hand']),'spells-only control')
    if row['label']=='empty_or_reward_only':
        if case==contract['ordered_cases'][0]:require(not expected['hand'],'normal genuinely empty hand')
        else:require(len(expected['hand'])==1 and expected['hand'][0]['card_id']=='__triple_reward','genuine retained golden reward')


def validate(report,contract):
    require(isinstance(report,dict),'report object')
    require(set(report)==set(contract['expected_report_fields']),'exact report fields')
    require(report.get('status')==contract['success_status'] and report.get('failures')==0,'successful new narrow status only')
    require(report.get('failure_snapshots')==[],'no failed snapshots')
    require(report.get('completed_cases')==contract['ordered_cases'],'complete ordered cases')
    for key,value in contract['report_values'].items():require(report.get(key)==value,'report constant '+key)
    for field,limit in contract['expected_counts'].items():
        require(isinstance(report.get(field),list),'report list '+field)
        count=len(report[field])
        require(count==limit if isinstance(limit,int) else limit['minimum']<=count<=limit['maximum'],'bounded fresh '+field+' count')
    allowed=set(contract['allowed_check_scenarios'])
    require(all(row.get('scenario') in allowed and row.get('passed') is True for row in report['checks']),'every assertion passed in admitted scenario')
    checks=Counter((row['scenario'],row['label']) for row in report['checks'])
    for case,labels in contract['required_check_counts_by_scenario'].items():
        for label,count in labels.items():require(checks[(case,label)]==count,'required semantic label '+case+':'+label)
    commands=report['commands']; seen=Counter()
    for row in commands:
        require(row.get('scenario') in contract['ordered_cases'] and row.get('expected_ok') is True and row.get('result',{}).get('ok') is True and row.get('phase')!='error','every command genuinely successful')
        require(row.get('player') in [0,1] and isinstance(row.get('command'),dict),'real player command')
        seen[(row['scenario'],row['label'])]+=1
    for key,count in seen.items():
        for suffix in contract['command_check_suffixes']['ok']:require(checks[(key[0],key[1]+suffix)]==count,'command assertion binding')
    for case,labels in contract['required_command_label_counts_by_case'].items():
        for label,count in labels.items():require(seen[(case,label)]==count,'fixed real command count '+case+':'+label)
    require(set(contract['required_command_types'])<={row['command'].get('type') for row in commands},'all required public command kinds')
    loads=[{k:r.get(k) for k in ['scenario','label']} for r in report['loads']]
    require(loads==contract['expected_loads'],'unique exact native-save labels')
    require(len({r.get('path') for r in report['loads']})==len(loads),'distinct native save paths')
    require(len(report['casts'])==contract['cast_contract']['total_cast_count'],'exact cast count')
    at=0
    for case in contract['ordered_cases']:
        rows=report['casts'][at:at+14];at+=14
        require(rows[:7]==rows[7:],'replayed complete cast receipts match')
        for i,row in enumerate(rows):verify_cast(row,contract,i,case)
        actual=[row for row in commands if row['scenario']==case and row['label'].startswith('cast actual Fortify ')]
        require(len(actual)==14,'actual spell command count')
        for receipt,row in zip(rows,actual):
            require(row['label']=='cast actual Fortify '+receipt['label'] and row['command']==receipt['command'] and row['player']==0,'cast rows bind exact real commands')
    return {'status':'passed_independent_data_validation_only','casts':len(report['casts']),'native_loads':len(loads),'no_engine_run':True,'acceptance_requires_sealed_engine_evidence':True}


if __name__=='__main__':
    import argparse
    parser=argparse.ArgumentParser();parser.add_argument('report');parser.add_argument('--contract',default=str(Path(__file__).with_name('harness_contract.json')))
    args=parser.parse_args()
    print(json.dumps(validate(json.loads(Path(args.report).read_text()),json.loads(Path(args.contract).read_text())),indent=2))
