extends SceneTree
## NEW RECONSTRUCTION 2026-11-04. Not the lost original artifact or prior acceptance.
## Preparation only; execute only under independent review and a new sealed release.
const OUTPUT = "user://twilight_lifecycle_public_report.json"
const TWILIGHT = "BG36_703"
const GOLDEN = "BG36_703_G"
const TAD = "BG22_202"
const CYCLONE = "BGS_119"
const PATCHWERK = "TB_BaconShop_HERO_34"
const FORTIFY = "BG28_503"
const CASES = ["normal_twilight_lifecycle","golden_twilight_lifecycle"]
const CAST_LABELS = ["nonmatching_board","nonmatching_shop","leftmost_after_spell","repeat_leftmost","reordered_leftmost","spells_only","empty_or_reward_only"]
const EXPECTED_COUNTERS = {"actual_hand_casts":14,"source_targeted_casts":10,"nonmatching_casts":4,"exact_hand_grants":6,"recipientless_casts":4,"fortify_applications":14,"shop_target_casts":2,"repeat_target_casts":2,"reordered_target_casts":2,"sold_units":6,"native_roundtrips":6,"replay_comparisons":1}
const UPGRADE_PRICES = [0,5,7,8,11,11,0]
var game_script: GDScript
var room_script: GDScript
var catalog: RefCounted
var game: RefCounted
var stock_baseline: Dictionary = {}
var tier_started_round: int = 1
var scenario: String = "source_contracts"
var failures: int = 0
var acquiring: bool = true
var case_counters: Dictionary = {}
var report: Dictionary = {"status":"not_run","reconstruction":"new_20261104T0819Z_not_original_artifact","historical_acceptance_credit":0,"execution_fingerprint":"","checks":[],"commands":[],"loads":[],"combats":[],"casts":[],"counters_by_case":{},"failure_snapshots":[],"completed_cases":[],"required_cases":CASES,"scope":"new reconstructed isolated37.0.2 Twilight normal/genuine golden public recruit lifecycle","held":["full current pool acceptance","complete identity acceptance","adjacent combat listener acceptance and composition","Lucky Egg provider lifecycle acceptance","official complete timing equivalence","multiple same-identity board source composition","Tidecaller plus Twilight interaction","golden empty hand","cross-owner copies and transformations","buffed triples","old-save migration","internal buff-call cardinality is source-reviewed, not observed by public snapshots"]}
func check(ok: bool, label: String, detail: Variant = null) -> bool:
	report.checks.append({"scenario":scenario,"label":label,"passed":ok,"detail":detail})
	print("BASIC_CHECK ", scenario, " | ", label, " | ", ok)
	if not ok:
		failures += 1
		if game != null and not game.state.is_empty(): report.failure_snapshots.append({"scenario":scenario,"label":label,"snapshot":snapshot()})
		persist()
	return ok

func persist() -> void:
	var file: FileAccess = FileAccess.open(OUTPUT,FileAccess.WRITE)
	if file != null: file.store_string(JSON.stringify(report,"  "))

func owner(player: int = 0) -> Dictionary:
	return game.state.players[player]

func snapshot() -> Dictionary:
	return {"schema_version":game_script.SAVE_VERSION,"rules_version":game_script.RULES_VERSION,"execution_fingerprint":game.catalog.execution_fingerprint,"room":game.room.duplicate(true),"state":game.state.duplicate(true),"pool":game.pool.duplicate(true),"spell_pool":game.spell_pool.duplicate(true),"rng_seed":str(game.rng.seed),"rng_state":str(game.rng.state),"next_uid":game.next_uid,"events":game.events.duplicate(true),"command_log":game.command_log.duplicate(true),"last_combats":game.last_combats.duplicate(true)}

func index_uid(zone: String, uid: String, player: int = 0) -> int:
	for i in range(owner(player)[zone].size()):
		if owner(player)[zone][i].get("uid") == uid: return i
	return -1

func index_card(zone: String, identity: String, player: int = 0) -> int:
	for i in range(owner(player)[zone].size()):
		if owner(player)[zone][i].get("card_id") == identity: return i
	return -1

func unit(zone: String, uid: String, player: int = 0) -> Dictionary:
	var i: int = index_uid(zone,uid,player)
	return {} if i < 0 else owner(player)[zone][i]

func command(cmd: Dictionary, label: String, player: int = 0, expect_ok: bool = true) -> bool:
	var before: Dictionary = snapshot()
	var result: Dictionary = game.apply_command(player,cmd)
	report.commands.append({"scenario":scenario,"label":label,"player":player,"command":cmd.duplicate(true),"result":result.duplicate(true),"before_round":before.state.round,"after_round":game.state.round,"phase":game.state.phase,"expected_ok":expect_ok})
	if not check(result.get("ok",false) == expect_ok,label + ": expected command result",result): return false
	if not expect_ok:
		if not check(not str(result.get("error","")).is_empty(),label + ": explicit error returned"): return false
		return check(snapshot() == before,label + ": rejected command leaves every persisted field unchanged")
	if not check(game.state.phase != "error",label + ": no engine error phase"): return false
	if not check(game.state.command_sequence == before.state.command_sequence + 1 and game.command_log.size() == before.command_log.size() + 1,label + ": one real command receipt; no bot actions"): return false
	return check(stock_totals() == stock_baseline,label + ": complete native stock conservation")

func roundtrip(label: String) -> bool:
	var before: Dictionary = snapshot()
	var path: String = "user://twilight_lifecycle_" + scenario + "_" + str(report.loads.size()+1) + ".json"
	var saved: int = game.save_to(path)
	if not check(saved == OK,label + ": native save",saved): return false
	if not check(snapshot() == before,label + ": saving does not mutate engine"): return false
	var restored: RefCounted = game_script.new()
	var loaded: int = restored.load_from(path,catalog)
	if not check(loaded == OK,label + ": fresh native load",loaded): return false
	game = restored
	var after: Dictionary = snapshot()
	for field in before:
		if not check(after[field] == before[field],label + ": native roundtrip " + field): return false
	report.loads.append({"scenario":scenario,"label":label,"path":ProjectSettings.globalize_path(path)})
	case_counters.native_roundtrips+=1
	persist()
	return true

func buy_minion(identity: String, player: int = 0, uid: String = "") -> String:
	var index: int = index_card("shop",identity,player) if uid.is_empty() else index_uid("shop",uid,player)
	if not check(index >= 0,"real minion offer exists " + identity): return ""
	var offered: Dictionary = owner(player).shop[index].duplicate(true)
	var before_gold: int = owner(player).gold
	var before_pool: Dictionary = game.pool.duplicate(true)
	var before_hand: int = owner(player).hand.size()
	if not check(offered.get("pool_id") == identity and offered.get("pool_count") == 1,"offered minion has native stock entitlement"): return ""
	if not command({"type":"buy","index":index},"buy minion " + identity,player): return ""
	var acquired: Dictionary = unit("hand",offered.uid,player)
	if not check(owner(player).gold == before_gold-3 and owner(player).hand.size() == before_hand+1 and not acquired.is_empty() and index_uid("shop",offered.uid,player) == -1,"buy pays three and moves original UID once"): return ""
	if not check(game.pool == before_pool and acquired.get("pool_count") == 1,"buy does not debit reserved minion stock twice"): return ""
	return offered.uid

func play_minion(uid: String, player: int = 0) -> bool:
	var index: int = index_uid("hand",uid,player)
	if not check(index >= 0,"real acquired minion in hand"): return false
	var before: Dictionary = unit("hand",uid,player).duplicate(true)
	var gold: int = owner(player).gold
	var board_size: int = owner(player).board.size()
	if not command({"type":"play","index":index,"position":board_size},"play acquired minion",player): return false
	var after: Dictionary = unit("board",uid,player)
	if not check(not after.is_empty() and index_uid("hand",uid,player) == -1 and owner(player).board.size() == board_size+1 and owner(player).gold == gold,"play moves original UID once without payment"): return false
	for field in ["card_id","attack","health","max_health","keywords","temporary_buffs","permanent_keywords","pool_id","pool_count"]:
		if not check(after.get(field) == before.get(field),"played minion preserves acquired " + field): return false
	return true

func stock_totals() -> Dictionary:
	var totals: Dictionary = {}
	for identity in game.pool: totals["minion:"+str(identity)] = game.pool[identity]
	for identity in game.spell_pool: totals["spell:"+str(identity)] = game.spell_pool[identity]
	for player in game.state.players:
		for body in player.board + player.hand + player.shop:
			var count: int = int(body.get("pool_count",0))
			if count == 0: continue
			var kind: String = "spell" if body.get("pool_kind","") == "spell" else "minion"
			var key: String = kind+":"+str(body.get("pool_id",""))
			totals[key] = int(totals.get(key,0)) + count
	return totals

func refresh_player(player: int) -> bool:
	var before = owner(player).duplicate(true)
	var cost = 0 if before.free_rolls > 0 else 1
	if not command({"type":"roll"},"real paid bounded acquisition roll",player): return false
	return check(owner(player).gold == before.gold-cost and owner(player).board == before.board and owner(player).hand == before.hand,"refresh pays native price and leaves owned cards alone")

func acquire(identity: String, player: int = 0) -> String:
	for _step in range(60):
		if index_card("shop",identity,player)>=0 and owner(player).gold>=3: return buy_minion(identity,player)
		if owner(player).gold>=4:
			if not refresh_player(player): return ""
		elif not advance(): return ""
	check(false,"bounded real purchase unavailable; no synthetic offer",identity)
	return ""

func advance() -> bool:
	var round_before: int = game.state.round
	var hp_before: Array = [owner().health,owner(1).health,owner().armor,owner(1).armor]
	if acquiring and not check(owner().board.is_empty() and owner(1).board.is_empty(),"acquisition combat starts with both actual boards empty"): return false
	if not owner(1).ready:
		if not command({"type":"end_turn"},"ready real opponent",1): return false
	if not command({"type":"end_turn"},"resolve actual end_turn"): return false
	if not check(game.state.round==round_before+1 and game.state.phase=="recruit" and owner().alive and owner(1).alive and not owner().ready,"actual combat returns to next active recruit"): return false
	if not check(game.last_combats.size()==1 and game.last_combats[0].get("error","")=="","one successful full Game combat"): return false
	if acquiring:
		var c: Dictionary=game.last_combats[0]
		if not check(c.winner==-1 and c.left.is_empty() and c.right.is_empty() and hp_before==[owner().health,owner(1).health,owner().armor,owner(1).armor],"acquisition ties preserve both hero resources without resetting anything"): return false
		for e in c.log:
			if not check(e.get("event") not in ["attack","damage","death","hand_buff"],"no unrelated acquisition combat hazard"): return false
	report.combats.append({"scenario":scenario,"round":round_before,"acquisition":acquiring,"result":game.last_combats[0].duplicate(true)})
	return true

func buy_true_triple_player(identity: String,golden_id: String,player: int) -> String:
	var originals: Array=[]
	for _i in range(2):
		var uid: String=acquire(identity,player)
		if uid.is_empty(): return ""
		originals.append(uid)
	for _step in range(60):
		if index_card("shop",identity,player)>=0 and owner(player).gold>=3: break
		if owner(player).gold>=4:
			if not refresh_player(player): return ""
		elif not advance(): return ""
	var i: int=index_card("shop",identity,player)
	if not check(i>=0 and owner(player).gold>=3,"real affordable third normal offer for owner "+str(player)): return ""
	var offered: Dictionary=owner(player).shop[i].duplicate(true)
	var before: Dictionary=snapshot()
	if not command({"type":"buy","index":i},"actual third paid normal purchase",player): return ""
	var gi: int=index_card("hand",golden_id,player)
	if not check(gi>=0 and owner(player).gold==before.state.players[player].gold-3 and game.pool==before.pool,"real owner-specific triple payment and reserved stock"): return ""
	var golden: Dictionary=owner(player).hand[gi]
	if not check(golden.golden and golden.pool_id==identity and golden.pool_count==3,"native golden has three-copy stock entitlement"): return ""
	for uid in originals+[offered.uid]:
		if not check(index_uid("hand",uid,player)<0 and index_uid("board",uid,player)<0 and index_uid("shop",uid,player)<0,"each genuine ordinary UID consumed once for exact owner"): return ""
	var triples: Array=[]
	for event in game.events.slice(before.events.size()):
		if event.get("type")=="triple": triples.append(event)
	if not check(triples.size()==1 and triples[0].player==player and triples[0].card_id==golden_id,"one new triple receipt attributed to actual owner"): return ""
	if not check(owner(1-player).hand==before.state.players[1-player].hand and owner(1-player).board==before.state.players[1-player].board,"tripling one owner never consumes the other owner's cards"): return ""
	return golden.uid

func configure(golden: bool) -> bool:
	scenario=CASES[1 if golden else 0]
	acquiring=true
	case_counters={}
	for key in EXPECTED_COUNTERS: case_counters[key]=0
	var config=room_script.new()
	config.reset(catalog)
	config.data.bot_count=1
	config.data.seed=2026110421 if golden else 2026110420
	config.data.enabled_minions=[TWILIGHT,TAD,CYCLONE]
	config.data.enabled_spells=[FORTIFY]
	config.data.enabled_heroes=[PATCHWERK]
	config.data.selected_hero=PATCHWERK
	config.data.damage_received_listeners=false
	for key in ["enabled_anomalies","enabled_trinkets","enabled_quests","enabled_rewards"]: config.data[key]=[]
	var issues: Array=config.validate(catalog)
	if not check(issues.is_empty(),"bounded native room admits actual current sources",issues): return false
	game=game_script.new()
	var started: Dictionary=game.start(config.data,catalog)
	if not check(started.get("ok",false),"fresh actual native Game starts",started): return false
	stock_baseline=stock_totals()
	tier_started_round=1
	return check(not game.pool.has(GOLDEN),"golden source is never an ordinary stock offer")

func reach_tier4() -> bool:
	for _step in range(30):
		if owner().tier==4: return true
		var quote: int=maxi(0,int(UPGRADE_PRICES[owner().tier])-(int(game.state.round)-tier_started_round))
		if not check(owner().upgrade_cost==quote,"independent native tier-up quote"): return false
		if owner().gold<quote:
			if not advance(): return false
			continue
		var tier: int=owner().tier
		var gold: int=owner().gold
		if not command({"type":"upgrade"},"pay actual tier upgrade"): return false
		tier_started_round=game.state.round
		if not check(owner().tier==tier+1 and owner().gold==gold-quote,"one real tier and exact payment"): return false
	return check(false,"tier4 acquisition budget exhausted; no synthetic repair")

func buy_fortify() -> String:
	var i: int=index_card("shop",FORTIFY)
	if not check(i>=0 and owner().gold>=1 and owner().hand.size()<10,"real affordable Fortify offer and free hand slot"): return ""
	var offered: Dictionary=owner().shop[i].duplicate(true)
	var before: Dictionary=snapshot()
	if not check(offered.kind=="spell" and offered.pool_id==FORTIFY and offered.pool_kind=="spell" and offered.pool_count==1,"Fortify offer has one genuine spell-stock reservation"): return ""
	if not command({"type":"buy","index":i},"buy actual Fortify for one Gold"): return ""
	var held: Dictionary=unit("hand",offered.uid)
	if not check(not held.is_empty() and held.card_id==FORTIFY and held.pool_count==0 and owner().gold==before.state.players[0].gold-1 and owner().hand.size()==before.state.players[0].hand.size()+1 and index_uid("shop",offered.uid)<0,"spell purchase pays one and moves original UID once"): return ""
	if not check(game.pool==before.pool and game.spell_pool[FORTIFY]==before.spell_pool[FORTIFY]+1,"spell purchase releases exactly one reservation without touching minion stock"): return ""
	return offered.uid

func acquire_fortify() -> String:
	for _step in range(60):
		if index_card("shop",FORTIFY)>=0 and owner().gold>=1: return buy_fortify()
		if owner().gold>=2:
			if not refresh_player(0): return ""
		elif not advance(): return ""
	check(false,"bounded actual Fortify acquisition exhausted; no synthetic spell")
	return ""

func prepare_target_offers() -> bool:
	for _step in range(100):
		if index_card("shop",TWILIGHT)>=0 and index_card("shop",FORTIFY)>=0:
			if owner().gold>=1: return true
			if not owner().frozen and not command({"type":"freeze"},"freeze actual source control and final spell"): return false
			if not advance(): return false
			continue
		if owner().gold>0:
			if not refresh_player(0): return false
		elif not advance(): return false
	return check(false,"bounded genuine target offers exhausted; no forced RNG or shop mutation")

func index_in_array(bodies: Array,uid: String) -> int:
	for i in range(bodies.size()):
		if bodies[i].get("uid")==uid: return i
	return -1

func grant_plain(body: Dictionary,attack: int,health: int) -> void:
	# Expected deep copies only. Never passed a Game-owned dictionary.
	body.attack+=attack
	body.health+=health
	body.max_health+=health

func apply_expected_fortify(body: Dictionary) -> void:
	grant_plain(body,0,3)
	if "taunt" not in body.keywords: body.keywords.append("taunt")
	if "taunt" not in body.permanent_keywords: body.permanent_keywords.append("taunt")

func cast_and_verify(setup: Dictionary,spell_uid: String,target_zone: String,target_uid: String,label: String,amount: int) -> bool:
	var before: Dictionary=snapshot()
	var spell: Dictionary=unit("hand",spell_uid).duplicate(true)
	var target: Dictionary=unit(target_zone,target_uid).duplicate(true)
	var source_targeted: bool=target_zone=="board" and target_uid==setup.source
	if not check(not spell.is_empty() and spell.card_id==FORTIFY and spell.kind=="spell" and spell.pool_count==0 and not target.is_empty() and target.kind=="minion",label+": actual acquired hand spell and actual selected minion exist"): return false
	if not check(source_targeted==(label not in ["nonmatching_board","nonmatching_shop"]),label+": independent board and exact source UID gate"): return false
	var expected: Dictionary={}
	for zone in ["board","hand","shop"]: expected[zone]=before.state.players[0][zone].duplicate(true)
	expected.hand.remove_at(index_in_array(expected.hand,spell_uid))
	apply_expected_fortify(expected[target_zone][index_in_array(expected[target_zone],target_uid)])
	var minion_uids: Array=[]
	for body in expected.hand:
		if body.get("kind")=="minion": minion_uids.append(body.uid)
	var eligible: Array=minion_uids.slice(0,1) if source_targeted else []
	for uid in eligible: grant_plain(expected.hand[index_in_array(expected.hand,uid)],amount,amount)
	var grant_expected: bool=label in ["leftmost_after_spell","repeat_leftmost","reordered_leftmost"]
	if not check((eligible.size()==1)==grant_expected and eligible.size()<=1,label+": exactly the first remaining hand minion or no recipient"): return false
	if label in ["leftmost_after_spell","repeat_leftmost"]:
		if not check(minion_uids==[setup.first,setup.second] and eligible==[setup.first] and expected.hand[0].kind=="spell" and expected.hand[0].uid==setup.reserve,"preceding genuine spell is skipped and exact first of two minions selected"): return false
	if label=="reordered_leftmost":
		if not check(minion_uids==[setup.second] and eligible==[setup.second] and index_uid("board",setup.first)>=0,"real first-minion play makes exact second minion the next recipient"): return false
	if label in ["spells_only","empty_or_reward_only"]:
		if not check(minion_uids.is_empty() and eligible.is_empty(),"recipientless source cast has no hand-minion target"): return false
		if label=="spells_only" and not check(not expected.hand.is_empty() and expected.hand.all(func(body):return body.kind=="spell"),"real spells-only hand survives recipientless cast"): return false
		if label=="empty_or_reward_only":
			if setup.golden:
				if not check(expected.hand.size()==1 and expected.hand[0].card_id=="__triple_reward","genuine golden reward-only hand is retained without fabricated discard"): return false
			elif not check(expected.hand.is_empty(),"real normal final cast leaves empty hand without a grant"): return false
	var cmd: Dictionary={"type":"play","index":index_uid("hand",spell_uid),"target":index_uid(target_zone,target_uid),"target_zone":target_zone}
	if not command(cmd,"cast actual Fortify "+label): return false
	if not check(index_uid("hand",spell_uid)<0 and index_uid("board",spell_uid)<0 and index_uid("shop",spell_uid)<0 and owner().hand.size()==before.state.players[0].hand.size()-1 and owner().gold==before.state.players[0].gold,"actual cast consumes its purchased UID once without extra payment"): return false
	if not check(owner().stats.spells==before.state.players[0].stats.spells+1 and game.pool==before.pool and game.spell_pool==before.spell_pool,"two Fortify leaves count as one real cast with unchanged reserved stock"): return false
	var receipt: Dictionary=game.command_log[-1]
	if not check(receipt.player==0 and receipt.origin=="human" and receipt.command==cmd and receipt.sequence==before.state.command_sequence+1,"real command receipt binds exact selected target index and zone"): return false
	for zone in ["board","hand","shop"]:
		if not check(owner()[zone]==expected[zone],label+": exact complete "+zone+" dictionaries after one cast",{"expected":expected[zone],"actual":owner()[zone]}): return false
	if not check(owner(1)==before.state.players[1],"real casts never change another owner's native player state"): return false
	var selected: Dictionary=unit(target_zone,target_uid)
	var only_fortify: Dictionary=target.duplicate(true)
	apply_expected_fortify(only_fortify)
	if not check(selected==only_fortify,"selected board or shop target receives only Fortify health and Taunt"): return false
	if source_targeted and not check(selected.uid==setup.source and selected.attack==target.attack and selected.health==target.health+3 and selected.max_health==target.max_health+3,"source self never receives its own hand grant"): return false
	for uid in eligible:
		var old: Dictionary=before.state.players[0].hand[index_in_array(before.state.players[0].hand,uid)]
		var now: Dictionary=unit("hand",uid)
		if not check(now.attack-old.attack==amount and now.health-old.health==amount and now.max_health-old.max_health==amount and now.temporary_buffs.is_empty(),"one exact aggregate permanent Twilight hand grant, never one per spell leaf"): return false
	if not grant_expected and not check(owner().hand==expected.hand,"no unrelated or recipientless cast changes any remaining hand card"): return false
	if label in ["leftmost_after_spell","repeat_leftmost"]:
		if not check(unit("hand",setup.second)==before.state.players[0].hand[index_in_array(before.state.players[0].hand,setup.second)] and unit("hand",setup.reserve)==before.state.players[0].hand[index_in_array(before.state.players[0].hand,setup.reserve)],"second minion and preceding spell remain fully unchanged"): return false
	if label=="repeat_leftmost" and not check("taunt" in target.keywords and selected.keywords==target.keywords and selected.permanent_keywords==target.permanent_keywords,"repeat self cast adds one grant without duplicate Taunt"): return false
	case_counters.actual_hand_casts+=1
	case_counters.fortify_applications+=1
	case_counters.exact_hand_grants+=eligible.size()
	if source_targeted:
		case_counters.source_targeted_casts+=1
		if eligible.is_empty(): case_counters.recipientless_casts+=1
	else: case_counters.nonmatching_casts+=1
	if target_zone=="shop": case_counters.shop_target_casts+=1
	if label=="repeat_leftmost": case_counters.repeat_target_casts+=1
	if label=="reordered_leftmost": case_counters.reordered_target_casts+=1
	report.casts.append({"scenario":scenario,"label":label,"spell_uid":spell_uid,"spell_id":FORTIFY,"source_uid":setup.source,"source_id":unit("board",setup.source).card_id,"target_zone":target_zone,"target_uid":target_uid,"source_targeted":source_targeted,"triggered":not eligible.is_empty(),"grant_attack":amount if not eligible.is_empty() else 0,"grant_health":amount if not eligible.is_empty() else 0,"remaining_hand_minion_uids":minion_uids,"eligible_hand_uids":eligible,"expected_program_applications":1 if source_targeted else 0,"program_application_count_is_static_expectation":true,"fortify_applications":1,"command_sequence":receipt.sequence,"command":cmd,"before_owned":before.state.players[0],"after_owned":owner().duplicate(true)})
	return true

func next_turn_permanence(setup: Dictionary) -> bool:
	var before: Dictionary=snapshot()
	if not owner().frozen and not command({"type":"freeze"},"freeze actual source control for hand-grant permanence"): return false
	if not check(owner().frozen,"actual public freeze is set"): return false
	if not advance(): return false
	for zone in ["board","hand"]:
		var expected: Array=before.state.players[0][zone].duplicate(true)
		for body in expected: body.blood_gems_received_turn=0
		if not check(owner()[zone]==expected,"next turn preserves every "+zone+" field except explicit native zero counter initialization",{"expected":expected,"actual":owner()[zone]}): return false
	for old in before.state.players[0].shop:
		var expected: Dictionary=old.duplicate(true)
		expected.blood_gems_received_turn=0
		if not check(unit("shop",old.uid)==expected,"frozen native shop UID preserves Fortify and all unrelated fields"): return false
	if not check(index_uid("hand",setup.first)>=0 and index_uid("hand",setup.second)>=0 and unit("hand",setup.first).temporary_buffs.is_empty() and unit("hand",setup.second).temporary_buffs.is_empty(),"both real hand minions persist and permanent gain has no temporary ledger"): return false
	for combat in game.last_combats:
		for event in combat.get("log",[]):
			if not check(event.get("event")!="combat_spell_completed","permanence transition contains no secondary combat spell route"): return false
	return check(stock_totals()==stock_baseline,"all stock remains conserved after real next-turn hand permanence")

func sell_acquired(uid: String) -> bool:
	var before: Dictionary=snapshot()
	var body: Dictionary=unit("board",uid).duplicate(true)
	if not check(not body.is_empty() and body.card_id in [TWILIGHT,GOLDEN,CYCLONE],"only genuinely acquired source or effect-free hand recipient is sold"): return false
	if not command({"type":"sell","index":index_uid("board",uid)},"sell real acquired minion"): return false
	var expected_pool: Dictionary=before.pool.duplicate(true)
	expected_pool[body.pool_id]+=body.pool_count
	if not check(index_uid("board",uid)<0 and index_uid("hand",uid)<0 and index_uid("shop",uid)<0 and owner().gold==before.state.players[0].gold+1 and game.pool==expected_pool and game.spell_pool==before.spell_pool,"sale returns exact original stock entitlement once and pays one Gold"): return false
	case_counters.sold_units+=1
	return true

func execute_lifecycle(setup: Dictionary,amount: int,execution_label: String) -> bool:
	var targets: Array=[["board",setup.board_control],["shop",setup.shop_source],["board",setup.source],["board",setup.source]]
	for i in range(4):
		if not cast_and_verify(setup,setup.spells[i],targets[i][0],targets[i][1],CAST_LABELS[i],amount): return false
	if not roundtrip(execution_label+" two exact hand grants before next-turn native roundtrip"): return false
	if not next_turn_permanence(setup): return false
	if not play_minion(setup.first): return false
	if not cast_and_verify(setup,setup.spells[4],"board",setup.source,CAST_LABELS[4],amount): return false
	if not roundtrip(execution_label+" reordered hand recipient exact grant native roundtrip"): return false
	if not play_minion(setup.second): return false
	if not cast_and_verify(setup,setup.spells[5],"board",setup.source,CAST_LABELS[5],amount): return false
	if not cast_and_verify(setup,setup.reserve,"board",setup.source,CAST_LABELS[6],amount): return false
	for uid in [setup.first,setup.second,setup.source]:
		if not sell_acquired(uid): return false
	return check(stock_totals()==stock_baseline,"all stock remains conserved after real source and recipient sales")

func lifecycle_case(golden: bool) -> bool:
	if not configure(golden) or not reach_tier4(): return false
	var source: String=buy_true_triple_player(TWILIGHT,GOLDEN,0) if golden else acquire(TWILIGHT)
	var board_control: String=acquire(TAD)
	var reserve: String=acquire_fortify()
	var first: String=acquire(CYCLONE)
	var second: String=acquire(CYCLONE)
	if source.is_empty() or board_control.is_empty() or reserve.is_empty() or first.is_empty() or second.is_empty(): return false
	var spells: Array=[]
	for _i in range(5):
		var spell_uid: String=acquire_fortify()
		if spell_uid.is_empty(): return false
		spells.append(spell_uid)
	if not check(owner().hand.size()==10,"genuine setup respects native ten-card hand capacity before playing minions"): return false
	if not prepare_target_offers(): return false
	var shop_source: String=owner().shop[index_card("shop",TWILIGHT)].uid
	# Golden play awards its real reward only after releasing a slot; never discard it.
	if not play_minion(board_control) or not play_minion(source): return false
	acquiring=false
	var last_spell: String=buy_fortify()
	if last_spell.is_empty(): return false
	spells.append(last_spell)
	if not check(unit("board",source).attack==(6 if golden else 3) and unit("board",source).health==(14 if golden else 7) and unit("board",source).max_health==unit("board",source).health and unit("board",source).temporary_buffs.is_empty() and unit("board",source).pool_count==(3 if golden else 1),"genuine acquired source has exact 37.0.2 body and stock entitlement"): return false
	var rewards: Array=owner().hand.filter(func(body):return body.get("card_id")=="__triple_reward")
	if not check(rewards.size()==(1 if golden else 0) and owner().hand.size()==(10 if golden else 9),"native genuine triple reward is retained without hand overflow"): return false
	if golden and not check(rewards[0].kind=="spell" and rewards[0].effects==[{"type":"spell_discover","tier":5}],"genuine tier-four golden play awards exact native tier-five reward"): return false
	if not check(owner().hand[0].uid==reserve and owner().hand[0].kind=="spell" and owner().hand[1].uid==first and owner().hand[2].uid==second and unit("hand",first).card_id==CYCLONE and unit("hand",second).card_id==CYCLONE,"real paid hand order is preceding spell then two exact non-Murloc minions"): return false
	if not check(shop_source!=source and unit("shop",shop_source).card_id==TWILIGHT and unit("board",board_control).card_id==TAD,"nonmatching controls are another owned Murloc and a distinct real shop source"): return false
	if not roundtrip("genuine setup immediately before actual targeted hand casts"): return false
	var replay_path: String=report.loads[-1].path
	var before: Dictionary=snapshot()
	var setup: Dictionary={"source":source,"board_control":board_control,"reserve":reserve,"first":first,"second":second,"shop_source":shop_source,"spells":spells,"golden":golden}
	var amount: int=18 if golden else 9
	if not execute_lifecycle(setup,amount,"first execution"): return false
	var after: Dictionary=snapshot()
	var fresh: RefCounted=game_script.new()
	if not check(fresh.load_from(replay_path,catalog)==OK,"fresh replay loads exact genuine setup save"): return false
	game=fresh
	if not check(snapshot()==before,"replay restores all 13 native persisted fields"): return false
	if not execute_lifecycle(setup,amount,"deterministic replay"): return false
	if not check(snapshot()==after,"same actual public command sequence reproduces all 13 persisted fields"): return false
	case_counters.replay_comparisons+=1
	if not roundtrip("permanent played and sold result native roundtrip"): return false
	if not check(case_counters==EXPECTED_COUNTERS,"exact fixed lifecycle counters match before any gameplay credit",case_counters): return false
	report.counters_by_case[scenario]=case_counters.duplicate(true)
	report.completed_cases.append(scenario)
	return true

func finish() -> void:
	report.status="passed_narrow_new_reconstruction_only" if failures==0 and report.completed_cases==CASES else "failed_or_incomplete_no_credit"
	report.failures=failures
	persist()
	print("TWILIGHT_LIFECYCLE_PUBLIC_TERMINAL ",JSON.stringify(report))
	quit(0 if report.status=="passed_narrow_new_reconstruction_only" else 1)

func _initialize() -> void:
	if "--reviewed-twilight-lifecycle" not in OS.get_cmdline_user_args():
		print("TWILIGHT_LIFECYCLE_DRAFT_HOLD: requires new independently reviewed sealed candidate and parent release")
		quit(2);return
	game_script=load("res://core/game.gd")
	room_script=load("res://core/room_config.gd")
	catalog=load("res://core/catalog.gd").new()
	catalog.load_catalog()
	report.execution_fingerprint=catalog.execution_fingerprint
	if not check(catalog.load_errors.is_empty(),"candidate Catalog clean",catalog.load_errors): finish();return
	for id in [TWILIGHT,GOLDEN]:
		var golden: bool=id==GOLDEN
		var card: Dictionary=catalog.get_card(id)
		var effects: Array=[{"type":"on_target_spell_hand_buff","target_scope":"self","scope":"leftmost","attack":18 if golden else 9,"health":18 if golden else 9}]
		if not check(card.effects==effects and card.tier==4 and card.attack==(6 if golden else 3) and card.health==(14 if golden else 7) and card.is_golden==golden and card.tribes==["鱼人"] and (card.normal_id==TWILIGHT if golden else card.golden_id==GOLDEN),"pinned complete Twilight normal and golden identity body and single-grant program"): finish();return
	var tad: Dictionary=catalog.get_card(TAD)
	if not check(tad.tier==2 and tad.attack==2 and tad.health==2 and tad.tribes==["鱼人"] and tad.effects==[{"type":"on_sell_random_card","tribe":"鱼人","count":1}] and tad.keywords.is_empty(),"pinned admitted native Tad control with uninvoked sale effect"): finish();return
	var control: Dictionary=catalog.get_card(CYCLONE)
	if not check(control.tier==1 and control.attack==2 and control.health==1 and control.tribes==["元素"] and control.effects.is_empty() and control.keywords==["divine_shield","windfury"],"pinned admitted native non-Murloc recipient without recruit effects"): finish();return
	var fortify: Dictionary=catalog.get_card(FORTIFY)
	if not check(fortify.cost==1 and fortify.tier==1 and fortify.effects==[{"type":"spell_buff","scope":"target","attack":0,"health":3,"allow_shop":true,"temporary":false},{"type":"spell_keyword","scope":"target","keyword":"taunt","allow_shop":true,"temporary":false}],"pinned Fortify two-leaf permanent health and Taunt program"): finish();return
	for golden in [false,true]:
		if not lifecycle_case(golden): finish();return
	finish()
