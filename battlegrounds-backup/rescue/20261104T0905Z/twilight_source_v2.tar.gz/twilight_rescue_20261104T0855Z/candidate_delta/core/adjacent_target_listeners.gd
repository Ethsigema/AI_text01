extends RefCounted
# Native selected Tide cast, not a hand play. Board gains stay combat-local;
# real hand gains use the existing permanent hand journal/settlement writer.
const Hand=preload("res://core/combat_hand.gd")
const HandStats=preload("res://core/kill_hand_host.gd")
const Gains=preload("res://core/attack_gain_listeners.gd")
const Keep=preload("res://core/combat_keep_gains.gd")
const Tide=preload("res://core/adjacent_tide_sources.gd")
const FAMILY="native-adjacent-tide-target-listeners-v1"
const ORIGIN="native_adjacent_deathrattle_tide"
const PROGRAMS={
 "BG36_703":[{"type":"on_target_spell_hand_buff","target_scope":"self","scope":"leftmost","attack":9,"health":9}],
 "BG36_703_G":[{"type":"on_target_spell_hand_buff","target_scope":"self","scope":"leftmost","attack":18,"health":18}],
 "BG36_704":[{"type":"on_target_spell_hand_buff","target_scope":"tribe","target_tribe":"鱼人","scope":"board_and_hand","tribe":"鱼人","attack":3,"health":4}],
 "BG36_704_G":[{"type":"on_target_spell_hand_buff","target_scope":"tribe","target_tribe":"鱼人","scope":"board_and_hand","tribe":"鱼人","attack":6,"health":8}]}
static func claimed(unit: Dictionary) -> bool: return PROGRAMS.has(unit.get("card_id"))
static func source_error(engine,unit: Dictionary) -> String:
 if not claimed(unit) or unit.get("effects")!=PROGRAMS[unit.card_id]: return "adjacent_target_complete_native_program_required"
 var template: Dictionary=engine._options.get("hand_card_templates",{}).get(unit.card_id,{})
 if template.get("effects")!=PROGRAMS[unit.card_id]: return "adjacent_target_native_template_required"
 for key in ["card_id","kind","name","tier","tribes","golden"]:
  if unit.get(key)!=template.get(key): return "adjacent_target_changed_native_"+key
 if not unit.get("attachments",[]).is_empty(): return "adjacent_target_attachments_held"
 return ""
static func owner_context(engine,player: Dictionary) -> Dictionary:
 var issue=""
 var qualified: bool=player.get("board",[]).any(func(unit):return claimed(unit))
 if qualified:
  if not engine._mechanic_effects(player).is_empty(): issue="adjacent_target_owned_modifier_composition_held"
  for unit in player.get("board",[]):
   if claimed(unit):
    if unit.get("effects")!=PROGRAMS[unit.card_id]: issue="adjacent_target_original_observer_changed"
   elif unit.get("card_id") in Tide.IDS:
    var source_issue: String=Tide.unit_error(unit)
    if not source_issue.is_empty(): issue=source_issue
   elif not unit.get("effects",[]).is_empty(): issue="adjacent_target_original_owner_reader_composition_held"
  for card in player.get("hand",[]):
   if card.get("kind")=="minion" and not card.get("effects",[]).is_empty(): issue="adjacent_target_original_hand_reader_composition_held"
 return {"owner":player.id,"error":issue,"qualified":qualified}
static func domain_error(engine,side: int) -> String:
 var context: Dictionary=engine._options.get("native_combat_spell_contexts",[])[side].get("target_listeners",{})
 if context.get("owner")!=engine._options["native_combat_spell_contexts"][side].owner: return "adjacent_target_real_owner_required"
 if not context.get("qualified",false): return "adjacent_target_original_owner_domain_required"
 if not str(context.get("error","missing")).is_empty(): return str(context.get("error"))
 if not engine._combat_hand.available[side]: return "adjacent_target_complete_actual_hand_required"
 for unit in engine._boards[side]:
  if not Gains.active(unit): continue
  if claimed(unit):
   var issue=source_error(engine,unit)
   if not issue.is_empty(): return issue
  elif unit.get("card_id") in Tide.IDS:
   var issue=Tide.unit_error(unit)
   if not issue.is_empty(): return issue
  elif not unit.get("effects",[]).is_empty(): return "adjacent_target_other_board_listener_composition_held"
 for card in engine._combat_hand.hands[side]:
  if card.get("kind")=="minion" and (not card.get("effects",[]).is_empty() or card.get("generated",false)): return "adjacent_target_nonplain_or_generated_hand_held"
 return ""
static func target_gate(engine,side: int,target_uid: String) -> String:
 if target_uid.is_empty(): return ""
 return domain_error(engine,side)
static func plan(engine,side: int,board: Array,hand: Array,target_uid: String) -> Dictionary:
 var groups: Array=[];var ticks=0
 if target_uid.is_empty() or not board.any(func(unit):return claimed(unit) and Gains.active(unit)): return {"ok":true,"error":"","groups":groups,"hand":hand.duplicate(true),"ticks":0}
 var issue=domain_error(engine,side)
 if not issue.is_empty(): return {"ok":false,"error":issue}
 var shadow_hand=hand.duplicate(true)
 var target: Dictionary=Gains._find(board,target_uid)
 if not Gains.living(target): return {"ok":false,"error":"adjacent_target_actual_selected_unit_required"}
 var owner=int(engine._options["native_combat_spell_contexts"][side].owner)
 for source in board:
  if not claimed(source) or not Gains.active(source): continue
  var effect: Dictionary=PROGRAMS[source.card_id][0]
  if effect.target_scope=="self" and source.uid!=target_uid: continue
  if effect.target_scope=="tribe" and not engine._tribe_matches(target,"鱼人"): continue
  var before_board=board.duplicate(true);var before_hand=shadow_hand.duplicate(true);var steps: Array=[]
  var recipients: Array=[]
  for card in shadow_hand:
   if card.get("kind")!="minion" or (effect.scope!="leftmost" and not engine._tribe_matches(card,"鱼人")): continue
   recipients.append(card)
   if effect.scope=="leftmost": break
  for card in recipients:
   var projected=HandStats.adjust_copy(card,owner,int(effect.attack),int(effect.health),engine._options.has(Gains.Received.CONTEXT))
   if not str(projected.error).is_empty(): return {"ok":false,"error":projected.error}
   var before=card.duplicate(true);card.clear();card.merge(projected.after,true)
   steps.append({"zone":"hand","uid":card.uid,"before":before,"after":card.duplicate(true)})
  if effect.scope=="board_and_hand":
   for card in board:
    if not Gains.living(card) or not engine._tribe_matches(card,"鱼人"): continue
    var before=card.duplicate(true)
    issue=Keep._adjust(card,int(effect.attack),int(effect.health),engine._options.has(Gains.Received.CONTEXT))
    if not issue.is_empty(): return {"ok":false,"error":issue}
    steps.append({"zone":"board","uid":card.uid,"before":before,"after":card.duplicate(true)})
  ticks+=steps.size()
  groups.append({"source":source.uid,"source_id":source.card_id,"effect":effect.duplicate(true),"target_uid":target_uid,"board_before":before_board,"hand_before":before_hand,"board_after":board.duplicate(true),"hand_after":shadow_hand.duplicate(true),"steps":steps})
 return {"ok":true,"error":"","groups":groups,"hand":shadow_hand,"ticks":ticks}
static func commit(engine,side: int,cast_source: Dictionary,completion: int,plan: Dictionary) -> bool:
 if plan.groups.is_empty(): return true
 var host=engine._combat_ring_cast_host
 var ticket: Dictionary=host._ticket
 if ticket.get("origin")!=ORIGIN or ticket.get("stage")!="completion" or not is_same(ticket.get("source"),cast_source) or ticket.get("side")!=side or ticket.get("spell")!=Tide.SPELL: engine._fail("adjacent_target_true_private_tide_capability_required");return false
 if completion<0 or completion>=engine._log.size(): engine._fail("adjacent_target_completion_missing");return false
 var cast: Dictionary=engine._log[completion]
 if cast.get("event")!="combat_spell_completed" or cast.get("origin")!=ORIGIN or cast.get("target_uid")!=ticket.get("target_uid") or cast.get("source")!=cast_source.get("uid") or cast.get("activation_sequence")!=ticket.get("activation"): engine._fail("adjacent_target_actual_cast_receipt_changed");return false
 for group in plan.groups:
  if engine._boards[side]!=group.board_before or engine._combat_hand.hands[side]!=group.hand_before: engine._fail("adjacent_target_group_prefix_changed");return false
  var source: Dictionary=Gains._find(engine._boards[side],group.source)
  if not Gains.active(source) or not source_error(engine,source).is_empty() or source.card_id!=group.source_id or group.target_uid!=cast.target_uid: engine._fail("adjacent_target_real_observer_changed");return false
  for step in group.steps:
   var target: Dictionary=Gains._find(engine._combat_hand.hands[side] if step.zone=="hand" else engine._boards[side],step.uid)
   if target!=step.before: engine._fail("adjacent_target_real_recipient_changed");return false
   if not engine._tick(FAMILY): return false
   if step.zone=="hand":
    if not engine._commit_native_hand_stats(side,target,step.after): return false
    engine._emit("hand_buff",{"type":"hand_buff","side":side,"source":source.uid,"source_id":source.card_id,"target_uid":target.uid,"attack_delta":group.effect.attack,"health_delta":group.effect.health,"attack":target.attack,"health":target.health,"max_health":target.max_health,"permanent":true,"repetition":1,"adjacent_target_family":FAMILY,"owner":ticket.owner,"completion_sequence":completion,"activation_sequence":ticket.activation,"cast_target_uid":cast.target_uid})
   else:
    if not engine._adjust_board_stats(target,int(group.effect.attack),int(group.effect.health)): return false
    engine._emit("trigger_buff",{"side":side,"source":source.uid,"source_id":source.card_id,"target":target.uid,"reason":FAMILY,"completion_sequence":completion,"attack_delta":group.effect.attack,"health_delta":group.effect.health,"attack":target.attack,"health":target.health,"max_health":target.max_health})
   if not engine._error.is_empty() or target!=step.after: engine._fail("adjacent_target_actual_writer_changed");return false
  if engine._boards[side]!=group.board_after or engine._combat_hand.hands[side]!=group.hand_after: engine._fail("adjacent_target_group_suffix_changed");return false
 return true
static func settlement_error(unit: Dictionary,owner: int,event: Dictionary,result: Dictionary,received: bool) -> String:
 if event.get("adjacent_target_family")!=FAMILY: return ""
 if event.get("type")!="hand_buff" or event.get("permanent")!=true or event.get("owner")!=owner or event.get("target_uid")!=unit.get("uid") or not PROGRAMS.has(event.get("source_id")): return "adjacent_target_changed_hand_receipt"
 var effect: Dictionary=PROGRAMS[event.source_id][0]
 if event.get("attack_delta")!=effect.attack or event.get("health_delta")!=effect.health: return "adjacent_target_changed_hand_amount"
 var log: Array=result.get("log",[]);var index=int(event.get("completion_sequence",-1));var activation=int(event.get("activation_sequence",-1))
 if activation<0 or index<=activation or index>=log.size(): return "adjacent_target_missing_result_parent"
 var cast: Dictionary=log[index];var issuer: Dictionary=log[activation]
 if cast.get("event")!="combat_spell_completed" or cast.get("origin")!=ORIGIN or cast.get("caster_kind")!="player" or cast.get("spell_id")!=Tide.SPELL or cast.get("owner")!=owner or cast.get("side")!=event.get("side") or cast.get("target_uid")!=event.get("cast_target_uid") or cast.get("activation_sequence")!=activation: return "adjacent_target_result_cast_changed"
 if issuer.get("event")!="native_combat_spell_activation" or issuer.get("origin")!=ORIGIN or issuer.get("source_id") not in Tide.IDS or issuer.get("target_uid")!=cast.target_uid or issuer.get("source")!=cast.get("source"): return "adjacent_target_result_issuer_changed"
 if effect.target_scope=="self" and event.get("source")!=cast.target_uid: return "adjacent_target_self_target_changed"
 return str(HandStats.adjust_copy(unit,owner,int(effect.attack),int(effect.health),received).error)
