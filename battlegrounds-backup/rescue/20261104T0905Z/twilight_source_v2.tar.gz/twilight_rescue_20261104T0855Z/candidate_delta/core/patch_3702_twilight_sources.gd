extends RefCounted
## Newly reconstructed bounded source revision; historical evidence is not acceptance.
const REVISION: String="partial-37.0.2-twilight-reconstructed-20261104-v1"
const IDS: Array=["BG36_703","BG36_703_G"]
const IDENTITY_FIELDS: Array=["id","card_code","dbf_id","kind","name","tier","tribes","keywords","is_golden","normal_id","golden_id"]
const OVERLAY: String="data/patch_3702_twilight_overlay.json"
const FILE_SHA256: Dictionary={"data/patch_3702_twilight_overlay.json":"8a4efa3de94b23ccd64cd346e5baa85c043528928c371b7ef9050ad03b8388f8","research/patch_3702_twilight/source_evidence.json":"a3371229b2d13651730d7666b9e7978e36efa1bd92302df1af0ca75c579b9ce5","research/patch_3702_twilight/official_patch_twilight_excerpt.html":"accc8b52e03182a133a44440a0cb166f3c747d7b9c3df1b4d4285034866b6d82","research/patch_3702_twilight/native/BG36_703.xml":"4d249f18fe2c3dc663b2b4f3fee2516e31cb6f0b10bbf5bee623392ce6b10f74","research/patch_3702_twilight/native/BG36_703_G.xml":"4984faa86c50fc3da5edb1b991e0347353b768b850752abdca4a8e5d62f37f9e"}
const RUNTIME_PATHS: Array=["core/patch_3702_twilight_sources.gd","data/patch_3702_twilight_overlay.json","research/patch_3702_twilight/source_evidence.json","research/patch_3702_twilight/official_patch_twilight_excerpt.html","research/patch_3702_twilight/native/BG36_703.xml","research/patch_3702_twilight/native/BG36_703_G.xml","core/adjacent_target_listeners.gd","core/dark_gift_qualification.gd","core/damage_listener_room.gd","core/lucky_egg_sources.gd"]
static func accepts_id(id: Variant) -> bool:
	return id is String and id in IDS
static func same(a: Variant,b: Variant) -> bool:
	# JSON numbers are floats while Catalog normalizes integral values to ints.
	# Compare finite integral numbers symmetrically, never accepting booleans.
	if b is int or b is float:
		return (a is int or a is float) and not a is bool and is_finite(float(a)) and is_finite(float(b)) and a==floor(a) and b==floor(b) and a==b
	if typeof(a)!=typeof(b): return false
	if b is Dictionary:
		if a.size()!=b.size(): return false
		for key in b:
			if not a.has(key) or not same(a[key],b[key]): return false
		return true
	if b is Array:
		if a.size()!=b.size(): return false
		for index in range(b.size()):
			if not same(a[index],b[index]): return false
		return true
	return a==b
static func normalize(value: Variant) -> Variant:
	if value is float and is_finite(value) and value==floor(value) and value>=-9007199254740991 and value<=9007199254740991: return int(value)
	if value is Array:
		var items: Array=[]
		for item in value: items.append(normalize(item))
		return items
	if value is Dictionary:
		var fields: Dictionary={}
		for key in value: fields[key]=normalize(value[key])
		return fields
	return value
static func proof_error() -> String:
	for path in FILE_SHA256:
		if not FileAccess.file_exists("res://"+path) or FileAccess.get_sha256("res://"+path)!=FILE_SHA256[path]: return "partial_3702_twilight_evidence_changed:"+str(path)
	return ""
static func packet() -> Dictionary:
	if not proof_error().is_empty(): return {}
	var value: Variant=JSON.parse_string(FileAccess.get_file_as_string("res://"+OVERLAY))
	if not value is Dictionary or value.get("revision")!=REVISION or not value.get("cards") is Array or value.cards.size()!=IDS.size(): return {}
	var result: Dictionary={}
	for row in value.cards:
		if not row is Dictionary or not accepts_id(row.get("id")) or result.has(row.id): return {}
		for key in ["expected_baseline","effective_fields","lucky_egg_expected_baseline"]:
			if not row.get(key) is Dictionary: return {}
		result[row.id]=normalize(row)
	return result
static func apply_overlay(cards: Dictionary) -> String:
	var rows: Dictionary=packet()
	if rows.size()!=IDS.size(): return "partial_3702_twilight_missing_or_changed_packet"
	var staged: Dictionary={}
	for id in IDS:
		# Authenticate both complete historical rows before changing either.
		if not cards.has(id) or not same(cards[id],rows[id].expected_baseline): return "partial_3702_twilight_changed_baseline:"+id
		var merged: Dictionary=cards[id].duplicate(true)
		merged.merge(rows[id].effective_fields,true)
		if str(merged.text).sha256_text()!=merged.coverage_text_sha256: return "partial_3702_twilight_changed_text_digest:"+id
		staged[id]=merged
	for id in IDS: cards[id]=staged[id]
	return ""
static func source_error(card: Dictionary) -> String:
	var id: Variant=card.get("id")
	if not accepts_id(id): return "partial_3702_twilight_unknown_source"
	var rows: Dictionary=packet()
	if rows.size()!=IDS.size(): return "partial_3702_twilight_missing_or_changed_packet"
	# Bind immutable identity facts without freezing later pool/display policy.
	for key in IDENTITY_FIELDS:
		if not card.has(key) or not same(card[key],rows[id].expected_baseline[key]): return "partial_3702_twilight_changed_identity:"+str(id)+":"+str(key)
	for key in rows[id].effective_fields:
		if not card.has(key) or not same(card[key],rows[id].effective_fields[key]): return "partial_3702_twilight_changed_effective_source:"+str(id)+":"+str(key)
	return ""
static func lucky_egg_target_error(card: Dictionary,historical_expected: Dictionary) -> String:
	var id: Variant=card.get("id")
	if not accepts_id(id): return "partial_3702_twilight_wrong_provider_identity"
	var rows: Dictionary=packet()
	if rows.size()!=IDS.size(): return "partial_3702_twilight_missing_or_changed_packet"
	if not same(historical_expected,rows[id].lucky_egg_expected_baseline): return "partial_3702_twilight_changed_lucky_egg_historical_target:"+str(id)
	var issue: String=source_error(card)
	if not issue.is_empty(): return issue
	var expected: Dictionary=historical_expected.duplicate(true)
	for key in ["attack","health","effects"]: expected[key]=rows[id].effective_fields[key]
	for key in expected:
		if not card.has(key) or not same(card[key],expected[key]): return "partial_3702_twilight_changed_lucky_egg_target:"+str(id)+":"+str(key)
	return ""
