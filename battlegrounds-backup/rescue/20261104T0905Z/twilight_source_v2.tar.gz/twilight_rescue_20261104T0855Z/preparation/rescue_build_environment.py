"""Current read-only inputs plus explicit historical metadata for byte comparison.

This does not claim the missing independent-review file was restored. The
historical review SHA is retained solely as an original source-evidence datum.
"""
from common import *

RESTORE = Path('/workspace/scratch/dd4f12b08ec0/recovery_restart_20261104T0855Z')
PACKAGE = RESTORE / 'early_source'
MURCULES = RESTORE / 'restored_murcules_project'
B = RESTORE / 'restored_early_source_project'
A = PACKAGE / 'ashen'
T = PACKAGE / 'tidecaller'
C = Path('/tmp/twilight_rescue_20261104T0855Z')
D = C / 'candidate_delta'
XML = PACKAGE / 'verified_source_packet/CardDefs.Bacon.37.0.2.256589.xml'
HTML = PACKAGE / 'verified_source_packet/official_patch_3702.html'
HISTORICAL_ROOT = Path('/workspace/shared/recovery_restart_20261104T0750Z')
HISTORICAL_B = HISTORICAL_ROOT / 'restored_murcules_project'
HISTORICAL_A = HISTORICAL_ROOT / 'rebuild_ashen_candidate'
HISTORICAL_T = HISTORICAL_ROOT / 'rebuild_tidecaller_candidate'
HISTORICAL_C = HISTORICAL_ROOT / 'rebuild_twilight_candidate'
HISTORICAL_XML = HISTORICAL_A / 'source_research/CardDefs.Bacon.37.0.2.256589.xml'
HISTORICAL_HTML = HISTORICAL_A / 'source_research/official_patch_3702.html'
CURRENT_MAP = json.loads((PACKAGE / 'FINAL_RUNTIME_MAP.json').read_text())['files']

def historical_input_path(name):
    # Origins derive from authenticated manifests, not fabricated source data.
    for layer, old_root in [(T, HISTORICAL_T), (A, HISTORICAL_A)]:
        if name in json.loads((layer / 'DELTA_MANIFEST.json').read_text())['runtime_changes']:
            return str(old_root / 'files' / name)
    return str(HISTORICAL_B / name)

def layers():
    assert sha(XML) == XML_SHA and sha(HTML) == HTML_SHA
    paths, origins, manifests = {}, {}, []
    for layer, expected, origin, logical_root in [(A, ASHEN_SHA, 'ashen_delta', HISTORICAL_A), (T, TIDE_SHA, 'tidecaller_delta', HISTORICAL_T)]:
        assert sha(layer / 'DELTA_MANIFEST.json') == expected
        manifest = json.loads((layer / 'DELTA_MANIFEST.json').read_text())
        assert manifest['baseline'] == str(HISTORICAL_B) and manifest['output'] == str(logical_root / 'files')
        actual_set = {p.relative_to(layer / 'files').as_posix() for p in (layer / 'files').rglob('*') if p.is_file()}
        assert actual_set == set(manifest['runtime_changes'])
        for name, row in manifest['runtime_changes'].items():
            rel = Path(name)
            assert not rel.is_absolute() and '..' not in rel.parts and rel.as_posix() == name
            prior = paths.get(name, MURCULES / name)
            if row['before_sha256'] is None: assert not prior.exists()
            else: assert sha(prior) == row['before_sha256'], name
            current = layer / 'files' / name
            assert current.is_file() and not current.is_symlink()
            assert sha(current) == row['after_sha256'] and current.stat().st_size == row['size']
            paths[name], origins[name] = current, origin
        manifests.append(manifest)
    # Authenticate all source inputs used by the builder against the restored
    # package's exact final runtime map, without copying that runtime.
    names = set(paths) | {'data/catalog_raw.json', 'data/catalog.json', 'data/source_catalog/minions.json', 'data/catalog_value_overrides.json', 'data/current_scope_manifest.json', 'data/tribe_pool_requirements.json', 'data/patch_3702_membership.json', 'core/patch_3702_membership_sources.gd', 'core/game.gd', 'core/recruit_hand_effects.gd', 'core/recruit_token_sources.gd', 'core/factory_line_sources.gd', 'core/dark_gift_sources.gd', 'research/lucky_egg_rebuilt/target_contracts.json', 'research/adjacent_target_listeners_20261029/FRONTIER.json'}
    for name in names:
        source = paths.get(name, B / name)
        assert sha(source) == CURRENT_MAP[name]
        assert sha(B / name) == CURRENT_MAP[name]
    return paths, origins, manifests
