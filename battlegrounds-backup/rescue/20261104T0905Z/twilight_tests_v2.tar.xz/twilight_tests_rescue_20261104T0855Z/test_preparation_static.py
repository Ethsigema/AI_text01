"""No-engine source and validator checks. Fixtures confer zero gameplay credit."""
from pathlib import Path
from copy import deepcopy
import hashlib,importlib.util,json,re,sys,unittest,xml.etree.ElementTree as ET
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent;ROOT=HERE.parent
PUBLIC=(HERE/'twilight_lifecycle_public.gd').read_text()
CONTRACT=json.loads((HERE/'harness_contract.json').read_text())
spec=importlib.util.spec_from_file_location('twilight_validator',HERE/'validate_twilight_report.py');validator=importlib.util.module_from_spec(spec);spec.loader.exec_module(validator)

def functions(text):return {m.group(1):m.group(0).strip() for m in re.finditer(r'^func (\w+)\([^\n]+(?:\n(?!func )[^\n]*)*',text,re.M)}

def body(uid,identity,kind='minion',attack=2,health=1):
 return {'uid':uid,'card_id':identity,'kind':kind,'attack':attack,'health':health,'max_health':health,'keywords':[],'permanent_keywords':[],'temporary_buffs':[],'pool_count':0 if kind=='spell' else 1}

def fixture(case,index):
 c=CONTRACT['cast_contract'];amount=c['vectors_by_case'][case][0];label=c['ordered_labels_per_case'][index]
 source=body('source',c['source_ids_by_case'][case],attack=6 if amount==18 else 3,health=14 if amount==18 else 7)
 board=[source,body('control','BG22_202')];shop=[body('shop-source','BG36_703',attack=3,health=7)]
 count=c['ordered_remaining_hand_minion_counts_per_case'][index]
 hand=[body('reserve','BG28_503','spell')]
 if count==2:hand += [body('first','BGS_119'),body('second','BGS_119')]
 elif count==1:hand += [body('second','BGS_119')];board.append(body('first','BGS_119'))
 if label=='empty_or_reward_only':hand=[]
 if amount==18:hand.append(body('reward','__triple_reward','spell'))
 spell=body('actual-cast','BG28_503','spell');hand.append(spell)
 before={'board':board,'shop':shop,'hand':hand,'gold':4,'stats':{'spells':2}}
 targeted=c['ordered_source_targeted_per_case'][index];trigger=c['ordered_triggered_per_case'][index]
 zone=c['ordered_target_zones_per_case'][index];uid='control' if label=='nonmatching_board' else 'shop-source' if zone=='shop' else 'source'
 expected=deepcopy(before);expected['hand']=[b for b in expected['hand'] if b['uid']!='actual-cast'];expected['stats']['spells']+=1
 selected=next(b for b in expected[zone] if b['uid']==uid);selected['health']+=3;selected['max_health']+=3;selected['keywords'].append('taunt');selected['permanent_keywords'].append('taunt')
 minions=[b for b in expected['hand'] if b['kind']=='minion'];eligible=minions[:1] if targeted else []
 for b in eligible:
  for key in ['attack','health','max_health']:b[key]+=amount
 return {'scenario':case,'label':label,'spell_uid':'actual-cast','spell_id':'BG28_503','source_uid':'source','source_id':source['card_id'],'target_zone':zone,'target_uid':uid,'source_targeted':targeted,'triggered':trigger,'grant_attack':amount if trigger else 0,'grant_health':amount if trigger else 0,'remaining_hand_minion_uids':[b['uid'] for b in minions],'eligible_hand_uids':[b['uid'] for b in eligible],'expected_program_applications':int(targeted),'program_application_count_is_static_expectation':True,'fortify_applications':1,'command_sequence':15,'command':{'type':'play','index':len(hand)-1,'target':next(i for i,b in enumerate(before[zone]) if b['uid']==uid),'target_zone':zone},'before_owned':before,'after_owned':expected}

class PreparationStatic(unittest.TestCase):
 def test_new_harness_hash_and_identity(self):
  self.assertEqual(hashlib.sha256((HERE/'twilight_lifecycle_public.gd').read_bytes()).hexdigest(),CONTRACT['harness_sha256'])
  self.assertEqual(CONTRACT['historical_acceptance_credit'],0);self.assertTrue(CONTRACT['not_original_artifact'])
  self.assertIn('NEW RECONSTRUCTION',PUBLIC);self.assertIn('passed_narrow_new_reconstruction_only',PUBLIC)
 def test_constants_match(self):
  parse=lambda k:json.loads(re.search(r'^const '+k+r' = (.+)$',PUBLIC,re.M).group(1))
  self.assertEqual(parse('CASES'),CONTRACT['ordered_cases']);self.assertEqual(parse('CAST_LABELS')*2,CONTRACT['cast_contract']['ordered_labels_per_case'])
  for values in CONTRACT['expected_counters_by_case'].values():self.assertEqual(parse('EXPECTED_COUNTERS'),values)
 def test_no_private_or_injected_gameplay(self):
  self.assertNotRegex(PUBLIC,r'game\._\w+\s*\(')
  self.assertNotRegex(PUBLIC,r'game\.(?:state|pool|spell_pool|rng|next_uid)(?:\.\w+|\[[^\]\n]+\])*\s*(?:\+=|-=|=(?!=))')
  self.assertNotRegex(PUBLIC,r'owner\([^)]*\)\.[\w.]+\s*=(?!=)')
  self.assertNotIn('load_from_dict',PUBLIC);self.assertNotIn('_spawn',PUBLIC)
  self.assertIn('game.apply_command(player,cmd)',PUBLIC)
 def test_restored_helpers_byte_equal(self):
  baseline=functions((ROOT/'murcules_package/patch/harness_revision_v2/murcules_deadkiller_public.gd').read_text());new=functions(PUBLIC)
  for name in ['owner','snapshot','index_uid','index_card','unit','buy_minion','play_minion','stock_totals','refresh_player','acquire','advance','buy_true_triple_player']:
   with self.subTest(helper=name):self.assertEqual(new[name],baseline[name])
  tide=functions((ROOT/'rebuild_tidecaller_tests/tidecaller_lifecycle_public.gd').read_text())
  self.assertEqual(new['command'],tide['command'])
  self.assertNotIn('no_removed_identity',PUBLIC)
 def test_unique_twelve_save_labels_and_full_fields(self):
  expected=CONTRACT['expected_loads'];self.assertEqual(len(expected),12)
  self.assertEqual(len({(r['scenario'],r['label']) for r in expected}),12)
  self.assertEqual(len(CONTRACT['native_snapshot_fields']),13)
  for field in CONTRACT['native_snapshot_fields']:self.assertIn('"'+field+'":',functions(PUBLIC)['snapshot'])
  self.assertIn('snapshot()==after',PUBLIC);self.assertIn('for field in before:',PUBLIC)
  self.assertIn('execute_lifecycle(setup,amount,"deterministic replay")',PUBLIC)
 def test_predeclared_semantic_not_historical_counts(self):
  self.assertEqual(CONTRACT['semantic_counts'],[{'path':['casts'],'measure':'length','expected':28}])
  self.assertEqual(CONTRACT['expected_counts']['loads'],12)
  self.assertIsInstance(CONTRACT['expected_counts']['commands'],dict);self.assertIsInstance(CONTRACT['expected_counts']['checks'],dict)
  minimum=sum(sum(row.values()) for row in CONTRACT['required_check_counts_by_scenario'].values());self.assertEqual(minimum,CONTRACT['expected_counts']['checks']['minimum'])
  self.assertEqual(CONTRACT['acquisition_limits']['normal_case_total_acquisition_steps_at_most'],30+4*60+6*60+100)
  self.assertEqual(CONTRACT['acquisition_limits']['golden_case_total_acquisition_steps_at_most'],30+6*60+6*60+100)
 def test_paid_tier4_golden_reward_and_order(self):
  for value in ['owner().tier==4','golden.pool_count==3','owner().hand.size()==10','owner().hand[0].uid==reserve','owner().hand[1].uid==first','owner().hand[2].uid==second','play_minion(board_control) or not play_minion(source)','play_minion(setup.first)','play_minion(setup.second)','sell_acquired(uid)','body.blood_gems_received_turn=0']:self.assertIn(value,PUBLIC)
  self.assertIn('"spell_discover","tier":5',PUBLIC)
  self.assertIn('golden empty hand',CONTRACT['not_covered'])
 def test_independent_full_native_xml(self):
  raw=(ROOT/'rebuild_ashen_candidate/source_research/CardDefs.Bacon.37.0.2.256589.xml').read_bytes()
  self.assertEqual(hashlib.sha256(raw).hexdigest(),'103890e791863c743dd4b873e4cb789b711543ba839f923f677ebba6d672ff5a')
  for identity,atk,hp,amount,link,linked in [('BG36_703',3,7,9,'BACON_TRIPLE_UPGRADE_MINION_ID',132990),('BG36_703_G',6,14,18,'BACON_TRIPLED_BASE_MINION_ID',132989)]:
   entity=ET.fromstring(re.search(rb'<Entity CardID="'+identity.encode()+rb'"[^>]*>.*?</Entity>',raw,re.S).group(0));tags={t.attrib['name']:t for t in entity.findall('Tag')}
   for key,value in [('ATK',atk),('HEALTH',hp),('TECH_LEVEL',4),('TAG_SCRIPT_DATA_NUM_1',amount),('TAG_SCRIPT_DATA_NUM_2',amount),(link,linked)]:self.assertEqual(int(tags[key].attrib['value']),value)
   self.assertEqual(tags['CARDTEXT'].findtext('zhCN'),'每当你对本随从施放法术，使你手牌中最左边的随从牌获得+{0}/+{1}。')
 def test_new_overlay_agrees_without_native_credit(self):
  data=json.loads((ROOT/'rebuild_twilight_candidate/files/data/patch_3702_twilight_overlay.json').read_text())
  for row,atk,hp,amount in zip(data['cards'],[3,6],[7,14],[9,18]):
   v=row['effective_fields'];self.assertEqual((v['attack'],v['health']),(atk,hp));self.assertEqual(v['effects'],[{'type':'on_target_spell_hand_buff','target_scope':'self','scope':'leftmost','attack':amount,'health':amount}])
 def test_validator_accepts_synthetic_expected_vectors_only(self):
  for case in CONTRACT['ordered_cases']:
   for i in range(7):
    with self.subTest(case=case,index=i):validator.verify_cast(fixture(case,i),CONTRACT,i,case)
 def test_validator_rejects_extra_full_grants(self):
  for case in CONTRACT['ordered_cases']:
   row=fixture(case,2);next(b for b in row['after_owned']['hand'] if b['uid']=='first')['attack']+=CONTRACT['cast_contract']['vectors_by_case'][case][0]
   with self.assertRaises(ValueError):validator.verify_cast(row,CONTRACT,2,case)
 def test_validator_rejects_second_recipient_or_source_self_grant(self):
  case=CONTRACT['ordered_cases'][0]
  for zone,uid in [('hand','second'),('board','source')]:
   row=fixture(case,2);next(b for b in row['after_owned'][zone] if b['uid']==uid)['health']+=9
   with self.assertRaises(ValueError):validator.verify_cast(row,CONTRACT,2,case)
 def test_validator_rejects_fabricated_count_wrong_uid_and_spell_mutation(self):
  case=CONTRACT['ordered_cases'][0]
  for mutate in [lambda r:r.update(program_application_count_is_static_expectation=False),lambda r:r.update(target_uid='control'),lambda r:r['after_owned']['hand'][0].update(attack=8),lambda r:r['command'].update(index=0),lambda r:r.update(eligible_hand_uids=['second'])]:
   row=fixture(case,2);mutate(row)
   with self.assertRaises(ValueError):validator.verify_cast(row,CONTRACT,2,case)
if __name__=='__main__':unittest.main(verbosity=2)
