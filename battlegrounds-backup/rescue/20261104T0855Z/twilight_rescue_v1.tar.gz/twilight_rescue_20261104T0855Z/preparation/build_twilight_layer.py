"""New eleven-file Twilight layer, not restoration of the lost combined candidate."""
from common import *
import copy
import xml.etree.ElementTree as ET

assert not (C / 'SOURCE_DELTA_SEAL.json').exists(), 'Source already frozen; do not rewrite it.'
paths, origins, manifests = layers()
input_path = lambda name: paths.get(name, B / name)
read = lambda name: input_path(name).read_text()
def write(name, value):
    p = D / name
    p.parent.mkdir(parents=True, exist_ok=True)
    assert not p.is_symlink()
    p.write_bytes(value if isinstance(value, bytes) else value.encode())

raw = {x['id']: x for x in json.loads(read('data/catalog_raw.json'))['cards']}
compiled = {x['id']: x for x in json.loads(read('data/catalog.json'))['cards']}
egg = json.loads(read('research/lucky_egg_rebuilt/target_contracts.json'))
assert egg['pairs'][IDS[0]] == IDS[1]
adjacent, dark, damage = [read('core/' + name + '.gd') for name in ['adjacent_target_listeners', 'dark_gift_qualification', 'damage_listener_room']]
programs, facts, pins = constant(adjacent, 'PROGRAMS'), constant(dark, 'FACTS'), constant(damage, 'PINNED_PROGRAMS')
proof_fields = constant(damage, 'PROOF_FIELDS')
rows, entities, damage_proofs = [], {}, {}
xml, html = XML.read_bytes(), HTML.read_bytes()
prefix = 'research/patch_3702_twilight'
for n, identity in enumerate(IDS):
    match = re.search(rb'<Entity\b[^>]*CardID="' + identity.encode() + rb'"[^>]*>.*?</Entity>', xml, re.S)
    assert match
    body = match[0]
    native = ET.fromstring(body)
    tags = {t.attrib['name']: t.attrib.get('value') for t in native.findall('Tag')}
    values = [int(tags[k]) for k in ['ATK', 'HEALTH', 'TECH_LEVEL', 'TAG_SCRIPT_DATA_NUM_1', 'TAG_SCRIPT_DATA_NUM_2']]
    assert values == ([3, 7, 4, 9, 9] if n == 0 else [6, 14, 4, 18, 18])
    assert native.attrib == {'CardID': identity, 'ID': str(132989 + n), 'version': '2'}
    assert tags['CARDTYPE'] == '4' and tags['CARDRACE'] == '14'
    assert tags['BACON_TRIPLE_UPGRADE_MINION_ID' if n == 0 else 'BACON_TRIPLED_BASE_MINION_ID'] == str(132990 if n == 0 else 132989)
    assert (tags.get('PREMIUM') is None and tags['IS_BACON_POOL_MINION'] == '1') if n == 0 else tags['PREMIUM'] == '1'
    assert digest(body) == ['4d249f18fe2c3dc663b2b4f3fee2516e31cb6f0b10bbf5bee623392ce6b10f74', '4984faa86c50fc3da5edb1b991e0347353b768b850752abdca4a8e5d62f37f9e'][n]
    native_path = prefix + '/native/' + identity + '.xml'
    write(native_path, body)
    text = native.find("Tag[@name='CARDTEXT']/zhCN").text.format(values[3], values[4])
    entities[identity] = {'dbf_id': str(132989 + n), 'entity_version': 2, 'path': native_path, 'sha256': digest(body), 'bytes': len(body), 'byte_range': [match.start(), match.end()], 'tags': tags, 'rendered_zhCN': text}
    base = dict(copy.deepcopy(raw[identity]), **copy.deepcopy(compiled[identity]))
    old_effect = [{'type': 'on_target_spell_hand_buff', 'target_scope': 'self', 'scope': 'leftmost', 'attack': 8 if n == 0 else 16, 'health': 8 if n == 0 else 16}]
    assert base['effects'] == programs[identity] == facts[identity]['effects'] == old_effect
    assert [base['attack'], base['health']] == ([4, 6] if n == 0 else [8, 12])
    effects = copy.deepcopy(old_effect)
    effects[0].update(attack=values[3], health=values[4])
    fields = copy.deepcopy(base['fields'])
    fields.update(attack=values[0], health=values[1], text=text, updated_at='2026-11-03 Patch37.0.2.256589')
    status = copy.deepcopy(base['field_status'])
    for k, v in [('attack', values[0]), ('health', values[1])]:
        status[k].update(value=v, verification='confirmed_independent_37_0_2_native_entity', value_source=native_path)
    marker = {'revision': REV, 'client_version': '37.0.2.256589', 'native_commit': '31b034c26f24b8a66ece845ffd03c1ca397b9a02', 'native_entity_version': 2, 'native_path': native_path, 'native_sha256': digest(body)}
    effective = {'attack': values[0], 'health': values[1], 'text': text, 'effects': effects, 'coverage_text_sha256': digest(text), 'fields': fields, 'field_status': status, 'patch_3702_twilight': marker}
    assert all(base[k] == v for k, v in egg['targets'][identity].items())
    rows.append({'id': identity, 'expected_baseline': base, 'effective_fields': effective, 'lucky_egg_expected_baseline': copy.deepcopy(egg['targets'][identity])})
    current = dict(copy.deepcopy(base), **copy.deepcopy(effective))
    old_proof, new_proof = [{k: c.get(k) for k in proof_fields} for c in [base, current]]
    old_hash, new_hash = digest(canonical(old_proof)), digest(canonical(new_proof))
    assert pins[identity] == old_hash
    assert new_hash == ['b9a5ee22f1dd2a007160bea4841134062feb4c26d2b38429c2a43b776500cebd', '59b08eb057a8275ac555755b0aeb8d91cd04dc96ed8b35263bde2d5d5bb5d6eb'][n]
    damage_proofs[identity] = {'before': old_proof, 'after': new_proof, 'before_sha256': old_hash, 'after_sha256': new_hash}
    needle = '"' + identity + '": "' + old_hash + '"'
    assert damage.count(needle) == 1
    damage = damage.replace(needle, '"' + identity + '": "' + new_hash + '"')
    needle = '"' + identity + '":' + enc(old_effect)
    assert adjacent.count(needle) == 1 and dark.count(enc(old_effect)) == 1
    adjacent = adjacent.replace(needle, '"' + identity + '":' + enc(effects))
    dark = dark.replace(enc(old_effect), enc(effects))
for name, value in [('adjacent_target_listeners', adjacent), ('dark_gift_qualification', dark), ('damage_listener_room', damage)]: write('core/' + name + '.gd', value)

lucky = read('core/lucky_egg_sources.gd')
assert 'Patch3702Twilight' not in lucky and 'Patch3702Ashen.lucky_egg_expectation(id,expected)' in lucky
lucky = lucky.replace('extends RefCounted\n', 'extends RefCounted\nconst Patch3702Twilight=preload("res://core/patch_3702_twilight_sources.gd")\n', 1)
needle = '\t\tif id in Patch3702Ashen.IDS:\n'
assert lucky.count(needle) == 1
branch = '\t\tif Patch3702Twilight.accepts_id(id):\n\t\t\tvar twilight_issue: String=Patch3702Twilight.lucky_egg_target_error(card,expected)\n\t\t\tif not twilight_issue.is_empty(): return twilight_issue\n\t\t\tcontinue\n'
lucky = lucky.replace(needle, branch + needle, 1)
write('core/lucky_egg_sources.gd', lucky)
excerpt = re.search(rb'<p>Twilight Tidehunter</p>\s*<ul>.*?</ul>', html, re.S)
assert excerpt
excerpt_path = prefix + '/official_patch_twilight_excerpt.html'
write(excerpt_path, excerpt[0])
overlay_path = 'data/patch_3702_twilight_overlay.json'
dump(D / overlay_path, {'revision': REV, 'status': 'new_reconstruction_pending_fresh_acceptance', 'native_entity_version': 2, 'full_latest_patch': False, 'historical_acceptance_credit': 0, 'cards': rows, 'scope': 'Only the two Twilight bodies, texts and one spell-on-this-board-source grant to the leftmost hand minion. Keep new Ashen and Tidecaller layers, all historical provider targets and eligibility, and generic writers unchanged.'})
dependencies = ['data/catalog_raw.json', 'data/catalog.json', 'data/source_catalog/minions.json', 'data/catalog_value_overrides.json', 'data/current_scope_manifest.json', 'data/tribe_pool_requirements.json', 'data/patch_3702_membership.json', 'core/patch_3702_membership_sources.gd', 'core/game.gd', 'core/recruit_hand_effects.gd', 'core/recruit_token_sources.gd', 'core/factory_line_sources.gd', 'core/dark_gift_sources.gd', 'research/lucky_egg_rebuilt/target_contracts.json', 'research/adjacent_target_listeners_20261029/FRONTIER.json'] + list(paths)
dependencies = sorted(set(dependencies))
assert not any(x['id'] in IDS for x in json.loads(read('data/catalog_value_overrides.json'))['overrides'])
evidence_path = prefix + '/source_evidence.json'
evidence = {'schema_version': 1, 'revision': REV, 'status': 'new_layer_source_only_no_historical_credit', 'restored_base': str(B), 'prerequisites': {'ashen_manifest_sha256': ASHEN_SHA, 'tidecaller_manifest_sha256': TIDE_SHA, 'tidecaller_review_sha256': REVIEW_SHA}, 'fresh_native': {'path': str(XML), 'sha256': XML_SHA, 'url': 'https://raw.githubusercontent.com/HearthSim/hsdata/31b034c26f24b8a66ece845ffd03c1ca397b9a02/CardDefs.Bacon.xml', 'commit': '31b034c26f24b8a66ece845ffd03c1ca397b9a02', 'client_version': '37.0.2.256589'}, 'fresh_official': {'path': str(HTML), 'sha256': HTML_SHA, 'url': 'https://hearthstone.blizzard.com/en-us/news/24307311/3702-patch-notes', 'lost_full_page_hash_reused': False, 'excerpt_path': excerpt_path, 'excerpt_sha256': digest(excerpt[0])}, 'entities': entities, 'damage_proof_fields': proof_fields, 'damage_proofs': damage_proofs, 'layered_input_hashes': {p: {'path': str(input_path(p)), 'origin': origins.get(p, 'restored_base'), 'sha256': sha(input_path(p))} for p in dependencies}, 'preserved_layers': {'ashen': manifests[0]['runtime_changes'], 'tidecaller': manifests[1]['runtime_changes']}, 'closure': {'trigger': 'Real cast on this board source UID, not Rally; ordered hand minion filter skips preceding spells, one 9/9 or 18/18 grant.', 'adjacent': 'Only two numeric PROGRAMS change; all original combat holds remain, no combat acceptance.', 'damage': 'Only two exact 13-field Twilight pins change from current Tidecaller layer.', 'dark_gift': 'Only two Twilight FACTS.effects change; both current Ashen and Tidecaller rows and all policies retained.', 'lucky_egg': 'Only two existing IDs dispatch to full historical-expectation authentication and revised-source validation. Substitute attack, health, effects only. Current Ashen expectation API preserved verbatim. No provider lifecycle credit or eligibility expansion.', 'factory_line_and_dark_gift_sources': 'Historical identities, DBFs, variants and native qualification facts unchanged; no repin.', 'generic_writers': 'game.gd and recruit_hand_effects.gd unchanged, including valid-cast, identity, order and integer safeguards.', 'scope': 'No pool, Naga, excluded Aberration, six-extra, all-type, optional exclusion or Tier-7 changes.'}, 'acceptance': {'engine': False, 'historical_credit': 0, 'new_complete_identity_credit': 0, 'full_latest_patch': False, 'provider_or_combat_credit': False}}
dump(D / evidence_path, evidence)
proof_paths = [overlay_path, evidence_path, excerpt_path] + [entities[i]['path'] for i in IDS]
proofs = {p: sha(D / p) for p in proof_paths}
module = read('core/patch_3702_tidecaller_sources.gd').replace(manifests[1]['revision'], REV).replace('BG36_704', 'BG36_703').replace('patch_3702_tidecaller', 'patch_3702_twilight').replace('partial_3702_tidecaller', 'partial_3702_twilight')
module = module.replace('["expected_baseline","effective_fields"]', '["expected_baseline","effective_fields","lucky_egg_expected_baseline"]')
module += '''static func lucky_egg_target_error(card: Dictionary,historical_expected: Dictionary) -> String:
	var id: Variant=card.get("id")
	if not accepts_id(id): return "partial_3702_twilight_wrong_provider_identity"
	var rows: Dictionary=packet()
	if rows.size()!=IDS.size(): return "partial_3702_twilight_missing_or_changed_packet"
	if not same(historical_expected,rows[id].lucky_egg_expected_baseline): return "partial_3702_twilight_changed_lucky_egg_historical_target:"+str(id)
	var issue: String=source_error(card)
	if not issue.is_empty(): return issue
	var expected: Dictionary=historical_expected.duplicate(true)
	for key in ["attack","health","effects"]: expected[key]=rows[id].effective_fields[key]
	for key in expected:
		if not card.has(key) or not same(card[key],expected[key]): return "partial_3702_twilight_changed_lucky_egg_target:"+str(id)+":"+str(key)
	return ""
'''
module_path = 'core/patch_3702_twilight_sources.gd'
runtime_paths = [module_path] + proof_paths + ['core/adjacent_target_listeners.gd', 'core/dark_gift_qualification.gd', 'core/damage_listener_room.gd', 'core/lucky_egg_sources.gd']
module = re.sub(r'^const FILE_SHA256: Dictionary=.*$', lambda _: 'const FILE_SHA256: Dictionary=' + enc(proofs), module, flags=re.M)
module = re.sub(r'^const RUNTIME_PATHS: Array=.*$', lambda _: 'const RUNTIME_PATHS: Array=' + enc(runtime_paths), module, flags=re.M)
write(module_path, module)
cat = read('core/catalog.gd')
assert 'Patch3702Twilight' not in cat and 'Patch3702Ashen.raw_error(raw_card,path)' in cat
cat = cat.replace('extends RefCounted\n', 'extends RefCounted\nconst Patch3702Twilight=preload("res://core/patch_3702_twilight_sources.gd")\n', 1)
needle = '\tvar fingerprints: PackedStringArray = []\n'
assert cat.count(needle) == 1
cat = cat.replace(needle, needle + '\tvar twilight_patch_issue: String=Patch3702Twilight.proof_error()\n\tif not twilight_patch_issue.is_empty():\n\t\tload_errors.append(twilight_patch_issue);return\n\tfor path in Patch3702Twilight.RUNTIME_PATHS:\n\t\tfingerprints.append(path+":"+FileAccess.get_file_as_string("res://"+path).sha256_text())\n', 1)
needle = '\tvar tidecaller_overlay_issue: String=Patch3702Tidecaller.apply_overlay(cards)\n'
assert cat.count(needle) == 1
cat = cat.replace(needle, '\tvar twilight_overlay_issue: String=Patch3702Twilight.apply_overlay(cards)\n\tif not twilight_overlay_issue.is_empty():\n\t\tload_errors.append(twilight_overlay_issue);return\n' + needle, 1)
needle = 'func _validate_effects(effects: Variant, depth: int = 0, source: Dictionary = {}) -> String:\n'
assert cat.count(needle) == 1
cat = cat.replace(needle, needle + '\tif Patch3702Twilight.accepts_id(source.get("id")):\n\t\tvar twilight_issue: String=Patch3702Twilight.source_error(source)\n\t\tif not twilight_issue.is_empty(): return twilight_issue\n\t\tif depth!=0 or not Patch3702Twilight.same(effects,source.get("effects")): return "partial_3702_twilight_whole_program_required"\n', 1)
write('core/catalog.gd', cat)
changes = {}
for p in sorted(D.rglob('*')):
    if not p.is_file(): continue
    name = p.relative_to(D).as_posix()
    prior = input_path(name)
    changes[name] = {'change': 'modified' if prior.exists() else 'new', 'before_origin': origins.get(name, 'restored_base'), 'before_sha256': sha(prior) if prior.exists() else None, 'after_sha256': sha(p), 'size': p.stat().st_size}
assert len(changes) == 11 and sum(v['change'] == 'modified' for v in changes.values()) == 5
layers()
dump(C / 'DELTA_MANIFEST.json', {'schema_version': 1, 'revision': REV, 'status': 'author_frozen_source_pending_independent_review_and_native_validation', 'frozen': True, 'baseline': str(B), 'output': str(D), 'prerequisite_layers': [{'path': str(A / 'DELTA_MANIFEST.json'), 'sha256': ASHEN_SHA}, {'path': str(T / 'DELTA_MANIFEST.json'), 'sha256': TIDE_SHA}], 'prerequisite_tidecaller_review': {'path': str(REVIEW), 'sha256': REVIEW_SHA}, 'runtime_changes': changes, 'modified_files': 5, 'new_files': 6, 'combined_layer_path_count': len(set(paths) | set(changes)), 'no_engine_run': True, 'historical_test_credit': 0, 'native_acceptance_credit': 0, 'new_complete_identity_credit': 0, 'original_lost_source_restoration_claimed': False, 'fresh_official_page_sha256': HTML_SHA})
dump(C / 'expected_effective_twilight.json', {r['id']: dict(copy.deepcopy(r['expected_baseline']), **copy.deepcopy(r['effective_fields'])) for r in rows})
print(enc({'files': len(changes), 'combined_paths': len(set(paths) | set(changes)), 'manifest_sha256': sha(C / 'DELTA_MANIFEST.json'), 'native_or_gameplay_credit': 0}))
