"""Read-only authenticated layering helpers for the new Twilight build."""
from pathlib import Path
import hashlib, json, re

ROOT = Path('/workspace/shared/recovery_restart_20261104T0750Z')
B = ROOT / 'restored_murcules_project'
A = ROOT / 'rebuild_ashen_candidate'
T = ROOT / 'rebuild_tidecaller_candidate'
C = ROOT / 'rebuild_twilight_candidate'
D = C / 'files'
REV = 'partial-37.0.2-twilight-reconstructed-20261104-v1'
IDS = ['BG36_703', 'BG36_703_G']
ASHEN_SHA = '6aec556bacffa1d2da5f6cc671a6f14291e6b4f61629746cf92a7652f632311a'
TIDE_SHA = '34b11c174cee8dfe672792a1bbbc895304d9d589de66674654e14e80c43b1ea5'
REVIEW = ROOT / 'rebuild_review/TIDECALLER_SOURCE_FINAL_REVIEW.json'
REVIEW_SHA = '2c6748eda871eb8c71db60c92979c6629655e2aff52de85c8af6476eec18e90c'
XML = A / 'source_research/CardDefs.Bacon.37.0.2.256589.xml'
XML_SHA = '103890e791863c743dd4b873e4cb789b711543ba839f923f677ebba6d672ff5a'
HTML = A / 'source_research/official_patch_3702.html'
HTML_SHA = 'ec92b700fcce10ee8ebdec83b3b44e16e1d8c5f332a63f8ba1a1938e585a24b9'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
digest = lambda x: hashlib.sha256(x.encode() if isinstance(x, str) else x).hexdigest()
enc = lambda x: json.dumps(x, ensure_ascii=False, separators=(',', ':'))

def dump(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    assert not path.is_symlink()
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')

def constant(text, name):
    m = re.search(r'^const ' + name + r'(?:\s*:\s*(?:Dictionary|Array))?\s*=\s*', text, re.M)
    assert m, name
    tail = text[m.end():]
    if name == 'PINNED_PROGRAMS': tail = re.sub(r',\s*}', '}', tail[:tail.index('\n}') + 2])
    return json.JSONDecoder().raw_decode(tail)[0]

def canonical(x):
    if isinstance(x, dict): return 'd{' + ''.join(canonical(k) + canonical(x[k]) for k in sorted(x)) + '}'
    if isinstance(x, list): return 'a[' + ''.join(canonical(v) for v in x) + ']'
    if x is None: return 'n'
    if type(x) is bool: return 'b1' if x else 'b0'
    if type(x) is int: return 'i' + str(x) + ';'
    if type(x) is str: return 's' + str(len(x)) + ':' + x
    raise AssertionError('Invalid canonical type')

def layers():
    assert sha(REVIEW) == REVIEW_SHA
    review = json.loads(REVIEW.read_text())
    assert review['status'] == 'PASS_RECONSTRUCTED_TIDECALLER_STATIC_SOURCE_ONLY' and not review['blocking_source_findings']
    assert sha(XML) == XML_SHA and sha(HTML) == HTML_SHA
    paths, origins, manifests = {}, {}, []
    for layer, expected, origin in [(A, ASHEN_SHA, 'ashen_delta'), (T, TIDE_SHA, 'tidecaller_delta')]:
        assert sha(layer / 'DELTA_MANIFEST.json') == expected
        manifest = json.loads((layer / 'DELTA_MANIFEST.json').read_text())
        assert manifest['baseline'] == str(B) and manifest['output'] == str(layer / 'files')
        actual_set = {p.relative_to(layer / 'files').as_posix() for p in (layer / 'files').rglob('*') if p.is_file()}
        assert actual_set == set(manifest['runtime_changes'])
        for name, row in manifest['runtime_changes'].items():
            rel = Path(name)
            assert not rel.is_absolute() and '..' not in rel.parts and rel.as_posix() == name
            prior = paths.get(name, B / name)
            if row['before_sha256'] is None: assert not prior.exists()
            else: assert sha(prior) == row['before_sha256'], name
            current = layer / 'files' / name
            assert current.is_file() and not current.is_symlink()
            assert sha(current) == row['after_sha256'] and current.stat().st_size == row['size']
            paths[name], origins[name] = current, origin
        manifests.append(manifest)
    return paths, origins, manifests
