# Twilight rescue after second workspace loss

Status: transcribed recovery preparation, not surviving original candidate bytes. `/workspace/shared` and the eleven-file Twilight layer were confirmed absent by a read-only check at 2026-11-04 08:56 UTC. `/tmp` exists and is writable. No engine, credentials, import, runtime copy or source rebuild was performed.

`preparation/common.py` and `preparation/build_twilight_layer.py` are complete transcriptions of this worker's earlier tool-visible source. Only Python AST syntax parsing has been performed on these rescue copies. Their newly calculated file hashes are rescue-artifact hashes, not independently recovered original hashes.

The builder contains the complete overlay/evidence/manifest generation and the Lucky Egg adapter implementation. It derives the remaining source helper code from the authenticated new Tidecaller module, preserving its finite integral bool-safe equality, complete merged-row authentication, atomic two-row writes, source identity/effective-field validation, proof hashes and normalization. `twilight_module_reference.gd.in` separately preserves the helper's structure for review, with non-executable placeholders for generated evidence hashes and runtime paths.

## Exact former source identities

- New Twilight eleven-file `DELTA_MANIFEST.json`: `f6d6345d09c1bf99aa88b105aa8ab8c7dccc100235fba884a99f2b7d212ab258`.
- New Twilight `SOURCE_DELTA_SEAL.json`: `48999873bc12c320848a2e715d0ed5c0d56cecf9cb22c220880fe61fcb26aa0d`.
- Independent review `rebuild_review/twilight/TWILIGHT_SOURCE_FINAL_REVIEW.json`: `20fb8c7b82587c94fa5e96d323d65d666571c646bb62ccc5030ca5051327b514`.
- Historical author checks: 442 static/Python-reference checks; historical independent checks: 443 read-only source/byte checks. These are conversation history, not current reproduced evidence or native/gameplay credit.

The original full manifests and current Twilight file hashes were not printed in this worker's context. They are not recreated here from guesses. If an authenticated source-map or checkpoint recovers their complete hashes, compare against those. Do not assign the known historical manifest hash to newly different bytes.

## Expected restored inputs

The scripts deliberately retain their original absolute paths and expected SHA values. They must not be run while dependencies are missing. Restore and authenticate the following first:

1. `/workspace/shared/recovery_restart_20261104T0750Z/restored_murcules_project`.
2. `rebuild_ashen_candidate/DELTA_MANIFEST.json` SHA `6aec556bacffa1d2da5f6cc671a6f14291e6b4f61629746cf92a7652f632311a`, and every declared `files/` payload/preimage.
3. `rebuild_tidecaller_candidate/DELTA_MANIFEST.json` SHA `34b11c174cee8dfe672792a1bbbc895304d9d589de66674654e14e80c43b1ea5`, and every declared payload/preimage.
4. `rebuild_review/TIDECALLER_SOURCE_FINAL_REVIEW.json` SHA `2c6748eda871eb8c71db60c92979c6629655e2aff52de85c8af6476eec18e90c`.
5. `rebuild_ashen_candidate/source_research/CardDefs.Bacon.37.0.2.256589.xml` SHA `103890e791863c743dd4b873e4cb789b711543ba839f923f677ebba6d672ff5a`.
6. `rebuild_ashen_candidate/source_research/official_patch_3702.html` SHA `ec92b700fcce10ee8ebdec83b3b44e16e1d8c5f332a63f8ba1a1938e585a24b9`.

The old first-attempt official page SHA ending `ba9db83` is not the new full-page input and must not replace it.

## Current API and precise scope

- New revision: `partial-37.0.2-twilight-reconstructed-20261104-v1`.
- Module: `core/patch_3702_twilight_sources.gd`, Catalog constant `Patch3702Twilight`, marker `patch_3702_twilight`.
- Normal BG36_703/DBF132989: 3/7, exactly one +9/+9 grant.
- Golden BG36_703_G/DBF132990: 6/14, exactly one +18/+18 grant.
- Real spell target must be this board source UID. Ordered hand-minion selection skips spells. Not Rally, not a Murloc-only hand recipient, not repeated golden grants.
- The **new** Ashen Lucky Egg API is `Patch3702Ashen.lucky_egg_expectation(id,expected)` under `if id in Patch3702Ashen.IDS`. The builder preserves that entire branch and adds Twilight's exact two-ID branch immediately before it. Do not reintroduce the lost old Ashen `lucky_egg_target_error` call.
- New Ashen Catalog has `Patch3702Ashen.raw_error(raw_card,path)` before merging. The builder asserts it exists and keeps it unchanged. It adds Twilight hooks into the **current Tidecaller Catalog**, never overwrites it with a historical Catalog.
- Twilight itself authenticates complete merged raw-plus-compiled rows, not separately overwritten raw shadow fields. This was explicitly noted in independent review. Do not mislabel it a per-input raw-record guard.
- Lucky Egg Twilight helper validates the complete original historical target expectation and current source, then substitutes only attack, health and effects. No eligibility expansion, target-manifest rewrite or other-pair change.
- Generic `game.gd` and `recruit_hand_effects.gd`, all combat/provider holds, Naga/excluded Aberration membership, six extras and prior partial systems remain unchanged.

## Eleven source payloads

Five composed modifications: `core/catalog.gd`, `core/adjacent_target_listeners.gd`, `core/damage_listener_room.gd`, `core/dark_gift_qualification.gd`, `core/lucky_egg_sources.gd`.

Six additions: `core/patch_3702_twilight_sources.gd`, `data/patch_3702_twilight_overlay.json`, `research/patch_3702_twilight/source_evidence.json`, `research/patch_3702_twilight/official_patch_twilight_excerpt.html`, and native `BG36_703.xml`/`BG36_703_G.xml` under that research directory's `native/`.

Ashen plus Tidecaller plus Twilight cover 24 distinct paths. This is not the old first-attempt 17-file combined candidate.

Known native entity hashes remain `4d249f18fe2c3dc663b2b4f3fee2516e31cb6f0b10bbf5bee623392ce6b10f74` and `4984faa86c50fc3da5edb1b991e0347353b768b850752abdca4a8e5d62f37f9e`. Expected damage program hashes, not file hashes, are `b9a5ee22f1dd2a007160bea4841134062feb4c26d2b38429c2a43b776500cebd` and `59b08eb057a8275ac555755b0aeb8d91cd04dc96ed8b35263bde2d5d5bb5d6eb`.

The previously observed exact Twilight excerpt SHA was `accc8b52e03182a133a44440a0cb166f3c747d7b9c3df1b4d4285034866b6d82`. The transcribed new builder extracts it from authenticated fresh HTML instead of trusting this note. Any mismatch must be investigated, not overwritten to fit a prior hash.

## Recovery execution boundary

This package has not recreated `files/`, a manifest, a source seal, a static pass or a native pass. An authorized later process may run the builder only against authenticated complete inputs and into a fresh candidate destination. Preserve the rescue package first. Compare generated manifest against the historical expected hash if all original paths/content are restored. A mismatch is a new candidate requiring renewed review, not proof of restoration. Rebuild and rerun current checks before sealing; no native acceptance may be inferred from source similarity.
