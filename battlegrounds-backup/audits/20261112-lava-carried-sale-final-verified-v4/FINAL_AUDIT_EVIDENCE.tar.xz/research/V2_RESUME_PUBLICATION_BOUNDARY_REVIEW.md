# V2 续纯测与最终封包边界独立审查

结论：当前冻结工具未发现阻止所选有限恢复流程的确定静态问题。只续13纯合同、原Game重验而非重跑、旧失败保留、成功需实际完整证据的边界成立。本审查未运行Godot、runner、audit、构包或下载，不推断正在运行的30383已通过。

## 实际冻结核验
- run_pure_resume_v2.py SHA 594ad384e974651cf154d7e901fefd9bebb0537286e79d558cf1bd6590d828de，匹配。
- PUBLICATION_TOOLS_FROZEN_V2.json SHA 6db02997a8cd9dca587f8f40b924a9436c0c382fb535cc5bc4b53dec47b4e3d2，匹配；所列8文件逐字节数/SHA均匹配。
- RECOVERY_TOOLS_FROZEN_V2.json 所列文件实际匹配；ORIGINAL_ATTEMPT_PINNED.json 的62旧文件逐字节数/SHA核验均匹配。

## 只续纯测
recovery_common 的 PURE_TESTS 固定为原冻结 TESTS[1:]；执行循环仅遍历此列表。run_pure 先验证完整(label/source/budget/count)白名单，再要求非Game content_contract或3个指定旧合同，budget180。虽然第二表达式使用and/or优先级，前置完整元组白名单封住了任意source替换，没有full_matrix入口。原 Game 路径只传给 original_revalidate，以原log/scene/进程/wrapper/source SHA及原FAILED状态+13omitted进行重验。

共享锁、新 RESUME 必须不存在、写文件xb、HOME/XDG全外置；两个实际源码树初始/最终全量scan，每纯测另有原run_test预检。每步重核工具及62旧pin；finally再次检查旧Game原证据和prepared wrapper，不把旧输出覆盖成成功。provenance 调用明确要求985a11e已fresh核验的失败保存包及4文件实际字节一致，在任何纯测启动前写PREPARED时即过该门槛。

全部13实际result exit0、日志validator通过并返回无Game scenario之后，才接受3334纯检查；组合原Game155为3489。异常保留新失败summary，不产生成功combined。独立audit另拒续跑目录多余result，复核原Game与13真实进程、时序、source maps和完整最终声明。

## 封包与fresh发布
combined_publication_v2.verify_combined 不是读一个成功字符串：必须有原Game实际重验、13逐条classify/validator、原VALIDATED结果逐字相等、成功独立audit且errors空、两次attempt/一个Game/续跑零Game的provenance相等，并重新实际scan两个完整源树。

封包复验固定early23字节；原source包16个非SUMS文件与early一致。新目录写入early22原非SUMS字节+7个新结果/归档/说明+新SUMS，要求最终30；再次验证early22 SHA不变。原MANIFEST和delta不改，历史未验收状态不会被重写。归档每成员SHA包括旧FAILED/原Game证据、续纯测、纠错工具、985a保存凭据及launch path纠正；独立审查报告和重新hash摘要纳入新证据。输出xb与新目录拒覆盖。

verify_combined_publication_v2 先重验实际组合证据，再对指定40位固定commit重新下载30文件，校验bytes/SHA/Git blob SHA、SUMS完整覆盖、early22不变及所有tar.xz逐成员重hash，并检查实际scene/final一致。不是仅核本地包即宣称远端通过。

## 保持的限制
当前仅静态审查与小文件SHA核验；没有执行最终包工具，不能宣称30文件已发布或13pure已完成。所有成功依赖后续真实回执，不以synthetic7或pre-freeze42替代。权限仍只是有限两cast/三战/跨轮sale样本；未推默认池、全游戏、buffed真rebuy或任意steps。冻结工具若需改动应另立版本，不能覆盖本次已审文件。

## 后续协调补充
父线程随后指出最终publication需新增共享flock，且db9a历史措辞应更精确。当前V2封包/freshverify本身未取得共享锁，因此上述静态流程核验不等于认可并行构包；不得在续纯测运行时执行。生产者将另冻V3，保留V2。本报告的resume边界结论不受影响；最终publication许可结论等待V3锁与文案差分复核，本次未争用任何执行锁。
