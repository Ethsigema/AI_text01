from pathlib import Path
import json,hashlib,subprocess,tarfile,datetime
R=Path(__file__).resolve().parent
pub=json.loads((R/'PUBLICATION.json').read_text()); meta=json.loads((R/'UPLOAD_METADATA.json').read_text()); D=R/'fresh_remote_985a11e'; D.mkdir()
assert pub['commit']=='985a11e784e1e80ff0390c4707c2043d430543f4'
assert len(meta['records'])==4
h=lambda b:hashlib.sha256(b).hexdigest()
for r in meta['records']:
 p=D/r['name']; assert p.parent==D
 url=f"https://raw.githubusercontent.com/Ethsigema/AI_text01/{pub['commit']}/{pub['folder']}/{r['name']}"
 subprocess.run(['curl','--fail','--location','--silent','--show-error','--max-time','120',url,'-o',str(p)],check=True)
 b=p.read_bytes(); assert len(b)==r['bytes'] and h(b)==r['sha256'] and hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==r['git_sha']
assert {p.name for p in D.iterdir()}=={r['name'] for r in meta['records']}
sums={n:s for s,n in (l.split('  ',1) for l in (D/'SHA256SUMS').read_text().splitlines())};assert set(sums)=={r['name'] for r in meta['records']} - {'SHA256SUMS'}
for n,s in sums.items():assert h((D/n).read_bytes())==s
m=json.loads((D/'MEMBER_MANIFEST.json').read_text());assert m['files']==64
with tarfile.open(D/'VALIDATOR_FAILURE_EVIDENCE.tar.xz') as t:
 ms=t.getmembers();assert len(ms)==len({x.name for x in ms})==64 and {x.name for x in ms}==set(m['members'])
 for x in ms:
  assert x.isfile() and not x.name.startswith('/') and '..' not in Path(x.name).parts
  b=t.extractfile(x).read();assert {'bytes':len(b),'sha256':h(b)}==m['members'][x.name]
result={'status':'PASS_FRESH_PUBLICATION_AND_ALL_MEMBERS','commit':pub['commit'],'source_commit':pub['source_commit'],'files':4,'bytes':sum(r['bytes'] for r in meta['records']),'archive_members':64,'every_file_git_sha_size_sha256_verified':True,'sha256sums_verified':True,'every_archive_member_rehashed':True,'whole_suite_acceptance':False,'verified_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'download_directory':str(D),'sha256sums_sha256':h((D/'SHA256SUMS').read_bytes()),'records':meta['records']}
with (R/'PUBLICATION_VERIFIED.json').open('x') as f:json.dump(result,f,indent=2,sort_keys=True);f.write('\n')
print(json.dumps(result))
