from pathlib import Path
import json,hashlib,subprocess,tarfile,argparse,datetime
R=Path(__file__).resolve().parents[2]
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--execute',action='store_true',required=True);ap.add_argument('--publication',type=Path,required=True);a=ap.parse_args()
 pub=json.loads(a.publication.read_text());meta=json.loads((R/'FINAL_COMBINED_V4_AUDIT_UPLOAD_METADATA.json').read_text());folder=pub.get('remote_folder',pub.get('folder'));assert folder==meta['folder'];commit=pub['commit'];assert len(commit)==40 and all(c in '0123456789abcdef' for c in commit)
 d=R/('final_combined_v4_audit_remote_'+commit);d.mkdir();h=lambda b:hashlib.sha256(b).hexdigest()
 for r in meta['records']:
  n=r['name'];assert Path(n).name==n
  subprocess.run(['curl','--fail','--silent','--show-error','--location','--max-time','120',f'https://raw.githubusercontent.com/Ethsigema/AI_text01/{commit}/{folder}/{n}','-o',str(d/n)],check=True)
  b=(d/n).read_bytes();assert len(b)==r['bytes'] and h(b)==r['sha256'] and hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==r['git_sha']
 sums={n:s for s,n in [line.split('  ',1) for line in (d/'SHA256SUMS').read_text().splitlines()]};assert set(sums)=={r['name'] for r in meta['records']}-{'SHA256SUMS'}
 for n,s in sums.items():assert h((d/n).read_bytes())==s
 m=json.loads((d/'MEMBER_MANIFEST.json').read_text());assert h((d/'FINAL_AUDIT_EVIDENCE.tar.xz').read_bytes())==m['archive_sha256']
 seen={}
 with tarfile.open(d/'FINAL_AUDIT_EVIDENCE.tar.xz') as t:
  for x in t:
   assert x.isfile() and not x.name.startswith('/') and '..' not in Path(x.name).parts and x.name not in seen
   b=t.extractfile(x).read();seen[x.name]={'bytes':len(b),'sha256':h(b)}
   if x.name in ['SOURCE_PUBLICATION.json','FINAL_COMBINED_V3_PUBLICATION.json','FINAL_COMBINED_V4_PUBLICATION_VERIFIED.json']:assert b==(R/x.name).read_bytes()
 assert seen==m['members']
 result={'status':'PASS_FRESH_AUDIT_ALL_FILES_MEMBERS_AND_REFERENCES','commit':commit,'files':len(meta['records']),'bytes':meta['bytes'],'archive_members':len(seen),'source_commit':meta['source_commit'],'final_commit':meta['final_commit'],'verified_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'game_run':False}
 with (R/'FINAL_COMBINED_V4_AUDIT_PUBLICATION_VERIFIED.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
 print(json.dumps(result))
if __name__=='__main__':main()
