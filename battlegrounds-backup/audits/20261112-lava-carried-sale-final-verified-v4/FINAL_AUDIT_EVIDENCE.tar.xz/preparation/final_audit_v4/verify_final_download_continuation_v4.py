"""Fresh-download fixed final30 and verify all members. No Game, Git or upload."""
import argparse,subprocess,re
import sys
sys.path.insert(0,str(__import__("pathlib").Path(__file__).resolve().parents[1]/"recovery_v2"))
from publication_common_v3 import *
import recovery_common as rc
import validator_v2 as v
import audit_core_v2 as ac
def verify_combined_evidence_no_source_rescan():
 rc.verify_tools();rc.verify_pins();m,expected,_=rc.package()
 bindings={'source_commit':SOURCE,'source_map_sha256':m['source_map_sha256'],'aggregate_sha256':m['aggregate_sha256']}
 final=read(rc.REMOTE/rc.FINAL_NAME);audit=read(rc.REMOTE/rc.AUDIT_NAME)
 require(final['status']==rc.FINAL_STATUS,'not completed combined success')
 require(audit['status']=='PASS_RECOVERED_POST_ATTEMPT_SOURCE_AND_EVIDENCE_AUDIT','missing independent post audit')
 for obj in [final,audit]:
  for k,value in bindings.items():require(obj[k]==value,'binding '+k)
 require(final['execution_attempts']==2 and final['full_game_processes']==1 and final['full_game_processes_in_resume']==0,'wrong execution accounting')
 game,original=rc.original_revalidate(expected,bindings,require_saved=True)
 prep=rc.check_preparation(rc.RESUME,bindings,rc.HERE/'run_pure_resume_v2.py')
 classified,errors=ac.classify_attempt(rc.RESUME,expected,bindings,rc.RESTORED,prep['entries'],tests=rc.PURE_TESTS)
 require(not errors and len(classified)==13 and all(x['classification']=='executed_validated' for x in classified.values()),'pure attempt incomplete')
 tests={rc.GAME:game}
 for label,*_ in rc.PURE_TESTS:tests[label]=read(rc.RESUME/(label+'_VALIDATED.json'))
 require(final['tests']==tests,'combined test receipt mismatch')
 require(final['provenance']==audit['provenance']==rc.provenance(),'provenance mismatch')
 require(audit['runner_suite_accepted'] is True and audit['errors']==[],'audit not accepted')
 require(final['evidence_directories']=={x[0]:str(rc.ORIGINAL if x[0]==rc.GAME else rc.RESUME) for x in v.TESTS},'evidence paths')
 require(final['total_passed_checks']==3489 and final['pure_passed_checks']==3334 and final['original_game_revalidated_checks']==155,'combined counts')
 require(final['full_game_acceptance'] is False and final['default_pool_promoted'] is False and final['old_full_matrices_repeated'] is False,'overclaim')
 summary=read(rc.RESUME/'ATTEMPT_SUMMARY.json')
 require(summary['status']=='THIRTEEN_PURE_VALIDATED_SOURCE_INTEGRITY_PASS' and summary['error'] is None and summary['provenance']==rc.provenance(),'resume incomplete')
 require(sum(x['passed_checks'] for x in tests.values())==3489,'wrong total')
 require(set(audit['tests'])==set(tests) and all(x['classification']=='executed_validated' for x in audit['tests'].values()),'audit classification')
 trees=audit['trees']
 require(all(x['matches'] for x in trees.values()),'actual source changed')
 return final,audit,game['verified_scenario_fields'],trees


def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--execute',action='store_true',required=True);ap.add_argument('--publication',type=Path,required=True);a=ap.parse_args()
 final,audit,scenario,trees=verify_combined_evidence_no_source_rescan();pub=read(a.publication)
 require(re.fullmatch('[0-9a-f]{40}',pub['commit']) and pub['commit'] not in [SOURCE,EARLY] and pub['source_commit']==SOURCE,'invalid final commit')
 require(pub.get('folder',pub.get('remote_folder'))==FOLDER,'folder mismatch')
 records=read(ROOT/'FINAL_COMBINED_V3_PUBLICATION_FILES.json');require(len(records)==30,'expected30')
 out=ROOT/('final_combined_v3_remote_'+pub['commit']);require(out.is_dir(),"missing actual first-download directory")
 require({p.name for p in out.iterdir()}=={r["name"] for r in records},"exact downloaded path set")
 for row in records:
  n=row['name'];require(safe(n) and '/' not in n,'unsafe name');url=f'https://raw.githubusercontent.com/Ethsigema/AI_text01/{pub["commit"]}/{FOLDER}/{n}'
  b=(out/n).read_bytes();require(len(b)==row['bytes'] and sha(b)==row['sha256'] and hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==row['git_sha'],'reread fixed downloaded bytes '+n)

 sums={}
 for line in (out/'SHA256SUMS.txt').read_text().splitlines():
  digest,n=line.split('  ',1);require(n not in sums and safe(n) and '/' not in n and sha((out/n).read_bytes())==digest,'bad SUMS');sums[n]=digest
 require(set(sums)=={r['name'] for r in records}-{'SHA256SUMS.txt'},'SUMS coverage')
 early=read(ROOT/'EARLY_PUBLICATION_VERIFIED.json');unchanged={}
 for row in early['records']:
  if row['name']!='SHA256SUMS.txt':require(sha((out/row['name']).read_bytes())==row['sha256'],'early changed');unchanged[row['name']]=row['sha256']
 require(len(unchanged)==22,'early22')
 manifest=read(out/'MANIFEST.json');archives={}
 for p in out.glob('*.tar.xz'):
  meta={'archive_sha256':manifest['archive_sha256'],'members':manifest['changed_files']} if p.name==manifest.get('archive') else read(out/(p.name.removesuffix('.tar.xz')+'_MANIFEST.json'))
  if p.name=='FIX_EVIDENCE.tar.xz':
   require('members' not in meta and len(meta)==85,'known FIX direct-map schema');meta={'archive_sha256':next(r['sha256'] for r in records if r['name']==p.name),'members':meta}
  require(meta['archive_sha256']==next(r['sha256'] for r in records if r['name']==p.name),'manifest versus pinned archive hash')
  archives[p.name]=verify_archive(p.read_bytes(),meta)
 require({'FIX_EVIDENCE.tar.xz','TOOLS_EVIDENCE.tar.xz','GAMEPLAY_EVIDENCE.tar.xz'}<=set(archives),'archive coverage')
 require(read(out/'GAMEPLAY_INDEPENDENT_VERIFICATION.json')==final and read(out/'GAMEPLAY_MATRIX_RESULT.json')==scenario,'combined receipt changed')
 with tarfile.open(out/'GAMEPLAY_EVIDENCE.tar.xz','r:xz') as t:
  names=set(t.getnames())
  required=['remote_snapshot_32a8b33/independent_tests/ATTEMPT_SUMMARY.json','remote_snapshot_32a8b33/RECOVERED_GAME_VERIFICATION_V2.json','remote_snapshot_32a8b33/RECOVERED_POST_ATTEMPT_AUDIT_V2.json','evidence/LAUNCH_PREFLIGHT_PATH_CORRECTION.json','research/ACTUAL_GAME_VALIDATOR_FAILURE_REVIEW.md']
  require(set(required)<=names,'combined provenance missing')
  require(json.loads(t.extractfile(required[1]).read())==final,'archived final mismatch')
 require(archives=={'FIX_EVIDENCE.tar.xz':85,'TOOLS_EVIDENCE.tar.xz':93,'GAMEPLAY_EVIDENCE.tar.xz':len(read(out/'GAMEPLAY_EVIDENCE_MANIFEST.json')['members']),manifest['archive']:157},'archive counts')
 report={'status':'PASS_COMBINED_V4_CONTINUATION_FIXED_DOWNLOADED_BYTES_ALL_MEMBERS','commit':pub['commit'],'source_commit':SOURCE,'remote_folder':FOLDER,'files':30,'records':records,'archive_member_counts':archives,'early22_immutable':unchanged,'game_rerun':False,'original_game_revalidated':True,'resumed_pure_processes':13,'game_started_by_verifier':False,'full_game_acceptance':False,'outcome':'success','original_download_attempt_exit':1,'continuation_read_only':True,'redownloaded':False,'source_rescanned':False,'original_game_revalidated_checks':155,'pure_passed_checks':3334,'total_passed_checks':3489}
 put(ROOT/'FINAL_COMBINED_V4_PUBLICATION_VERIFIED.json',enc(report))
 print(json.dumps({'status':report['status'],'files':30,'archives':archives,'total':3489}))
if __name__=='__main__':main()
