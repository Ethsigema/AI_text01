"""Combined publication primitives. No import-time writes, Godot, Git or network."""
from pathlib import Path, PurePosixPath
import hashlib,json,tarfile,io,gzip
ROOT=Path(__file__).resolve().parents[2]
SOURCE='32a8b33abe2bfb980c5ec890e7950f6b5a9f1346'
EARLY='ab9761e064910020211629dc0d2a6032cce8eea4'
FOLDER='battlegrounds-backup/pending/20261112-lava-carried-sale'
def require(ok,msg):
 if not ok:raise ValueError(msg)
def sha(b):return hashlib.sha256(b).hexdigest()
def enc(x):return (json.dumps(x,sort_keys=True,indent=2)+'\n').encode()
def read(p):return json.loads(Path(p).read_bytes())
def put(p,b):
 with Path(p).open('xb') as f:f.write(b)
def safe(n):return isinstance(n,str) and bool(n) and not PurePosixPath(n).is_absolute() and '..' not in PurePosixPath(n).parts and '\\' not in n
def rows(p):
 out=[]
 for f in sorted(p.iterdir()):
  require(f.is_file() and not f.is_symlink(),'non-regular package member')
  b=f.read_bytes();out.append(dict(name=f.name,bytes=len(b),sha256=sha(b),git_sha=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()))
 return out
def archive(files):
 stream=io.BytesIO()
 with tarfile.open(fileobj=stream,mode='w:xz') as t:
  for n,b in sorted(files.items()):
   require(safe(n),'unsafe archive member');m=tarfile.TarInfo(n);m.size=len(b);m.mode=0o644;t.addfile(m,io.BytesIO(b))
 data=stream.getvalue();meta={'archive_sha256':sha(data),'members':{n:{'bytes':len(b),'sha256':sha(b)} for n,b in files.items()}};verify_archive(data,meta);return data,meta
def verify_archive(data,meta):
 require(sha(data)==meta['archive_sha256'],'archive hash');seen={}
 with tarfile.open(fileobj=io.BytesIO(data),mode='r:xz') as t:
  for m in t:
   require(m.isfile() and safe(m.name) and m.name not in seen,'invalid archive member');b=t.extractfile(m).read();seen[m.name]={'bytes':len(b),'sha256':sha(b)}
 require(seen==meta['members'],'archive member mismatch');return len(seen)
def check_rows(path,records):
 require(len(records)==len({r['name'] for r in records}),'duplicate records')
 for r in records:
  require(safe(r['name']) and '/' not in r['name'],'unsafe name');b=(path/r['name']).read_bytes();require(len(b)==r['bytes'] and sha(b)==r['sha256'],'bytes mismatch '+r['name'])
 return True
