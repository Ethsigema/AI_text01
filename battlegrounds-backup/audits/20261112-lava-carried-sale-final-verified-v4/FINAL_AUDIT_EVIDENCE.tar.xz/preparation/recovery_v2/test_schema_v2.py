"""Detached synthetic validator examples only. Never Game or live identity evidence."""
from pathlib import Path
from copy import deepcopy
import json,tempfile
import validator_v2 as r

def rejected(fn,label):
 try:fn()
 except (ValueError,AssertionError,KeyError,TypeError,FileNotFoundError,StopIteration):return label
 raise AssertionError('Accepted synthetic negative '+label)

def fixture():
 diagnostic={'native_factory_preview':True,'actual_token_issuance':False,'uid_allocated':False,'zone_inserted':False,'shape_error':'','key_types':[{'key':k,'key_type':v[0],'value_type':v[1]} for k,v in r.NATIVE_PREVIEW_TOP_TYPES.items()],'base_key_types':[{'key':k,'key_type':v[0],'value_type':v[1]} for k,v in r.NATIVE_PREVIEW_BASE_TYPES.items()]}
 passes=['PASS '+key for key,n in r.CARRIED_SALE_FULL_MARKERS.items() for _ in range(n)]+['PASS public_darkcrest_play_u30','PASS synthetic_dynamic_funding_observation']
 ordered=['PASS '+key for key in r.carried_sale_ordered_markers()];passes=[x for x in passes if x not in ordered]+ordered;n=len(passes)
 unit=lambda uid,card,atk=2:{'uid':uid,'card_id':card,'kind':'minion','golden':False,'attack':atk,'health':5,'max_health':5}
 sale={'lava_uid':'u20','mini_uid':'u10','index':0,'retirement':{'owner':0,'round':3,'sequence':30,'mini_buffed':True},'departed_stats':{'attack':6,'health':5,'kept':0},'gold_before':5,'gold_after':6,'sold_before':0,'sold_after':1,'stock_before':14,'stock_after':15,'uid_before':100,'uid_after':100,'rng_before':-1234,'rng_after':-1234,'native_preview_attack':2,'native_preview_health':5,'preview_not_actual_rebuy':True,'owner_bound_history_gate_observed':True,'actual_shop_buy_attempted':False}
 row={'scope':r.CARRIED_SALE_SCOPE,'seed':20261120,'checks':n-1,'sale_clock':{'last_cast_sequence':20,'reset_sequence':30,'current_sequence':30,'first_recruit_sequence':30,'reset_equals_current':True,'first_after_reset':True},'sale':sale,'casts':[{'round':i+1,'source_uid':'u10','token_uid':['u40','u60'][i],'target_uid':'u20','attack_before':2+2*i,'attack_after':4+2*i,'health':5,'kept':1} for i in range(2)],'pre_sale_combats':[{'round':i+1,'target_uid':'u20','combat_start':unit('u20','BG23_009',4+2*i),'recruit_attack':4+2*i,'recruit_health':5,'recruit_kept':0} for i in range(2)],'post_sale_combat_start':{'event':'combat_start','sequence':0,'seed':-123,'rules':'sandbox-1','sort_formation_contract':'actual_combat_start_before_start_effects_v1','round_up_plain_contract':'','left':[unit('u10','BG23_000'),unit('u30','BG31_920')],'right':[unit('u95','BG23_000')],'left_hand_count':1,'right_hand_count':0,'left_hand_summon_locks':[],'right_hand_summon_locks':[]},'darkcrest_uid':'u30','darkcrest_final_tier':4,'mini_uid':'u10','lava_uid':'u20','preserved_token_uid':'u80','replacement_token_uid':'u120','unused_expiry':{'used':False,'expired':True,'spells_before':12,'spells_after':12},'native_preview_diagnostic':diagnostic,'acquisitions':[{'id':'BG23_000','uid':'u10','rolls':80,'source_owned':False},{'id':'BG23_009','uid':'u20','rolls':100,'source_owned':False}],'coin_pre_source_fixture':True,'entirely_natural_game':False,'actual_lava_rebuy_tested':False,'old_full_matrix_repeated':False}
 log='DARKCREST_LAVA_CARRIED_SALE_MATRIX_LOAD_BEGIN\nMINI_NATIVE_PREVIEW_KEY_TYPES '+json.dumps(diagnostic)+'\n'+'\n'.join(passes)+'\nDARKCREST_LAVA_CARRIED_SALE_REAL_MATRIX_PASS cases=1 casts=2 combats=3 checks='+str(n)+'\n'
 return row,log,n

def main():
 checks=[];ready=r.NEW_VALIDATORS_READY;count=r.NEW_TEST_METADATA['pure_checks'];r.NEW_VALIDATORS_READY=True;r.NEW_TEST_METADATA['pure_checks']=42
 row,log,n=fixture()
 with tempfile.TemporaryDirectory(prefix='carried_schema_synthetic_',dir=Path(__file__).parent) as tmp:
  root=Path(tmp);path=root/r.NEW_TEST_METADATA['scenario_file']
  def full(value,text=log):path.write_text(json.dumps(value));return r.validate('lava_carried_sale_real_matrix',text,None,root)
  assert full(row)==(n,row);checks.append('synthetic_exact_V4_two_cast_three_combat_equality_sample_NOT_GAME')
  mutations=[(['checks'],n,'pre_file_count'),(['checks'],True,'strict_integer'),(['scope'],'all positive buff histories proven','no_all_counts_claim'),(['seed'],1,'seed'),(['darkcrest_final_tier'],2,'acquisition_level4'),(['coin_pre_source_fixture'],False,'fixture_disclosure'),(['entirely_natural_game'],True,'natural_claim'),(['actual_lava_rebuy_tested'],True,'no_actual_rebuy'),(['old_full_matrix_repeated'],True,'no_old_full'),(['sale_clock','last_cast_sequence'],30,'lastcast_strictly_before_reset'),(['sale_clock','reset_sequence'],29,'inclusive_equal_reset_sample'),(['sale_clock','current_sequence'],31,'no_extra_command_advance'),(['sale_clock','first_recruit_sequence'],29,'first_recruit_equal_current'),(['sale_clock','current_sequence'],True,'clock_strict_integer'),(['sale_clock','reset_equals_current'],False,'equality_explicit'),(['sale_clock','first_after_reset'],False,'first_after_reset_explicit'),(['sale','retirement','sequence'],31,'retirement_at_same_clock'),(['sale','retirement','round'],2,'sale_round3'),(['sale','retirement','owner'],1,'owner_bound'),(['sale','retirement','mini_buffed'],False,'buffed_history'),(['sale','departed_stats','attack'],4,'two_buff_sample'),(['sale','departed_stats','kept'],1,'kept0_carried_sale'),(['sale','departed_stats','health'],6,'health5'),(['sale','lava_uid'],'u10','sold_original'),(['sale','mini_uid'],'u30','live_original_mini'),(['sale','index'],1,'position0'),(['sale','gold_after'],5,'sale_gold'),(['sale','stock_after'],14,'stock_return'),(['sale','sold_after'],0,'sold_count'),(['sale','uid_after'],101,'no_uid_alloc'),(['sale','rng_after'],5,'no_rng'),(['sale','native_preview_attack'],6,'no_buff_pool_pollution'),(['sale','preview_not_actual_rebuy'],False,'preview_not_actual'),(['sale','owner_bound_history_gate_observed'],False,'history_gate_observed'),(['sale','actual_shop_buy_attempted'],True,'shop_challenge_not_proven'),(['casts',0,'round'],2,'first_round'),(['casts',1,'round'],3,'second_round'),(['casts',1,'attack_after'],8,'sample_exact6'),(['casts',1,'token_uid'],'u40','fresh_second_token'),(['casts',0,'source_uid'],'u30','cast_source'),(['casts',1,'target_uid'],'u30','original_target'),(['preserved_token_uid'],'u60','new_ready_token'),(['replacement_token_uid'],'u80','fresh_after_expiry'),(['pre_sale_combats',0,'recruit_kept'],1,'first_native_reset'),(['pre_sale_combats',1,'recruit_attack'],4,'second_buff_retained'),(['pre_sale_combats',1,'combat_start','attack'],4,'actual_second_combat_copy'),(['pre_sale_combats',1,'combat_start','golden'],True,'ordinary_lava'),(['unused_expiry','used'],True,'unused_not_cast'),(['unused_expiry','expired'],False,'native_expiry'),(['unused_expiry','spells_after'],13,'no_cast_counter_increase'),(['post_sale_combat_start','left',0,'uid'],'u20','sold_lava_absent'),(['post_sale_combat_start','right'],[],'nonempty_enemy'),(['post_sale_combat_start','left',1,'card_id'],'BG36_508','correct_darkcrest'),(['acquisitions',0,'rolls'],81,'roll_bound'),(['acquisitions',1,'source_owned'],True,'pre_source_original')]
  for keys,value,label in mutations:
   bad=deepcopy(row);target=bad
   for key in keys[:-1]:target=target[key]
   target[keys[-1]]=value;checks.append(rejected(lambda:full(bad),label))
  for keys in [[],['sale'],['sale_clock'],['unused_expiry']]:
   original=row
   for key in keys:original=original[key]
   for field in original:
    bad=deepcopy(row);target=bad
    for key in keys:target=target[key]
    target.pop(field);checks.append(rejected(lambda:full(bad),'missing_'+'.'.join(keys+[field])))
  for field in ['casts','pre_sale_combats']:
   bad=deepcopy(row);bad[field].append(deepcopy(bad[field][0]));checks.append(rejected(lambda:full(bad),'extra_'+field))
  bad=deepcopy(row);bad['all_positive_steps_proven']=True;checks.append(rejected(lambda:full(bad),'extra_unproven_global_claim'))
  for altered,label in [(log+'PASS extra\n','pass_count'),(log.replace('casts=2','casts=1'),'two_casts_required'),(log.replace('combats=3','combats=2'),'three_combats_required'),(log.replace('PASS real_first_command_after_reset_equality_observed','PASS missing'),'clock_equality_marker'),(log.replace('PASS current_cast_sale_gate_read_only_first','PASS missing'),'same_round_gate_only_readonly_marker'),(log.replace('PASS mini_token_record_reference_survives_lava_sale','PASS missing'),'all_three_receipt_references_preserved'),(log+'SCRIPT ERROR: synthetic\n','engine_error')]:checks.append(rejected(lambda:full(row,altered),label))
  altered=log.replace('PASS history_observation_does_not_advance_reset_clock','PASS TEMP').replace('PASS public_native_buffed_lava_sell','PASS history_observation_does_not_advance_reset_clock').replace('PASS TEMP','PASS public_native_buffed_lava_sell');checks.append(rejected(lambda:full(row,altered),'clock_readonly_before_actual_sale'))
  lines=['PASS '+key for key,n in r.CARRIED_SALE_PURE_MARKERS.items() for _ in range(n)]+['PASS '+key+str(i) for key,n in r.CARRIED_SALE_PURE_PREFIX_COUNTS.items() for i in range(n)];assert len(lines)==42
  summary={'passed':42,'failed':0,'failures':[],'real_game_run':False,'actual_provenance_proven':False,'deep_registry_faults_tested':False,'scope':r.CARRIED_SALE_PURE_SCOPE}
  def purelog(value):return '\n'.join(lines)+'\nDARKCREST_LAVA_CARRIED_SALE_CONTENT_CONTRACT '+json.dumps(value)+'\n'
  assert r.validate('lava_carried_sale_content_contract',purelog(summary),42,root)==(42,None);checks.append('synthetic_pure42_not_actual_count_proof')
  for key,value in [('passed',41),('failed',False),('real_game_run',True),('actual_provenance_proven',True),('deep_registry_faults_tested',True),('scope','deep registry and live histories proven')]:
   bad=dict(summary);bad[key]=value;checks.append(rejected(lambda:r.validate('lava_carried_sale_content_contract',purelog(bad),42,root),'pure_bad_'+key))
  r.NEW_TEST_METADATA['pure_checks']=None;checks.append(rejected(lambda:r.validate('lava_carried_sale_content_contract',purelog(summary),42,root),'UNKNOWN_actual_count_rejects'))
 r.NEW_TEST_METADATA['pure_checks']=count;r.NEW_VALIDATORS_READY=ready
 print(json.dumps({'status':'PASS_SYNTHETIC_CARRIED_SALE_V4_SCHEMA_NOT_GAMEPLAY','checks':len(checks),'labels':checks,'game_started':False,'godot_started':False,'actual_count_not_inferred':True},indent=2))
if __name__=='__main__':main()
