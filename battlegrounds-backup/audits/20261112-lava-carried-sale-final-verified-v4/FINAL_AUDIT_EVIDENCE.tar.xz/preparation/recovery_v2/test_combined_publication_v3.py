"""Synthetic content checks only: no actual acceptance, Game, Git or network."""
import tempfile
from publication_common_v3 import *
from combined_publication_v3 import render
import recovery_common as rc
checks=[]
def reject(fn):
 try:fn()
 except Exception:return True
 return False
require(ROOT.name=='develop_lava_carried_sale_20261112','ROOT depth');checks.append('ROOT depth')
data,meta=archive({'old/ATTEMPT_SUMMARY.json':b'{"failed":true}','new/pure.log':b'PASS fake fixture\n'})
require(verify_archive(data,meta)==2,'roundtrip');checks.append('archive roundtrip')
require(reject(lambda:verify_archive(data+b'x',meta)),'tamper reject');checks.append('archive tamper reject')
require(reject(lambda:archive({'../bad':b'x'})),'path reject');checks.append('archive unsafe path reject')
require(reject(lambda:render({'status':'FAILED','tests':{}})),'no fake success');checks.append('failed renderer reject')
f={'status':rc.FINAL_STATUS,'tests':{str(i):{} for i in range(14)}}
t=render(f);require('没有重跑 Game' in t and '13纯测未运行' in t and 'db9a' in t,'provenance text');checks.append('split provenance text')
with tempfile.TemporaryDirectory() as d:
 p=Path(d)/'immutable';put(p,b'old');require(reject(lambda:put(p,b'new')) and p.read_bytes()==b'old','exclusive output');checks.append('no overwrite')
print(json.dumps({'status':'PASS_SYNTHETIC_ONLY_NOT_GAME_OR_PUBLICATION','checks':checks,'count':len(checks)},ensure_ascii=False,indent=2))
