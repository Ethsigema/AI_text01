"""Validate real split-attempt evidence and build new final30. No Game/Git/upload."""
import argparse,shutil
from publication_common_v3 import *
import recovery_common as rc
import validator_v2 as v
import audit_core_v2 as ac

def verify_combined():
 rc.verify_tools();rc.verify_pins();m,expected,_=rc.package()
 bindings={'source_commit':SOURCE,'source_map_sha256':m['source_map_sha256'],'aggregate_sha256':m['aggregate_sha256']}
 final=read(rc.REMOTE/rc.FINAL_NAME);audit=read(rc.REMOTE/rc.AUDIT_NAME)
 require(final['status']==rc.FINAL_STATUS,'not completed combined success')
 require(audit['status']=='PASS_RECOVERED_POST_ATTEMPT_SOURCE_AND_EVIDENCE_AUDIT','missing independent post audit')
 for obj in [final,audit]:
  for k,value in bindings.items():require(obj[k]==value,'binding '+k)
 require(final['execution_attempts']==2 and final['full_game_processes']==1 and final['full_game_processes_in_resume']==0,'wrong execution accounting')
 game,original=rc.original_revalidate(expected,bindings,require_saved=True)
 prep=rc.check_preparation(rc.RESUME,bindings,rc.HERE/'run_pure_resume_v2.py')
 classified,errors=ac.classify_attempt(rc.RESUME,expected,bindings,rc.RESTORED,prep['entries'],tests=rc.PURE_TESTS)
 require(not errors and len(classified)==13 and all(x['classification']=='executed_validated' for x in classified.values()),'pure attempt incomplete')
 tests={rc.GAME:game}
 for label,*_ in rc.PURE_TESTS:tests[label]=read(rc.RESUME/(label+'_VALIDATED.json'))
 require(final['tests']==tests,'combined test receipt mismatch')
 require(final['provenance']==audit['provenance']==rc.provenance(),'provenance mismatch')
 require(audit['runner_suite_accepted'] is True and audit['errors']==[],'audit not accepted')
 require(final['evidence_directories']=={x[0]:str(rc.ORIGINAL if x[0]==rc.GAME else rc.RESUME) for x in v.TESTS},'evidence paths')
 require(final['total_passed_checks']==3489 and final['pure_passed_checks']==3334 and final['original_game_revalidated_checks']==155,'combined counts')
 require(final['full_game_acceptance'] is False and final['default_pool_promoted'] is False and final['old_full_matrices_repeated'] is False,'overclaim')
 summary=read(rc.RESUME/'ATTEMPT_SUMMARY.json')
 require(summary['status']=='THIRTEEN_PURE_VALIDATED_SOURCE_INTEGRITY_PASS' and summary['error'] is None and summary['provenance']==rc.provenance(),'resume incomplete')
 require(sum(x['passed_checks'] for x in tests.values())==3489,'wrong total')
 require(set(audit['tests'])==set(tests) and all(x['classification']=='executed_validated' for x in audit['tests'].values()),'audit classification')
 trees={n:v.scan_tree(p,expected,m['aggregate_sha256'])[0] for n,p in [('candidate',rc.CANDIDATE),('restored_snapshot',rc.RESTORED)]}
 require(all(x['matches'] for x in trees.values()),'actual source changed')
 return final,audit,game['verified_scenario_fields'],trees

def render(final):
 require(final['status']==rc.FINAL_STATUS and len(final['tests'])==14,'cannot render success')
 return '''# 有限组合验收：原 Game 复验 + 新纯测续跑

源码32a8b33。原单次 Game 进程 exit0，155项、两次原生施法、三轮非空战斗；原外部验证器误把方法参数 first/second 当 PASS 标签，原attempt整体失败、13纯测未运行，旧日志与失败回执原样保留。

修正验证器重新检查同一原日志/场景/进程凭据，没有重跑 Game。另一个新attempt实际执行13份纯合同，共3334项；组合3489项。只一个真实Game进程、两个执行attempt、一个runtime树，candidate与restore为两份来源核验，不是两次Game。

有限样本：原Mini两轮首次塑造将原Lava2/5→4/5→6/5；跨轮reset kept0后首命令原生出售，保留当前ready票；第三轮战斗后原未用票到期并原生重发。2次样本不证明所有合法steps；暗潮获取牌等级4不是随从星级变更。同轮admission仅观察，未另售。未扩金色、新target、退役Mini、buffed rebuy、inactive全局规则或默认池。

上一批未发布的 db9a 研究 tar 封装原字节丢失，非源码丢失；源码原 SHA 与保存的 diff 已通过实际重建核验。不声称该封装已完全恢复，也不是本批再次丢失。此文件本身不证明远端最终发布，须另有fresh publication核验。
'''

def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--execute',action='store_true',required=True);a=ap.parse_args()
 guard=acquire_publication_lock() # retained through verification, full rehash and package writes
 final,audit,scenario,trees=verify_combined()
 early=ROOT/'restore_receipt_package';download=read(ROOT/'EARLY_PUBLICATION_VERIFIED.json')
 require(download['commit']==EARLY and download['source_commit']==SOURCE and download['files']==23,'early fixed commit')
 check_rows(early,download['records']);require(read(ROOT/'RESTORE_RECEIPT_PUBLICATION.json')['commit']==EARLY,'early publication')
 source=read(rc.REMOTE/'FRESH_PACKAGE_DOWNLOAD_VERIFIED.json')['records']
 for row in source:
  n=row['filename']
  if n!='SHA256SUMS.txt':require((early/n).read_bytes()==(rc.REMOTE/'package'/n).read_bytes(),'source immutable '+n)
 require(len([x for x in source if x['filename']!='SHA256SUMS.txt'])==16,'source16')
 files={}
 for directory in [rc.ORIGINAL,rc.RESUME,rc.HERE]:
  for p in sorted(directory.iterdir()):
   if p.is_file() and not p.is_symlink() and p.suffix in {'.py','.gd','.json','.log','.md','.txt'}:files[str(p.relative_to(ROOT))]=p.read_bytes()
 for p in [rc.REMOTE/rc.FINAL_NAME,rc.REMOTE/rc.AUDIT_NAME,ROOT/'EARLY_PUBLICATION_VERIFIED.json',ROOT/'RESTORE_RECEIPT_PUBLICATION.json',ROOT/'evidence/LAUNCH_PREFLIGHT_PATH_CORRECTION.json',ROOT/'research/ACTUAL_GAME_VALIDATOR_FAILURE_REVIEW.md',ROOT/'research/V2_VALIDATOR_DIFF_REVIEW.md',ROOT/'validator_failure_backup_v1/PUBLICATION_VERIFIED.json',ROOT/'validator_failure_backup_v1/PUBLICATION.json',ROOT/'validator_failure_backup_v1/UPLOAD_METADATA.json',rc.REMOTE/'INDEPENDENT_RESTORE_VERIFIED.json',rc.REMOTE/'FRESH_PACKAGE_DOWNLOAD_VERIFIED.json']:
  files[str(p.relative_to(ROOT))]=p.read_bytes()
 post={'source_commit':SOURCE,'outcome':'success','provenance':rc.provenance(),'trees':trees,'source_integrity_ok':True,'game_started_by_packager':False,'full_game_acceptance':False,'source_map_sha256':final['source_map_sha256'],'aggregate_sha256':final['aggregate_sha256']}
 files['PACKAGING_COMBINED_POST_TEST_REHASH.json']=enc(post)
 data,meta=archive(files);text=render(final).encode()
 extras={'GAMEPLAY_EVIDENCE.tar.xz':data,'GAMEPLAY_EVIDENCE_MANIFEST.json':enc(meta),'GAMEPLAY_OUTCOME.json':enc(post),'GAMEPLAY_INDEPENDENT_VERIFICATION.json':(rc.REMOTE/rc.FINAL_NAME).read_bytes(),'GAMEPLAY_MATRIX_RESULT.json':(rc.ORIGINAL/v.NEW_TEST_METADATA['scenario_file']).read_bytes(),'GAMEPLAY_VERIFIED_SLICE.md':text,'GAMEPLAY_OUTCOME.md':text}
 out=ROOT/'final_combined_v3_package';require(not out.exists(),'output already exists');out.mkdir()
 for row in download['records']:
  if row['name']!='SHA256SUMS.txt':put(out/row['name'],(early/row['name']).read_bytes())
 for n,b in extras.items():put(out/n,b)
 put(out/'SHA256SUMS.txt',''.join(sha(p.read_bytes())+'  '+p.name+'\n' for p in sorted(out.iterdir())).encode())
 records=rows(out);require(len(records)==30,'final30 count')
 for row in download['records']:
  if row['name']!='SHA256SUMS.txt':require(sha((out/row['name']).read_bytes())==row['sha256'],'early22 changed')
 put(ROOT/'FINAL_COMBINED_V3_UPLOAD_METADATA.json',enc({'status':'LOCAL_COMBINED_READY_NOT_PUBLISHED','source_commit':SOURCE,'remote_folder':FOLDER,'folder':FOLDER,'files':30,'records':records,'bytes':sum(r['bytes'] for r in records)}))
 put(ROOT/'FINAL_COMBINED_V3_PUBLICATION_FILES.json',enc(records))
if __name__=='__main__':main()
