"""Immutable split-attempt provenance. Read-only except explicit new receipt outputs. No Game."""
from pathlib import Path
import json
import validator_v2 as v
import audit_core_v2 as a
HERE=Path(__file__).resolve().parent
STAGE=HERE.parent.parent
REMOTE=STAGE/'remote_snapshot_32a8b33'
ORIGINAL=REMOTE/'independent_tests'
RESUME=REMOTE/'independent_pure_resume_v2'
RESTORED=REMOTE/'single_tree_restore/restored_snapshot'
CANDIDATE=STAGE/'candidate'
GAME=v.TESTS[0][0]
PURE_TESTS=v.TESTS[1:]
FINAL_STATUS='PASS_RECOVERED_ORIGINAL_GAME_V2_REVALIDATED_AND_THIRTEEN_PURE_RESUMED_DUAL_SOURCE_REHASH'
FINAL_NAME='RECOVERED_GAME_VERIFICATION_V2.json'
AUDIT_NAME='RECOVERED_POST_ATTEMPT_AUDIT_V2.json'

def package():
 v.validate_paths(CANDIDATE,RESTORED,STAGE)
 return v.verify_package(REMOTE/'package',REMOTE/'INDEPENDENT_RESTORE_VERIFIED.json',REMOTE/'FRESH_PACKAGE_DOWNLOAD_VERIFIED.json',v.FROZEN_SOURCE_COMMIT,v.FROZEN_SOURCE['source_map_sha256'],v.FROZEN_SOURCE['aggregate_sha256'],RESTORED)

def verify_pins():
 pins=v.read_json(HERE/'ORIGINAL_ATTEMPT_PINNED.json')
 for name,row in pins['files'].items():
  p=STAGE/name
  v.require(p.is_file() and not p.is_symlink(),('Pinned original missing',name))
  b=p.read_bytes();v.require(len(b)==row['bytes'] and v.sha(b)==row['sha256'],('Pinned original changed',name))
 return pins

def verify_failure_publication():
 p=STAGE/'validator_failure_backup_v1/PUBLICATION_VERIFIED.json';receipt=v.read_json(p)
 v.require(receipt['status']=='PASS_FRESH_PUBLICATION_AND_ALL_MEMBERS' and receipt['commit']=='985a11e784e1e80ff0390c4707c2043d430543f4','Failure preservation must be published and freshly verified first')
 v.require(receipt['source_commit']==v.FROZEN_SOURCE_COMMIT and receipt['files']==4 and receipt['bytes']==1094580 and receipt['archive_members']==64,'Failure preservation scope mismatch')
 v.require(all(receipt[k] is True for k in ['every_file_git_sha_size_sha256_verified','sha256sums_verified','every_archive_member_rehashed']) and receipt['whole_suite_acceptance'] is False,'Failure preservation is not suite acceptance')
 directory=STAGE/'validator_failure_backup_v1/fresh_remote_985a11e'
 v.require(Path(receipt['download_directory'])==directory,'Failure preservation fresh path mismatch')
 for row in receipt['records']:
  b=(directory/row['name']).read_bytes()
  v.require(len(b)==row['bytes'] and v.sha(b)==row['sha256'],'Failure preservation fresh bytes changed')
 return v.sha(p.read_bytes())

def verify_tools():
 p=HERE/'RECOVERY_TOOLS_FROZEN_V2.json';freeze=v.read_json(p)
 for name,row in freeze['files'].items():
  b=(HERE/name).read_bytes();v.require(len(b)==row['bytes'] and v.sha(b)==row['sha256'],('Frozen recovery tool changed',name))
 return v.sha(p.read_bytes())

def check_preparation(evidence,bindings,runner_path):
 prep=v.read_json(evidence/'PREPARED_FROM_REMOTE.json')
 for key,value in bindings.items():v.require(prep.get(key)==value,('Preparation binding',key))
 v.require(prep['candidate_path']==str(CANDIDATE) and prep['restored_snapshot_path']==str(RESTORED),'Preparation paths')
 v.require(prep['runtime_mode']==v.RUNTIME_MODE and prep['runtime_trees']==[str(RESTORED)] and prep['two_runtime_copies'] is False,'Preparation runtime')
 v.require(prep['new_test_metadata']==v.NEW_TEST_METADATA,'Preparation test metadata')
 v.require(prep['runner_sha256']==v.sha(runner_path.read_bytes()),'Prepared runner bytes mismatch')
 v.verify_prepared(evidence,prep['entries'])
 return prep

def original_revalidate(expected,bindings,require_saved=False):
 verify_pins()
 prep=check_preparation(ORIGINAL,bindings,HERE.parent/'run_remote_lava_carried_sale.py')
 old=v.read_json(ORIGINAL/'ATTEMPT_SUMMARY.json')
 v.require(old['status']=='FAILED_OR_INCOMPLETE_ATTEMPT' and old['validated_tests']==[],'Original failure must remain recorded')
 v.require(old['error']=="ValueError(('Required PASS marker multiplicity', 'first', 1))",'Not the known external-validator-only failure')
 v.require(old['result_receipts_present']==[GAME] and old['tests_without_result_receipt']==[x[0] for x in PURE_TESTS],'Original omitted13 differs')
 for key,value in bindings.items():v.require(old[key]==value,('Original summary binding',key))
 for label in ['candidate','restored_snapshot']:
  for container,prefix in [(prep['initial_trees'],'INITIAL'),(old['trees'],'FINAL')]:
   row=container[label];p=ORIGINAL/(prefix+'_'+label+'_source_map.json')
   v.require(row['matches'] is True and row['aggregate_sha256']==bindings['aggregate_sha256'],'Original dual source mismatch')
   v.require(row['files']==v.FROZEN_SOURCE['source_files'] and row['bytes']==v.FROZEN_SOURCE['source_bytes'],'Original source count mismatch')
   v.require(row['observed_source_map_file']==p.name and v.sha(p.read_bytes())==row['observed_source_map_sha256']==bindings['source_map_sha256'] and v.read_json(p)==expected,'Original complete source map mismatch')
 rows,errors=a.classify_attempt(ORIGINAL,expected,bindings,RESTORED,prep['entries'],validation_evidence=HERE,allow_missing_validation=not require_saved)
 v.require(not errors,('Original process/scenario evidence failed',errors))
 v.require(rows[GAME]['classification']==('executed_validated' if require_saved else 'executed_revalidated'),'Original real Game not revalidated')
 v.require(all(rows[x[0]]['classification']=='omitted' for x in PURE_TESTS),'Original pure must stay omitted')
 count,scenario=v.validate(GAME,(ORIGINAL/(GAME+'.log')).read_text(),None,ORIGINAL)
 result=rows[GAME]['result']
 v.require(count==155 and result['process_started'] is True and result['exit']==0 and result['reason']=='exited' and result['exception'] is None,'Pinned actual original Game evidence not complete')
 v.require(result['elapsed']<=3600 and result['sampled_process_group_peak_rss']<=result['rss_soft_limit']<=4*1024**3,'Original resource bound exceeded')
 saved={'source':v.TESTS[0][1],'passed_checks':count,'log_sha256':result['log_sha256'],'test_sha256':expected[v.TESTS[0][1]]['sha256'],'result_sha256':v.sha((ORIGINAL/(GAME+'_result.json')).read_bytes()),'source_snapshot_matches':True,'failures':[],'result':result,'verified_scenario_fields':scenario,'scenario_sha256':v.sha((ORIGINAL/v.NEW_TEST_METADATA['scenario_file']).read_bytes())}
 if require_saved:v.require(v.read_json(HERE/(GAME+'_VALIDATED.json'))==saved,'V2 saved revalidation mismatch')
 return saved,rows

def provenance():
 return {'failure_preservation_commit':'985a11e784e1e80ff0390c4707c2043d430543f4','failure_preservation_receipt_sha256':verify_failure_publication(),'original_attempt_directory':str(ORIGINAL),'original_attempt_status':'FAILED_OR_INCOMPLETE_ATTEMPT','original_game_process_exit':0,'original_validator_failed':True,'original_validator_error':"ValueError(('Required PASS marker multiplicity', 'first', 1))",'original_pure_omitted':[x[0] for x in PURE_TESTS],'original_attempt_pinned_sha256':v.sha((HERE/'ORIGINAL_ATTEMPT_PINNED.json').read_bytes()),'corrected_game_validation_receipt':str(HERE/(GAME+'_VALIDATED.json')),'corrected_game_validation_sha256':v.sha((HERE/(GAME+'_VALIDATED.json')).read_bytes()),'resume_directory':str(RESUME),'game_rerun':False,'new_full_game_processes_in_resume':0,'full_game_processes_across_attempts':1,'pure_processes_planned_in_resume':13,'runtime_trees':[str(RESTORED)],'source_integrity_trees':[str(CANDIDATE),str(RESTORED)]}
