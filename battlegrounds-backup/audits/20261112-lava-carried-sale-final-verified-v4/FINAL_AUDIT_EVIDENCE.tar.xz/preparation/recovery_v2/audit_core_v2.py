"""Read-only audit of one single-runtime carried-buff Lava native-sale compatibility attempt; never launches Godot.

Always distinguish executed, launch-failed, incomplete, preflight-only, omitted,
and validated tests. Source integrity never upgrades failed gameplay to a pass.
Report facts even when other audit checks fail. No run_tree is used or created.
"""
from pathlib import Path
import argparse
import fcntl
import json
import sys
from validator_v2 import (sha, read_json, write_new, utc, TESTS, require,
    verify_package, validate_paths, snapshot_trees, validate, verify_prepared,
    RUNTIME_MODE, FINAL_STATUS, NEW_TEST_METADATA, require_frozen, PINNED_TESTS, PLANNED_SCOPE)


def classify_attempt(evidence, expected, bindings, restored, prepared, tests=None, validation_evidence=None, allow_missing_validation=False):
    results = {}; errors = []; prior_end = None
    for label, source, budget, count in (TESTS if tests is None else tests):
        receipt_path = evidence / (label + '_result.json')
        log_path = evidence / (label + '.log')
        started = evidence / (label + '_STARTED.json')
        intent = evidence / (label + '_LAUNCH_INTENT.json')
        precheck_path = evidence / (label + '_PRECHECK.json')
        row = {'source': source, 'process_started': False, 'classification': 'omitted'}
        results[label] = row
        if not receipt_path.exists():
            if started.exists() or log_path.exists() or intent.exists():
                row['classification'] = 'launch_or_execution_without_completion_receipt'
                row['process_started'] = True if started.exists() else None
                errors.append(label + ': launch/execution outcome uncertain; not omitted or passed')
            elif precheck_path.exists():
                row['classification'] = 'preflight_only_not_started'
            continue
        try:
            result = read_json(receipt_path); row['result'] = result
            row['process_started'] = result.get('process_started')
            require(type(row['process_started']) is bool, 'Missing explicit process_started')
            row['classification'] = 'executed_not_yet_validated' if row['process_started'] else 'launch_failed_not_executed'
            for key, value in bindings.items(): require(result.get(key) == value, 'Result binding mismatch: ' + key)
            require(result['source'] == source and result['runtime_mode'] == RUNTIME_MODE, 'Wrong test/runtime source')
            require(result['source_sha256'] == expected[source]['sha256'], 'Result test hash mismatch')
            wrapper = evidence / (label + '.gd')
            require(result['command'] == ['godot', '--headless', '--path', str(restored), '--script', str(wrapper)], 'Unexpected runtime command')
            require(result['wrapper_sha256'] == prepared[wrapper.name]['sha256'] == sha(wrapper.read_bytes()), 'Wrapper hash mismatch')
            require(log_path.is_file() and sha(log_path.read_bytes()) == result['log_sha256'], 'Log hash mismatch')
            precheck = read_json(precheck_path)
            for key, value in bindings.items(): require(precheck.get(key) == value, 'Precheck binding mismatch: ' + key)
            require(precheck['runtime_tree'] == str(restored) and precheck['source'] == source and precheck['runtime_mode'] == RUNTIME_MODE, 'Precheck wrong runtime')
            observed = evidence / precheck['source_map_file']
            require(observed == evidence / (label + '_source_map.json'), 'Precheck map path mismatch')
            require(sha(observed.read_bytes()) == precheck['observed_source_map_sha256'] and read_json(observed) == expected, 'Full pretest source map mismatch')
            tree = precheck['tree']
            require(tree['matches'] is True and tree['aggregate_sha256'] == bindings['aggregate_sha256'], 'Pretest aggregate mismatch')
            require(all(tree[k] == [] for k in ['missing', 'extra', 'mismatched']), 'Pretest map changed')
            require(result['start_tree'] == tree and result['source_snapshot_matches'] is True, 'Result/precheck mismatch')
            require(result['timeout_seconds'] == budget and type(result['rss_soft_limit']) is int and 0 < result['rss_soft_limit'] <= 4 * 1024**3, 'Budget mismatch')
            if not row['process_started']:
                require(result['exit'] is None and result['reason'] == 'launch_failed', 'Invalid no-process receipt')
                errors.append(label + ': launch failed before process start'); continue
            require(started.is_file(), 'Started process missing start receipt')
            start_record = read_json(started)
            require(start_record['command'] == result['command'] and start_record['source_commit'] == bindings['source_commit'], 'Start receipt binding mismatch')
            require(prior_end is None or result['started_at_utc'] >= prior_end, 'Test processes not serial')
            require(result['finished_at_utc'] >= result['started_at_utc'], 'Invalid process timestamps')
            prior_end = result['finished_at_utc']
            if result['exit'] != 0 or result['reason'] != 'exited':
                row['classification'] = 'process_failed'; errors.append(label + ': process failed'); continue
            log = log_path.read_text(encoding='utf-8')
            passed, scenario = validate(label, log, count, evidence)
            row['classification'] = 'executed_revalidated'
            row['revalidated_checks'] = passed
            validated_path = (validation_evidence or evidence) / (label + '_VALIDATED.json')
            if allow_missing_validation and not validated_path.exists():
                continue
            require(validated_path.is_file(), 'Revalidated log has no runner validation receipt')
            saved = read_json(validated_path)
            require(saved['result'] == result and saved['result_sha256'] == sha(receipt_path.read_bytes()), 'Validation/result receipt mismatch')
            require(saved['passed_checks'] == passed and saved['log_sha256'] == result['log_sha256'] and saved['failures'] == [], 'Validation counts/log mismatch')
            if scenario is not None:
                require(saved['verified_scenario_fields'] == scenario and saved['scenario_sha256'] == sha((evidence / NEW_TEST_METADATA['scenario_file']).read_bytes()), 'Scenario binding mismatch')
            row['classification'] = 'executed_validated'
        except Exception as exc:
            if row['classification'] not in ['process_failed', 'launch_failed_not_executed']:
                row['classification'] = 'executed_validation_or_evidence_failed' if row['process_started'] else 'receipt_or_launch_evidence_failed'
            row['audit_error'] = repr(exc); errors.append(label + ': ' + repr(exc))
    return results, errors

