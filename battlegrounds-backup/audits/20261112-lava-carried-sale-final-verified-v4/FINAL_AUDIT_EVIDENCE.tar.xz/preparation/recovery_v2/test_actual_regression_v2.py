"""Uses frozen actual original log/source, not markers-generated positive fixtures. No Godot."""
from pathlib import Path
from copy import deepcopy
import ast,importlib.util,json,tempfile
from collections import Counter
from recovery_common import *

def reject(fn):
 try:fn()
 except (ValueError,AssertionError,KeyError,TypeError,StopIteration):return
 raise AssertionError('Invalid evidence accepted')

def main():
 checks=[];_,expected,bindings=package();saved,rows=original_revalidate(expected,bindings,require_saved=True);checks.append('actual_original_process_and_log_and_scene_revalidate_155')
 oldpath=HERE.parent/'run_remote_lava_carried_sale.py';spec=importlib.util.spec_from_file_location('old_carried_validator',oldpath);old=importlib.util.module_from_spec(spec);spec.loader.exec_module(old)
 log=(ORIGINAL/(GAME+'.log')).read_text();scene=v.read_json(ORIGINAL/v.NEW_TEST_METADATA['scenario_file'])
 reject(lambda:old.validate(GAME,log,None,ORIGINAL));checks.append('original_validator_reproduces_actual_false_rejection_without_Game')
 source=(RESTORED/v.TESTS[0][1]).read_text()
 for label in ['first','second']:
  assert 'observe_current_cast_sale_gate(lava,"'+label+'")' in source
  assert not any('must(' in line and ',"'+label+'")' in line for line in source.splitlines())
  assert label not in v.CARRIED_SALE_FULL_MARKERS
  for prefix in ['actual_current_cast_sale_gate_','current_cast_sale_gate_read_only_']:
   assert prefix+label in v.CARRIED_SALE_FULL_MARKERS and log.splitlines().count('PASS '+prefix+label)==1
  checks.append('source_argument_'+label+'_is_not_must_label_but_composed_markers_required')
 assert {k:n for k,n in old.CARRIED_SALE_FULL_MARKERS.items() if k not in ['first','second']}==v.CARRIED_SALE_FULL_MARKERS
 checks.append('exactly_two_nonmarkers_removed_all_other_requirements_preserved')
 oldast=ast.parse(oldpath.read_text());newast=ast.parse((HERE/'validator_v2.py').read_text())
 oldfunc={n.name:ast.dump(n) for n in oldast.body if isinstance(n,ast.FunctionDef) and n.name!='main'}
 newfunc={n.name:ast.dump(n) for n in newast.body if isinstance(n,ast.FunctionDef) and n.name!='main'}
 assert oldfunc==newfunc;checks.append('all_nonentrypoint_functions_AST_identical_to_old_strict_validator')
 counts=Counter(line[5:] for line in log.splitlines() if line.startswith('PASS '))
 assert sum(counts.values())==155 and all(counts[k]==n for k,n in v.CARRIED_SALE_FULL_MARKERS.items())
 checks.append('independent_actual_log_counter_matches_corrected_requirements')
 for marker in v.CARRIED_SALE_FULL_MARKERS:
  modified=log.replace('PASS '+marker+'\n','PASS __missing_required_marker__\n',1)
  reject(lambda:v.validate(GAME,modified,None,ORIGINAL));checks.append('actual_log_required_marker_not_relaxed:'+marker)
 with tempfile.TemporaryDirectory(dir=HERE,prefix='regression_detached_') as td:
  p=Path(td);f=p/v.NEW_TEST_METADATA['scenario_file'];f.write_text(json.dumps(scene))
  assert v.validate(GAME,log,None,p)==(155,scene)
  for keys,value in [(['sale_clock','current_sequence'],88),(['sale_clock','last_cast_sequence'],87),(['unused_expiry','used'],True),(['casts',1,'attack_after'],8),(['sale','departed_stats','kept'],1)]:
   row=deepcopy(scene);target=row
   for key in keys[:-1]:target=target[key]
   target[keys[-1]]=value;f.write_text(json.dumps(row));reject(lambda:v.validate(GAME,log,None,p));checks.append('actual_scene_mutation_rejected:'+str(keys))
 import run_pure_resume_v2 as resume
 reject(lambda:resume.run_pure(GAME,v.TESTS[0][1],3600,{},None,{},None,{}));checks.append('resume_entry_rejects_real_Game_before_subprocess')
 assert len(PURE_TESTS)==13 and sum(t[3] for t in PURE_TESTS)==3334 and all(t[0]!=GAME for t in PURE_TESTS)
 checks.append('thirteen_never_executed_pure_only_total3334')
 assert all(rows[t[0]]['classification']=='omitted' for t in PURE_TESTS);checks.append('original_thirteen_omitted_not_rewritten_as_pass')
 verify_failure_publication();checks.append('failure_preservation_fresh4_gate_verified_not_suite_acceptance')
 print(v.dump({'status':'PASS_ACTUAL_EVIDENCE_REGRESSION_AND_DETACHED_NEGATIVES_V2','checks':len(checks),'labels':checks,'original_log_sha256':v.sha(log.encode()),'original_Game_checks_revalidated':155,'new_processes':0,'game_rerun':False,'pure_tests_executed':0}).decode())
if __name__=='__main__':main()
