"""Independent post-audit of two attempts and one original Game. Never starts Godot."""
import argparse,fcntl,sys
from recovery_common import *

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--execute',action='store_true');args=p.parse_args()
 if not args.execute:print('Requires --execute to write new recovered audit; no Game.');return
 output=REMOTE/AUDIT_NAME;v.require(not output.exists(),'Never overwrite recovery audit')
 with (STAGE.parent/'develop_empty_ghost_20261112/.independent_full_game.lock').open('a') as lock:
  fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
  errors=[];expected={};bindings={};original_rows={};pure_rows={};accepted=False;final=None
  try:
   verify_tools();_,expected,bindings=package();saved,original_rows=original_revalidate(expected,bindings,require_saved=True)
  except Exception as exc:errors.append('Original source/provenance: '+repr(exc))
  prepared={}
  try:
   prep=check_preparation(RESUME,bindings,HERE/'run_pure_resume_v2.py');prepared=prep['entries']
   v.require(prep['provenance']==provenance() and prep['recovery_tools_freeze_sha256']==verify_tools(),'Recovery preparation provenance changed')
   v.require(prep['game_started_by_resume'] is False and prep['tests_to_execute']==[x[0] for x in PURE_TESTS],'Resume claimed wrong processes')
  except Exception as exc:errors.append('Resume preparation: '+repr(exc))
  v.require(RESUME.is_dir(),'No pure resume evidence; cannot audit')
  trees=v.snapshot_trees(CANDIDATE,RESTORED,expected,v.FROZEN_SOURCE['aggregate_sha256'],RESUME,'AUDIT_V2')
  if not expected or not all(row['matches'] for row in trees.values()):errors.append('Post-audit complete dual source mismatch')
  pure_rows,pure_errors=a.classify_attempt(RESUME,expected,bindings,RESTORED,prepared,tests=PURE_TESTS);errors.extend(pure_errors)
  # A real Game command in the continuation is forbidden, even if hidden outside expected rows.
  actual_results=sorted(p.name for p in RESUME.glob('*_result.json'))
  expected_results=sorted(x[0]+'_result.json' for x in PURE_TESTS if (RESUME/(x[0]+'_result.json')).exists())
  if actual_results!=expected_results:errors.append('Unexpected process result in pure continuation')
  results={}
  if GAME in original_rows:results[GAME]={**original_rows[GAME],'attempt':'original_game_v2_revalidated','evidence_directory':str(ORIGINAL)}
  results.update({label:{**row,'attempt':'pure_resume_v2','evidence_directory':str(RESUME)} for label,row in pure_rows.items()})
  try:
   summary=v.read_json(RESUME/'ATTEMPT_SUMMARY.json')
   v.require(summary['provenance']==provenance() and summary['game_processes_in_this_attempt']==0,'Resume summary provenance mismatch')
   for key,value in bindings.items():v.require(summary[key]==value,'Resume summary source mismatch')
   v.require(summary['result_receipts_present']==[x[0] for x in PURE_TESTS if (RESUME/(x[0]+'_result.json')).exists()],'Resume executed receipts mismatch')
   v.require(summary['tests_without_result_receipt']==[x[0] for x in PURE_TESTS if not (RESUME/(x[0]+'_result.json')).exists()],'Resume omitted receipts mismatch')
   prior=original_rows[GAME]['result']['finished_at_utc']
   for label,_,_,_ in PURE_TESTS:
    row=pure_rows[label]
    if row.get('process_started') is True:
     v.require(row['result']['started_at_utc']>=prior,'Original/resume process overlap');prior=row['result']['finished_at_utc']
   if (REMOTE/FINAL_NAME).exists():
    final=v.read_json(REMOTE/FINAL_NAME)
    for key,value in bindings.items():v.require(final[key]==value,'Final source binding mismatch')
    v.require(final['status']==FINAL_STATUS and final['provenance']==provenance(),'Final recovery provenance mismatch')
    v.require(final['evidence_directories']=={x[0]:str(ORIGINAL if x[0]==GAME else RESUME) for x in v.TESTS},'Final evidence paths mismatch')
    v.require(final['runtime_trees']==[str(RESTORED)] and final['source_integrity_trees']==[str(CANDIDATE),str(RESTORED)] and final['runtime_mode']==v.RUNTIME_MODE and final['two_runtime_copies'] is False,'Final runtime path mismatch')
    v.require(final['full_game_processes']==1 and final['full_game_processes_in_resume']==0 and final['execution_attempts']==2 and final['sequential_game_execution'] is True,'Final process claim mismatch')
    v.require(final['old_full_matrices_repeated'] is False and final['full_game_acceptance'] is False and final['default_pool_promoted'] is False and final['new_native_permanence_algorithm_added'] is False,'Final overclaim')
    v.require(final['planned_scope']==v.PLANNED_SCOPE and final['new_test_metadata']==v.NEW_TEST_METADATA and final['scope']==v.NEW_TEST_METADATA['scope'],'Final scope changed')
    v.require(summary['status']=='THIRTEEN_PURE_VALIDATED_SOURCE_INTEGRITY_PASS' and summary['error'] is None,'Pure summary not complete')
    v.require(set(final['tests'])==set(results)=={x[0] for x in v.TESTS} and all(row['classification']=='executed_validated' for row in results.values()),'Combined tests missing/failed')
    for label in final['tests']:
     path=(HERE if label==GAME else RESUME)/(label+'_VALIDATED.json')
     v.require(final['tests'][label]==v.read_json(path),'Combined validated receipt changed')
    v.require(final['total_passed_checks']==3489 and final['pure_passed_checks']==3334 and final['original_game_revalidated_checks']==155,'Combined actual counts mismatch')
    for container in [summary,final]:
     v.require(all(container['trees'][k]['matches'] is True and container['trees'][k]['aggregate_sha256']==bindings['aggregate_sha256'] for k in ['candidate','restored_snapshot']),'Final dual source receipts mismatch')
    accepted=not errors
  except Exception as exc:errors.append('Combined summary/receipt: '+repr(exc))
  report={'status':'PASS_RECOVERED_POST_ATTEMPT_SOURCE_AND_EVIDENCE_AUDIT' if not errors else 'FAIL_RECOVERED_POST_ATTEMPT_AUDIT',**bindings,'verified_at_utc':v.utc(),'trees':trees,'errors':errors,'runner_suite_accepted':accepted,'runner_success_receipt_present':final is not None,'tests':results,'executed_tests':[k for k,row in results.items() if row.get('process_started') is True],'omitted_tests':[k for k,row in results.items() if row['classification']=='omitted'],'original_attempt_tests':original_rows,'original_attempt_status_preserved':'FAILED_OR_INCOMPLETE_ATTEMPT','original_omitted_tests':[x[0] for x in PURE_TESTS],'runtime_mode':v.RUNTIME_MODE,'two_runtime_copies':False,'provenance':provenance(),'not_run_tests_are_not_passes':True,'source_integrity_is_not_gameplay_acceptance':True,'godot_or_game_started_by_audit':False}
  v.write_new(output,report);print(v.dump({'status':report['status'],'suite_accepted':accepted,'executed':len(report['executed_tests']),'omitted':report['omitted_tests'],'errors':errors}).decode())
  if errors:sys.exit(1)
if __name__=='__main__':main()
