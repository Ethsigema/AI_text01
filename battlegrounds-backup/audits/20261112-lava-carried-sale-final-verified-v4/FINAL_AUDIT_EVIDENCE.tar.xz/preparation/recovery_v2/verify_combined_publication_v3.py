"""Fresh-download fixed final30 and verify all members. No Game, Git or upload."""
import argparse,subprocess,re
from publication_common_v3 import *
from combined_publication_v3 import verify_combined

def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--execute',action='store_true',required=True);ap.add_argument('--publication',type=Path,required=True);a=ap.parse_args()
 final,audit,scenario,trees=verify_combined();pub=read(a.publication)
 require(re.fullmatch('[0-9a-f]{40}',pub['commit']) and pub['commit'] not in [SOURCE,EARLY] and pub['source_commit']==SOURCE,'invalid final commit')
 require(pub.get('folder',pub.get('remote_folder'))==FOLDER,'folder mismatch')
 records=read(ROOT/'FINAL_COMBINED_V3_PUBLICATION_FILES.json');require(len(records)==30,'expected30')
 out=ROOT/('final_combined_v3_remote_'+pub['commit']);out.mkdir(exist_ok=False)
 for row in records:
  n=row['name'];require(safe(n) and '/' not in n,'unsafe name');url=f'https://raw.githubusercontent.com/Ethsigema/AI_text01/{pub["commit"]}/{FOLDER}/{n}'
  partial=out/(n+'.partial');subprocess.run(['curl','-fsSL','--retry','3','--connect-timeout','30','--max-time','300','-o',str(partial),url],check=True)
  b=partial.read_bytes();require(len(b)==row['bytes'] and sha(b)==row['sha256'] and hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==row['git_sha'],'fresh bytes '+n);partial.rename(out/n)
 sums={}
 for line in (out/'SHA256SUMS.txt').read_text().splitlines():
  digest,n=line.split('  ',1);require(n not in sums and safe(n) and '/' not in n and sha((out/n).read_bytes())==digest,'bad SUMS');sums[n]=digest
 require(set(sums)=={r['name'] for r in records}-{'SHA256SUMS.txt'},'SUMS coverage')
 early=read(ROOT/'EARLY_PUBLICATION_VERIFIED.json');unchanged={}
 for row in early['records']:
  if row['name']!='SHA256SUMS.txt':require(sha((out/row['name']).read_bytes())==row['sha256'],'early changed');unchanged[row['name']]=row['sha256']
 require(len(unchanged)==22,'early22')
 manifest=read(out/'MANIFEST.json');archives={}
 for p in out.glob('*.tar.xz'):
  meta={'archive_sha256':manifest['archive_sha256'],'members':manifest['changed_files']} if p.name==manifest.get('archive') else read(out/(p.name.removesuffix('.tar.xz')+'_MANIFEST.json'))
  archives[p.name]=verify_archive(p.read_bytes(),meta)
 require({'FIX_EVIDENCE.tar.xz','TOOLS_EVIDENCE.tar.xz','GAMEPLAY_EVIDENCE.tar.xz'}<=set(archives),'archive coverage')
 require(read(out/'GAMEPLAY_INDEPENDENT_VERIFICATION.json')==final and read(out/'GAMEPLAY_MATRIX_RESULT.json')==scenario,'combined receipt changed')
 with tarfile.open(out/'GAMEPLAY_EVIDENCE.tar.xz','r:xz') as t:
  names=set(t.getnames())
  required=['remote_snapshot_32a8b33/independent_tests/ATTEMPT_SUMMARY.json','remote_snapshot_32a8b33/RECOVERED_GAME_VERIFICATION_V2.json','remote_snapshot_32a8b33/RECOVERED_POST_ATTEMPT_AUDIT_V2.json','evidence/LAUNCH_PREFLIGHT_PATH_CORRECTION.json','research/ACTUAL_GAME_VALIDATOR_FAILURE_REVIEW.md']
  require(set(required)<=names,'combined provenance missing')
  require(json.loads(t.extractfile(required[1]).read())==final,'archived final mismatch')
 report={'status':'PASS_COMBINED_V3_FINAL_FRESH_BYTES_ALL_ARCHIVE_MEMBERS','commit':pub['commit'],'source_commit':SOURCE,'remote_folder':FOLDER,'files':30,'records':records,'archive_member_counts':archives,'early22_immutable':unchanged,'game_rerun':False,'original_game_revalidated':True,'resumed_pure_processes':13,'game_started_by_verifier':False,'full_game_acceptance':False,'outcome':'success'}
 put(ROOT/'FINAL_COMBINED_V3_PUBLICATION_VERIFIED.json',enc(report))
if __name__=='__main__':main()
