"""Revalidate existing original Game evidence. No Godot, no original writes."""
import argparse
from recovery_common import *
def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--execute',action='store_true');args=p.parse_args()
 if not args.execute:print('Read-only original Game validation; --execute writes NEW V2 receipts only. No Godot.');return
 _,expected,bindings=package();saved,rows=original_revalidate(expected,bindings)
 v.write_new(HERE/(GAME+'_VALIDATED.json'),saved)
 v.write_new(HERE/'ORIGINAL_GAME_REVALIDATED_V2.json',{'status':'PASS_ORIGINAL_GAME_EXIT0_155_REVALIDATED_WITH_CORRECTED_MARKER_SET',**bindings,'verified_at_utc':v.utc(),'original_failure_preserved':True,'godot_started':False,'game_rerun':False,'checks':saved['passed_checks'],'tests':rows,'provenance':provenance(),'validator_sha256':v.sha((HERE/'validator_v2.py').read_bytes())})
 print('PASS_ORIGINAL_GAME_REVALIDATED_V2 checks=155 new_processes=0 original_omitted_pure=13')
if __name__=='__main__':main()
