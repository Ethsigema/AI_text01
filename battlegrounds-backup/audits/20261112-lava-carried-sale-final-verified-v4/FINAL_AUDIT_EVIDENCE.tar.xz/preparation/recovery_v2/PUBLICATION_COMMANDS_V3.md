# Commands, not executed here

Only after recovery original-log validation, 13 new actual pure runs, independent recovered audit, and full dual-source SHA pass:

```sh
python develop_lava_carried_sale_20261112/preparation/recovery_v2/combined_publication_v3.py --execute
```

Outputs new stage/final_combined_v3_package (30 files), FINAL_COMBINED_V3_UPLOAD_METADATA.json and FINAL_COMBINED_V3_PUBLICATION_FILES.json. New commit must preserve pending/20261112-lava-carried-sale history; do not replace/delete old commits. Source16 non-SUMS and early22 non-SUMS must remain byte-identical. This tool does not publish.

After parent publishes and saves a new publication JSON containing exact commit/source_commit/folder:

```sh
python develop_lava_carried_sale_20261112/preparation/recovery_v2/verify_combined_publication_v3.py --execute --publication /ABSOLUTE/PATH/TO/NEW_FINAL_PUBLICATION.json
python develop_lava_carried_sale_20261112/preparation/recovery_v2/prepare_combined_audit_v3.py --execute --publication /ABSOLUTE/PATH/TO/NEW_FINAL_PUBLICATION.json --audit-remote-folder battlegrounds-backup/audits/20261112-lava-carried-sale-combined-v3
```

Fresh verifier downloads all30 from exact commit and verifies SHA/size/Git blob IDs/SUMS/early22/all archive members, original failed attempt presence and corrected final evidence. Small audit is a new local output and still requires separate parent publication/fresh verification. No Godot or Git is invoked by these tools. Existing outputs are refused, not overwritten. Do not run again over any existing output; revised tools/results require new version paths.

Original Game was NOT rerun: original exit0 process/log is revalidated by corrected strict validator. Original validator failure +13 omitted remains recorded; new pure attempt supplies 13 actual executions. Final acceptance cannot be written before real success and independent audit. Historical db9a package loss remains disclosed.

V3 holds the runtime shared nonblocking flock throughout build. A busy runner causes refusal, never waiting or terminating it. Help/synthetic do not acquire that lock. V2 frozen tools remain untouched.
