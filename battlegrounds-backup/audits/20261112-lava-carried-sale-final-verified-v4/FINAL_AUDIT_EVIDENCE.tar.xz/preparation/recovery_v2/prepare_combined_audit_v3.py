"""Prepare a small new final publication audit. Never upload or run Game."""
import argparse
from publication_common_v3 import *
def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--execute',action='store_true',required=True);ap.add_argument('--publication',type=Path,required=True);ap.add_argument('--audit-remote-folder',required=True);a=ap.parse_args()
 require(safe(a.audit_remote_folder) and a.audit_remote_folder.startswith('battlegrounds-backup/audits/'),'audit folder')
 receipt=read(ROOT/'FINAL_COMBINED_V3_PUBLICATION_VERIFIED.json');pub=read(a.publication)
 require(receipt['status']=='PASS_COMBINED_V3_FINAL_FRESH_BYTES_ALL_ARCHIVE_MEMBERS' and receipt['commit']==pub['commit'] and receipt['source_commit']==SOURCE and receipt['files']==30 and receipt['game_rerun'] is False,'not verified')
 out=ROOT/'final_combined_v3_verification_audit';out.mkdir(exist_ok=False)
 for n in ['SOURCE_PUBLICATION.json','RESTORE_RECEIPT_PUBLICATION.json','FINAL_COMBINED_V3_PUBLICATION_VERIFIED.json','FINAL_COMBINED_V3_UPLOAD_METADATA.json','FINAL_COMBINED_V3_PUBLICATION_FILES.json']:put(out/n,(ROOT/n).read_bytes())
 put(out/'FINAL_PUBLICATION.json',a.publication.read_bytes())
 for n in ['publication_common_v3.py','combined_publication_v3.py','verify_combined_publication_v3.py','prepare_combined_audit_v3.py']:
  put(out/n,(Path(__file__).parent/n).read_bytes())
 put(out/'README.md',f'# 最终组合发布核验\n\n最终commit {pub["commit"]}，source {SOURCE}，fresh30文件及所有archive成员已核。原Game exit0经修正validator复验，没有再跑Game；13pure在新attempt实际执行。原attempt失败与13omitted保留，非单attempt全成功。上一批未发布的 db9a 研究 tar 封装原字节丢失，非源码丢失；源码原 SHA 与保存 diff 重建通过，不声称封装完全恢复，也不是本批再次丢失。此新审计包尚未发布。\n'.encode())
 put(out/'SHA256SUMS.txt',''.join(sha(p.read_bytes())+'  '+p.name+'\n' for p in sorted(out.iterdir())).encode())
 records=rows(out);put(ROOT/'FINAL_COMBINED_V3_AUDIT_UPLOAD_METADATA.json',enc({'status':'LOCAL_AUDIT_READY_NOT_PUBLISHED','source_commit':SOURCE,'folder':a.audit_remote_folder,'remote_folder':a.audit_remote_folder,'files':len(records),'records':records,'bytes':sum(r['bytes'] for r in records)}))
if __name__=='__main__':main()
