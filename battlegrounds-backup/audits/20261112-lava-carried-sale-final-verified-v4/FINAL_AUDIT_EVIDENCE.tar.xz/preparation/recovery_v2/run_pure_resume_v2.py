"""Resume only the thirteen never-executed pure contracts. Original Game is never rerun."""
import argparse,fcntl,os
from recovery_common import *

def run_pure(label,source,budget,bindings,evidence,expected,env,prepared):
 v.require((label,source,budget,next(x[3] for x in PURE_TESTS if x[0]==label)) in PURE_TESTS,'Pure-only test allowlist')
 v.require(label!=GAME and source.endswith('/content_contract.gd') or label in ['source_eot_contract','hand_shape_contract','seafloor_annotation_contract'],'No Game/real_matrix execution in recovery')
 v.require(budget==180,'Pure budget only')
 return v.run_test(label,source,budget,bindings,RESTORED,evidence,expected,v.FROZEN_SOURCE['aggregate_sha256'],env,prepared)

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--execute',action='store_true');args=p.parse_args()
 v.require_frozen();verify_tools();manifest,expected,bindings=package();saved,original_rows=original_revalidate(expected,bindings,require_saved=True)
 if not args.execute:
  print(v.dump({'status':'CONFIGURATION_ONLY_NO_GODOT','tests':PURE_TESTS,'original_game_checks':saved['passed_checks'],'new_game_processes':0,'provenance':provenance()}).decode());return
 lock_path=STAGE.parent/'develop_empty_ghost_20261112/.independent_full_game.lock'
 with lock_path.open('a') as lock:
  fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
  v.require(not RESUME.exists(),'Never overwrite a prior pure-resume attempt')
  v.require(not (REMOTE/FINAL_NAME).exists(),'Never overwrite a combined receipt')
  RESUME.mkdir();runs={};prepared={};error=None;final_trees={};prior_end=saved['result']['finished_at_utc']
  try:
   initial=v.snapshot_trees(CANDIDATE,RESTORED,expected,bindings['aggregate_sha256'],RESUME,'INITIAL')
   v.require(all(row['matches'] for row in initial.values()),'Initial dual source integrity failed')
   verify_pins();verify_tools()
   for label,name,_,_ in PURE_TESTS:
    data=('extends "res://'+name+'"\n').encode()
    with (RESUME/(label+'.gd')).open('xb') as f:f.write(data)
    prepared[label+'.gd']={'bytes':len(data),'sha256':v.sha(data),'source':name,'source_sha256':expected[name]['sha256'],'kind':'external_wrapper'}
   fixture=(RESTORED/v.FIXTURE).read_bytes();v.require({'bytes':len(fixture),'sha256':v.sha(fixture)}==expected[v.FIXTURE],'Fixture changed')
   with (RESUME/'darkcrest_sources_archived.gd').open('xb') as f:f.write(fixture)
   prepared['darkcrest_sources_archived.gd']={**expected[v.FIXTURE],'source':v.FIXTURE,'kind':'small_remote_fixture_copy'}
   v.write_new(RESUME/'PREPARED_FROM_REMOTE.json',{**bindings,'prepared_at_utc':v.utc(),'entries':prepared,'baseline':v.BASELINE,'initial_trees':initial,'candidate_path':str(CANDIDATE),'restored_snapshot_path':str(RESTORED),'runtime_mode':v.RUNTIME_MODE,'runtime_trees':[str(RESTORED)],'two_runtime_copies':False,'runner_sha256':v.sha(Path(__file__).read_bytes()),'new_test_metadata':v.NEW_TEST_METADATA,'provenance':provenance(),'recovery_tools_freeze_sha256':verify_tools(),'tests_to_execute':[x[0] for x in PURE_TESTS],'game_started_by_resume':False})
   env=os.environ.copy()
   for key,folder in [('HOME','home'),('XDG_CACHE_HOME','cache'),('XDG_CONFIG_HOME','config'),('XDG_DATA_HOME','data')]:
    destination=RESUME/folder;destination.mkdir();env[key]=str(destination)
   for label,name,budget,count in PURE_TESTS:
    verify_tools();verify_pins()
    result,log=run_pure(label,name,budget,bindings,RESUME,expected,env,prepared)
    v.require(result['started_at_utc']>=prior_end,'Nonserial original/resume process timestamps');prior_end=result['finished_at_utc']
    actual,scenario=v.validate(label,log,count,RESUME);v.require(scenario is None,'Pure test unexpectedly produced Game scenario')
    row={'source':name,'passed_checks':actual,'log_sha256':result['log_sha256'],'test_sha256':expected[name]['sha256'],'result_sha256':v.sha((RESUME/(label+'_result.json')).read_bytes()),'source_snapshot_matches':True,'failures':[],'result':result}
    runs[label]=row;v.write_new(RESUME/(label+'_VALIDATED.json'),row)
  except BaseException as exc:error=exc
  finally:
   final_trees=v.snapshot_trees(CANDIDATE,RESTORED,expected,bindings['aggregate_sha256'],RESUME,'FINAL')
   try:
    verify_tools();verify_pins();v.verify_prepared(RESUME,prepared)
    _,last_map,last_bindings=package();v.require(last_map==expected and last_bindings==bindings,'Package/restore binding changed')
    original_revalidate(expected,bindings,require_saved=True)
   except Exception as exc:
    if error is None:error=exc
   if not all(row['matches'] for row in final_trees.values()) and error is None:error=ValueError('Post-resume dual source failed')
   summary={**bindings,'finished_at_utc':v.utc(),'status':'THIRTEEN_PURE_VALIDATED_SOURCE_INTEGRITY_PASS' if error is None and len(runs)==13 else 'FAILED_OR_INCOMPLETE_PURE_RESUME','error':repr(error) if error is not None else None,'validated_tests':list(runs),'result_receipts_present':[x[0] for x in PURE_TESTS if (RESUME/(x[0]+'_result.json')).exists()],'tests_without_result_receipt':[x[0] for x in PURE_TESTS if not (RESUME/(x[0]+'_result.json')).exists()],'trees':final_trees,'runtime_mode':v.RUNTIME_MODE,'two_runtime_copies':False,'provenance':provenance(),'game_processes_in_this_attempt':0,'original_game_checks_revalidated':155}
   v.write_new(RESUME/'ATTEMPT_SUMMARY.json',summary)
  if error is not None:raise error
  v.require(len(runs)==13 and sum(x['passed_checks'] for x in runs.values())==3334,'Not all thirteen pure contracts validated')
  combined={GAME:saved,**runs}
  final={'status':FINAL_STATUS,**bindings,'verified_at_utc':v.utc(),'trees':final_trees,'tests':combined,'baseline':v.BASELINE,'runtime_mode':v.RUNTIME_MODE,'runtime_trees':[str(RESTORED)],'source_integrity_trees':[str(CANDIDATE),str(RESTORED)],'two_runtime_copies':False,'sequential_game_execution':True,'full_game_processes':1,'full_game_processes_in_resume':0,'execution_attempts':2,'old_full_matrices_repeated':False,'planned_scope':v.PLANNED_SCOPE,'new_test_metadata':v.NEW_TEST_METADATA,'full_game_acceptance':False,'default_pool_promoted':False,'new_native_permanence_algorithm_added':False,'scope':v.NEW_TEST_METADATA['scope'],'provenance':provenance(),'evidence_directories':{x[0]:str(ORIGINAL if x[0]==GAME else RESUME) for x in v.TESTS},'total_passed_checks':sum(x['passed_checks'] for x in combined.values()),'pure_passed_checks':sum(x['passed_checks'] for x in runs.values()),'original_game_revalidated_checks':saved['passed_checks']}
  v.write_new(REMOTE/FINAL_NAME,final)
  print('PASS_RECOVERED_ORIGINAL_GAME_AND_THIRTEEN_PURE combined_checks='+str(final['total_passed_checks']),flush=True)
if __name__=='__main__':main()
