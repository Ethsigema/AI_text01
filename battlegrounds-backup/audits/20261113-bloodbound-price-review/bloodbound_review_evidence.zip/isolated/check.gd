extends SceneTree
const B=preload("res://core/patch_3702_bloodbound_earrings_sources.gd")
var failures: Array=[]
var checks: int=0
func check(ok: bool, label: String):
 checks+=1
 if not ok: failures.append(label)
func _init():
 check(B.proof_error()=="","immutable source proof")
 check(B.EXPECTED_RAW.cost==1,"historical raw preserved")
 check(B.EXPECTED_CURRENT.cost==2,"effective lesser price")
 var greater: Dictionary={}
 var raw=JSON.parse_string(FileAccess.get_file_as_string("res://data/catalog_raw.json"))
 for c in raw.cards:
  if c.id=="BG32_MagicItem_808t":greater=c
 check(greater.get("cost")==6,"greater own cost6")
 var before=greater.duplicate(true)
 var cards={B.ID:B.EXPECTED_BASELINE.duplicate(true),"BG32_MagicItem_808t":greater}
 check(B.apply_overlay(cards)=="","actual overlay succeeds")
 check(cards[B.ID].cost==2,"actual resulting lesser cost2")
 check(cards["BG32_MagicItem_808t"]==before,"greater untouched")
 check(B.source_error(cards[B.ID])=="","effective source accepted")
 var stale=cards[B.ID].duplicate(true);stale.cost=1
 check(not B.source_error(stale).is_empty(),"stale price rejected")
 var bad={B.ID:B.EXPECTED_BASELINE.duplicate(true)};bad[B.ID].cost=999
 check(not B.apply_overlay(bad).is_empty(),"changed baseline rejected")
 print(JSON.stringify({"checks":checks,"failures":failures,"scope":"isolated acquisition overlay, not full catalog or gameplay"}))
 quit(0 if failures.is_empty() else 1)
