from pathlib import Path
import json,gzip,hashlib,fcntl,stat,datetime,shutil
R=Path.cwd();P=R/'develop_lava_next_20261112/preparation'
sha=lambda b:hashlib.sha256(b).hexdigest()
read=lambda p:json.loads(p.read_text())
def scan(t,expected,aggregate):
 actual={};agg=hashlib.sha256();allocated=0
 for p in sorted(t.rglob('*'),key=lambda x:x.relative_to(t).as_posix()):
  s=p.lstat();assert not stat.S_ISLNK(s.st_mode)
  if stat.S_ISDIR(s.st_mode):continue
  assert stat.S_ISREG(s.st_mode) and s.st_nlink==1,p
  b=p.read_bytes();n=p.relative_to(t).as_posix();actual[n]={'bytes':len(b),'sha256':sha(b)};agg.update(n.encode()+b'\0'+str(len(b)).encode()+b'\0'+b);allocated+=s.st_blocks*512
 assert actual==expected and agg.hexdigest()==aggregate
 return {'files':len(actual),'bytes':sum(x['bytes'] for x in actual.values()),'aggregate_sha256':agg.hexdigest(),'allocated_file_bytes':allocated,'unique':[],'missing':[],'extra':[],'mismatched':[],'symlinks_special_hardlinks':[]}
def sums(p):
 rows={}
 for line in (p/'SHA256SUMS.txt').read_text().splitlines():
  h,n=line.split('  ',1);assert n not in rows and sha((p/n).read_bytes())==h;rows[n]=h
 return rows
specs=[('recover_tier5_after_environment_change_20261112','candidate_rebuilt','remote_snapshot_3da3922','restored_snapshot','final_remote_publication_fd0355f'),('develop_lava_permanent_v2_20261112','candidate','remote_snapshot_0b2962c','single_tree_restore/restored_snapshot','final_remote_publication_7f88ffc807925d7c5c82345dffc91bab1b1516e0')]
rows=[];lockpath=R/'develop_empty_ghost_20261112/.independent_full_game.lock'
with lockpath.open('r') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 for stage,cand,remote,tree,finaldir in specs:
  root=R/stage;r=root/remote;pkg=r/'package';m=read(pkg/'MANIFEST.json');raw=gzip.decompress((pkg/'SOURCE_MAP.json.gz').read_bytes());expected=json.loads(raw);assert sha(raw)==m['source_map_sha256']
  first=scan(root/cand,expected,m['aggregate_sha256']);second=scan(r/tree,expected,m['aggregate_sha256']);assert first==second
  orig=sums(pkg);final=sums(root/finaldir);pub=read(root/'FINAL_PUBLICATION_VERIFIED.json');assert pub['status'].startswith('PASS')
  documented_differences=[n for n,h in orig.items() if final.get(n)!=h]
  assert documented_differences==(['RECOVERY.md'] if cand=='candidate_rebuilt' else []),documented_differences
  for n in ['delta.tar.xz','SOURCE_MAP.json.gz','MANIFEST.json']:assert orig[n]==final[n]
  preserved=[r/tree,r/'independent_tests',pkg,root/finaldir,root/'unaccepted_package'];assert all(x.is_dir() for x in preserved)
  rows.append({'candidate_path':str(root/cand),'classification':'completed_non_backup_development_work_copy','equivalent_preserved_restore':str(r/tree),'source_commit':pub['source_commit'],'final_commit':pub['commit'],'source_map_sha256':sha(raw),'manifest_sha256':sha((pkg/'MANIFEST.json').read_bytes()),'candidate_full_check':first,'restore_full_check':second,'publication_receipt':str(root/'FINAL_PUBLICATION_VERIFIED.json'),'publication_receipt_sha256':sha((root/'FINAL_PUBLICATION_VERIFIED.json').read_bytes()),'final_documentation_changes_not_source':documented_differences,'source_package_non_sums_verified':len(orig),'final_package_non_sums_verified':len(final),'preserved_directories':list(map(str,preserved))})
 report={'status':'PASS_READ_ONLY_TWO_COMPLETED_WORK_COPIES_EQUIVALENT_NO_DELETE','checked_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'common_lock':str(lockpath),'exclusive_lock_acquired':True,'targets':rows,'reclaimable_file_allocated_bytes':sum(x['candidate_full_check']['allocated_file_bytes'] for x in rows),'logical_bytes':sum(x['candidate_full_check']['bytes'] for x in rows),'disk':shutil.disk_usage(R)._asdict(),'deleted':[],'game_started':False}
 (P/'CLEANUP_PREFLIGHT.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
