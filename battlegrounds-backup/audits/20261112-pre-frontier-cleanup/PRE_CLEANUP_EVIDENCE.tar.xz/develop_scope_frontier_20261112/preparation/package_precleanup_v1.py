from pathlib import Path
import json,hashlib,tarfile,io,datetime
R=Path.cwd();P=Path(__file__).resolve().parent;S=P.parent
h=lambda b:hashlib.sha256(b).hexdigest(); enc=lambda v:(json.dumps(v,indent=2,sort_keys=True)+'\n').encode()
plan=json.loads((P/'SPACE_PLAN_V1.json').read_text()); assert plan['status']=='PASS_READ_ONLY_TWO_OPTIONAL_DUPLICATES_NO_DELETE' and plan['deleted']==[]
paths=[P/n for n in ['space_preflight_v1.py','space_preflight_v2.py','SPACE_PLAN_V1.log','SPACE_PLAN_V1_SUCCESS.log','SPACE_PLAN_V1.json','SPACE_PLAN_V1.md','PREFLIGHT_SCHEMA_CORRECTION.md','package_precleanup_v1.py']]
paths += [Path(r['path']) for r in plan['important_local_late_evidence']]
for row in plan['targets']:
 paths += [Path(r['path']) for r in row['proof_records']]
 paths += [Path(row['source_package'])/n for n in ['MANIFEST.json','SHA256SUMS.txt']]
paths=sorted(set(paths)); files={str(p.relative_to(R)):p.read_bytes() for p in paths}; assert all(not p.is_symlink() for p in paths)
for row in plan['targets']:
 for r in row['proof_records']:assert h(Path(r['path']).read_bytes())==r['sha256']
for r in plan['important_local_late_evidence']:assert h(Path(r['path']).read_bytes())==r['sha256']
out=P/'pre_cleanup_evidence_package';out.mkdir()
with tarfile.open(out/'PRE_CLEANUP_EVIDENCE.tar.xz','w:xz') as t:
 for n,b in files.items():
  i=tarfile.TarInfo(n);i.size=len(b);i.mode=0o644;t.addfile(i,io.BytesIO(b))
assert all(p.read_bytes()==files[str(p.relative_to(R))] for p in paths)
members={n:{'bytes':len(b),'sha256':h(b)} for n,b in files.items()}
with tarfile.open(out/'PRE_CLEANUP_EVIDENCE.tar.xz') as t:
 ms=t.getmembers();assert len(ms)==len(members)==len({x.name for x in ms})
 for x in ms:
  assert x.isfile() and not x.name.startswith('/') and '..' not in Path(x.name).parts
  b=t.extractfile(x).read();assert members[x.name]=={'bytes':len(b),'sha256':h(b)}
(out/'MEMBER_MANIFEST.json').write_bytes(enc({'archive_sha256':h((out/'PRE_CLEANUP_EVIDENCE.tar.xz').read_bytes()),'members':members,'files':len(members),'double_read_unchanged':True,'every_member_rehashed':True}))
(out/'README.md').write_text('''# Frontier pre-cleanup read-only evidence\n\nNo deletion, copy or Game has occurred. SPACE_PLAN_V1 records locked full-file/path/size/SHA/aggregate comparisons for exactly two possible targets:\n1. develop_lava_carried_sale_20261112/candidate, equal to retained remote_snapshot_32a8b33/single_tree_restore/restored_snapshot.\n2. recover_tier5_after_environment_change_20261112/restored_base, equal to retained audit_20261112T1000Z/restored_base.\n\nThey are completed successful development/intermediate dependency copies, not unique backups or final immutable restore trees. All remote snapshots, original/base inputs, fixed packages, failure/unfinished/unique material, logs and audit trees remain protected. Audit base remains preserved. Historical scripts mentioning the optional Tier5 base target must not be silently edited; any later workflow must use explicit new equivalent-path arguments or separately versioned tools.\n\nInitial read-only preflight failed because old base14 MANIFEST lacks aggregate_sha256. Preserved V2 script pins known base14 aggregate and checks it against both actual historical restore receipts, then hashes complete trees; it succeeded. Initial failure log and script are retained. All proof records and three prior late publication/metadata/actual final-audit readback files are included. Historical db9a unpublished wrapper loss remains disclosed; not claimed recovered.\n\nThis package does not authorize deletion. First publish and actually fresh-verify it; any later exact two-target deletion requires separate authorization, common-lock second complete equivalence and preserved dependencies checks. Then independent copy of current32a8 immutable may be authorized separately. Estimated reclaimable file blocks and post-next-copy/fresh55/one-restore budget are in the plan.\n\nRecovery: verify SHA256SUMS, then archive SHA and all safe regular-file members against MEMBER_MANIFEST.json. Extract only into a new evidence directory, retaining relative paths. This is evidence, not a complete source restore. Original artifacts were not modified.\n''')
(out/'SHA256SUMS').write_text(''.join(f'{h(p.read_bytes())}  {p.name}\n' for p in sorted(out.iterdir())))
folder='battlegrounds-backup/audits/20261112-pre-frontier-cleanup';records=[]
for p in sorted(out.iterdir()):
 b=p.read_bytes();records.append({'name':p.name,'path':folder+'/'+p.name,'bytes':len(b),'size':len(b),'sha256':h(b),'git_sha':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()})
meta={'status':'LOCAL_PRE_CLEANUP_EVIDENCE_READY_NO_DELETION','folder':folder,'remote_folder':folder,'package':str(out),'files':len(records),'bytes':sum(r['bytes'] for r in records),'evidence_members':len(members),'records':records}
with (P/'PRE_CLEANUP_UPLOAD_METADATA.json').open('xb') as f:f.write(enc(meta))
print(json.dumps(meta))
