# Read-only space plan V1

Two optional non-backup duplicates fully scanned against retained equivalents, exact file/path/bytes/SHA/aggregate; no unique, extra, symlink or hardlink files. No deletion or copying authorized/executed.

- /workspace/scratch/dd4f12b08ec0/develop_lava_carried_sale_20261112/candidate -> retained /workspace/scratch/dd4f12b08ec0/develop_lava_carried_sale_20261112/remote_snapshot_32a8b33/single_tree_restore/restored_snapshot; 27994 files / 1550944027 bytes.
- /workspace/scratch/dd4f12b08ec0/recover_tier5_after_environment_change_20261112/restored_base -> retained /workspace/scratch/dd4f12b08ec0/audit_20261112T1000Z/restored_base; 27920 files / 1549340406 bytes.

Current free 1543389184 bytes; reclaimable file allocation 3237208064; estimated remaining after independent candidate + fresh55 budget + one independent lowdisk restore/runtime tree: 1201636096 bytes. Directory-block overhead and future source growth not included.

Keep all remote snapshots, audit trees, source/input/packages, failure candidates/logs, immutable versions. First back up listed late receipts plus this preflight/script to a new remote audit and fresh-verify. Any later exact deletion requires parent authorization and locked second full comparison. Tier5 base is an old completed dependency intermediate; its retained audit equivalent and original/base14 fixed bytes are verified. Historical scripts must not be silently rewritten if removed. Historical db9a unpublished wrapper loss remains an exception, not claimed recovered.
