from pathlib import Path
import json,gzip,hashlib,fcntl,shutil,datetime
R=Path.cwd();P=Path(__file__).resolve().parent
ns={};exec((R/'develop_lava_next_20261112/preparation/cleanup_preflight.py').read_text().split('specs=')[0],ns);scan=ns['scan'];sums=ns['sums'];sha=lambda b:hashlib.sha256(b).hexdigest();read=lambda p:json.loads(p.read_text())
C=R/'develop_lava_carried_sale_20261112';T=R/'recover_tier5_after_environment_change_20261112';A=R/'audit_20261112T1000Z'
specs=[(C/'candidate',C/'remote_snapshot_32a8b33/single_tree_restore/restored_snapshot',C/'remote_snapshot_32a8b33/package','completed_successful_development_copy_not_backup'),(T/'restored_base',A/'restored_base',T/'base_package','completed_successful_tier5_reconstruction_base14_intermediate_not_final_snapshot')]
rows=[];lock=R/'develop_empty_ghost_20261112/.independent_full_game.lock'
with lock.open('r') as f:
 fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB)
 for target,equiv,pkg,classification in specs:
  m=read(pkg/'MANIFEST.json');raw=gzip.decompress((pkg/'SOURCE_MAP.json.gz').read_bytes());expected=json.loads(raw);assert sha(raw)==m['source_map_sha256'];agg=m['aggregate_sha256'] if target.name=='candidate' else '5ba04ef124fc78cf20e2a942a60589fb92dc76e6808155648226a534a4599e05';x=scan(target,expected,agg);y=scan(equiv,expected,agg);assert {k:v for k,v in x.items() if k!='allocated_file_bytes'}=={k:v for k,v in y.items() if k!='allocated_file_bytes'}
  checks=sums(pkg);proof=[]
  if target.name=='candidate':
   rp=C/'FINAL_COMBINED_V4_PUBLICATION_VERIFIED.json';pub=read(rp);assert pub['commit']=='6e3c116f4b0cd6c867f903bfe5944224e6916194' and pub['status'].startswith('PASS')
   final=C/('final_combined_v3_remote_'+pub['commit']);sums(final)
   for n,h in checks.items():assert sha((final/n).read_bytes())==h
   for q in pub['records']:
    b=(final/q['name']).read_bytes();assert len(b)==q['bytes'] and sha(b)==q['sha256']
   ar=C/'FINAL_COMBINED_V4_AUDIT_PUBLICATION_VERIFIED.json';assert read(ar)['commit']=='6e33350a74b013d770abae96be1ca4f4028209bf'
   proof=[rp,ar,C/'SOURCE_PUBLICATION.json',C/'remote_snapshot_32a8b33/RECOVERED_POST_ATTEMPT_AUDIT_V2.json',C/'validator_failure_backup_v1/PUBLICATION_VERIFIED.json']
  else:
   assert sha(gzip.decompress((A/'base_package/SOURCE_MAP.json.gz').read_bytes()))==sha(raw);assert sums(A/'base_package')==checks
   for p in [T/'original_release.zip',A/'original_release.zip']:assert p.stat().st_size==324041102 and sha(p.read_bytes())=='33b3a1a12185cf9035cec33da4fff7008c7680194eb045b37234fbb934803d65'
   for p in [T/'BASE_RESTORE_CURRENT.json',A/'BASE_RESTORE.json']:assert read(p)['aggregate_sha256']==agg
   pub=read(T/'FINAL_PUBLICATION_VERIFIED.json');assert pub['commit']=='fd0355f88ef67f7e05fb5eae8c7e677356624734' and pub['status'].startswith('PASS');sums(T/'final_remote_publication_fd0355f')
   proof=[T/'BASE_RESTORE_CURRENT.json',A/'BASE_RESTORE.json',T/'CURRENT_RECOVERY_VERIFIED.json',T/'FINAL_PUBLICATION_VERIFIED.json',T/'FRESH_DOWNLOAD_VERIFIED.json',A/'FRESH_DOWNLOAD_VERIFIED.json']
  rows.append({'target':str(target),'equivalent_preserved_tree':str(equiv),'classification':classification,'source_package':str(pkg),'source_map_sha256':sha(raw),'aggregate_sha256':agg,'target_full_check':x,'equivalent_full_check':y,'proof_records':[{'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in proof],'package_checksums_sha256':sha((pkg/'SHA256SUMS.txt').read_bytes())})
late=[C/'FINAL_COMBINED_V4_AUDIT_PUBLICATION.json',C/'FINAL_COMBINED_V4_AUDIT_PUBLICATION_VERIFIED.json',C/'FINAL_COMBINED_V4_AUDIT_UPLOAD_METADATA.json']
late_rows=[{'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes()),'reason':'created after final audit archive; preserve before any cleanup'} for p in late]
disk=shutil.disk_usage(R)._asdict();alloc=sum(x['target_full_check']['allocated_file_bytes'] for x in rows);new=rows[0]['target_full_check']['allocated_file_bytes'];report={'status':'PASS_READ_ONLY_TWO_OPTIONAL_DUPLICATES_NO_DELETE','checked_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'common_lock':str(lock),'targets':rows,'disk':disk,'reclaimable_file_allocated_bytes':alloc,'estimated_free_after_cleanup':disk['free']+alloc,'estimated_after_new_candidate_fresh55_single_restore':disk['free']+alloc-2*new-340000000,'planned_fresh55_budget_bytes':340000000,'important_local_late_evidence':late_rows,'deleted':[],'copied':[],'game_started':False,'cleanup_authorized':False,'historical_script_reference_warning':'Many historical scripts refer to recover_tier5.../restored_base. If separately authorized deletion occurs, use retained audit_20261112T1000Z/restored_base only via explicit new arguments/tool versions; never rewrite historical artifacts. Audit tree remains protected.','historical_db9a_wrapper_loss_not_recovered':True}
with (P/'SPACE_PLAN_V1.json').open('x') as f:json.dump(report,f,indent=2);f.write('\n')
(P/'SPACE_PLAN_V1.md').write_text('# Read-only space plan V1\n\nTwo optional non-backup duplicates fully scanned against retained equivalents, exact file/path/bytes/SHA/aggregate; no unique, extra, symlink or hardlink files. No deletion or copying authorized/executed.\n\n'+ '\n'.join(f"- {x['target']} -> retained {x['equivalent_preserved_tree']}; {x['target_full_check']['files']} files / {x['target_full_check']['bytes']} bytes." for x in rows)+f"\n\nCurrent free {disk['free']} bytes; reclaimable file allocation {alloc}; estimated remaining after independent candidate + fresh55 budget + one independent lowdisk restore/runtime tree: {report['estimated_after_new_candidate_fresh55_single_restore']} bytes. Directory-block overhead and future source growth not included.\n\nKeep all remote snapshots, audit trees, source/input/packages, failure candidates/logs, immutable versions. First back up listed late receipts plus this preflight/script to a new remote audit and fresh-verify. Any later exact deletion requires parent authorization and locked second full comparison. Tier5 base is an old completed dependency intermediate; its retained audit equivalent and original/base14 fixed bytes are verified. Historical scripts must not be silently rewritten if removed. Historical db9a unpublished wrapper loss remains an exception, not claimed recovered.\n")
print(json.dumps({'targets':len(rows),'reclaimable':alloc,'free':disk['free'],'estimated_after':report['estimated_after_new_candidate_fresh55_single_restore'],'late_files':len(late_rows)}))
