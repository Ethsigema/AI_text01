extends "res://tests/darkcrest_lava_buffed_sale_20261112/content_contract.gd"
