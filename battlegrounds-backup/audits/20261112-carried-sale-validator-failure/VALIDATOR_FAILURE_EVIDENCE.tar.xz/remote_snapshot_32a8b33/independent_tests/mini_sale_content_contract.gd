extends "res://tests/darkcrest_mini_sale_20261112/content_contract.gd"
