extends "res://tests/darkcrest_lava_permanent_20261112/content_contract.gd"
