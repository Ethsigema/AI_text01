extends "res://tests/darkcrest_lava_carried_sale_20261112/content_contract.gd"
