from pathlib import Path,PurePosixPath
import json,hashlib,subprocess,datetime,shutil
R=Path(__file__).resolve().parent.parent
sha=lambda b:hashlib.sha256(b).hexdigest();read=lambda p:json.loads(p.read_text())
meta=read(R/'FINAL_VERIFICATION_AUDIT_UPLOAD_METADATA.json');pub=read(R/'FINAL_VERIFICATION_AUDIT_PUBLICATION.json');commit=pub['commit'];assert commit=='fe0c37566b75e82ffdc1ab5619e0018962a7e73b';folder=meta['remote_folder'];assert folder=='battlegrounds-backup/audits/20261112-mini-native-sale-final-verified'
out=R/'final_audit_remote_fe0c375';out.mkdir(exist_ok=False);records=[]
for x in meta['records']:
 n=x['name'];assert n==PurePosixPath(n).name and n not in ('','.','..');url=f'https://raw.githubusercontent.com/Ethsigema/AI_text01/{commit}/{folder}/{n}';p=out/n
 subprocess.run(['curl','-fsSL','--retry','3','--connect-timeout','30','--max-time','120',url,'-o',str(p)],check=True)
 b=p.read_bytes();assert len(b)==x['bytes'] and sha(b)==x['sha256'] and hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==x['git_sha'];records.append({**x,'url':url})
assert {x.name for x in out.iterdir()}=={x['name'] for x in records} and len(records)==19
seen=set()
for line in (out/'SHA256SUMS.txt').read_text().splitlines():
 h,n=line.split('  ',1);assert n not in seen and n==PurePosixPath(n).name and n!='SHA256SUMS.txt' and sha((out/n).read_bytes())==h;seen.add(n)
assert seen=={x['name'] for x in records}-{'SHA256SUMS.txt'}
for n in ['SOURCE_PUBLICATION.json','FINAL_PUBLICATION.json','FINAL_PUBLICATION_VERIFIED.json','FINAL_UPLOAD_METADATA.json','FINAL_PUBLICATION_FILES.json','EARLY_PUBLICATION_VERIFIED.json']:
 assert (out/n).read_bytes()==(R/n).read_bytes()
assert read(out/'SOURCE_PUBLICATION.json')['commit']=='a96a03307c43c5641793663b99e864877543d1b5';assert read(out/'FINAL_PUBLICATION.json')['commit']=='d914d66999536eb4250841488d09ae7ba3f82ccf'
v=read(out/'FINAL_PUBLICATION_VERIFIED.json');assert v['files']==30 and sum(v['archive_member_counts'].values())==468 and v['outcome']=='success'
r={'status':'PASS_FRESH_FINAL_AUDIT_PUBLICATION_ALL_FILES','commit':commit,'files':19,'bytes':sum(x['bytes'] for x in records),'records':records,'sha256sums_sha256':sha((out/'SHA256SUMS.txt').read_bytes()),'source_and_final_reference_bytes_unchanged':True,'verified_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'game_started':False,'new_restore':False,'source_modified':False,'further_recursive_publication':False,'disk':shutil.disk_usage(R)._asdict()};(R/'FINAL_VERIFICATION_AUDIT_PUBLICATION_VERIFIED.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:v for k,v in r.items() if k!='records'},indent=2))
